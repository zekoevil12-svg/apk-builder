package com.rifq.app.prayerfocus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Restores Prayer Device Lock state and reschedules exact alarms after:
 * - Device reboot (BOOT_COMPLETED / LOCKED_BOOT_COMPLETED / QUICKBOOT_POWERON)
 * - App update (MY_PACKAGE_REPLACED)
 * - System clock change (TIME_SET)
 * - Timezone change (TIMEZONE_CHANGED)
 *
 * Requirement 21 Guarantee:
 * If a reboot occurs mid-prayer (e.g., Adhan at 12:35, Reboot at 12:45, End at 12:55),
 * PrayerFocusBootReceiver restores the exact [12:35, 12:55] window (10 minutes remaining)
 * without starting a new 20-minute timer, schedules the exact 12:55 end alarm, and enforces
 * Prayer Device Lock immediately once Keyguard is unlocked.
 */
public class PrayerFocusBootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        String action = intent.getAction();
        if (action == null) return;

        if (
            Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
            Intent.ACTION_TIME_CHANGED.equals(action) ||
            Intent.ACTION_TIMEZONE_CHANGED.equals(action) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(action) ||
            PrayerDeviceLockService.ACTION_RESCHEDULE_PRAYER_LOCKS.equals(action)
        ) {
            SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
            boolean enabled = prefs.getBoolean(PrayerFocusPrefs.KEY_ENABLED, false);

            // 1. Recompute today's and tomorrow's 20-minute prayer windows natively
            NativePrayerTimeCalculator.computeTodayAndTomorrowWindows(context);

            if (!enabled) {
                return;
            }

            // 2. Reschedule all upcoming start & end alarms via AlarmManager & PrayerDeviceLockService
            PrayerFocusAlarmReceiver.scheduleUpcomingAlarms(context);
            PrayerDeviceLockService.startAndScheduleAlarms(context);

            // 3. Configure Kiosk Lock Task policy if Device Owner
            if (PrayerDeviceAdminReceiver.isDeviceOwner(context)) {
                PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(context);
            }

            // 4. If reboot happened mid-prayer (currentTime < endTimestamp) and device is already unlocked,
            // enforce Prayer Device Lock immediately for the remaining minutes!
            PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
            if (active != null && System.currentTimeMillis() < active.endTimeMs) {
                if (!PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                    PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(context, active, "BOOT_RECOVERY");
                }
            }
        }
    }
}
