package com.rifq.app.widgets;

/**
 * Official Android Home Screen Widget Provider for RIFQ Prayer Times & Adhan («مواقيت الصلاة والأذان»).
 */
public class RifqPrayerWidgetProvider extends RifqBaseWidgetProvider {
    @Override
    protected String getDefaultWidgetType() {
        return "prayer";
    }
}
