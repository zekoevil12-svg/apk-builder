package com.rifq.app.audioathkar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.rifq.app.notifications.RifqNotificationChannels;
import com.rifq.app.notifications.RifqNotificationHelper;

/**
 * BroadcastReceiver for RIFQ Spoken Audio Athkar:
 * 1. Handles scheduled audio Dhikr alarms (`ACTION_TRIGGER_SCHEDULED_AUDIO_DHIKR`)
 * 2. Handles immediate stop button taps from notifications or widgets (`ACTION_STOP_AUDIO_DHIKR`)
 * 3. Handles speaking a specific Dhikr from notification actions or widgets (`ACTION_SPEAK_SPECIFIC_DHIKR`)
 */
public class RifqAudioAthkarReceiver extends BroadcastReceiver {

    public static final String ACTION_TRIGGER_SCHEDULED_AUDIO_DHIKR =
        "com.rifq.app.audioathkar.ACTION_TRIGGER_SCHEDULED_AUDIO_DHIKR";
    public static final String ACTION_SPEAK_SPECIFIC_DHIKR =
        "com.rifq.app.audioathkar.ACTION_SPEAK_SPECIFIC_DHIKR";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || intent.getAction() == null) {
            return;
        }

        String action = intent.getAction();

        if (RifqAudioAthkarService.ACTION_STOP_AUDIO_DHIKR.equals(action)) {
            RifqAudioAthkarService.stopSpeakingNow(context);
            return;
        }

        if (ACTION_SPEAK_SPECIFIC_DHIKR.equals(action)) {
            String text = intent.getStringExtra(RifqAudioAthkarService.EXTRA_DHIKR_TEXT);
            String title = intent.getStringExtra(RifqAudioAthkarService.EXTRA_DHIKR_TITLE);
            String source = intent.getStringExtra(RifqAudioAthkarService.EXTRA_DHIKR_SOURCE);
            String category = intent.getStringExtra(RifqAudioAthkarService.EXTRA_CATEGORY_OVERRIDE);
            RifqAudioAthkarService.speakDhikrNow(
                context,
                text,
                title,
                source,
                category,
                true,
                false
            );
            return;
        }

        if (ACTION_TRIGGER_SCHEDULED_AUDIO_DHIKR.equals(action)) {
            RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(context);
            if (!cfg.enabled) {
                return;
            }

            // Pick next non-repeating authentic Dhikr
            RifqAudioAthkarCatalog.AudioDhikrEntry dhikr =
                RifqAudioAthkarCatalog.pickNextNonRepeatingDhikr(context, null);

            if ("text_only".equalsIgnoreCase(cfg.alertMode)) {
                // Text notification only (no spoken audio)
                if (!RifqAudioAthkarPrefs.isWithinQuietHours(cfg, java.util.Calendar.getInstance())) {
                    RifqNotificationHelper.showSystemNotification(
                        context,
                        (int) (System.currentTimeMillis() & 0x7FFFFFFF),
                        RifqNotificationChannels.CHANNEL_ADHKAR,
                        "🌿 " + dhikr.title,
                        dhikr.text,
                        "moment_dhikr",
                        "",
                        dhikr.id,
                        "audio_sched_" + System.currentTimeMillis(),
                        false,
                        true
                    );
                }
            } else if ("audio_only".equalsIgnoreCase(cfg.alertMode)) {
                // Spoken audio only (with temporary stop control while speaking)
                RifqAudioAthkarService.speakDhikrNow(
                    context,
                    dhikr.text,
                    dhikr.title,
                    dhikr.source,
                    dhikr.category,
                    false,
                    false
                );
            } else {
                // "text_and_audio": both text notification + spoken audio
                RifqAudioAthkarService.speakDhikrNow(
                    context,
                    dhikr.text,
                    dhikr.title,
                    dhikr.source,
                    dhikr.category,
                    false,
                    true
                );
            }

            // Schedule the next occurrence
            RifqAudioAthkarScheduler.rescheduleAll(context);
        }
    }
}
