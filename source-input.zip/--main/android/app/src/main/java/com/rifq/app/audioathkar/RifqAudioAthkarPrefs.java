package com.rifq.app.audioathkar;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Device-protected SharedPreferences manager for RIFQ Spoken Audio Athkar («الأذكار الصوتية»).
 *
 * Persists all user controls on the Android device so background alarms, boot receivers,
 * notifications, and Home Screen Widgets can read them even when RIFQ is closed or after reboot.
 */
public class RifqAudioAthkarPrefs {

    public static final String PREFS_NAME = "rifq_audio_athkar_prefs";
    private static final Object LOCK = new Object();

    // User setting keys
    public static final String KEY_ENABLED = "audio_athkar_enabled";
    public static final String KEY_ALERT_MODE = "audio_athkar_alert_mode"; // "text_only" | "audio_only" | "text_and_audio"
    public static final String KEY_CATEGORIES_JSON = "audio_athkar_categories_json"; // ["all"] or ["general","morning","evening","salawat"]
    public static final String KEY_SCHEDULE_MODE = "audio_athkar_schedule_mode"; // "with_notifications" | "interval" | "custom_times"
    public static final String KEY_INTERVAL_MINUTES = "audio_athkar_interval_minutes"; // 60, 120, 180, 360
    public static final String KEY_CUSTOM_TIMES_JSON = "audio_athkar_custom_times_json"; // ["08:00","14:00","20:00"]
    public static final String KEY_QUIET_HOURS_ENABLED = "audio_athkar_quiet_enabled";
    public static final String KEY_QUIET_HOURS_START = "audio_athkar_quiet_start"; // "22:30"
    public static final String KEY_QUIET_HOURS_END = "audio_athkar_quiet_end"; // "05:00"
    public static final String KEY_RESPECT_SILENT_DND = "audio_athkar_respect_silent_dnd";
    public static final String KEY_RESPECT_ACTIVE_AUDIO = "audio_athkar_respect_active_audio";
    public static final String KEY_SPEECH_RATE = "audio_athkar_speech_rate";
    public static final String KEY_SPEECH_PITCH = "audio_athkar_speech_pitch";
    public static final String KEY_VOLUME = "audio_athkar_volume";
    public static final String KEY_PREFERRED_VOICE_NAME = "audio_athkar_preferred_voice";

    // Synced catalog & non-repeating history keys
    public static final String KEY_SYNCED_CATALOG_JSON = "audio_athkar_synced_catalog_json";
    public static final String KEY_LAST_SPOKEN_IDS_JSON = "audio_athkar_last_spoken_ids_json";
    public static final String KEY_LAST_SPOKEN_AT_MS = "audio_athkar_last_spoken_at_ms";
    public static final String KEY_NEXT_SCHEDULED_AT_MS = "audio_athkar_next_scheduled_at_ms";

    // Live playback state keys (for widgets & notifications)
    public static final String KEY_IS_PLAYING = "audio_athkar_is_playing";
    public static final String KEY_PLAYING_SINCE_MS = "audio_athkar_playing_since_ms";
    public static final String KEY_CURRENT_PLAYING_TEXT = "audio_athkar_current_text";
    public static final String KEY_CURRENT_PLAYING_SOURCE = "audio_athkar_current_source";
    public static final String KEY_DETECTED_VOICE_SUMMARY = "audio_athkar_detected_voice_summary";
    public static final String KEY_IS_MALE_VOICE_MATCHED = "audio_athkar_is_male_voice_matched";

    public static class AudioAthkarConfig {
        public boolean enabled = true;
        public String alertMode = "text_and_audio"; // "text_only" | "audio_only" | "text_and_audio"
        public List<String> categories = new ArrayList<>(); // "all" | "general" | "morning" | "evening" | "salawat"
        public String scheduleMode = "with_notifications"; // "with_notifications" | "interval" | "custom_times"
        public int intervalMinutes = 120; // 120 = every 2 hours
        public List<String> customTimes = new ArrayList<>();
        public boolean quietHoursEnabled = true;
        public String quietHoursStart = "22:30";
        public String quietHoursEnd = "05:00";
        public boolean respectSilentAndDnd = true;
        public boolean respectActiveAudio = true;
        public float speechRate = 0.86f;
        public float speechPitch = 0.92f;
        public float volume = 0.88f;
        public String preferredVoiceName = "";
    }

    public static SharedPreferences getPrefs(Context context) {
        Context appCtx = context.getApplicationContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Context deviceCtx = appCtx.createDeviceProtectedStorageContext();
            if (deviceCtx != null) {
                return deviceCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            }
        }
        return appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static AudioAthkarConfig loadConfig(Context context) {
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            AudioAthkarConfig cfg = new AudioAthkarConfig();
            cfg.enabled = prefs.getBoolean(KEY_ENABLED, true);
            cfg.alertMode = prefs.getString(KEY_ALERT_MODE, "text_and_audio");
            if (cfg.alertMode == null || cfg.alertMode.isEmpty()) {
                cfg.alertMode = "text_and_audio";
            }

            String catsRaw = prefs.getString(KEY_CATEGORIES_JSON, "[\"all\"]");
            try {
                JSONArray arr = new JSONArray(catsRaw);
                for (int i = 0; i < arr.length(); i++) {
                    String c = arr.optString(i, "").trim();
                    if (!c.isEmpty()) cfg.categories.add(c);
                }
            } catch (Exception ignored) {
            }
            if (cfg.categories.isEmpty()) {
                cfg.categories.add("all");
            }

            cfg.scheduleMode = prefs.getString(KEY_SCHEDULE_MODE, "with_notifications");
            if (cfg.scheduleMode == null || cfg.scheduleMode.isEmpty()) {
                cfg.scheduleMode = "with_notifications";
            }
            cfg.intervalMinutes = Math.max(30, prefs.getInt(KEY_INTERVAL_MINUTES, 120));

            String timesRaw = prefs.getString(KEY_CUSTOM_TIMES_JSON, "[\"08:00\",\"13:30\",\"17:30\",\"21:00\"]");
            try {
                JSONArray arr = new JSONArray(timesRaw);
                for (int i = 0; i < arr.length(); i++) {
                    String t = arr.optString(i, "").trim();
                    if (t.matches("^\\d{2}:\\d{2}$")) {
                        cfg.customTimes.add(t);
                    }
                }
            } catch (Exception ignored) {
            }
            if (cfg.customTimes.isEmpty()) {
                cfg.customTimes.add("08:00");
                cfg.customTimes.add("13:30");
                cfg.customTimes.add("17:30");
                cfg.customTimes.add("21:00");
            }

            cfg.quietHoursEnabled = prefs.getBoolean(KEY_QUIET_HOURS_ENABLED, true);
            cfg.quietHoursStart = prefs.getString(KEY_QUIET_HOURS_START, "22:30");
            cfg.quietHoursEnd = prefs.getString(KEY_QUIET_HOURS_END, "05:00");
            cfg.respectSilentAndDnd = prefs.getBoolean(KEY_RESPECT_SILENT_DND, true);
            cfg.respectActiveAudio = prefs.getBoolean(KEY_RESPECT_ACTIVE_AUDIO, true);
            cfg.speechRate = clampFloat(prefs.getFloat(KEY_SPEECH_RATE, 0.86f), 0.65f, 1.25f);
            cfg.speechPitch = clampFloat(prefs.getFloat(KEY_SPEECH_PITCH, 0.92f), 0.70f, 1.20f);
            cfg.volume = clampFloat(prefs.getFloat(KEY_VOLUME, 0.88f), 0.10f, 1.0f);
            cfg.preferredVoiceName = prefs.getString(KEY_PREFERRED_VOICE_NAME, "");
            return cfg;
        }
    }

    public static void saveConfig(Context context, AudioAthkarConfig cfg) {
        if (context == null || cfg == null) return;
        synchronized (LOCK) {
            JSONArray catsArr = new JSONArray();
            if (cfg.categories == null || cfg.categories.isEmpty()) {
                catsArr.put("all");
            } else {
                for (String c : cfg.categories) {
                    if (c != null && !c.trim().isEmpty()) {
                        catsArr.put(c.trim());
                    }
                }
            }

            JSONArray timesArr = new JSONArray();
            if (cfg.customTimes != null) {
                for (String t : cfg.customTimes) {
                    if (t != null && t.trim().matches("^\\d{2}:\\d{2}$")) {
                        timesArr.put(t.trim());
                    }
                }
            }
            if (timesArr.length() == 0) {
                timesArr.put("08:00");
                timesArr.put("13:30");
                timesArr.put("17:30");
                timesArr.put("21:00");
            }

            getPrefs(context).edit()
                .putBoolean(KEY_ENABLED, cfg.enabled)
                .putString(KEY_ALERT_MODE, cfg.alertMode != null ? cfg.alertMode : "text_and_audio")
                .putString(KEY_CATEGORIES_JSON, catsArr.toString())
                .putString(KEY_SCHEDULE_MODE, cfg.scheduleMode != null ? cfg.scheduleMode : "with_notifications")
                .putInt(KEY_INTERVAL_MINUTES, Math.max(30, cfg.intervalMinutes))
                .putString(KEY_CUSTOM_TIMES_JSON, timesArr.toString())
                .putBoolean(KEY_QUIET_HOURS_ENABLED, cfg.quietHoursEnabled)
                .putString(KEY_QUIET_HOURS_START, cfg.quietHoursStart != null ? cfg.quietHoursStart : "22:30")
                .putString(KEY_QUIET_HOURS_END, cfg.quietHoursEnd != null ? cfg.quietHoursEnd : "05:00")
                .putBoolean(KEY_RESPECT_SILENT_DND, cfg.respectSilentAndDnd)
                .putBoolean(KEY_RESPECT_ACTIVE_AUDIO, cfg.respectActiveAudio)
                .putFloat(KEY_SPEECH_RATE, clampFloat(cfg.speechRate, 0.65f, 1.25f))
                .putFloat(KEY_SPEECH_PITCH, clampFloat(cfg.speechPitch, 0.70f, 1.20f))
                .putFloat(KEY_VOLUME, clampFloat(cfg.volume, 0.10f, 1.0f))
                .putString(KEY_PREFERRED_VOICE_NAME, cfg.preferredVoiceName != null ? cfg.preferredVoiceName : "")
                .commit();
        }
    }

    public static JSONObject toJsonObject(Context context) {
        AudioAthkarConfig cfg = loadConfig(context);
        SharedPreferences prefs = getPrefs(context);
        JSONObject obj = new JSONObject();
        try {
            obj.put("enabled", cfg.enabled);
            obj.put("alertMode", cfg.alertMode);
            JSONArray cats = new JSONArray();
            for (String c : cfg.categories) cats.put(c);
            obj.put("categories", cats);
            obj.put("scheduleMode", cfg.scheduleMode);
            obj.put("intervalMinutes", cfg.intervalMinutes);
            JSONArray times = new JSONArray();
            for (String t : cfg.customTimes) times.put(t);
            obj.put("customTimes", times);
            obj.put("quietHoursEnabled", cfg.quietHoursEnabled);
            obj.put("quietHoursStart", cfg.quietHoursStart);
            obj.put("quietHoursEnd", cfg.quietHoursEnd);
            obj.put("respectSilentAndDnd", cfg.respectSilentAndDnd);
            obj.put("respectActiveAudio", cfg.respectActiveAudio);
            obj.put("speechRate", cfg.speechRate);
            obj.put("speechPitch", cfg.speechPitch);
            obj.put("volume", cfg.volume);
            obj.put("preferredVoiceName", cfg.preferredVoiceName);
            obj.put("isPlaying", isCurrentlyPlaying(context));
            obj.put("currentPlayingText", prefs.getString(KEY_CURRENT_PLAYING_TEXT, ""));
            obj.put("currentPlayingSource", prefs.getString(KEY_CURRENT_PLAYING_SOURCE, ""));
            obj.put("detectedVoiceSummary", prefs.getString(KEY_DETECTED_VOICE_SUMMARY, "صوت عربي ذكوري هادئ"));
            obj.put("isMaleVoiceMatched", prefs.getBoolean(KEY_IS_MALE_VOICE_MATCHED, true));
            obj.put("nextScheduledAtMs", prefs.getLong(KEY_NEXT_SCHEDULED_AT_MS, 0L));
        } catch (Exception ignored) {
        }
        return obj;
    }

    public static boolean isWithinQuietHours(AudioAthkarConfig cfg, Calendar cal) {
        if (cfg == null || !cfg.quietHoursEnabled) return false;
        int startMins = parseTimeMinutes(cfg.quietHoursStart, 22 * 60 + 30);
        int endMins = parseTimeMinutes(cfg.quietHoursEnd, 5 * 60);
        int nowMins = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);

        if (startMins <= endMins) {
            return nowMins >= startMins && nowMins < endMins;
        } else {
            // Spans across midnight (e.g., 22:30 -> 05:00)
            return nowMins >= startMins || nowMins < endMins;
        }
    }

    /**
     * Checks all polite playback rules before playing a scheduled / automatic spoken Dhikr:
     * 1. Feature enabled & alertMode includes audio ("audio_only" or "text_and_audio")
     * 2. Not within Quiet Hours (when automatic)
     * 3. Not during an active phone/VoIP call or ringtone
     * 4. Respects Silent / Vibrate / Do Not Disturb mode (unless user disabled respectSilentAndDnd)
     * 5. Does not interrupt other active media playback if respectActiveAudio is enabled
     */
    public static boolean canPlayAudioNow(Context context, boolean isManualUserTrigger) {
        if (context == null) return false;
        AudioAthkarConfig cfg = loadConfig(context);

        if (!isManualUserTrigger) {
            if (!cfg.enabled) return false;
            if ("text_only".equalsIgnoreCase(cfg.alertMode)) return false;
            if (isWithinQuietHours(cfg, Calendar.getInstance())) return false;
        }

        try {
            AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int mode = am.getMode();
                // Never play spoken Dhikr during a phone call, VoIP call, or incoming ring
                if (
                    mode == AudioManager.MODE_IN_CALL ||
                    mode == AudioManager.MODE_IN_COMMUNICATION ||
                    mode == AudioManager.MODE_RINGTONE
                ) {
                    return false;
                }

                if (!isManualUserTrigger) {
                    if (cfg.respectSilentAndDnd) {
                        int ringerMode = am.getRingerMode();
                        if (ringerMode == AudioManager.RINGER_MODE_SILENT || ringerMode == AudioManager.RINGER_MODE_VIBRATE) {
                            return false;
                        }
                    }

                    if (cfg.respectActiveAudio && am.isMusicActive()) {
                        return false;
                    }
                }
            }

            if (!isManualUserTrigger && cfg.respectSilentAndDnd && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    int filter = nm.getCurrentInterruptionFilter();
                    if (
                        filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
                        filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
                    ) {
                        return false;
                    }
                }
            }
        } catch (Exception ignored) {
        }

        return true;
    }

    public static void setPlayingState(Context context, boolean playing, String text, String source) {
        if (context == null) return;
        getPrefs(context).edit()
            .putBoolean(KEY_IS_PLAYING, playing)
            .putLong(KEY_PLAYING_SINCE_MS, playing ? System.currentTimeMillis() : 0L)
            .putString(KEY_CURRENT_PLAYING_TEXT, playing && text != null ? text : "")
            .putString(KEY_CURRENT_PLAYING_SOURCE, playing && source != null ? source : "")
            .commit();
    }

    public static boolean isCurrentlyPlaying(Context context) {
        if (context == null) return false;
        SharedPreferences prefs = getPrefs(context);
        boolean flag = prefs.getBoolean(KEY_IS_PLAYING, false);
        if (!flag) return false;
        long since = prefs.getLong(KEY_PLAYING_SINCE_MS, 0L);
        // Auto-expire stale flag after 45 seconds
        if (System.currentTimeMillis() - since > 45_000L) {
            setPlayingState(context, false, "", "");
            return false;
        }
        return true;
    }

    public static List<String> getLastSpokenIds(Context context) {
        List<String> list = new ArrayList<>();
        if (context == null) return list;
        String raw = getPrefs(context).getString(KEY_LAST_SPOKEN_IDS_JSON, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String id = arr.optString(i, "");
                if (!id.isEmpty()) list.add(id);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static void recordSpokenDhikrId(Context context, String id) {
        if (context == null || id == null || id.isEmpty()) return;
        synchronized (LOCK) {
            List<String> recent = getLastSpokenIds(context);
            recent.remove(id);
            recent.add(0, id);
            while (recent.size() > 14) {
                recent.remove(recent.size() - 1);
            }
            JSONArray arr = new JSONArray();
            for (String item : recent) arr.put(item);
            getPrefs(context).edit()
                .putString(KEY_LAST_SPOKEN_IDS_JSON, arr.toString())
                .putLong(KEY_LAST_SPOKEN_AT_MS, System.currentTimeMillis())
                .apply();
        }
    }

    public static int parseTimeMinutes(String hhmm, int fallbackMinutes) {
        if (hhmm == null) return fallbackMinutes;
        try {
            String[] parts = hhmm.trim().split(":");
            if (parts.length == 2) {
                int h = Integer.parseInt(parts[0]);
                int m = Integer.parseInt(parts[1]);
                if (h >= 0 && h <= 23 && m >= 0 && m <= 59) {
                    return h * 60 + m;
                }
            }
        } catch (Exception ignored) {
        }
        return fallbackMinutes;
    }

    private static float clampFloat(float val, float min, float max) {
        if (Float.isNaN(val)) return min;
        return Math.max(min, Math.min(max, val));
    }
}
