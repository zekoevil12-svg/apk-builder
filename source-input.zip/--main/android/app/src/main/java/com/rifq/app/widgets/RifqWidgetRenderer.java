package com.rifq.app.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import com.rifq.app.MainActivity;
import com.rifq.app.R;
import com.rifq.app.notifications.RifqNotificationHelper;

/**
 * Renders Android Native `RemoteViews` for all 4 RIFQ Home Screen Widget types:
 * 1. "tasbeeh" (عداد التسبيح اليومي)
 * 2. "prayer"  (مواقيت الصلاة والأذان)
 * 3. "dhikr"   (ذكر اليوم المبارك)
 * 4. "multi"   (الويدجت الشامل)
 *
 * Supports responsive sizes (Small 2x2, Medium 4x2, Large 4x4) and all 4 RIFQ themes
 * ("navy", "gold", "midnight", "cream") using real offline/synced user data.
 */
public class RifqWidgetRenderer {

    public static final String ACTION_INCREMENT_TASBEEH = "com.rifq.app.widget.ACTION_INCREMENT_TASBEEH";
    public static final String ACTION_CYCLE_TASBEEH_DHIKR = "com.rifq.app.widget.ACTION_CYCLE_TASBEEH_DHIKR";
    public static final String ACTION_NEXT_DHIKR = "com.rifq.app.widget.ACTION_NEXT_DHIKR";
    public static final String ACTION_COPY_DHIKR = "com.rifq.app.widget.ACTION_COPY_DHIKR";
    public static final String ACTION_SPEAK_DHIKR = "com.rifq.app.widget.ACTION_SPEAK_DHIKR";
    public static final String ACTION_REFRESH_WIDGET = "com.rifq.app.widget.ACTION_REFRESH_WIDGET";
    public static final String ACTION_WIDGET_PINNED = "com.rifq.app.widget.ACTION_WIDGET_PINNED";
    public static final String ACTION_AUTO_UPDATE_PRAYER_TRANSITION = "com.rifq.app.widget.ACTION_AUTO_UPDATE_PRAYER_TRANSITION";

    private static class ThemePalette {
        final int bgResId;
        final int badgeResId;
        final int btnResId;
        final int btnTextColor;
        final int primaryTextColor;
        final int secondaryTextColor;
        final int accentTextColor;
        final int badgeTextColor;

        ThemePalette(
            int bgResId,
            int badgeResId,
            int btnResId,
            int btnTextColor,
            int primaryTextColor,
            int secondaryTextColor,
            int accentTextColor,
            int badgeTextColor
        ) {
            this.bgResId = bgResId;
            this.badgeResId = badgeResId;
            this.btnResId = btnResId;
            this.btnTextColor = btnTextColor;
            this.primaryTextColor = primaryTextColor;
            this.secondaryTextColor = secondaryTextColor;
            this.accentTextColor = accentTextColor;
            this.badgeTextColor = badgeTextColor;
        }
    }

    private static ThemePalette resolveThemePalette(String theme) {
        if ("gold".equalsIgnoreCase(theme)) {
            return new ThemePalette(
                R.drawable.bg_rifq_widget_gold,
                R.drawable.bg_rifq_widget_badge_light,
                R.drawable.bg_rifq_widget_btn_indigo,
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#25263A"),
                Color.parseColor("#6E7185"),
                Color.parseColor("#4145C7"),
                Color.parseColor("#4145C7")
            );
        }
        if ("cream".equalsIgnoreCase(theme)) {
            return new ThemePalette(
                R.drawable.bg_rifq_widget_cream,
                R.drawable.bg_rifq_widget_badge_light,
                R.drawable.bg_rifq_widget_btn_indigo,
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#25263A"),
                Color.parseColor("#77798C"),
                Color.parseColor("#5B5FEF"),
                Color.parseColor("#4145C7")
            );
        }
        if ("midnight".equalsIgnoreCase(theme)) {
            return new ThemePalette(
                R.drawable.bg_rifq_widget_midnight,
                R.drawable.bg_rifq_widget_badge_dark,
                R.drawable.bg_rifq_widget_btn_indigo,
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#D0D2E0"),
                Color.parseColor("#72B7E8"),
                Color.parseColor("#72B7E8")
            );
        }
        // Default: "navy" (الأزرق الملكي - الهوية الرسمية لرِفْق)
        return new ThemePalette(
            R.drawable.bg_rifq_widget_navy,
            R.drawable.bg_rifq_widget_badge_dark,
            R.drawable.bg_rifq_widget_btn_gold,
            Color.parseColor("#25263A"),
            Color.parseColor("#FFFFFF"),
            Color.parseColor("#DCE0FF"),
            Color.parseColor("#E8B84A"),
            Color.parseColor("#FFF8E7")
        );
    }

    /**
     * Resolves the effective widget size ("small" | "medium" | "large") based on user config
     * and live launcher resize dimensions (`AppWidgetManager.getAppWidgetOptions`).
     */
    public static String resolveEffectiveSize(
        AppWidgetManager appWidgetManager,
        int appWidgetId,
        String configuredSize
    ) {
        if ("small".equalsIgnoreCase(configuredSize)
            || "medium".equalsIgnoreCase(configuredSize)
            || "large".equalsIgnoreCase(configuredSize)) {
            // Still check if the user explicitly resized the widget very small on the launcher
            if (appWidgetManager != null && appWidgetId != 0) {
                try {
                    Bundle opts = appWidgetManager.getAppWidgetOptions(appWidgetId);
                    if (opts != null) {
                        int minW = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
                        int minH = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
                        if (minW > 0 && minW < 165) {
                            return "small";
                        }
                        if (minH >= 200 && minW >= 220) {
                            return "large";
                        }
                    }
                } catch (Exception ignored) {
                }
            }
            return configuredSize.toLowerCase();
        }

        // "auto" responsive size detection from Launcher grid bounds
        if (appWidgetManager != null && appWidgetId != 0) {
            try {
                Bundle opts = appWidgetManager.getAppWidgetOptions(appWidgetId);
                if (opts != null) {
                    int minW = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 200);
                    int minH = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120);
                    if (minW < 165) {
                        return "small";
                    }
                    if (minH >= 190) {
                        return "large";
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return "medium";
    }

    public static RemoteViews buildWidgetRemoteViews(
        Context context,
        AppWidgetManager appWidgetManager,
        int appWidgetId,
        Class<?> providerClass,
        String defaultType
    ) {
        RifqWidgetPrefs.WidgetInstanceConfig cfg = RifqWidgetPrefs.getWidgetConfig(context, appWidgetId, defaultType);
        String effectiveType = cfg.type != null ? cfg.type : defaultType;
        String effectiveSize = resolveEffectiveSize(appWidgetManager, appWidgetId, cfg.size);
        ThemePalette palette = resolveThemePalette(cfg.theme);

        if ("prayer".equalsIgnoreCase(effectiveType)) {
            return buildPrayerRemoteViews(context, appWidgetId, providerClass, effectiveSize, palette, cfg.targetPrayer);
        } else if ("dhikr".equalsIgnoreCase(effectiveType)) {
            return buildDhikrRemoteViews(context, appWidgetId, providerClass, effectiveSize, palette);
        } else if ("multi".equalsIgnoreCase(effectiveType)) {
            return buildMultiRemoteViews(context, appWidgetId, providerClass, effectiveSize, palette, cfg.targetPrayer, cfg.statsMode);
        } else {
            return buildTasbeehRemoteViews(context, appWidgetId, providerClass, effectiveSize, palette, cfg.customDhikr, cfg.statsMode);
        }
    }

    private static RemoteViews buildTasbeehRemoteViews(
        Context context,
        int appWidgetId,
        Class<?> providerClass,
        String size,
        ThemePalette palette,
        String instanceCustomDhikr,
        String statsMode
    ) {
        boolean isSmall = "small".equalsIgnoreCase(size);
        boolean isLarge = "large".equalsIgnoreCase(size);
        int layoutId = isSmall ? R.layout.widget_rifq_tasbeeh_small : R.layout.widget_rifq_tasbeeh;

        RemoteViews views = new RemoteViews(context.getPackageName(), layoutId);
        RifqWidgetPrefs.TasbeehSnapshot snap = RifqWidgetPrefs.getTasbeehSnapshot(context);

        String dhikrToDisplay = (instanceCustomDhikr != null && !instanceCustomDhikr.trim().isEmpty())
            ? instanceCustomDhikr.trim()
            : snap.activeDhikr;

        int progressPct = Math.min(100, Math.round((snap.todayCount * 100f) / Math.max(1, snap.dailyGoal)));

        // Determine primary stat & subtitle based on statsMode ("today_count" | "streak" | "lifetime" | "completed_athkar")
        String primaryNumberText = RifqWidgetPrefs.formatArabicNumber(snap.todayCount);
        String goalOrSubtitleText = isSmall
            ? "/ " + RifqWidgetPrefs.formatArabicNumber(snap.dailyGoal)
            : "الهدف: " + RifqWidgetPrefs.formatArabicNumber(snap.dailyGoal);
        String badgeTitle = "📿 عداد التسبيح";

        if ("streak".equalsIgnoreCase(statsMode)) {
            primaryNumberText = RifqWidgetPrefs.formatArabicNumber(snap.streakDays);
            goalOrSubtitleText = isSmall ? "يوم متتالي" : "يوم متتالي • اليوم: " + RifqWidgetPrefs.formatArabicNumber(snap.todayCount);
            badgeTitle = "🔥 سلسلة المواظبة";
        } else if ("lifetime".equalsIgnoreCase(statsMode)) {
            primaryNumberText = RifqWidgetPrefs.formatArabicNumber(snap.lifetimeTotal);
            goalOrSubtitleText = isSmall ? "إجمالي" : "إجمالي التسبيح • اليوم: " + RifqWidgetPrefs.formatArabicNumber(snap.todayCount);
            badgeTitle = "🏆 حصاد التسبيح";
        } else if ("completed_athkar".equalsIgnoreCase(statsMode)) {
            primaryNumberText = RifqWidgetPrefs.formatArabicNumber(snap.completedAthkarToday);
            goalOrSubtitleText = isSmall ? "أوراد اليوم" : "أذكار مكتملة • التسبيح: " + RifqWidgetPrefs.formatArabicNumber(snap.todayCount);
            badgeTitle = "✨ إنجاز الأوراد";
        }

        // Apply theme
        views.setInt(R.id.widget_root, "setBackgroundResource", palette.bgResId);
        views.setInt(R.id.tv_badge, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.tv_badge, palette.badgeTextColor);
        views.setTextViewText(R.id.tv_badge, isSmall ? "رِفْق" : badgeTitle);
        views.setTextColor(R.id.tv_count, palette.primaryTextColor);
        views.setTextColor(R.id.tv_goal, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_dhikr, palette.primaryTextColor);
        views.setTextColor(R.id.tv_streak, palette.accentTextColor);
        views.setTextColor(R.id.tv_progress_pct, palette.accentTextColor);
        views.setInt(R.id.btn_increment, "setBackgroundResource", palette.btnResId);
        views.setTextColor(R.id.btn_increment, palette.btnTextColor);

        // Bind data
        views.setTextViewText(R.id.tv_count, primaryNumberText);
        views.setTextViewText(R.id.tv_goal, goalOrSubtitleText);
        views.setTextViewText(R.id.tv_dhikr, dhikrToDisplay);
        views.setTextViewText(
            R.id.tv_streak,
            isSmall ? "🔥 " + snap.streakDays : "🔥 سلسلة " + snap.streakDays + " يوم"
        );
        views.setTextViewText(R.id.tv_progress_pct, progressPct + "%");
        views.setProgressBar(R.id.pb_goal, 100, progressPct, false);

        if (!isSmall) {
            views.setTextColor(R.id.tv_brand, palette.secondaryTextColor);
            views.setTextColor(R.id.tv_dhikr_label, palette.secondaryTextColor);
            views.setTextColor(R.id.tv_progress_label, palette.secondaryTextColor);
            views.setInt(R.id.btn_cycle_dhikr, "setBackgroundResource", palette.badgeResId);
            views.setTextColor(R.id.btn_cycle_dhikr, palette.accentTextColor);

            views.setOnClickPendingIntent(
                R.id.btn_cycle_dhikr,
                buildBroadcastPendingIntent(
                    context,
                    providerClass,
                    ACTION_CYCLE_TASBEEH_DHIKR,
                    appWidgetId,
                    11000 + appWidgetId
                )
            );

            if (isLarge) {
                views.setViewVisibility(R.id.container_large_stats, View.VISIBLE);
                views.setTextColor(R.id.tv_lifetime_total, palette.primaryTextColor);
                views.setTextColor(R.id.tv_sessions_today, palette.accentTextColor);
                views.setTextViewText(
                    R.id.tv_lifetime_total,
                    "إجمالي التسبيحات: " + RifqWidgetPrefs.formatArabicNumber(snap.lifetimeTotal)
                );
                views.setTextViewText(
                    R.id.tv_sessions_today,
                    "أذكار مكتملة اليوم: " + RifqWidgetPrefs.formatArabicNumber(snap.completedAthkarToday)
                );
            } else {
                views.setViewVisibility(R.id.container_large_stats, View.GONE);
            }
        }

        // Interactive +1 button (executes directly on Home Screen without opening app)
        views.setOnClickPendingIntent(
            R.id.btn_increment,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_INCREMENT_TASBEEH,
                appWidgetId,
                10000 + appWidgetId
            )
        );

        // Deep link to Tasbeeh screen when tapping main body
        views.setOnClickPendingIntent(
            R.id.container_open_app,
            buildDeepLinkPendingIntent(context, "tasbeeh", dhikrToDisplay, 20000 + appWidgetId)
        );

        return views;
    }

    private static RemoteViews buildPrayerRemoteViews(
        Context context,
        int appWidgetId,
        Class<?> providerClass,
        String size,
        ThemePalette palette,
        String targetPrayer
    ) {
        boolean isSmall = "small".equalsIgnoreCase(size);
        int layoutId = isSmall ? R.layout.widget_rifq_prayer_small : R.layout.widget_rifq_prayer;

        RemoteViews views = new RemoteViews(context.getPackageName(), layoutId);
        RifqWidgetPrayerCalculator.PrayerWidgetSnapshot snap = RifqWidgetPrayerCalculator.calculateSnapshot(
            context,
            targetPrayer
        );
        boolean isCustomPrayerSelected = targetPrayer != null
            && !targetPrayer.trim().isEmpty()
            && !"next".equalsIgnoreCase(targetPrayer.trim());

        views.setInt(R.id.widget_root, "setBackgroundResource", palette.bgResId);
        views.setInt(R.id.tv_badge, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.tv_badge, palette.badgeTextColor);
        views.setTextColor(R.id.tv_city, palette.accentTextColor);
        views.setTextColor(R.id.tv_hijri, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_next_prayer_name, palette.accentTextColor);
        views.setTextColor(R.id.tv_next_prayer_time, palette.primaryTextColor);
        views.setTextColor(R.id.tv_remaining_label, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_remaining_value, palette.accentTextColor);

        views.setTextViewText(R.id.tv_city, "📍 " + snap.cityNameAr);
        views.setTextViewText(R.id.tv_hijri, snap.hijriDateText);
        views.setTextViewText(
            R.id.tv_next_prayer_name,
            isSmall
                ? "صلاة " + snap.nextPrayerNameAr
                : (isCustomPrayerSelected
                    ? "موعد صلاة " + snap.nextPrayerNameAr
                    : "الصلاة القادمة: صلاة " + snap.nextPrayerNameAr)
        );
        views.setTextViewText(R.id.tv_next_prayer_time, snap.nextPrayerTimeFormatted);
        views.setTextViewText(R.id.tv_remaining_value, snap.remainingCountdown);

        if (!isSmall) {
            views.setTextViewText(R.id.val_fajr, snap.fajrShort);
            views.setTextViewText(R.id.val_sunrise, snap.sunriseShort);
            views.setTextViewText(R.id.val_dhuhr, snap.dhuhrShort);
            views.setTextViewText(R.id.val_asr, snap.asrShort);
            views.setTextViewText(R.id.val_maghrib, snap.maghribShort);
            views.setTextViewText(R.id.val_isha, snap.ishaShort);

            stylePrayerBox(views, R.id.box_fajr, R.id.lbl_fajr, R.id.val_fajr, "fajr".equals(snap.nextPrayerKey), palette);
            stylePrayerBox(views, R.id.box_sunrise, R.id.lbl_sunrise, R.id.val_sunrise, "sunrise".equals(snap.nextPrayerKey), palette);
            stylePrayerBox(views, R.id.box_dhuhr, R.id.lbl_dhuhr, R.id.val_dhuhr, "dhuhr".equals(snap.nextPrayerKey), palette);
            stylePrayerBox(views, R.id.box_asr, R.id.lbl_asr, R.id.val_asr, "asr".equals(snap.nextPrayerKey), palette);
            stylePrayerBox(views, R.id.box_maghrib, R.id.lbl_maghrib, R.id.val_maghrib, "maghrib".equals(snap.nextPrayerKey), palette);
            stylePrayerBox(views, R.id.box_isha, R.id.lbl_isha, R.id.val_isha, "isha".equals(snap.nextPrayerKey), palette);
        }

        // Refresh countdown button
        views.setOnClickPendingIntent(
            R.id.btn_refresh_prayer,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_REFRESH_WIDGET,
                appWidgetId,
                12000 + appWidgetId
            )
        );

        // Deep link to Prayers screen
        views.setOnClickPendingIntent(
            R.id.container_open_app,
            buildDeepLinkPendingIntent(context, "prayers", "", 21000 + appWidgetId)
        );

        return views;
    }

    private static void stylePrayerBox(
        RemoteViews views,
        int boxId,
        int lblId,
        int valId,
        boolean isNextPrayer,
        ThemePalette palette
    ) {
        if (isNextPrayer) {
            views.setInt(boxId, "setBackgroundResource", R.drawable.bg_rifq_widget_prayer_active);
            views.setTextColor(lblId, Color.parseColor("#25263A"));
            views.setTextColor(valId, Color.parseColor("#25263A"));
        } else {
            views.setInt(boxId, "setBackgroundResource", R.drawable.bg_rifq_widget_card_inner);
            views.setTextColor(lblId, palette.secondaryTextColor);
            views.setTextColor(valId, palette.primaryTextColor);
        }
    }

    private static RemoteViews buildDhikrRemoteViews(
        Context context,
        int appWidgetId,
        Class<?> providerClass,
        String size,
        ThemePalette palette
    ) {
        boolean isSmall = "small".equalsIgnoreCase(size);
        int layoutId = isSmall ? R.layout.widget_rifq_dhikr_small : R.layout.widget_rifq_dhikr;

        RemoteViews views = new RemoteViews(context.getPackageName(), layoutId);
        RifqWidgetPrefs.BuiltInDhikr dhikr = RifqWidgetPrefs.getCurrentDhikrForWidget(context, appWidgetId);

        boolean showCopiedFeedback = System.currentTimeMillis() <
            RifqWidgetPrefs.getPrefs(context).getLong(RifqWidgetPrefs.KEY_COPY_FEEDBACK_UNTIL_MS, 0L);
        boolean isAudioPlaying = com.rifq.app.audioathkar.RifqAudioAthkarPrefs.isCurrentlyPlaying(context);

        views.setInt(R.id.widget_root, "setBackgroundResource", palette.bgResId);
        views.setTextColor(R.id.tv_badge, palette.badgeTextColor);
        views.setTextColor(R.id.tv_dhikr_text, palette.primaryTextColor);
        views.setTextColor(R.id.tv_dhikr_source, palette.secondaryTextColor);
        views.setInt(R.id.btn_next_dhikr, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.btn_next_dhikr, palette.accentTextColor);
        views.setInt(R.id.btn_listen_dhikr, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.btn_listen_dhikr, palette.accentTextColor);
        views.setInt(R.id.btn_copy_dhikr, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.btn_copy_dhikr, palette.accentTextColor);

        views.setTextViewText(R.id.tv_dhikr_text, "«" + dhikr.text + "»");
        views.setTextViewText(
            R.id.tv_dhikr_source,
            isSmall ? dhikr.source : "المصدر: " + dhikr.source
        );
        views.setTextViewText(R.id.btn_listen_dhikr, isAudioPlaying ? "⏹ إيقاف" : "🔊 استماع");
        views.setTextViewText(R.id.btn_copy_dhikr, showCopiedFeedback ? "✓ تم النسخ" : "📋 نسخ");

        if (!isSmall) {
            views.setInt(R.id.tv_badge, "setBackgroundResource", palette.badgeResId);
            views.setTextColor(R.id.tv_brand, palette.secondaryTextColor);
            views.setTextColor(R.id.tv_dhikr_virtue, palette.accentTextColor);
            views.setTextViewText(
                R.id.tv_dhikr_virtue,
                (dhikr.virtue != null && !dhikr.virtue.isEmpty())
                    ? "✨ فضله: " + dhikr.virtue
                    : "✨ ذكر مبارك من القرآن والسنة"
            );
            views.setInt(R.id.btn_tasbeeh_this, "setBackgroundResource", palette.btnResId);
            views.setTextColor(R.id.btn_tasbeeh_this, palette.btnTextColor);
            views.setOnClickPendingIntent(
                R.id.btn_tasbeeh_this,
                buildDeepLinkPendingIntent(context, "tasbeeh", dhikr.text, 22500 + appWidgetId)
            );
        }

        // Next Dhikr interactive button
        views.setOnClickPendingIntent(
            R.id.btn_next_dhikr,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_NEXT_DHIKR,
                appWidgetId,
                13000 + appWidgetId
            )
        );

        // Listen / Stop Audio Dhikr interactive button
        views.setOnClickPendingIntent(
            R.id.btn_listen_dhikr,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_SPEAK_DHIKR,
                appWidgetId,
                14500 + appWidgetId
            )
        );

        // Copy Dhikr interactive button
        views.setOnClickPendingIntent(
            R.id.btn_copy_dhikr,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_COPY_DHIKR,
                appWidgetId,
                14000 + appWidgetId
            )
        );

        // Deep link to Athkar Explorer screen
        views.setOnClickPendingIntent(
            R.id.container_open_app,
            buildDeepLinkPendingIntent(context, "athkar", dhikr.text, 22000 + appWidgetId)
        );

        return views;
    }

    private static RemoteViews buildMultiRemoteViews(
        Context context,
        int appWidgetId,
        Class<?> providerClass,
        String size,
        ThemePalette palette,
        String targetPrayer,
        String statsMode
    ) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_rifq_multi);

        RifqWidgetPrefs.TasbeehSnapshot tasbeehSnap = RifqWidgetPrefs.getTasbeehSnapshot(context);
        RifqWidgetPrayerCalculator.PrayerWidgetSnapshot prayerSnap = RifqWidgetPrayerCalculator.calculateSnapshot(
            context,
            targetPrayer
        );
        RifqWidgetPrefs.BuiltInDhikr dhikr = RifqWidgetPrefs.getCurrentDhikrForWidget(context, appWidgetId);

        views.setInt(R.id.widget_root, "setBackgroundResource", palette.bgResId);
        views.setInt(R.id.tv_badge, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.tv_badge, palette.badgeTextColor);
        views.setTextColor(R.id.tv_city, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_streak, palette.accentTextColor);

        views.setTextColor(R.id.tv_tasbeeh_label, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_count, palette.primaryTextColor);
        views.setTextColor(R.id.tv_goal, palette.accentTextColor);
        views.setInt(R.id.btn_increment, "setBackgroundResource", palette.btnResId);
        views.setTextColor(R.id.btn_increment, palette.btnTextColor);

        views.setTextColor(R.id.tv_next_prayer_label, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_next_prayer_name, palette.accentTextColor);
        views.setTextColor(R.id.tv_next_prayer_time, palette.primaryTextColor);
        views.setTextColor(R.id.tv_remaining_value, palette.accentTextColor);

        views.setTextColor(R.id.tv_dhikr_label, palette.secondaryTextColor);
        views.setTextColor(R.id.tv_dhikr_text, palette.primaryTextColor);
        views.setInt(R.id.btn_listen_dhikr, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.btn_listen_dhikr, palette.accentTextColor);
        views.setTextViewText(
            R.id.btn_listen_dhikr,
            com.rifq.app.audioathkar.RifqAudioAthkarPrefs.isCurrentlyPlaying(context) ? "⏹ إيقاف" : "🔊 استماع"
        );
        views.setInt(R.id.btn_next_dhikr, "setBackgroundResource", palette.badgeResId);
        views.setTextColor(R.id.btn_next_dhikr, palette.accentTextColor);

        // Bind data
        views.setTextViewText(R.id.tv_city, "📍 " + prayerSnap.cityNameAr + " • " + prayerSnap.hijriDateText);
        views.setTextViewText(R.id.tv_streak, "🔥 " + tasbeehSnap.streakDays + " أيام");

        if ("streak".equalsIgnoreCase(statsMode)) {
            views.setTextViewText(R.id.tv_tasbeeh_label, "سلسلة المواظبة");
            views.setTextViewText(R.id.tv_count, RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.streakDays));
            views.setTextViewText(R.id.tv_goal, "اليوم: " + RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.todayCount));
        } else if ("lifetime".equalsIgnoreCase(statsMode)) {
            views.setTextViewText(R.id.tv_tasbeeh_label, "حصاد التسبيح");
            views.setTextViewText(R.id.tv_count, RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.lifetimeTotal));
            views.setTextViewText(R.id.tv_goal, "اليوم: " + RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.todayCount));
        } else if ("completed_athkar".equalsIgnoreCase(statsMode)) {
            views.setTextViewText(R.id.tv_tasbeeh_label, "إنجاز الأوراد");
            views.setTextViewText(R.id.tv_count, RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.completedAthkarToday));
            views.setTextViewText(R.id.tv_goal, "التسبيح: " + RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.todayCount));
        } else {
            views.setTextViewText(R.id.tv_tasbeeh_label, "تسبيحات اليوم");
            views.setTextViewText(R.id.tv_count, RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.todayCount));
            views.setTextViewText(
                R.id.tv_goal,
                "هدف اليوم: " + RifqWidgetPrefs.formatArabicNumber(tasbeehSnap.dailyGoal)
            );
        }

        views.setTextViewText(R.id.tv_next_prayer_name, "صلاة " + prayerSnap.nextPrayerNameAr);
        views.setTextViewText(R.id.tv_next_prayer_time, prayerSnap.nextPrayerTimeFormatted);
        views.setTextViewText(R.id.tv_remaining_value, prayerSnap.remainingCountdown);

        views.setTextViewText(R.id.tv_dhikr_text, "«" + dhikr.text + "»");

        // Interactive +1 Tasbeeh button
        views.setOnClickPendingIntent(
            R.id.btn_increment,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_INCREMENT_TASBEEH,
                appWidgetId,
                15000 + appWidgetId
            )
        );

        // Interactive Listen / Stop Audio Dhikr button
        views.setOnClickPendingIntent(
            R.id.btn_listen_dhikr,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_SPEAK_DHIKR,
                appWidgetId,
                16500 + appWidgetId
            )
        );

        // Interactive Next Dhikr button
        views.setOnClickPendingIntent(
            R.id.btn_next_dhikr,
            buildBroadcastPendingIntent(
                context,
                providerClass,
                ACTION_NEXT_DHIKR,
                appWidgetId,
                16000 + appWidgetId
            )
        );

        // Deep links for the 3 distinct cards inside MultiWidget
        views.setOnClickPendingIntent(
            R.id.container_open_tasbeeh,
            buildDeepLinkPendingIntent(context, "tasbeeh", tasbeehSnap.activeDhikr, 23000 + appWidgetId)
        );
        views.setOnClickPendingIntent(
            R.id.container_open_prayers,
            buildDeepLinkPendingIntent(context, "prayers", "", 24000 + appWidgetId)
        );
        views.setOnClickPendingIntent(
            R.id.container_open_athkar,
            buildDeepLinkPendingIntent(context, "athkar", dhikr.text, 25000 + appWidgetId)
        );

        return views;
    }

    private static PendingIntent buildBroadcastPendingIntent(
        Context context,
        Class<?> providerClass,
        String action,
        int appWidgetId,
        int requestCode
    ) {
        Intent intent = new Intent(context, providerClass);
        intent.setAction(action);
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }

    private static PendingIntent buildDeepLinkPendingIntent(
        Context context,
        String targetScreen,
        String dhikrText,
        int requestCode
    ) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(RifqNotificationHelper.EXTRA_FROM_NOTIFICATION_TAP, true);
        intent.putExtra(RifqNotificationHelper.EXTRA_NOTIF_SCREEN, targetScreen);
        intent.putExtra("screen", targetScreen);
        if (dhikrText != null && !dhikrText.isEmpty()) {
            intent.putExtra("widgetDhikrText", dhikrText);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }

    /**
     * Updates all placed RIFQ Home Screen Widgets across all 4 AppWidgetProviders.
     */
    public static void updateAllPlacedWidgets(Context context) {
        if (context == null) return;
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            if (manager == null) return;

            Class<?>[] providers = new Class<?>[]{
                RifqTasbeehWidgetProvider.class,
                RifqPrayerWidgetProvider.class,
                RifqDhikrWidgetProvider.class,
                RifqMultiWidgetProvider.class
            };
            String[] defaultTypes = new String[]{"tasbeeh", "prayer", "dhikr", "multi"};

            for (int p = 0; p < providers.length; p++) {
                Class<?> providerCls = providers[p];
                String defType = defaultTypes[p];
                ComponentName cn = new ComponentName(context, providerCls);
                int[] ids = manager.getAppWidgetIds(cn);
                if (ids == null || ids.length == 0) continue;
                for (int appWidgetId : ids) {
                    RemoteViews rv = buildWidgetRemoteViews(context, manager, appWidgetId, providerCls, defType);
                    manager.updateAppWidget(appWidgetId, rv);
                }
            }
        } catch (Exception ignored) {
        }
    }
}
