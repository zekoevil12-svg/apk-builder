package com.rifq.app.widgets;

/**
 * Official Android Home Screen Widget Provider for RIFQ Daily Tasbeeh Counter («عداد التسبيح اليومي»).
 */
public class RifqTasbeehWidgetProvider extends RifqBaseWidgetProvider {
    @Override
    protected String getDefaultWidgetType() {
        return "tasbeeh";
    }
}
