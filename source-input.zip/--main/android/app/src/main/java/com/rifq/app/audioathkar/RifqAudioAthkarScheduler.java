package com.rifq.app.audioathkar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

/**
 * Android `AlarmManager` scheduler for RIFQ Spoken Audio Athkar («جدولة الأذكار الصوتية في الخلفية»).
 *
 * Works when RIFQ is open, in background, closed, or after device reboot (`BOOT_COMPLETED`).
 * Supports:
 * 1. "with_notifications" — synchronized with RIFQ's Athkar & Reminder notifications
 * 2. "interval"           — periodic interval (e.g. every 1h, 2h, 3h, 6h) while skipping Quiet Hours
 * 3. "custom_times"       — exact user-selected daily times (e.g. 08:00, 14:00, 20:00)
 */
public class RifqAudioAthkarScheduler {

    private static final int REQUEST_CODE_AUDIO_ATHKAR_ALARM = 88500;

    public static void rescheduleAll(Context context) {
        if (context == null) return;
        cancelScheduledAlarms(context);

        RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(context);
        if (!cfg.enabled) {
            RifqAudioAthkarPrefs.getPrefs(context).edit()
                .putLong(RifqAudioAthkarPrefs.KEY_NEXT_SCHEDULED_AT_MS, 0L)
                .apply();
            return;
        }

        // If mode is "with_notifications", RifqNotificationReceiver handles speaking when Athkar notifications fire.
        // However, if interval or custom_times is selected, we schedule dedicated AlarmManager wakeups.
        if ("interval".equalsIgnoreCase(cfg.scheduleMode)) {
            long nextTriggerMs = computeNextIntervalTriggerMs(cfg);
            scheduleAlarmAt(context, nextTriggerMs);
        } else if ("custom_times".equalsIgnoreCase(cfg.scheduleMode)) {
            long nextTriggerMs = computeNextCustomTimeTriggerMs(cfg);
            if (nextTriggerMs > 0L) {
                scheduleAlarmAt(context, nextTriggerMs);
            }
        } else {
            // "with_notifications" mode: also compute next approximate time for UI status display
            long nextTriggerMs = computeNextCustomTimeTriggerMs(cfg);
            RifqAudioAthkarPrefs.getPrefs(context).edit()
                .putLong(RifqAudioAthkarPrefs.KEY_NEXT_SCHEDULED_AT_MS, nextTriggerMs)
                .apply();
        }
    }

    public static void cancelScheduledAlarms(Context context) {
        if (context == null) return;
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = buildAlarmPendingIntent(context, PendingIntent.FLAG_NO_CREATE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        } catch (Exception ignored) {
        }
    }

    private static void scheduleAlarmAt(Context context, long triggerAtMs) {
        if (context == null || triggerAtMs <= System.currentTimeMillis()) return;
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            PendingIntent pi = buildAlarmPendingIntent(context, PendingIntent.FLAG_UPDATE_CURRENT);
            if (pi == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            }

            RifqAudioAthkarPrefs.getPrefs(context).edit()
                .putLong(RifqAudioAthkarPrefs.KEY_NEXT_SCHEDULED_AT_MS, triggerAtMs)
                .apply();
        } catch (Exception ignored) {
        }
    }

    private static PendingIntent buildAlarmPendingIntent(Context context, int baseFlags) {
        Intent intent = new Intent(context, RifqAudioAthkarReceiver.class);
        intent.setAction(RifqAudioAthkarReceiver.ACTION_TRIGGER_SCHEDULED_AUDIO_DHIKR);
        int flags = baseFlags;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(context, REQUEST_CODE_AUDIO_ATHKAR_ALARM, intent, flags);
    }

    private static long computeNextIntervalTriggerMs(RifqAudioAthkarPrefs.AudioAthkarConfig cfg) {
        int intervalMins = Math.max(30, cfg.intervalMinutes);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, intervalMins);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return adjustOutOfQuietHours(cfg, cal).getTimeInMillis();
    }

    private static long computeNextCustomTimeTriggerMs(RifqAudioAthkarPrefs.AudioAthkarConfig cfg) {
        if (cfg.customTimes == null || cfg.customTimes.isEmpty()) {
            return computeNextIntervalTriggerMs(cfg);
        }

        long now = System.currentTimeMillis();
        long earliestCandidate = Long.MAX_VALUE;

        // Check today (dayOffset = 0) and tomorrow (dayOffset = 1)
        for (int dayOffset = 0; dayOffset <= 1; dayOffset++) {
            for (String hhmm : cfg.customTimes) {
                int totalMins = RifqAudioAthkarPrefs.parseTimeMinutes(hhmm, -1);
                if (totalMins < 0) continue;

                Calendar candidate = Calendar.getInstance();
                candidate.add(Calendar.DAY_OF_YEAR, dayOffset);
                candidate.set(Calendar.HOUR_OF_DAY, totalMins / 60);
                candidate.set(Calendar.MINUTE, totalMins % 60);
                candidate.set(Calendar.SECOND, 0);
                candidate.set(Calendar.MILLISECOND, 0);

                if (candidate.getTimeInMillis() <= now + 5_000L) {
                    continue;
                }
                if (RifqAudioAthkarPrefs.isWithinQuietHours(cfg, candidate)) {
                    continue;
                }
                if (candidate.getTimeInMillis() < earliestCandidate) {
                    earliestCandidate = candidate.getTimeInMillis();
                }
            }
        }

        if (earliestCandidate == Long.MAX_VALUE) {
            return computeNextIntervalTriggerMs(cfg);
        }
        return earliestCandidate;
    }

    private static Calendar adjustOutOfQuietHours(RifqAudioAthkarPrefs.AudioAthkarConfig cfg, Calendar target) {
        if (!cfg.quietHoursEnabled || !RifqAudioAthkarPrefs.isWithinQuietHours(cfg, target)) {
            return target;
        }
        int endMins = RifqAudioAthkarPrefs.parseTimeMinutes(cfg.quietHoursEnd, 5 * 60);
        int endHour = endMins / 60;
        int endMin = endMins % 60;

        Calendar adjusted = (Calendar) target.clone();
        adjusted.set(Calendar.HOUR_OF_DAY, endHour);
        adjusted.set(Calendar.MINUTE, endMin + 5); // 5 minutes after quiet hours end
        adjusted.set(Calendar.SECOND, 0);
        adjusted.set(Calendar.MILLISECOND, 0);

        if (adjusted.getTimeInMillis() <= target.getTimeInMillis()) {
            adjusted.add(Calendar.DAY_OF_YEAR, 1);
        }
        return adjusted;
    }
}
