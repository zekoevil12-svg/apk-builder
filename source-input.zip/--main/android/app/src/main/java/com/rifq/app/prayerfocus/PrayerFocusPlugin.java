package com.rifq.app.prayerfocus;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.text.TextUtils;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Capacitor Native Android Plugin for RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Exposes authoritative Native Android state & APIs to React/TypeScript:
 * - getPrayerFocusStatus() / getPrayerDeviceLockState() / getFocusState()
 * - isPrayerFocusServiceEnabled()
 * - openAccessibilitySettings()
 * - openDeviceAdminSettings()
 * - setPrayerFocusEnabled(enabled)
 * - setPrayerFocusDuration(minutes)
 * - getCurrentForegroundPackage()
 * - startPrayerFocus()
 * - stopPrayerFocus()
 * - syncPrayerFocusConfig(...)
 * - clearPendingHarvestPrompt()
 */
@CapacitorPlugin(name = "PrayerFocus")
public class PrayerFocusPlugin extends Plugin {

    @PluginMethod
    public void isPrayerFocusServiceEnabled(PluginCall call) {
        Context context = getContext();
        boolean serviceEnabled = isAccessibilityServiceEnabled(context);
        boolean deviceOwnerActive = PrayerDeviceAdminReceiver.isDeviceOwner(context);
        boolean deviceAdminActive = PrayerDeviceAdminReceiver.isDeviceAdminActive(context);
        boolean lockTaskPermitted = PrayerDeviceAdminReceiver.isLockTaskPermitted(context);

        JSObject ret = new JSObject();
        ret.put("enabled", serviceEnabled || deviceOwnerActive);
        ret.put("granted", serviceEnabled || deviceOwnerActive);
        ret.put("accessibilityGranted", serviceEnabled);
        ret.put("connected", PrayerFocusAccessibilityService.isConnected());
        ret.put("deviceOwnerActive", deviceOwnerActive);
        ret.put("deviceAdminActive", deviceAdminActive);
        ret.put("lockTaskPermitted", lockTaskPermitted);
        call.resolve(ret);
    }

    @PluginMethod
    public void checkAccessibilityPermission(PluginCall call) {
        isPrayerFocusServiceEnabled(call);
    }

    @PluginMethod
    public void openAccessibilitySettings(PluginCall call) {
        Context context = getContext();
        PrayerFocusPrefs.getPrefs(context).edit()
            .putBoolean(PrayerFocusPrefs.KEY_ACCESSIBILITY_CONSENT, true)
            .apply();

        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        JSObject ret = new JSObject();
        ret.put("opened", true);
        call.resolve(ret);
    }

    /**
     * Opens the official Android Device Administrator activation dialog for PrayerDeviceAdminReceiver.
     * Note: Full Kiosk Lock Task Mode requires Device Owner provisioning (dpm set-device-owner),
     * which Android enforces at provisioning time.
     */
    @PluginMethod
    public void openDeviceAdminSettings(PluginCall call) {
        Context context = getContext();
        ComponentName adminComponent = PrayerDeviceAdminReceiver.getComponentName(context);

        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "تُستخدم صلاحية مسؤول الجهاز في تطبيق رِفْق لدعم قفل الجهاز وقت الصلاة لمدة 20 دقيقة."
        );
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        JSObject ret = new JSObject();
        ret.put("opened", true);
        call.resolve(ret);
    }

    /**
     * Returns the authoritative native PrayerDeviceLockState (Requirement 26, 30, 31).
     */
    @PluginMethod
    public void getPrayerFocusStatus(PluginCall call) {
        Context context = getContext();
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        boolean serviceEnabled = isAccessibilityServiceEnabled(context);
        boolean featureEnabled = prefs.getBoolean(PrayerFocusPrefs.KEY_ENABLED, false);
        boolean deviceOwnerAvailable = PrayerDeviceAdminReceiver.isDeviceOwnerFeatureAvailable(context);
        boolean deviceOwnerActive = PrayerDeviceAdminReceiver.isDeviceOwner(context);
        boolean deviceAdminActive = PrayerDeviceAdminReceiver.isDeviceAdminActive(context);
        boolean lockTaskPermitted = PrayerDeviceAdminReceiver.isLockTaskPermitted(context);
        boolean lockTaskActive = PrayerDeviceAdminReceiver.isLockTaskActive(context);
        String lockTaskModeState = PrayerDeviceAdminReceiver.getLockTaskModeStateString(context);
        boolean keyguardLocked = PrayerDeviceAdminReceiver.isKeyguardLocked(context);

        String durationMode = prefs.getString(
            PrayerFocusPrefs.KEY_DURATION_MODE,
            String.valueOf(PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES)
        );
        int durationMinutes = prefs.getInt(
            PrayerFocusPrefs.KEY_DURATION_MINUTES,
            PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES
        );
        String prayerTogglesJson = prefs.getString(PrayerFocusPrefs.KEY_PRAYER_TOGGLES, "");

        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
        boolean protectionReady = serviceEnabled || deviceOwnerActive;

        JSObject ret = new JSObject();
        ret.put("enabled", featureEnabled);
        ret.put("serviceEnabled", serviceEnabled);
        ret.put("accessibilityGranted", serviceEnabled);
        ret.put("deviceOwnerAvailable", deviceOwnerAvailable);
        ret.put("deviceOwnerActive", deviceOwnerActive);
        ret.put("deviceAdminActive", deviceAdminActive);
        ret.put("lockTaskPermitted", lockTaskPermitted);
        ret.put("lockTaskActive", lockTaskActive);
        ret.put("lockTaskModeState", lockTaskModeState);
        // Real hardware/OS lock state — never true just because React renders a view
        ret.put("isDeviceLocked", keyguardLocked || lockTaskActive);
        ret.put("isDeviceUnlocked", !keyguardLocked);
        ret.put("durationMode", durationMode);
        ret.put("durationMinutes", durationMinutes);
        ret.put("prayerTogglesJson", prayerTogglesJson);
        ret.put("currentForegroundPackage", getForegroundPkg(context));
        ret.put("isActive", active != null && protectionReady);

        if (active != null) {
            ret.put("activePrayer", active.prayerKey);
            ret.put("prayerKey", active.prayerKey);
            ret.put("prayerNameAr", active.prayerNameAr);
            ret.put("adhanTimestamp", active.startTimeMs);
            ret.put("endTimestamp", active.endTimeMs);
            ret.put("startTimeMs", active.startTimeMs);
            ret.put("endTimeMs", active.endTimeMs);
            ret.put("remainingTime", active.getRemainingMs());
            ret.put("remainingMs", active.getRemainingMs());
            ret.put("remainingMinutes", active.getRemainingMinutes());
            ret.put("lockStartTime", active.getLockStartTimeFormatted());
            ret.put("lockEndTime", active.getLockEndTimeFormatted());
        } else {
            ret.put("activePrayer", "");
            ret.put("adhanTimestamp", 0L);
            ret.put("endTimestamp", 0L);
            ret.put("remainingTime", 0L);
            ret.put("lockStartTime", "");
            ret.put("lockEndTime", "");
        }

        String pendingHarvestPrayerKey = prefs.getString(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_KEY, null);
        String pendingHarvestPrayerName = prefs.getString(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_NAME, null);
        String pendingHarvestDate = prefs.getString(PrayerFocusPrefs.KEY_PENDING_HARVEST_DATE, null);
        if (pendingHarvestPrayerKey != null) {
            ret.put("pendingHarvestPrayerKey", pendingHarvestPrayerKey);
            ret.put("pendingHarvestPrayerName", pendingHarvestPrayerName);
            ret.put("pendingHarvestDate", pendingHarvestDate);
        }

        call.resolve(ret);
    }

    @PluginMethod
    public void getPrayerDeviceLockState(PluginCall call) {
        getPrayerFocusStatus(call);
    }

    @PluginMethod
    public void getFocusState(PluginCall call) {
        getPrayerFocusStatus(call);
    }

    @PluginMethod
    public void setPrayerFocusEnabled(PluginCall call) {
        Context context = getContext();
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        prefs.edit().putBoolean(PrayerFocusPrefs.KEY_ENABLED, enabled).apply();

        if (enabled) {
            if (PrayerDeviceAdminReceiver.isDeviceOwner(context)) {
                PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(context);
            }
            PrayerFocusAlarmReceiver.scheduleUpcomingAlarms(context);
            PrayerDeviceLockService.startAndScheduleAlarms(context);
            PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
            if (active != null && !PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(context, active, "FEATURE_ENABLED");
            }
        } else {
            PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(context);
        }

        JSObject ret = new JSObject();
        ret.put("enabled", enabled);
        ret.put("serviceEnabled", isAccessibilityServiceEnabled(context));
        ret.put("deviceOwnerActive", PrayerDeviceAdminReceiver.isDeviceOwner(context));
        call.resolve(ret);
    }

    @PluginMethod
    public void setPrayerFocusDuration(PluginCall call) {
        Context context = getContext();
        Integer minutes = call.getInt("minutes", null);
        String mode = call.getString("durationMode", null);

        SharedPreferences.Editor editor = PrayerFocusPrefs.getPrefs(context).edit();
        if (minutes != null && minutes > 0) {
            editor.putString(PrayerFocusPrefs.KEY_DURATION_MODE, String.valueOf(minutes));
            editor.putInt(PrayerFocusPrefs.KEY_DURATION_MINUTES, minutes);
        } else if ("until_end_of_prayer".equalsIgnoreCase(mode) || (minutes != null && minutes <= 0)) {
            editor.putString(PrayerFocusPrefs.KEY_DURATION_MODE, "until_end_of_prayer");
        } else if (mode != null) {
            editor.putString(PrayerFocusPrefs.KEY_DURATION_MODE, mode);
            try {
                int parsed = Integer.parseInt(mode);
                if (parsed > 0) editor.putInt(PrayerFocusPrefs.KEY_DURATION_MINUTES, parsed);
            } catch (Exception ignored) {
            }
        }
        editor.apply();

        NativePrayerTimeCalculator.computeTodayAndTomorrowWindows(context);
        PrayerFocusAlarmReceiver.scheduleUpcomingAlarms(context);

        JSObject ret = new JSObject();
        ret.put(
            "durationMode",
            PrayerFocusPrefs.getPrefs(context).getString(
                PrayerFocusPrefs.KEY_DURATION_MODE,
                String.valueOf(PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES)
            )
        );
        ret.put(
            "durationMinutes",
            PrayerFocusPrefs.getPrefs(context).getInt(
                PrayerFocusPrefs.KEY_DURATION_MINUTES,
                PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES
            )
        );
        call.resolve(ret);
    }

    @PluginMethod
    public void getCurrentForegroundPackage(PluginCall call) {
        String pkg = getForegroundPkg(getContext());
        JSObject ret = new JSObject();
        ret.put("packageName", pkg);
        call.resolve(ret);
    }

    private String getForegroundPkg(Context context) {
        String live = PrayerFocusAccessibilityService.getCurrentForegroundPackageName();
        if (live != null && !live.isEmpty()) {
            return live;
        }
        return PrayerFocusPrefs.getPrefs(context).getString(PrayerFocusPrefs.KEY_CURRENT_FOREGROUND_PKG, "");
    }

    @PluginMethod
    public void startPrayerFocus(PluginCall call) {
        Context context = getContext();
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);

        String prayerKey = call.getString("prayerKey", "dhuhr");
        String prayerNameAr = call.getString("prayerNameAr", "الصلاة");
        Integer customMinutes = call.getInt("durationMinutes", null);
        Long explicitEndMs = null;
        if (call.hasOption("endTimeMs")) {
            Double d = call.getDouble("endTimeMs");
            if (d != null) explicitEndMs = d.longValue();
        }

        long now = System.currentTimeMillis();
        long endMs;
        if (explicitEndMs != null && explicitEndMs > now) {
            endMs = explicitEndMs;
        } else if (customMinutes != null && customMinutes > 0) {
            endMs = now + (long) customMinutes * 60000L;
        } else {
            int savedMins = prefs.getInt(
                PrayerFocusPrefs.KEY_DURATION_MINUTES,
                PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES
            );
            endMs = now + (long) savedMins * 60000L;
        }

        prefs.edit()
            .putBoolean(PrayerFocusPrefs.KEY_ENABLED, true)
            .putLong(PrayerFocusPrefs.KEY_DISMISSED_UNTIL_MS, 0L)
            .putString(PrayerFocusPrefs.KEY_DISMISSED_WINDOW_ID, "")
            .putLong(PrayerFocusPrefs.KEY_MANUAL_SESSION_START_MS, now)
            .putLong(PrayerFocusPrefs.KEY_MANUAL_SESSION_END_MS, endMs)
            .putString(PrayerFocusPrefs.KEY_MANUAL_SESSION_PRAYER_KEY, prayerKey)
            .putString(PrayerFocusPrefs.KEY_MANUAL_SESSION_PRAYER_NAME, prayerNameAr)
            .apply();

        PrayerFocusAlarmReceiver.scheduleUpcomingAlarms(context);
        PrayerDeviceLockService.startAndScheduleAlarms(context);

        PrayerFocusPrefs.ActiveFocusWindow activeWindow = new PrayerFocusPrefs.ActiveFocusWindow(
            "manual_" + now,
            prayerKey,
            prayerNameAr,
            now,
            endMs
        );
        PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(context, activeWindow, "MANUAL_START");

        JSObject ret = new JSObject();
        ret.put("started", true);
        ret.put("prayerKey", prayerKey);
        ret.put("prayerNameAr", prayerNameAr);
        ret.put("startTimeMs", now);
        ret.put("endTimeMs", endMs);
        ret.put("adhanTimestamp", now);
        ret.put("endTimestamp", endMs);
        ret.put("serviceEnabled", isAccessibilityServiceEnabled(context));
        ret.put("deviceOwnerActive", PrayerDeviceAdminReceiver.isDeviceOwner(context));
        ret.put("lockTaskActive", PrayerDeviceAdminReceiver.isLockTaskActive(context));
        call.resolve(ret);
    }

    @PluginMethod
    public void stopPrayerFocus(PluginCall call) {
        Context context = getContext();
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(PrayerFocusPrefs.KEY_ACTIVE_LOCK_END_MS, 0L);
        editor.putLong(PrayerFocusPrefs.KEY_MANUAL_SESSION_END_MS, 0L);
        if (active != null) {
            if (active.windowId != null && !active.windowId.isEmpty()) {
                editor.putString(PrayerFocusPrefs.KEY_DISMISSED_WINDOW_ID, active.windowId);
            }
            editor.putLong(PrayerFocusPrefs.KEY_DISMISSED_UNTIL_MS, active.endTimeMs);
        }
        editor.apply();

        PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(context);

        JSObject ret = new JSObject();
        ret.put("stopped", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void syncPrayerFocusConfig(PluginCall call) {
        Context context = getContext();
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        String durationMode = call.getString(
            "durationMode",
            String.valueOf(PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES)
        );
        int durationMinutes = call.getInt(
            "durationMinutes",
            PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES
        );
        String prayerTogglesJson = call.getString("prayerTogglesJson", null);
        String scheduledWindowsJson = call.getString("scheduledWindowsJson", null);

        Double cityLat = call.getDouble("cityLat", null);
        Double cityLng = call.getDouble("cityLng", null);
        String cityNameAr = call.getString("cityNameAr", null);
        String calcMethod = call.getString("calcMethod", null);
        String madhab = call.getString("madhab", null);
        String manualOffsetsJson = call.getString("manualOffsetsJson", null);

        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(PrayerFocusPrefs.KEY_ENABLED, enabled);
        editor.putString(PrayerFocusPrefs.KEY_DURATION_MODE, durationMode);
        editor.putInt(PrayerFocusPrefs.KEY_DURATION_MINUTES, durationMinutes);

        if (prayerTogglesJson != null) {
            editor.putString(PrayerFocusPrefs.KEY_PRAYER_TOGGLES, prayerTogglesJson);
        }
        if (scheduledWindowsJson != null) {
            editor.putString(PrayerFocusPrefs.KEY_SCHEDULED_WINDOWS, scheduledWindowsJson);
        }
        if (cityLat != null && cityLng != null) {
            editor.putLong(PrayerFocusPrefs.KEY_CITY_LAT_BITS, Double.doubleToLongBits(cityLat));
            editor.putLong(PrayerFocusPrefs.KEY_CITY_LNG_BITS, Double.doubleToLongBits(cityLng));
        }
        if (cityNameAr != null) {
            editor.putString(PrayerFocusPrefs.KEY_CITY_NAME_AR, cityNameAr);
        }
        if (calcMethod != null) {
            editor.putString(PrayerFocusPrefs.KEY_CALC_METHOD, calcMethod);
        }
        if (madhab != null) {
            editor.putString(PrayerFocusPrefs.KEY_MADHAB, madhab);
        }
        if (manualOffsetsJson != null) {
            editor.putString(PrayerFocusPrefs.KEY_MANUAL_OFFSETS, manualOffsetsJson);
        }
        editor.apply();

        if (enabled) {
            if (PrayerDeviceAdminReceiver.isDeviceOwner(context)) {
                PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(context);
            }
            PrayerFocusAlarmReceiver.scheduleUpcomingAlarms(context);
            PrayerDeviceLockService.startAndScheduleAlarms(context);
        }

        boolean serviceEnabled = isAccessibilityServiceEnabled(context);
        boolean deviceOwnerActive = PrayerDeviceAdminReceiver.isDeviceOwner(context);
        JSObject ret = new JSObject();
        ret.put("synced", true);
        ret.put("serviceEnabled", serviceEnabled);
        ret.put("accessibilityGranted", serviceEnabled);
        ret.put("deviceOwnerActive", deviceOwnerActive);
        ret.put("deviceAdminActive", PrayerDeviceAdminReceiver.isDeviceAdminActive(context));
        ret.put("lockTaskPermitted", PrayerDeviceAdminReceiver.isLockTaskPermitted(context));
        call.resolve(ret);
    }

    @PluginMethod
    public void clearPendingHarvestPrompt(PluginCall call) {
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(getContext());
        prefs.edit()
            .remove(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_KEY)
            .remove(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_NAME)
            .remove(PrayerFocusPrefs.KEY_PENDING_HARVEST_DATE)
            .apply();
        JSObject ret = new JSObject();
        ret.put("cleared", true);
        call.resolve(ret);
    }

    public static boolean isAccessibilityServiceEnabled(Context context) {
        if (context == null) return false;
        ComponentName expectedComponentName = new ComponentName(context, PrayerFocusAccessibilityService.class);
        String enabledServicesSetting = Settings.Secure.getString(
            context.getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (enabledServicesSetting == null || enabledServicesSetting.isEmpty()) {
            return false;
        }

        TextUtils.SimpleStringSplitter colonSplitter = new TextUtils.SimpleStringSplitter(':');
        colonSplitter.setString(enabledServicesSetting);
        while (colonSplitter.hasNext()) {
            String componentNameString = colonSplitter.next();
            ComponentName enabledService = ComponentName.unflattenFromString(componentNameString);
            if (enabledService != null && enabledService.equals(expectedComponentName)) {
                return true;
            }
        }
        return false;
    }
}
