package com.rifq.app.audioathkar;

import android.content.Context;
import com.rifq.app.widgets.RifqWidgetPrefs;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Authentic RIFQ Audio Athkar Catalog («موسوعة الأذكار الصوتية الحقيقية في رِفْق»).
 *
 * Uses the exact authentic texts from RIFQ's `athkarData.ts` and `momentDhikrData.ts`,
 * plus any dynamically synced or custom Athkar stored in `SharedPreferences`.
 * Provides intelligent, non-repeating Dhikr selection across all categories:
 * - "general" (الأذكار العامة والتسبيح والاستغفار)
 * - "morning" (أذكار الصباح)
 * - "evening" (أذكار المساء)
 * - "salawat" (الصلاة على النبي ﷺ)
 * - "all"     (جميع الأذكار)
 */
public class RifqAudioAthkarCatalog {

    public static class AudioDhikrEntry {
        public final String id;
        public final String title;
        public final String text;
        public final String category; // "general" | "morning" | "evening" | "salawat"
        public final String source;
        public final String virtue;

        public AudioDhikrEntry(
            String id,
            String title,
            String text,
            String category,
            String source,
            String virtue
        ) {
            this.id = id;
            this.title = title;
            this.text = text;
            this.category = category;
            this.source = source;
            this.virtue = virtue;
        }
    }

    private static final AudioDhikrEntry[] BUILT_IN_CATALOG = new AudioDhikrEntry[]{
        // ─── 1. الأذكار العامة (General Athkar) ───
        new AudioDhikrEntry(
            "gen_baqiyat",
            "الباقيات الصالحات",
            "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ",
            "general",
            "صحيح مسلم",
            "أحب الكلام إلى الله ومكفرات الذنوب وغراس الجنة"
        ),
        new AudioDhikrEntry(
            "gen_kalimatan",
            "كلمتان حبيبتان إلى الرحمن",
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
            "general",
            "متفق عليه",
            "كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن"
        ),
        new AudioDhikrEntry(
            "gen_tahlil",
            "ذكر التوحيد العظيم",
            "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "general",
            "متفق عليه",
            "حرز عظيم ورفعة في الدرجات ومغفرة للخطايا"
        ),
        new AudioDhikrEntry(
            "gen_hawqalah",
            "كنز من كنوز الجنة",
            "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ",
            "general",
            "متفق عليه",
            "كنز من كنوز الجنة وباب الفرج والمعونة"
        ),
        new AudioDhikrEntry(
            "gen_istighfar",
            "تاج الاستغفار",
            "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
            "general",
            "سنن أبي داود والترمذي",
            "غفران الذنوب وتفريج الكروب"
        ),
        new AudioDhikrEntry(
            "gen_subhan_adada",
            "التسبيح المضاعف",
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ",
            "general",
            "صحيح مسلم",
            "أجر عظيم مضاعف يفوق ساعات الذكر"
        ),
        new AudioDhikrEntry(
            "gen_yunus",
            "دعوة ذي النون",
            "لَا إِلَهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ",
            "general",
            "سورة الأنبياء - الآية 87",
            "ما دعا بها مكروب إلا فرج الله كربه"
        ),
        new AudioDhikrEntry(
            "gen_hasbiyallah",
            "تفويض الأمر لله",
            "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",
            "general",
            "سورة التوبة - الآية 129",
            "من قالها كفاه الله ما أهمه من أمر الدنيا والآخرة"
        ),
        new AudioDhikrEntry(
            "gen_raditu",
            "الرضا بالله رباً",
            "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا",
            "general",
            "صحيح مسلم",
            "وجبت له الجنة وكان حقاً على الله أن يرضيه"
        ),
        new AudioDhikrEntry(
            "gen_ainni",
            "وصية النبي ﷺ لمعاذ",
            "اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ",
            "general",
            "سنن أبي داود",
            "معونة الله للعبد على الطاعة والذكر"
        ),
        new AudioDhikrEntry(
            "gen_qulub",
            "دعاء ثبات القلب",
            "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ",
            "general",
            "سنن الترمذي",
            "كان أكثر دعاء النبي ﷺ لثبات القلب على الإيمان"
        ),
        new AudioDhikrEntry(
            "gen_afw",
            "سؤال العفو والعافية",
            "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي",
            "general",
            "سنن الترمذي",
            "من أجمع أدعية العفو والمغفرة"
        ),
        new AudioDhikrEntry(
            "gen_rabbana",
            "دعاء خيري الدنيا والآخرة",
            "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            "general",
            "سورة البقرة - الآية 201",
            "أجمع دعاء كان يدعو به النبي ﷺ"
        ),

        // ─── 2. الصلاة على النبي ﷺ (Salawat upon the Prophet ﷺ) ───
        new AudioDhikrEntry(
            "sal_1",
            "الصلاة والسلام على النبي ﷺ",
            "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ ﷺ",
            "salawat",
            "صحيح مسلم",
            "من صلى عليّ صلاة صلى الله عليه بها عشراً"
        ),
        new AudioDhikrEntry(
            "sal_2",
            "الصلاة الإبراهيمية المباركة",
            "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ",
            "salawat",
            "متفق عليه",
            "أكمل صيغ الصلاة على النبي ﷺ المستجابة"
        ),
        new AudioDhikrEntry(
            "sal_3",
            "البركة على النبي وآله ﷺ",
            "اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ",
            "salawat",
            "متفق عليه",
            "كفاية الهم ومغفرة الذنب وشفاعة النبي ﷺ"
        ),
        new AudioDhikrEntry(
            "sal_4",
            "الصلاة على النبي وأزواجه وذريته ﷺ",
            "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَأَزْوَاجِهِ وَذُرِّيَّتِهِ، كَمَا صَلَّيْتَ عَلَى آلِ إِبْرَاهِيمَ، وَبَارِكْ عَلَى مُحَمَّدٍ وَأَزْوَاجِهِ وَذُرِّيَّتِهِ، كَمَا بَارَكْتَ عَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ",
            "salawat",
            "متفق عليه",
            "صيغة نبوية مأثورة في الصحيحين"
        ),

        // ─── 3. أذكار الصباح (Morning Athkar) ───
        new AudioDhikrEntry(
            "morn_1",
            "ذكر الصباح الجامع",
            "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "morning",
            "صحيح مسلم",
            "إعلان التوحيد والحمد في مطلع الصباح"
        ),
        new AudioDhikrEntry(
            "morn_2",
            "باسمك نصبح ونمسي",
            "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",
            "morning",
            "سنن الترمذي",
            "تفويض الحياة والممات لله سبحانه كل صباح"
        ),
        new AudioDhikrEntry(
            "morn_3",
            "أداء شكر اليوم",
            "اللَّهُمَّ مَا أَصْبَحَ بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ",
            "morning",
            "سنن أبي داود",
            "من قالها حين يصبح فقد أدى شكر يومه"
        ),
        new AudioDhikrEntry(
            "morn_4",
            "دعاء العلم والرزق والعمل",
            "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
            "morning",
            "سنن ابن ماجه",
            "توجيه بوصلة اليوم نحو العلم النافع والعمل الصالح"
        ),
        new AudioDhikrEntry(
            "morn_5",
            "سيد الاستغفار",
            "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
            "morning",
            "صحيح البخاري",
            "من قالها موقناً بها فمات من يومه دخل الجنة"
        ),
        new AudioDhikrEntry(
            "morn_6",
            "حرز الحفظ من كل ضرر",
            "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
            "morning",
            "سنن أبي داود والترمذي",
            "لم يضره شيء في يومه ولا فجأة بلاء"
        ),
        new AudioDhikrEntry(
            "morn_7",
            "استغاثة الحي القيوم",
            "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ",
            "morning",
            "سنن النسائي والحاكم",
            "إصلاح الشأن كله بعون الله ورعايته"
        ),

        // ─── 4. أذكار المساء (Evening Athkar) ───
        new AudioDhikrEntry(
            "even_1",
            "ذكر المساء الجامع",
            "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "evening",
            "صحيح مسلم",
            "سكينة المساء وحفظ الله للعبد في ليلته"
        ),
        new AudioDhikrEntry(
            "even_2",
            "ذكر المساء والتوكل",
            "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ",
            "evening",
            "سنن الترمذي",
            "تجديد التوكل والإنابة عند إقبال الليل"
        ),
        new AudioDhikrEntry(
            "even_3",
            "أداء شكر الليلة",
            "اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ",
            "evening",
            "سنن أبي داود",
            "من قالها حين يمسي فقد أدى شكر ليلته"
        ),
        new AudioDhikrEntry(
            "even_4",
            "التعوذ بكلمات الله التامات",
            "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
            "evening",
            "صحيح مسلم",
            "حفظ وأمان من كل سوء في الليل"
        ),
        new AudioDhikrEntry(
            "even_5",
            "دعاء العافية في البدن والسمع والبصر",
            "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ",
            "evening",
            "سنن أبي داود",
            "حفظ الجوارح والنعمة بالعافية الدائمة"
        ),
        new AudioDhikrEntry(
            "even_6",
            "تفريج الهم والحزن",
            "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَأَعُوذُ بِكَ مِنَ الْعَجْزِ وَالْكَسَلِ، وَأَعُوذُ بِكَ مِنَ الْجُبْنِ وَالْبُخْلِ، وَأَعُوذُ بِكَ مِنْ غَلَبَةِ الدَّيْنِ وَقَهْرِ الرِّجَالِ",
            "evening",
            "صحيح البخاري",
            "أذهب الله همه وقضى عنه دينه"
        )
    };

    /**
     * Returns the full combined list of authentic Athkar (Built-in + Synced from React app + Custom Athkar).
     */
    public static List<AudioDhikrEntry> getAllAthkar(Context context) {
        List<AudioDhikrEntry> all = new ArrayList<>();
        Set<String> seenTexts = new HashSet<>();

        for (AudioDhikrEntry entry : BUILT_IN_CATALOG) {
            all.add(entry);
            seenTexts.add(entry.text.trim());
        }

        if (context == null) return all;

        // Merge full synced catalog from React app if present
        String syncedRaw = RifqAudioAthkarPrefs.getPrefs(context).getString(
            RifqAudioAthkarPrefs.KEY_SYNCED_CATALOG_JSON,
            ""
        );
        if (syncedRaw != null && !syncedRaw.isEmpty()) {
            try {
                JSONArray arr = new JSONArray(syncedRaw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.optJSONObject(i);
                    if (obj == null) continue;
                    String text = obj.optString("text", "").trim();
                    if (text.isEmpty() || text.length() > 380 || seenTexts.contains(text)) {
                        continue;
                    }
                    String id = obj.optString("id", "sync_" + i);
                    String title = obj.optString("title", "ذكر مبارك");
                    String cat = normalizeCategory(obj.optString("category", "general"), text);
                    String source = obj.optString("source", "من السنة النبوية");
                    String virtue = obj.optString("virtue", "");
                    all.add(new AudioDhikrEntry(id, title, text, cat, source, virtue));
                    seenTexts.add(text);
                }
            } catch (Exception ignored) {
            }
        }

        // Also merge user custom athkar from widget prefs if present
        String customRaw = RifqWidgetPrefs.getPrefs(context).getString(
            RifqWidgetPrefs.KEY_CUSTOM_ATHKAR_JSON,
            ""
        );
        if (customRaw != null && !customRaw.isEmpty()) {
            try {
                JSONArray arr = new JSONArray(customRaw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.optJSONObject(i);
                    if (obj == null) continue;
                    String text = obj.optString("text", "").trim();
                    if (text.isEmpty() || text.length() > 380 || seenTexts.contains(text)) {
                        continue;
                    }
                    String id = obj.optString("id", "custom_" + i);
                    String cat = normalizeCategory(obj.optString("category", "general"), text);
                    String source = obj.optString("source", "ذكر مخصص");
                    String virtue = obj.optString("virtue", "");
                    all.add(new AudioDhikrEntry(id, "ذكر من وردك", text, cat, source, virtue));
                    seenTexts.add(text);
                }
            } catch (Exception ignored) {
            }
        }

        return all;
    }

    public static String normalizeCategory(String rawCategory, String text) {
        if (text != null && (text.contains("صَلِّ") || text.contains("صلِّ") || text.contains("صَلَّى") || text.contains("نَبِيِّنَا مُحَمَّد"))) {
            return "salawat";
        }
        if (rawCategory == null) return "general";
        String lower = rawCategory.trim().toLowerCase();
        if ("morning".equals(lower)) return "morning";
        if ("evening".equals(lower)) return "evening";
        if ("salawat".equals(lower)) return "salawat";
        return "general";
    }

    /**
     * Requirement 14: Picks a non-repeating authentic Dhikr matching the user's selected categories
     * (or an explicit category override) while avoiding recently spoken items.
     */
    public static AudioDhikrEntry pickNextNonRepeatingDhikr(Context context, String categoryOverride) {
        List<AudioDhikrEntry> all = getAllAthkar(context);
        RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(context);

        Set<String> allowedCategories = new HashSet<>();
        if (categoryOverride != null && !categoryOverride.trim().isEmpty() && !"all".equalsIgnoreCase(categoryOverride.trim())) {
            allowedCategories.add(categoryOverride.trim().toLowerCase());
        } else if (cfg.categories != null && !cfg.categories.contains("all")) {
            for (String c : cfg.categories) {
                if (c != null && !c.trim().isEmpty()) {
                    allowedCategories.add(c.trim().toLowerCase());
                }
            }
        }

        int currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        boolean isMorningWindow = currentHour >= 4 && currentHour < 11;
        boolean isEveningWindow = currentHour >= 15 && currentHour < 21;

        List<AudioDhikrEntry> pool = new ArrayList<>();
        for (AudioDhikrEntry entry : all) {
            if (!allowedCategories.isEmpty()) {
                if (allowedCategories.contains(entry.category)) {
                    pool.add(entry);
                }
            } else {
                // When "all" is enabled, avoid morning-specific phrasing ("أصبحنا") at night and evening phrasing ("أمسينا") in the morning
                if ("morning".equals(entry.category) && !isMorningWindow && isEveningWindow) {
                    continue;
                }
                if ("evening".equals(entry.category) && !isEveningWindow && isMorningWindow) {
                    continue;
                }
                pool.add(entry);
            }
        }

        if (pool.isEmpty()) {
            pool.addAll(all);
        }

        List<String> recentIds = RifqAudioAthkarPrefs.getLastSpokenIds(context);
        List<AudioDhikrEntry> freshCandidates = new ArrayList<>();
        for (AudioDhikrEntry candidate : pool) {
            if (!recentIds.contains(candidate.id)) {
                freshCandidates.add(candidate);
            }
        }

        List<AudioDhikrEntry> finalPool = freshCandidates.isEmpty() ? pool : freshCandidates;
        // Avoid repeating the very last spoken ID even if pool wrapped around
        if (finalPool.size() > 1 && !recentIds.isEmpty()) {
            String veryLastId = recentIds.get(0);
            List<AudioDhikrEntry> withoutVeryLast = new ArrayList<>();
            for (AudioDhikrEntry item : finalPool) {
                if (!veryLastId.equals(item.id)) {
                    withoutVeryLast.add(item);
                }
            }
            if (!withoutVeryLast.isEmpty()) {
                finalPool = withoutVeryLast;
            }
        }

        Random rng = new Random(System.currentTimeMillis() ^ System.nanoTime());
        AudioDhikrEntry chosen = finalPool.get(rng.nextInt(finalPool.size()));
        RifqAudioAthkarPrefs.recordSpokenDhikrId(context, chosen.id);
        return chosen;
    }
}
