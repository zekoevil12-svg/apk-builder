package com.rifq.app.prayerfocus;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

/**
 * Official Android AccessibilityService & Live Unlock Event Monitor for
 * RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Key Capabilities & Guarantees:
 * 1. Dynamically registers PrayerDeviceUnlockReceiver for ACTION_USER_PRESENT & ACTION_SCREEN_ON
 *    so the exact millisecond the user unlocks Keyguard (PIN, Password, Pattern, Fingerprint, Face Unlock),
 *    RIFQ checks if currentTime < endTimestamp and immediately enforces Prayer Device Lock / Lock Task Mode.
 * 2. Event-driven (TYPE_WINDOW_STATE_CHANGED & TYPE_WINDOWS_CHANGED) — zero polling, zero intentional delay.
 * 3. Blocks Home Launcher, Recent Apps, and all non-exempt apps during the 20-minute prayer window.
 * 4. Always allows Emergency Dialer, SOS, and active phone calls (Requirement 20).
 * 5. Never reads screen text, passwords, notifications, or personal data (canRetrieveWindowContent="false").
 */
public class PrayerFocusAccessibilityService extends AccessibilityService {

    private static volatile String lastForegroundPackage = "";
    private static volatile boolean isServiceCurrentlyConnected = false;
    private PrayerDeviceUnlockReceiver dynamicUnlockReceiver;

    public static String getCurrentForegroundPackageName() {
        return lastForegroundPackage != null ? lastForegroundPackage : "";
    }

    public static boolean isConnected() {
        return isServiceCurrentlyConnected;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        isServiceCurrentlyConnected = true;
        PrayerFocusPrefs.getPrefs(this).edit()
            .putBoolean(PrayerFocusPrefs.KEY_SERVICE_RUNNING, true)
            .apply();

        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOWS_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.notificationTimeout = 30L; // Fast event delivery with zero artificial delay
            setServiceInfo(info);
        }

        registerLiveUnlockReceiver();

        // If the service connects while inside an active 20-minute Prayer Device Lock window
        // and the device is unlocked, enforce immediately!
        PrayerFocusPrefs.ActiveFocusWindow activeWindow = PrayerFocusPrefs.getCurrentActiveWindow(this);
        if (activeWindow != null && !PrayerDeviceAdminReceiver.isKeyguardLocked(this)) {
            PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(this, activeWindow, "SERVICE_CONNECTED");
        }
    }

    private void registerLiveUnlockReceiver() {
        unregisterLiveUnlockReceiver();
        try {
            dynamicUnlockReceiver = new PrayerDeviceUnlockReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_USER_PRESENT);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_START);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_END);
            filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(dynamicUnlockReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(dynamicUnlockReceiver, filter);
            }
        } catch (Exception ignored) {
        }
    }

    private void unregisterLiveUnlockReceiver() {
        if (dynamicUnlockReceiver != null) {
            try {
                unregisterReceiver(dynamicUnlockReceiver);
            } catch (Exception ignored) {
            }
            dynamicUnlockReceiver = null;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int eventType = event.getEventType();
        if (
            eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED
        ) {
            return;
        }

        String candidatePkg = null;
        if (event.getPackageName() != null) {
            candidatePkg = event.getPackageName().toString().trim();
        }

        String candidateClassName = null;
        if (event.getClassName() != null) {
            candidateClassName = event.getClassName().toString().trim();
        }

        if (candidatePkg != null && !candidatePkg.isEmpty() && !isKeyboardOverlayPackage(candidatePkg)) {
            lastForegroundPackage = candidatePkg;
            PrayerFocusPrefs.getPrefs(this).edit()
                .putString(PrayerFocusPrefs.KEY_CURRENT_FOREGROUND_PKG, candidatePkg)
                .apply();
        }

        // Check authoritative timestamp state: if (currentTime < endTimestamp) -> ACTIVE
        PrayerFocusPrefs.ActiveFocusWindow activeWindow = PrayerFocusPrefs.getCurrentActiveWindow(this);
        if (activeWindow == null) {
            return;
        }

        // Never interfere while Android Keyguard (PIN/Password/Biometric lockscreen) is still locked
        if (PrayerDeviceAdminReceiver.isKeyguardLocked(this)) {
            return;
        }

        // 1. Check primary foreground window: block Home Launcher, Recents, and all non-exempt apps
        String blockedDetectedPkg = null;
        if (
            candidatePkg != null &&
            !candidatePkg.isEmpty() &&
            !PrayerFocusPrefs.isExemptFromPrayerLock(this, candidatePkg, candidateClassName)
        ) {
            blockedDetectedPkg = candidatePkg;
        }

        // 2. Also inspect interactive windows (handles Split-Screen, Floating Windows, Recents)
        if (blockedDetectedPkg == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                List<AccessibilityWindowInfo> windows = getWindows();
                if (windows != null) {
                    for (AccessibilityWindowInfo win : windows) {
                        if (win == null || win.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) {
                            continue;
                        }
                        if (win.getRoot() != null && win.getRoot().getPackageName() != null) {
                            String winPkg = win.getRoot().getPackageName().toString().trim();
                            if (
                                !winPkg.isEmpty() &&
                                !PrayerFocusPrefs.isExemptFromPrayerLock(this, winPkg, null)
                            ) {
                                blockedDetectedPkg = winPkg;
                                break;
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }

        if (blockedDetectedPkg == null) {
            return;
        }

        // Immediate enforcement with zero artificial delay
        PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(
            this,
            activeWindow,
            "ACCESSIBILITY_INTERCEPT:" + blockedDetectedPkg
        );
    }

    private boolean isKeyboardOverlayPackage(String pkg) {
        String lower = pkg.toLowerCase(java.util.Locale.US);
        return (
            lower.contains("inputmethod") ||
            lower.contains("keyboard") ||
            lower.contains("gboard") ||
            lower.contains("honeyboard")
        );
    }

    @Override
    public boolean onUnbind(Intent intent) {
        isServiceCurrentlyConnected = false;
        unregisterLiveUnlockReceiver();
        PrayerFocusPrefs.getPrefs(this).edit()
            .putBoolean(PrayerFocusPrefs.KEY_SERVICE_RUNNING, false)
            .apply();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        isServiceCurrentlyConnected = false;
        unregisterLiveUnlockReceiver();
        PrayerFocusPrefs.getPrefs(this).edit()
            .putBoolean(PrayerFocusPrefs.KEY_SERVICE_RUNNING, false)
            .apply();
        super.onDestroy();
    }

    @Override
    public void onInterrupt() {
        // Required override
    }
}
