package com.rifq.app.prayerfocus;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import com.rifq.app.MainActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

/**
 * Official Android Native Background Service (`PrayerDeviceLockService`) for RIFQ.
 *
 * Responsibilities:
 * 1. Works 100% independently of JavaScript/WebView, even when the RIFQ app is completely closed.
 * 2. Uses Android `AlarmManager` (`setExactAndAllowWhileIdle`) to schedule:
 *    - Prayer Lock Start (`ACTION_FOCUS_START`) at exact `adhanTimestamp`
 *    - Prayer Lock End (`ACTION_FOCUS_END`) at exact `endTimestamp = adhanTimestamp + 20 minutes`
 *    - Automatic daily midnight recalculation (`ACTION_RESCHEDULE_PRAYER_LOCKS`) using
 *      `NativePrayerTimeCalculator` so future days' 20-minute prayer locks are scheduled offline.
 * 3. Dynamically listens for `Intent.ACTION_USER_PRESENT` & `Intent.ACTION_SCREEN_ON` in the background
 *    and immediately re-enforces `LockTaskMode` / `PrayerLockActivity` with zero delay whenever
 *    the user unlocks the device while `currentTime < endTimestamp`.
 */
public class PrayerDeviceLockService extends Service {

    public static final String ACTION_START_AND_SCHEDULE = "com.rifq.app.ACTION_START_AND_SCHEDULE_PRAYER_LOCK";
    public static final String ACTION_ENFORCE_ACTIVE_WINDOW = "com.rifq.app.ACTION_ENFORCE_ACTIVE_PRAYER_WINDOW";
    public static final String ACTION_RELEASE_EXPIRED_WINDOW = "com.rifq.app.ACTION_RELEASE_EXPIRED_PRAYER_WINDOW";
    public static final String ACTION_RESCHEDULE_PRAYER_LOCKS = "com.rifq.app.ACTION_RESCHEDULE_PRAYER_LOCKS";

    private static final String LOCK_SERVICE_CHANNEL_ID = "rifq_prayer_device_lock_service";
    private static final int FOREGROUND_LOCK_NOTIFICATION_ID = 2205;
    private static final int REQUEST_CODE_DAILY_RESCHEDULE = 4950;

    private BroadcastReceiver backgroundUnlockReceiver;
    private boolean isRunningInForeground = false;

    /**
     * Static helper to start `PrayerDeviceLockService` and schedule all 20-minute Prayer Lock alarms
     * via `AlarmManager` completely natively.
     */
    public static void startAndScheduleAlarms(Context context) {
        if (context == null) return;
        try {
            // Always schedule exact AlarmManager start/end windows immediately
            scheduleTwentyMinutePrayerAlarmsNatively(context);

            if (!PrayerFocusPrefs.isEnabled(context)) {
                return;
            }

            Intent serviceIntent = new Intent(context, PrayerDeviceLockService.class);
            serviceIntent.setAction(ACTION_START_AND_SCHEDULE);

            PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
            if (active != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
        } catch (Exception ignored) {
            // Even if Android 12+ background service start restrictions apply while in background,
            // AlarmManager exact alarms are already scheduled above!
        }
    }

    /**
     * Computes today's and tomorrow's 20-minute prayer lock windows natively (independent of JS)
     * and schedules exact `AlarmManager` Start (`adhanTimestamp`) and End (`adhanTimestamp + 20 minutes`)
     * alarms plus a daily recalculation alarm.
     */
    public static void scheduleTwentyMinutePrayerAlarmsNatively(Context context) {
        if (context == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        if (!prefs.getBoolean(PrayerFocusPrefs.KEY_ENABLED, false)) {
            return;
        }

        long now = System.currentTimeMillis();

        // 1. Recompute today's and tomorrow's 20-minute windows natively using saved astronomical coordinates
        JSONArray computedWindows = NativePrayerTimeCalculator.computeTodayAndTomorrowWindows(context);

        // 2. Schedule exact Start (adhanTimestamp) and End (adhanTimestamp + 20 minutes) alarms
        try {
            for (int i = 0; i < computedWindows.length(); i++) {
                JSONObject obj = computedWindows.optJSONObject(i);
                if (obj == null || !obj.optBoolean("enabled", true)) continue;

                String winId = obj.optString("id", "");
                String pKey = obj.optString("prayerKey", "dhuhr");
                String pName = obj.optString("prayerNameAr", "الصلاة");
                long adhanTimestamp = obj.optLong("startTimeMs", 0L);
                // Enforce strict 20-minute rule: endTimestamp = adhanTimestamp + 20 minutes
                int durationMins = PrayerFocusPrefs.getLockDurationMinutes(context);
                long endTimestamp = obj.optLong("endTimeMs", adhanTimestamp + (long) durationMins * 60000L);

                if (adhanTimestamp > now) {
                    PrayerFocusAlarmReceiver.scheduleExact(
                        context,
                        alarmManager,
                        PrayerFocusAlarmReceiver.ACTION_FOCUS_START,
                        winId,
                        pKey,
                        pName,
                        adhanTimestamp,
                        endTimestamp,
                        4000 + i * 2
                    );
                }
                if (endTimestamp > now) {
                    PrayerFocusAlarmReceiver.scheduleExact(
                        context,
                        alarmManager,
                        PrayerFocusAlarmReceiver.ACTION_FOCUS_END,
                        winId,
                        pKey,
                        pName,
                        adhanTimestamp,
                        endTimestamp,
                        4001 + i * 2
                    );
                }
            }
        } catch (Exception ignored) {
        }

        // 3. Ensure any currently active 20-minute window has its exact End alarm scheduled
        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
        if (active != null && active.endTimeMs > now) {
            PrayerFocusAlarmReceiver.scheduleExact(
                context,
                alarmManager,
                PrayerFocusAlarmReceiver.ACTION_FOCUS_END,
                active.windowId,
                active.prayerKey,
                active.prayerNameAr,
                active.startTimeMs,
                active.endTimeMs,
                4999
            );
        }

        // 4. Schedule daily midnight recalculation alarm so alarms continue indefinitely even if RIFQ is never opened
        scheduleDailyMidnightRescheduleAlarm(context, alarmManager);
    }

    private static void scheduleDailyMidnightRescheduleAlarm(Context context, AlarmManager alarmManager) {
        try {
            Calendar nextMidnight = Calendar.getInstance();
            nextMidnight.add(Calendar.DAY_OF_YEAR, 1);
            nextMidnight.set(Calendar.HOUR_OF_DAY, 0);
            nextMidnight.set(Calendar.MINUTE, 5);
            nextMidnight.set(Calendar.SECOND, 0);
            nextMidnight.set(Calendar.MILLISECOND, 0);

            Intent intent = new Intent(context, PrayerFocusBootReceiver.class);
            intent.setAction(ACTION_RESCHEDULE_PRAYER_LOCKS);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getBroadcast(context, REQUEST_CODE_DAILY_RESCHEDULE, intent, flags);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextMidnight.getTimeInMillis(), pi);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, nextMidnight.getTimeInMillis(), pi);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ensureServiceNotificationChannel();
        registerBackgroundUnlockReceiver();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!PrayerFocusPrefs.isEnabled(this)) {
            stopForegroundIfNeeded();
            stopSelf();
            return START_NOT_STICKY;
        }

        // Schedule / refresh all 20-minute Prayer Lock Start & End alarms via AlarmManager
        scheduleTwentyMinutePrayerAlarmsNatively(this);

        String action = intent != null ? intent.getAction() : null;
        if (ACTION_RELEASE_EXPIRED_WINDOW.equals(action)) {
            PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(this);
            stopForegroundIfNeeded();
            return START_STICKY;
        }

        PrayerFocusPrefs.ActiveFocusWindow activeWindow = PrayerFocusPrefs.getCurrentActiveWindow(this);
        long now = System.currentTimeMillis();

        if (activeWindow != null && now >= activeWindow.startTimeMs && now < activeWindow.endTimeMs) {
            // Promote to foreground during the active 20-minute window so Android OS keeps
            // the ACTION_USER_PRESENT unlock listener alive until exact endTimestamp
            promoteToForegroundForActivePrayer(activeWindow);

            // If the device is currently unlocked, enforce LockTaskMode immediately!
            if (!PrayerDeviceAdminReceiver.isKeyguardLocked(this)) {
                PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(
                    this,
                    activeWindow,
                    "NATIVE_SERVICE_ACTIVE_WINDOW"
                );
            }
        } else {
            stopForegroundIfNeeded();
        }

        return START_STICKY;
    }

    private void registerBackgroundUnlockReceiver() {
        unregisterBackgroundUnlockReceiver();
        try {
            backgroundUnlockReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (context == null || intent == null) return;
                    String act = intent.getAction();
                    if (act == null) return;

                    if (Intent.ACTION_USER_PRESENT.equals(act)) {
                        // Immediate zero-delay check on Keyguard credential unlock (PIN/Biometric/Pattern)
                        long currentTime = System.currentTimeMillis();
                        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
                        if (active != null && currentTime >= active.startTimeMs && currentTime < active.endTimeMs) {
                            PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(
                                context,
                                active,
                                "SERVICE_ACTION_USER_PRESENT"
                            );
                        } else {
                            stopForegroundIfNeeded();
                        }
                    } else if (Intent.ACTION_SCREEN_ON.equals(act)) {
                        if (!PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                            long currentTime = System.currentTimeMillis();
                            PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
                            if (active != null && currentTime >= active.startTimeMs && currentTime < active.endTimeMs) {
                                PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(
                                    context,
                                    active,
                                    "SERVICE_ACTION_SCREEN_ON"
                                );
                            }
                        }
                    } else if (PrayerFocusAlarmReceiver.ACTION_FOCUS_END.equals(act)) {
                        PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(context);
                        stopForegroundIfNeeded();
                        scheduleTwentyMinutePrayerAlarmsNatively(context);
                    } else if (
                        Intent.ACTION_TIME_CHANGED.equals(act) ||
                        Intent.ACTION_TIMEZONE_CHANGED.equals(act)
                    ) {
                        scheduleTwentyMinutePrayerAlarmsNatively(context);
                    }
                }
            };

            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_USER_PRESENT);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_TIME_CHANGED);
            filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_START);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_END);
            filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(backgroundUnlockReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(backgroundUnlockReceiver, filter);
            }
        } catch (Exception ignored) {
        }
    }

    private void unregisterBackgroundUnlockReceiver() {
        if (backgroundUnlockReceiver != null) {
            try {
                unregisterReceiver(backgroundUnlockReceiver);
            } catch (Exception ignored) {
            }
            backgroundUnlockReceiver = null;
        }
    }

    private void promoteToForegroundForActivePrayer(PrayerFocusPrefs.ActiveFocusWindow activeWindow) {
        try {
            ensureServiceNotificationChannel();
            Intent openIntent = new Intent(this, PrayerLockActivity.class);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                piFlags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getActivity(this, 2206, openIntent, piFlags);

            String title = "وضع قفل الجهاز لصلاة " + activeWindow.prayerNameAr + " نشط 🔒";
            String body = "الأذان: " + activeWindow.getLockStartTimeFormatted() +
                " • ينتهي القفل تلقائياً عند: " + activeWindow.getLockEndTimeFormatted();

            Notification notification = new NotificationCompat.Builder(this, LOCK_SERVICE_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();

            startForeground(FOREGROUND_LOCK_NOTIFICATION_ID, notification);
            isRunningInForeground = true;
        } catch (Exception ignored) {
        }
    }

    private void stopForegroundIfNeeded() {
        if (isRunningInForeground) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE);
                } else {
                    stopForeground(true);
                }
            } catch (Exception ignored) {
            }
            isRunningInForeground = false;
        }
    }

    private void ensureServiceNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(LOCK_SERVICE_CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                    LOCK_SERVICE_CHANNEL_ID,
                    "رِفْق - خدمة قفل الجهاز وقت الصلاة",
                    NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("تعمل أثناء فترة الـ20 دقيقة لقفل الجهاز وقت الصلاة");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public void onDestroy() {
        unregisterBackgroundUnlockReceiver();
        stopForegroundIfNeeded();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
