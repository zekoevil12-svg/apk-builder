package com.rifq.app.prayerfocus;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.telecom.TelecomManager;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Official Android DeviceAdminReceiver & DevicePolicyManager helper for
 * RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Uses official Android Enterprise / Dedicated Device / Kiosk APIs:
 * - DevicePolicyManager.isDeviceOwnerApp(packageName)
 * - DevicePolicyManager.isAdminActive(adminComponent)
 * - DevicePolicyManager.setLockTaskPackages(adminComponent, packages)
 * - DevicePolicyManager.setLockTaskFeatures(adminComponent, flags)
 * - DevicePolicyManager.isLockTaskPermitted(packageName)
 * - ActivityManager.getLockTaskModeState()
 * - KeyguardManager.isKeyguardLocked()
 *
 * Never uses root, reflection, fake overlays, or credential manipulation.
 */
public class PrayerDeviceAdminReceiver extends DeviceAdminReceiver {

    public static ComponentName getComponentName(Context context) {
        if (context != null) {
            try {
                DevicePolicyManager dpm = getDpm(context);
                ComponentName rootAdmin = new ComponentName(
                    context.getApplicationContext(),
                    com.rifq.app.RifqDeviceAdminReceiver.class
                );
                if (dpm != null && dpm.isAdminActive(rootAdmin)) {
                    return rootAdmin;
                }
            } catch (Exception ignored) {
            }
        }
        return new ComponentName(context.getApplicationContext(), PrayerDeviceAdminReceiver.class);
    }

    public static DevicePolicyManager getDpm(Context context) {
        if (context == null) return null;
        return (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
    }

    /**
     * Returns true if DevicePolicyManager is present on this Android device.
     */
    public static boolean isDeviceOwnerFeatureAvailable(Context context) {
        if (context == null) return false;
        PackageManager pm = context.getPackageManager();
        boolean hasDeviceAdminFeature = pm != null && pm.hasSystemFeature(PackageManager.FEATURE_DEVICE_ADMIN);
        return hasDeviceAdminFeature && getDpm(context) != null;
    }

    /**
     * Authoritative check: returns true ONLY if RIFQ is genuinely provisioned as the
     * Android Device Owner (Dedicated Device / Kiosk Mode) in DevicePolicyManager.
     */
    public static boolean isDeviceOwner(Context context) {
        if (context == null) return false;
        try {
            DevicePolicyManager dpm = getDpm(context);
            return dpm != null && dpm.isDeviceOwnerApp(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Authoritative check: returns true if RIFQ's DeviceAdminReceiver is an active Device Administrator.
     */
    public static boolean isDeviceAdminActive(Context context) {
        if (context == null) return false;
        try {
            DevicePolicyManager dpm = getDpm(context);
            return dpm != null && dpm.isAdminActive(getComponentName(context));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Authoritative check: returns true if Android DevicePolicyManager permits RIFQ to enter
     * full Kiosk Lock Task Mode without user confirmation dialog.
     */
    public static boolean isLockTaskPermitted(Context context) {
        if (context == null) return false;
        try {
            DevicePolicyManager dpm = getDpm(context);
            if (dpm == null) return false;
            if (dpm.isDeviceOwnerApp(context.getPackageName()) && !dpm.isLockTaskPermitted(context.getPackageName())) {
                configureKioskLockTaskPolicy(context);
            }
            return dpm.isLockTaskPermitted(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Configures Lock Task packages and features when RIFQ is the Device Owner:
     * - Whitelists RIFQ itself + Emergency/Dialer/SOS packages so Emergency calls ALWAYS work
     *   inside Lock Task Mode (Requirement 20).
     * - Disables Home button, Overview/Recent Apps, Notifications shade, and Global Actions
     *   during Lock Task Mode on Android 9+ (API 28+).
     */
    public static boolean configureKioskLockTaskPolicy(Context context) {
        if (context == null) return false;
        try {
            DevicePolicyManager dpm = getDpm(context);
            if (dpm == null || !dpm.isDeviceOwnerApp(context.getPackageName())) {
                return false;
            }

            ComponentName admin = getComponentName(context);
            String[] allowedPackages = buildLockTaskAllowedPackages(context);
            dpm.setLockTaskPackages(admin, allowedPackages);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // Allow only system info in status bar; block Home, Overview/Recents, Notifications, Keyguard bypass
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_SYSTEM_INFO);
            }
            return dpm.isLockTaskPermitted(context.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Builds the list of packages permitted inside Lock Task Mode:
     * RIFQ + Emergency Dialer / SOS / Telecom packages so the user is NEVER blocked from calling Emergency/SOS.
     */
    private static String[] buildLockTaskAllowedPackages(Context context) {
        Set<String> pkgs = new HashSet<>();
        pkgs.add(context.getPackageName());
        pkgs.add("com.android.phone");
        pkgs.add("com.android.server.telecom");
        pkgs.add("com.android.incallui");
        pkgs.add("com.google.android.dialer");
        pkgs.add("com.android.dialer");
        pkgs.add("com.samsung.android.dialer");
        pkgs.add("com.samsung.android.incallui");
        pkgs.add("com.android.emergency");
        pkgs.add("com.sec.android.app.emergencymode");
        pkgs.add("com.google.android.apps.safetyhub");

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null && tm.getDefaultDialerPackage() != null && !tm.getDefaultDialerPackage().isEmpty()) {
                    pkgs.add(tm.getDefaultDialerPackage());
                }
            }
            PackageManager pm = context.getPackageManager();
            if (pm != null) {
                addResolvedIntentPackages(pm, new Intent("android.intent.action.EMERGENCY_DIAL"), pkgs);
                addResolvedIntentPackages(pm, new Intent("android.telephony.action.EMERGENCY_ASSISTANCE"), pkgs);
                addResolvedIntentPackages(pm, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")), pkgs);
            }
        } catch (Exception ignored) {
        }

        List<String> list = new ArrayList<>(pkgs);
        return list.toArray(new String[0]);
    }

    private static void addResolvedIntentPackages(PackageManager pm, Intent intent, Set<String> out) {
        try {
            List<ResolveInfo> infos = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            if (infos != null) {
                for (ResolveInfo info : infos) {
                    if (info != null && info.activityInfo != null && info.activityInfo.packageName != null) {
                        out.add(info.activityInfo.packageName);
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Queries Android's ActivityManager for the REAL system Lock Task Mode state.
     * Never fakes or simulates this value.
     */
    public static boolean isLockTaskActive(Context context) {
        if (context == null) return false;
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return am.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE;
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return am.isInLockTaskMode();
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    public static String getLockTaskModeStateString(Context context) {
        if (context == null) return "NONE";
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return "NONE";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                int state = am.getLockTaskModeState();
                if (state == ActivityManager.LOCK_TASK_MODE_LOCKED) return "LOCKED";
                if (state == ActivityManager.LOCK_TASK_MODE_PINNED) return "PINNED";
                return "NONE";
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return am.isInLockTaskMode() ? "LOCKED" : "NONE";
            }
        } catch (Exception ignored) {
        }
        return "NONE";
    }

    /**
     * Queries Android's KeyguardManager to determine whether the hardware/system lockscreen
     * (PIN / Password / Pattern / Biometric Keyguard) is currently locked.
     */
    public static boolean isKeyguardLocked(Context context) {
        if (context == null) return false;
        try {
            KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
            if (km == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                return km.isKeyguardLocked() || km.isDeviceLocked();
            }
            return km.isKeyguardLocked();
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        if (isDeviceOwner(context)) {
            configureKioskLockTaskPolicy(context);
        }
    }

    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        super.onProfileProvisioningComplete(context, intent);
        if (isDeviceOwner(context)) {
            configureKioskLockTaskPolicy(context);
        }
    }

    @Override
    public void onLockTaskModeEntering(Context context, Intent intent, String pkg) {
        super.onLockTaskModeEntering(context, intent, pkg);
        PrayerFocusPrefs.getPrefs(context).edit()
            .putBoolean(PrayerFocusPrefs.KEY_LOCK_TASK_ACTIVE, true)
            .apply();
    }

    @Override
    public void onLockTaskModeExiting(Context context, Intent intent) {
        super.onLockTaskModeExiting(context, intent);
        PrayerFocusPrefs.getPrefs(context).edit()
            .putBoolean(PrayerFocusPrefs.KEY_LOCK_TASK_ACTIVE, false)
            .apply();
    }
}
