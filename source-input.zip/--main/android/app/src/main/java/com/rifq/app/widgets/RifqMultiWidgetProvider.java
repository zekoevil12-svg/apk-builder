package com.rifq.app.widgets;

/**
 * Official Android Home Screen Widget Provider for RIFQ Comprehensive Multi-Widget («الويدجت الشامل»).
 */
public class RifqMultiWidgetProvider extends RifqBaseWidgetProvider {
    @Override
    protected String getDefaultWidgetType() {
        return "multi";
    }
}
