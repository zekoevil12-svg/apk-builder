package com.rifq.app.widgets;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import com.rifq.app.prayerfocus.PrayerFocusPrefs;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Offline-First Native Astronomical Prayer Time & Hijri Date Calculator for RIFQ Home Screen Widgets.
 *
 * Uses the user's real saved RIFQ coordinates, city name, calculation method, madhab, manual offsets,
 * and Hijri adjustment. Works 100% offline even when RIFQ has been closed for days or after device reboot.
 */
public class RifqWidgetPrayerCalculator {

    public static class PrayerWidgetSnapshot {
        public final String cityNameAr;
        public final String hijriDateText;
        public final String nextPrayerKey;      // "fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha"
        public final String nextPrayerNameAr;   // "الفجر" | "الشروق" | "الظهر" | "العصر" | "المغرب" | "العشاء"
        public final String nextPrayerTimeFormatted;
        public final long nextPrayerTimeMs;
        public final String remainingCountdown;
        public final String fajrShort;
        public final String sunriseShort;
        public final String dhuhrShort;
        public final String asrShort;
        public final String maghribShort;
        public final String ishaShort;

        public PrayerWidgetSnapshot(
            String cityNameAr,
            String hijriDateText,
            String nextPrayerKey,
            String nextPrayerNameAr,
            String nextPrayerTimeFormatted,
            long nextPrayerTimeMs,
            String remainingCountdown,
            String fajrShort,
            String sunriseShort,
            String dhuhrShort,
            String asrShort,
            String maghribShort,
            String ishaShort
        ) {
            this.cityNameAr = cityNameAr;
            this.hijriDateText = hijriDateText;
            this.nextPrayerKey = nextPrayerKey;
            this.nextPrayerNameAr = nextPrayerNameAr;
            this.nextPrayerTimeFormatted = nextPrayerTimeFormatted;
            this.nextPrayerTimeMs = nextPrayerTimeMs;
            this.remainingCountdown = remainingCountdown;
            this.fajrShort = fajrShort;
            this.sunriseShort = sunriseShort;
            this.dhuhrShort = dhuhrShort;
            this.asrShort = asrShort;
            this.maghribShort = maghribShort;
            this.ishaShort = ishaShort;
        }
    }

    private static double deg2rad(double d) {
        return (d * Math.PI) / 180.0;
    }

    private static double rad2deg(double r) {
        return (r * 180.0) / Math.PI;
    }

    private static double normalizeAngle(double a) {
        double b = a - 360.0 * Math.floor(a / 360.0);
        return b < 0 ? b + 360.0 : b;
    }

    private static double normalizeHours(double h) {
        double b = h - 24.0 * Math.floor(h / 24.0);
        return b < 0 ? b + 24.0 : b;
    }

    private static double getJulianDate(int year, int month, int day) {
        int y = year;
        int m = month;
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        int a = (int) Math.floor(y / 100.0);
        int b = 2 - a + (int) Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524.5;
    }

    private static double[] getSunPosition(double jd) {
        double d = jd - 2451545.0;
        double g = normalizeAngle(357.529 + 0.98560028 * d);
        double q = normalizeAngle(280.459 + 0.98564736 * d);
        double l = normalizeAngle(q + 1.915 * Math.sin(deg2rad(g)) + 0.020 * Math.sin(deg2rad(2 * g)));
        double e = 23.439 - 0.00000036 * d;
        double ra = rad2deg(Math.atan2(Math.cos(deg2rad(e)) * Math.sin(deg2rad(l)), Math.cos(deg2rad(l)))) / 15.0;
        double eqt = q / 15.0 - normalizeHours(ra);
        double decl = rad2deg(Math.asin(Math.sin(deg2rad(e)) * Math.sin(deg2rad(l))));
        return new double[]{decl, eqt};
    }

    private static double computeHourAngle(double lat, double decl, double angle) {
        double num = -Math.sin(deg2rad(angle)) - Math.sin(deg2rad(lat)) * Math.sin(deg2rad(decl));
        double den = Math.cos(deg2rad(lat)) * Math.cos(deg2rad(decl));
        double val = Math.max(-1.0, Math.min(1.0, num / den));
        return rad2deg(Math.acos(val)) / 15.0;
    }

    private static double computeAsrHourAngle(double lat, double decl, int shadowFactor) {
        double angle = -rad2deg(Math.atan(1.0 / (shadowFactor + Math.tan(deg2rad(Math.abs(lat - decl))))));
        return computeHourAngle(lat, decl, angle);
    }

    private static double[] getMethodParams(String method) {
        if ("UmmAlQura".equalsIgnoreCase(method)) return new double[]{18.5, 0.0, 90.0};
        if ("MuslimWorldLeague".equalsIgnoreCase(method)) return new double[]{18.0, 17.0, 0.0};
        if ("Karachi".equalsIgnoreCase(method)) return new double[]{18.0, 18.0, 0.0};
        if ("NorthAmerica".equalsIgnoreCase(method)) return new double[]{15.0, 15.0, 0.0};
        if ("Dubai".equalsIgnoreCase(method)) return new double[]{18.2, 18.2, 0.0};
        if ("Qatar".equalsIgnoreCase(method)) return new double[]{18.0, 0.0, 90.0};
        if ("Kuwait".equalsIgnoreCase(method)) return new double[]{18.0, 17.5, 0.0};
        if ("Turkey".equalsIgnoreCase(method)) return new double[]{18.0, 17.0, 0.0};
        if ("Singapore".equalsIgnoreCase(method)) return new double[]{20.0, 18.0, 0.0};
        return new double[]{19.5, 17.5, 0.0}; // Egyptian default
    }

    private static long hoursToTimestamp(Calendar dayCal, double fractionalHours, int offsetMinutes) {
        Calendar c = (Calendar) dayCal.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long totalMs = Math.round((fractionalHours * 3600.0 + offsetMinutes * 60.0) * 1000.0);
        return c.getTimeInMillis() + totalMs;
    }

    private static long[] computeSixPrayersForDay(
        Calendar dayCal,
        double lat,
        double lng,
        String method,
        String madhab,
        JSONObject offsetsObj
    ) {
        int year = dayCal.get(Calendar.YEAR);
        int month = dayCal.get(Calendar.MONTH) + 1;
        int day = dayCal.get(Calendar.DAY_OF_MONTH);

        TimeZone tz = dayCal.getTimeZone();
        double tzOffsetHours = tz.getOffset(dayCal.getTimeInMillis()) / 3600000.0;

        double jd = getJulianDate(year, month, day) - lng / (15.0 * 24.0);
        double[] sun = getSunPosition(jd + 0.5);
        double decl = sun[0];
        double eqt = sun[1];

        double[] params = getMethodParams(method);
        double dhuhrH = 12.0 + tzOffsetHours - lng / 15.0 - eqt;
        double sunriseAngle = 0.833;
        double sunriseHa = computeHourAngle(lat, decl, sunriseAngle);
        double sunriseH = dhuhrH - sunriseHa;
        double maghribH = dhuhrH + sunriseHa;

        double fajrHa = computeHourAngle(lat, decl, params[0]);
        double fajrH = dhuhrH - fajrHa;

        int shadowFactor = "hanafi".equalsIgnoreCase(madhab) ? 2 : 1;
        double asrHa = computeAsrHourAngle(lat, decl, shadowFactor);
        double asrH = dhuhrH + asrHa;

        double ishaH;
        if (params[2] > 0) {
            ishaH = maghribH + params[2] / 60.0;
        } else {
            double ishaHa = computeHourAngle(lat, decl, params[1]);
            ishaH = dhuhrH + ishaHa;
        }

        long fajrMs = hoursToTimestamp(dayCal, fajrH, offsetsObj.optInt("fajr", 0));
        long sunriseMs = hoursToTimestamp(dayCal, sunriseH, offsetsObj.optInt("sunrise", 0));
        long dhuhrMs = hoursToTimestamp(dayCal, dhuhrH + 2.0 / 60.0, offsetsObj.optInt("dhuhr", 0));
        long asrMs = hoursToTimestamp(dayCal, asrH, offsetsObj.optInt("asr", 0));
        long maghribMs = hoursToTimestamp(dayCal, maghribH + 1.0 / 60.0, offsetsObj.optInt("maghrib", 0));
        long ishaMs = hoursToTimestamp(dayCal, ishaH, offsetsObj.optInt("isha", 0));

        return new long[]{fajrMs, sunriseMs, dhuhrMs, asrMs, maghribMs, ishaMs};
    }

    public static PrayerWidgetSnapshot calculateSnapshot(Context context) {
        return calculateSnapshot(context, "next");
    }

    public static PrayerWidgetSnapshot calculateSnapshot(Context context, String targetPrayer) {
        SharedPreferences widgetPrefs = RifqWidgetPrefs.getPrefs(context);
        SharedPreferences focusPrefs = PrayerFocusPrefs.getPrefs(context);

        long defaultLatBits = Double.doubleToLongBits(30.0444);
        long defaultLngBits = Double.doubleToLongBits(31.2357);

        long latBits = widgetPrefs.contains(RifqWidgetPrefs.KEY_CITY_LAT_BITS)
            ? widgetPrefs.getLong(RifqWidgetPrefs.KEY_CITY_LAT_BITS, defaultLatBits)
            : focusPrefs.getLong(PrayerFocusPrefs.KEY_CITY_LAT_BITS, defaultLatBits);
        long lngBits = widgetPrefs.contains(RifqWidgetPrefs.KEY_CITY_LNG_BITS)
            ? widgetPrefs.getLong(RifqWidgetPrefs.KEY_CITY_LNG_BITS, defaultLngBits)
            : focusPrefs.getLong(PrayerFocusPrefs.KEY_CITY_LNG_BITS, defaultLngBits);

        double lat = Double.longBitsToDouble(latBits);
        double lng = Double.longBitsToDouble(lngBits);

        String cityNameAr = widgetPrefs.getString(
            RifqWidgetPrefs.KEY_CITY_NAME_AR,
            focusPrefs.getString(PrayerFocusPrefs.KEY_CITY_NAME_AR, "القاهرة")
        );
        if (cityNameAr == null || cityNameAr.trim().isEmpty()) {
            cityNameAr = "القاهرة";
        }

        String method = widgetPrefs.getString(
            RifqWidgetPrefs.KEY_CALC_METHOD,
            focusPrefs.getString(PrayerFocusPrefs.KEY_CALC_METHOD, "Egyptian")
        );
        String madhab = widgetPrefs.getString(
            RifqWidgetPrefs.KEY_MADHAB,
            focusPrefs.getString(PrayerFocusPrefs.KEY_MADHAB, "shafi")
        );
        String timeFormat = widgetPrefs.getString(RifqWidgetPrefs.KEY_TIME_FORMAT, "12h");
        int hijriAdjustment = widgetPrefs.getInt(RifqWidgetPrefs.KEY_HIJRI_ADJUSTMENT, 0);

        String offsetsRaw = widgetPrefs.getString(
            RifqWidgetPrefs.KEY_MANUAL_OFFSETS_JSON,
            focusPrefs.getString(PrayerFocusPrefs.KEY_MANUAL_OFFSETS, "{}")
        );
        JSONObject offsetsObj;
        try {
            offsetsObj = new JSONObject(offsetsRaw != null ? offsetsRaw : "{}");
        } catch (Exception e) {
            offsetsObj = new JSONObject();
        }

        Calendar todayCal = Calendar.getInstance();
        long[] todayTimes = computeSixPrayersForDay(todayCal, lat, lng, method, madhab, offsetsObj);

        String[] keys = new String[]{"fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"};
        String[] namesAr = new String[]{"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};

        long now = System.currentTimeMillis();
        int nextIdx = -1;
        long nextTimeMs = 0L;

        // Check if user selected a specific prayer ("fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha")
        int explicitPrayerIdx = -1;
        if (targetPrayer != null && !"next".equalsIgnoreCase(targetPrayer.trim())) {
            for (int i = 0; i < keys.length; i++) {
                if (keys[i].equalsIgnoreCase(targetPrayer.trim())) {
                    explicitPrayerIdx = i;
                    break;
                }
            }
        }

        if (explicitPrayerIdx >= 0) {
            nextIdx = explicitPrayerIdx;
            if (todayTimes[explicitPrayerIdx] >= now) {
                nextTimeMs = todayTimes[explicitPrayerIdx];
            } else {
                Calendar tomorrowCal = (Calendar) todayCal.clone();
                tomorrowCal.add(Calendar.DAY_OF_YEAR, 1);
                long[] tomorrowTimes = computeSixPrayersForDay(tomorrowCal, lat, lng, method, madhab, offsetsObj);
                nextTimeMs = tomorrowTimes[explicitPrayerIdx];
            }
        } else {
            for (int i = 0; i < todayTimes.length; i++) {
                if (todayTimes[i] > now) {
                    nextIdx = i;
                    nextTimeMs = todayTimes[i];
                    break;
                }
            }

            if (nextIdx == -1) {
                Calendar tomorrowCal = (Calendar) todayCal.clone();
                tomorrowCal.add(Calendar.DAY_OF_YEAR, 1);
                long[] tomorrowTimes = computeSixPrayersForDay(tomorrowCal, lat, lng, method, madhab, offsetsObj);
                nextIdx = 0;
                nextTimeMs = tomorrowTimes[0];
            }
        }

        String nextKey = keys[nextIdx];
        String nextNameAr = namesAr[nextIdx];
        String nextFormatted = formatTime(nextTimeMs, "24h".equalsIgnoreCase(timeFormat), true);

        long diffMs = Math.max(0L, nextTimeMs - now);
        long totalMinutes = diffMs / 60000L;
        long hours = totalMinutes / 60L;
        long mins = totalMinutes % 60L;
        String remainingStr;
        if (hours > 0) {
            remainingStr = String.format(Locale.US, "%02d:%02d س", hours, mins);
        } else if (mins > 0) {
            remainingStr = String.format(Locale.US, "%d د", mins);
        } else {
            remainingStr = "حان الآن";
        }

        boolean is24h = "24h".equalsIgnoreCase(timeFormat);
        String fajrShort = formatTime(todayTimes[0], is24h, false);
        String sunriseShort = formatTime(todayTimes[1], is24h, false);
        String dhuhrShort = formatTime(todayTimes[2], is24h, false);
        String asrShort = formatTime(todayTimes[3], is24h, false);
        String maghribShort = formatTime(todayTimes[4], is24h, false);
        String ishaShort = formatTime(todayTimes[5], is24h, false);

        String hijriText = computeHijriDateString(now, hijriAdjustment);

        return new PrayerWidgetSnapshot(
            cityNameAr,
            hijriText,
            nextKey,
            nextNameAr,
            nextFormatted,
            nextTimeMs,
            remainingStr,
            fajrShort,
            sunriseShort,
            dhuhrShort,
            asrShort,
            maghribShort,
            ishaShort
        );
    }

    private static String formatTime(long timestampMs, boolean use24h, boolean includePeriod) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(timestampMs);
        int hour24 = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        if (use24h) {
            return String.format(Locale.US, "%02d:%02d", hour24, minute);
        }
        boolean isPm = hour24 >= 12;
        int hour12 = hour24 % 12;
        if (hour12 == 0) hour12 = 12;
        if (includePeriod) {
            return String.format(Locale.US, "%d:%02d %s", hour12, minute, isPm ? "م" : "ص");
        }
        return String.format(Locale.US, "%d:%02d", hour12, minute);
    }

    private static final String[] HIJRI_MONTH_NAMES = new String[]{
        "محرم",
        "صفر",
        "ربيع الأول",
        "ربيع الآخر",
        "جمادى الأولى",
        "جمادى الآخرة",
        "رجب",
        "شعبان",
        "رمضان",
        "شوال",
        "ذو القعدة",
        "ذو الحجة"
    };

    private static String computeHijriDateString(long nowMs, int adjustmentDays) {
        long adjustedMs = nowMs + (long) adjustmentDays * 86400_000L;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                android.icu.util.IslamicCalendar islamicCal = new android.icu.util.IslamicCalendar();
                islamicCal.setTimeInMillis(adjustedMs);
                int day = islamicCal.get(android.icu.util.Calendar.DAY_OF_MONTH);
                int month = islamicCal.get(android.icu.util.Calendar.MONTH);
                int year = islamicCal.get(android.icu.util.Calendar.YEAR);
                String monthName = HIJRI_MONTH_NAMES[Math.max(0, Math.min(11, month))];
                return day + " " + monthName + " " + year + " هـ";
            } catch (Exception ignored) {
            }
        }
        // Fallback Kuwaiti astronomical conversion if ICU is unavailable
        Calendar gCal = Calendar.getInstance();
        gCal.setTimeInMillis(adjustedMs);
        double jd = getJulianDate(
            gCal.get(Calendar.YEAR),
            gCal.get(Calendar.MONTH) + 1,
            gCal.get(Calendar.DAY_OF_MONTH)
        );
        double l = Math.floor(jd) - 1948440 + 10632;
        double n = Math.floor((l - 1) / 10631.0);
        l = l - 10631 * n + 354;
        double j = (Math.floor((10985 - l) / 5316.0)) * (Math.floor((50 * l) / 17719.0))
            + (Math.floor(l / 5670.0)) * (Math.floor((43 * l) / 15238.0));
        l = l - (Math.floor((30 - j) / 15.0)) * (Math.floor((17719 * j) / 50.0))
            - (Math.floor(j / 16.0)) * (Math.floor((15238 * j) / 43.0)) + 29;
        int month = (int) Math.floor((24 * l) / 709.0);
        int day = (int) (l - Math.floor((709 * month) / 24.0));
        int year = (int) (30 * n + j - 30);
        String monthName = HIJRI_MONTH_NAMES[Math.max(0, Math.min(11, month - 1))];
        return day + " " + monthName + " " + year + " هـ";
    }
}
