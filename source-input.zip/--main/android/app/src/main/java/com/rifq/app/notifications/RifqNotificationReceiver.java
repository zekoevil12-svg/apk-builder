package com.rifq.app.notifications;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.rifq.app.audioathkar.RifqAudioAthkarCatalog;
import com.rifq.app.audioathkar.RifqAudioAthkarPrefs;
import com.rifq.app.audioathkar.RifqAudioAthkarService;
import org.json.JSONObject;

/**
 * Receives scheduled alarm broadcasts from Android AlarmManager when RIFQ is open,
 * in background, or completely closed, and posts the real Android System Notification
 * while also recording it for the in-app Notification Center ("مركز التذكيرات والإشعارات")
 * and triggering Spoken Audio Athkar according to user settings.
 */
public class RifqNotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (!RifqAlarmScheduler.ACTION_TRIGGER_NOTIFICATION.equals(action)) {
            return;
        }

        String id = intent.getStringExtra("id");
        int notificationId = intent.getIntExtra(
            "notificationId",
            RifqAlarmScheduler.stableNotificationId(id)
        );
        String channelId = intent.getStringExtra("channelId");
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        String screen = intent.getStringExtra("screen");
        String ward = intent.getStringExtra("ward");
        String dhikrId = intent.getStringExtra("dhikrId");
        String signatureKey = intent.getStringExtra("signatureKey");
        String timeHHMM = intent.getStringExtra("timeHHMM");
        boolean repeatDaily = intent.getBooleanExtra("repeatDaily", true);

        String normalizedChannel = RifqNotificationChannels.normalizeChannelId(channelId);
        boolean isAthkarOrReminder =
            RifqNotificationChannels.CHANNEL_ADHKAR.equals(normalizedChannel) ||
            RifqNotificationChannels.CHANNEL_REMINDERS.equals(normalizedChannel);

        RifqAudioAthkarPrefs.AudioAthkarConfig audioCfg = RifqAudioAthkarPrefs.loadConfig(context);

        String spokenText = body;
        String spokenTitle = title;
        String spokenSource = "الأذكار اليومية";

        // Rotate Dhikr on recurring daily Athkar slots so it never repeats the same Dhikr boringly
        if (isAthkarOrReminder && repeatDaily) {
            String catHint = null;
            if ("morning".equalsIgnoreCase(ward) || (id != null && id.contains("morning"))) {
                catHint = "morning";
            } else if ("evening".equalsIgnoreCase(ward) || (id != null && id.contains("evening"))) {
                catHint = "evening";
            }
            RifqAudioAthkarCatalog.AudioDhikrEntry freshDhikr =
                RifqAudioAthkarCatalog.pickNextNonRepeatingDhikr(context, catHint);
            if (freshDhikr != null && freshDhikr.text != null && !freshDhikr.text.isEmpty()) {
                spokenText = freshDhikr.text;
                spokenSource = freshDhikr.source;
                if (id != null && id.startsWith("dhikr_slot_")) {
                    body = freshDhikr.text;
                    dhikrId = freshDhikr.id;
                }
            }
        }

        boolean shouldShowText = !isAthkarOrReminder ||
            !audioCfg.enabled ||
            !"audio_only".equalsIgnoreCase(audioCfg.alertMode);

        boolean shouldSpeakAudio = isAthkarOrReminder &&
            audioCfg.enabled &&
            !"text_only".equalsIgnoreCase(audioCfg.alertMode);

        // 1. Display real Android System Notification AND record in In-App Notification Center (unless audio_only)
        if (shouldShowText) {
            RifqNotificationHelper.showSystemNotification(
                context,
                notificationId,
                channelId,
                title,
                body,
                screen,
                ward,
                dhikrId,
                signatureKey,
                false, // respect channel state & quiet hours
                true   // record in in-app Notification Center
            );
        }

        // 1.5. Speak Dhikr aloud on the user's Android device if Spoken Athkar is enabled
        if (shouldSpeakAudio && spokenText != null && !spokenText.trim().isEmpty()) {
            RifqAudioAthkarService.speakDhikrNow(
                context,
                spokenText,
                spokenTitle,
                spokenSource,
                null,
                false,
                false
            );
        }

        // 2. If this is a daily repeating reminder, automatically schedule tomorrow's occurrence
        if (repeatDaily && timeHHMM != null && !timeHHMM.isEmpty()) {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                long nowMs = System.currentTimeMillis();
                long nextTriggerMs = RifqAlarmScheduler.computeNextOccurrenceMs(
                    timeHHMM,
                    nowMs + 60_000L
                );
                String nextDateStr = RifqAlarmScheduler.formatDateYYYYMMDD(nextTriggerMs);
                String nextSignature = nextDateStr + "_" + (id != null ? id : "rem") + "_" + timeHHMM;

                try {
                    JSONObject nextItem = new JSONObject();
                    nextItem.put("id", id != null ? id : "notif_item");
                    nextItem.put("notificationId", notificationId);
                    nextItem.put("channelId", channelId != null ? channelId : RifqNotificationChannels.CHANNEL_GENERAL);
                    nextItem.put("title", title != null ? title : "رِفْق | RIFQ");
                    nextItem.put("body", body != null ? body : "");
                    nextItem.put("screen", screen != null ? screen : "");
                    nextItem.put("ward", ward != null ? ward : "");
                    nextItem.put("dhikrId", dhikrId != null ? dhikrId : "");
                    nextItem.put("timestamp", nextTriggerMs);
                    nextItem.put("timeHHMM", timeHHMM);
                    nextItem.put("repeatDaily", true);
                    nextItem.put("enabled", true);
                    nextItem.put("signatureKey", nextSignature);

                    RifqAlarmScheduler.scheduleSingleItem(context, alarmManager, nextItem, nowMs);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
