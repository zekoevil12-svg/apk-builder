package com.rifq.app.quranaudio;

import android.content.Context;
import android.content.SharedPreferences;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Native Android Capacitor Plugin for persistent Offline Quran Audio Downloads (`@CapacitorPlugin(name = "RifqQuranAudio")`).
 *
 * Stores downloaded Surah MP3 files permanently inside the app's private internal storage directory
 * (`context.getFilesDir()/quran_audio/`) so files survive app closure, Force Close, cache cleanup,
 * and device reboots, and can be played 100% offline.
 */
@CapacitorPlugin(name = "RifqQuranAudio")
public class RifqQuranAudioPlugin extends Plugin {

    private static final String PREFS_NAME = "rifq_quran_audio_offline_meta_v2";
    private static final String KEY_DOWNLOADS_MAP = "downloads_map_json";
    private static final String AUDIO_FOLDER_NAME = "quran_audio";
    private static final long MIN_VALID_MP3_BYTES = 10240L; // 10 KB minimum

    private final ExecutorService downloadExecutor = Executors.newFixedThreadPool(2);

    private File getAudioDirectory(Context context) {
        File dir = new File(context.getFilesDir(), AUDIO_FOLDER_NAME);
        if (!dir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        }
        return dir;
    }

    private String sanitizeTrackId(String rawId) {
        if (rawId == null || rawId.trim().isEmpty()) {
            return "unknown_track";
        }
        return rawId.trim().replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    private SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    private synchronized JSONObject loadMetadataMap(Context context) {
        try {
            String raw = getPrefs(context).getString(KEY_DOWNLOADS_MAP, "{}");
            if (raw != null && !raw.trim().isEmpty()) {
                return new JSONObject(raw);
            }
        } catch (Exception ignored) {
        }
        return new JSONObject();
    }

    private synchronized void saveMetadataMap(Context context, JSONObject map) {
        try {
            getPrefs(context)
                .edit()
                .putString(KEY_DOWNLOADS_MAP, map != null ? map.toString() : "{}")
                .commit();
        } catch (Exception ignored) {
        }
    }

    /**
     * Verifies that the file on disk exists, is larger than MIN_VALID_MP3_BYTES,
     * and is not an HTML/JSON error page.
     */
    private boolean isValidMp3File(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            return false;
        }
        if (file.length() < MIN_VALID_MP3_BYTES) {
            return false;
        }
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            byte[] header = new byte[16];
            int read = fis.read(header);
            if (read < 4) {
                return false;
            }
            String headStr = new String(header, 0, read, StandardCharsets.US_ASCII).trim().toLowerCase(Locale.ROOT);
            if (
                headStr.startsWith("<!doc") ||
                headStr.startsWith("<html") ||
                headStr.startsWith("<?xml") ||
                headStr.startsWith("{\"error")
            ) {
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private String nowIsoTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    private JSObject jsonToJSObject(JSONObject obj) {
        JSObject js = new JSObject();
        if (obj == null) return js;
        Iterator<String> keys = obj.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            try {
                js.put(k, obj.get(k));
            } catch (Exception ignored) {
            }
        }
        return js;
    }

    private void emitProgress(String trackId, int surahNumber, String reciterId, int percent) {
        try {
            JSObject data = new JSObject();
            data.put("id", trackId);
            data.put("surahNumber", surahNumber);
            data.put("reciterId", reciterId);
            data.put("percent", percent);
            notifyListeners("quranAudioDownloadProgress", data);
        } catch (Exception ignored) {
        }
    }

    /**
     * Downloads a Surah MP3 from candidateUrls into permanent internal storage (`filesDir/quran_audio/`),
     * verifies file integrity, and persists metadata in SharedPreferences.
     */
    @PluginMethod
    public void downloadSurah(final PluginCall call) {
        final Context context = getContext();
        if (context == null) {
            call.reject("Context unavailable");
            return;
        }

        final String trackId = call.getString("id", "");
        final String surahId = call.getString("surahId", "");
        final String reciterId = call.getString("reciterId", "");
        final String reciterName = call.getString("reciterName", "");
        final int surahNumber = call.getInt("surahNumber", 1);
        final String surahName = call.getString("surahName", "");
        final JSArray candidateUrlsJs = call.getArray("candidateUrls");

        if (trackId == null || trackId.trim().isEmpty() || candidateUrlsJs == null || candidateUrlsJs.length() == 0) {
            call.reject("بيانات تحميل السورة غير مكتملة");
            return;
        }

        downloadExecutor.execute(() -> {
            File audioDir = getAudioDirectory(context);
            String safeId = sanitizeTrackId(trackId);
            File finalFile = new File(audioDir, safeId + ".mp3");
            File partFile = new File(audioDir, safeId + ".mp3.part");

            // If a valid file already exists on disk, verify and return its metadata without re-downloading
            if (isValidMp3File(finalFile)) {
                try {
                    JSONObject metaMap = loadMetadataMap(context);
                    JSONObject existing = metaMap.optJSONObject(trackId);
                    String primaryUrl = candidateUrlsJs.getString(0);
                    JSONObject record = new JSONObject();
                    record.put("id", trackId);
                    record.put("surahId", surahId.isEmpty() ? "surah_" + surahNumber : surahId);
                    record.put("reciterId", reciterId);
                    record.put("reciterName", reciterName);
                    record.put("surahNumber", surahNumber);
                    record.put("surahName", surahName);
                    record.put("sourceUrl", existing != null ? existing.optString("sourceUrl", primaryUrl) : primaryUrl);
                    record.put("audioUrl", existing != null ? existing.optString("audioUrl", primaryUrl) : primaryUrl);
                    record.put("localFilePath", finalFile.getAbsolutePath());
                    record.put("fileSizeBytes", finalFile.length());
                    record.put("downloadedAt", existing != null ? existing.optString("downloadedAt", nowIsoTimestamp()) : nowIsoTimestamp());
                    record.put("downloadStatus", "downloaded");

                    metaMap.put(trackId, record);
                    saveMetadataMap(context, metaMap);

                    emitProgress(trackId, surahNumber, reciterId, 100);
                    call.resolve(jsonToJSObject(record));
                    return;
                } catch (Exception ignored) {
                }
            }

            // Clean up any leftover partial file before starting
            if (partFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                partFile.delete();
            }

            Exception lastException = null;
            emitProgress(trackId, surahNumber, reciterId, 5);

            for (int i = 0; i < candidateUrlsJs.length(); i++) {
                String candidateUrl = null;
                try {
                    candidateUrl = candidateUrlsJs.getString(i);
                } catch (Exception ignored) {
                }
                if (candidateUrl == null || candidateUrl.trim().isEmpty()) {
                    continue;
                }

                HttpURLConnection connection = null;
                InputStream inputStream = null;
                FileOutputStream outputStream = null;

                try {
                    String currentUrl = candidateUrl.trim();
                    int redirects = 0;

                    while (redirects < 5) {
                        URL urlObj = new URL(currentUrl);
                        connection = (HttpURLConnection) urlObj.openConnection();
                        connection.setInstanceFollowRedirects(true);
                        connection.setConnectTimeout(15000);
                        connection.setReadTimeout(30000);
                        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) RifqApp/1.0");
                        connection.setRequestProperty("Accept", "audio/mpeg, audio/*, */*");
                        connection.connect();

                        int code = connection.getResponseCode();
                        if (
                            code == HttpURLConnection.HTTP_MOVED_PERM ||
                            code == HttpURLConnection.HTTP_MOVED_TEMP ||
                            code == HttpURLConnection.HTTP_SEE_OTHER ||
                            code == 307 ||
                            code == 308
                        ) {
                            String location = connection.getHeaderField("Location");
                            connection.disconnect();
                            if (location == null || location.trim().isEmpty()) {
                                throw new IOException("Redirect without Location header");
                            }
                            currentUrl = location.trim();
                            redirects++;
                            continue;
                        }
                        break;
                    }

                    int responseCode = connection.getResponseCode();
                    if (responseCode < 200 || responseCode >= 300) {
                        throw new IOException("HTTP " + responseCode + " from " + candidateUrl);
                    }

                    long contentLength = connection.getContentLengthLong();
                    inputStream = new BufferedInputStream(connection.getInputStream(), 32 * 1024);
                    outputStream = new FileOutputStream(partFile);

                    byte[] buffer = new byte[16 * 1024];
                    long totalRead = 0L;
                    int bytesRead;
                    long lastProgressEmit = 0L;

                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                        totalRead += bytesRead;

                        long now = System.currentTimeMillis();
                        if (now - lastProgressEmit >= 140) {
                            lastProgressEmit = now;
                            int pct;
                            if (contentLength > 0) {
                                pct = (int) Math.min(96L, Math.max(8L, (totalRead * 96L) / contentLength));
                            } else {
                                pct = (int) Math.min(90L, 10L + (totalRead / (64 * 1024)));
                            }
                            emitProgress(trackId, surahNumber, reciterId, pct);
                        }
                    }

                    outputStream.flush();
                    outputStream.getFD().sync();
                    outputStream.close();
                    outputStream = null;
                    inputStream.close();
                    inputStream = null;

                    // Verify full content length if server provided it
                    if (contentLength > 0 && totalRead != contentLength) {
                        throw new IOException("Incomplete download: read " + totalRead + " of " + contentLength);
                    }

                    // Verify MP3 integrity
                    if (!isValidMp3File(partFile)) {
                        throw new IOException("Downloaded file failed MP3 validation");
                    }

                    // Move partFile -> finalFile
                    if (finalFile.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        finalFile.delete();
                    }
                    if (!partFile.renameTo(finalFile)) {
                        // Fallback copy if rename across mount points fails
                        try (
                            FileInputStream in = new FileInputStream(partFile);
                            FileOutputStream out = new FileOutputStream(finalFile)
                        ) {
                            byte[] copyBuf = new byte[16 * 1024];
                            int r;
                            while ((r = in.read(copyBuf)) != -1) {
                                out.write(copyBuf, 0, r);
                            }
                            out.flush();
                            out.getFD().sync();
                        }
                        //noinspection ResultOfMethodCallIgnored
                        partFile.delete();
                    }

                    if (!isValidMp3File(finalFile)) {
                        throw new IOException("Final MP3 file verification failed");
                    }

                    String downloadedAt = nowIsoTimestamp();
                    JSONObject record = new JSONObject();
                    record.put("id", trackId);
                    record.put("surahId", surahId.isEmpty() ? "surah_" + surahNumber : surahId);
                    record.put("reciterId", reciterId);
                    record.put("reciterName", reciterName);
                    record.put("surahNumber", surahNumber);
                    record.put("surahName", surahName);
                    record.put("sourceUrl", candidateUrl);
                    record.put("audioUrl", candidateUrl);
                    record.put("localFilePath", finalFile.getAbsolutePath());
                    record.put("fileSizeBytes", finalFile.length());
                    record.put("downloadedAt", downloadedAt);
                    record.put("downloadStatus", "downloaded");

                    JSONObject metaMap = loadMetadataMap(context);
                    metaMap.put(trackId, record);
                    saveMetadataMap(context, metaMap);

                    emitProgress(trackId, surahNumber, reciterId, 100);
                    call.resolve(jsonToJSObject(record));
                    return;
                } catch (Exception e) {
                    lastException = e;
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException ignored) {
                        }
                    }
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException ignored) {
                        }
                    }
                    if (partFile.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        partFile.delete();
                    }
                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }

            // All candidate URLs failed: ensure no corrupted or partial files remain
            if (partFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                partFile.delete();
            }
            if (finalFile.exists() && !isValidMp3File(finalFile)) {
                //noinspection ResultOfMethodCallIgnored
                finalFile.delete();
            }

            call.reject(
                lastException != null
                    ? "فشل تحميل السورة: " + lastException.getMessage()
                    : "تعذر تحميل ملف السورة الصوتي"
            );
        });
    }

    /**
     * Verifies all downloaded files on disk and returns the list of healthy downloaded Surahs.
     * Deletes any partial `.part` or corrupted files automatically.
     */
    @PluginMethod
    public void verifyAndListDownloads(final PluginCall call) {
        final Context context = getContext();
        if (context == null) {
            call.reject("Context unavailable");
            return;
        }

        downloadExecutor.execute(() -> {
            File audioDir = getAudioDirectory(context);

            // 1. Clean up any leftover .part files from interrupted sessions
            File[] allFiles = audioDir.listFiles();
            if (allFiles != null) {
                for (File f : allFiles) {
                    if (f.getName().endsWith(".part")) {
                        //noinspection ResultOfMethodCallIgnored
                        f.delete();
                    }
                }
            }

            JSONObject metaMap = loadMetadataMap(context);
            JSArray clientRecords = call.getArray("clientRecords");
            boolean mapModified = false;

            // 2. If client passed records, adopt any that correspond to a real valid file on disk
            if (clientRecords != null) {
                for (int i = 0; i < clientRecords.length(); i++) {
                    try {
                        JSONObject cObj = clientRecords.getJSONObject(i);
                        if (cObj == null) continue;
                        String id = cObj.optString("id", "");
                        if (id.isEmpty() || metaMap.has(id)) continue;

                        File candidateFile = new File(audioDir, sanitizeTrackId(id) + ".mp3");
                        if (isValidMp3File(candidateFile)) {
                            cObj.put("localFilePath", candidateFile.getAbsolutePath());
                            cObj.put("fileSizeBytes", candidateFile.length());
                            cObj.put("downloadStatus", "downloaded");
                            metaMap.put(id, cObj);
                            mapModified = true;
                        }
                    } catch (Exception ignored) {
                    }
                }
            }

            // 3. Verify every entry in metaMap against the physical file on disk
            JSONObject verifiedMap = new JSONObject();
            JSArray verifiedList = new JSArray();

            Iterator<String> keys = metaMap.keys();
            while (keys.hasNext()) {
                String trackId = keys.next();
                JSONObject item = metaMap.optJSONObject(trackId);
                if (item == null) {
                    mapModified = true;
                    continue;
                }

                String savedPath = item.optString("localFilePath", "");
                File file = !savedPath.isEmpty()
                    ? new File(savedPath)
                    : new File(audioDir, sanitizeTrackId(trackId) + ".mp3");

                if (!file.exists()) {
                    file = new File(audioDir, sanitizeTrackId(trackId) + ".mp3");
                }

                if (isValidMp3File(file)) {
                    try {
                        item.put("localFilePath", file.getAbsolutePath());
                        item.put("fileSizeBytes", file.length());
                        item.put("downloadStatus", "downloaded");
                        if (item.optString("surahId", "").isEmpty()) {
                            item.put("surahId", "surah_" + item.optInt("surahNumber", 1));
                        }
                        if (item.optString("sourceUrl", "").isEmpty()) {
                            item.put("sourceUrl", item.optString("audioUrl", ""));
                        }
                        verifiedMap.put(trackId, item);
                        verifiedList.put(item);
                    } catch (Exception ignored) {
                    }
                } else {
                    // Corrupted or missing file: delete if exists and remove from metadata
                    if (file.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        file.delete();
                    }
                    mapModified = true;
                }
            }

            if (mapModified || verifiedMap.length() != metaMap.length()) {
                saveMetadataMap(context, verifiedMap);
            }

            JSObject result = new JSObject();
            result.put("downloads", verifiedList);
            call.resolve(result);
        });
    }

    /**
     * Checks whether a specific Surah track file exists and is valid on disk.
     */
    @PluginMethod
    public void verifySurahFile(final PluginCall call) {
        final Context context = getContext();
        if (context == null) {
            call.reject("Context unavailable");
            return;
        }

        final String trackId = call.getString("id", "");
        if (trackId == null || trackId.trim().isEmpty()) {
            JSObject res = new JSObject();
            res.put("exists", false);
            call.resolve(res);
            return;
        }

        File audioDir = getAudioDirectory(context);
        JSONObject metaMap = loadMetadataMap(context);
        JSONObject record = metaMap.optJSONObject(trackId);

        File file = null;
        if (record != null) {
            String path = record.optString("localFilePath", "");
            if (!path.isEmpty()) {
                file = new File(path);
            }
        }
        if (file == null || !file.exists()) {
            file = new File(audioDir, sanitizeTrackId(trackId) + ".mp3");
        }

        boolean valid = isValidMp3File(file);
        JSObject res = new JSObject();
        res.put("exists", valid);
        if (valid) {
            res.put("localFilePath", file.getAbsolutePath());
            res.put("fileSizeBytes", file.length());
            if (record != null) {
                res.put("record", jsonToJSObject(record));
            }
        }
        call.resolve(res);
    }

    /**
     * Deletes a downloaded Surah MP3 file from disk and removes its metadata from SharedPreferences.
     */
    @PluginMethod
    public void deleteSurah(final PluginCall call) {
        final Context context = getContext();
        if (context == null) {
            call.reject("Context unavailable");
            return;
        }

        final String trackId = call.getString("id", "");
        if (trackId == null || trackId.trim().isEmpty()) {
            call.reject("Missing track id");
            return;
        }

        downloadExecutor.execute(() -> {
            File audioDir = getAudioDirectory(context);
            JSONObject metaMap = loadMetadataMap(context);
            JSONObject existing = metaMap.optJSONObject(trackId);

            if (existing != null) {
                String path = existing.optString("localFilePath", "");
                if (!path.isEmpty()) {
                    File f = new File(path);
                    if (f.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        f.delete();
                    }
                }
                metaMap.remove(trackId);
                saveMetadataMap(context, metaMap);
            }

            File stdFile = new File(audioDir, sanitizeTrackId(trackId) + ".mp3");
            if (stdFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                stdFile.delete();
            }
            File partFile = new File(audioDir, sanitizeTrackId(trackId) + ".mp3.part");
            if (partFile.exists()) {
                //noinspection ResultOfMethodCallIgnored
                partFile.delete();
            }

            JSArray remaining = new JSArray();
            Iterator<String> keys = metaMap.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject item = metaMap.optJSONObject(k);
                if (item != null) {
                    remaining.put(item);
                }
            }

            JSObject result = new JSObject();
            result.put("deleted", true);
            result.put("downloads", remaining);
            call.resolve(result);
        });
    }
}
