package com.rifq.app.prayerfocus;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Native Android BroadcastReceiver that detects the exact moment the device transitions from
 * LOCKED -> UNLOCKED (Intent.ACTION_USER_PRESENT / Intent.ACTION_SCREEN_ON when Keyguard is unlocked).
 *
 * Behavior (Requirement 1, 2, 5, 6, 7, 8, 27):
 * 1. Reads currentTime = System.currentTimeMillis()
 * 2. Reads active Prayer Device Lock window (adhanTimestamp & endTimestamp = adhanTimestamp + 20 minutes)
 * 3. If currentTime < endTimestamp:
 *    - Does NOT treat Keyguard unlock as the end of Prayer Device Lock
 *    - Does NOT start a new 20-minute timer
 *    - Immediately re-applies Lock Task / Prayer Device Lock protection with zero delay
 * 4. If currentTime >= endTimestamp:
 *    - Releases Lock Task Mode and allows normal device usage.
 */
public class PrayerDeviceUnlockReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) {
            return;
        }

        String action = intent.getAction();
        if (action == null) {
            return;
        }

        if (Intent.ACTION_USER_PRESENT.equals(action)) {
            // Fired by Android OS the exact moment Keyguard credential unlock succeeds
            // (PIN, Password, Pattern, Fingerprint, Face Unlock, or Smart Lock)
            PrayerDeviceLockEnforcer.onDeviceUnlocked(context, "ACTION_USER_PRESENT");
        } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
            // If the screen turns on and the device has no secure Keyguard (or biometric unlocked immediately)
            if (!PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                PrayerDeviceLockEnforcer.onDeviceUnlocked(context, "ACTION_SCREEN_ON_UNLOCKED");
            }
        } else if (PrayerFocusAlarmReceiver.ACTION_FOCUS_END.equals(action)) {
            PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(context);
        }
    }
}
