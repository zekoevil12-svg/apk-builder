package com.rifq.app.prayerfocus;

import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.content.Intent;

/**
 * Central native enforcement coordinator for RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Guarantees:
 * 1. Zero intentional delay (no sleep, no setTimeout, no slow polling, no network/Firebase wait).
 * 2. Strict timestamp authority:
 *    - endTimestamp = adhanTimestamp + 20 minutes
 *    - Prayer Device Lock is ACTIVE if and only if currentTime < endTimestamp
 * 3. Never resets or restarts a new 20-minute timer when the user unlocks the phone mid-prayer
 *    or when the phone reboots mid-prayer.
 * 4. If the device is provisioned as Device Owner / Dedicated Device, configures Lock Task Mode
 *    via DevicePolicyManager and launches PrayerLockActivity into startLockTask() immediately.
 * 5. Never attempts to break Android Keyguard while the screen is locked; instead, the instant
 *    Keyguard transitions from LOCKED -> UNLOCKED (ACTION_USER_PRESENT), immediately enforces
 *    PrayerLockActivity + Lock Task Mode for the remaining duration until endTimestamp.
 */
public class PrayerDeviceLockEnforcer {

    public static final String ACTION_RELEASE_PRAYER_DEVICE_LOCK = "com.rifq.app.ACTION_RELEASE_PRAYER_DEVICE_LOCK";
    private static volatile long lastEnforceTimestampMs = 0L;

    /**
     * Immediately enforces Prayer Device Lock if currentTime < activeWindow.endTimeMs.
     * Called on:
     * - Exact Adhan start (when device is unlocked)
     * - Immediate Keyguard unlock (ACTION_USER_PRESENT / ACTION_SCREEN_ON)
     * - Accessibility window state change (attempt to use Home, Recents, or any non-exempt app)
     * - Reboot recovery during an active 20-minute prayer window
     */
    public static void enforceImmediateDeviceLock(
        Context context,
        PrayerFocusPrefs.ActiveFocusWindow activeWindow,
        String triggerReason
    ) {
        if (context == null || activeWindow == null) {
            return;
        }

        long currentTime = System.currentTimeMillis();
        // Law of truth: Prayer Device Lock is active ONLY while currentTime < endTimestamp
        if (currentTime < activeWindow.startTimeMs || currentTime >= activeWindow.endTimeMs) {
            releaseDeviceLockIfActive(context);
            return;
        }

        // If Keyguard is currently locked (user hasn't entered PIN/biometric yet), do not try to break Keyguard.
        // Instead, if Device Admin is active and this is Adhan start while unlocked, or once Keyguard is unlocked,
        // enforce immediately.
        boolean keyguardLocked = PrayerDeviceAdminReceiver.isKeyguardLocked(context);
        if (keyguardLocked && !"DEVICE_UNLOCKED".equals(triggerReason)) {
            return;
        }

        // Ultra-short frame deduplication (60ms) only to prevent duplicate Intent dispatch in the exact same millisecond
        if (!"DEVICE_UNLOCKED".equals(triggerReason) && (currentTime - lastEnforceTimestampMs < 60L)) {
            return;
        }
        lastEnforceTimestampMs = currentTime;

        // Ensure DevicePolicyManager Kiosk Lock Task whitelist is configured if Device Owner is active
        if (PrayerDeviceAdminReceiver.isDeviceOwner(context)) {
            PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(context);
        }

        // Launch PrayerLockActivity immediately with zero animation and singleTop/clearTop flags
        Intent lockIntent = new Intent(context, PrayerLockActivity.class);
        lockIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK |
            Intent.FLAG_ACTIVITY_SINGLE_TOP |
            Intent.FLAG_ACTIVITY_CLEAR_TOP |
            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT |
            Intent.FLAG_ACTIVITY_NO_ANIMATION |
            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        );
        lockIntent.putExtra("windowId", activeWindow.windowId);
        lockIntent.putExtra("prayerKey", activeWindow.prayerKey);
        lockIntent.putExtra("prayerNameAr", activeWindow.prayerNameAr);
        lockIntent.putExtra("startTimeMs", activeWindow.startTimeMs);
        lockIntent.putExtra("endTimeMs", activeWindow.endTimeMs);
        lockIntent.putExtra("adhanTimestamp", activeWindow.startTimeMs);
        lockIntent.putExtra("endTimestamp", activeWindow.endTimeMs);
        lockIntent.putExtra("triggerReason", triggerReason != null ? triggerReason : "ENFORCE");
        context.startActivity(lockIntent);
    }

    /**
     * Evaluates current state on device unlock (LOCKED -> UNLOCKED) and enforces immediately
     * if currentTime < endTimestamp, or releases if currentTime >= endTimestamp.
     */
    public static void onDeviceUnlocked(Context context, String unlockSource) {
        if (context == null) return;
        long currentTime = System.currentTimeMillis();
        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);

        if (active != null && currentTime >= active.startTimeMs && currentTime < active.endTimeMs) {
            // Device was unlocked while Prayer Device Lock is still active!
            // Re-apply protection immediately without resetting endTimestamp.
            enforceImmediateDeviceLock(context, active, "DEVICE_UNLOCKED");
        } else {
            // Window has expired or no window is active -> allow normal phone usage
            if (PrayerLockActivity.isCurrentlyShowing()) {
                releaseDeviceLockIfActive(context);
            }
        }
    }

    /**
     * Releases Prayer Device Lock and exits Lock Task Mode immediately when currentTime >= endTimestamp
     * or when the session is explicitly stopped.
     */
    public static void releaseDeviceLockIfActive(Context context) {
        if (context == null) return;
        PrayerFocusPrefs.clearActiveLockWindow(context);

        // Immediately notify PrayerLockActivity to stopLockTask() and finish()
        PrayerLockActivity.finishActiveInstanceAndStopLockTask();

        Intent releaseIntent = new Intent(ACTION_RELEASE_PRAYER_DEVICE_LOCK);
        releaseIntent.setPackage(context.getPackageName());
        context.sendBroadcast(releaseIntent);
    }

    /**
     * Optional helper: if RIFQ has active DeviceAdmin or DeviceOwner policy and needs to lock Keyguard immediately.
     */
    public static void lockScreenViaDevicePolicyIfPermitted(Context context) {
        if (context == null) return;
        try {
            if (PrayerDeviceAdminReceiver.isDeviceAdminActive(context) || PrayerDeviceAdminReceiver.isDeviceOwner(context)) {
                DevicePolicyManager dpm = PrayerDeviceAdminReceiver.getDpm(context);
                if (dpm != null) {
                    dpm.lockNow();
                }
            }
        } catch (Exception ignored) {
        }
    }
}
