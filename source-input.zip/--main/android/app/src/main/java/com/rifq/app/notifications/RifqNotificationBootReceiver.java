package com.rifq.app.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Restores all scheduled RIFQ notifications and ensures Android Notification Channels exist after:
 * - Device reboot (BOOT_COMPLETED / LOCKED_BOOT_COMPLETED / QUICKBOOT_POWERON)
 * - App update (MY_PACKAGE_REPLACED)
 * - System time or timezone change (TIME_SET / TIMEZONE_CHANGED)
 */
public class RifqNotificationBootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (action == null) return;

        if (
            Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
            Intent.ACTION_TIME_CHANGED.equals(action) ||
            Intent.ACTION_TIMEZONE_CHANGED.equals(action) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(action)
        ) {
            RifqNotificationChannels.createAllChannels(context);
            RifqAlarmScheduler.rescheduleAllSavedAlarms(context);
            com.rifq.app.audioathkar.RifqAudioAthkarScheduler.rescheduleAll(context);
        }
    }
}
