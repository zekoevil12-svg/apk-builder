package com.rifq.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.rifq.app.auth.RifqGoogleAuthPlugin;
import com.rifq.app.notifications.RifqNotificationChannels;
import com.rifq.app.notifications.RifqNotificationHelper;
import com.rifq.app.notifications.RifqNotificationPrefs;
import com.rifq.app.notifications.RifqNotificationsPlugin;
import com.rifq.app.prayerfocus.PrayerDeviceAdminReceiver;
import com.rifq.app.prayerfocus.PrayerDeviceLockEnforcer;
import com.rifq.app.prayerfocus.PrayerDeviceLockService;
import com.rifq.app.prayerfocus.PrayerFocusAlarmReceiver;
import com.rifq.app.prayerfocus.PrayerFocusPlugin;
import com.rifq.app.prayerfocus.PrayerFocusPrefs;
import com.rifq.app.quranaudio.RifqQuranAudioPlugin;
import com.rifq.app.widgets.RifqWidgetPrefs;
import com.rifq.app.widgets.RifqWidgetRenderer;
import com.rifq.app.widgets.RifqWidgetsPlugin;

/**
 * Main Capacitor Android Activity for «رِفْق | RIFQ».
 *
 * Responsibilities:
 * 1. Registers Capacitor plugins: PrayerFocusPlugin & RifqNotificationsPlugin.
 * 2. Registers an immediate, event-driven BroadcastReceiver for `Intent.ACTION_USER_PRESENT`
 *    (and `ACTION_SCREEN_ON` / `ACTION_FOCUS_START` / `ACTION_FOCUS_END`) that immediately verifies
 *    whether `currentTime < endTimestamp` (within the 20-minute prayer lock window) and re-activates
 *    `LockTaskMode` (`startLockTask()` + `PrayerLockActivity`) with zero intentional delay.
 * 3. Starts/synchronizes `PrayerDeviceLockService` so 20-minute prayer lock windows are scheduled
 *    via Android `AlarmManager` independently of JavaScript even when RIFQ is closed.
 */
public class MainActivity extends BridgeActivity {

    /**
     * Immediate BroadcastReceiver inside MainActivity that intercepts `Intent.ACTION_USER_PRESENT`
     * the instant the user unlocks Keyguard (PIN, Password, Pattern, Fingerprint, Face Unlock).
     */
    private final BroadcastReceiver userPresentLockReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) {
                return;
            }
            String action = intent.getAction();
            if (
                Intent.ACTION_USER_PRESENT.equals(action) ||
                PrayerFocusAlarmReceiver.ACTION_FOCUS_START.equals(action)
            ) {
                verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_" + action);
            } else if (Intent.ACTION_SCREEN_ON.equals(action)) {
                if (!PrayerDeviceAdminReceiver.isKeyguardLocked(MainActivity.this)) {
                    verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_SCREEN_ON");
                }
            } else if (
                PrayerFocusAlarmReceiver.ACTION_FOCUS_END.equals(action) ||
                PrayerDeviceLockEnforcer.ACTION_RELEASE_PRAYER_DEVICE_LOCK.equals(action)
            ) {
                releaseMainActivityLockTaskIfActive();
            }
        }
    };

    private boolean isUserPresentReceiverRegistered = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(RifqGoogleAuthPlugin.class);
        registerPlugin(PrayerFocusPlugin.class);
        registerPlugin(RifqNotificationsPlugin.class);
        registerPlugin(RifqWidgetsPlugin.class);
        registerPlugin(RifqQuranAudioPlugin.class);
        super.onCreate(savedInstanceState);

        RifqNotificationChannels.createAllChannels(this);
        registerUserPresentReceiver();

        // Start/schedule native AlarmManager 20-minute prayer lock service (independent of JS)
        PrayerDeviceLockService.startAndScheduleAlarms(this);

        // Ensure Spoken Audio Athkar AlarmManager schedule is active
        com.rifq.app.audioathkar.RifqAudioAthkarScheduler.rescheduleAll(this);

        // Refresh all placed RIFQ Home Screen Widgets
        RifqWidgetRenderer.updateAllPlacedWidgets(this);

        // Immediately check if we are currently inside an active 20-minute prayer window
        verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_ON_CREATE");

        handleNotificationTapIntent(getIntent());
        handleDeepLinkIntent(getIntent());
    }

    @Override
    public void onResume() {
        super.onResume();
        verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_ON_RESUME");
        RifqWidgetRenderer.updateAllPlacedWidgets(this);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_WINDOW_FOCUS");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        verifyAndEnforcePrayerLockImmediately("MAIN_ACTIVITY_NEW_INTENT");
        handleNotificationTapIntent(intent);
        handleDeepLinkIntent(intent);
    }

    @Override
    public void onDestroy() {
        unregisterUserPresentReceiver();
        super.onDestroy();
    }

    /**
     * Registers `userPresentLockReceiver` with high priority for `ACTION_USER_PRESENT`.
     */
    private void registerUserPresentReceiver() {
        if (isUserPresentReceiverRegistered) return;
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_USER_PRESENT);
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_START);
            filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_END);
            filter.addAction(PrayerDeviceLockEnforcer.ACTION_RELEASE_PRAYER_DEVICE_LOCK);
            filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(userPresentLockReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(userPresentLockReceiver, filter);
            }
            isUserPresentReceiverRegistered = true;
        } catch (Exception ignored) {
        }
    }

    private void unregisterUserPresentReceiver() {
        if (!isUserPresentReceiverRegistered) return;
        try {
            unregisterReceiver(userPresentLockReceiver);
        } catch (Exception ignored) {
        }
        isUserPresentReceiverRegistered = false;
    }

    /**
     * Zero-delay verification:
     * Checks `currentTime < endTimestamp` (`adhanTimestamp + 20 minutes`).
     * If active and Keyguard is unlocked, immediately activates `LockTaskMode` and launches `PrayerLockActivity`.
     */
    private void verifyAndEnforcePrayerLockImmediately(String triggerSource) {
        long currentTime = System.currentTimeMillis();
        PrayerFocusPrefs.ActiveFocusWindow activeWindow = PrayerFocusPrefs.getCurrentActiveWindow(this);

        if (activeWindow != null && currentTime >= activeWindow.startTimeMs && currentTime < activeWindow.endTimeMs) {
            if (PrayerDeviceAdminReceiver.isKeyguardLocked(this)) {
                return;
            }
            try {
                if (PrayerDeviceAdminReceiver.isDeviceOwner(this)) {
                    PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(this);
                }
                if (
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP &&
                    PrayerDeviceAdminReceiver.isLockTaskPermitted(this) &&
                    !PrayerDeviceAdminReceiver.isLockTaskActive(this)
                ) {
                    startLockTask();
                }
            } catch (Exception ignored) {
            }

            PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(this, activeWindow, triggerSource);
        } else {
            releaseMainActivityLockTaskIfActive();
        }
    }

    private void releaseMainActivityLockTaskIfActive() {
        try {
            if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP &&
                PrayerDeviceAdminReceiver.isLockTaskActive(this)
            ) {
                stopLockTask();
            }
        } catch (Exception ignored) {
        }
    }

    private void handleNotificationTapIntent(Intent intent) {
        if (intent == null) return;
        boolean fromTap = intent.getBooleanExtra(RifqNotificationHelper.EXTRA_FROM_NOTIFICATION_TAP, false);
        String screen = intent.getStringExtra(RifqNotificationHelper.EXTRA_NOTIF_SCREEN);
        String ward = intent.getStringExtra(RifqNotificationHelper.EXTRA_NOTIF_WARD);
        String dhikrId = intent.getStringExtra(RifqNotificationHelper.EXTRA_NOTIF_DHIKR_ID);
        String notifId = intent.getStringExtra(RifqNotificationHelper.EXTRA_NOTIF_ID);

        // Also support FCM background notification tap where extra keys "screen" or "route" are passed directly
        if (!fromTap && screen == null) {
            screen = intent.getStringExtra("screen");
            if (screen == null) {
                screen = intent.getStringExtra("route");
            }
            if (ward == null) {
                ward = intent.getStringExtra("ward");
            }
            if (dhikrId == null) {
                dhikrId = intent.getStringExtra("dhikrId");
            }
            if (screen != null && !screen.isEmpty()) {
                fromTap = true;
            }
        }

        if (fromTap) {
            RifqNotificationPrefs.setPendingNavigation(this, screen, ward, dhikrId, notifId);
            RifqNotificationsPlugin.notifyNotificationTapped(screen, ward, dhikrId, notifId);
            // Clear the flag so rotating the screen does not re-trigger navigation
            intent.removeExtra(RifqNotificationHelper.EXTRA_FROM_NOTIFICATION_TAP);
        }
    }

    /**
     * Handles incoming Android App Links (https://.../?wirdJoin=INVITE_CODE) and Custom Scheme Deep Links
     * (rifq://wird?wirdJoin=INVITE_CODE) when opened from Telegram, WhatsApp, Messenger, Chrome, etc.,
     * whether the app was closed (cold start), in the background, or already open in the foreground.
     */
    private void handleDeepLinkIntent(Intent intent) {
        if (intent == null) return;
        try {
            String inviteCode = intent.getStringExtra("wirdJoin");
            String rawUrl = "";

            Uri data = intent.getData();
            if (data != null) {
                rawUrl = data.toString();
                if (inviteCode == null || inviteCode.trim().isEmpty()) {
                    inviteCode = data.getQueryParameter("wirdJoin");
                }
                if (inviteCode == null || inviteCode.trim().isEmpty()) {
                    inviteCode = data.getQueryParameter("joinCode");
                }
                if (inviteCode == null || inviteCode.trim().isEmpty()) {
                    inviteCode = data.getQueryParameter("code");
                }
                if ((inviteCode == null || inviteCode.trim().isEmpty()) && data.getPathSegments() != null) {
                    java.util.List<String> segments = data.getPathSegments();
                    if (segments.size() >= 2) {
                        String first = segments.get(0).toLowerCase();
                        if ("wird".equals(first) || "join".equals(first)) {
                            inviteCode = segments.get(1);
                        }
                    }
                }
            }

            if (inviteCode != null) {
                String cleaned = inviteCode.replaceAll("\\s+", "").toUpperCase();
                if (!cleaned.isEmpty()) {
                    RifqNotificationPrefs.setPendingWirdInvite(this, cleaned, rawUrl);
                    RifqNotificationsPlugin.notifyWirdInviteDeepLink(cleaned, rawUrl);
                    // Clear data URI on the intent so orientation changes do not re-trigger the same deep link
                    intent.setData(null);
                    intent.removeExtra("wirdJoin");
                }
            }
        } catch (Exception ignored) {
        }
    }
}
