package com.rifq.app.prayerfocus;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Handles exact Android AlarmManager alarms for Prayer Device Lock start and end times
 * even when RIFQ is closed, the screen is off, or the device is in Doze/Sleep mode.
 *
 * Key Guarantees (Requirements 12-16):
 * 1. Exact start at adhanTimestamp (startTimeMs) and exact end at endTimestamp = adhanTimestamp + 20 minutes.
 * 2. If the phone is UNLOCKED at Adhan time: immediately activates Prayer Device Lock and enters Lock Task Mode.
 * 3. If the phone is LOCKED at Adhan time: records the active [adhanTimestamp, endTimestamp] window without
 *    breaking Android Keyguard; as soon as the user unlocks Keyguard, PrayerDeviceUnlockReceiver enforces immediately.
 * 4. At exact endTimestamp (ACTION_FOCUS_END): immediately releases Lock Task Mode and unlocks the device
 *    without waiting for RIFQ WebView, Firebase, or network.
 */
public class PrayerFocusAlarmReceiver extends BroadcastReceiver {

    public static final String ACTION_FOCUS_START = "com.rifq.app.ACTION_PRAYER_FOCUS_START";
    public static final String ACTION_FOCUS_END = "com.rifq.app.ACTION_PRAYER_FOCUS_END";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || !PrayerFocusPrefs.isEnabled(context)) {
            return;
        }

        String action = intent.getAction();
        String windowId = intent.getStringExtra("windowId");
        String prayerKey = intent.getStringExtra("prayerKey");
        if (prayerKey == null || prayerKey.isEmpty()) {
            prayerKey = "dhuhr";
        }
        String prayerNameAr = intent.getStringExtra("prayerNameAr");
        if (prayerNameAr == null || prayerNameAr.isEmpty()) {
            prayerNameAr = "الصلاة";
        }
        String todayStr = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (windowId == null || windowId.isEmpty()) {
            windowId = todayStr + "_" + prayerKey;
        }

        if (ACTION_FOCUS_START.equals(action)) {
            long nowMs = System.currentTimeMillis();
            int durationMins = PrayerFocusPrefs.getLockDurationMinutes(context);
            long startMs = intent.getLongExtra("startTimeMs", nowMs);
            // Strict rule: endTimestamp = adhanTimestamp + duration (20 minutes default)
            long endMs = intent.getLongExtra("endTimeMs", startMs + (long) durationMins * 60000L);

            if (nowMs >= endMs) {
                return;
            }

            // 1. Persist active 20-minute Prayer Device Lock window in SharedPreferences
            PrayerFocusPrefs.setActiveLockWindow(
                context,
                windowId,
                prayerKey,
                prayerNameAr,
                startMs,
                endMs
            );

            // 2. Guarantee exact end alarm is scheduled for endMs and notify PrayerDeviceLockService
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                scheduleExact(context, alarmManager, ACTION_FOCUS_END, windowId, prayerKey, prayerNameAr, startMs, endMs, 4999);
            }
            PrayerDeviceLockService.startAndScheduleAlarms(context);

            // 3. Deduplicate notification per windowId
            if (!PrayerFocusPrefs.hasAdhanFiredForWindow(context, windowId)) {
                PrayerFocusPrefs.markAdhanFiredForWindow(context, windowId);
                showFocusNotification(
                    context,
                    "حان الآن وقت صلاة " + prayerNameAr + " 🕌",
                    "بدأ وضع قفل الجهاز وقت الصلاة لمدة 20 دقيقة (" +
                        PrayerFocusPrefs.formatTimeHHMM(startMs) + " → " +
                        PrayerFocusPrefs.formatTimeHHMM(endMs) + ") للتفرغ لأداء صلاة " + prayerNameAr + ".",
                    2100
                );
            }

            // 4. Requirement 16: If the phone is currently UNLOCKED at Adhan time, enforce Prayer Device Lock immediately!
            // Requirement 15: If the phone is LOCKED at Adhan time, do not break Keyguard; PrayerDeviceUnlockReceiver
            // will enforce immediately the instant Keyguard is unlocked.
            if (!PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                PrayerFocusPrefs.ActiveFocusWindow activeWindow = new PrayerFocusPrefs.ActiveFocusWindow(
                    windowId,
                    prayerKey,
                    prayerNameAr,
                    startMs,
                    endMs
                );
                PrayerDeviceLockEnforcer.enforceImmediateDeviceLock(context, activeWindow, "ADHAN_ALARM_START");
            }
        } else if (ACTION_FOCUS_END.equals(action)) {
            // Requirement 13: Automatically release Prayer Device Lock & exit Lock Task Mode at exact endTimestamp!
            PrayerDeviceLockEnforcer.releaseDeviceLockIfActive(context);

            try {
                Intent releaseSvcIntent = new Intent(context, PrayerDeviceLockService.class);
                releaseSvcIntent.setAction(PrayerDeviceLockService.ACTION_RELEASE_EXPIRED_WINDOW);
                context.startService(releaseSvcIntent);
            } catch (Exception ignored) {
            }
            PrayerDeviceLockService.scheduleTwentyMinutePrayerAlarmsNatively(context);

            // Save pending Harvest prompt ("هل أديت صلاة ...؟") without auto-logging the prayer
            SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
            prefs.edit()
                .putString(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_KEY, prayerKey)
                .putString(PrayerFocusPrefs.KEY_PENDING_HARVEST_PRAYER_NAME, prayerNameAr)
                .putString(PrayerFocusPrefs.KEY_PENDING_HARVEST_DATE, todayStr)
                .apply();

            showFocusNotification(
                context,
                "هل أديت صلاة " + prayerNameAr + "؟ 🕌",
                "انتهى وضع قفل الجهاز وقت الصلاة وعاد الهاتف للوضع الطبيعي. افتح رِفْق لتسجيل صلاتك في حصاد العبادات.",
                2101
            );
        }
    }

    public static void scheduleUpcomingAlarms(Context context) {
        if (context == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        if (!prefs.getBoolean(PrayerFocusPrefs.KEY_ENABLED, false)) {
            return;
        }

        long now = System.currentTimeMillis();
        String windowsJson = prefs.getString(PrayerFocusPrefs.KEY_SCHEDULED_WINDOWS, "[]");
        JSONArray arr = null;
        try {
            arr = new JSONArray(windowsJson);
        } catch (Exception ignored) {
        }

        if (arr == null || arr.length() == 0) {
            arr = NativePrayerTimeCalculator.computeTodayAndTomorrowWindows(context);
        }

        try {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null || !obj.optBoolean("enabled", true)) continue;

                String winId = obj.optString("id", "");
                String pKey = obj.optString("prayerKey", "dhuhr");
                String pName = obj.optString("prayerNameAr", "الصلاة");
                long startMs = obj.optLong("startTimeMs", 0L);
                long endMs = obj.optLong("endTimeMs", 0L);

                if (startMs > now) {
                    scheduleExact(context, alarmManager, ACTION_FOCUS_START, winId, pKey, pName, startMs, endMs, 4000 + i * 2);
                }
                if (endMs > now) {
                    scheduleExact(context, alarmManager, ACTION_FOCUS_END, winId, pKey, pName, startMs, endMs, 4001 + i * 2);
                }
            }
        } catch (Exception ignored) {
        }

        // Also ensure any active manual or mid-prayer window has its exact end alarm scheduled
        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(context);
        if (active != null && active.endTimeMs > now) {
            scheduleExact(
                context,
                alarmManager,
                ACTION_FOCUS_END,
                active.windowId,
                active.prayerKey,
                active.prayerNameAr,
                active.startTimeMs,
                active.endTimeMs,
                4999
            );
        }
    }

    public static void scheduleExact(
        Context context,
        AlarmManager alarmManager,
        String action,
        String windowId,
        String prayerKey,
        String prayerNameAr,
        long startTimeMs,
        long endTimeMs,
        int requestCode
    ) {
        long triggerAtMs = ACTION_FOCUS_START.equals(action) ? startTimeMs : endTimeMs;
        Intent intent = new Intent(context, PrayerFocusAlarmReceiver.class);
        intent.setAction(action);
        intent.putExtra("windowId", windowId);
        intent.putExtra("prayerKey", prayerKey);
        intent.putExtra("prayerNameAr", prayerNameAr);
        intent.putExtra("startTimeMs", startTimeMs);
        intent.putExtra("endTimeMs", endTimeMs);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent, flags);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            }
        } catch (SecurityException se) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
        }
    }

    private void showFocusNotification(Context context, String title, String body, int notificationId) {
        com.rifq.app.notifications.RifqNotificationHelper.showSystemNotification(
            context,
            notificationId,
            com.rifq.app.notifications.RifqNotificationChannels.CHANNEL_PRAYER,
            title,
            body,
            "prayers",
            "",
            "",
            "",
            true,
            true
        );
    }
}
