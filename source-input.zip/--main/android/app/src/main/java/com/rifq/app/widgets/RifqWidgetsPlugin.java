package com.rifq.app.widgets;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;

/**
 * Capacitor Native Android Bridge for RIFQ Home Screen Widgets (`@CapacitorPlugin(name = "RifqWidgets")`).
 *
 * Exposes:
 * - `isRequestPinAppWidgetSupported()`
 * - `requestPinWidget({ type, size, theme, dhikrText, targetPrayer, statsMode })`
 * - `getInstalledWidgetsStatus()`
 * - `saveGlobalWidgetPreferences({ type, size, theme, dhikrText, targetPrayer, statsMode, applyToInstalled })`
 * - `openWidgetConfigActivity({ appWidgetId, type, size, theme, dhikrText, targetPrayer, statsMode })`
 * - `syncWidgetState(...)`
 * - `consumePendingWidgetIncrements()`
 * - `updateInstanceConfig({ appWidgetId, type, size, theme, dhikrText, targetPrayer, statsMode })`
 * - `refreshAllWidgets()`
 */
@CapacitorPlugin(name = "RifqWidgets")
public class RifqWidgetsPlugin extends Plugin {

    private static RifqWidgetsPlugin activeInstance = null;

    @Override
    public void load() {
        super.load();
        activeInstance = this;
        Context ctx = getContext();
        if (ctx != null) {
            RifqWidgetRenderer.updateAllPlacedWidgets(ctx);
            RifqBaseWidgetProvider.scheduleNextPrayerTransitionAlarm(ctx);
        }
    }

    public static void notifyNativeTasbeehIncremented(RifqWidgetPrefs.TasbeehSnapshot snap) {
        if (activeInstance == null || snap == null) return;
        try {
            JSObject data = new JSObject();
            data.put("uid", snap.uid);
            data.put("todayDateStr", snap.todayDateStr);
            data.put("todayCount", snap.todayCount);
            data.put("dailyGoal", snap.dailyGoal);
            data.put("streakDays", snap.streakDays);
            data.put("lifetimeTotal", snap.lifetimeTotal);
            data.put("activeDhikr", snap.activeDhikr);
            activeInstance.notifyListeners("rifqWidgetTasbeehIncremented", data);
        } catch (Exception ignored) {
        }
    }

    public static void notifyWidgetPinned(int appWidgetId, String widgetType) {
        if (activeInstance == null) return;
        try {
            JSObject data = new JSObject();
            data.put("appWidgetId", appWidgetId);
            data.put("type", widgetType);
            data.put("pinnedAt", System.currentTimeMillis());
            activeInstance.notifyListeners("rifqWidgetPinned", data);
        } catch (Exception ignored) {
        }
    }

    public static void notifyWidgetConfigSaved(
        int appWidgetId,
        String type,
        String size,
        String theme,
        String customDhikr,
        String targetPrayer,
        String statsMode
    ) {
        if (activeInstance == null) return;
        try {
            JSObject data = new JSObject();
            data.put("appWidgetId", appWidgetId);
            data.put("type", type);
            data.put("size", size);
            data.put("theme", theme);
            data.put("customDhikr", customDhikr);
            data.put("targetPrayer", targetPrayer);
            data.put("statsMode", statsMode);
            data.put("savedAt", System.currentTimeMillis());
            activeInstance.notifyListeners("rifqWidgetConfigSaved", data);
        } catch (Exception ignored) {
        }
    }

    private static Class<?> resolveProviderClassForType(String type) {
        if ("prayer".equalsIgnoreCase(type)) return RifqPrayerWidgetProvider.class;
        if ("dhikr".equalsIgnoreCase(type)) return RifqDhikrWidgetProvider.class;
        if ("multi".equalsIgnoreCase(type)) return RifqMultiWidgetProvider.class;
        return RifqTasbeehWidgetProvider.class;
    }

    @PluginMethod
    public void isRequestPinAppWidgetSupported(PluginCall call) {
        Context context = getContext();
        boolean supported = false;
        if (context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                AppWidgetManager manager = AppWidgetManager.getInstance(context);
                if (manager != null) {
                    supported = manager.isRequestPinAppWidgetSupported();
                }
            } catch (Exception ignored) {
            }
        }
        JSObject ret = buildInstalledWidgetsStatusObject(context);
        ret.put("supported", supported);
        call.resolve(ret);
    }

    @PluginMethod
    public void getInstalledWidgetsStatus(PluginCall call) {
        Context context = getContext();
        JSObject ret = buildInstalledWidgetsStatusObject(context);
        call.resolve(ret);
    }

    private JSObject buildInstalledWidgetsStatusObject(Context context) {
        JSObject ret = new JSObject();
        boolean pinSupported = false;
        JSArray instancesArr = new JSArray();
        int totalCount = 0;

        if (context != null) {
            try {
                RifqWidgetPrefs.WidgetInstanceConfig globalDef = RifqWidgetPrefs.getGlobalDefaultConfig(context);
                JSObject globalObj = new JSObject();
                globalObj.put("type", globalDef.type);
                globalObj.put("size", globalDef.size);
                globalObj.put("theme", globalDef.theme);
                globalObj.put("customDhikr", globalDef.customDhikr);
                globalObj.put("targetPrayer", globalDef.targetPrayer);
                globalObj.put("statsMode", globalDef.statsMode);
                ret.put("globalConfig", globalObj);

                AppWidgetManager manager = AppWidgetManager.getInstance(context);
                if (manager != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        pinSupported = manager.isRequestPinAppWidgetSupported();
                    }

                    Class<?>[] providers = new Class<?>[]{
                        RifqTasbeehWidgetProvider.class,
                        RifqPrayerWidgetProvider.class,
                        RifqDhikrWidgetProvider.class,
                        RifqMultiWidgetProvider.class
                    };
                    String[] defaultTypes = new String[]{"tasbeeh", "prayer", "dhikr", "multi"};

                    for (int p = 0; p < providers.length; p++) {
                        ComponentName cn = new ComponentName(context, providers[p]);
                        int[] ids = manager.getAppWidgetIds(cn);
                        if (ids == null) continue;
                        for (int id : ids) {
                            totalCount++;
                            RifqWidgetPrefs.WidgetInstanceConfig cfg = RifqWidgetPrefs.getWidgetConfig(
                                context,
                                id,
                                defaultTypes[p]
                            );
                            String effectiveSize = RifqWidgetRenderer.resolveEffectiveSize(manager, id, cfg.size);
                            JSObject inst = new JSObject();
                            inst.put("appWidgetId", id);
                            inst.put("providerType", defaultTypes[p]);
                            inst.put("type", cfg.type);
                            inst.put("size", cfg.size);
                            inst.put("effectiveSize", effectiveSize);
                            inst.put("theme", cfg.theme);
                            inst.put("customDhikr", cfg.customDhikr);
                            inst.put("targetPrayer", cfg.targetPrayer);
                            inst.put("statsMode", cfg.statsMode);
                            instancesArr.put(inst);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }

        ret.put("supported", pinSupported);
        ret.put("installedCount", totalCount);
        ret.put("instances", instancesArr);
        return ret;
    }

    /**
     * Persists widget preferences from the in-app 'Widget Settings' page directly into
     * Android `SharedPreferences` (`RifqWidgetPrefs`) so all `AppWidgetProvider`s read them.
     */
    @PluginMethod
    public void saveGlobalWidgetPreferences(PluginCall call) {
        Context context = getContext();
        String type = call.getString("type", "tasbeeh");
        String size = call.getString("size", "medium");
        String theme = call.getString("theme", "navy");
        String dhikrText = call.getString("dhikrText", "");
        String targetPrayer = call.getString("targetPrayer", "next");
        String statsMode = call.getString("statsMode", "today_count");
        boolean applyToInstalled = Boolean.TRUE.equals(call.getBoolean("applyToInstalled", true));

        if (context != null) {
            RifqWidgetPrefs.saveGlobalDefaultConfig(
                context,
                type,
                size,
                theme,
                dhikrText,
                targetPrayer,
                statsMode
            );

            if (applyToInstalled) {
                try {
                    AppWidgetManager manager = AppWidgetManager.getInstance(context);
                    if (manager != null) {
                        Class<?>[] providers = new Class<?>[]{
                            RifqTasbeehWidgetProvider.class,
                            RifqPrayerWidgetProvider.class,
                            RifqDhikrWidgetProvider.class,
                            RifqMultiWidgetProvider.class
                        };
                        String[] defaultTypes = new String[]{"tasbeeh", "prayer", "dhikr", "multi"};
                        for (int p = 0; p < providers.length; p++) {
                            ComponentName cn = new ComponentName(context, providers[p]);
                            int[] ids = manager.getAppWidgetIds(cn);
                            if (ids == null) continue;
                            for (int id : ids) {
                                RifqWidgetPrefs.WidgetInstanceConfig existing = RifqWidgetPrefs.getWidgetConfig(
                                    context,
                                    id,
                                    defaultTypes[p]
                                );
                                RifqWidgetPrefs.saveWidgetConfig(
                                    context,
                                    id,
                                    existing.type,
                                    size,
                                    theme,
                                    dhikrText,
                                    targetPrayer,
                                    statsMode
                                );
                            }
                        }
                    }
                } catch (Exception ignored) {
                }
            }

            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            RifqBaseWidgetProvider.scheduleNextPrayerTransitionAlarm(context);
        }

        JSObject ret = buildInstalledWidgetsStatusObject(context);
        ret.put("saved", context != null);
        call.resolve(ret);
    }

    /**
     * Launches the native Android `RifqWidgetConfigActivity` directly from the in-app 'Widget Settings' page.
     */
    @PluginMethod
    public void openWidgetConfigActivity(PluginCall call) {
        Context context = getContext();
        JSObject ret = new JSObject();
        if (context == null) {
            ret.put("opened", false);
            call.resolve(ret);
            return;
        }

        int appWidgetId = call.getInt("appWidgetId", AppWidgetManager.INVALID_APPWIDGET_ID);
        String type = call.getString("type", null);
        String size = call.getString("size", null);
        String theme = call.getString("theme", null);
        String dhikrText = call.getString("dhikrText", null);
        String targetPrayer = call.getString("targetPrayer", null);
        String statsMode = call.getString("statsMode", null);

        try {
            Intent intent = new Intent(context, RifqWidgetConfigActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(RifqWidgetConfigActivity.EXTRA_LAUNCHED_FROM_APP, true);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            if (type != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_TYPE, type);
            if (size != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_SIZE, size);
            if (theme != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_THEME, theme);
            if (dhikrText != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_DHIKR, dhikrText);
            if (targetPrayer != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_PRAYER, targetPrayer);
            if (statsMode != null) intent.putExtra(RifqWidgetConfigActivity.EXTRA_PRESELECT_STATS_MODE, statsMode);
            context.startActivity(intent);
            ret.put("opened", true);
        } catch (Exception e) {
            ret.put("opened", false);
            ret.put("error", e.getMessage());
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void requestPinWidget(PluginCall call) {
        Context context = getContext();
        String type = call.getString("type", "tasbeeh");
        String size = call.getString("size", "medium");
        String theme = call.getString("theme", "navy");
        String dhikrText = call.getString("dhikrText", "");
        String targetPrayer = call.getString("targetPrayer", "next");
        String statsMode = call.getString("statsMode", "today_count");

        JSObject ret = new JSObject();
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            ret.put("supported", false);
            ret.put("requested", false);
            ret.put("reason", "ANDROID_VERSION_BELOW_OREO");
            call.resolve(ret);
            return;
        }

        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            if (manager == null || !manager.isRequestPinAppWidgetSupported()) {
                ret.put("supported", false);
                ret.put("requested", false);
                ret.put("reason", "LAUNCHER_NOT_SUPPORTED");
                call.resolve(ret);
                return;
            }

            // Store pending configuration in SharedPreferences so when the user accepts the system Pin dialog,
            // the newly assigned appWidgetId receives these exact settings
            RifqWidgetPrefs.setPendingPinConfig(context, type, size, theme, dhikrText, targetPrayer, statsMode);

            Class<?> providerClass = resolveProviderClassForType(type);
            ComponentName providerComponent = new ComponentName(context, providerClass);

            Intent pinnedCallbackIntent = new Intent(context, providerClass);
            pinnedCallbackIntent.setAction(RifqWidgetRenderer.ACTION_WIDGET_PINNED);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                flags |= PendingIntent.FLAG_MUTABLE;
            }
            PendingIntent successCallback = PendingIntent.getBroadcast(
                context,
                (int) (System.currentTimeMillis() & 0x7FFFFFFF),
                pinnedCallbackIntent,
                flags
            );

            Bundle extras = new Bundle();
            boolean requestAccepted = manager.requestPinAppWidget(providerComponent, extras, successCallback);

            ret.put("supported", true);
            ret.put("requested", requestAccepted);
            ret.put("reason", requestAccepted ? "SYSTEM_DIALOG_SHOWN" : "LAUNCHER_REJECTED_REQUEST");
            call.resolve(ret);
        } catch (Exception e) {
            ret.put("supported", false);
            ret.put("requested", false);
            ret.put("reason", e.getMessage() != null ? e.getMessage() : "PIN_EXCEPTION");
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void syncWidgetState(PluginCall call) {
        Context context = getContext();
        if (context == null) {
            call.resolve(new JSObject().put("synced", false));
            return;
        }

        String uid = call.getString("uid", "guest");
        int todayCount = call.getInt("todayCount", 0);
        int dailyGoal = call.getInt("dailyGoal", 100);
        int streakDays = call.getInt("streakDays", 0);
        int lifetimeTotal = call.getInt("lifetimeTotal", todayCount);
        int completedAthkarToday = call.getInt("completedAthkarToday", 0);
        String activeDhikr = call.getString("activeDhikr", null);
        boolean vibrationEnabled = Boolean.TRUE.equals(call.getBoolean("vibrationEnabled", true));

        String cityNameAr = call.getString("cityNameAr", null);
        Double cityLat = call.getDouble("cityLat", null);
        Double cityLng = call.getDouble("cityLng", null);
        String calcMethod = call.getString("calcMethod", null);
        String madhab = call.getString("madhab", null);
        String timeFormat = call.getString("timeFormat", null);
        Integer hijriAdjustment = call.getInt("hijriAdjustment", null);
        String manualOffsetsJson = call.getString("manualOffsetsJson", null);
        String customAthkarJson = call.getString("customAthkarJson", null);

        RifqWidgetPrefs.syncStateFromApp(
            context,
            uid,
            todayCount,
            dailyGoal,
            streakDays,
            lifetimeTotal,
            completedAthkarToday,
            activeDhikr,
            vibrationEnabled,
            cityNameAr,
            cityLat,
            cityLng,
            calcMethod,
            madhab,
            timeFormat,
            hijriAdjustment,
            manualOffsetsJson,
            customAthkarJson
        );

        RifqWidgetRenderer.updateAllPlacedWidgets(context);
        RifqBaseWidgetProvider.scheduleNextPrayerTransitionAlarm(context);

        JSObject ret = buildInstalledWidgetsStatusObject(context);
        ret.put("synced", true);
        call.resolve(ret);
    }

    @PluginMethod
    public void consumePendingWidgetIncrements(PluginCall call) {
        Context context = getContext();
        JSObject ret = new JSObject();
        if (context == null) {
            ret.put("pendingDeltaCount", 0);
            call.resolve(ret);
            return;
        }
        JSONObject consumed = RifqWidgetPrefs.consumePendingIncrementsAtomically(context);
        try {
            ret.put("pendingDeltaCount", consumed.optInt("pendingDeltaCount", 0));
            ret.put("dhikrDeltasJson", consumed.optJSONObject("dhikrDeltas") != null
                ? consumed.optJSONObject("dhikrDeltas").toString()
                : "{}");
            ret.put("dateStr", consumed.optString("dateStr", ""));
            ret.put("uid", consumed.optString("uid", "guest"));
            ret.put("lastNativeMutationAt", consumed.optLong("lastNativeMutationAt", 0L));
            ret.put("todayTotalCount", consumed.optInt("todayTotalCount", 0));
        } catch (Exception ignored) {
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void updateInstanceConfig(PluginCall call) {
        Context context = getContext();
        int appWidgetId = call.getInt("appWidgetId", 0);
        String type = call.getString("type", null);
        String size = call.getString("size", null);
        String theme = call.getString("theme", null);
        String dhikrText = call.getString("dhikrText", null);
        String targetPrayer = call.getString("targetPrayer", null);
        String statsMode = call.getString("statsMode", null);

        if (context != null && appWidgetId != 0) {
            RifqWidgetPrefs.saveWidgetConfig(
                context,
                appWidgetId,
                type,
                size,
                theme,
                dhikrText,
                targetPrayer,
                statsMode
            );
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
        }

        JSObject ret = buildInstalledWidgetsStatusObject(context);
        ret.put("updated", appWidgetId != 0);
        call.resolve(ret);
    }

    @PluginMethod
    public void refreshAllWidgets(PluginCall call) {
        Context context = getContext();
        if (context != null) {
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            RifqBaseWidgetProvider.scheduleNextPrayerTransitionAlarm(context);
        }
        JSObject ret = buildInstalledWidgetsStatusObject(context);
        ret.put("refreshed", true);
        call.resolve(ret);
    }
}
