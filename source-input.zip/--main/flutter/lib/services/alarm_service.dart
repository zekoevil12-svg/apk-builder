import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:vibration/vibration.dart';
import 'alarm_database_helper.dart';

class AlarmService {
  static final AlarmService _instance = AlarmService._internal();
  factory AlarmService() => _instance;
  AlarmService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _gradualVolumeTimer;
  bool _isPlaying = false;

  bool get isPlaying => _isPlaying;

  Future<void> init() async {
    tz.initializeTimeZones();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) {
        // Handled when user taps the alarm notification
      },
    );
  }

  // ── تشغيل صوت المنبه مع اهتزاز وخاصية الصوت التدريجي ──
  Future<void> triggerAlarmAudio({
    required String soundType,
    bool gradualVolume = false,
  }) async {
    _isPlaying = true;
    _gradualVolumeTimer?.cancel();

    // تشغيل الاهتزاز إذا كان مدعوماً
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(pattern: [500, 1000, 500, 1000], repeat: 0);
    }

    try {
      if (gradualVolume) {
        await _audioPlayer.setVolume(0.0);
        double volume = 0.0;
        _gradualVolumeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
          if (volume < 1.0) {
            volume += 0.033; // يصل إلى 100% خلال 30 ثانية
            if (volume > 1.0) volume = 1.0;
            _audioPlayer.setVolume(volume);
          } else {
            timer.cancel();
          }
        });
      } else {
        await _audioPlayer.setVolume(1.0);
      }

      await _audioPlayer.setReleaseMode(ReleaseMode.loop);
      
      // تشغيل الصوت المختار
      if (soundType == 'adhan_fajr') {
        await _audioPlayer.play(AssetSource('audio/adhan_fajr.mp3'));
      } else {
        await _audioPlayer.play(AssetSource('audio/gentle_alert.mp3'));
      }
    } catch (e) {
      // Fallback: If audio file not found, vibration and system tone will work
      debugPrint('Audio playback error (fallback to system tone): $e');
    }
  }

  // ── إيقاف المنبه والاهتزاز والصوت ──
  Future<void> stopAlarm() async {
    _isPlaying = false;
    _gradualVolumeTimer?.cancel();
    try {
      await _audioPlayer.stop();
    } catch (_) {}
    try {
      await Vibration.cancel();
    } catch (_) {}
  }

  // ── جدولة منبه ذكي في وقت محدد ──
  Future<void> scheduleSmartAlarm({
    required int id,
    required int hour,
    required int minute,
    required String challengeType,
    required String difficulty,
    required String sound,
  }) async {
    final now = DateTime.now();
    var scheduledDate = DateTime(now.year, now.month, now.day, hour, minute);
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    final tzDateTime = tz.TZDateTime.from(scheduledDate, tz.local);

    const androidDetails = AndroidNotificationDetails(
      'rifq_smart_alarm',
      'المنبّه الذكي بتحديات',
      channelDescription: 'منبه ذكي يستوجب حل تحدي للاستيقاظ',
      importance: Importance.max,
      priority: Priority.high,
      fullScreenIntent: true,
      playSound: true,
      enableVibration: true,
    );

    const details = NotificationDetails(android: androidDetails);

    await _notificationsPlugin.zonedSchedule(
      id,
      '⏰ استيقظ! حان وقت صلاة الفجر والذكر',
      'اضغط لإيقاف المنبه عبر إكمال تحدي $challengeType',
      tzDateTime,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  // ── جدولة منبه الفجر الفلكي بناءً على إحداثيات الموقع ──
  Future<DateTime?> scheduleFajrAlarm({
    required int minutesBefore,
    required String sound,
    required bool gradualVolume,
  }) async {
    try {
      // 1. جلب إحداثيات الموقع (القاهرة / الموقع الحالي)
      double lat = 30.0444; // القاهرة افتراضياً
      double lng = 31.2357;

      try {
        final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium,
          timeLimit: const Duration(seconds: 3),
        );
        lat = position.latitude;
        lng = position.longitude;
      } catch (_) {
        // استخدام الإحداثيات الافتراضية عند عدم توفر GPS
      }

      final coordinates = Coordinates(lat, lng);
      final params = CalculationMethod.egyptian.getParameters();
      params.madhab = Madhab.shafi;

      final prayerTimes = PrayerTimes(
        coordinates,
        DateComponents.from(DateTime.now()),
        params,
      );

      DateTime fajrTime = prayerTimes.fajr;
      final now = DateTime.now();

      // إذا انقضى وقت فجر اليوم، يتم الحساب لليوم التالي
      if (fajrTime.isBefore(now)) {
        final tomorrow = now.add(const Duration(days: 1));
        final nextDayPrayers = PrayerTimes(
          coordinates,
          DateComponents.from(tomorrow),
          params,
        );
        fajrTime = nextDayPrayers.fajr;
      }

      final reminderTime = fajrTime.subtract(Duration(minutes: minutesBefore));
      final tzDateTime = tz.TZDateTime.from(reminderTime, tz.local);

      const androidDetails = AndroidNotificationDetails(
        'fajr_channel',
        'منبّه الفجر',
        channelDescription: 'تنبيه موعد صلاة الفجر الحقيقي',
        importance: Importance.max,
        priority: Priority.high,
        fullScreenIntent: true,
        playSound: true,
        enableVibration: true,
      );

      const details = NotificationDetails(android: androidDetails);

      await _notificationsPlugin.zonedSchedule(
        1001, // المعرف الثابت لمنبه الفجر
        '🌅 تذكير صلاة الفجر',
        'باقي $minutesBefore دقيقة على أذان الفجر، استعد للصلاة',
        tzDateTime,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );

      return reminderTime;
    } catch (e) {
      debugPrint('Error scheduling Fajr alarm: $e');
      return null;
    }
  }

  // ── جدولة تذكير قبل النوم مع محتوى متغير وموثق ──
  Future<void> scheduleSleepReminder({
    required int hour,
    required int minute,
    required String contentType,
    required String sound,
  }) async {
    final now = DateTime.now();
    var scheduledDate = DateTime(now.year, now.month, now.day, hour, minute);
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    final tzDateTime = tz.TZDateTime.from(scheduledDate, tz.local);

    final content = getDailySleepContent(contentType);

    const androidDetails = AndroidNotificationDetails(
      'sleep_channel',
      'تذكير النوم',
      channelDescription: 'تذكير أذكار وأدعية النوم النبوية',
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
    );

    const details = NotificationDetails(android: androidDetails);

    await _notificationsPlugin.zonedSchedule(
      2001, // المعرف الثابت لتذكير النوم
      '🛏️ تذكير قبل النوم • رِفْق',
      content,
      tzDateTime,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  // ── الحصول على محتوى يومي متغير موثق ──
  String getDailySleepContent(String type) {
    final dayIndex = DateTime.now().day;

    final athkarList = [
      '«بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا» — صحيح البخاري 6324',
      '«اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ» — سنن أبي داود 5045',
      '«سُبْحَانَ اللَّهِ (33) وَالْحَمْدُ لِلَّهِ (33) وَاللَّهُ أَكْبَرُ (34)» — صحيح البخاري 6318',
      '«اللَّهُمَّ أَسْلَمْتُ نَفْسِي إِلَيْكَ، وَفَوَّضْتُ أَمْرِي إِلَيْكَ» — صحيح البخاري 247',
      '«اقرأ آيَةَ الْكُرْسِيِّ قبل نومك لن يزال عليك من الله حافظ» — صحيح البخاري 2311',
    ];

    final duaList = [
      '«اللَّهُمَّ بِاسْمِكَ أَحْيَا وَأَمُوتُ»',
      '«اللَّهُمَّ إِنِّي أَسْلَمْتُ نَفْسِي إِلَيْكَ وَوَجَّهْتُ وَجْهِي إِلَيْكَ»',
      '«اللَّهُمَّ أَعُوذُ بِكَلِمَاتِكَ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ»',
      '«رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ»',
    ];

    final tipsList = [
      'توجيه نبوي: نم على طهارة وتوضأ وضوءك للصلاة.',
      'سنة نبوية: انفض فراشك ثلاثاً قبل النوم واذكر اسم الله.',
      'نصيحة إيمانية: سبّح 33 واحمد 33 وكبّر 34 قبل أن تغمض عينيك.',
      'نصيحة القلب: لا تنم وفي قلبك غِل أو شحناء على أحد من المسلمين.',
    ];

    final quranList = [
      '﴿وَهُوَ الَّذِي يَتَوَفَّاكُم بِاللَّيْلِ وَيَعْلَمُ مَا جَرَحْتُم بِالنَّهَارِ﴾ — الأنعام: 60',
      '﴿اللَّهُ يَتَوَفَّى الْأَنفُسَ حِينَ مَوْتِهَا وَالَّتِي لَمْ تَمُتْ فِي مَنَامِهَا﴾ — الزمر: 42',
      '﴿قُلْ بِفَضْلِ اللَّهِ وَبِرَحْمَتِهِ فَبِذَٰلِكَ فَلْيَفْرَحُوا﴾ — يونس: 58',
      '﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾ — الرعد: 28',
    ];

    if (type == 'dua') {
      return duaList[dayIndex % duaList.length];
    } else if (type == 'tip') {
      return tipsList[dayIndex % tipsList.length];
    } else if (type == 'quran') {
      return quranList[dayIndex % quranList.length];
    } else if (type == 'random') {
      final all = [...athkarList, ...duaList, ...tipsList, ...quranList];
      return all[dayIndex % all.length];
    }

    return athkarList[dayIndex % athkarList.length];
  }

  // ── إلغاء منبه ──
  Future<void> cancelAlarm(int id) async {
    await _notificationsPlugin.cancel(id);
  }
}
