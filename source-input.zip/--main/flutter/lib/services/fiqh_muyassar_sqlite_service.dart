import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

class FiqhCategoryModel {
  final String id;
  final String name;
  final String subtitle;
  final String description;
  final List<String> subtopics;
  final int orderNumber;

  const FiqhCategoryModel({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.description,
    required this.subtopics,
    required this.orderNumber,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'subtitle': subtitle,
        'description': description,
        'subtopics_json': jsonEncode(subtopics),
        'order_number': orderNumber,
      };

  factory FiqhCategoryModel.fromMap(Map<String, dynamic> map) {
    final List<dynamic> decoded =
        jsonDecode((map['subtopics_json'] as String?) ?? '[]');
    return FiqhCategoryModel(
      id: map['id'] as String,
      name: map['name'] as String,
      subtitle: map['subtitle'] as String,
      description: map['description'] as String,
      subtopics: decoded.map((e) => e.toString()).toList(),
      orderNumber: map['order_number'] as int,
    );
  }
}

class FiqhTopicModel {
  final String id;
  final String categoryId;
  final String subtopic;
  final String title;
  final String rulingBadge;
  final String summary;
  final String definitionAndExplanation;
  final List<String> conditionsAndPillars;
  final String quranAyah;
  final String quranSurah;
  final String sunnahHadith;
  final String sunnahSource;
  final List<String> importantMasail;
  final String fiqhReference;
  final int orderNumber;
  final bool isFavorite;

  const FiqhTopicModel({
    required this.id,
    required this.categoryId,
    required this.subtopic,
    required this.title,
    required this.rulingBadge,
    required this.summary,
    required this.definitionAndExplanation,
    required this.conditionsAndPillars,
    required this.quranAyah,
    required this.quranSurah,
    required this.sunnahHadith,
    required this.sunnahSource,
    required this.importantMasail,
    required this.fiqhReference,
    required this.orderNumber,
    this.isFavorite = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'category_id': categoryId,
        'subtopic': subtopic,
        'title': title,
        'ruling_badge': rulingBadge,
        'summary': summary,
        'definition_and_explanation': definitionAndExplanation,
        'conditions_and_pillars_json': jsonEncode(conditionsAndPillars),
        'quran_ayah': quranAyah,
        'quran_surah': quranSurah,
        'sunnah_hadith': sunnahHadith,
        'sunnah_source': sunnahSource,
        'important_masail_json': jsonEncode(importantMasail),
        'fiqh_reference': fiqhReference,
        'order_number': orderNumber,
        'is_favorite': isFavorite ? 1 : 0,
      };

  factory FiqhTopicModel.fromMap(Map<String, dynamic> map) {
    final List<dynamic> conds =
        jsonDecode((map['conditions_and_pillars_json'] as String?) ?? '[]');
    final List<dynamic> masail =
        jsonDecode((map['important_masail_json'] as String?) ?? '[]');
    return FiqhTopicModel(
      id: map['id'] as String,
      categoryId: map['category_id'] as String,
      subtopic: map['subtopic'] as String,
      title: map['title'] as String,
      rulingBadge: map['ruling_badge'] as String,
      summary: map['summary'] as String,
      definitionAndExplanation: map['definition_and_explanation'] as String,
      conditionsAndPillars: conds.map((e) => e.toString()).toList(),
      quranAyah: (map['quran_ayah'] as String?) ?? '',
      quranSurah: (map['quran_surah'] as String?) ?? '',
      sunnahHadith: map['sunnah_hadith'] as String,
      sunnahSource: map['sunnah_source'] as String,
      importantMasail: masail.map((e) => e.toString()).toList(),
      fiqhReference: map['fiqh_reference'] as String,
      orderNumber: map['order_number'] as int,
      isFavorite: (map['is_favorite'] as int? ?? 0) == 1,
    );
  }
}

class FiqhMuyassarSqliteService {
  FiqhMuyassarSqliteService._();
  static final FiqhMuyassarSqliteService instance =
      FiqhMuyassarSqliteService._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'rifq_fiqh_muyassar_v1.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE fiqh_categories (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            description TEXT NOT NULL,
            subtopics_json TEXT NOT NULL,
            order_number INTEGER NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE fiqh_topics (
            id TEXT PRIMARY KEY,
            category_id TEXT NOT NULL,
            subtopic TEXT NOT NULL,
            title TEXT NOT NULL,
            ruling_badge TEXT NOT NULL,
            summary TEXT NOT NULL,
            definition_and_explanation TEXT NOT NULL,
            conditions_and_pillars_json TEXT NOT NULL,
            quran_ayah TEXT NOT NULL,
            quran_surah TEXT NOT NULL,
            sunnah_hadith TEXT NOT NULL,
            sunnah_source TEXT NOT NULL,
            important_masail_json TEXT NOT NULL,
            fiqh_reference TEXT NOT NULL,
            order_number INTEGER NOT NULL,
            is_favorite INTEGER NOT NULL DEFAULT 0
          )
        ''');

        await db.execute('''
          CREATE TABLE fiqh_favorites (
            id TEXT PRIMARY KEY,
            topic_id TEXT NOT NULL UNIQUE,
            added_at TEXT NOT NULL
          )
        ''');

        final batch = db.batch();
        for (final cat in _initialCategories) {
          batch.insert('fiqh_categories', cat.toMap());
        }
        for (final topic in _initialTopics) {
          batch.insert('fiqh_topics', topic.toMap());
        }
        await batch.commit(noResult: true);
      },
    );
    return _db!;
  }

  Future<List<FiqhCategoryModel>> getCategories() async {
    final db = await database;
    final rows = await db.query('fiqh_categories', orderBy: 'order_number ASC');
    return rows.map(FiqhCategoryModel.fromMap).toList();
  }

  Future<List<FiqhTopicModel>> getAllTopics() async {
    final db = await database;
    final rows = await db.query('fiqh_topics', orderBy: 'order_number ASC');
    return rows.map(FiqhTopicModel.fromMap).toList();
  }

  Future<Set<String>> getFavoriteIds() async {
    final db = await database;
    final rows = await db.query('fiqh_favorites');
    return rows.map((r) => r['topic_id'] as String).toSet();
  }

  Future<bool> toggleFavorite(String topicId) async {
    final db = await database;
    final existing = await db.query(
      'fiqh_favorites',
      where: 'topic_id = ?',
      whereArgs: [topicId],
    );
    bool isFav = false;
    if (existing.isNotEmpty) {
      await db.delete(
        'fiqh_favorites',
        where: 'topic_id = ?',
        whereArgs: [topicId],
      );
      isFav = false;
    } else {
      await db.insert('fiqh_favorites', {
        'id': 'fav_${DateTime.now().millisecondsSinceEpoch}',
        'topic_id': topicId,
        'added_at': DateTime.now().toIso8601String(),
      });
      isFav = true;
    }
    await db.update(
      'fiqh_topics',
      {'is_favorite': isFav ? 1 : 0},
      where: 'id = ?',
      whereArgs: [topicId],
    );
    return isFav;
  }

  static const List<FiqhCategoryModel> _initialCategories = [
    FiqhCategoryModel(
      id: 'tahara',
      name: 'الطهارة',
      subtitle: 'مفتاح الصلاة وأحكام المياه والوضوء والغسل والتيمم',
      description: 'بيان أقسام المياه، وفروض الوضوء وسننه ونواقضه، وموجبات الغسل، وأحكام التيمم.',
      subtopics: ['الوضوء', 'الغسل', 'التيمم', 'نواقض الوضوء', 'أحكام المياه'],
      orderNumber: 1,
    ),
    FiqhCategoryModel(
      id: 'salah',
      name: 'الصلاة',
      subtitle: 'شروط الصلاة وأركانها وواجباتها وسننها والجماعة والجمعة',
      description: 'أحكام الصلوات الخمس، شروط صحتها، أركانها وواجباتها وسننها، وأحكام الجماعة والجمعة وأهل الأعذار.',
      subtopics: [
        'شروط الصلاة',
        'أركان الصلاة',
        'واجبات الصلاة',
        'سنن الصلاة',
        'الصلوات الخمس',
        'صلاة الجماعة',
        'صلاة الجمعة',
        'صلاة المسافر',
        'صلاة المريض',
        'صلاة الخوف',
      ],
      orderNumber: 2,
    ),
    FiqhCategoryModel(
      id: 'zakah',
      name: 'الزكاة',
      subtitle: 'شروط وجوبها وأنصبة النقود والذهب والفضة والتجارة والزروع والأنعام',
      description: 'أحكام الركن الثالث من أركان الإسلام، شروط وجوب الزكاة، مقادير الأنصبة، ومصارف الزكاة الثمانية.',
      subtopics: [
        'شروط وجوب الزكاة',
        'زكاة النقود',
        'زكاة الذهب والفضة',
        'زكاة التجارة',
        'زكاة الزروع',
        'زكاة الأنعام',
        'مصارف الزكاة',
      ],
      orderNumber: 3,
    ),
    FiqhCategoryModel(
      id: 'siyam',
      name: 'الصيام',
      subtitle: 'أحكام صيام رمضان، شروطه، مبطلاته، القضاء، التطوع، والاعتكاف',
      description: 'شروط وجوب الصيام وصحته، المفطرات، أحكام القضاء والفدية، وصيام التطوع والاعتكاف.',
      subtopics: ['شروط الصيام', 'مبطلات الصيام', 'صيام رمضان', 'قضاء الصيام', 'صيام التطوع', 'الاعتكاف'],
      orderNumber: 4,
    ),
    FiqhCategoryModel(
      id: 'hajj',
      name: 'الحج والعمرة',
      subtitle: 'شروط الحج ومناسك الحج والعمرة والإحرام والطواف والسعي وعرفة',
      description: 'أحكام المناسك العظام من الإحرام والمواقيت، والوقوف بعرفة، والطواف، والسعي بين الصفا والمروة.',
      subtopics: ['شروط الحج', 'مناسك الحج', 'مناسك العمرة', 'الإحرام', 'الطواف', 'السعي', 'الوقوف بعرفة'],
      orderNumber: 5,
    ),
    FiqhCategoryModel(
      id: 'nikah',
      name: 'النكاح',
      subtitle: 'أحكام الزواج والخطبة وعقد النكاح وحقوق الزوجين والطلاق والعدة',
      description: 'فقه الأسرة في الإسلام: الخطبة، شروط عقد النكاح وأركانه، الحقوق الزوجية، وأحكام الطلاق والعدة.',
      subtopics: ['أحكام الزواج', 'الخطبة', 'عقد النكاح', 'حقوق الزوجين', 'الطلاق', 'العدة'],
      orderNumber: 6,
    ),
    FiqhCategoryModel(
      id: 'muamalat',
      name: 'المعاملات',
      subtitle: 'أحكام البيع والربا والقرض والرهن والإجارة والمضاربة',
      description: 'ضوابط الكسب الحلال، شروط صحة البيع، صور الربا المحرمة، وأحكام التوثيقات والشركات.',
      subtopics: ['البيع', 'الربا', 'القرض', 'الرهن', 'الإجارة', 'المضاربة'],
      orderNumber: 7,
    ),
    FiqhCategoryModel(
      id: 'atima',
      name: 'الأطعمة والأشربة',
      subtitle: 'أحكام الحلال والحرام، الذبح، الأطعمة المحرمة، الأشربة، وآداب الطعام',
      description: 'الأصل في الأطعمة والأشربة، ضوابط التذكية الشرعية، الأعيان المحرمة، والهدي النبوي في الطعام.',
      subtopics: ['الحلال والحرام', 'الذبح', 'الأطعمة المحرمة', 'الأشربة', 'آداب الطعام'],
      orderNumber: 8,
    ),
  ];

  static const List<FiqhTopicModel> _initialTopics = [
    FiqhTopicModel(
      id: 'tahara-1',
      categoryId: 'tahara',
      subtopic: 'أحكام المياه',
      title: 'أقسام المياه وأحكام الماء الطهور والنجس',
      rulingBadge: 'ركن / شرط',
      summary: 'الماء الطهور هو الباقي على خلقته، وهو طاهر في نفسه مطهر لغيره يرفع الحدث ويزيل الخبث.',
      definitionAndExplanation: 'الطهارة لغة: النظافة والنزاهة، واصطلاحاً: رفع الحدث وزوال الخبث بالماء الطهور الباقي على أصل خلقته.',
      conditionsAndPillars: [
        'الماء الطهور طاهر في نفسه مطهر لغيره يرفع الحدث الأصغر والأكبر.',
        'الماء المتغير بالنجاسة في لونه أو طعمه أو ريحه نجس يحرم استعماله بالإجماع.',
        'ماء البحر طهور وميتته حلال بنص الحديث الصحيح.',
      ],
      quranAyah: '﴿وَأَنزَلْنَا مِنَ السَّمَاءِ مَاءً طَهُورًا﴾',
      quranSurah: 'سورة الفرقان: آية 48',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ فِي البَحْرِ: «هُوَ الطَّهُورُ مَاؤُهُ، الحِلُّ مَيْتَتُهُ»',
      sunnahSource: 'رواه أبو داود (83) والترمذي (69) وصححه',
      importantMasail: [
        'الأصل في المياه الطهارة ولا ينتقل عنها بالشك.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الطهارة (ص 15-19)',
      orderNumber: 1,
    ),
    FiqhTopicModel(
      id: 'tahara-2',
      categoryId: 'tahara',
      subtopic: 'الوضوء',
      title: 'فروض الوضوء وشروط صحته وسننه',
      rulingBadge: 'واجب / فرض',
      summary: 'فروض الوضوء ستة: غسل الوجه ومنه المضمضة والاستنشاق، وغسل اليدين للمرفقين، ومسح الرأس ومنه الأذنان، وغسل الرجلين للكعبين، والترتيب، والموالاة.',
      definitionAndExplanation: 'الوضوء شرط لصحة الصلاة لا تقبل بغيره مع القدرة، وتسبقه النية بالقلب والتسمية.',
      conditionsAndPillars: [
        'غسل الوجه كاملاً مع المضمضة والاستنشاق.',
        'غسل اليدين مع المرفقين.',
        'مسح جميع الرأس مع الأذنين.',
        'غسل الرجلين مع الكعبين، والترتيب، والموالاة.',
      ],
      quranAyah: '﴿يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا قُمْتُمْ إِلَى الصَّلَاةِ فَاغْسِلُوا وُجُوهَكُمْ وَأَيْدِيَكُمْ إِلَى الْمَرَافِقِ وَامْسَحُوا بِرُءُوسِكُمْ وَأَرْجُلَكُمْ إِلَى الْكَعْبَيْنِ﴾',
      quranSurah: 'سورة المائدة: آية 6',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «لَا تُقْبَلُ صَلَاةُ مَنْ أَحْدَثَ حَتَّى يَتَوَضَّأَ»',
      sunnahSource: 'متفق عليه: البخاري (135)، ومسلم (225)',
      importantMasail: [
        'تثليث الغسل سنة والفرض مرة واحدة سابغة.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - باب الوضوء (ص 26-32)',
      orderNumber: 2,
    ),
    FiqhTopicModel(
      id: 'salah-1',
      categoryId: 'salah',
      subtopic: 'شروط الصلاة',
      title: 'شروط صحة الصلاة التسعة وأركانها الأربعة عشر',
      rulingBadge: 'ركن / شرط',
      summary: 'شروط الصلاة تسعة: الإسلام، والعقل، والتمييز، ورفع الحدث، وإزالة النجاسة، وستر العورة، ودخول الوقت، واستقبال القبلة، والنية.',
      definitionAndExplanation: 'الصلاة عمود الإسلام، ولا تصح إلا بتحقق شروطها التسعة قبل تكبيرة الإحرام والإتيان بأركانها الأربعة عشر بطمأنينة.',
      conditionsAndPillars: [
        'الإسلام والعقل والتمييز ورفع الحدث وإزالة النجاسة وستر العورة.',
        'دخول الوقت، واستقبال القبلة، والنية بالقلب.',
        'أركانها: القيام، تكبيرة الإحرام، الفاتحة، الركوع، الرفع منه، السجود على الأعضاء السبعة، الجلوس بين السجدتين، الطمأنينة، التشهد الأخير والجلوس له، الصلاة على النبي ﷺ، التسليمتان، والترتيب.',
      ],
      quranAyah: '﴿إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَّوْقُوتًا﴾',
      quranSurah: 'سورة النساء: آية 103',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «مِفْتَاحُ الصَّلَاةِ الطُّهُورُ، وَتَحْرِيمُهَا التَّكْبِيرُ، وَتَحْلِيلُهَا التَّسْلِيمُ»',
      sunnahSource: 'رواه أبو داود (61) والترمذي (3)',
      importantMasail: [
        'الركن لا يسقط عمداً ولا سهواً، والواجب يسقط بالسهو ويجبر بسجود السهو.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الصلاة (ص 75-85)',
      orderNumber: 3,
    ),
    FiqhTopicModel(
      id: 'zakah-1',
      categoryId: 'zakah',
      subtopic: 'شروط وجوب الزكاة',
      title: 'شروط وجوب الزكاة وأنصبة الذهب والفضة والنقود والمصارف الثمانية',
      rulingBadge: 'واجب / فرض',
      summary: 'نصاب الذهب 85 جراماً، ونصاب الفضة 595 جراماً، والواجب ربع العشر (2.5%) بعد تمام الحول، وتصرف في الأصناف الثمانية.',
      definitionAndExplanation: 'الزكاة الركن الثالث من أركان الإسلام، تجب في الذهب والفضة والنقود وعروض التجارة والزروع والأنعام السائمة.',
      conditionsAndPillars: [
        'الإسلام، والحرية، وملك النصاب ملكاً تاماً، ومضي الحول في غير الزروع والثمار.',
        'نصاب الزروع 5 أوسق (612 كجم) وفيها العشر بلا كلفة أو نصف العشر بكلفة.',
        'المصارف الثمانية: الفقراء، والمساكين، والعاملين عليها، والمؤلفة قلوبهم، وفي الرقاب، والغارمين، وفي سبيل الله، وابن السبيل.',
      ],
      quranAyah: '﴿إِنَّمَا الصَّدَقَاتُ لِلْفُقَرَاءِ وَالْمَسَاكِينِ وَالْعَامِلِينَ عَلَيْهَا وَالْمُؤَلَّفَةِ قُلُوبُهُمْ وَفِي الرِّقَابِ وَالْغَارِمِينَ وَفِي سَبِيلِ اللَّهِ وَابْنِ السَّبِيلِ﴾',
      quranSurah: 'سورة التوبة: آية 60',
      sunnahHadith: 'قَالَ النَّبِيُّ ﷺ لِمُعَاذٍ: «فَأَعْلِمْهُمْ أَنَّ اللَّهَ قَدِ افْتَرَضَ عَلَيْهِمْ صَدَقَةً فِي أَمْوَالِهِمْ تُؤْخَذُ مِنْ أَغْنِيَائِهِمْ وَتُرَدُّ عَلَى فُقَرَائِهِمْ»',
      sunnahSource: 'متفق عليه: البخاري (1395)، ومسلم (19)',
      importantMasail: [
        'عروض التجارة تُقوّم عند تمام الحول بسعر السوق ويخرج منها ربع العشر (2.5%).',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الزكاة (ص 129-147)',
      orderNumber: 4,
    ),
    FiqhTopicModel(
      id: 'siyam-1',
      categoryId: 'siyam',
      subtopic: 'صيام رمضان',
      title: 'أحكام صيام رمضان وشروطه ومبطلاته والقضاء والاعتكاف',
      rulingBadge: 'واجب / فرض',
      summary: 'الصيام هو التعبد لله بالإمساك عن المفطرات من طلوع الفجر الصادق إلى غروب الشمس مع تبييت النية في الفرض.',
      definitionAndExplanation: 'صيام رمضان أحد أركان الإسلام، ويثبت برؤية الهلال أو إكمال شعبان ثلاثين يوماً.',
      conditionsAndPillars: [
        'الإسلام، والعقل، والبلوغ، والقدرة، والإقامة، والخلو من الحيض والنفاس.',
        'لا يفطر الصائم بالمفطرات إلا إذا كان عالماً ذاكراً مختاراً.',
        'الاعتكاف سنة مؤكدة في المسجد لا سيما في العشر الأواخر من رمضان.',
      ],
      quranAyah: '﴿فَمَن شَهِدَ مِنكُمُ الشَّهْرَ فَلْيَصُمْهُ﴾',
      quranSurah: 'سورة البقرة: آية 185',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «مَنْ صَامَ رَمَضَانَ إِيمَانًا وَاحْتِسَابًا غُفِرَ لَهُ مَا تَقَدَّمَ مِنْ ذَنْبِهِ»',
      sunnahSource: 'متفق عليه: البخاري (38)، ومسلم (760)',
      importantMasail: [
        'من أكل أو شرب ناسياً فليتم صومه فإنما أطعمه الله وسقاه.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الصيام (ص 149-167)',
      orderNumber: 5,
    ),
    FiqhTopicModel(
      id: 'hajj-1',
      categoryId: 'hajj',
      subtopic: 'مناسك الحج',
      title: 'شروط الحج وأركانه الأربعة وواجباته ومناسك العمرة',
      rulingBadge: 'واجب / فرض',
      summary: 'أركان الحج أربعة: الإحرام، والوقوف بعرفة، وطواف الإفاضة، والسعي بين الصفا والمروة.',
      definitionAndExplanation: 'يجب الحج مرة واحدة في العمر على المستطيع، وأركان العمرة ثلاثة: الإحرام والطواف والسعي.',
      conditionsAndPillars: [
        'شروط الوجوب: الإسلام، والعقل، والبلوغ، والحرية، والاستطاعة المالية والبدنية، والمحرم للمرأة.',
        'الوقوف بعرفة هو ركن الحج الأعظم من زوال يوم التاسع إلى فجر يوم النحر.',
      ],
      quranAyah: '﴿وَلِلَّهِ عَلَى النَّاسِ حِجُّ الْبَيْتِ مَنِ اسْتَطَاعَ إِلَيْهِ سَبِيلًا﴾',
      quranSurah: 'سورة آل عمران: آية 97',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «الحَجُّ عَرَفَةُ، فَمَنْ جَاءَ قَبْلَ صَلَاةِ الفَجْرِ مِنْ لَيْلَةِ جَمْعٍ فَقَدْ تَمَّ حَجُّهُ»',
      sunnahSource: 'رواه أبو داود (1949) والترمذي (889) وصححه',
      importantMasail: [
        'العمرة إلى العمرة كفارة لما بينهما، والحج المبرور ليس له جزاء إلا الجنة.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الحج (ص 169-193)',
      orderNumber: 6,
    ),
    FiqhTopicModel(
      id: 'nikah-1',
      categoryId: 'nikah',
      subtopic: 'عقد النكاح',
      title: 'أحكام الخطبة وأركان عقد النكاح وحقوق الزوجين والطلاق والعدة',
      rulingBadge: 'سنة مؤكدة',
      summary: 'يشترط لصحة النكاح تعيين الزوجين ورضاهما والولي والشاهدان، مع وجوب المهر والعشرة بالمعروف.',
      definitionAndExplanation: 'شرع الله الزواج لتحقيق السكن والمودة والرحمة، وجعل لكل من الزوجين حقوقاً وواجبات بالمعروف.',
      conditionsAndPillars: [
        'الإيجاب والقبول، والولي للمرأة، وشاهدا عدل، ورضا الزوجين.',
        'الطلاق السني طلقة واحدة في طهر لم يجامعها فيه، وعدة الحامل بوضع الحمل والمتوفى عنها أربعة أشهر وعشراً.',
      ],
      quranAyah: '﴿وَعَاشِرُوهُنَّ بِالْمَعْرُوفِ﴾',
      quranSurah: 'سورة النساء: آية 19',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «لَا نِكَاحَ إِلَّا بِوَلِيٍّ»',
      sunnahSource: 'رواه أبو داود (2085) والترمذي (1101) وصححه',
      importantMasail: [
        'ذمة المرأة المالية مستقلة شرعاً ومهرها حق خالص لها.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب النكاح والطلاق (ص 289-333)',
      orderNumber: 7,
    ),
    FiqhTopicModel(
      id: 'muamalat-1',
      categoryId: 'muamalat',
      subtopic: 'البيع',
      title: 'ضوابط البيع الحلال وتحريم الربا وأحكام القرض والرهن والإجارة والمضاربة',
      rulingBadge: 'مباح',
      summary: 'الأصل في البيوع الحل بالتراضي والعلم بالمبيع والثمن، ويحرم الربا والغرر والغش.',
      definitionAndExplanation: 'أحل الله البيع وحرم الربا بجميع صوره (ربا الديون وربا الفضل والنسيئة)، وشرع القرض الحسن والرهن والإجارة والمضاربة.',
      conditionsAndPillars: [
        'التراضي، وأهلية العاقدين، وملك العين وإباحتها والقدرة على تسليمها، والعلم بالمبيع والثمن.',
        'في المضاربة يكون الربح بنسبة شائعة متفق عليها والخسارة المالية على رب المال ما لم يتعد المضارب.',
      ],
      quranAyah: '﴿وَأَحَلَّ اللَّهُ الْبَيْعَ وَحَرَّمَ الرِّبَا﴾',
      quranSurah: 'سورة البقرة: آية 275',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «البَيِّعَانِ بِالخِيَارِ مَا لَمْ يَتَفَرَّقَا، فَإِنْ صَدَقَا وَبَيَّنَا بُورِكَ لَهُمَا فِي بَيْعِهِمَا»',
      sunnahSource: 'متفق عليه: البخاري (2079)، ومسلم (1532)',
      importantMasail: [
        'كل قرض اشترط فيه نفع للمقرض فهو ربا محرم بالإجماع.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب البيوع والمعاملات (ص 209-252)',
      orderNumber: 8,
    ),
    FiqhTopicModel(
      id: 'atima-1',
      categoryId: 'atima',
      subtopic: 'الحلال والحرام',
      title: 'أحكام الأطعمة والأشربة وشروط الذكاة الشرعية وآداب الطعام',
      rulingBadge: 'مباح',
      summary: 'الأصل في الأطعمة والأشربة الطاهرة الحل، وتحرم الميتة والدم ولحم الخنزير وكل ذي ناب من السباع وكل مسكر.',
      definitionAndExplanation: 'يشترط لحل حيوان البر المأكول الذكاة الشرعية بقطع الحلقوم والمريء بآلة محددة مع ذكر اسم الله.',
      conditionsAndPillars: [
        'ذكر اسم الله عند الذبح، وإنهار الدم بآلة حادة من مسلم أو كتابي.',
        'تحريم كل مسكر ومخدر؛ فما أسكر كثيره فقليله حرام.',
        'آداب الطعام: التسمية، والأكل باليمين ومما يليه، وحمد الله بعد الفراغ.',
      ],
      quranAyah: '﴿وَيُحِلُّ لَهُمُ الطَّيِّبَاتِ وَيُحَرِّمُ عَلَيْهِمُ الْخَبَائِثَ﴾',
      quranSurah: 'سورة الأعراف: آية 157',
      sunnahHadith: 'قَالَ رَسُولُ اللَّهِ ﷺ: «يَا غُلَامُ، سَمِّ اللَّهَ، وَكُلْ بِيَمِينِكَ، وَكُلْ مِمَّا يَلِيكَ»',
      sunnahSource: 'متفق عليه: البخاري (5376)، ومسلم (2022)',
      importantMasail: [
        'صيد البحر وطعامه حلال حياً وميتاً بنص القرآن الكريم.',
      ],
      fiqhReference: 'الفقه الميسر في ضوء الكتاب والسنة - كتاب الأطعمة والأشربة (ص 369-387)',
      orderNumber: 9,
    ),
  ];
}
