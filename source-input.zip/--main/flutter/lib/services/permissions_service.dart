// =========================================================================
// Real 100% Native Permissions Service for "رِفْق | RIFQ" (Flutter - Android/iOS)
// =========================================================================

import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'notification_manager.dart';

enum RifqPermissionStatus {
  granted,
  denied,
  restricted,
  limited,
  permanentlyDenied,
  provisional,
  notRequested,
}

class PermissionResult {
  final RifqPermissionStatus status;
  final bool isGranted;
  final bool isPermanentlyDenied;
  final String? errorMessage;
  final dynamic data;

  const PermissionResult({
    required this.status,
    required this.isGranted,
    this.isPermanentlyDenied = false,
    this.errorMessage,
    this.data,
  });
}

class PermissionsService {
  static final PermissionsService _instance = PermissionsService._internal();
  factory PermissionsService() => _instance;
  PermissionsService._internal();

  // Storage Keys matching Specification 【9】
  static const String keyLocationStatus = 'location_permission_status';
  static const String keyNotificationStatus = 'notification_permission_status';
  static const String keyMicrophoneStatus = 'microphone_permission_status';
  static const String keyStorageStatus = 'storage_permission_status';

  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  final SpeechToText _speechToText = SpeechToText();
  bool _isNotificationsInitialized = false;

  /// Map permission_handler status to our comprehensive enum
  RifqPermissionStatus _mapStatus(PermissionStatus status) {
    switch (status) {
      case PermissionStatus.granted:
        return RifqPermissionStatus.granted;
      case PermissionStatus.denied:
        return RifqPermissionStatus.denied;
      case PermissionStatus.permanentlyDenied:
        return RifqPermissionStatus.permanentlyDenied;
      case PermissionStatus.restricted:
        return RifqPermissionStatus.restricted;
      case PermissionStatus.limited:
        return RifqPermissionStatus.limited;
      case PermissionStatus.provisional:
        return RifqPermissionStatus.provisional;
    }
  }

  /// Initialize local notification channels via NotificationManager
  Future<void> initNotificationsPlugin() async {
    if (_isNotificationsInitialized) return;
    await NotificationManager.init();
    _isNotificationsInitialized = true;
  }

  /// Save status in shared_preferences
  Future<void> _saveStatus(String storageKey, RifqPermissionStatus status) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(storageKey, status.name);
  }

  /// Get status from shared_preferences
  Future<RifqPermissionStatus> getSavedStatus(String storageKey) async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(storageKey);
    if (saved != null) {
      for (var val in RifqPermissionStatus.values) {
        if (val.name == saved) return val;
      }
    }
    return RifqPermissionStatus.notRequested;
  }

  // =========================================================================
  // 1. REAL LOCATION PERMISSION & GPS TRIGGER
  // =========================================================================
  Future<PermissionResult> requestLocationPermission() async {
    // 1. Check if GPS hardware service is enabled on device
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return const PermissionResult(
        status: RifqPermissionStatus.denied,
        isGranted: false,
        errorMessage: 'خدمات الموقع الجغرافي (GPS) مغلقة على هاتفك. يرجى تفعيلها.',
      );
    }

    // 2. Request native permission dialog
    final status = await Permission.locationWhenInUse.request();
    final mapped = _mapStatus(status);
    await _saveStatus(keyLocationStatus, mapped);

    if (status.isGranted || status.isLimited) {
      try {
        // Execute real feature immediately: obtain real GPS coordinates
        final Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 10),
        );
        return PermissionResult(
          status: mapped,
          isGranted: true,
          data: position,
        );
      } catch (e) {
        return PermissionResult(
          status: mapped,
          isGranted: true,
          errorMessage: 'تم منح الإذن ولكن تعذر قراءة الإحداثيات الحالية: $e',
        );
      }
    } else if (status.isPermanentlyDenied) {
      return const PermissionResult(
        status: RifqPermissionStatus.permanentlyDenied,
        isGranted: false,
        isPermanentlyDenied: true,
        errorMessage: 'تم رفض إذن الموقع بشكل دائم. يمكنك تفعيله يدوياً عبر إعدادات الجهاز.',
      );
    } else {
      return const PermissionResult(
        status: RifqPermissionStatus.denied,
        isGranted: false,
        errorMessage: 'لم يتم منح الإذن. يمكنك إدخال اسم مدينتك يدوياً دون أي مشكلة.',
      );
    }
  }

  // =========================================================================
  // 2. REAL NOTIFICATION PERMISSION & IMMEDIATE REAL PUSH TEST
  // =========================================================================
  Future<PermissionResult> requestNotificationPermission() async {
    await NotificationManager.init();

    // Real native system prompt via NotificationManager
    final granted = await NotificationManager.requestPermission();
    final enabled = granted || await NotificationManager.areNotificationsEnabled();

    if (enabled) {
      await _saveStatus(keyNotificationStatus, RifqPermissionStatus.granted);
      await NotificationManager.showNotification(
        id: 1001,
        title: 'رِفْق | RIFQ',
        body: 'تم تفعيل تنبيهات الصلاة والأذكار بنجاح في تطبيق رِفْق',
        channelId: NotificationManager.adhanChannelId,
        channelName: 'تنبيهات الأذان',
      );
      return const PermissionResult(
        status: RifqPermissionStatus.granted,
        isGranted: true,
      );
    }

    final blocked = await NotificationManager.isPermanentlyBlockedInSystem();
    if (blocked) {
      await _saveStatus(
          keyNotificationStatus, RifqPermissionStatus.permanentlyDenied);
      return const PermissionResult(
        status: RifqPermissionStatus.permanentlyDenied,
        isGranted: false,
        isPermanentlyDenied: true,
        errorMessage:
            'الإشعارات محظورة في إعدادات الهاتف. يمكنك تفعيلها من إعدادات النظام.',
      );
    }

    await _saveStatus(keyNotificationStatus, RifqPermissionStatus.denied);
    return const PermissionResult(
      status: RifqPermissionStatus.denied,
      isGranted: false,
      errorMessage:
          'لم يتم تفعيل الإشعارات. يمكنك تفعيلها من إعدادات الإشعارات في أي وقت.',
    );
  }

  // =========================================================================
  // 3. REAL MICROPHONE PERMISSION & SPEECH ENGINE TEST
  // =========================================================================
  Future<PermissionResult> requestMicrophonePermission() async {
    final status = await Permission.microphone.request();
    final mapped = _mapStatus(status);
    await _saveStatus(keyMicrophoneStatus, mapped);

    if (status.isGranted) {
      // Execute real test: verify speech recognizer initializes
      bool hasSpeech = false;
      try {
        hasSpeech = await _speechToText.initialize(
          onError: (val) => debugPrint('STT Error: $val'),
          onStatus: (val) => debugPrint('STT Status: $val'),
        );
      } catch (e) {
        debugPrint('STT Init exception: $e');
      }

      return PermissionResult(
        status: mapped,
        isGranted: true,
        data: hasSpeech,
      );
    } else if (status.isPermanentlyDenied) {
      return const PermissionResult(
        status: RifqPermissionStatus.permanentlyDenied,
        isGranted: false,
        isPermanentlyDenied: true,
        errorMessage: 'تم رفض إذن الميكروفون نهائياً. التطبيق يوفر المسبحة اللمسية بالكامل بدون ميكروفون.',
      );
    } else {
      return const PermissionResult(
        status: RifqPermissionStatus.denied,
        isGranted: false,
        errorMessage: 'لم يتم منح إذن الميكروفون. يمكنك استخدام المسبحة اللمسية التفاعلية.',
      );
    }
  }

  // =========================================================================
  // 4. REAL STORAGE PERMISSION
  // =========================================================================
  Future<PermissionResult> requestStoragePermission() async {
    PermissionStatus status;
    if (Platform.isAndroid) {
      // Android 13+ (API 33+) uses audio permission for sound files
      final audioStatus = await Permission.audio.status;
      if (audioStatus.isGranted) {
        status = PermissionStatus.granted;
      } else {
        status = await Permission.audio.request();
        if (status.isDenied) {
          status = await Permission.storage.request();
        }
      }
    } else {
      // iOS sandboxed documents storage is always permitted
      status = PermissionStatus.granted;
    }

    final mapped = _mapStatus(status);
    await _saveStatus(keyStorageStatus, mapped);

    return PermissionResult(
      status: mapped,
      isGranted: status.isGranted,
      isPermanentlyDenied: status.isPermanentlyDenied,
      errorMessage: status.isPermanentlyDenied
          ? 'إذن التخزين محظور. يمكنك تفعيله من الإعدادات للاستماع دون اتصال.'
          : (status.isDenied ? 'لم يتم منح إذن التخزين. سيتم تشغيل التلاوات مباشرة عبر الإنترنت.' : null),
    );
  }

  // =========================================================================
  // 5. OPEN SYSTEM APP SETTINGS (Requirement 【4】)
  // =========================================================================
  Future<bool> openSystemSettings() async {
    return await openAppSettings();
  }

  // =========================================================================
  // 6. VERIFY ALL PERMISSIONS ON APP LAUNCH (Requirement 【9】)
  // =========================================================================
  Future<Map<String, RifqPermissionStatus>> checkAllPermissionsOnResume() async {
    final Map<String, RifqPermissionStatus> statuses = {};

    // 1. Location
    final locStatus = await Permission.locationWhenInUse.status;
    statuses['location'] = _mapStatus(locStatus);
    await _saveStatus(keyLocationStatus, statuses['location']!);

    // 2. Notifications (Real check via NotificationManager)
    final notifEnabled = await NotificationManager.areNotificationsEnabled();
    if (notifEnabled) {
      statuses['notifications'] = RifqPermissionStatus.granted;
    } else {
      final notifStatus = await Permission.notification.status;
      statuses['notifications'] = _mapStatus(notifStatus);
    }
    await _saveStatus(keyNotificationStatus, statuses['notifications']!);

    // 3. Microphone
    final micStatus = await Permission.microphone.status;
    statuses['microphone'] = _mapStatus(micStatus);
    await _saveStatus(keyMicrophoneStatus, statuses['microphone']!);

    // 4. Storage
    final storageStatus = Platform.isAndroid ? await Permission.audio.status : PermissionStatus.granted;
    statuses['storage'] = _mapStatus(storageStatus);
    await _saveStatus(keyStorageStatus, statuses['storage']!);

    return statuses;
  }
}
