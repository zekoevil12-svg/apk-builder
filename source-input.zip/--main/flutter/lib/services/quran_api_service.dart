import 'dart:convert';
import 'package:http/http.dart' as http;
import 'quran_database_helper.dart';

class QuranApiService {
  static const String baseUrlAlquran = 'https://api.alquran.cloud/v1';
  static const String baseUrlQuranCom = 'https://api.quran.com/api/v4';

  /// Fetches Surah verses from SQLite first. If missing, fetches from API and caches locally.
  static Future<List<Map<String, dynamic>>> getSurahVerses(int surahNumber) async {
    // 1. Try local SQLite
    final localVerses = await QuranDatabaseHelper.instance.getVersesForSurah(surahNumber);
    if (localVerses.isNotEmpty) {
      return localVerses.map((v) => {
        'numberInSurah': v['number_in_surah'],
        'text': v['text_ar'],
        'page': v['page_number'],
        'juz': v['juz_number'],
      }).toList();
    }

    // 2. Fetch from verified alquran.cloud API (Uthmani text)
    try {
      final response = await http.get(
        Uri.parse('$baseUrlAlquran/surah/$surahNumber/editions/quran-uthmani,ar.muyassar'),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = json.decode(utf8.decode(response.bodyBytes));
        if (data['code'] == 200 && data['data'] is List) {
          final arabicData = data['data'][0];
          final tafseerData = data['data'][1];
          final rawAyahs = arabicData['ayahs'] as List;

          final List<Map<String, dynamic>> parsedVerses = [];
          for (int i = 0; i < rawAyahs.length; i++) {
            final a = rawAyahs[i];
            String text = a['text'];

            // Bismillah treatment
            if (surahNumber != 1 && surahNumber != 9 && i == 0 && text.startsWith('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')) {
              text = text.replaceFirst('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', '').trim();
            }

            parsedVerses.add({
              'numberInSurah': a['numberInSurah'],
              'text': text,
              'page': a['page'],
              'juz': a['juz'],
            });
          }

          // Cache in SQLite
          await QuranDatabaseHelper.instance.saveSurahVerses(surahNumber, parsedVerses);

          return parsedVerses;
        }
      }
    } catch (e) {
      print('Error fetching Quran API: $e');
    }

    return [];
  }

  /// Fetches authentic Tafseer from Quran.com API (16: Muyassar, 169: Saadi, 14: Ibn Kathir, 93: Qurtubi)
  static Future<String> getTafseerText(int surahNumber, int ayahNumber, String tafseerType) async {
    int tafseerId = 16; // Muyassar default
    if (tafseerType == 'saadi') tafseerId = 169;
    if (tafseerType == 'ibnkathir') tafseerId = 14;
    if (tafseerType == 'qurtubi') tafseerId = 93;

    try {
      final res = await http.get(
        Uri.parse('$baseUrlQuranCom/tafsirs/$tafseerId/by_ayah/$surahNumber:$ayahNumber'),
        headers: {'Accept': 'application/json'},
      );
      if (res.statusCode == 200) {
        final data = json.decode(utf8.decode(res.bodyBytes));
        if (data['tafsir'] != null && data['tafsir']['text'] != null) {
          String text = data['tafsir']['text'];
          return text.replaceAll(RegExp(r'<[^>]*>'), '').trim();
        }
      }
    } catch (e) {
      print('Error fetching tafseer: $e');
    }
    return 'التفسير متاح عبر الاتصال بالإنترنت.';
  }
}
