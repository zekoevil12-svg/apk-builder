import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class QuranDatabaseHelper {
  static final QuranDatabaseHelper instance = QuranDatabaseHelper._init();
  static Database? _database;

  QuranDatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('rifq_quran_v1.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    // 1. جدول surahs
    await db.execute('''
      CREATE TABLE surahs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        number INTEGER NOT NULL UNIQUE,
        name_ar TEXT NOT NULL,
        name_en TEXT NOT NULL,
        verses_count INTEGER NOT NULL,
        type TEXT NOT NULL,
        juz_number INTEGER NOT NULL
      )
    ''');

    // 2. جدول verses
    await db.execute('''
      CREATE TABLE verses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        surah_id INTEGER NOT NULL,
        number_in_surah INTEGER NOT NULL,
        text_ar TEXT NOT NULL,
        page_number INTEGER,
        juz_number INTEGER,
        FOREIGN KEY (surah_id) REFERENCES surahs (number)
      )
    ''');

    // 3. جدول tafsirs
    await db.execute('''
      CREATE TABLE tafsirs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        verse_id INTEGER NOT NULL,
        tafsir_type TEXT NOT NULL,
        text TEXT NOT NULL,
        source TEXT,
        FOREIGN KEY (verse_id) REFERENCES verses (id)
      )
    ''');

    // 4. جدول bookmarks
    await db.execute('''
      CREATE TABLE bookmarks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        surah_id INTEGER NOT NULL,
        verse_number INTEGER NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    // 5. جدول favorites
    await db.execute('''
      CREATE TABLE favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        surah_id INTEGER NOT NULL,
        verse_number INTEGER,
        added_at TEXT NOT NULL
      )
    ''');

    // 6. جدول reading_progress
    await db.execute('''
      CREATE TABLE reading_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        last_surah_id INTEGER NOT NULL,
        last_verse_number INTEGER NOT NULL,
        last_read_at TEXT NOT NULL
      )
    ''');

    // 7. جدول khatmah
    await db.execute('''
      CREATE TABLE khatmah (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        started_at TEXT NOT NULL,
        target_end_date TEXT NOT NULL,
        daily_goal TEXT NOT NULL,
        completed_juz INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1
      )
    ''');
  }

  // --- CRUD helpers ---
  Future<void> saveSurahVerses(int surahNumber, List<Map<String, dynamic>> verses) async {
    final db = await instance.database;
    final batch = db.batch();
    for (var v in verses) {
      batch.insert(
        'verses',
        {
          'surah_id': surahNumber,
          'number_in_surah': v['numberInSurah'],
          'text_ar': v['text'],
          'page_number': v['page'],
          'juz_number': v['juz'],
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<List<Map<String, dynamic>>> getVersesForSurah(int surahNumber) async {
    final db = await instance.database;
    return await db.query(
      'verses',
      where: 'surah_id = ?',
      whereArgs: [surahNumber],
      orderBy: 'number_in_surah ASC',
    );
  }

  Future<void> saveLastReadPosition(int surahId, int verseNumber) async {
    final db = await instance.database;
    await db.delete('reading_progress');
    await db.insert('reading_progress', {
      'last_surah_id': surahId,
      'last_verse_number': verseNumber,
      'last_read_at': DateTime.now().toIso8601String(),
    });
  }

  Future<Map<String, dynamic>?> getLastReadPosition() async {
    final db = await instance.database;
    final res = await db.query('reading_progress', limit: 1);
    if (res.isNotEmpty) return res.first;
    return null;
  }

  Future<void> toggleBookmark(int surahId, int verseNumber) async {
    final db = await instance.database;
    final existing = await db.query(
      'bookmarks',
      where: 'surah_id = ? AND verse_number = ?',
      whereArgs: [surahId, verseNumber],
    );
    if (existing.isNotEmpty) {
      await db.delete(
        'bookmarks',
        where: 'surah_id = ? AND verse_number = ?',
        whereArgs: [surahId, verseNumber],
      );
    } else {
      await db.insert('bookmarks', {
        'surah_id': surahId,
        'verse_number': verseNumber,
        'created_at': DateTime.now().toIso8601String(),
      });
    }
  }

  Future<List<Map<String, dynamic>>> getBookmarks() async {
    final db = await instance.database;
    return await db.query('bookmarks', orderBy: 'created_at DESC');
  }

  Future<void> toggleFavoriteSurah(int surahId) async {
    final db = await instance.database;
    final existing = await db.query(
      'favorites',
      where: 'surah_id = ? AND verse_number IS NULL',
      whereArgs: [surahId],
    );
    if (existing.isNotEmpty) {
      await db.delete(
        'favorites',
        where: 'surah_id = ? AND verse_number IS NULL',
        whereArgs: [surahId],
      );
    } else {
      await db.insert('favorites', {
        'surah_id': surahId,
        'verse_number': null,
        'added_at': DateTime.now().toIso8601String(),
      });
    }
  }

  Future<List<int>> getFavoriteSurahIds() async {
    final db = await instance.database;
    final res = await db.query(
      'favorites',
      where: 'verse_number IS NULL',
    );
    return res.map((r) => r['surah_id'] as int).toList();
  }
}
