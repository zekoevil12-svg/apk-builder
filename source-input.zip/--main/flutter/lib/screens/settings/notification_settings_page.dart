import 'package:flutter/material.dart';
import '../../services/notification_manager.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// صفحة إعدادات الإشعارات الحقيقية في تطبيق «رِفْق | RIFQ»
/// - تفحص الحالة الفعلية من النظام عبر NotificationManager.areNotificationsEnabled()
/// - تعيد الفحص تلقائياً عند العودة من إعدادات النظام (didChangeAppLifecycleState)
/// - تطلب صلاحية POST_NOTIFICATIONS الحقيقية أو تفتح إعدادات النظام
/// - ترسل إشعاراً حقيقياً 100% عند التجربة أو التفعيل
/// ══════════════════════════════════════════════════════════════════════════
class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({Key? key}) : super(key: key);

  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage>
    with WidgetsBindingObserver {
  bool _notificationsEnabled = false;
  bool _permanentlyBlocked = false;
  bool _loading = true;

  bool _adhanToggle = true;
  bool _quranToggle = true;
  bool _azkarToggle = true;
  bool _remindersToggle = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ✅ إعادة فحص الحالة الفعلية تلقائياً عند العودة من إعدادات النظام
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPermission();
    }
  }

  Future<void> _checkPermission() async {
    if (mounted) {
      setState(() => _loading = true);
    }

    final enabled = await NotificationManager.areNotificationsEnabled();
    final blocked =
        enabled ? false : await NotificationManager.isPermanentlyBlockedInSystem();

    final adhan = await NotificationManager.isChannelEnabled(
        NotificationManager.adhanChannelId);
    final quran = await NotificationManager.isChannelEnabled(
        NotificationManager.quranChannelId);
    final azkar = await NotificationManager.isChannelEnabled(
        NotificationManager.azkarChannelId);
    final reminders = await NotificationManager.isChannelEnabled(
        NotificationManager.remindersChannelId);

    if (mounted) {
      setState(() {
        _notificationsEnabled = enabled;
        _permanentlyBlocked = blocked;
        _adhanToggle = adhan;
        _quranToggle = quran;
        _azkarToggle = azkar;
        _remindersToggle = reminders;
        _loading = false;
      });
    }
  }

  Future<void> _requestOrOpenSettings() async {
    final granted = await NotificationManager.requestPermission();

    if (granted) {
      await _checkPermission();
      // إرسال إشعار حقيقي عند الموافقة لتأكيد عمل النظام
      await NotificationManager.showNotification(
        id: 998,
        title: 'رِفْق | RIFQ',
        body: 'تم تفعيل الإشعارات بنجاح في تطبيق رِفْق',
      );
    } else {
      // فتح إعدادات إشعارات التطبيق في النظام مباشرة
      await NotificationManager.openNotificationSettings();
    }
  }

  Future<void> _sendTestNotification() async {
    final success = await NotificationManager.showNotification(
      id: 999,
      title: '✅ إشعار تجريبي',
      body: 'الإشعارات تعمل بشكل صحيح في تطبيق رِفْق',
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor:
              success ? const Color(0xFF4CAF82) : const Color(0xFFD95C6A),
          content: Text(
            success
                ? 'تم إرسال الإشعار بنجاح'
                : 'فشل إرسال الإشعار - تحقق من الإعدادات',
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      );
    }
  }

  Future<void> _updateChannelToggle(String channelId, bool value) async {
    await NotificationManager.setChannelEnabled(channelId, value);
    await _checkPermission();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: _loading
          ? const Scaffold(
              backgroundColor: Color(0xFFF7F7FC),
              body: Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF5B5FEF),
                ),
              ),
            )
          : Scaffold(
              backgroundColor: const Color(0xFFF7F7FC),
              appBar: AppBar(
                backgroundColor: const Color(0xFFF7F7FC),
                elevation: 0,
                iconTheme: const IconThemeData(color: Color(0xFF25263A)),
                title: const Text(
                  'الإشعارات',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF5B5FEF),
                  ),
                ),
                actions: [
                  IconButton(
                    onPressed: _checkPermission,
                    tooltip: 'إعادة فحص الحالة',
                    icon: const Icon(
                      Icons.refresh_rounded,
                      color: Color(0xFF5B5FEF),
                    ),
                  ),
                ],
              ),
              body: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // حالة الإشعارات العامة الفعليه
                  _buildStatusCard(),

                  const SizedBox(height: 16),

                  // Toggles للقنوات الحقيقية
                  _buildToggleTile(
                    'تنبيهات الأذان',
                    _notificationsEnabled && _adhanToggle,
                    NotificationManager.adhanChannelId,
                  ),
                  _buildToggleTile(
                    'تذكير القرآن',
                    _notificationsEnabled && _quranToggle,
                    NotificationManager.quranChannelId,
                  ),
                  _buildToggleTile(
                    'الأذكار',
                    _notificationsEnabled && _azkarToggle,
                    NotificationManager.azkarChannelId,
                  ),
                  _buildToggleTile(
                    'التذكيرات',
                    _notificationsEnabled && _remindersToggle,
                    NotificationManager.remindersChannelId,
                  ),

                  const SizedBox(height: 24),

                  // زر التفعيل أو فتح إعدادات النظام عند عدم التفعيل
                  if (!_notificationsEnabled)
                    ElevatedButton(
                      onPressed: _requestOrOpenSettings,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF5B5FEF),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        _permanentlyBlocked
                            ? 'فتح إعدادات الإشعارات في النظام'
                            : 'تفعيل إشعارات التطبيق',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                    ),

                  const SizedBox(height: 16),

                  // زر إرسال إشعار تجريبي حقيقي
                  if (_notificationsEnabled)
                    OutlinedButton(
                      onPressed: _sendTestNotification,
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFF5B5FEF), width: 1.5),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'إرسال إشعار تجريبي',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF5B5FEF),
                          fontSize: 15,
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _buildStatusCard() {
    final String statusTitle = _notificationsEnabled
        ? 'الإشعارات مفعلة'
        : (_permanentlyBlocked ? 'الإشعارات متوقفة' : 'الإشعارات غير مفعلة');

    final String statusSubtitle = _notificationsEnabled
        ? 'ستستقبل الإشعارات من رِفْق'
        : (_permanentlyBlocked
            ? 'تم إيقاف الإشعارات من إعدادات الجهاز — اضغط لفتح إعدادات النظام وتفعيلها'
            : 'فعّل الإشعارات لاستقبال التنبيهات');

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _notificationsEnabled
              ? const Color(0xFF4CAF82)
              : const Color(0xFFD95C6A),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            _notificationsEnabled
                ? Icons.notifications_active_rounded
                : Icons.notifications_off_rounded,
            color: _notificationsEnabled
                ? const Color(0xFF4CAF82)
                : const Color(0xFFD95C6A),
            size: 32,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  statusTitle,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Color(0xFF25263A),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  statusSubtitle,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13,
                    color: Color(0xFF77798C),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleTile(String title, bool value, String channelId) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 15,
                color: Color(0xFF25263A),
              ),
            ),
          ),
          Switch(
            value: value,
            onChanged: _notificationsEnabled
                ? (v) => _updateChannelToggle(channelId, v)
                : null,
            activeColor: const Color(0xFF5B5FEF),
          ),
        ],
      ),
    );
  }
}
