// =========================================================================
// Real 100% Flutter Native Permissions Flow Screen for "رِفْق | RIFQ"
// =========================================================================

import 'package:flutter/material.dart';
import '../services/permissions_service.dart';

class PermissionsFlowScreen extends StatefulWidget {
  final VoidCallback onFlowCompleted;

  const PermissionsFlowScreen({
    Key? key,
    required this.onFlowCompleted,
  }) : super(key: key);

  @override
  State<PermissionsFlowScreen> createState() => _PermissionsFlowScreenState();
}

class _PermissionsFlowScreenState extends State<PermissionsFlowScreen> with WidgetsBindingObserver {
  final PermissionsService _service = PermissionsService();
  int _currentStep = 0;
  bool _isLoading = false;
  String? _statusBanner;
  bool _isError = false;
  bool _showOpenSettings = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkCurrentStepStatus();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// When user returns from System Settings, re-check permissions automatically
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkCurrentStepStatus();
    }
  }

  Future<void> _checkCurrentStepStatus() async {
    final statuses = await _service.checkAllPermissionsOnResume();
    setState(() {
      // Refresh UI with latest real OS permissions
    });
  }

  void _nextStep() {
    setState(() {
      _statusBanner = null;
      _showOpenSettings = false;
      _isError = false;
      if (_currentStep < 3) {
        _currentStep++;
      } else {
        widget.onFlowCompleted();
      }
    });
  }

  Future<void> _handleAllow() async {
    setState(() {
      _isLoading = true;
      _statusBanner = null;
      _showOpenSettings = false;
      _isError = false;
    });

    PermissionResult result;

    if (_currentStep == 0) {
      result = await _service.requestLocationPermission();
    } else if (_currentStep == 1) {
      result = await _service.requestNotificationPermission();
    } else if (_currentStep == 2) {
      result = await _service.requestMicrophonePermission();
    } else {
      result = await _service.requestStoragePermission();
    }

    setState(() {
      _isLoading = false;
      if (result.isGranted) {
        _isError = false;
        _statusBanner = 'تم منح الإذن بنجاح والتأكد من عمل الميزة في النظام! ✅';
        Future.delayed(const Duration(milliseconds: 900), () {
          if (mounted) _nextStep();
        });
      } else if (result.isPermanentlyDenied) {
        _isError = true;
        _showOpenSettings = true;
        _statusBanner = result.errorMessage ?? 'تم رفض الإذن نهائياً من إعدادات النظام.';
      } else {
        _isError = true;
        _statusBanner = result.errorMessage ?? 'لم يتم منح الإذن. يمكنك المتابعة بدون الميزة.';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    const Color primaryBlue = Color(0xFF4145C7);
    const Color secondaryGold = Color(0xFF5B5FEF);
    const Color bgBeige = Color(0xFFF7F7FC);

    final List<Map<String, dynamic>> steps = [
      {
        'title': 'الوصول إلى الموقع الجغرافي',
        'desc': 'لتحديد مواقيت الصلاة بدقة في مدينتك وتحديد اتجاه القبلة الصحيح',
        'icon': Icons.explore_rounded,
        'badge': 'مواقيت الصلاة والقبلة',
        'fallback': 'البديل المتاح: إدخال المدينة يدوياً بالكامل.',
        'privacy': 'يُطلب أثناء استخدام التطبيق فقط. لا يتم تتبعك في الخلفية مطلقاً.'
      },
      {
        'title': 'تفعيل الإشعارات والأذان',
        'desc': 'لتصلك تنبيهات الأذان والأذكار المباركة في وقتها بدقة',
        'icon': Icons.notifications_active_rounded,
        'badge': 'الأذان والأذكار',
        'fallback': 'البديل المتاح: التطبيق يعمل بدون تنبيهات خارجية في الخلفية.',
        'privacy': 'نرسل تنبيهات الأذان والأذكار فقط دون أي إعلانات أو إزعاج.'
      },
      {
        'title': 'الميكروفون للتسبيح الصوتي',
        'desc': 'لتسبيح الأذكار بصوتك. صوتك لا يُسجَّل ولا يُرسَل لأي جهة',
        'icon': Icons.mic_rounded,
        'badge': 'تسبيح ذكي بدون لمس',
        'fallback': 'البديل المتاح: المسبحة اللمسية المركزية تعمل بكفاءة تامة.',
        'privacy': 'المعالجة الصوتية تتم محلياً 100% داخل جهازك دون تسجيل.'
      },
      {
        'title': 'تخزين الصوتيات بدون إنترنت',
        'desc': 'لتحميل القرآن وتلاوات القراء والاستماع في أي وقت دون اتصال',
        'icon': Icons.download_for_offline_rounded,
        'badge': 'الاستماع بدون إنترنت',
        'fallback': 'البديل المتاح: الاستماع المباشر للتلاوات عبر الإنترنت.',
        'privacy': 'يقتصر على حفظ المقاطع الصوتية المصرح بها فقط.'
      },
    ];

    final current = steps[_currentStep];

    return Scaffold(
      backgroundColor: bgBeige,
      body: SafeArea(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
            child: Column(
              children: [
                // Top Bar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: primaryBlue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'إذن ${_currentStep + 1} من 4',
                        style: const TextStyle(
                          color: primaryBlue,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: widget.onFlowCompleted,
                      child: const Text(
                        'تخطي الكل',
                        style: TextStyle(color: Colors.black54, fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),

                const Spacer(),

                // Center Icon Circle
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [secondaryGold, Color(0xFFFFF9E6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: secondaryGold.withOpacity(0.3),
                        blurRadius: 30,
                        spreadRadius: 2,
                      )
                    ],
                  ),
                  child: Center(
                    child: Icon(
                      current['icon'] as IconData,
                      size: 60,
                      color: primaryBlue,
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // Badge
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: primaryBlue,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    current['badge'] as String,
                    style: const TextStyle(
                      color: secondaryGold,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 16),

                // Title & Description
                Text(
                  current['title'] as String,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: primaryBlue,
                  ),
                ),

                const SizedBox(height: 10),

                Text(
                  current['desc'] as String,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black87,
                    height: 1.5,
                  ),
                ),

                const SizedBox(height: 20),

                // Privacy Box
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.black12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.shield_outlined, color: secondaryGold, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          current['privacy'] as String,
                          style: const TextStyle(fontSize: 12, color: Colors.black87),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Fallback explanation
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline, color: primaryBlue, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          current['fallback'] as String,
                          style: const TextStyle(fontSize: 11, color: primaryBlue),
                        ),
                      ),
                    ],
                  ),
                ),

                // Feedback Banner if any
                if (_statusBanner != null) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _isError ? Colors.red.withOpacity(0.1) : Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _isError ? Colors.red : Colors.green),
                    ),
                    child: Text(
                      _statusBanner!,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: _isError ? Colors.red[900] : Colors.green[900],
                      ),
                    ),
                  ),
                ],

                const Spacer(),

                // Action Buttons
                if (_showOpenSettings) ...[
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryBlue,
                        shape: RoundedRectangleRadius(borderRadius: BorderRadius.circular(16)),
                      ),
                      onPressed: () => _service.openSystemSettings(),
                      icon: const Icon(Icons.settings, color: Colors.white),
                      label: const Text(
                        'فتح إعدادات الجهاز لتفعيل الإذن',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: secondaryGold,
                      shape: RoundedRectangleRadius(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: _isLoading ? null : _handleAllow,
                    child: _isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          )
                        : const Text(
                            'السماح والمتابعة',
                            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                  ),
                ),

                const SizedBox(height: 10),

                TextButton(
                  onPressed: _isLoading ? null : _nextStep,
                  child: const Text(
                    'المتابعة بدون تفعيل هذه الميزة',
                    style: TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
