import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// أيقونات ورسوميات SVG حقيقية لقسم الحمل «رحلتك» في رِفْق للمرأة
/// بدون أي إيموجي كأيقونات رئيسية - الهوية اللونية: ذهبي + وردي هادئ + بيج + بني
/// ══════════════════════════════════════════════════════════════════════════

class PregnancySvgIcons {
  static const String _gold = '#E8B84A';
  static const String _softPink = '#E99AC7';
  static const String _lightPink = '#EEEEFF';
  static const String _brown = '#5B5FEF';
  static const String _green = '#4CAF82';
  static const String _blue = '#72B7E8';

  /// أيقونة رحلتك / الأم والجنين (الرئيسية)
  static Widget journeyHeader({double size = 26}) {
    const svg = '''
<svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="32" cy="32" r="29" fill="$_lightPink" stroke="$_gold" stroke-width="2.2"/>
  <path d="M32 14C24.5 14 19 20 19 28.5C19 39.5 32 50 32 50C32 50 45 39.5 45 28.5C45 20 39.5 14 32 14Z" fill="$_softPink" fill-opacity="0.45" stroke="$_brown" stroke-width="2" stroke-linejoin="round"/>
  <circle cx="32" cy="26" r="5" fill="$_gold"/>
  <path d="M26 35C26 31.8 28.7 29.5 32 29.5C35.3 29.5 38 31.8 38 35" stroke="$_brown" stroke-width="2.2" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة حجم وتطور الجنين
  static Widget fetusGrowth({double size = 36, int trimester = 2}) {
    final String accent = trimester == 1
        ? _softPink
        : trimester == 2
            ? _gold
            : _green;
    final svg = '''
<svg viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="40" cy="40" r="36" fill="$_lightPink" stroke="$accent" stroke-width="2.5"/>
  <circle cx="40" cy="40" r="28" fill="#FFFFFF" stroke="$_softPink" stroke-width="1.5" stroke-dasharray="4 3"/>
  <circle cx="43" cy="28" r="8" fill="$_softPink" stroke="$_brown" stroke-width="2"/>
  <path d="M36 35C30 37 27 44 30 50C33 55 41 56 46 52C50 49 49 42 44 38" fill="$_softPink" fill-opacity="0.5" stroke="$_brown" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M34 45C36 43 39 43 41 45" stroke="$accent" stroke-width="2" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة استشارة الطبيب / التنبيه الطبي الموثق
  static Widget doctorConsult({double size = 22}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="24" cy="24" r="21" fill="#E3F2FD" stroke="$_blue" stroke-width="2"/>
  <path d="M24 14V34M14 24H34" stroke="$_blue" stroke-width="3.2" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة الميزان / وزن وصحة الأم
  static Widget weightHealth({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect x="8" y="8" width="32" height="32" rx="8" fill="$_lightPink" stroke="$_gold" stroke-width="2.2"/>
  <path d="M16 18C19 13 29 13 32 18L29 24H19L16 18Z" fill="#FFFFFF" stroke="$_brown" stroke-width="1.8"/>
  <path d="M24 23L27 17" stroke="$_gold" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M16 32H32" stroke="$_brown" stroke-width="2" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة عداد حركات الجنين (Kick Counter)
  static Widget kicksCounter({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="24" cy="24" r="20" fill="$_lightPink" stroke="$_softPink" stroke-width="2.2"/>
  <path d="M21 31C18 28 18 22 21 19C23.5 16.5 27 18 27 22C27 25 25 28 25 31C25 33.5 22.8 33 21 31Z" fill="$_gold" stroke="$_brown" stroke-width="1.8"/>
  <circle cx="19" cy="14" r="2" fill="$_brown"/>
  <circle cx="23.5" cy="13" r="1.8" fill="$_brown"/>
  <circle cx="27.5" cy="14" r="1.6" fill="$_brown"/>
  <circle cx="30.5" cy="16.5" r="1.4" fill="$_brown"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة مؤقت الانقباضات (Contraction Timer)
  static Widget contractionTimer({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="24" cy="26" r="16" fill="#FFFFFF" stroke="$_gold" stroke-width="2.4"/>
  <path d="M20 6H28M24 6V10" stroke="$_brown" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M15 26H19L22 20L26 32L29 26H33" stroke="$_softPink" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة مواعيد الطبيبة والفحوصات
  static Widget appointments({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect x="8" y="11" width="32" height="29" rx="6" fill="#FFFFFF" stroke="$_gold" stroke-width="2.2"/>
  <path d="M8 19H40" stroke="$_gold" stroke-width="2"/>
  <path d="M16 7V13M32 7V13" stroke="$_brown" stroke-width="2.4" stroke-linecap="round"/>
  <path d="M24 24V34M19 29H29" stroke="$_green" stroke-width="2.5" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة التغذية والفيتامينات
  static Widget nutrition({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M24 14C17 14 12 19 12 27C12 35 17.5 41 24 41C30.5 41 36 35 36 27C36 19 31 14 24 14Z" fill="$_lightPink" stroke="$_green" stroke-width="2.2"/>
  <path d="M24 14C24 10 27 7 31 7C31 11 28 14 24 14Z" fill="$_green"/>
  <path d="M20 26L23 29L29 23" stroke="$_green" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة أدعية وفقه الحامل
  static Widget duasAndFiqh({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M10 14C15 12 21 12 24 15C27 12 33 12 38 14V36C33 34 27 34 24 37C21 34 15 34 10 36V14Z" fill="#FFFFFF" stroke="$_gold" stroke-width="2.2" stroke-linejoin="round"/>
  <path d="M24 15V37" stroke="$_gold" stroke-width="2"/>
  <circle cx="24" cy="9" r="2.5" fill="$_softPink"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة حقيبة الولادة
  static Widget hospitalBag({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect x="8" y="16" width="32" height="24" rx="6" fill="$_lightPink" stroke="$_brown" stroke-width="2.2"/>
  <path d="M18 16V12C18 9.8 19.8 8 22 8H26C28.2 8 30 9.8 30 12V16" stroke="$_brown" stroke-width="2.2"/>
  <path d="M24 23V33M19 28H29" stroke="$_gold" stroke-width="2.6" stroke-linecap="round"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة مذكرات رحلتي
  static Widget journal({double size = 24}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <rect x="11" y="8" width="26" height="32" rx="4" fill="#FFFFFF" stroke="$_softPink" stroke-width="2.2"/>
  <path d="M17 16H31M17 22H31M17 28H25" stroke="$_brown" stroke-width="2" stroke-linecap="round"/>
  <circle cx="31" cy="31" r="4" fill="$_gold"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }

  /// أيقونة الماء والترطيب
  static Widget waterDrop({double size = 22}) {
    const svg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M24 8C24 8 12 22 12 30C12 36.6 17.4 42 24 42C30.6 42 36 36.6 36 30C36 22 24 8 24 8Z" fill="#E3F2FD" stroke="$_blue" stroke-width="2.2"/>
</svg>
''';
    return SvgPicture.string(svg, width: size, height: size);
  }
}
