import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;
import '../../services/notification_manager.dart';
import 'pregnancy_medical_data.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// قاعدة البيانات الحقيقية لقسم الحمل «رحلتك» (SQLite 100% - بدون أي بيانات وهمية)
/// - 9 جداول فعلية:
///   1. pregnancy_profile (ملف الحمل وحساب الأسابيع التلقائي)
///   2. pregnancy_weights (سجل وزن الأم والقياسات الحيوية)
///   3. pregnancy_symptoms (سجل الأعراض اليومية، الماء، الفيتامينات)
///   4. fetal_kicks (عداد حركات الجنين Kick Counter)
///   5. contractions (مؤقت الانقباضات Contraction Timer)
///   6. pregnancy_appointments (مواعيد الطبيبة والفحوصات مع إشعارات حقيقية)
///   7. hospital_bag_items (قائمة حقيبة الولادة للأم والمولود والمستندات)
///   8. pregnancy_notes (مذكرات رحلة الحمل ورسائل للجنين)
///   9. pregnancy_reminders (التذكيرات اليومية الحقيقية المجدولة)
/// ══════════════════════════════════════════════════════════════════════════

class PregnancyProfileModel {
  final int? id;
  final String calculationMethod; // 'lmp' | 'due_date'
  final String lmpDate; // YYYY-MM-DD
  final String dueDate; // YYYY-MM-DD
  final double? prePregnancyWeight;
  final double? heightCm;
  final String bloodType;
  final String doctorName;
  final String hospitalName;
  final String createdAt;

  const PregnancyProfileModel({
    this.id,
    required this.calculationMethod,
    required this.lmpDate,
    required this.dueDate,
    this.prePregnancyWeight,
    this.heightCm,
    required this.bloodType,
    required this.doctorName,
    required this.hospitalName,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'calculation_method': calculationMethod,
        'lmp_date': lmpDate,
        'due_date': dueDate,
        'pre_pregnancy_weight': prePregnancyWeight,
        'height_cm': heightCm,
        'blood_type': bloodType,
        'doctor_name': doctorName,
        'hospital_name': hospitalName,
        'created_at': createdAt,
      };

  factory PregnancyProfileModel.fromMap(Map<String, dynamic> map) =>
      PregnancyProfileModel(
        id: map['id'] as int?,
        calculationMethod: (map['calculation_method'] as String?) ?? 'lmp',
        lmpDate: map['lmp_date'] as String,
        dueDate: map['due_date'] as String,
        prePregnancyWeight: (map['pre_pregnancy_weight'] as num?)?.toDouble(),
        heightCm: (map['height_cm'] as num?)?.toDouble(),
        bloodType: (map['blood_type'] as String?) ?? '',
        doctorName: (map['doctor_name'] as String?) ?? '',
        hospitalName: (map['hospital_name'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class PregnancyCalculationResult {
  final int currentWeek; // 1 .. 40
  final int extraDays; // 0 .. 6
  final int totalDaysPassed;
  final int remainingDays;
  final double progressPercent; // 0 .. 100
  final int trimester; // 1, 2, 3
  final String trimesterTitle;
  final DateTime lmpDate;
  final DateTime dueDate;

  const PregnancyCalculationResult({
    required this.currentWeek,
    required this.extraDays,
    required this.totalDaysPassed,
    required this.remainingDays,
    required this.progressPercent,
    required this.trimester,
    required this.trimesterTitle,
    required this.lmpDate,
    required this.dueDate,
  });
}

class PregnancyWeightRecord {
  final int? id;
  final int pregnancyId;
  final String date; // YYYY-MM-DD
  final int week;
  final double weightKg;
  final String bloodPressure;
  final String notes;
  final String createdAt;

  const PregnancyWeightRecord({
    this.id,
    required this.pregnancyId,
    required this.date,
    required this.week,
    required this.weightKg,
    required this.bloodPressure,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'date': date,
        'week': week,
        'weight_kg': weightKg,
        'blood_pressure': bloodPressure,
        'notes': notes,
        'created_at': createdAt,
      };

  factory PregnancyWeightRecord.fromMap(Map<String, dynamic> map) =>
      PregnancyWeightRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        date: map['date'] as String,
        week: (map['week'] as int?) ?? 1,
        weightKg: (map['weight_kg'] as num).toDouble(),
        bloodPressure: (map['blood_pressure'] as String?) ?? '',
        notes: (map['notes'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class PregnancySymptomRecord {
  final int? id;
  final int pregnancyId;
  final String date; // YYYY-MM-DD
  final int week;
  final List<String> symptoms;
  final String severity; // 'mild' | 'moderate' | 'severe'
  final int waterCups;
  final bool folicAcidTaken;
  final bool ironTaken;
  final bool calciumTaken;
  final String notes;
  final String createdAt;

  const PregnancySymptomRecord({
    this.id,
    required this.pregnancyId,
    required this.date,
    required this.week,
    required this.symptoms,
    required this.severity,
    required this.waterCups,
    required this.folicAcidTaken,
    required this.ironTaken,
    required this.calciumTaken,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'date': date,
        'week': week,
        'symptoms_json': jsonEncode(symptoms),
        'severity': severity,
        'water_cups': waterCups,
        'folic_acid_taken': folicAcidTaken ? 1 : 0,
        'iron_taken': ironTaken ? 1 : 0,
        'calcium_taken': calciumTaken ? 1 : 0,
        'notes': notes,
        'created_at': createdAt,
      };

  factory PregnancySymptomRecord.fromMap(Map<String, dynamic> map) {
    List<String> parsed = [];
    try {
      final raw = map['symptoms_json'] as String?;
      if (raw != null && raw.isNotEmpty) {
        parsed = List<String>.from(jsonDecode(raw) as List);
      }
    } catch (_) {}
    return PregnancySymptomRecord(
      id: map['id'] as int?,
      pregnancyId: map['pregnancy_id'] as int,
      date: map['date'] as String,
      week: (map['week'] as int?) ?? 1,
      symptoms: parsed,
      severity: (map['severity'] as String?) ?? 'mild',
      waterCups: (map['water_cups'] as int?) ?? 0,
      folicAcidTaken: ((map['folic_acid_taken'] as int?) ?? 0) == 1,
      ironTaken: ((map['iron_taken'] as int?) ?? 0) == 1,
      calciumTaken: ((map['calcium_taken'] as int?) ?? 0) == 1,
      notes: (map['notes'] as String?) ?? '',
      createdAt: (map['created_at'] as String?) ?? '',
    );
  }
}

class FetalKickSessionRecord {
  final int? id;
  final int pregnancyId;
  final String date;
  final String startTime;
  final String endTime;
  final int durationSeconds;
  final int kicksCount;
  final String notes;
  final String createdAt;

  const FetalKickSessionRecord({
    this.id,
    required this.pregnancyId,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.durationSeconds,
    required this.kicksCount,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'date': date,
        'start_time': startTime,
        'end_time': endTime,
        'duration_seconds': durationSeconds,
        'kicks_count': kicksCount,
        'notes': notes,
        'created_at': createdAt,
      };

  factory FetalKickSessionRecord.fromMap(Map<String, dynamic> map) =>
      FetalKickSessionRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        date: map['date'] as String,
        startTime: (map['start_time'] as String?) ?? '',
        endTime: (map['end_time'] as String?) ?? '',
        durationSeconds: (map['duration_seconds'] as int?) ?? 0,
        kicksCount: (map['kicks_count'] as int?) ?? 0,
        notes: (map['notes'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class ContractionRecord {
  final int? id;
  final int pregnancyId;
  final String date;
  final String startTime;
  final String endTime;
  final int durationSeconds;
  final int? intervalSeconds;
  final String intensity; // 'mild' | 'moderate' | 'strong'
  final String createdAt;

  const ContractionRecord({
    this.id,
    required this.pregnancyId,
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.durationSeconds,
    this.intervalSeconds,
    required this.intensity,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'date': date,
        'start_time': startTime,
        'end_time': endTime,
        'duration_seconds': durationSeconds,
        'interval_seconds': intervalSeconds,
        'intensity': intensity,
        'created_at': createdAt,
      };

  factory ContractionRecord.fromMap(Map<String, dynamic> map) =>
      ContractionRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        date: map['date'] as String,
        startTime: (map['start_time'] as String?) ?? '',
        endTime: (map['end_time'] as String?) ?? '',
        durationSeconds: (map['duration_seconds'] as int?) ?? 0,
        intervalSeconds: map['interval_seconds'] as int?,
        intensity: (map['intensity'] as String?) ?? 'moderate',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class PregnancyAppointmentRecord {
  final int? id;
  final int pregnancyId;
  final String title;
  final String doctorOrLab;
  final String appointmentType; // 'checkup' | 'ultrasound' | 'lab' | 'vaccine'
  final String date; // YYYY-MM-DD
  final String time; // HH:mm
  final String notes;
  final bool reminderEnabled;
  final bool isCompleted;
  final int? notificationId;
  final String createdAt;

  const PregnancyAppointmentRecord({
    this.id,
    required this.pregnancyId,
    required this.title,
    required this.doctorOrLab,
    required this.appointmentType,
    required this.date,
    required this.time,
    required this.notes,
    required this.reminderEnabled,
    required this.isCompleted,
    this.notificationId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'title': title,
        'doctor_or_lab': doctorOrLab,
        'appointment_type': appointmentType,
        'date': date,
        'time': time,
        'notes': notes,
        'reminder_enabled': reminderEnabled ? 1 : 0,
        'is_completed': isCompleted ? 1 : 0,
        'notification_id': notificationId,
        'created_at': createdAt,
      };

  factory PregnancyAppointmentRecord.fromMap(Map<String, dynamic> map) =>
      PregnancyAppointmentRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        title: map['title'] as String,
        doctorOrLab: (map['doctor_or_lab'] as String?) ?? '',
        appointmentType: (map['appointment_type'] as String?) ?? 'checkup',
        date: map['date'] as String,
        time: (map['time'] as String?) ?? '10:00',
        notes: (map['notes'] as String?) ?? '',
        reminderEnabled: ((map['reminder_enabled'] as int?) ?? 1) == 1,
        isCompleted: ((map['is_completed'] as int?) ?? 0) == 1,
        notificationId: map['notification_id'] as int?,
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class HospitalBagItemRecord {
  final int? id;
  final int pregnancyId;
  final String category; // 'mother' | 'baby' | 'documents'
  final String itemName;
  final bool isPacked;
  final String createdAt;

  const HospitalBagItemRecord({
    this.id,
    required this.pregnancyId,
    required this.category,
    required this.itemName,
    required this.isPacked,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'category': category,
        'item_name': itemName,
        'is_packed': isPacked ? 1 : 0,
        'created_at': createdAt,
      };

  factory HospitalBagItemRecord.fromMap(Map<String, dynamic> map) =>
      HospitalBagItemRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        category: (map['category'] as String?) ?? 'mother',
        itemName: map['item_name'] as String,
        isPacked: ((map['is_packed'] as int?) ?? 0) == 1,
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class PregnancyNoteRecord {
  final int? id;
  final int pregnancyId;
  final int week;
  final String date;
  final String title;
  final String content;
  final String createdAt;

  const PregnancyNoteRecord({
    this.id,
    required this.pregnancyId,
    required this.week,
    required this.date,
    required this.title,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'pregnancy_id': pregnancyId,
        'week': week,
        'date': date,
        'title': title,
        'content': content,
        'created_at': createdAt,
      };

  factory PregnancyNoteRecord.fromMap(Map<String, dynamic> map) =>
      PregnancyNoteRecord(
        id: map['id'] as int?,
        pregnancyId: map['pregnancy_id'] as int,
        week: (map['week'] as int?) ?? 1,
        date: map['date'] as String,
        title: (map['title'] as String?) ?? '',
        content: map['content'] as String,
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class PregnancyReminderSetting {
  final String reminderKey; // 'folic_iron' | 'water' | 'kicks' | 'dua'
  final String title;
  final String subtitle;
  final String time; // HH:mm
  final bool enabled;
  final int notificationId;

  const PregnancyReminderSetting({
    required this.reminderKey,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.enabled,
    required this.notificationId,
  });

  Map<String, dynamic> toMap() => {
        'reminder_key': reminderKey,
        'title': title,
        'subtitle': subtitle,
        'time': time,
        'enabled': enabled ? 1 : 0,
        'notification_id': notificationId,
      };

  factory PregnancyReminderSetting.fromMap(Map<String, dynamic> map) =>
      PregnancyReminderSetting(
        reminderKey: map['reminder_key'] as String,
        title: map['title'] as String,
        subtitle: (map['subtitle'] as String?) ?? '',
        time: (map['time'] as String?) ?? '09:00',
        enabled: ((map['enabled'] as int?) ?? 0) == 1,
        notificationId: (map['notification_id'] as int?) ?? 7100,
      );
}

class PregnancySqliteService {
  PregnancySqliteService._();
  static final PregnancySqliteService instance = PregnancySqliteService._();

  Database? _db;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  bool _tzInitialized = false;

  Future<void> initRealNotifications() async {
    await NotificationManager.init();
    if (!_tzInitialized) {
      tz_data.initializeTimeZones();
      _tzInitialized = true;
    }
  }

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'rifq_pregnancy_journey_v1.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE pregnancy_profile (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            calculation_method TEXT NOT NULL,
            lmp_date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            pre_pregnancy_weight REAL,
            height_cm REAL,
            blood_type TEXT,
            doctor_name TEXT,
            hospital_name TEXT,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pregnancy_weights (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            week INTEGER NOT NULL,
            weight_kg REAL NOT NULL,
            blood_pressure TEXT,
            notes TEXT,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pregnancy_symptoms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            week INTEGER NOT NULL,
            symptoms_json TEXT NOT NULL,
            severity TEXT NOT NULL,
            water_cups INTEGER NOT NULL DEFAULT 0,
            folic_acid_taken INTEGER NOT NULL DEFAULT 0,
            iron_taken INTEGER NOT NULL DEFAULT 0,
            calcium_taken INTEGER NOT NULL DEFAULT 0,
            notes TEXT,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE fetal_kicks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL,
            kicks_count INTEGER NOT NULL,
            notes TEXT,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE contractions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            duration_seconds INTEGER NOT NULL,
            interval_seconds INTEGER,
            intensity TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pregnancy_appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            doctor_or_lab TEXT,
            appointment_type TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            notes TEXT,
            reminder_enabled INTEGER NOT NULL DEFAULT 1,
            is_completed INTEGER NOT NULL DEFAULT 0,
            notification_id INTEGER,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE hospital_bag_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            item_name TEXT NOT NULL,
            is_packed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pregnancy_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pregnancy_id INTEGER NOT NULL,
            week INTEGER NOT NULL,
            date TEXT NOT NULL,
            title TEXT,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');

        await db.execute('''
          CREATE TABLE pregnancy_reminders (
            reminder_key TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            subtitle TEXT NOT NULL,
            time TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 0,
            notification_id INTEGER NOT NULL
          )
        ''');

        // إدراج إعدادات التذكيرات الـ 4 مغلقة افتراضياً (تفعّلها المستخدمة باختيارها)
        final defaultReminders = [
          const PregnancyReminderSetting(
            reminderKey: 'folic_iron',
            title: 'تذكير فيتامينات الحمل وحمض الفوليك',
            subtitle: 'تذكير يومي بمكملاتكِ الموصوفة من الطبيبة',
            time: '10:00',
            enabled: false,
            notificationId: 7101,
          ),
          const PregnancyReminderSetting(
            reminderKey: 'water',
            title: 'تذكير شرب الماء والترطيب',
            subtitle: 'للحفاظ على ترطيب جسمكِ والسائل الأمنيوسي',
            time: '13:00',
            enabled: false,
            notificationId: 7102,
          ),
          const PregnancyReminderSetting(
            reminderKey: 'kicks',
            title: 'تذكير متابعة وعدّ حركات الجنين',
            subtitle: 'وقت هادئ للاطمئنان على نشاط جنينكِ اليومي',
            time: '20:00',
            enabled: false,
            notificationId: 7103,
          ),
          const PregnancyReminderSetting(
            reminderKey: 'dua',
            title: 'تذكير دعاء الحامل وورد السكينة',
            subtitle: 'لحظات إيمانية للدعاء بحفظ جنينكِ وتيسير حملكِ',
            time: '17:00',
            enabled: false,
            notificationId: 7104,
          ),
        ];

        for (final r in defaultReminders) {
          await db.insert('pregnancy_reminders', r.toMap());
        }
      },
    );
    return _db!;
  }

  /// حساب عمر الحمل تلقائياً من تاريخ آخر دورة (LMP) أو موعد الولادة المتوقع (EDD)
  static PregnancyCalculationResult calculatePregnancy(
      PregnancyProfileModel profile) {
    final lmp = DateTime.parse(profile.lmpDate);
    final due = DateTime.parse(profile.dueDate);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final lmpClean = DateTime(lmp.year, lmp.month, lmp.day);
    final dueClean = DateTime(due.year, due.month, due.day);

    final daysPassed = today.difference(lmpClean).inDays.clamp(0, 294);
    final week = ((daysPassed ~/ 7) + 1).clamp(1, 40);
    final extraDays = daysPassed % 7;
    final remaining = dueClean.difference(today).inDays.clamp(0, 280);
    final progress = ((daysPassed / 280.0) * 100.0).clamp(0.0, 100.0);

    int trimester = 1;
    String trimesterTitle = 'الثلث الأول';
    if (week >= 28) {
      trimester = 3;
      trimesterTitle = 'الثلث الثالث';
    } else if (week >= 14) {
      trimester = 2;
      trimesterTitle = 'الثلث الثاني';
    }

    return PregnancyCalculationResult(
      currentWeek: week,
      extraDays: extraDays,
      totalDaysPassed: daysPassed,
      remainingDays: remaining,
      progressPercent: progress,
      trimester: trimester,
      trimesterTitle: trimesterTitle,
      lmpDate: lmpClean,
      dueDate: dueClean,
    );
  }

  // ── 1. ملف الحمل (Profile) ──
  Future<PregnancyProfileModel?> getActiveProfile() async {
    final db = await database;
    final rows =
        await db.query('pregnancy_profile', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return null;
    return PregnancyProfileModel.fromMap(rows.first);
  }

  Future<int> saveOrReplaceProfile(PregnancyProfileModel profile) async {
    final db = await database;
    await db.delete('pregnancy_profile');
    final id = await db.insert('pregnancy_profile', profile.toMap());

    // تهيئة حقيبة الولادة القياسية إذا كانت فارغة لهذا الحمل
    final existingBag = await db.query(
      'hospital_bag_items',
      where: 'pregnancy_id = ?',
      whereArgs: [id],
    );
    if (existingBag.isEmpty) {
      final nowIso = DateTime.now().toIso8601String();
      for (final entry in PregnancyMedicalData.defaultHospitalBagItems.entries) {
        for (final item in entry.value) {
          await db.insert(
            'hospital_bag_items',
            HospitalBagItemRecord(
              pregnancyId: id,
              category: entry.key,
              itemName: item,
              isPacked: false,
              createdAt: nowIso,
            ).toMap(),
          );
        }
      }
    }
    return id;
  }

  // ── 2. الوزن والقياسات الحيوية ──
  Future<int> insertWeight(PregnancyWeightRecord record) async {
    final db = await database;
    return db.insert('pregnancy_weights', record.toMap());
  }

  Future<List<PregnancyWeightRecord>> getWeights(int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'pregnancy_weights',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'date ASC, id ASC',
    );
    return rows.map((r) => PregnancyWeightRecord.fromMap(r)).toList();
  }

  Future<void> deleteWeight(int id) async {
    final db = await database;
    await db.delete('pregnancy_weights', where: 'id = ?', whereArgs: [id]);
  }

  // ── 3. الأعراض والماء والفيتامينات ──
  Future<int> insertSymptomRecord(PregnancySymptomRecord record) async {
    final db = await database;
    return db.insert('pregnancy_symptoms', record.toMap());
  }

  Future<List<PregnancySymptomRecord>> getSymptomRecords(int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'pregnancy_symptoms',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map((r) => PregnancySymptomRecord.fromMap(r)).toList();
  }

  Future<void> deleteSymptomRecord(int id) async {
    final db = await database;
    await db.delete('pregnancy_symptoms', where: 'id = ?', whereArgs: [id]);
  }

  // ── 4. عداد حركات الجنين (Kicks) ──
  Future<int> insertKickSession(FetalKickSessionRecord record) async {
    final db = await database;
    return db.insert('fetal_kicks', record.toMap());
  }

  Future<List<FetalKickSessionRecord>> getKickSessions(int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'fetal_kicks',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'id DESC',
    );
    return rows.map((r) => FetalKickSessionRecord.fromMap(r)).toList();
  }

  Future<void> deleteKickSession(int id) async {
    final db = await database;
    await db.delete('fetal_kicks', where: 'id = ?', whereArgs: [id]);
  }

  // ── 5. مؤقت الانقباضات (Contractions) ──
  Future<int> insertContraction(ContractionRecord record) async {
    final db = await database;
    return db.insert('contractions', record.toMap());
  }

  Future<List<ContractionRecord>> getContractions(int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'contractions',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'id DESC',
    );
    return rows.map((r) => ContractionRecord.fromMap(r)).toList();
  }

  Future<void> deleteContraction(int id) async {
    final db = await database;
    await db.delete('contractions', where: 'id = ?', whereArgs: [id]);
  }

  // ── 6. مواعيد الطبيبة والفحوصات مع إشعارات حقيقية 100% ──
  Future<int> insertAppointment(PregnancyAppointmentRecord record) async {
    final db = await database;
    final id = await db.insert('pregnancy_appointments', record.toMap());
    if (record.reminderEnabled && !record.isCompleted) {
      await _scheduleAppointmentNotification(
        id: id,
        title: record.title,
        doctorOrLab: record.doctorOrLab,
        dateIso: record.date,
        timeHm: record.time,
      );
    }
    return id;
  }

  Future<List<PregnancyAppointmentRecord>> getAppointments(
      int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'pregnancy_appointments',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'date ASC, time ASC',
    );
    return rows.map((r) => PregnancyAppointmentRecord.fromMap(r)).toList();
  }

  Future<void> toggleAppointmentCompleted(int id, bool completed) async {
    final db = await database;
    await db.update(
      'pregnancy_appointments',
      {'is_completed': completed ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
    if (completed) {
      await _notifications.cancel(7500 + id);
    }
  }

  Future<void> deleteAppointment(int id) async {
    final db = await database;
    await _notifications.cancel(7500 + id);
    await db.delete('pregnancy_appointments', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> _scheduleAppointmentNotification({
    required int id,
    required String title,
    required String doctorOrLab,
    required String dateIso,
    required String timeHm,
  }) async {
    try {
      await initRealNotifications();
      final enabled = await NotificationManager.areNotificationsEnabled();
      if (!enabled) return;

      final dParts = dateIso.split('-');
      final tParts = timeHm.split(':');
      if (dParts.length != 3 || tParts.length < 2) return;

      final scheduled = DateTime(
        int.parse(dParts[0]),
        int.parse(dParts[1]),
        int.parse(dParts[2]),
        int.parse(tParts[0]),
        int.parse(tParts[1]),
      );

      if (scheduled.isBefore(DateTime.now())) return;
      final tzTime = tz.TZDateTime.from(scheduled, tz.local);

      await _notifications.zonedSchedule(
        7500 + id,
        'موعد متابعة الحمل — رحلتكِ',
        doctorOrLab.isNotEmpty ? '$title لدى $doctorOrLab' : title,
        tzTime,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            NotificationManager.remindersChannelId,
            'التذكيرات',
            channelDescription: 'مواعيد وتذكيرات متابعة الحمل في رفق للمرأة',
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (_) {}
  }

  // ── 7. حقيبة الولادة التفاعلية ──
  Future<List<HospitalBagItemRecord>> getHospitalBagItems(
      int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'hospital_bag_items',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'id ASC',
    );
    return rows.map((r) => HospitalBagItemRecord.fromMap(r)).toList();
  }

  Future<int> insertHospitalBagItem(HospitalBagItemRecord item) async {
    final db = await database;
    return db.insert('hospital_bag_items', item.toMap());
  }

  Future<void> toggleHospitalBagItem(int id, bool isPacked) async {
    final db = await database;
    await db.update(
      'hospital_bag_items',
      {'is_packed': isPacked ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteHospitalBagItem(int id) async {
    final db = await database;
    await db.delete('hospital_bag_items', where: 'id = ?', whereArgs: [id]);
  }

  // ── 8. مذكرات رحلتي (Journal) ──
  Future<int> insertNote(PregnancyNoteRecord note) async {
    final db = await database;
    return db.insert('pregnancy_notes', note.toMap());
  }

  Future<List<PregnancyNoteRecord>> getNotes(int pregnancyId) async {
    final db = await database;
    final rows = await db.query(
      'pregnancy_notes',
      where: 'pregnancy_id = ?',
      whereArgs: [pregnancyId],
      orderBy: 'id DESC',
    );
    return rows.map((r) => PregnancyNoteRecord.fromMap(r)).toList();
  }

  Future<void> deleteNote(int id) async {
    final db = await database;
    await db.delete('pregnancy_notes', where: 'id = ?', whereArgs: [id]);
  }

  // ── 9. التذكيرات اليومية الحقيقية ──
  Future<List<PregnancyReminderSetting>> getReminders() async {
    final db = await database;
    final rows = await db.query('pregnancy_reminders', orderBy: 'notification_id ASC');
    return rows.map((r) => PregnancyReminderSetting.fromMap(r)).toList();
  }

  Future<bool> updateReminder({
    required String reminderKey,
    required bool enabled,
    required String timeHm,
  }) async {
    final db = await database;
    await initRealNotifications();

    if (enabled) {
      bool permitted = await NotificationManager.areNotificationsEnabled();
      if (!permitted) {
        permitted = await NotificationManager.requestPermission();
      }
      if (!permitted) {
        return false;
      }
    }

    await db.update(
      'pregnancy_reminders',
      {
        'enabled': enabled ? 1 : 0,
        'time': timeHm,
      },
      where: 'reminder_key = ?',
      whereArgs: [reminderKey],
    );

    final rows = await db.query(
      'pregnancy_reminders',
      where: 'reminder_key = ?',
      whereArgs: [reminderKey],
      limit: 1,
    );
    if (rows.isEmpty) return false;
    final setting = PregnancyReminderSetting.fromMap(rows.first);

    if (enabled) {
      final parts = timeHm.split(':');
      final hour = int.tryParse(parts[0]) ?? 9;
      final minute = parts.length > 1 ? (int.tryParse(parts[1]) ?? 0) : 0;

      final now = tz.TZDateTime.now(tz.local);
      var scheduled =
          tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
      if (scheduled.isBefore(now)) {
        scheduled = scheduled.add(const Duration(days: 1));
      }

      await _notifications.zonedSchedule(
        setting.notificationId,
        setting.title,
        setting.subtitle,
        scheduled,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            NotificationManager.remindersChannelId,
            'التذكيرات',
            channelDescription: 'تذكيرات متابعة الحمل اليومية في رفق للمرأة',
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } else {
      await _notifications.cancel(setting.notificationId);
    }

    return true;
  }

  // ── مسح جميع بيانات الحمل بالكامل ──
  Future<void> wipeAllPregnancyData() async {
    final db = await database;
    await db.delete('pregnancy_profile');
    await db.delete('pregnancy_weights');
    await db.delete('pregnancy_symptoms');
    await db.delete('fetal_kicks');
    await db.delete('contractions');
    await db.delete('pregnancy_appointments');
    await db.delete('hospital_bag_items');
    await db.delete('pregnancy_notes');
    await db.update('pregnancy_reminders', {'enabled': 0});
    for (int id = 7101; id <= 7104; id++) {
      await _notifications.cancel(id);
    }
  }
}
