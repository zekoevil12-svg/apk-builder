import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'woman_data.dart';
import 'child_plant_screen.dart';
import 'child_plant_svg_widgets.dart';
import 'pregnancy_screen.dart';
import 'pregnancy_svg_widgets.dart';

class MuslimWomanScreen extends StatefulWidget {
  const MuslimWomanScreen({Key? key}) : super(key: key);

  @override
  State<MuslimWomanScreen> createState() => _MuslimWomanScreenState();
}

class _MuslimWomanScreenState extends State<MuslimWomanScreen> {
  // الهوية اللونية
  static const Color primaryGold = Color(0xFF5B5FEF);
  static const Color softPink = Color(0xFFE99AC7);
  static const Color deepBrown = Color(0xFF25263A);
  static const Color bgBeige = Color(0xFFF7F7FC);

  String _selectedTab = 'all'; // 'all', 'fiqh', 'women', 'duas', 'fatwa', 'favorites'
  Set<String> _favoriteIds = {};
  bool _isLoadingFavorites = true;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList('woman_favorites') ?? [];
      if (mounted) {
        setState(() {
          _favoriteIds = list.toSet();
          _isLoadingFavorites = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _isLoadingFavorites = false);
      }
    }
  }

  Future<void> _toggleFavorite(String id) async {
    HapticFeedback.lightImpact();
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (_favoriteIds.contains(id)) {
        _favoriteIds.remove(id);
      } else {
        _favoriteIds.add(id);
      }
    });
    await prefs.setStringList('woman_favorites', _favoriteIds.toList());
  }

  void _showToast(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle_outline, color: primaryGold, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: deepBrown,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: primaryGold.withOpacity(0.5)),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  List<WomanCategory> get _filteredCategories {
    if (_selectedTab == 'all') return MuslimWomanData.categories;
    if (_selectedTab == 'favorites') return MuslimWomanData.categories;
    return MuslimWomanData.categories
        .where((cat) => cat.mainTab == _selectedTab)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth >= 600;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF121212) : bgBeige,
        appBar: AppBar(
          backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: deepBrown),
            onPressed: () => Navigator.pop(context),
          ),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: const [
              Text('🌸', style: TextStyle(fontSize: 20)),
              SizedBox(width: 8),
              Text(
                'المرأة المسلمة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: deepBrown,
                ),
              ),
            ],
          ),
          centerTitle: true,
          actions: [
            IconButton(
              icon: const Icon(Icons.search, color: primaryGold),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WomanSearchScreen(
                      favoriteIds: _favoriteIds,
                      onToggleFavorite: _toggleFavorite,
                      showToast: _showToast,
                    ),
                  ),
                );
              },
            ),
            IconButton(
              icon: Icon(
                _selectedTab == 'favorites' ? Icons.star : Icons.star_border,
                color: primaryGold,
              ),
              onPressed: () {
                setState(() {
                  _selectedTab = _selectedTab == 'favorites' ? 'all' : 'favorites';
                });
              },
            ),
          ],
        ),
        body: _selectedTab == 'favorites'
            ? _buildFavoritesView(isDark)
            : CustomScrollView(
                slivers: [
                  // بطاقة الترحيب والآية القرآنية
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white,
                              softPink.withOpacity(0.18),
                            ],
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                          ),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: primaryGold.withOpacity(0.35)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.04),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 24,
                                  height: 1.5,
                                  color: primaryGold,
                                ),
                                const Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 8),
                                  child: Text('🌷', style: TextStyle(fontSize: 16)),
                                ),
                                Container(
                                  width: 24,
                                  height: 1.5,
                                  color: primaryGold,
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              '﴿وَمَن يَعْمَلْ مِنَ الصَّالِحَاتِ مِن ذَكَرٍ أَوْ أُنثَىٰ وَهُوَ مُؤْمِنٌ فَأُولَٰئِكَ يَدْخُلُونَ الْجَنَّةَ وَلَا يُظْلَمُونَ نَقِيرًا﴾',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: deepBrown,
                                height: 1.6,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'سورة النساء: الآية 124 • فقه وسير وأدعية موثقة',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 12,
                                color: primaryGold.withOpacity(0.9),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // شريط التبويبات الفئوية
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          children: [
                            _buildTabChip('all', 'الكل (21)'),
                            _buildTabChip('fiqh', '🕌 فقه المرأة'),
                            _buildTabChip('women', '📜 نساء خالدات'),
                            _buildTabChip('duas', '🤲 أدعية'),
                            _buildTabChip('fatwa', '⚖️ فتاوى'),
                            _buildTabChip('favorites', '⭐ المفضلة (${_favoriteIds.length})'),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // قسم الحمل المستقل «رحلتك» داخل قسم رفق للمرأة (بدون شارة وبأيقونة SVG حقيقية)
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const PregnancyJourneyScreen(),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: primaryGold),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEEEEFF),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: primaryGold.withOpacity(0.5)),
                                ),
                                alignment: Alignment.center,
                                child: PregnancySvgIcons.journeyHeader(size: 26),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'الحمل — رحلتكِ',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDark ? Colors.white : deepBrown,
                                      ),
                                    ),
                                    const Text(
                                      'تتبع الحمل لـ 40 أسبوعاً، حجم الجنين، عداد الحركات، الانقباضات، المواعيد، وحقيبة الولادة',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 12,
                                        color: Color(0xFF77798C),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.arrow_forward_ios, size: 16, color: primaryGold),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // قسم نبتة طفلي المستقل داخل شبكة أقسام قسم المرأة (بدون شارة وبأيقونة SVG حقيقية)
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ChildPlantScreen(),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: softPink),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEEEEFF),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: primaryGold.withOpacity(0.5)),
                                ),
                                alignment: Alignment.center,
                                child: ChildPlantSvgIcons.sprout(size: 24),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'نبتة طفلي',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                        color: isDark ? Colors.white : deepBrown,
                                      ),
                                    ),
                                    const Text(
                                      'متابعة عمر الطفل، قياسات النمو، الرسوم البيانية، والمواعيد بخصوصية كاملة',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 12,
                                        color: Color(0xFF77798C),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.arrow_forward_ios, size: 16, color: primaryGold),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // شبكة التصنيفات
                  SliverPadding(
                    padding: const EdgeInsets.all(16),
                    sliver: SliverGrid(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: isTablet ? 3 : 2,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: isTablet ? 1.15 : 0.98,
                      ),
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          final category = _filteredCategories[index];
                          final count = MuslimWomanData.allItems
                              .where((item) => item.categoryId == category.id)
                              .length;

                          return _buildCategoryCard(category, count, isDark);
                        },
                        childCount: _filteredCategories.length,
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildTabChip(String id, String label) {
    final isSelected = _selectedTab == id;
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _selectedTab = id);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? primaryGold : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected ? primaryGold : primaryGold.withOpacity(0.3),
              width: 1.2,
            ),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: primaryGold.withOpacity(0.3),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : [],
          ),
          child: Text(
            label,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 12.5,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.w600,
              color: isSelected ? Colors.white : deepBrown,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(WomanCategory category, int count, bool isDark) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => WomanCategoryDetailScreen(
              category: category,
              favoriteIds: _favoriteIds,
              onToggleFavorite: _toggleFavorite,
              showToast: _showToast,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: primaryGold.withOpacity(0.24),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // أيقونة دائرية 60px بلمسة وردية ذهبية
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    category.themeColor.withOpacity(0.2),
                    softPink.withOpacity(0.25),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: primaryGold.withOpacity(0.35),
                  width: 1.5,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                category.icon,
                style: const TextStyle(fontSize: 28),
              ),
            ),
            const SizedBox(height: 10),
            // عنوان التصنيف
            Text(
              category.title,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: deepBrown,
              ),
            ),
            const SizedBox(height: 4),
            // عدد العناصر
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: bgBeige,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                count > 0 ? '$count موضوع موثق' : 'محتوى شامل',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 10.5,
                  fontWeight: FontWeight.w600,
                  color: primaryGold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFavoritesView(bool isDark) {
    final favItems = MuslimWomanData.allItems
        .where((item) => _favoriteIds.contains(item.id))
        .toList();

    if (favItems.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Text('⭐', style: TextStyle(fontSize: 48)),
            SizedBox(height: 12),
            Text(
              'لا توجد عناصر محفوظة في المفضلة بعد',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: deepBrown,
              ),
            ),
            SizedBox(height: 6),
            Text(
              'اضغطي على علامة النجمة في أي موضوع لحفظه هنا',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 13,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: favItems.length,
      itemBuilder: (context, index) {
        final item = favItems[index];
        return _buildItemCard(item, isDark);
      },
    );
  }

  Widget _buildItemCard(WomanContentItem item, bool isDark) {
    final isFav = _favoriteIds.contains(item.id);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryGold.withOpacity(0.24)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WomanItemDetailScreen(
                item: item,
                isFavorite: isFav,
                onToggleFavorite: () => _toggleFavorite(item.id),
                showToast: _showToast,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      item.title,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: deepBrown,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      isFav ? Icons.star : Icons.star_border,
                      color: primaryGold,
                    ),
                    onPressed: () => _toggleFavorite(item.id),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                item.arabicText,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 15,
                  height: 1.5,
                  color: deepBrown,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'المصدر: ${item.source}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 11,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.copy_rounded, size: 18, color: primaryGold),
                    onPressed: () {
                      Clipboard.setData(ClipboardData(
                        text: '${item.title}\n\n${item.arabicText}\n\nالمصدر: ${item.source}\n(تطبيق رِفْق | قسم المرأة المسلمة)',
                      ));
                      _showToast('تم نسخ النص بنجاح 📋');
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// شاشة قائمة عناصر تصنيف معين
class WomanCategoryDetailScreen extends StatefulWidget {
  final WomanCategory category;
  final Set<String> favoriteIds;
  final Function(String) onToggleFavorite;
  final Function(String) showToast;

  const WomanCategoryDetailScreen({
    Key? key,
    required this.category,
    required this.favoriteIds,
    required this.onToggleFavorite,
    required this.showToast,
  }) : super(key: key);

  @override
  State<WomanCategoryDetailScreen> createState() => _WomanCategoryDetailScreenState();
}

class _WomanCategoryDetailScreenState extends State<WomanCategoryDetailScreen> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final items = MuslimWomanData.allItems
        .where((i) => i.categoryId == widget.category.id)
        .where((i) =>
            _searchQuery.isEmpty ||
            i.title.contains(_searchQuery) ||
            i.arabicText.contains(_searchQuery))
        .toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF121212) : const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Color(0xFF25263A)),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            widget.category.title,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Color(0xFF25263A),
            ),
          ),
          centerTitle: true,
        ),
        body: Column(
          children: [
            // شريط البحث الموضعي
            Padding(
              padding: const EdgeInsets.all(14),
              child: TextField(
                onChanged: (val) => setState(() => _searchQuery = val.trim()),
                decoration: InputDecoration(
                  hintText: 'ابحث في ${widget.category.title}...',
                  hintStyle: const TextStyle(fontFamily: 'Cairo', fontSize: 13),
                  prefixIcon: const Icon(Icons.search, color: Color(0xFF5B5FEF)),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: const Color(0xFF5B5FEF).withOpacity(0.3)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: const Color(0xFF5B5FEF).withOpacity(0.3)),
                  ),
                ),
              ),
            ),
            Expanded(
              child: items.isEmpty
                  ? Center(
                      child: Text(
                        'لا توجد نتائج مطابقة',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          color: Colors.grey.shade600,
                          fontSize: 14,
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        final item = items[index];
                        final isFav = widget.favoriteIds.contains(item.id);

                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: const Color(0xFF5B5FEF).withOpacity(0.24)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(16),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => WomanItemDetailScreen(
                                    item: item,
                                    isFavorite: isFav,
                                    onToggleFavorite: () {
                                      widget.onToggleFavorite(item.id);
                                      setState(() {});
                                    },
                                    showToast: widget.showToast,
                                  ),
                                ),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Text(
                                          item.title,
                                          style: const TextStyle(
                                            fontFamily: 'Cairo',
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                            color: Color(0xFF25263A),
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(
                                          isFav ? Icons.star : Icons.star_border,
                                          color: const Color(0xFF5B5FEF),
                                        ),
                                        onPressed: () {
                                          widget.onToggleFavorite(item.id);
                                          setState(() {});
                                        },
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item.arabicText,
                                    maxLines: 4,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontFamily: 'Amiri',
                                      fontSize: 15,
                                      height: 1.6,
                                      color: Color(0xFF25263A),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    'المصدر: ${item.source}',
                                    style: const TextStyle(
                                      fontFamily: 'Cairo',
                                      fontSize: 11,
                                      color: Colors.grey,
                                    ),
                                  ),
                                  const Divider(height: 18),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      TextButton.icon(
                                        onPressed: () {
                                          Clipboard.setData(ClipboardData(
                                            text: '${item.title}\n\n${item.arabicText}\n\nالمصدر: ${item.source}',
                                          ));
                                          widget.showToast('تم نسخ النص بنجاح 📋');
                                        },
                                        icon: const Icon(Icons.copy, size: 16, color: Color(0xFF5B5FEF)),
                                        label: const Text(
                                          'نسخ',
                                          style: TextStyle(
                                            fontFamily: 'Cairo',
                                            fontSize: 12,
                                            color: Color(0xFF5B5FEF),
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      TextButton.icon(
                                        onPressed: () {
                                          Clipboard.setData(ClipboardData(
                                            text: '${item.title}\n\n${item.arabicText}\n\nالمصدر: ${item.source}\n(تطبيق رِفْق | قسم المرأة المسلمة)',
                                          ));
                                          widget.showToast('تم تجهيز النص للمشاركة 📤');
                                        },
                                        icon: const Icon(Icons.share, size: 16, color: Color(0xFF5B5FEF)),
                                        label: const Text(
                                          'مشاركة',
                                          style: TextStyle(
                                            fontFamily: 'Cairo',
                                            fontSize: 12,
                                            color: Color(0xFF5B5FEF),
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// شاشة تفاصيل العنصر مع تكبير وتصغير الخط والشرح الكامل والفوائد
class WomanItemDetailScreen extends StatefulWidget {
  final WomanContentItem item;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;
  final Function(String) showToast;

  const WomanItemDetailScreen({
    Key? key,
    required this.item,
    required this.isFavorite,
    required this.onToggleFavorite,
    required this.showToast,
  }) : super(key: key);

  @override
  State<WomanItemDetailScreen> createState() => _WomanItemDetailScreenState();
}

class _WomanItemDetailScreenState extends State<WomanItemDetailScreen> {
  double _fontScale = 1.0;
  late bool _fav;

  @override
  void initState() {
    super.initState();
    _fav = widget.isFavorite;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const goldColor = Color(0xFF5B5FEF);
    const deepBrown = Color(0xFF25263A);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF121212) : const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: deepBrown),
            onPressed: () => Navigator.pop(context),
          ),
          title: Text(
            widget.item.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: deepBrown,
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(
                _fav ? Icons.star : Icons.star_border,
                color: goldColor,
              ),
              onPressed: () {
                setState(() => _fav = !_fav);
                widget.onToggleFavorite();
              },
            ),
            IconButton(
              icon: const Icon(Icons.copy_rounded, color: goldColor),
              onPressed: () {
                Clipboard.setData(ClipboardData(
                  text: '${widget.item.title}\n\n${widget.item.arabicText}\n\nالمصدر: ${widget.item.source}\n(تطبيق رِفْق | قسم المرأة المسلمة)',
                ));
                widget.showToast('تم نسخ النص والمصدر بنجاح 📋');
              },
            ),
          ],
        ),
        bottomNavigationBar: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              // زر تكبير الخط
              IconButton(
                icon: const Icon(Icons.text_increase, color: goldColor),
                onPressed: () {
                  setState(() {
                    if (_fontScale < 1.4) _fontScale += 0.1;
                  });
                },
                tooltip: 'تكبير الخط',
              ),
              // زر تصغير الخط
              IconButton(
                icon: const Icon(Icons.text_decrease, color: goldColor),
                onPressed: () {
                  setState(() {
                    if (_fontScale > 0.8) _fontScale -= 0.1;
                  });
                },
                tooltip: 'تصغير الخط',
              ),
              // زر نسخ
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: goldColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Clipboard.setData(ClipboardData(
                    text: '${widget.item.title}\n\n${widget.item.arabicText}\n\nالمصدر: ${widget.item.source}\n(تطبيق رِفْق | قسم المرأة المسلمة)',
                  ));
                  widget.showToast('تم نسخ النص بنجاح 📋');
                },
                icon: const Icon(Icons.copy, size: 16),
                label: const Text('نسخ', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
              ),
              // زر مشاركة
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: deepBrown,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Clipboard.setData(ClipboardData(
                    text: '${widget.item.title}\n\n${widget.item.arabicText}\n\nالمصدر: ${widget.item.source}\n(تطبيق رِفْق | قسم المرأة المسلمة)',
                  ));
                  widget.showToast('تم تجهيز النص ومشاركته 📤');
                },
                icon: const Icon(Icons.share, size: 16),
                label: const Text('مشاركة', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // بطاقة النص الأصلي الموثق
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: goldColor.withOpacity(0.35)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.item.title,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 18 * _fontScale,
                        color: deepBrown,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      widget.item.arabicText,
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 18 * _fontScale,
                        height: 1.7,
                        color: deepBrown,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F7FC),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '📚 المصدر: ${widget.item.source}',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12 * _fontScale,
                          fontWeight: FontWeight.w600,
                          color: goldColor,
                        ),
                      ),
                    ),
                    if (widget.item.scholar != null) ...[
                      const SizedBox(height: 6),
                      Text(
                        'العالم: ${widget.item.scholar}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              // الشرح والبيان
              if (widget.item.explanation != null) ...[
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE99AC7).withOpacity(0.5)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.lightbulb_outline, color: goldColor, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'الشرح والبيان الفقهي',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: deepBrown,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        widget.item.explanation!,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 14 * _fontScale,
                          height: 1.6,
                          color: deepBrown.withOpacity(0.9),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              // الفوائد والاستنباطات
              if (widget.item.benefits != null && widget.item.benefits!.isNotEmpty) ...[
                const SizedBox(height: 16),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: goldColor.withOpacity(0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.check_circle_outline, color: goldColor, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'الفوائد والدروس المستفادة',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: deepBrown,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      ...widget.item.benefits!.map(
                        (b) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('• ', style: TextStyle(color: goldColor, fontSize: 16, fontWeight: FontWeight.bold)),
                              Expanded(
                                child: Text(
                                  b,
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 13.5 * _fontScale,
                                    height: 1.5,
                                    color: deepBrown,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

/// شاشة البحث في كل محتوى المرأة المسلمة
class WomanSearchScreen extends StatefulWidget {
  final Set<String> favoriteIds;
  final Function(String) onToggleFavorite;
  final Function(String) showToast;

  const WomanSearchScreen({
    Key? key,
    required this.favoriteIds,
    required this.onToggleFavorite,
    required this.showToast,
  }) : super(key: key);

  @override
  State<WomanSearchScreen> createState() => _WomanSearchScreenState();
}

class _WomanSearchScreenState extends State<WomanSearchScreen> {
  String _query = '';
  String _selectedCatId = 'all';

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final results = MuslimWomanData.allItems.where((item) {
      final matchesQuery = _query.isEmpty ||
          item.title.contains(_query) ||
          item.arabicText.contains(_query) ||
          item.source.contains(_query) ||
          (item.explanation != null && item.explanation!.contains(_query));
      final matchesCat = _selectedCatId == 'all' || item.categoryId == _selectedCatId;
      return matchesQuery && matchesCat;
    }).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF121212) : const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Color(0xFF25263A)),
            onPressed: () => Navigator.pop(context),
          ),
          title: TextField(
            autofocus: true,
            onChanged: (val) => setState(() => _query = val.trim()),
            decoration: const InputDecoration(
              hintText: 'ابحث في الأحكام، السير، الفتاوى، الأدعية...',
              hintStyle: TextStyle(fontFamily: 'Cairo', fontSize: 13),
              border: InputBorder.none,
            ),
          ),
        ),
        body: Column(
          children: [
            // فلتر التصنيفات السريع
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  _buildCatFilterChip('all', 'الكل'),
                  ...MuslimWomanData.categories.map((c) => _buildCatFilterChip(c.id, c.title)),
                ],
              ),
            ),
            Expanded(
              child: results.isEmpty
                  ? Center(
                      child: Text(
                        _query.isEmpty ? 'اكتبي كلمة البحث للبدء' : 'لا توجد نتائج مطابقة لبحثك',
                        style: const TextStyle(fontFamily: 'Cairo', color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(14),
                      itemCount: results.length,
                      itemBuilder: (context, index) {
                        final item = results[index];
                        final isFav = widget.favoriteIds.contains(item.id);

                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFF5B5FEF).withOpacity(0.25)),
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(12),
                            title: Text(
                              item.title,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                                color: Color(0xFF25263A),
                              ),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text(
                                  item.arabicText,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: 'Amiri',
                                    fontSize: 14,
                                    color: Color(0xFF25263A),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'المصدر: ${item.source}',
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 11,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                            trailing: IconButton(
                              icon: Icon(
                                isFav ? Icons.star : Icons.star_border,
                                color: const Color(0xFF5B5FEF),
                              ),
                              onPressed: () {
                                widget.onToggleFavorite(item.id);
                                setState(() {});
                              },
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => WomanItemDetailScreen(
                                    item: item,
                                    isFavorite: isFav,
                                    onToggleFavorite: () {
                                      widget.onToggleFavorite(item.id);
                                      setState(() {});
                                    },
                                    showToast: widget.showToast,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCatFilterChip(String id, String label) {
    final isSelected = _selectedCatId == id;
    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: FilterChip(
        selected: isSelected,
        label: Text(
          label,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 11.5,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.white : const Color(0xFF25263A),
          ),
        ),
        selectedColor: const Color(0xFF5B5FEF),
        backgroundColor: Colors.white,
        onSelected: (val) => setState(() => _selectedCatId = id),
      ),
    );
  }
}
