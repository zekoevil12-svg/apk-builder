import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'child_plant_db.dart';
import 'child_plant_svg_widgets.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// ميزة «نبتة طفلي» المتكاملة داخل قسم «رِفْق للمرأة» (Flutter - Android/iOS)
/// - 9 شاشات متكاملة بدون أي بيانات وهمية أو إشعارات وهمية
/// - قاعدة بيانات SQLite حقيقية (5 جداول) + إشعارات محلية حقيقية + رسوم fl_chart
/// ══════════════════════════════════════════════════════════════════════════

class ChildPlantScreen extends StatefulWidget {
  const ChildPlantScreen({super.key});

  @override
  State<ChildPlantScreen> createState() => _ChildPlantScreenState();
}

class _ChildPlantScreenState extends State<ChildPlantScreen> {
  // الهوية اللونية الرسمية لقسم المرأة
  static const Color kBeige = Color(0xFFF7F7FC);
  static const Color kSoftPink = Color(0xFFE99AC7);
  static const Color kLightPink = Color(0xFFEEEEFF);
  static const Color kGold = Color(0xFF5B5FEF);
  static const Color kBrown = Color(0xFF25263A);
  static const Color kGrey = Color(0xFF77798C);
  static const Color kGreen = Color(0xFF4CAF82);

  final ChildPlantSqliteService _dbService = ChildPlantSqliteService.instance;
  final ImagePicker _imagePicker = ImagePicker();

  String _activeView = 'main'; // main, add_child, measurements, charts, stages, appointments, activities, notes, children
  bool _isLoading = true;
  bool _darkMode = false;
  bool _pinEnabled = false;
  String? _savedPin;
  bool _isUnlocked = true;

  List<ChildRecordModel> _children = [];
  ChildRecordModel? _selectedChild;
  List<MeasurementRecordModel> _measurements = [];
  List<AppointmentRecordModel> _appointments = [];
  List<NoteRecordModel> _notes = [];
  List<ActivityRecordModel> _activities = [];

  // حقول الشاشة 1: إضافة طفل
  final TextEditingController _nameCtrl = TextEditingController();
  DateTime? _selectedBirthDate;
  String _selectedGender = 'male';
  String? _selectedPhotoPath;
  final TextEditingController _heightCtrl = TextEditingController();
  final TextEditingController _weightCtrl = TextEditingController();
  final TextEditingController _headCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _initializeAll();
  }

  Future<void> _initializeAll() async {
    await _dbService.initRealNotifications();
    final prefs = await SharedPreferences.getInstance();
    _darkMode = prefs.getBool('child_plant_dark_mode') ?? false;
    _pinEnabled = prefs.getBool('child_plant_pin_enabled') ?? false;
    _savedPin = prefs.getString('child_plant_pin_code');
    _isUnlocked = !_pinEnabled;
    await _reloadDatabase();
  }

  Future<void> _reloadDatabase({int? preferChildId}) async {
    final children = await _dbService.getChildren();
    ChildRecordModel? current;
    if (children.isNotEmpty) {
      final targetId = preferChildId ?? _selectedChild?.id ?? children.first.id;
      current = children.firstWhere(
        (c) => c.id == targetId,
        orElse: () => children.first,
      );
    }

    List<MeasurementRecordModel> meas = [];
    List<AppointmentRecordModel> appts = [];
    List<NoteRecordModel> notes = [];
    List<ActivityRecordModel> acts = [];

    if (current?.id != null) {
      meas = await _dbService.getMeasurements(current!.id!);
      appts = await _dbService.getAppointments(current.id!);
      notes = await _dbService.getNotes(current.id!);
      acts = await _dbService.getActivities(current.id!);
    }

    if (mounted) {
      setState(() {
        _children = children;
        _selectedChild = current;
        _measurements = meas;
        _appointments = appts;
        _notes = notes;
        _activities = acts;
        _isLoading = false;
        if (_children.isEmpty) {
          _activeView = 'add_child';
        }
      });
    }
  }

  String _formatDateDMY(String isoDate) {
    final parts = isoDate.split('-');
    if (parts.length == 3) {
      return '${parts[2]}/${parts[1]}/${parts[0]}';
    }
    return isoDate;
  }

  String _todayIso() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  void _showStatusBanner(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: kGreen,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _pickChildPhoto() async {
    final picked = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (picked != null && mounted) {
      setState(() {
        _selectedPhotoPath = picked.path;
      });
    }
  }

  Future<void> _saveNewChild() async {
    final name = _nameCtrl.text.trim();
    final validNameReg = RegExp(r'^[\u0600-\u06FFa-zA-Z0-9\s\-_.]*$');
    if (name.isNotEmpty && !validNameReg.hasMatch(name)) {
      _showStatusBanner('الاسم لا يجب أن يحتوي على رموز غريبة');
      return;
    }

    if (_selectedBirthDate == null) {
      _showStatusBanner('يرجى اختيار تاريخ الميلاد (حقل إلزامي)');
      return;
    }

    if (_selectedBirthDate!.isAfter(DateTime.now())) {
      _showStatusBanner('تاريخ الميلاد لا يمكن أن يكون في المستقبل');
      return;
    }

    final h = _heightCtrl.text.trim().isNotEmpty
        ? double.tryParse(_heightCtrl.text.trim())
        : null;
    final w = _weightCtrl.text.trim().isNotEmpty
        ? double.tryParse(_weightCtrl.text.trim())
        : null;
    final hc = _headCtrl.text.trim().isNotEmpty
        ? double.tryParse(_headCtrl.text.trim())
        : null;

    if ((h != null && h <= 0) ||
        (w != null && w <= 0) ||
        (hc != null && hc <= 0)) {
      _showStatusBanner('الأرقام المدخلة يجب أن تكون موجبة');
      return;
    }

    final bStr =
        '${_selectedBirthDate!.year}-${_selectedBirthDate!.month.toString().padLeft(2, '0')}-${_selectedBirthDate!.day.toString().padLeft(2, '0')}';
    final nowIso = DateTime.now().toIso8601String();

    final childId = await _dbService.insertChild(
      ChildRecordModel(
        name: name.isEmpty ? 'طفلي' : name,
        birthDate: bStr,
        gender: _selectedGender,
        photoPath: _selectedPhotoPath,
        createdAt: nowIso,
      ),
    );

    if (h != null || w != null || hc != null) {
      await _dbService.saveMeasurement(
        MeasurementRecordModel(
          childId: childId,
          date: _todayIso(),
          height: h,
          weight: w,
          headCircumference: hc,
          notes: 'القياس الأول عند إضافة الطفل',
          createdAt: nowIso,
        ),
      );
    }

    _nameCtrl.clear();
    _selectedBirthDate = null;
    _selectedPhotoPath = null;
    _heightCtrl.clear();
    _weightCtrl.clear();
    _headCtrl.clear();

    await _reloadDatabase(preferChildId: childId);
    setState(() {
      _activeView = 'main';
    });
    _showStatusBanner('تم حفظ الطفل وحساب العمر تلقائياً بنجاح');
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _darkMode ? const Color(0xFF121212) : kBeige;
    final cardColor = _darkMode ? const Color(0xFF1E1E1E) : Colors.white;
    final textColor = _darkMode ? Colors.white : kBrown;

    if (_isLoading) {
      return Scaffold(
        backgroundColor: bgColor,
        body: const Center(child: CircularProgressIndicator(color: kGold)),
      );
    }

    // شاشة القفل بكلمة مرور اختياري
    if (_pinEnabled && !_isUnlocked) {
      final pinCtrl = TextEditingController();
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: bgColor,
          appBar: AppBar(
            backgroundColor: cardColor,
            title: Text(
              'نبتة طفلي',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
          ),
          body: Center(
            child: Container(
              margin: const EdgeInsets.all(24),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ChildPlantSvgIcons.sprout(size: 36),
                  const SizedBox(height: 12),
                  Text(
                    'أدخلي رمز الحماية المحلي لفتح نبتة طفلي',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: pinCtrl,
                    obscureText: true,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      hintText: 'رمز المرور',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: kGold),
                    onPressed: () {
                      if (pinCtrl.text == _savedPin) {
                        setState(() => _isUnlocked = true);
                      } else {
                        _showStatusBanner('رمز المرور غير صحيح');
                      }
                    },
                    child: const Text(
                      'فتح',
                      style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: cardColor,
          elevation: 0.5,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: textColor),
            onPressed: () {
              if (_activeView != 'main' && _children.isNotEmpty) {
                setState(() => _activeView = 'main');
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              ChildPlantSvgIcons.sprout(size: 22),
              const SizedBox(width: 8),
              Text(
                _screenTitle(),
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: Icon(
                _darkMode ? Icons.wb_sunny_outlined : Icons.dark_mode_outlined,
                color: kGold,
              ),
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                setState(() => _darkMode = !_darkMode);
                await prefs.setBool('child_plant_dark_mode', _darkMode);
              },
            ),
            if (_activeView == 'add_child' || _children.isEmpty)
              TextButton(
                onPressed: _saveNewChild,
                child: const Text(
                  'حفظ',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: kGold,
                  ),
                ),
              )
            else if (_children.length > 1)
              IconButton(
                icon: Icon(Icons.people_outline, color: textColor),
                onPressed: () => setState(() => _activeView = 'children'),
              ),
          ],
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: _buildCurrentScreen(cardColor, textColor),
        ),
      ),
    );
  }

  String _screenTitle() {
    if (_activeView == 'add_child' || _children.isEmpty) return 'إضافة طفل';
    switch (_activeView) {
      case 'measurements':
        return 'قياسات النمو';
      case 'charts':
        return 'الرسوم البيانية';
      case 'stages':
        return 'مراحل النمو';
      case 'appointments':
        return 'المواعيد';
      case 'activities':
        return 'سجل الطفل';
      case 'notes':
        return 'ملاحظاتي';
      case 'children':
        return 'أطفالي';
      default:
        return 'نبتة طفلي';
    }
  }

  Widget _buildCurrentScreen(Color cardColor, Color textColor) {
    if (_children.isEmpty || _activeView == 'add_child') {
      return _buildAddChildScreen(cardColor, textColor);
    }
    switch (_activeView) {
      case 'measurements':
        return _buildMeasurementsScreen(cardColor, textColor);
      case 'charts':
        return _buildChartsScreen(cardColor, textColor);
      case 'stages':
        return _buildStagesTimelineScreen(cardColor, textColor);
      case 'appointments':
        return _buildAppointmentsScreen(cardColor, textColor);
      case 'activities':
        return _buildActivitiesScreen(cardColor, textColor);
      case 'notes':
        return _buildNotesScreen(cardColor, textColor);
      case 'children':
        return _buildChildrenListScreen(cardColor, textColor);
      default:
        return _buildMainPlantScreen(cardColor, textColor);
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 1: إضافة طفل
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildAddChildScreen(Color cardColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kSoftPink),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '1. اسم الطفل (اختياري)',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 6),
          TextField(
            controller: _nameCtrl,
            decoration: InputDecoration(
              hintText: 'اسم الطفل',
              filled: true,
              fillColor: kBeige,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: kGold),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            '2. تاريخ الميلاد (إلزامي)',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 6),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: kGold),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onPressed: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(2010),
                lastDate: DateTime.now(),
              );
              if (picked != null) {
                setState(() => _selectedBirthDate = picked);
              }
            },
            child: Text(
              _selectedBirthDate == null
                  ? 'اختيار تاريخ الميلاد'
                  : '${_selectedBirthDate!.day}/${_selectedBirthDate!.month}/${_selectedBirthDate!.year}',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
          ),
          const SizedBox(height: 14),
          Text(
            '3. الجنس',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: ChoiceChip(
                  label: const Text('ذكر', style: TextStyle(fontFamily: 'Cairo')),
                  selected: _selectedGender == 'male',
                  selectedColor: kGold,
                  onSelected: (_) => setState(() => _selectedGender = 'male'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ChoiceChip(
                  label: const Text('أنثى', style: TextStyle(fontFamily: 'Cairo')),
                  selected: _selectedGender == 'female',
                  selectedColor: kGold,
                  onSelected: (_) => setState(() => _selectedGender = 'female'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          OutlinedButton(
            style: OutlinedButton.styleFrom(side: const BorderSide(color: kGold)),
            onPressed: _pickChildPhoto,
            child: Text(
              _selectedPhotoPath == null
                  ? '4. اختيار صورة الطفل (اختياري)'
                  : 'تم اختيار صورة الطفل',
              style: TextStyle(fontFamily: 'Cairo', color: textColor),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _heightCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'الطول (سم)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _weightCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'الوزن (كغ)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _headCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'محيط الرأس',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          InkWell(
            onTap: _saveNewChild,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [kGold, Color(0xFFB8923A)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              alignment: Alignment.center,
              child: const Text(
                'حفظ',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 2: نبتة طفلي — الرئيسية
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildMainPlantScreen(Color cardColor, Color textColor) {
    final child = _selectedChild!;
    final age = CalculatedChildAgeInfo.fromBirthDate(child.birthDate);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // بطاقة الطفل
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kSoftPink),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: kLightPink,
                backgroundImage: child.photoPath != null &&
                        File(child.photoPath!).existsSync()
                    ? FileImage(File(child.photoPath!))
                    : null,
                child: child.photoPath == null
                    ? ChildPlantSvgIcons.sprout(size: 26)
                    : null,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      child.name,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: textColor,
                      ),
                    ),
                    Text(
                      'العمر: ${age.formattedArabic}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: kGreen,
                      ),
                    ),
                    Text(
                      'تاريخ الميلاد: ${_formatDateDMY(child.birthDate)}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // النبتة التفاعلية SVG
        Container(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            children: [
              InteractiveChildPlantSvgWidget(
                stageIndex: age.stageIndex,
                visualScale: age.visualScale,
              ),
              const SizedBox(height: 10),
              Text(
                age.stageTitle,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: kGreen,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // العمر الحقيقي والتنبيه غير الطبي
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            children: [
              Text(
                'صغيرك يكبر يومًا بعد يوم',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: textColor,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'عمره الآن: ${age.formattedArabic}',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: kGreen,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                '[النبتة تمثيل بصري لعمر طفلك وليست مقياسًا طبيًا]',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: kGrey,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // الأزرار السريعة
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.9,
          children: [
            _quickNavCard(
              title: 'قياسات النمو',
              icon: ChildPlantSvgIcons.ruler(),
              onTap: () => setState(() => _activeView = 'measurements'),
              cardColor: cardColor,
              textColor: textColor,
            ),
            _quickNavCard(
              title: 'الرسوم البيانية',
              icon: ChildPlantSvgIcons.weightScale(),
              onTap: () => setState(() => _activeView = 'charts'),
              cardColor: cardColor,
              textColor: textColor,
            ),
            _quickNavCard(
              title: 'مراحل النمو',
              icon: ChildPlantSvgIcons.headCircumference(),
              onTap: () => setState(() => _activeView = 'stages'),
              cardColor: cardColor,
              textColor: textColor,
            ),
            _quickNavCard(
              title: 'المواعيد',
              icon: ChildPlantSvgIcons.calendar(),
              onTap: () => setState(() => _activeView = 'appointments'),
              cardColor: cardColor,
              textColor: textColor,
            ),
            _quickNavCard(
              title: 'ملاحظاتي',
              icon: ChildPlantSvgIcons.notebook(),
              onTap: () => setState(() => _activeView = 'notes'),
              cardColor: cardColor,
              textColor: textColor,
            ),
            _quickNavCard(
              title: 'سجل الطفل',
              icon: ChildPlantSvgIcons.activityLog(),
              onTap: () => setState(() => _activeView = 'activities'),
              cardColor: cardColor,
              textColor: textColor,
            ),
          ],
        ),
      ],
    );
  }

  Widget _quickNavCard({
    required String title,
    required Widget icon,
    required VoidCallback onTap,
    required Color cardColor,
    required Color textColor,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kSoftPink),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon,
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                title,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: textColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 3: قياسات النمو
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildMeasurementsScreen(Color cardColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: kGold),
          onPressed: () => _openMeasurementDialog(),
          child: const Text(
            'إضافة قياس',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_measurements.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kSoftPink),
            ),
            child: Column(
              children: [
                ChildPlantSvgIcons.sprout(size: 36),
                const SizedBox(height: 10),
                Text(
                  'لم تتم إضافة أي قياسات بعد',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: kGold),
                  onPressed: () => _openMeasurementDialog(),
                  child: const Text(
                    'إضافة أول قياس',
                    style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                  ),
                ),
              ],
            ),
          )
        else
          ..._measurements.map(
            (m) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'التاريخ: ${_formatDateDMY(m.date)}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: kGold,
                        ),
                      ),
                      Row(
                        children: [
                          TextButton(
                            onPressed: () => _openMeasurementDialog(existing: m),
                            child: const Text('تعديل'),
                          ),
                          TextButton(
                            onPressed: () async {
                              if (m.id != null) {
                                await _dbService.deleteMeasurement(m.id!);
                                await _reloadDatabase();
                              }
                            },
                            child: const Text(
                              'حذف',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Text(
                    'الطول: ${m.height ?? '-'} سم • الوزن: ${m.weight ?? '-'} كغ • محيط الرأس: ${m.headCircumference ?? '-'} سم',
                    style: TextStyle(fontFamily: 'Cairo', color: textColor),
                  ),
                  if (m.notes.isNotEmpty)
                    Text(
                      m.notes,
                      style: const TextStyle(fontFamily: 'Cairo', color: kGrey),
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Future<void> _openMeasurementDialog({MeasurementRecordModel? existing}) async {
    final hCtrl = TextEditingController(
        text: existing?.height != null ? '${existing!.height}' : '');
    final wCtrl = TextEditingController(
        text: existing?.weight != null ? '${existing!.weight}' : '');
    final hcCtrl = TextEditingController(
        text: existing?.headCircumference != null
            ? '${existing!.headCircumference}'
            : '');
    final noteCtrl = TextEditingController(text: existing?.notes ?? '');
    String dateStr = existing?.date ?? _todayIso();

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          existing == null ? 'إضافة قياس' : 'تعديل القياس',
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: hCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'الطول (سم)'),
              ),
              TextField(
                controller: wCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'الوزن (كغ)'),
              ),
              TextField(
                controller: hcCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'محيط الرأس (سم)'),
              ),
              TextField(
                controller: noteCtrl,
                decoration: const InputDecoration(labelText: 'ملاحظة'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kGold),
            onPressed: () async {
              final h = double.tryParse(hCtrl.text.trim());
              final w = double.tryParse(wCtrl.text.trim());
              final hc = double.tryParse(hcCtrl.text.trim());
              if (h == null && w == null && hc == null) return;
              if ((h != null && h <= 0) ||
                  (w != null && w <= 0) ||
                  (hc != null && hc <= 0)) return;

              await _dbService.saveMeasurement(
                MeasurementRecordModel(
                  id: existing?.id,
                  childId: _selectedChild!.id!,
                  date: dateStr,
                  height: h,
                  weight: w,
                  headCircumference: hc,
                  notes: noteCtrl.text.trim(),
                  createdAt: DateTime.now().toIso8601String(),
                ),
              );
              if (mounted) Navigator.pop(ctx);
              await _reloadDatabase();
            },
            child: const Text('حفظ', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 4: الرسوم البيانية (fl_chart - 3 Line Charts)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildChartsScreen(Color cardColor, Color textColor) {
    if (_measurements.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kSoftPink),
        ),
        child: Column(
          children: [
            Text(
              'لم تتم إضافة قياسات بعد',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kGold),
              onPressed: () => _openMeasurementDialog(),
              child: const Text(
                'إضافة قياس',
                style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
              ),
            ),
          ],
        ),
      );
    }

    final chronological = [..._measurements.reversed];
    final heightSpots = <FlSpot>[];
    final weightSpots = <FlSpot>[];
    final headSpots = <FlSpot>[];

    for (int i = 0; i < chronological.length; i++) {
      final m = chronological[i];
      if (m.height != null && m.height! > 0) {
        heightSpots.add(FlSpot(i.toDouble(), m.height!));
      }
      if (m.weight != null && m.weight! > 0) {
        weightSpots.add(FlSpot(i.toDouble(), m.weight!));
      }
      if (m.headCircumference != null && m.headCircumference! > 0) {
        headSpots.add(FlSpot(i.toDouble(), m.headCircumference!));
      }
    }

    return Column(
      children: [
        _buildSingleLineChartCard(
          title: '1. الطول مع مرور الوقت (سم)',
          spots: heightSpots,
          lineColor: kGreen,
          cardColor: cardColor,
          textColor: textColor,
        ),
        const SizedBox(height: 12),
        _buildSingleLineChartCard(
          title: '2. الوزن مع مرور الوقت (كغ)',
          spots: weightSpots,
          lineColor: kGold,
          cardColor: cardColor,
          textColor: textColor,
        ),
        const SizedBox(height: 12),
        _buildSingleLineChartCard(
          title: '3. محيط الرأس مع مرور الوقت (سم)',
          spots: headSpots,
          lineColor: kSoftPink,
          cardColor: cardColor,
          textColor: textColor,
        ),
      ],
    );
  }

  Widget _buildSingleLineChartCard({
    required String title,
    required List<FlSpot> spots,
    required Color lineColor,
    required Color cardColor,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kSoftPink),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 12),
          if (spots.isEmpty)
            const Text(
              'لم تتم إضافة قياسات لهذا المؤشر بعد',
              style: TextStyle(fontFamily: 'Cairo', color: kGrey),
            )
          else
            SizedBox(
              height: 180,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  borderData: FlBorderData(show: true),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      color: lineColor,
                      barWidth: 3,
                      dotData: const FlDotData(show: true),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 5: مراحل النمو (Timeline) — WHO / CDC
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildStagesTimelineScreen(Color cardColor, Color textColor) {
    final stages = [
      {
        'range': 'من الولادة - 6 أشهر',
        'title': 'البداية: بذرة وبرعم أولي',
        'desc':
            'التفاعل البصري والسمعي مع الأم والابتسامة الاجتماعية والانتباه للأصوات (مرجع تعليمي عام: WHO / CDC).'
      },
      {
        'range': 'من 6 - 12 شهراً',
        'title': 'مرحلة لاحقة: نبتة صغيرة',
        'desc':
            'الجلوس المتوازن، استكشاف الأشياء باليدين، بدء الحبو والمناغاة (WHO / CDC).'
      },
      {
        'range': 'من 1 - 2 سنة',
        'title': 'مرحلة نمو: نبتة أكثر نمواً',
        'desc':
            'الخطوات الأولى والمشي المستقل، نطق الكلمات الأولى، وفهم الإشارات البسيطة (WHO / CDC).'
      },
      {
        'range': 'من 2 - 4 سنوات',
        'title': 'مرحلة أكبر: نبتة كبيرة مورقة',
        'desc':
            'تكوين الجمل القصيرة، اللعب التخيلي، الجري بتوازن، وتنمية المهارات الاجتماعية (WHO / CDC).'
      },
      {
        'range': 'بعد 4 سنوات',
        'title': 'مرحلة متقدمة: شجرة صغيرة',
        'desc':
            'الاستقلالية التدريجية في المهارات اليومية، سرد القصص، والتعلم التعاوني (WHO / CDC).'
      },
    ];

    return Column(
      children: stages
          .map(
            (s) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        s['title']!,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      Text(
                        s['range']!,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: kGold,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    s['desc']!,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 12,
                      color: kGrey,
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 6: المواعيد (مع جدولة إشعار حقيقي)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildAppointmentsScreen(Color cardColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: kGold),
          onPressed: () => _openAppointmentDialog(),
          child: const Text(
            'إضافة موعد',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_appointments.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kSoftPink),
            ),
            child: Column(
              children: [
                ChildPlantSvgIcons.calendar(size: 36),
                const SizedBox(height: 10),
                Text(
                  'لا توجد مواعيد قادمة',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: kGold),
                  onPressed: () => _openAppointmentDialog(),
                  child: const Text(
                    'إضافة موعد',
                    style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                  ),
                ),
              ],
            ),
          )
        else
          ..._appointments.map(
            (a) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        a.title,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      Row(
                        children: [
                          TextButton(
                            onPressed: () => _openAppointmentDialog(existing: a),
                            child: const Text('تعديل'),
                          ),
                          TextButton(
                            onPressed: () async {
                              if (a.id != null) {
                                await _dbService.deleteAppointment(a.id!);
                                await _reloadDatabase();
                              }
                            },
                            child: const Text(
                              'حذف',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Text(
                    'التاريخ: ${_formatDateDMY(a.date)} • الوقت: ${a.time}',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      color: kGold,
                    ),
                  ),
                  if (a.doctorName.isNotEmpty)
                    Text(
                      'الطبيب: ${a.doctorName}',
                      style: TextStyle(fontFamily: 'Cairo', color: textColor),
                    ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Future<void> _openAppointmentDialog({AppointmentRecordModel? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final docCtrl = TextEditingController(text: existing?.doctorName ?? '');
    final notesCtrl = TextEditingController(text: existing?.notes ?? '');
    String dateStr = existing?.date ?? _todayIso();
    String timeStr = existing?.time ?? '10:00';
    bool reminder = (existing?.reminderEnabled ?? 1) == 1;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => AlertDialog(
          title: Text(
            existing == null ? 'إضافة موعد' : 'تعديل الموعد',
            style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(labelText: 'اسم الموعد'),
                ),
                TextField(
                  controller: docCtrl,
                  decoration:
                      const InputDecoration(labelText: 'اسم الطبيب (اختياري)'),
                ),
                TextField(
                  controller: notesCtrl,
                  decoration: const InputDecoration(labelText: 'ملاحظة'),
                ),
                SwitchListTile(
                  title: const Text(
                    'تفعيل التنبيه الحقيقي',
                    style: TextStyle(fontFamily: 'Cairo', fontSize: 13),
                  ),
                  value: reminder,
                  onChanged: (v) => setModalState(() => reminder = v),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kGold),
              onPressed: () async {
                if (titleCtrl.text.trim().isEmpty) return;
                await _dbService.saveAppointment(
                  AppointmentRecordModel(
                    id: existing?.id,
                    childId: _selectedChild!.id!,
                    title: titleCtrl.text.trim(),
                    date: dateStr,
                    time: timeStr,
                    doctorName: docCtrl.text.trim(),
                    notes: notesCtrl.text.trim(),
                    reminderEnabled: reminder ? 1 : 0,
                    createdAt: DateTime.now().toIso8601String(),
                  ),
                );
                if (mounted) Navigator.pop(ctx);
                await _reloadDatabase();
              },
              child: const Text('حفظ', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 7: سجل الطفل الموحد
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildActivitiesScreen(Color cardColor, Color textColor) {
    if (_activities.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kSoftPink),
        ),
        alignment: Alignment.center,
        child: Text(
          'لا توجد أحداث بعد',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            color: textColor,
          ),
        ),
      );
    }

    return Column(
      children: _activities
          .map(
            (act) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          act.title,
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            color: textColor,
                          ),
                        ),
                        Text(
                          act.subtitle,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: kGrey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    _formatDateDMY(act.date),
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      color: kGold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 8: ملاحظاتي
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildNotesScreen(Color cardColor, Color textColor) {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            children: [
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(labelText: 'عنوان الملاحظة'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: contentCtrl,
                decoration: const InputDecoration(labelText: 'نص الملاحظة'),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: kGold),
                onPressed: () async {
                  if (titleCtrl.text.trim().isEmpty ||
                      contentCtrl.text.trim().isEmpty) return;
                  await _dbService.saveNote(
                    NoteRecordModel(
                      childId: _selectedChild!.id!,
                      title: titleCtrl.text.trim(),
                      content: contentCtrl.text.trim(),
                      createdAt: _todayIso(),
                    ),
                  );
                  await _reloadDatabase();
                },
                child: const Text(
                  'حفظ',
                  style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (_notes.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kSoftPink),
            ),
            alignment: Alignment.center,
            child: Text(
              'ابدئي بإضافة أول ملاحظة',
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
          )
        else
          ..._notes.map(
            (n) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kSoftPink),
              ),
              child: ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(
                  n.title,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                subtitle: Text(
                  n.content,
                  style: const TextStyle(fontFamily: 'Cairo', color: kGrey),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () async {
                    if (n.id != null) {
                      await _dbService.deleteNote(n.id!);
                      await _reloadDatabase();
                    }
                  },
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 9: أطفالي (متعدد) + حذف كل بيانات طفل مع تأكيد
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildChildrenListScreen(Color cardColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: kGold),
          onPressed: () => setState(() => _activeView = 'add_child'),
          child: const Text(
            '+ إضافة طفل',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 12),
        ..._children.map((c) {
          final age = CalculatedChildAgeInfo.fromBirthDate(c.birthDate);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kSoftPink),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      c.name,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        color: textColor,
                      ),
                    ),
                    Text(
                      'العمر: ${age.formattedArabic}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: kGold),
                      onPressed: () async {
                        await _reloadDatabase(preferChildId: c.id);
                        setState(() => _activeView = 'main');
                      },
                      child: const Text(
                        'فتح',
                        style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 6),
                    TextButton(
                      onPressed: () async {
                        if (c.id != null) {
                          await _dbService.deleteAllChildData(c.id!);
                          await _reloadDatabase();
                        }
                      },
                      child: const Text(
                        'حذف',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}
