import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../../services/alarm_service.dart';
import '../../services/alarm_database_helper.dart';
import 'challenge_engine.dart';

class ChallengeScreen extends StatefulWidget {
  final int? alarmId;
  final String challengeType; // 'math', 'memory', 'shake', 'religious', 'random'
  final String difficulty; // 'easy', 'medium', 'hard'
  final String sound;

  const ChallengeScreen({
    Key? key,
    this.alarmId,
    required this.challengeType,
    required this.difficulty,
    this.sound = 'gentle',
  }) : super(key: key);

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  final AlarmService _alarmService = AlarmService();
  final AlarmDatabaseHelper _dbHelper = AlarmDatabaseHelper();

  late String _activeType;
  Timer? _countdownTimer;
  int _remainingSeconds = 30;
  bool _isSuccess = false;
  bool _isFailure = false;

  // 1. Math Challenge State
  final MathChallenge _mathEngine = MathChallenge();

  // 2. Memory Challenge State
  final MemoryChallenge _memoryEngine = MemoryChallenge();
  int? _firstFlippedCardIndex;
  bool _isCheckingMatch = false;

  // 3. Shake Challenge State
  StreamSubscription<AccelerometerEvent>? _sensorSubscription;
  int _shakeCount = 0;
  static const int _targetShakes = 30;
  DateTime _lastShakeTime = DateTime.now();

  // 4. Religious Question State
  final ReligiousChallenge _religiousEngine = ReligiousChallenge();
  late ReligiousQuestion _currentReligiousQuestion;

  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);

  @override
  void initState() {
    super.initState();
    _resolveActiveType();
    _startChallenge();
    // تشغيل صوت المنبه
    _alarmService.triggerAlarmAudio(soundType: widget.sound);
  }

  void _resolveActiveType() {
    if (widget.challengeType == 'random') {
      final types = ['math', 'memory', 'shake', 'religious'];
      _activeType = types[Random().nextInt(types.length)];
    } else {
      _activeType = widget.challengeType;
    }
  }

  void _startChallenge() {
    _countdownTimer?.cancel();

    if (_activeType == 'math') {
      _remainingSeconds = 30;
      _mathEngine.generate(widget.difficulty);
      _startTimer();
    } else if (_activeType == 'memory') {
      _remainingSeconds = 60;
      _memoryEngine.generate();
      _firstFlippedCardIndex = null;
      _startTimer();
    } else if (_activeType == 'shake') {
      _remainingSeconds = 45;
      _shakeCount = 0;
      _initShakeSensor();
      _startTimer();
    } else if (_activeType == 'religious') {
      _remainingSeconds = 30;
      _currentReligiousQuestion = _religiousEngine.getRandomQuestion();
      _startTimer();
    }
  }

  void _startTimer() {
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() => _remainingSeconds--);
      } else {
        // انتهى الوقت -> سؤال جديد وتنبيه
        HapticFeedback.heavyImpact();
        setState(() {
          _isFailure = true;
        });
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) {
            setState(() {
              _isFailure = false;
              _startChallenge();
            });
          }
        });
      }
    });
  }

  void _initShakeSensor() {
    try {
      _sensorSubscription = accelerometerEvents.listen((event) {
        final acceleration = sqrt(
          event.x * event.x + event.y * event.y + event.z * event.z,
        );

        // عتبة الحركة 15 م/ث² مع حد زمني 250 مللي ثانية لمنع العد المزدوج
        if (acceleration > 15) {
          final now = DateTime.now();
          if (now.difference(_lastShakeTime).inMilliseconds > 250) {
            _lastShakeTime = now;
            setState(() {
              _shakeCount++;
              if (_shakeCount >= _targetShakes) {
                _onChallengeSuccess();
              }
            });
          }
        }
      });
    } catch (_) {
      // مستشعر غير متوفر (المحاكي / الويب) -> سيعمل زر النقر البديل
    }
  }

  void _onChallengeSuccess() async {
    _countdownTimer?.cancel();
    _sensorSubscription?.cancel();
    await _alarmService.stopAlarm();

    // تسجيل النجاح في قاعدة البيانات
    await _dbHelper.logChallengeResult(
      alarmId: widget.alarmId,
      challengeType: _activeType,
      result: 'success',
    );

    setState(() {
      _isSuccess = true;
    });

    HapticFeedback.mediumImpact();
  }

  void _onAnswerMath(int chosen) {
    if (chosen == _mathEngine.answer) {
      _onChallengeSuccess();
    } else {
      HapticFeedback.vibrate();
      setState(() => _isFailure = true);
      Future.delayed(const Duration(milliseconds: 600), () {
        if (mounted) {
          setState(() {
            _isFailure = false;
            _mathEngine.generate(widget.difficulty);
          });
        }
      });
    }
  }

  void _onAnswerReligious(String chosen) {
    if (chosen == _currentReligiousQuestion.correctAnswer) {
      _onChallengeSuccess();
    } else {
      HapticFeedback.vibrate();
      setState(() => _isFailure = true);
      Future.delayed(const Duration(milliseconds: 600), () {
        if (mounted) {
          setState(() {
            _isFailure = false;
            _currentReligiousQuestion = _religiousEngine.getRandomQuestion();
          });
        }
      });
    }
  }

  void _onTapMemoryCard(int index) {
    if (_isCheckingMatch) return;
    final card = _memoryEngine.cards[index];
    if (card.isFlipped || card.isMatched) return;

    HapticFeedback.selectionClick();
    setState(() {
      card.isFlipped = true;
    });

    if (_firstFlippedCardIndex == null) {
      _firstFlippedCardIndex = index;
    } else {
      final firstCard = _memoryEngine.cards[_firstFlippedCardIndex!]!;
      _isCheckingMatch = true;

      if (firstCard.symbol == card.symbol) {
        // تطابق صحيح!
        firstCard.isMatched = true;
        card.isMatched = true;
        _firstFlippedCardIndex = null;
        _isCheckingMatch = false;

        if (_memoryEngine.isAllMatched) {
          _onChallengeSuccess();
        }
      } else {
        // عدم تطابق -> إرجاع البطاقات بعد 700 مللي ثانية
        Timer(const Duration(milliseconds: 700), () {
          if (mounted) {
            setState(() {
              firstCard.isFlipped = false;
              card.isFlipped = false;
              _firstFlippedCardIndex = null;
              _isCheckingMatch = false;
            });
          }
        });
      }
    }
  }

  void _snooze() async {
    _countdownTimer?.cancel();
    _sensorSubscription?.cancel();
    await _alarmService.stopAlarm();

    await _dbHelper.logChallengeResult(
      alarmId: widget.alarmId,
      challengeType: _activeType,
      result: 'snooze',
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم تأجيل المنبّه لمدة 5 دقائق ⏱️', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: Color(0xFF5B5FEF),
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _sensorSubscription?.cancel();
    _alarmService.stopAlarm();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _isSuccess
        ? const Color(0xFF4CAF82)
        : (_isFailure ? const Color(0xFFD95C6A) : const Color(0xFF1E1E1E));

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Header: ⏰ استيقظ!
                const Text(
                  '⏰ اسْتَيْقِظْ!',
                  style: TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    fontFamily: 'Cairo',
                    letterSpacing: -0.5,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  '«الصَّلَاةُ خَيْرٌ مِنَ النَّوْمِ»',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xFFE8B84A),
                    fontFamily: 'Amiri',
                  ),
                ),
                const SizedBox(height: 20),

                // Challenge Card Area
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 16,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(20),
                    child: _isSuccess ? _buildSuccessView() : _buildActiveChallengeView(),
                  ),
                ),
                const SizedBox(height: 20),

                // Snooze button
                if (!_isSuccess)
                  TextButton.icon(
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white70,
                      backgroundColor: Colors.white.withOpacity(0.12),
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: _snooze,
                    icon: const Icon(Icons.snooze_rounded, size: 20),
                    label: const Text(
                      '🔇 إيقاف مؤقت (5 دقائق)',
                      style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSuccessView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: const BoxDecoration(
            color: Color(0xFFF7F7FC),
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: const Icon(Icons.check_circle_rounded, color: Color(0xFF4CAF82), size: 54),
        ),
        const SizedBox(height: 16),
        const Text(
          'أحسنت! استيقظت بنجاح ✨',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: Color(0xFF4CAF82),
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'تقبّل الله طاعتكم، وبوركت في يومك وجعلته بداية خير وبركة',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, color: colorTextDarkBrown, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 28),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: colorAccentGold,
            padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: () => Navigator.pop(context),
          child: const Text(
            'ابدأ يومك المبارك 🕌',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white, fontFamily: 'Cairo'),
          ),
        ),
      ],
    );
  }

  Widget _buildActiveChallengeView() {
    return Column(
      children: [
        // Timer bar
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFFF7F7FC),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                _getChallengeHeader(),
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: colorTextDarkBrown, fontFamily: 'Cairo'),
              ),
            ),
            Row(
              children: [
                const Icon(Icons.timer_outlined, size: 18, color: colorAccentGold),
                const SizedBox(width: 4),
                Text(
                  '$_remainingSeconds ثانية',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Cairo',
                    color: _remainingSeconds <= 10 ? const Color(0xFFD95C6A) : colorTextDarkBrown,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: _activeType == 'shake'
                ? (_shakeCount / _targetShakes).clamp(0.0, 1.0)
                : (_remainingSeconds / 30.0).clamp(0.0, 1.0),
            backgroundColor: Colors.grey.shade200,
            valueColor: const AlwaysStoppedAnimation<Color>(colorAccentGold),
            minHeight: 6,
          ),
        ),
        const SizedBox(height: 16),

        // Specific Challenge Component
        Expanded(
          child: _buildChallengeBody(),
        ),
      ],
    );
  }

  String _getChallengeHeader() {
    switch (_activeType) {
      case 'math':
        return '🧮 تحدّي الرياضيات';
      case 'memory':
        return '🎴 تحدّي الذاكرة';
      case 'shake':
        return '📳 تحدّي رجّ الجهاز';
      case 'religious':
        return '🕌 سؤال إيماني موثق';
      default:
        return '🎲 تحدّي الاستيقاظ';
    }
  }

  Widget _buildChallengeBody() {
    switch (_activeType) {
      case 'math':
        return _buildMathView();
      case 'memory':
        return _buildMemoryView();
      case 'shake':
        return _buildShakeView();
      case 'religious':
        return _buildReligiousView();
      default:
        return _buildMathView();
    }
  }

  // 1. Math Challenge Widget
  Widget _buildMathView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          'أجب عن المسألة لإيقاف التنبيه:',
          style: TextStyle(fontSize: 13, color: Colors.grey, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 10),
        Text(
          '${_mathEngine.a} ${_mathEngine.operatorSymbol} ${_mathEngine.b} = ؟',
          style: const TextStyle(
            fontSize: 42,
            fontWeight: FontWeight.w900,
            color: colorTextDarkBrown,
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 24),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 2.2,
          children: _mathEngine.options.map((option) {
            return ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF7F7FC),
                foregroundColor: colorTextDarkBrown,
                elevation: 0,
                side: const BorderSide(color: colorAccentGold, width: 1.5),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => _onAnswerMath(option),
              child: Text(
                '$option',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // 2. Memory Challenge Widget
  Widget _buildMemoryView() {
    return Column(
      children: [
        const Text(
          'طابق جميع الأزواج المتشابهة (8 بطاقات):',
          style: TextStyle(fontSize: 13, color: Colors.grey, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 16),
        Expanded(
          child: GridView.builder(
            itemCount: _memoryEngine.cards.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
            ),
            itemBuilder: (context, index) {
              final card = _memoryEngine.cards[index];
              final isShown = card.isFlipped || card.isMatched;

              return GestureDetector(
                onTap: () => _onTapMemoryCard(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  decoration: BoxDecoration(
                    color: isShown ? (card.isMatched ? const Color(0xFFF7F7FC) : const Color(0xFFF7F7FC)) : colorAccentGold,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isShown ? colorAccentGold : Colors.transparent,
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    isShown ? card.symbol : '❓',
                    style: const TextStyle(fontSize: 26),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 3. Shake Challenge Widget
  Widget _buildShakeView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: const BoxDecoration(
            color: Color(0xFFF7F7FC),
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: const Text('📳', style: TextStyle(fontSize: 40)),
        ),
        const SizedBox(height: 16),
        const Text(
          'رجّ هاتفك بنشاط للاستيقاظ!',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
        ),
        const SizedBox(height: 8),
        Text(
          '$_shakeCount / $_targetShakes',
          style: const TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.w900,
            color: colorAccentGold,
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 16),
        // زر محاكاة بديل عند التجربة في أجهزة بدون مستشعر
        TextButton.icon(
          style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFF7F7FC),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          onPressed: () {
            HapticFeedback.lightImpact();
            setState(() {
              _shakeCount++;
              if (_shakeCount >= _targetShakes) {
                _onChallengeSuccess();
              }
            });
          },
          icon: const Icon(Icons.touch_app_rounded, size: 18, color: colorAccentGold),
          label: const Text(
            'اضغط للرج (تجربة بديلة) 👆',
            style: TextStyle(fontSize: 12, color: colorTextDarkBrown, fontFamily: 'Cairo'),
          ),
        ),
      ],
    );
  }

  // 4. Religious Question Widget
  Widget _buildReligiousView() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFF7F7FC),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            '📖 المصدر: ${_currentReligiousQuestion.source}',
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF4145C7), fontFamily: 'Cairo'),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          _currentReligiousQuestion.question,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: colorTextDarkBrown,
            fontFamily: 'Cairo',
            height: 1.4,
          ),
        ),
        const SizedBox(height: 20),
        ..._currentReligiousQuestion.options.map((opt) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF7F7FC),
                  foregroundColor: colorTextDarkBrown,
                  elevation: 0,
                  side: const BorderSide(color: colorAccentGold, width: 1.2),
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () => _onAnswerReligious(opt),
                child: Text(
                  opt,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
                ),
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
}
