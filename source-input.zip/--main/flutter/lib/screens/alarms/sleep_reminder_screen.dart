import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/alarm_database_helper.dart';
import '../../services/alarm_service.dart';

class SleepReminderScreen extends StatefulWidget {
  const SleepReminderScreen({Key? key}) : super(key: key);

  @override
  State<SleepReminderScreen> createState() => _SleepReminderScreenState();
}

class _SleepReminderScreenState extends State<SleepReminderScreen> {
  final AlarmDatabaseHelper _dbHelper = AlarmDatabaseHelper();
  final AlarmService _alarmService = AlarmService();

  TimeOfDay _selectedTime = const TimeOfDay(hour: 22, minute: 0);
  String _contentType = 'dhikr'; // 'dhikr', 'dua', 'tip', 'quran', 'random'
  String _sound = 'gentle'; // 'gentle', 'custom'
  String _repeatDays = 'all';
  bool _isActive = true;
  bool _isLoading = true;

  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);
  static const Color colorTextSecondaryGray = Color(0xFF77798C);

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    setState(() => _isLoading = true);
    final settings = await _dbHelper.getSleepReminder();
    _selectedTime = TimeOfDay(
      hour: settings['hour'] ?? 22,
      minute: settings['minute'] ?? 0,
    );
    _contentType = settings['content_type'] ?? 'dhikr';
    _sound = settings['sound'] ?? 'gentle';
    _repeatDays = settings['repeat_days'] ?? 'all';
    _isActive = (settings['is_active'] ?? 1) == 1;

    setState(() => _isLoading = false);
  }

  Future<void> _pickTime() async {
    HapticFeedback.lightImpact();
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: colorAccentGold,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: colorTextDarkBrown,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() => _selectedTime = picked);
    }
  }

  Future<void> _saveSettings() async {
    HapticFeedback.mediumImpact();

    await _dbHelper.saveSleepReminder({
      'hour': _selectedTime.hour,
      'minute': _selectedTime.minute,
      'content_type': _contentType,
      'sound': _sound,
      'repeat_days': _repeatDays,
      'is_active': _isActive ? 1 : 0,
    });

    if (_isActive) {
      await _alarmService.scheduleSleepReminder(
        hour: _selectedTime.hour,
        minute: _selectedTime.minute,
        contentType: _contentType,
        sound: _sound,
      );
    } else {
      await _alarmService.cancelAlarm(2001);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حفظ تذكير قبل النوم بنجاح 🛏️', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: Color(0xFF4CAF82),
        ),
      );
      Navigator.pop(context);
    }
  }

  String _formatTime() {
    final period = _selectedTime.hour >= 12 ? 'م' : 'ص';
    final h = _selectedTime.hour > 12
        ? _selectedTime.hour - 12
        : (_selectedTime.hour == 0 ? 12 : _selectedTime.hour);
    final m = _selectedTime.minute.toString().padLeft(2, '0');
    return '$h:$m $period';
  }

  @override
  Widget build(BuildContext context) {
    final previewContent = _alarmService.getDailySleepContent(_contentType);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorAccentGold, size: 22),
            onPressed: () => Navigator.pop(context),
          ),
          centerTitle: true,
          title: const Text(
            'تذكير قبل النوم 🛏️',
            style: TextStyle(
              color: colorAccentGold,
              fontWeight: FontWeight.w900,
              fontSize: 20,
              fontFamily: 'Cairo',
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.5),
            child: Container(color: colorAccentGold.withOpacity(0.3), height: 1.5),
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: colorAccentGold))
            : ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                children: [
                  // بطاقة معاينة التذكير الحالي
                  Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFFFDF9), Color(0xFFF7F7FC)],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      ),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: colorAccentGold.withOpacity(0.4), width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: colorAccentGold.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Row(
                              children: [
                                Text('✨', style: TextStyle(fontSize: 16)),
                                SizedBox(width: 6),
                                Text(
                                  'نموذج تذكير الليلة المتغير',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF4145C7),
                                    fontFamily: 'Cairo',
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: colorPrimaryWhite,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text('موثق', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: colorAccentGold)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          previewContent,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: colorTextDarkBrown,
                            height: 1.5,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // تفعيل التذكير
                  Container(
                    decoration: BoxDecoration(
                      color: colorPrimaryWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'تفعيل التذكير اليومي',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: colorTextDarkBrown,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        Switch(
                          value: _isActive,
                          activeColor: colorAccentGold,
                          onChanged: (v) => setState(() => _isActive = v),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 【1】الوقت
                  Container(
                    decoration: BoxDecoration(
                      color: colorPrimaryWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '⏰ وقت التذكير',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: colorTextDarkBrown,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            Text(
                              'الوقت الموصى به للاستعداد للنوم والذكر',
                              style: TextStyle(fontSize: 11, color: colorTextSecondaryGray, fontFamily: 'Cairo'),
                            ),
                          ],
                        ),
                        InkWell(
                          onTap: _pickTime,
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: colorBackgroundBeige,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: colorAccentGold.withOpacity(0.5)),
                            ),
                            child: Text(
                              _formatTime(),
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: colorAccentGold,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 【2】نوع التذكير
                  _buildSectionCard(
                    title: '📖 نوع المحتوى الإيماني اليومي',
                    children: [
                      _buildRadioOption('أذكار النوم النبوية الصحيحة (افتراضي)', 'dhikr', _contentType, (v) => setState(() => _contentType = v)),
                      _buildRadioOption('أدعية مأثورة قبل النوم', 'dua', _contentType, (v) => setState(() => _contentType = v)),
                      _buildRadioOption('نصيحة إيمانية وسنة مهجورة', 'tip', _contentType, (v) => setState(() => _contentType = v)),
                      _buildRadioOption('آية قرآنية سكينة للنفس', 'quran', _contentType, (v) => setState(() => _contentType = v)),
                      _buildRadioOption('عشوائي متجدد كل يوم', 'random', _contentType, (v) => setState(() => _contentType = v)),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // 【3】الصوت
                  _buildSectionCard(
                    title: '🎵 نغمة التنبيه',
                    children: [
                      _buildRadioOption('تنبيه هادئ لطيف (افتراضي)', 'gentle', _sound, (v) => setState(() => _sound = v)),
                      _buildRadioOption('صوت مخصص من الهاتف', 'custom', _sound, (v) => setState(() => _sound = v)),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // 【4】التكرار
                  _buildSectionCard(
                    title: '📅 التكرار',
                    children: [
                      _buildRadioOption('كل يوم (موصى به لحفظ الورد)', 'all', _repeatDays, (v) => setState(() => _repeatDays = v)),
                      _buildRadioOption('أيام الأسبوع المحددة', 'custom', _repeatDays, (v) => setState(() => _repeatDays = v)),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // 【5】زر الحفظ
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF5B5FEF), Color(0xFFE8B84A)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colorAccentGold.withOpacity(0.35),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: _saveSettings,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          child: Center(
                            child: Text(
                              'حفظ تذكير قبل النوم 🛏️',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: colorPrimaryWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorAccentGold.withOpacity(0.35), width: 1.2),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: colorTextDarkBrown,
              fontFamily: 'Cairo',
            ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }

  Widget _buildRadioOption(
    String label,
    String value,
    String currentValue,
    Function(String) onChanged,
  ) {
    final isSelected = value == currentValue;
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(value);
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? colorAccentGold : Colors.grey,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? colorTextDarkBrown : colorTextSecondaryGray,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
