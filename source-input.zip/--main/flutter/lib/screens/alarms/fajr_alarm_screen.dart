import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import '../../services/alarm_database_helper.dart';
import '../../services/alarm_service.dart';

class FajrAlarmScreen extends StatefulWidget {
  const FajrAlarmScreen({Key? key}) : super(key: key);

  @override
  State<FajrAlarmScreen> createState() => _FajrAlarmScreenState();
}

class _FajrAlarmScreenState extends State<FajrAlarmScreen> {
  final AlarmDatabaseHelper _dbHelper = AlarmDatabaseHelper();
  final AlarmService _alarmService = AlarmService();

  int _minutesBefore = 10; // 15, 10, 5
  String _sound = 'adhan_fajr'; // 'adhan_fajr', 'gentle', 'custom'
  bool _gradualVolume = true;
  String _repeatDays = 'all';
  bool _isActive = true;

  String _locationName = 'القاهرة، جمهورية مصر العربية';
  String _fajrTimeString = '4:45 ص';
  bool _isLoading = true;

  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);
  static const Color colorTextSecondaryGray = Color(0xFF77798C);

  @override
  void initState() {
    super.initState();
    _loadFajrData();
  }

  Future<void> _loadFajrData() async {
    setState(() => _isLoading = true);

    // 1. استرجاع الإعدادات المحفوظة في SQLite
    final settings = await _dbHelper.getFajrAlarm();
    _minutesBefore = settings['minutes_before'] ?? 10;
    _sound = settings['sound'] ?? 'adhan_fajr';
    _gradualVolume = (settings['gradual'] ?? 1) == 1;
    _repeatDays = settings['repeat_days'] ?? 'all';
    _isActive = (settings['is_active'] ?? 1) == 1;

    // 2. الحساب الفلكي الحقيقي لوقت صلاة الفجر اليوم
    double lat = 30.0444;
    double lng = 31.2357;

    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 2),
      );
      lat = pos.latitude;
      lng = pos.longitude;
      _locationName = 'موقعك الحالي (${lat.toStringAsFixed(2)}°, ${lng.toStringAsFixed(2)}°)';
    } catch (_) {
      _locationName = 'القاهرة (افتراضي)';
    }

    final coordinates = Coordinates(lat, lng);
    final params = CalculationMethod.egyptian.getParameters();
    params.madhab = Madhab.shafi;

    final prayerTimes = PrayerTimes(
      coordinates,
      DateComponents.from(DateTime.now()),
      params,
    );

    final fTime = prayerTimes.fajr;
    final h = fTime.hour > 12 ? fTime.hour - 12 : (fTime.hour == 0 ? 12 : fTime.hour);
    final m = fTime.minute.toString().padLeft(2, '0');
    _fajrTimeString = '$h:$m ص';

    setState(() => _isLoading = false);
  }

  Future<void> _saveFajrSettings() async {
    HapticFeedback.mediumImpact();

    await _dbHelper.saveFajrAlarm({
      'minutes_before': _minutesBefore,
      'sound': _sound,
      'gradual': _gradualVolume ? 1 : 0,
      'repeat_days': _repeatDays,
      'is_active': _isActive ? 1 : 0,
    });

    if (_isActive) {
      await _alarmService.scheduleFajrAlarm(
        minutesBefore: _minutesBefore,
        sound: _sound,
        gradualVolume: _gradualVolume,
      );
    } else {
      await _alarmService.cancelAlarm(1001);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حفظ وتفعيل منبّه الفجر بنجاح 🌅', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: Color(0xFF4CAF82),
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorAccentGold, size: 22),
            onPressed: () => Navigator.pop(context),
          ),
          centerTitle: true,
          title: const Text(
            'منبّه الفجر 🌅',
            style: TextStyle(
              color: colorAccentGold,
              fontWeight: FontWeight.w900,
              fontSize: 20,
              fontFamily: 'Cairo',
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.5),
            child: Container(color: colorAccentGold.withOpacity(0.3), height: 1.5),
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: colorAccentGold))
            : ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                children: [
                  // 【1】عرض موقيت الفجر الحالي
                  Container(
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFFFDF9), Color(0xFFF7F7FC)],
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                      ),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: colorAccentGold.withOpacity(0.5), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: colorAccentGold.withOpacity(0.12),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.location_on_rounded, color: colorAccentGold, size: 20),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '📍 موقعك: $_locationName',
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: colorTextDarkBrown,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              '🌅 الفجر اليوم:',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: colorTextDarkBrown,
                                fontFamily: 'Cairo',
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: colorPrimaryWhite,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: colorAccentGold.withOpacity(0.4)),
                              ),
                              child: Text(
                                _fajrTimeString,
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  color: colorAccentGold,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // تفعيل المنبه
                  Container(
                    decoration: BoxDecoration(
                      color: colorPrimaryWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'تفعيل منبّه الفجر',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: colorTextDarkBrown,
                            fontFamily: 'Cairo',
                          ),
                        ),
                        Switch(
                          value: _isActive,
                          activeColor: colorAccentGold,
                          onChanged: (v) => setState(() => _isActive = v),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 【2】وقت التذكير قبل الفجر
                  _buildSectionCard(
                    title: '⏱️ وقت التذكير قبل الأذان',
                    children: [
                      _buildRadioOption('قبل 15 دقيقة', 15, _minutesBefore, (v) => setState(() => _minutesBefore = v)),
                      _buildRadioOption('قبل 10 دقائق (موصى به)', 10, _minutesBefore, (v) => setState(() => _minutesBefore = v)),
                      _buildRadioOption('قبل 5 دقائق', 5, _minutesBefore, (v) => setState(() => _minutesBefore = v)),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // 【3】الصوت
                  _buildSectionCard(
                    title: '🎵 نغمة التنبيه',
                    children: [
                      _buildRadioOptionString('أذان الفجر المبارك (افتراضي)', 'adhan_fajr', _sound, (v) => setState(() => _sound = v)),
                      _buildRadioOptionString('تنبيه هادئ', 'gentle', _sound, (v) => setState(() => _sound = v)),
                      _buildRadioOptionString('صوت مخصص من الجهاز', 'custom', _sound, (v) => setState(() => _sound = v)),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // 【4】الصوت التدريجي
                  Container(
                    decoration: BoxDecoration(
                      color: colorPrimaryWhite,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const Text('🔊', style: TextStyle(fontSize: 24)),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'الصوت التدريجي',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: colorTextDarkBrown,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                              Text(
                                'يزيد الصوت بلطف من 0% إلى 100% خلال 30 ثانية',
                                style: TextStyle(
                                  fontSize: 11.5,
                                  color: colorTextSecondaryGray,
                                  fontFamily: 'Cairo',
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: _gradualVolume,
                          activeColor: colorAccentGold,
                          onChanged: (v) => setState(() => _gradualVolume = v),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // 【5】التكرار
                  _buildSectionCard(
                    title: '📅 التكرار',
                    children: [
                      _buildRadioOptionString('كل يوم', 'all', _repeatDays, (v) => setState(() => _repeatDays = v)),
                      _buildRadioOptionString('أيام العمل (الأحد - الخميس)', 'weekdays', _repeatDays, (v) => setState(() => _repeatDays = v)),
                      _buildRadioOptionString('عطلة نهاية الأسبوع فقط', 'weekends', _repeatDays, (v) => setState(() => _repeatDays = v)),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // 【6】زر الحفظ الذهبي
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF5B5FEF), Color(0xFFE8B84A)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colorAccentGold.withOpacity(0.35),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: _saveFajrSettings,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 16),
                          child: Center(
                            child: Text(
                              'حفظ إعدادات منبّه الفجر 🌅',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: colorPrimaryWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorAccentGold.withOpacity(0.35), width: 1.2),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: colorTextDarkBrown,
              fontFamily: 'Cairo',
            ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }

  Widget _buildRadioOption(
    String label,
    int value,
    int currentValue,
    Function(int) onChanged,
  ) {
    final isSelected = value == currentValue;
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(value);
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? colorAccentGold : Colors.grey,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? colorTextDarkBrown : colorTextSecondaryGray,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRadioOptionString(
    String label,
    String value,
    String currentValue,
    Function(String) onChanged,
  ) {
    final isSelected = value == currentValue;
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(value);
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? colorAccentGold : Colors.grey,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? colorTextDarkBrown : colorTextSecondaryGray,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
