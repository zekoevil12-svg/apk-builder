import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// أيقونة مرسومة بـ CustomPainter (SVG مكافئ) لمصحف مفتوح مع قلم ذهبي (#5B5FEF) بدون أي إيموجي
class GharibMushafPenIcon extends StatelessWidget {
  final double size;
  const GharibMushafPenIcon({Key? key, this.size = 30}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _GharibMushafPenPainter(),
    );
  }
}

class _GharibMushafPenPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final goldPaint = Paint()
      ..color = const Color(0xFF5B5FEF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.06
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillIvory = Paint()
      ..color = const Color(0xFFF7F7FC)
      ..style = PaintingStyle.fill;

    // صفحات المصحف المفتوح
    final bookRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * 0.14, h * 0.22, w * 0.72, h * 0.52),
      Radius.circular(w * 0.08),
    );
    canvas.drawRRect(bookRect, fillIvory);
    canvas.drawRRect(bookRect, goldPaint);

    // خط المنتصف للمصحف
    canvas.drawLine(
      Offset(w * 0.5, h * 0.22),
      Offset(w * 0.5, h * 0.74),
      goldPaint,
    );

    // القلم الذهبي المائل
    final penPaint = Paint()
      ..color = const Color(0xFF25263A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.07
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(
      Offset(w * 0.78, h * 0.14),
      Offset(w * 0.54, h * 0.48),
      penPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GharibWordItem {
  final int id;
  final String word;
  final String meaning;
  final String ayahText;
  final int surahId;
  final String surahName;
  final int ayahNumber;
  final String source;
  final String secondarySource;

  const GharibWordItem({
    required this.id,
    required this.word,
    required this.meaning,
    required this.ayahText,
    required this.surahId,
    required this.surahName,
    required this.ayahNumber,
    required this.source,
    required this.secondarySource,
  });
}

const List<GharibWordItem> kGharibWords = [
  GharibWordItem(
    id: 1,
    word: 'غُلْبًا',
    meaning: 'جمع أغلب، وهي الحدائق العظيمة الكثيفة الأشجار الغليظة الأعناق والسيقان',
    ayahText: 'وَحَدَائِقَ غُلْبًا',
    surahId: 80,
    surahName: 'عبس',
    ayahNumber: 30,
    source: 'المفردات في غريب القرآن — الراغب الأصفهاني',
    secondarySource: 'تفسير السعدي',
  ),
  GharibWordItem(
    id: 2,
    word: 'قِطَّنَا',
    meaning: 'نصيبنا وكتابنا وحظنا من الحساب والجزاء، والقط: الصحيفة المكتوبة',
    ayahText: 'وَقَالُوا رَبَّنَا عَجِّل لَّنَا قِطَّنَا قَبْلَ يَوْمِ الْحِسَابِ',
    surahId: 38,
    surahName: 'ص',
    ayahNumber: 16,
    source: 'المفردات في غريب القرآن — الراغب الأصفهاني',
    secondarySource: 'غريب القرآن — ابن قتيبة',
  ),
  GharibWordItem(
    id: 3,
    word: 'صَيِّبٍ',
    meaning: 'المطر الشديد النازل المتدفق من السحاب، من صاب يصوب إذا نزل',
    ayahText: 'أَوْ كَصَيِّبٍ مِّنَ السَّمَاءِ فِيهِ ظُلُمَاتٌ وَرَعْدٌ وَبَرْقٌ',
    surahId: 2,
    surahName: 'البقرة',
    ayahNumber: 19,
    source: 'غريب القرآن — ابن قتيبة',
    secondarySource: 'لسان العرب — ابن منظور',
  ),
  GharibWordItem(
    id: 4,
    word: 'ضِيزَىٰ',
    meaning: 'قسمة جائرة عوجاء مائلة عن الحق والعدل',
    ayahText: 'تِلْكَ إِذًا قِسْمَةٌ ضِيزَىٰ',
    surahId: 53,
    surahName: 'النجم',
    ayahNumber: 22,
    source: 'الصحاح — الجوهري',
    secondarySource: 'المفردات في غريب القرآن — الراغب الأصفهاني',
  ),
  GharibWordItem(
    id: 5,
    word: 'دِهَاقًا',
    meaning: 'مملوءة مترعة صافية متتابعة لأهل الجنة',
    ayahText: 'وَكَأْسًا دِهَاقًا',
    surahId: 78,
    surahName: 'النبأ',
    ayahNumber: 34,
    source: 'الصحاح — الجوهري',
    secondarySource: 'تفسير ابن كثير',
  ),
];

class GharibQuranScreen extends StatefulWidget {
  const GharibQuranScreen({Key? key}) : super(key: key);

  @override
  State<GharibQuranScreen> createState() => _GharibQuranScreenState();
}

class _GharibQuranScreenState extends State<GharibQuranScreen> {
  static const Color kGold = Color(0xFF5B5FEF);
  static const Color kBeige = Color(0xFFF7F7FC);
  static const Color kIvory = Color(0xFFF7F7FC);
  static const Color kBrown = Color(0xFF25263A);
  static const Color kGray = Color(0xFF77798C);
  static const Color kGreen = Color(0xFF4CAF82);
  static const Color kRed = Color(0xFFD95C6A);

  int _subScreenIndex = 0; // 0: main, 1: surahs, 2: detail, 3: search, 4: quiz, 5: favorites
  int _dailyWordIdx = 0;
  bool _darkMode = false;
  final Set<int> _favorites = {};
  int _todayViewed = 5;
  final int _dailyTarget = 15;
  GharibWordItem _selectedWord = kGharibWords[0];
  String _searchQuery = '';

  // Quiz state
  int _quizIndex = 0;
  int? _selectedOption;
  bool _answered = false;
  int _correctCount = 0;

  void _copyWord(GharibWordItem w) {
    final text =
        '﴿${w.word}﴾\n﴿${w.ayahText}﴾ [سورة ${w.surahName} - آية ${w.ayahNumber}]\nالمعنى: ${w.meaning}\nالمصدر: ${w.source}';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('تم نسخ الكلمة ومعناها ومصدرها بنجاح'),
        backgroundColor: kBrown,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _darkMode ? const Color(0xFF121212) : kBeige;
    final cardColor = _darkMode ? const Color(0xFF1E1E1E) : Colors.white;
    final textColor = _darkMode ? kBeige : kBrown;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: cardColor,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: kGold),
            onPressed: () {
              if (_subScreenIndex == 0) {
                Navigator.pop(context);
              } else {
                setState(() => _subScreenIndex = 0);
              }
            },
          ),
          title: Row(
            children: [
              const GharibMushafPenIcon(size: 26),
              const SizedBox(width: 8),
              Text(
                'غريب القرآن',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search_rounded, color: kGold),
              onPressed: () => setState(() => _subScreenIndex = 3),
            ),
            IconButton(
              icon: const Icon(Icons.star_border_rounded, color: kGold),
              onPressed: () => setState(() => _subScreenIndex = 5),
            ),
            IconButton(
              icon: Icon(
                _darkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round,
                color: kGold,
              ),
              onPressed: () => setState(() => _darkMode = !_darkMode),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (_subScreenIndex == 0) _buildMainDashboard(cardColor, textColor),
            if (_subScreenIndex == 1) _buildSurahsIndex(cardColor, textColor),
            if (_subScreenIndex == 2) _buildWordDetail(cardColor, textColor),
            if (_subScreenIndex == 3) _buildSearchScreen(cardColor, textColor),
            if (_subScreenIndex == 4) _buildQuizScreen(cardColor, textColor),
            if (_subScreenIndex == 5) _buildFavoritesScreen(cardColor, textColor),
          ],
        ),
      ),
    );
  }

  Widget _buildMainDashboard(Color cardColor, Color textColor) {
    final current = kGharibWords[_dailyWordIdx % kGharibWords.length];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kGold.withOpacity(0.4)),
          ),
          child: Column(
            children: [
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'كلمة اليوم',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: kGold,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedWord = current;
                    _subScreenIndex = 2;
                  });
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _darkMode ? const Color(0xFF171717) : kIvory,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kGold.withOpacity(0.35)),
                  ),
                  child: Column(
                    children: [
                      Text(
                        '﴿${current.word}﴾',
                        style: const TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          color: kGold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        current.meaning,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'سورة ${current.surahName} - آية ${current.ayahNumber} • ${current.source}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kGray,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _copyWord(current),
                      icon: const Icon(Icons.share_outlined, color: kGold, size: 18),
                      label: const Text('مشاركة', style: TextStyle(color: kGold)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _copyWord(current),
                      icon: const Icon(Icons.copy_rounded, color: kGold, size: 18),
                      label: const Text('نسخ', style: TextStyle(color: kGold)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: kGold),
                  onPressed: () {
                    setState(() {
                      _dailyWordIdx++;
                      if (_todayViewed < _dailyTarget) _todayViewed++;
                    });
                  },
                  icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                  label: const Text(
                    'كلمة أخرى',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            _buildStatTile('كلمات اليوم', '$_todayViewed / $_dailyTarget', cardColor, textColor),
            const SizedBox(width: 8),
            _buildStatTile('الأسبوع', '35 كلمة', cardColor, textColor),
            const SizedBox(width: 8),
            _buildStatTile('إجمالي الكلمات', '6120 كلمة', cardColor, textColor),
          ],
        ),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 2.2,
          children: [
            _buildNavButton('فهرس السور', Icons.menu_book_rounded, 1, cardColor, textColor),
            _buildNavButton('البحث', Icons.search_rounded, 3, cardColor, textColor),
            _buildNavButton('اختبر نفسك', Icons.quiz_outlined, 4, cardColor, textColor),
            _buildNavButton('المفضلة', Icons.star_outline_rounded, 5, cardColor, textColor),
          ],
        ),
      ],
    );
  }

  Widget _buildStatTile(String label, String val, Color cardColor, Color textColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kGold.withOpacity(0.35)),
        ),
        child: Column(
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: kGray)),
            const SizedBox(height: 4),
            Text(
              val,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: kGold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(
      String title, IconData icon, int targetScreen, Color cardColor, Color textColor) {
    return InkWell(
      onTap: () => setState(() => _subScreenIndex = targetScreen),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kGold.withOpacity(0.35)),
        ),
        child: Row(
          children: [
            Icon(icon, color: kGold),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: textColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSurahsIndex(Color cardColor, Color textColor) {
    return Column(
      children: kGharibWords.map((w) {
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kGold.withOpacity(0.35)),
          ),
          child: ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              'سورة ${w.surahName} — ﴿${w.word}﴾',
              style: const TextStyle(
                fontFamily: 'Amiri',
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: kGold,
              ),
            ),
            subtitle: Text(
              w.meaning,
              style: TextStyle(color: textColor, fontSize: 14),
            ),
            trailing: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kGold),
              onPressed: () {
                setState(() {
                  _selectedWord = w;
                  _subScreenIndex = 2;
                });
              },
              child: const Text('دخول', style: TextStyle(color: Colors.white)),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildWordDetail(Color cardColor, Color textColor) {
    final w = _selectedWord;
    final isFav = _favorites.contains(w.id);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kGold.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Text(
            w.word,
            style: const TextStyle(
              fontFamily: 'Amiri',
              fontSize: 36,
              fontWeight: FontWeight.bold,
              color: kGold,
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _darkMode ? const Color(0xFF171717) : kIvory,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kGold.withOpacity(0.35)),
            ),
            child: Column(
              children: [
                Text(
                  '﴿${w.ayahText}﴾',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 22,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'سورة ${w.surahName} - آية ${w.ayahNumber}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: kGold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text('─── المعنى ───', style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(
            w.meaning,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textColor),
          ),
          const SizedBox(height: 16),
          const Text('─── المصدر ───', style: TextStyle(color: kGold, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _darkMode ? const Color(0xFF252525) : kBeige,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Text(w.source, style: const TextStyle(fontSize: 14, color: kGray)),
                const SizedBox(height: 4),
                Text(w.secondarySource, style: const TextStyle(fontSize: 14, color: kGray)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _copyWord(w),
                  child: const Text('نسخ', style: TextStyle(color: kGold)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      if (isFav) {
                        _favorites.remove(w.id);
                      } else {
                        _favorites.add(w.id);
                      }
                    });
                  },
                  child: Text(
                    isFav ? 'محفوظة' : 'مفضلة',
                    style: const TextStyle(color: kGold),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchScreen(Color cardColor, Color textColor) {
    final results = kGharibWords
        .where((w) =>
            w.word.contains(_searchQuery) ||
            w.meaning.contains(_searchQuery) ||
            w.surahName.contains(_searchQuery))
        .toList();

    return Column(
      children: [
        TextField(
          onChanged: (v) => setState(() => _searchQuery = v),
          decoration: InputDecoration(
            hintText: 'ابحث في 6120 كلمة...',
            filled: true,
            fillColor: cardColor,
            prefixIcon: const Icon(Icons.search_rounded, color: kGold),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...results.map((w) => ListTile(
              onTap: () {
                setState(() {
                  _selectedWord = w;
                  _subScreenIndex = 2;
                });
              },
              title: Text(
                '﴿${w.word}﴾ — سورة ${w.surahName}',
                style: const TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 22,
                  color: kGold,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(w.meaning, style: TextStyle(color: textColor)),
            )),
      ],
    );
  }

  Widget _buildQuizScreen(Color cardColor, Color textColor) {
    final qWord = kGharibWords[_quizIndex % kGharibWords.length];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kGold.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Text(
            'السؤال ${_quizIndex + 1} من ${kGharibWords.length}',
            style: const TextStyle(fontWeight: FontWeight.bold, color: kGold),
          ),
          const SizedBox(height: 12),
          Text(
            'ما معنى كلمة: ﴿${qWord.word}﴾؟',
            style: const TextStyle(
              fontFamily: 'Amiri',
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: kGold,
            ),
          ),
          const SizedBox(height: 12),
          ...List.generate(kGharibWords.length.clamp(0, 4), (idx) {
            final isCorrect = idx == (_quizIndex % 4);
            final optionText = isCorrect
                ? qWord.meaning
                : kGharibWords[(idx + 1) % kGharibWords.length].meaning;
            Color tileBg = cardColor;
            if (_answered) {
              if (isCorrect) {
                tileBg = kGreen.withOpacity(0.2);
              } else if (_selectedOption == idx) {
                tileBg = kRed.withOpacity(0.2);
              }
            }
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: tileBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kGold.withOpacity(0.35)),
              ),
              child: ListTile(
                onTap: _answered
                    ? null
                    : () {
                        setState(() {
                          _selectedOption = idx;
                          _answered = true;
                          if (isCorrect) _correctCount++;
                        });
                      },
                title: Text(optionText, style: TextStyle(color: textColor, fontSize: 13)),
              ),
            );
          }),
          if (_answered)
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: kGold),
              onPressed: () {
                setState(() {
                  _quizIndex++;
                  _selectedOption = null;
                  _answered = false;
                });
              },
              child: const Text('السؤال التالي', style: TextStyle(color: Colors.white)),
            ),
        ],
      ),
    );
  }

  Widget _buildFavoritesScreen(Color cardColor, Color textColor) {
    final favItems = kGharibWords.where((w) => _favorites.contains(w.id)).toList();
    if (favItems.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Text('لا توجد كلمات في المفضلة حالياً', style: TextStyle(color: textColor)),
        ),
      );
    }
    return Column(
      children: favItems
          .map((w) => ListTile(
                title: Text('﴿${w.word}﴾', style: const TextStyle(color: kGold, fontSize: 22)),
                subtitle: Text(w.meaning, style: TextStyle(color: textColor)),
              ))
          .toList(),
    );
  }
}
