import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// ══════════════════════════════════════════════════════════════════════════
/// قاعدة بيانات «غراس الجنة» في Flutter (6 جداول SQLite حقيقية بدون أي بيانات وهمية)
/// الجداول:
/// 1. garden: id | total_plants | current_stage | last_watered_at
/// 2. seeds: id | type | custom_name | planted_at | note
/// 3. actions_types: id | name | icon | description | is_custom
/// 4. daily_stats: id | date | actions_count
/// 5. streak: id | current_streak | longest_streak | last_action_date
/// 6. achievements: id | achievement_id | unlocked_at
/// ══════════════════════════════════════════════════════════════════════════

class GhirasSeedModel {
  final int? id;
  final String type;
  final String customName;
  final String plantedAt;
  final String note;

  const GhirasSeedModel({
    this.id,
    required this.type,
    required this.customName,
    required this.plantedAt,
    required this.note,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'type': type,
        'custom_name': customName,
        'planted_at': plantedAt,
        'note': note,
      };

  factory GhirasSeedModel.fromMap(Map<String, dynamic> map) => GhirasSeedModel(
        id: map['id'] as int?,
        type: (map['type'] as String?) ?? 'dhikr_allah',
        customName: (map['custom_name'] as String?) ?? 'ذكر الله',
        plantedAt: (map['planted_at'] as String?) ?? '',
        note: (map['note'] as String?) ?? '',
      );
}

class GhirasActionTypeModel {
  final int? id;
  final String name;
  final String icon;
  final String description;
  final int isCustom;

  const GhirasActionTypeModel({
    this.id,
    required this.name,
    required this.icon,
    required this.description,
    required this.isCustom,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'icon': icon,
        'description': description,
        'is_custom': isCustom,
      };

  factory GhirasActionTypeModel.fromMap(Map<String, dynamic> map) =>
      GhirasActionTypeModel(
        id: map['id'] as int?,
        name: (map['name'] as String?) ?? '',
        icon: (map['icon'] as String?) ?? 'sprout',
        description: (map['description'] as String?) ?? '',
        isCustom: (map['is_custom'] as int?) ?? 0,
      );
}

class GhirasSqliteService {
  GhirasSqliteService._();
  static final GhirasSqliteService instance = GhirasSqliteService._();

  Database? _db;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  bool _notifReady = false;

  static const List<Map<String, dynamic>> defaultActions = [
    {
      'name': 'قراءة القرآن',
      'icon': 'quran',
      'description': 'تلاوة آيات أو ورد من كتاب الله عز وجل بتدبر',
      'is_custom': 0
    },
    {
      'name': 'ذكر الله',
      'icon': 'dhikr',
      'description': 'التسبيح والتحميد والتهليل والتكبير',
      'is_custom': 0
    },
    {
      'name': 'الصلاة',
      'icon': 'prayer',
      'description': 'أداء الفريضة في وقتها أو التزود بالسنن الرواتب',
      'is_custom': 0
    },
    {
      'name': 'الصدقة',
      'icon': 'sadaqah',
      'description': 'بذل المال أو الطعام أو الكلمة الطيبة',
      'is_custom': 0
    },
    {
      'name': 'بر الوالدين',
      'icon': 'parents',
      'description': 'الإحسان إلى الوالدين أو الدعاء لهما',
      'is_custom': 0
    },
    {
      'name': 'مساعدة شخص',
      'icon': 'help',
      'description': 'قضاء حاجة مسلم أو تفريج كربة',
      'is_custom': 0
    },
    {
      'name': 'الاستغفار',
      'icon': 'istighfar',
      'description': 'طلب المغفرة والتوبة والإنابة إلى الله',
      'is_custom': 0
    },
    {
      'name': 'الصلاة على النبي ﷺ',
      'icon': 'salawat',
      'description': 'الإكثار من الصلاة والسلام على نبينا محمد ﷺ',
      'is_custom': 0
    },
    {
      'name': 'صلة الرحم',
      'icon': 'kinship',
      'description': 'زيارة الأقارب أو السؤال عنهم وتفقد أحوالهم',
      'is_custom': 0
    },
  ];

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'rifq_ghiras_al_jannah.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // 1. جدول garden
        await db.execute('''
          CREATE TABLE garden (
            id INTEGER PRIMARY KEY,
            total_plants INTEGER DEFAULT 0,
            current_stage TEXT DEFAULT 'بذرة',
            last_watered_at TEXT
          )
        ''');
        await db.insert('garden', {
          'id': 1,
          'total_plants': 0,
          'current_stage': 'بذرة',
          'last_watered_at': null,
        });

        // 2. جدول seeds
        await db.execute('''
          CREATE TABLE seeds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            custom_name TEXT NOT NULL,
            planted_at TEXT NOT NULL,
            note TEXT
          )
        ''');

        // 3. جدول actions_types
        await db.execute('''
          CREATE TABLE actions_types (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT NOT NULL,
            description TEXT,
            is_custom INTEGER DEFAULT 0
          )
        ''');
        for (final act in defaultActions) {
          await db.insert('actions_types', act);
        }

        // 4. جدول daily_stats
        await db.execute('''
          CREATE TABLE daily_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT UNIQUE NOT NULL,
            actions_count INTEGER DEFAULT 0
          )
        ''');

        // 5. جدول streak
        await db.execute('''
          CREATE TABLE streak (
            id INTEGER PRIMARY KEY,
            current_streak INTEGER DEFAULT 0,
            longest_streak INTEGER DEFAULT 0,
            last_action_date TEXT
          )
        ''');
        await db.insert('streak', {
          'id': 1,
          'current_streak': 0,
          'longest_streak': 0,
          'last_action_date': null,
        });

        // 6. جدول achievements
        await db.execute('''
          CREATE TABLE achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            achievement_id TEXT UNIQUE NOT NULL,
            unlocked_at TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }

  static String stageNameForCount(int count) {
    if (count >= 500) return 'حديقة مزهرة';
    if (count >= 250) return 'بستان';
    if (count >= 100) return 'حديقة';
    if (count >= 30) return 'شجرة';
    if (count >= 15) return 'شتلة';
    if (count >= 5) return 'برعم';
    return 'بذرة';
  }

  Future<void> recomputeStatsAndTables() async {
    final db = await database;
    final seedRows = await db.query('seeds', orderBy: 'planted_at DESC');
    final totalPlants = seedRows.length;
    final stage = stageNameForCount(totalPlants);

    await db.update(
      'garden',
      {'total_plants': totalPlants, 'current_stage': stage},
      where: 'id = 1',
    );

    final dateCounts = <String, int>{};
    for (final r in seedRows) {
      final pAt = (r['planted_at'] as String?) ?? '';
      if (pAt.length >= 10) {
        final d = pAt.substring(0, 10);
        dateCounts[d] = (dateCounts[d] ?? 0) + 1;
      }
    }

    await db.delete('daily_stats');
    final sortedDates = dateCounts.keys.toList()..sort();
    for (final d in sortedDates) {
      await db.insert('daily_stats', {
        'date': d,
        'actions_count': dateCounts[d],
      });
    }

    int longest = 0;
    int running = 0;
    DateTime? prev;
    for (final dStr in sortedDates) {
      final dt = DateTime.tryParse(dStr);
      if (dt == null) continue;
      if (prev == null) {
        running = 1;
      } else {
        final diff = dt.difference(prev).inDays;
        if (diff == 1) {
          running += 1;
        } else if (diff > 1) {
          running = 1;
        }
      }
      if (running > longest) longest = running;
      prev = dt;
    }

    await db.update(
      'streak',
      {
        'current_streak': running,
        'longest_streak': longest,
        'last_action_date': sortedDates.isNotEmpty ? sortedDates.last : null,
      },
      where: 'id = 1',
    );

    final nowIso = DateTime.now().toIso8601String();
    Future<void> unlockIf(String achId, bool cond) async {
      if (cond) {
        await db.insert(
          'achievements',
          {'achievement_id': achId, 'unlocked_at': nowIso},
          conflictAlgorithm: ConflictAlgorithm.ignore,
        );
      }
    }

    await unlockIf('first_seed', totalPlants >= 1);
    await unlockIf('seven_days_logged', sortedDates.length >= 7);
    await unlockIf('thirty_seeds', totalPlants >= 30);
    await unlockIf('first_tree', totalPlants >= 30);
    await unlockIf('first_complete_garden', totalPlants >= 100);
    await unlockIf('thirty_days_streak', longest >= 30);
    await unlockIf('hundred_seeds', totalPlants >= 100);
  }

  Future<List<GhirasSeedModel>> getSeeds() async {
    final db = await database;
    final rows = await db.query('seeds', orderBy: 'planted_at DESC, id DESC');
    return rows.map(GhirasSeedModel.fromMap).toList();
  }

  Future<List<GhirasActionTypeModel>> getActionTypes() async {
    final db = await database;
    final rows = await db.query('actions_types', orderBy: 'id ASC');
    return rows.map(GhirasActionTypeModel.fromMap).toList();
  }

  Future<void> plantSeed(GhirasSeedModel seed) async {
    final db = await database;
    await db.insert('seeds', seed.toMap());
    await recomputeStatsAndTables();
  }

  Future<void> updateSeed(int id, String customName, String note) async {
    final db = await database;
    await db.update(
      'seeds',
      {'custom_name': customName, 'note': note},
      where: 'id = ?',
      whereArgs: [id],
    );
    await recomputeStatsAndTables();
  }

  Future<void> deleteSeed(int id) async {
    final db = await database;
    await db.delete('seeds', where: 'id = ?', whereArgs: [id]);
    await recomputeStatsAndTables();
  }

  Future<void> addCustomActionType(GhirasActionTypeModel action) async {
    final db = await database;
    await db.insert('actions_types', action.toMap());
  }

  Future<void> waterGardenNow() async {
    final db = await database;
    await db.update(
      'garden',
      {'last_watered_at': DateTime.now().toIso8601String()},
      where: 'id = 1',
    );
  }

  Future<Map<String, dynamic>> getSummary() async {
    final db = await database;
    final gardenRows = await db.query('garden', where: 'id = 1');
    final streakRows = await db.query('streak', where: 'id = 1');
    final statRows = await db.query('daily_stats', orderBy: 'date ASC');
    final achRows = await db.query('achievements');
    return {
      'garden': gardenRows.isNotEmpty ? gardenRows.first : {},
      'streak': streakRows.isNotEmpty ? streakRows.first : {},
      'daily_stats': statRows,
      'achievements': achRows,
    };
  }

  Future<void> wipeAllGardenData() async {
    final db = await database;
    await db.delete('seeds');
    await db.delete('daily_stats');
    await db.delete('achievements');
    await db.delete('actions_types', where: 'is_custom = 1');
    await db.update(
      'garden',
      {'total_plants': 0, 'current_stage': 'بذرة', 'last_watered_at': null},
      where: 'id = 1',
    );
    await db.update(
      'streak',
      {'current_streak': 0, 'longest_streak': 0, 'last_action_date': null},
      where: 'id = 1',
    );
  }

  /// جدولة إشعار يومي اختياري يفعّله المستخدم بنفسه (بدون إنترنت وبعد إغلاق التطبيق)
  Future<void> scheduleOptionalReminder({
    required int notificationId,
    required String title,
    required int hour,
    required int minute,
    required bool enabled,
  }) async {
    if (!_notifReady) {
      tz_data.initializeTimeZones();
      const androidSettings =
          AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosSettings = DarwinInitializationSettings();
      await _notifications.initialize(
        const InitializationSettings(
          android: androidSettings,
          iOS: iosSettings,
        ),
      );
      _notifReady = true;
    }

    if (!enabled) {
      await _notifications.cancel(notificationId);
      return;
    }

    final androidPlugin =
        _notifications.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();

    final now = tz.TZDateTime.now(tz.local);
    var scheduled =
        tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }

    await _notifications.zonedSchedule(
      notificationId,
      'غراس الجنة — $title',
      'موعدك الاختياري لتسجيل عمل صالح أو ري حديقتك في تطبيق رِفْق',
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'ghiras_al_jannah_channel',
          'تذكيرات غراس الجنة الاختيارية',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}
