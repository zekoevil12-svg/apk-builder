import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// شاشة قسم «الأربعون النووية» (42 حديثاً جامعاً للإمام النووي وابن رجب)
/// تعمل بدون إنترنت 100% مع البحث الفوري بدون تشكيل، الشرح الوافي، معاني المفردات، والفوائد المستنبطة
class ArbainNawawiyaScreen extends StatefulWidget {
  const ArbainNawawiyaScreen({Key? key}) : super(key: key);

  @override
  State<ArbainNawawiyaScreen> createState() => _ArbainNawawiyaScreenState();
}

class _ArbainNawawiyaScreenState extends State<ArbainNawawiyaScreen> {
  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorRoyalGreen = Color(0xFF4CAF82);
  static const Color colorDeepGreen = Color(0xFF4145C7);

  String _searchQuery = '';
  String _selectedTheme = 'الكل';
  final Set<int> _favorites = <int>{};
  final Set<int> _memorized = <int>{};

  static final List<Map<String, dynamic>> _arbainHadiths = [
    {
      'number': 1,
      'orderLabel': 'الحديث الأول',
      'title': 'إنما الأعمال بالنيات',
      'source': 'البخاري (1) ومسلم (1907)',
      'theme': 'أصول الدين والعقيدة',
      'narrator': 'أمير المؤمنين أبو حفص عمر بن الخطاب رضي الله عنه',
      'matn':
          'عَنْ أَمِيرِ الْمُؤْمِنِينَ أَبِي حَفْصٍ عُمَرَ بْنِ الْخَطَّابِ رَضِيَ اللَّهُ عَنْهُ قَالَ: سَمِعْتُ رَسُولَ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ يَقُولُ: «إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى، فَمَنْ كَانَتْ هِجْرَتُهُ إِلَى اللَّهِ وَرَسُولِهِ فَهِجْرَتُهُ إِلَى اللَّهِ وَرَسُولِهِ، وَمَنْ كَانَتْ هِجْرَتُهُ لِدُنْيَا يُصِيبُهَا أَوِ امْرَأَةٍ يَنْكِحُهَا فَهِجْرَتُهُ إِلَى مَا هَاجَرَ إِلَيْهِ».',
      'explanation':
          'هذا الحديث أصلٌ عظيم من أصول الإسلام، ويدخل فيه ثلث العلم؛ إذ يبين أن صحة الأعمال الشرعية وقبولها وترتب الثواب عليها إنما يدور مع النية إخلاصاً لله تعالى وتمييزاً للعبادات.',
      'benefits': [
        'اشتراط النية لقبول الأعمال الصالحة وصحتها.',
        'تحول العادات والمباحات بالنية الصالحة إلى طاعات يؤجر عليها العبد.',
        'محل النية القلب ولا يشرع التلفظ بها.',
      ],
    },
    {
      'number': 2,
      'orderLabel': 'الحديث الثاني',
      'title': 'حديث جبريل (مراتب الدين)',
      'source': 'مسلم (8)',
      'theme': 'أصول الدين والعقيدة',
      'narrator': 'عمر بن الخطاب رضي الله عنه',
      'matn':
          '«الإِسْلاَمُ أَنْ تَشْهَدَ أَنْ لاَ إِلَهَ إِلاَّ اللَّهُ وَأَنَّ مُحَمَّدًا رَسُولُ اللَّهِ، وَتُقِيمَ الصَّلاَةَ، وَتُؤْتِيَ الزَّكَاةَ، وَتَصُومَ رَمَضَانَ، وَتَحُجَّ الْبَيْتَ إِنِ اسْتَطَعْتَ إِلَيْهِ سَبِيلاً... وَالإِيمَانُ أَنْ تُؤْمِنَ بِاللَّهِ وَمَلاَئِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ وَالْيَوْمِ الآخِرِ وَتُؤْمِنَ بِالْقَدَرِ خَيْرِهِ وَشَرِّهِ... وَالإِحْسَانُ أَنْ تَعْبُدَ اللَّهَ كَأَنَّكَ تَرَاهُ، فَإِنْ لَمْ تَكُنْ تَرَاهُ فَإِنَّهُ يَرَاكَ».',
      'explanation':
          'يُسمى هذا الحديث أمّ السنة لاشتماله على مراتب الدين الثلاث: الإسلام، والإيمان، والإحسان، وبيان أمارات الساعة وآداب طالب العلم.',
      'benefits': [
        'بيان مراتب الدين الثلاث: الإسلام، ثم الإيمان، ثم الإحسان.',
        'وجوب الإيمان بالقدر خيره وشره.',
        'علم الساعة غيب استأثر الله به.',
      ],
    },
  ];

  String _normalizeArabic(String input) {
    return input
        .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '')
        .replaceAll(RegExp(r'[أإآ]'), 'ا')
        .replaceAll('ة', 'ه')
        .replaceAll('ى', 'ي')
        .trim();
  }

  @override
  Widget build(BuildContext context) {
    final normQuery = _normalizeArabic(_searchQuery);
    final filtered = _arbainHadiths.where((h) {
      if (_selectedTheme != 'الكل' && h['theme'] != _selectedTheme) {
        return false;
      }
      if (normQuery.isEmpty) return true;
      final combined = _normalizeArabic(
        '${h['number']} ${h['title']} ${h['matn']} ${h['explanation']} ${h['narrator']}',
      );
      return combined.contains(normQuery);
    }).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                'assets/icons/menu/ic_arbain_nawawiya.png',
                width: 28,
                height: 28,
              ),
              const SizedBox(width: 8),
              const Text(
                'الأربعون النووية (42 حديثاً)',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                  color: colorDeepGreen,
                ),
              ),
            ],
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // شريط البحث الفوري بدون تشكيل
            TextField(
              onChanged: (val) => setState(() => _searchQuery = val),
              decoration: InputDecoration(
                hintText: 'ابحث برقم الحديث أو العنوان أو الكلمة...',
                prefixIcon: const Icon(Icons.search, color: colorAccentGold),
                filled: true,
                fillColor: colorPrimaryWhite,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: colorAccentGold),
                ),
              ),
            ),
            const SizedBox(height: 14),
            ...filtered.map((item) {
              final num = item['number'] as int;
              final isFav = _favorites.contains(num);
              final isMem = _memorized.contains(num);
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colorPrimaryWhite,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: colorAccentGold, width: 1.2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${item['orderLabel']}: ${item['title']}',
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            color: colorDeepGreen,
                          ),
                        ),
                        Row(
                          children: [
                            IconButton(
                              onPressed: () {
                                HapticFeedback.lightImpact();
                                setState(() {
                                  isMem ? _memorized.remove(num) : _memorized.add(num);
                                });
                              },
                              icon: Icon(
                                isMem ? Icons.verified_rounded : Icons.verified_outlined,
                                color: colorRoyalGreen,
                              ),
                            ),
                            IconButton(
                              onPressed: () {
                                HapticFeedback.lightImpact();
                                setState(() {
                                  isFav ? _favorites.remove(num) : _favorites.add(num);
                                });
                              },
                              icon: Icon(
                                isFav ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                                color: colorAccentGold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item['matn'] as String,
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 18,
                        height: 1.9,
                        color: Color(0xFF1E2923),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
