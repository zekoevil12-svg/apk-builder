import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'muslim_woman/muslim_woman_screen.dart';
import 'quran/quran_mushaf_screen.dart';
import 'quran/quran_audio_screen.dart';
import 'gharib_quran/gharib_quran_screen.dart';
import 'alarms/smart_alarm_list_screen.dart';
import 'alarms/fajr_alarm_screen.dart';
import 'alarms/sleep_reminder_screen.dart';
import 'alarms/daily_reminders_screen.dart';
import 'misbaha/central_misbaha_screen.dart';
import 'wasaya/wasaya_screen.dart';
import 'fiqh_muyassar/fiqh_muyassar_screen.dart';
import 'arbain_nawawiya/arbain_nawawiya_screen.dart';
import 'ghiras/ghiras_screen.dart';
import 'ghiras/ghiras_svg_widgets.dart';
import 'settings/notification_settings_page.dart';
import 'category_pages.dart';
import '../widgets/rifq_section_icons.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  int _currentBottomNavIndex = 0;
  int _currentDuaIndex = 0;
  int _currentWisdomIndex = 0;
  late final AnimationController _staggerController;

  @override
  void initState() {
    super.initState();
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
    );
    _staggerController.forward();
  }

  @override
  void dispose() {
    _staggerController.dispose();
    super.dispose();
  }

  // 🎨 Fixed Color Palette
  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);
  static const Color colorTextSecondaryGray = Color(0xFF77798C);

  final List<Map<String, String>> _dailyWisdomList = [
    {
      'type': 'ذكر اليوم',
      'text': '«سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ»',
      'source': 'متفق عليه',
      'virtue': 'حبيبتانِ إلى الرَّحمن، خفيفتانِ على اللسان، ثقيلتانِ في الميزان'
    },
    {
      'type': 'نصيحة اليوم',
      'text': '«احْرِصْ عَلَىٰ مَا يَنْفَعُكَ، وَاسْتَعِنْ بِاللَّهِ وَلَا تَعْجَزْ»',
      'source': 'صحيح مسلم',
      'virtue': 'وصية نبوية جامعة للهمّة العالية والتوكل على الله'
    },
    {
      'type': 'ذكر اليوم',
      'text': '«لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ»',
      'source': 'متفق عليه',
      'virtue': 'كنزٌ من كنوز الجنة وباب عظيم لتيسير الأمور وانشراح الصدر'
    },
    {
      'type': 'نصيحة اليوم',
      'text': '«اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ، وَأَتْبِعِ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا، وَخَالِقِ النَّاسَ بِخُلُقٍ حَسَنٍ»',
      'source': 'جامع الترمذي',
      'virtue': 'قاعدة الحياة الطيبة في التعامل مع الله والنفس والناس'
    },
    {
      'type': 'ذكر اليوم',
      'text': '«أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيَّ الْقَيُّومَ وَأَتُوبُ إِلَيْهِ»',
      'source': 'سنن أبي داود والترمذي',
      'virtue': 'من قالها غُفرت ذنوبه وإن كان فرَّ من الزحف'
    },
    {
      'type': 'نصيحة اليوم',
      'text': '«عَجَبًا لِأَمْرِ الْمُؤْمِنِ، إِنَّ أَمْرَهُ كُلَّهُ خَيْرٌ؛ إِنْ أَصَابَتْهُ سَرَّاءُ شَكَرَ فَكَانَ خَيْرًا لَهُ»',
      'source': 'صحيح مسلم',
      'virtue': 'سكينة القلب والرضا بقضاء الله وقدره'
    }
  ];

  final List<Map<String, String>> _duas = [
    {
      'text': '«اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا»',
      'source': 'سنن ابن ماجه'
    },
    {
      'text': '«يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ»',
      'source': 'جامع الترمذي'
    },
    {
      'text': '«اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ»',
      'source': 'سنن أبي داود'
    },
    {
      'text': '«رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ»',
      'source': 'سورة البقرة: 201'
    },
    {
      'text': '«اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي»',
      'source': 'جامع الترمذي'
    }
  ];

  String _getDynamicGreeting() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 12) {
      return 'صباح الخير';
    } else if (hour >= 12 && hour < 18) {
      return 'مساء الخير';
    } else {
      return 'طاب مساؤك';
    }
  }

  String _getGreetingIconAsset() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 12) {
      return 'assets/icons/menu/ic_morning.png';
    } else if (hour >= 12 && hour < 18) {
      return 'assets/icons/menu/ic_evening.png';
    } else {
      return 'assets/icons/menu/ic_sleep.png';
    }
  }

  String _getHeroTitle() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 12) {
      return 'حان الآن وقت أذكار الصباح';
    } else if (hour >= 15 && hour < 22) {
      return 'حان الآن وقت أذكار المساء';
    } else {
      return 'الصلاة القادمة: صلاة العصر';
    }
  }

  String _getHeroSubtitle() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 12) {
      return '«أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ»';
    } else if (hour >= 15 && hour < 22) {
      return '«أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ»';
    } else {
      return 'باقي 1 ساعة و 24 دقيقة للأذان';
    }
  }

  void _showToast(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle_rounded, color: colorAccentGold, size: 18),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  fontFamily: 'Cairo',
                ),
              ),
            ),
          ],
        ),
        backgroundColor: colorTextDarkBrown,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: colorAccentGold, width: 1.2),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _copyDua() {
    final dua = _duas[_currentDuaIndex];
    final fullText = '${dua['text']}\n[${dua['source']}]\n— تطبيق رِفْق | RIFQ';
    Clipboard.setData(ClipboardData(text: fullText));
    _showToast('تم نسخ الدعاء بنجاح');
  }

  void _shareDua() {
    final dua = _duas[_currentDuaIndex];
    final fullText = '${dua['text']}\n[${dua['source']}]\n— تطبيق رِفْق | RIFQ';
    Clipboard.setData(ClipboardData(text: fullText));
    _showToast('تم نسخ نص الدعاء لمشاركته');
  }

  void _nextDua() {
    setState(() {
      _currentDuaIndex = (_currentDuaIndex + 1) % _duas.length;
    });
  }

  Future<void> _onRefresh() async {
    _staggerController.reset();
    _staggerController.forward();
    await Future.delayed(const Duration(milliseconds: 600));
    setState(() {});
    _showToast('تم تحديث البيانات بنجاح');
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        // ── 【1】شريط علوي (App Bar) ──
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          scrolledUnderElevation: 1,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.5),
            child: Container(
              color: colorAccentGold.withOpacity(0.35),
              height: 1.5,
            ),
          ),
          leading: Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu_rounded, color: colorAccentGold, size: 28),
              onPressed: () => Scaffold.of(context).openDrawer(),
              tooltip: 'القائمة الجانبية',
            ),
          ),
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: colorBackgroundBeige,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: colorAccentGold.withOpacity(0.3)),
                ),
                child: Image.asset(
                  'assets/icons/menu/ic_misbaha.png',
                  width: 22,
                  height: 22,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'الرئيسية',
                style: TextStyle(
                  color: colorAccentGold,
                  fontWeight: FontWeight.w900,
                  fontSize: 21,
                  letterSpacing: -0.5,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.share_outlined, color: colorAccentGold, size: 22),
              onPressed: () {
                Clipboard.setData(const ClipboardData(text: 'https://ais-dev-w24ueafjqjx4xkohc75ff6-637381413504.europe-west1.run.app'));
                _showToast('تم نسخ رابط تطبيق رِفْق للمشاركة');
              },
              tooltip: 'مشاركة',
            ),
            IconButton(
              icon: const Icon(Icons.notifications_none_rounded, color: colorAccentGold, size: 25),
              onPressed: () {
                HapticFeedback.lightImpact();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const NotificationSettingsPage()),
                );
              },
              tooltip: 'الإشعارات',
            ),
            const SizedBox(width: 6),
          ],
        ),

        // ── Drawer (القائمة الجانبية) ──
        drawer: Drawer(
          backgroundColor: colorPrimaryWhite,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.only(top: 50, bottom: 20, right: 20, left: 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFF7F7FC), Color(0xFFEEEEFF)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  border: Border(
                    bottom: BorderSide(color: colorAccentGold, width: 1),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: colorPrimaryWhite,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: colorAccentGold, width: 1.5),
                      ),
                      alignment: Alignment.center,
                      child: Image.asset(
                        'assets/icons/menu/ic_misbaha.png',
                        width: 34,
                        height: 34,
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'رِفْـق | RIFQ',
                      style: TextStyle(color: colorAccentGold, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'رفيقك اليومي للذكر والقرآن الكريم',
                      style: TextStyle(color: colorTextSecondaryGray, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    _buildDrawerItem('المسبحة المركزية', 'assets/icons/menu/ic_misbaha.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('misbaha')),
                      );
                    }),
                    _buildDrawerItem('المنبّه الذكي بتحديات', 'assets/icons/menu/ic_mosque.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const SmartAlarmListScreen()),
                      );
                    }),
                    _buildDrawerItem('منبّه الفجر الفلكي', 'assets/icons/menu/ic_morning.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const FajrAlarmScreen()),
                      );
                    }),
                    _buildDrawerItem('تذكير قبل النوم', 'assets/icons/menu/ic_sleep.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const SleepReminderScreen()),
                      );
                    }),
                    _buildDrawerItem('مواقيت الصلاة', 'assets/icons/menu/ic_mosque.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('prayer_times')),
                      );
                    }),
                    _buildDrawerItem('القرآن الكريم', 'assets/icons/menu/ic_quran.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('quran')),
                      );
                    }),
                    _buildDrawerItem('وِرد | WIRD', 'assets/icons/menu/ic_wird.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('wird')),
                      );
                    }),
                    _buildDrawerItem('غريب القرآن', 'assets/icons/menu/ic_gharib.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('gharib')),
                      );
                    }),
                    _buildDrawerItem('أحكام التجويد', 'assets/icons/menu/ic_tajweed.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('tajweed')),
                      );
                    }),
                    _buildDrawerItem('آية وفائدة', 'assets/icons/menu/ic_tadabbur.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('tadabbur')),
                      );
                    }),
                    _buildDrawerItem('الزكاة والمواريث', 'assets/icons/menu/ic_zakat.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('zakat')),
                      );
                    }),
                    _buildDrawerItem('التقويم والصيام', 'assets/icons/menu/ic_hijri.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('hijri')),
                      );
                    }),
                    _buildDrawerItem('الحج والعمرة', 'assets/icons/menu/ic_hajj.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('hajj')),
                      );
                    }),
                    _buildDrawerItem('الرقية والطب النبوي', 'assets/icons/menu/ic_ruqyah.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('ruqyah')),
                      );
                    }),
                    _buildDrawerItem('رِفْق للمرأة', 'assets/icons/menu/ic_woman_flower.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('woman_flower')),
                      );
                    }),
                    _buildDrawerItem('الأحاديث النبوية', 'assets/icons/menu/ic_hadith.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('hadith')),
                      );
                    }),
                    _buildDrawerItem('الأربعون النووية', 'assets/icons/menu/ic_arbain_nawawiya.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('nawawi')),
                      );
                    }),
                    _buildDrawerItem('وصايا الرسول ﷺ', 'assets/icons/menu/ic_wasaya.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('wasiya')),
                      );
                    }),
                    _buildDrawerItem('الفقه الميسر', 'assets/icons/menu/ic_fiqh_muyassar.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('fiqh_muyassar')),
                      );
                    }),
                    _buildDrawerItem('قصص الصحابة', 'assets/icons/menu/ic_companions.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('sahaba')),
                      );
                    }),
                    _buildDrawerItem('حكايات رِفْق', 'assets/icons/menu/ic_hikayat.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('hikayat')),
                      );
                    }),
                    _buildDrawerItem('قصص الأطفال', 'assets/icons/menu/ic_kids_stories.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('kids_stories')),
                      );
                    }),
                    _buildDrawerItem('موسوعة الأذكار', 'assets/icons/menu/ic_azkar.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('azkar')),
                      );
                    }),
                    _buildDrawerItem('تعليم الوضوء', 'assets/icons/menu/ic_wudu.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('wudu')),
                      );
                    }),
                    _buildDrawerItem('التحفيظ اليومي', 'assets/icons/menu/ic_graduation.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('graduation')),
                      );
                    }),
                    _buildDrawerItem('غراس الجنة', 'assets/icons/menu/ic_palm_tree.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('palm_tree')),
                      );
                    }),
                    _buildDrawerItem('التذكيرات اليومية', 'assets/icons/menu/ic_morning.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('daily_reminders')),
                      );
                    }),
                    _buildDrawerItem('حصاد الأعمال', 'assets/icons/menu/ic_trophy.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('trophy')),
                      );
                    }),
                    _buildDrawerItem('الإحصائيات', 'assets/icons/menu/ic_statistics.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('statistics')),
                      );
                    }),
                    _buildDrawerItem('الملف الشخصي', 'assets/icons/menu/ic_user.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('user')),
                      );
                    }),
                    _buildDrawerItem('أسماء الله', 'assets/icons/menu/ic_allah_names.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('allah_names')),
                      );
                    }),
                    _buildDrawerItem('الإعدادات', 'assets/icons/menu/ic_settings.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('settings')),
                      );
                    }),
                    _buildDrawerItem('تواصل المطور', 'assets/icons/menu/ic_contact.png', () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => _getPageForCategory('code')),
                      );
                    }),
                  ],
                ),
              ),
            ],
          ),
        ),

        // ── الجسم الرئيسي للشاشة ──
        body: RefreshIndicator(
          color: colorAccentGold,
          backgroundColor: colorPrimaryWhite,
          onRefresh: _onRefresh,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            children: [
              // ── 【2】قسم الترحيب ──
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: colorPrimaryWhite,
                          shape: BoxShape.circle,
                          border: Border.all(color: colorAccentGold.withOpacity(0.5)),
                        ),
                        child: Image.asset(
                          _getGreetingIconAsset(),
                          width: 22,
                          height: 22,
                          fit: BoxFit.contain,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        _getDynamicGreeting(),
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: colorTextDarkBrown,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'الإثنين، 21 سبتمبر 2026 • 10 ربيع الأول 1448 هـ',
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600,
                      color: colorTextSecondaryGray,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ── 【3】بطاقة كبيرة بارزة (HeroCard) ──
              _buildHeroCard(),
              const SizedBox(height: 20),

              // ── عنوان شبكة الأقسام (أكبر وأوضح مع شريط ذهبي جانبي) ──
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 5,
                        height: 26,
                        decoration: BoxDecoration(
                          color: colorAccentGold,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Text(
                        'أقسام رِفْـق',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: colorAccentGold,
                          letterSpacing: -0.3,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: colorAccentGold.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: colorAccentGold.withOpacity(0.3)),
                    ),
                    child: const Text(
                      '24 قسماً مباركاً',
                      style: TextStyle(
                        fontSize: 12,
                        color: colorTextDarkBrown,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // ── 【4】شبكة الأقسام (Grid) — 4 أعمدة وبطاقات 90×120 ──
              _buildSectionsGrid(),
              const SizedBox(height: 24),

              // ── 【5】بطاقة "دعاء اليوم" بحجم أوضح وأكبر ──
              _buildDailyDuaCard(),
              const SizedBox(height: 24),
            ],
          ),
        ),

        // ── 【6】شريط التنقل السفلي (Bottom Navigation) — أيقونات PNG حقيقية ──
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: colorPrimaryWhite,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 16,
                offset: const Offset(0, -4),
              ),
            ],
            border: const Border(
              top: BorderSide(
                color: Color(0xFFE6E6F0),
                width: 1.2,
              ),
            ),
          ),
          height: 76,
          child: Row(
            children: [
              // 1. الرئيسية
              _buildBottomNavItem(
                index: 0,
                assetPath: 'assets/icons/menu/ic_home.png',
                label: 'الرئيسية',
              ),
              // 2. القرآن
              _buildBottomNavItem(
                index: 1,
                assetPath: 'assets/icons/menu/ic_quran.png',
                label: 'القرآن',
              ),
              // 3. المسبحة (زر دائري بارز في المنتصف 65px مع توهج هادئ)
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.mediumImpact();
                    setState(() => _currentBottomNavIndex = 2);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CentralMisbahaScreen(),
                      ),
                    );
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          // خلفية التوهج الهادئ (Calm Glow Aura 74px)
                          Container(
                            transform: Matrix4.translationValues(0.0, -18.0, 0.0),
                            width: 74,
                            height: 74,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: colorAccentGold.withOpacity(0.28),
                                  blurRadius: 18,
                                  spreadRadius: 3,
                                ),
                              ],
                            ),
                          ),
                          // الزر الدائري الرئيسي بقطر 65px
                          Container(
                            transform: Matrix4.translationValues(0.0, -18.0, 0.0),
                            width: 65,
                            height: 65,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                colors: [Color(0xFF5B5FEF), Color(0xFF4D51DF), Color(0xFF4145C7)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              border: Border.all(color: Colors.white, width: 3.5),
                              boxShadow: [
                                BoxShadow(
                                  color: colorAccentGold.withOpacity(0.35),
                                  blurRadius: 14,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            alignment: Alignment.center,
                            child: const Icon(
                              Icons.grain_rounded,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                        ],
                      ),
                      Transform.translate(
                        offset: const Offset(0, -14),
                        child: const Text(
                          'المسبحة',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: colorAccentGold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // 4. المواقيت
              _buildBottomNavItem(
                index: 3,
                assetPath: 'assets/icons/menu/ic_mosque.png',
                label: 'المواقيت',
              ),
              // 5. الملف الشخصي
              _buildBottomNavItem(
                index: 4,
                assetPath: 'assets/icons/menu/ic_user.png',
                label: 'حسابي',
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── HeroCard Widget: بطاقة ذهبية أنيقة لنصيحة أو ذكر اليوم ──
  Widget _buildHeroCard() {
    final item = _dailyWisdomList[_currentWisdomIndex];

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          colors: [Color(0xFFFFFFFF), Color(0xFFF7F7FC), Color(0xFFEEEEFF)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        border: Border.all(color: colorAccentGold.withOpacity(0.5), width: 1.6),
        boxShadow: [
          BoxShadow(
            color: colorAccentGold.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // الشريط العلوي: الشارة + زر التبديل
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: colorAccentGold.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        'assets/icons/menu/ic_misbaha.png',
                        width: 16,
                        height: 16,
                        fit: BoxFit.contain,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        item['type']!,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF4145C7),
                        ),
                      ),
                    ],
                  ),
                ),
                InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    HapticFeedback.lightImpact();
                    setState(() {
                      _currentWisdomIndex = (_currentWisdomIndex + 1) % _dailyWisdomList.length;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.refresh_rounded, size: 14, color: colorAccentGold),
                        SizedBox(width: 4),
                        Text(
                          'ذكر آخر',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: colorTextDarkBrown),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // نص الذكر أو النصيحة (خط عريض وواضح)
            Text(
              item['text']!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: colorTextDarkBrown,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 8),

            // المصدر والفضل
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: colorAccentGold.withOpacity(0.25)),
                  ),
                  child: Text(
                    'المصدر: ${item['source']}',
                    style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: Color(0xFF4145C7)),
                  ),
                ),
                if (item['virtue'] != null)
                  Expanded(
                    child: Text(
                      item['virtue']!,
                      textAlign: TextAlign.left,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10, color: Color(0xFF77798C), fontWeight: FontWeight.w600),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 14),

            // الخط الفاصل والأزرار: نسخ ومشاركة
            Container(height: 1, color: colorAccentGold.withOpacity(0.2)),
            const SizedBox(height: 10),

            Row(
              children: [
                // زر نسخ
                Expanded(
                  child: Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {
                        HapticFeedback.mediumImpact();
                        final shareText = '${item['text']}\n\nالمصدر: ${item['source']}\nالفضل: ${item['virtue']}\n— تطبيق رِفْـق | RIFQ';
                        Clipboard.setData(ClipboardData(text: shareText));
                        _showToast('تم نسخ الذكر بنجاح');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: colorAccentGold.withOpacity(0.4)),
                        ),
                        alignment: Alignment.center,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.copy_rounded, size: 15, color: colorAccentGold),
                            SizedBox(width: 6),
                            Text(
                              'نسخ',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: colorTextDarkBrown),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),

                // زر مشاركة
                Expanded(
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {
                        HapticFeedback.mediumImpact();
                        final shareText = '${item['text']}\n\nالمصدر: ${item['source']}\nالفضل: ${item['virtue']}\n— تطبيق رِفْـق | RIFQ';
                        Clipboard.setData(ClipboardData(text: shareText));
                        _showToast('تم نسخ نص الذكر لمشاركته');
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          gradient: const LinearGradient(
                            colors: [Color(0xFF5B5FEF), Color(0xFF4D51DF), Color(0xFF4145C7)],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: colorAccentGold.withOpacity(0.3),
                              blurRadius: 6,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        alignment: Alignment.center,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.share_rounded, size: 15, color: Colors.white),
                            SizedBox(width: 6),
                            Text(
                              'مشاركة',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── دالة التنقل المركزية لكل قسم (بدون أي SnackBar) ──
  Widget _getPageForCategory(String route) {
    switch (route) {
      case 'misbaha':
        return const MisbahaPage();
      case 'quran':
        return const QuranPage();
      case 'quran_audio':
        return const QuranAudioPage();
      case 'prayer_times':
        return const PrayerTimesPage();
      case 'wird':
        return const WirdPage();
      case 'nawawi':
        return const NawawiPage();
      case 'wasiya':
        return const WasiyaPage();
      case 'sahaba':
        return const SahabaPage();
      case 'kids_stories':
        return const KidsStoriesPage();
      case 'azkar':
        return const AzkarPage();
      case 'wudu':
        return const WuduPage();
      case 'graduation':
        return const MemorizationPage();
      case 'trophy':
        return const AchievementsPage();
      case 'palm_tree':
        return const ParadiseGardenPage();
      case 'microphone':
        return const SmartTasbeehPage();
      case 'woman_flower':
        return const WomenRifqPage();
      case 'statistics':
        return const StatisticsPage();
      case 'user':
        return const ProfilePage();
      case 'settings':
        return const SettingsPage();
      case 'code':
        return const ContactPage();
      case 'allah_names':
        return const AllahNamesPage();
      case 'gharib':
        return const GharibQuranScreen();
      case 'fiqh_muyassar':
        return const FiqhMuyassarScreen();
      case 'daily_reminders':
        return const DailyRemindersScreen();
      case 'hadith':
        return const HadithPage();
      case 'tajweed':
        return const TajweedPage();
      case 'tadabbur':
        return const TadabburPage();
      case 'zakat':
        return const ZakatPage();
      case 'hijri':
        return const HijriFastingPage();
      case 'hajj':
        return const HajjUmrahPage();
      case 'ruqyah':
        return const RuqyahPage();
      default:
        return const ComingSoonPage(title: 'قريباً');
    }
  }

  // ── شبكة الأقسام (4 أعمدة على الجوال / 5 على التابلت — تنقل حقيقي لكل قسم) ──
  Widget _buildSectionsGrid() {
    final screenWidth = MediaQuery.of(context).size.width;
    final isTablet = screenWidth >= 600;
    final crossAxisCount = isTablet ? 5 : 4;

    final List<Map<String, String>> categories = [
      // الصف 1: المسبحة | المواقيت | القرآن | القرآن — استماع | وِرد | WIRD
      {'name': 'المسبحة', 'route': 'misbaha', 'icon': 'assets/icons/menu/ic_misbaha.png'},
      {'name': 'المواقيت', 'route': 'prayer_times', 'icon': 'assets/icons/menu/ic_mosque.png'},
      {'name': 'القرآن', 'route': 'quran', 'icon': 'assets/icons/menu/ic_quran.png'},
      {'name': 'القرآن — استماع', 'route': 'quran_audio', 'icon': 'assets/icons/menu/ic_quran_audio.png'},
      {'name': 'وِرد | WIRD', 'route': 'wird', 'icon': 'assets/icons/menu/ic_wird.png'},

      // الصف 2: الأربعون النووية | وصايا الرسول ﷺ | قصص الصحابة | قصص الأطفال | الأحاديث | غريب القرآن | أحكام التجويد
      {'name': 'الأربعون النووية', 'route': 'nawawi', 'icon': 'assets/icons/menu/ic_arbain_nawawiya.png'},
      {'name': 'وصايا الرسول ﷺ', 'route': 'wasiya', 'icon': 'assets/icons/menu/ic_wasaya.png'},
      {'name': 'قصص الصحابة', 'route': 'sahaba', 'icon': 'assets/icons/menu/ic_companions.png'},
      {'name': 'قصص الأطفال', 'route': 'kids_stories', 'icon': 'assets/icons/menu/ic_kids_stories.png'},
      {'name': 'الأحاديث', 'route': 'hadith', 'icon': 'assets/icons/menu/ic_hadith.png'},
      {'name': 'غريب القرآن', 'route': 'gharib', 'icon': 'assets/icons/menu/ic_gharib.png'},
      {'name': 'أحكام التجويد', 'route': 'tajweed', 'icon': 'assets/icons/menu/ic_tajweed.png'},

      // الصف 3: الفقه الميسر | آية وفائدة | الزكاة والمواريث | التقويم والصيام | الحج والعمرة
      {'name': 'الفقه الميسر', 'route': 'fiqh_muyassar', 'icon': 'assets/icons/menu/ic_fiqh_muyassar.png'},
      {'name': 'آية وفائدة', 'route': 'tadabbur', 'icon': 'assets/icons/menu/ic_tadabbur.png'},
      {'name': 'الزكاة والمواريث', 'route': 'zakat', 'icon': 'assets/icons/menu/ic_zakat.png'},
      {'name': 'التقويم والصيام', 'route': 'hijri', 'icon': 'assets/icons/menu/ic_hijri.png'},
      {'name': 'الحج والعمرة', 'route': 'hajj', 'icon': 'assets/icons/menu/ic_hajj.png'},

      // الصف 4: الرقية والطب النبوي | الأذكار | تعليم الوضوء | التحفيظ | رِفْق للمرأة
      {'name': 'الرقية والطب النبوي', 'route': 'ruqyah', 'icon': 'assets/icons/menu/ic_ruqyah.png'},
      {'name': 'الأذكار', 'route': 'azkar', 'icon': 'assets/icons/menu/ic_azkar.png'},
      {'name': 'تعليم الوضوء', 'route': 'wudu', 'icon': 'assets/icons/menu/ic_wudu.png'},
      {'name': 'التحفيظ', 'route': 'graduation', 'icon': 'assets/icons/menu/ic_graduation.png'},
      {'name': 'رِفْق للمرأة', 'route': 'woman_flower', 'icon': 'assets/icons/menu/ic_woman_flower.png'},

      // الصف 5: حصاد الأعمال | غراس الجنة | التذكيرات اليومية | أسماء الله
      {'name': 'حصاد الأعمال', 'route': 'trophy', 'icon': 'assets/icons/menu/ic_trophy.png'},
      {'name': 'غراس الجنة', 'route': 'palm_tree', 'icon': 'assets/icons/menu/ic_palm_tree.png'},
      {'name': 'التذكيرات اليومية', 'route': 'daily_reminders', 'icon': 'assets/icons/menu/ic_morning.png'},
      {'name': 'أسماء الله', 'route': 'allah_names', 'icon': 'assets/icons/menu/ic_allah_names.png'},

      // الصف 6: الإحصائيات | الملف الشخصي | الإعدادات | تواصل المطور
      {'name': 'الإحصائيات', 'route': 'statistics', 'icon': 'assets/icons/menu/ic_statistics.png'},
      {'name': 'الملف الشخصي', 'route': 'user', 'icon': 'assets/icons/menu/ic_user.png'},
      {'name': 'الإعدادات', 'route': 'settings', 'icon': 'assets/icons/menu/ic_settings.png'},
      {'name': 'تواصل المطور', 'route': 'code', 'icon': 'assets/icons/menu/ic_contact.png'},
    ];

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: const EdgeInsets.symmetric(vertical: 4),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 90 / 120,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final category = categories[index];
        return _SectionCardItem(
          item: category,
          index: index,
          animationController: _staggerController,
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => _getPageForCategory(category['route']!),
              ),
            );
          },
        );
      },
    );
  }

  // ── 【5】بطاقة دعاء اليوم (أكبر وأوضح مع خط 18px وأزرار واسعة) ──
  Widget _buildDailyDuaCard() {
    final dua = _duas[_currentDuaIndex];

    return Container(
      decoration: BoxDecoration(
        color: colorPrimaryWhite,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colorAccentGold.withOpacity(0.4), width: 1.4),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          // Header: Title + Rotate button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Image.asset(
                    'assets/icons/menu/ic_azkar.png',
                    width: 26,
                    height: 26,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'دعاء اليوم',
                    style: TextStyle(
                      color: colorAccentGold,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ],
              ),
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: _nextDua,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: colorBackgroundBeige,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: colorAccentGold.withOpacity(0.3)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.refresh_rounded, color: colorAccentGold, size: 18),
                      SizedBox(width: 4),
                      Text(
                        'دعاء آخر',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: colorTextDarkBrown,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 14),

          // Dua Text (18px كبير وواضح جداً للقراءة المريحة)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6.0),
            child: Column(
              children: [
                Text(
                  dua['text']!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Cairo',
                    color: colorTextDarkBrown,
                    height: 1.65,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: colorBackgroundBeige,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: colorAccentGold.withOpacity(0.25)),
                  ),
                  child: Text(
                    dua['source']!,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF4145C7),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 14),

          // Buttons: Copy & Share with Ripple
          Row(
            children: [
              // زر نسخ مع Material Ripple حقيقي
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: Ink(
                    decoration: BoxDecoration(
                      color: colorBackgroundBeige,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: colorAccentGold.withOpacity(0.35)),
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      splashColor: colorAccentGold.withOpacity(0.25),
                      highlightColor: colorAccentGold.withOpacity(0.1),
                      onTap: () {
                        HapticFeedback.lightImpact();
                        _copyDua();
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.copy_rounded, size: 18, color: colorAccentGold),
                            SizedBox(width: 8),
                            Text(
                              'نسخ الدعاء',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                                color: colorTextDarkBrown,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),

              // زر مشاركة مع Material Ripple فوق التدرج الذهبي
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: Ink(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: const LinearGradient(
                        colors: [Color(0xFF5B5FEF), Color(0xFF4D51DF), Color(0xFF4145C7)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colorAccentGold.withOpacity(0.35),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      splashColor: Colors.white.withOpacity(0.35),
                      highlightColor: Colors.white.withOpacity(0.15),
                      onTap: () {
                        HapticFeedback.lightImpact();
                        _shareDua();
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.share_rounded, size: 18, color: Colors.white),
                            SizedBox(width: 8),
                            Text(
                              'مشاركة',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Cairo',
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Bottom Nav Item Builder (أيقونات PNG حقيقية 28px ونصوص 12px) ──
  Widget _buildBottomNavItem({
    required int index,
    required String assetPath,
    required String label,
  }) {
    final bool isSelected = _currentBottomNavIndex == index;

    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.lightImpact();
            setState(() => _currentBottomNavIndex = index);
            if (index == 1) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => _getPageForCategory('quran'),
                ),
              );
            } else if (index == 3) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => _getPageForCategory('prayer_times'),
                ),
              );
            } else if (index == 4) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => _getPageForCategory('user'),
                ),
              );
            }
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Thin gold active indicator line at top
              if (isSelected)
                Container(
                  height: 3.5,
                  width: 36,
                  decoration: BoxDecoration(
                    color: colorAccentGold,
                    borderRadius: BorderRadius.circular(2),
                  ),
                )
              else
                const SizedBox(height: 3.5),
              const Spacer(),
              Icon(
                RifqIconAssets.resolveVectorIcon(label),
                size: 25,
                color: isSelected ? colorAccentGold : colorTextSecondaryGray,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w900 : FontWeight.bold,
                  fontFamily: 'Cairo',
                  color: isSelected ? colorAccentGold : colorTextSecondaryGray,
                ),
              ),
              const SizedBox(height: 6),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerItem(String title, String iconAssetPath, VoidCallback onTap) {
    return ListTile(
      leading: RifqSectionIconWidget(
        sectionName: title,
        assetPath: iconAssetPath,
        size: 38,
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: colorTextDarkBrown,
        ),
      ),
      onTap: onTap,
    );
  }
}

// ── 【3】بطاقة القسم الكاملة وفق مواصفات رِفْق الحديثة (White Card + Border #E6E6F0 + أيقونة احترافية) ──
class _SectionCardItem extends StatefulWidget {
  final Map<String, dynamic> item;
  final VoidCallback onTap;
  final int index;
  final AnimationController animationController;

  const _SectionCardItem({
    Key? key,
    required this.item,
    required this.onTap,
    required this.index,
    required this.animationController,
  }) : super(key: key);

  @override
  State<_SectionCardItem> createState() => _SectionCardItemState();
}

class _SectionCardItemState extends State<_SectionCardItem> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    final name = (widget.item['name'] ?? widget.item['title']) as String;
    final iconPath = (widget.item['icon'] ?? RifqIconAssets.resolveBySectionName(name)) as String;

    final start = (widget.index * 0.04).clamp(0.0, 0.65);
    final end = (start + 0.35).clamp(0.0, 1.0);
    final curvedAnim = CurvedAnimation(
      parent: widget.animationController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
    final slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.25),
      end: Offset.zero,
    ).animate(curvedAnim);
    final fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(curvedAnim);
    final scaleAnim = Tween<double>(begin: 0.94, end: 1.0).animate(curvedAnim);

    return FadeTransition(
      opacity: fadeAnim,
      child: SlideTransition(
        position: slideAnim,
        child: ScaleTransition(
          scale: scaleAnim,
          child: GestureDetector(
            onTapDown: (_) => setState(() => _isPressed = true),
            onTapUp: (_) => setState(() => _isPressed = false),
            onTapCancel: () => setState(() => _isPressed = false),
            onTap: widget.onTap,
            child: AnimatedScale(
              scale: _isPressed ? 0.95 : 1.0,
              duration: const Duration(milliseconds: 120),
              curve: Curves.easeInOut,
              child: Container(
                width: 90,
                height: 120,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFFFF),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: const Color(0xFFE6E6F0),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF25263A).withOpacity(0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RifqSectionIconWidget(
                      sectionName: name,
                      assetPath: iconPath,
                      size: 54,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      name,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: Color(0xFF25263A),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
