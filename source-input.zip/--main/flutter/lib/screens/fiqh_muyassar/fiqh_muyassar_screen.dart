import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/fiqh_muyassar_sqlite_service.dart';

class FiqhMuyassarScreen extends StatefulWidget {
  const FiqhMuyassarScreen({Key? key}) : super(key: key);

  @override
  State<FiqhMuyassarScreen> createState() => _FiqhMuyassarScreenState();
}

enum _FiqhSubScreen { home, category, detail, search, favorites }

class _FiqhMuyassarScreenState extends State<FiqhMuyassarScreen> {
  static const Color colorGold = Color(0xFF5B5FEF);
  static const Color colorLightGold = Color(0xFFE8B84A);
  static const Color colorWhite = Color(0xFFFFFFFF);
  static const Color colorBeige = Color(0xFFF7F7FC);
  static const Color colorBrown = Color(0xFF25263A);
  static const Color colorGray = Color(0xFF77798C);
  static const Color colorGreen = Color(0xFF4CAF82);

  _FiqhSubScreen _subScreen = _FiqhSubScreen.home;
  _FiqhSubScreen _previousScreen = _FiqhSubScreen.home;

  List<FiqhCategoryModel> _categories = [];
  List<FiqhTopicModel> _allTopics = [];
  Set<String> _favoriteIds = {};

  String _selectedCategoryId = 'tahara';
  String _selectedSubtopic = 'all';
  FiqhTopicModel? _selectedTopic;
  String _searchQuery = '';
  String _selectedFilterCategory = 'all';
  double _fontScale = 1.0;
  bool _isDarkMode = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final cats = await FiqhMuyassarSqliteService.instance.getCategories();
    final topics = await FiqhMuyassarSqliteService.instance.getAllTopics();
    final favs = await FiqhMuyassarSqliteService.instance.getFavoriteIds();
    if (!mounted) return;
    setState(() {
      _categories = cats;
      _allTopics = topics;
      _favoriteIds = favs;
      _selectedTopic = topics.isNotEmpty ? topics.first : null;
      _isLoading = false;
    });
  }

  FiqhTopicModel? get _dailyTopic {
    if (_allTopics.isEmpty) return null;
    final dayOfYear =
        DateTime.now().difference(DateTime(DateTime.now().year, 1, 1)).inDays;
    return _allTopics[dayOfYear % _allTopics.length];
  }

  Future<void> _toggleFav(String topicId) async {
    HapticFeedback.lightImpact();
    final isFav = await FiqhMuyassarSqliteService.instance.toggleFavorite(topicId);
    final favs = await FiqhMuyassarSqliteService.instance.getFavoriteIds();
    final topics = await FiqhMuyassarSqliteService.instance.getAllTopics();
    if (!mounted) return;
    setState(() {
      _favoriteIds = favs;
      _allTopics = topics;
      if (_selectedTopic?.id == topicId) {
        _selectedTopic = topics.firstWhere((t) => t.id == topicId);
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isFav ? 'تم حفظ المسألة الفقهية في المفضلة' : 'تمت إزالة المسألة من المفضلة',
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: colorBrown,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatShareText(FiqhTopicModel topic) {
    return '【الفقه الميسر | تطبيق رِفْق】\n'
        'المبحث: ${topic.subtopic} — ${topic.title}\n'
        'الحكم الشرعي: ${topic.rulingBadge}\n\n'
        '• الخلاصة: ${topic.summary}\n'
        '• الدليل من القرآن: ${topic.quranAyah} (${topic.quranSurah})\n'
        '• الدليل من السنة: ${topic.sunnahHadith} (${topic.sunnahSource})\n'
        '• المرجع: ${topic.fiqhReference}';
  }

  Future<void> _copyTopic(FiqhTopicModel topic) async {
    await Clipboard.setData(ClipboardData(text: _formatShareText(topic)));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'تم نسخ المسألة والحكم الفقهي مع الدليل والمصدر',
          style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: colorGreen,
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> _shareTopic(FiqhTopicModel topic) async {
    await Share.share(_formatShareText(topic));
  }

  static const String _scaleBookSvg = '''
<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="24" cy="24" r="22" fill="#F7F7FC" stroke="#5B5FEF" stroke-width="2"/>
  <path d="M24 8V29" stroke="#5B5FEF" stroke-width="2.2" stroke-linecap="round"/>
  <circle cx="24" cy="8" r="2" fill="#4CAF82"/>
  <path d="M12 13H36" stroke="#5B5FEF" stroke-width="2" stroke-linecap="round"/>
  <path d="M12 13L9 21H15L12 13Z" stroke="#5B5FEF" stroke-width="1.5"/>
  <path d="M8.5 21C8.5 22.8 10 24 12 24C14 24 15.5 22.8 15.5 21H8.5Z" fill="#5B5FEF"/>
  <path d="M36 13L33 21H39L36 13Z" stroke="#5B5FEF" stroke-width="1.5"/>
  <path d="M32.5 21C32.5 22.8 34 24 36 24C38 24 39.5 22.8 39.5 21H32.5Z" fill="#5B5FEF"/>
  <path d="M12 30C12 28.9 12.9 28 14 28H22C23.1 28 24 28.9 24 30V39H13.5C12.7 39 12 38.3 12 37.5V30Z" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="1.8"/>
  <path d="M36 30C36 28.9 35.1 28 34 28H26C24.9 28 24 28.9 24 30V39H34.5C35.3 39 36 38.3 36 37.5V30Z" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="1.8"/>
</svg>
''';

  void _handleBack() {
    if (_subScreen == _FiqhSubScreen.home) {
      Navigator.of(context).maybePop();
    } else if (_subScreen == _FiqhSubScreen.detail) {
      setState(() {
        _subScreen = _previousScreen == _FiqhSubScreen.detail
            ? _FiqhSubScreen.category
            : _previousScreen;
      });
    } else {
      setState(() {
        _subScreen = _FiqhSubScreen.home;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bgMain = _isDarkMode ? const Color(0xFF1A1412) : colorBeige;
    final bgCard = _isDarkMode ? const Color(0xFF261E1B) : colorWhite;
    final textPrimary = _isDarkMode ? colorBeige : colorBrown;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgMain,
        appBar: AppBar(
          backgroundColor: bgMain,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorGold),
            onPressed: _handleBack,
          ),
          title: Row(
            children: [
              SvgPicture.string(_scaleBookSvg, width: 32, height: 32),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'الفقه الميسر',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: colorGold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search_rounded, color: colorGold),
              onPressed: () => setState(() => _subScreen = _FiqhSubScreen.search),
            ),
            IconButton(
              icon: Icon(
                _favoriteIds.isNotEmpty
                    ? Icons.favorite_rounded
                    : Icons.favorite_border_rounded,
                color: colorGold,
              ),
              onPressed: () =>
                  setState(() => _subScreen = _FiqhSubScreen.favorites),
            ),
            IconButton(
              icon: Icon(
                _isDarkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round,
                color: colorGold,
              ),
              onPressed: () => setState(() => _isDarkMode = !_isDarkMode),
            ),
          ],
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: colorGold))
            : _buildBody(bgCard, textPrimary),
      ),
    );
  }

  Widget _buildBody(Color bgCard, Color textPrimary) {
    switch (_subScreen) {
      case _FiqhSubScreen.home:
        return _buildHome(bgCard, textPrimary);
      case _FiqhSubScreen.category:
        return _buildCategoryList(bgCard, textPrimary);
      case _FiqhSubScreen.detail:
        return _buildDetail(bgCard, textPrimary);
      case _FiqhSubScreen.search:
        return _buildSearch(bgCard, textPrimary);
      case _FiqhSubScreen.favorites:
        return _buildFavorites(bgCard, textPrimary);
    }
  }

  Widget _buildHome(Color bgCard, Color textPrimary) {
    final daily = _dailyTopic;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // البطاقة الترحيبية
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  SvgPicture.string(_scaleBookSvg, width: 48, height: 48),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'موسوعة الفقه الميسر في ضوء الكتاب والسنة',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: colorGold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'قَالَ رَسُولُ اللَّهِ ﷺ: «مَنْ يُرِدِ اللَّهُ بِهِ خَيْرًا يُفَقِّهْهُ فِي الدِّينِ»',
                          style: TextStyle(
                            fontFamily: 'Amiri',
                            fontSize: 16,
                            color: colorGreen,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // مسألة اليوم الفقهية
        if (daily != null) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: bgCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: colorGold, width: 1.5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'مسألة اليوم الفقهية • ${daily.subtopic}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: colorGold,
                      ),
                    ),
                    Text(
                      daily.rulingBadge,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        color: colorGreen,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  daily.title,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 16 * _fontScale,
                    color: textPrimary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  daily.summary,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 13.5 * _fontScale,
                    color: colorGray,
                  ),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: colorGreen,
                      foregroundColor: colorWhite,
                    ),
                    onPressed: () {
                      setState(() {
                        _selectedTopic = daily;
                        _previousScreen = _FiqhSubScreen.home;
                        _subScreen = _FiqhSubScreen.detail;
                      });
                    },
                    child: const Text(
                      'قراءة التفصيل والأدلة',
                      style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],

        // شبكة الأبواب الفقهية الثمانية
        const Text(
          'أبواب الفقه الميسر (8 أبواب معتمدة)',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: colorGold,
          ),
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
          ),
          itemCount: _categories.length,
          itemBuilder: (context, index) {
            final cat = _categories[index];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () {
                setState(() {
                  _selectedCategoryId = cat.id;
                  _selectedSubtopic = 'all';
                  _previousScreen = _FiqhSubScreen.home;
                  _subScreen = _FiqhSubScreen.category;
                });
              },
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: bgCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: colorGold),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SvgPicture.string(_scaleBookSvg, width: 34, height: 34),
                        Text(
                          '${cat.subtopics.length} مباحث',
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                            color: colorGreen,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      'كتاب ${cat.name}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: colorGold,
                      ),
                    ),
                    Text(
                      cat.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 11,
                        color: colorGray,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCategoryList(Color bgCard, Color textPrimary) {
    final items = _allTopics.where((t) {
      if (t.categoryId != _selectedCategoryId) return false;
      if (_selectedSubtopic != 'all' && t.subtopic != _selectedSubtopic) {
        return false;
      }
      return true;
    }).toList();

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, idx) {
        final topic = items[idx];
        return _buildTopicCard(topic, bgCard, textPrimary, _FiqhSubScreen.category);
      },
    );
  }

  Widget _buildTopicCard(
    FiqhTopicModel topic,
    Color bgCard,
    Color textPrimary,
    _FiqhSubScreen from,
  ) {
    final isFav = _favoriteIds.contains(topic.id);
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        setState(() {
          _selectedTopic = topic;
          _previousScreen = from;
          _subScreen = _FiqhSubScreen.detail;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: colorGold),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'مبحث: ${topic.subtopic}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: colorGold,
                  ),
                ),
                Text(
                  topic.rulingBadge,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: colorGreen,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              topic.title,
              style: TextStyle(
                fontFamily: 'Cairo',
                fontWeight: FontWeight.bold,
                fontSize: 15 * _fontScale,
                color: textPrimary,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              topic.summary,
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 13 * _fontScale,
                color: colorGray,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    topic.fiqhReference,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 11,
                      color: colorGreen,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.copy_rounded, size: 18, color: colorGold),
                      onPressed: () => _copyTopic(topic),
                    ),
                    IconButton(
                      icon: const Icon(Icons.share_rounded, size: 18, color: colorGreen),
                      onPressed: () => _shareTopic(topic),
                    ),
                    IconButton(
                      icon: Icon(
                        isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        size: 18,
                        color: colorGold,
                      ),
                      onPressed: () => _toggleFav(topic.id),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetail(Color bgCard, Color textPrimary) {
    final topic = _selectedTopic;
    if (topic == null) return const SizedBox.shrink();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold, width: 1.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${topic.subtopic} • الحكم: ${topic.rulingBadge}',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: colorGold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                topic.title,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18 * _fontScale,
                  color: textPrimary,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                topic.definitionAndExplanation,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 14 * _fontScale,
                  color: textPrimary,
                  height: 1.7,
                ),
              ),
              const Divider(height: 24, color: colorGold),
              const Text(
                'الأدلة الشرعية من الكتاب والسنة:',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: colorGold,
                ),
              ),
              const SizedBox(height: 8),
              if (topic.quranAyah.isNotEmpty) ...[
                Text(
                  '${topic.quranAyah} (${topic.quranSurah})',
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 17 * _fontScale,
                    color: colorGreen,
                  ),
                ),
                const SizedBox(height: 8),
              ],
              Text(
                topic.sunnahHadith,
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 17 * _fontScale,
                  color: textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'التخريج: ${topic.sunnahSource}',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: colorGreen,
                ),
              ),
              const Divider(height: 24, color: colorGold),
              Text(
                'المرجع: ${topic.fiqhReference}',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: colorGold,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSearch(Color bgCard, Color textPrimary) {
    final results = _allTopics.where((t) {
      if (_selectedFilterCategory != 'all' &&
          t.categoryId != _selectedFilterCategory) {
        return false;
      }
      if (_searchQuery.trim().isEmpty) return true;
      final q = _searchQuery.trim();
      return t.title.contains(q) ||
          t.subtopic.contains(q) ||
          t.summary.contains(q) ||
          t.definitionAndExplanation.contains(q);
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            onChanged: (v) => setState(() => _searchQuery = v),
            decoration: InputDecoration(
              hintText: 'ابحث في المسائل والأحكام والأدلة...',
              filled: true,
              fillColor: bgCard,
              prefixIcon: const Icon(Icons.search_rounded, color: colorGold),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: const BorderSide(color: colorGold),
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: results.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) => _buildTopicCard(
              results[index],
              bgCard,
              textPrimary,
              _FiqhSubScreen.search,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFavorites(Color bgCard, Color textPrimary) {
    final favs =
        _allTopics.where((t) => _favoriteIds.contains(t.id)).toList();
    if (favs.isEmpty) {
      return const Center(
        child: Text(
          'لا توجد مسائل محفوظة في المفضلة بعد',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: colorGold,
          ),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: favs.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) => _buildTopicCard(
        favs[index],
        bgCard,
        textPrimary,
        _FiqhSubScreen.favorites,
      ),
    );
  }
}
