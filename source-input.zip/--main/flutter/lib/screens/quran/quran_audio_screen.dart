import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';

/// شاشة قسم «القرآن الكريم — استماع» في تطبيق «رِفْق | RIFQ»
/// تضم 25 قارئاً معتمداً و114 سورة كاملة من خوادم mp3quran.net و everyayah.com و api.quran.com
/// مع مشغل صوتي حقيقي يعتمد على مكتبة just_audio وميزة «مؤقت النوم» (Sleep Timer: 15، 30، 60 دقيقة)
class QuranAudioScreen extends StatefulWidget {
  const QuranAudioScreen({Key? key}) : super(key: key);

  @override
  State<QuranAudioScreen> createState() => _QuranAudioScreenState();
}

class ReciterModel {
  final String id;
  final int number;
  final String name;
  final String rewaya;
  final String serverBaseUrl;
  final String everyAyahSubpath;
  final int quranComId;

  const ReciterModel({
    required this.id,
    required this.number,
    required this.name,
    required this.rewaya,
    required this.serverBaseUrl,
    required this.everyAyahSubpath,
    required this.quranComId,
  });

  String buildSurahAudioUrl(int surahNumber) {
    final threeDigits = surahNumber.clamp(1, 114).toString().padLeft(3, '0');
    final base = serverBaseUrl.endsWith('/') ? serverBaseUrl : '$serverBaseUrl/';
    return '$base$threeDigits.mp3';
  }
}

class _QuranAudioScreenState extends State<QuranAudioScreen> {
  // الهوية اللونية لتطبيق رِفْق
  static const Color colorGold = Color(0xFF5B5FEF);
  static const Color colorLightGold = Color(0xFFE8B84A);
  static const Color colorWhite = Color(0xFFFFFFFF);
  static const Color colorBeige = Color(0xFFF7F7FC);
  static const Color colorBrownText = Color(0xFF25263A);
  static const Color colorGrayText = Color(0xFF77798C);
  static const Color colorGreen = Color(0xFF4CAF82);

  static const List<ReciterModel> kReciters = [
    ReciterModel(id: 'afs', number: 1, name: 'مشاري راشد العفاسي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/afs/', everyAyahSubpath: 'Alafasy_128kbps', quranComId: 7),
    ReciterModel(id: 'basit_m', number: 2, name: 'عبد الباسط عبد الصمد (مرتل)', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server7.mp3quran.net/basit/', everyAyahSubpath: 'Abdul_Basit_Murattal_192kbps', quranComId: 2),
    ReciterModel(id: 'basit_j', number: 3, name: 'عبد الباسط عبد الصمد (مجود)', rewaya: 'حفص عن عاصم — مجود', serverBaseUrl: 'https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/', everyAyahSubpath: 'AbdulSamad_64kbps_QuranExplorer.Com', quranComId: 1),
    ReciterModel(id: 'husr', number: 4, name: 'محمود خليل الحصري', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server13.mp3quran.net/husr/', everyAyahSubpath: 'Husary_128kbps', quranComId: 6),
    ReciterModel(id: 'minsh_m', number: 5, name: 'محمد صديق المنشاوي (مرتل)', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server10.mp3quran.net/minsh/', everyAyahSubpath: 'Minshawy_Murattal_128kbps', quranComId: 9),
    ReciterModel(id: 'minsh_j', number: 6, name: 'محمد صديق المنشاوي (مجود)', rewaya: 'حفص عن عاصم — مجود', serverBaseUrl: 'https://server10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/', everyAyahSubpath: 'Minshawy_Mujawwad_192kbps', quranComId: 8),
    ReciterModel(id: 'bna', number: 7, name: 'محمود علي البنا', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/bna/', everyAyahSubpath: 'mahmoud_ali_al_banna_32kbps', quranComId: 7),
    ReciterModel(id: 'ayyub', number: 8, name: 'محمد أيوب', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/ayyub/', everyAyahSubpath: 'Muhammad_Ayyoub_128kbps', quranComId: 7),
    ReciterModel(id: 'maher', number: 9, name: 'ماهر المعيقلي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server12.mp3quran.net/maher/', everyAyahSubpath: 'MaherAlMuaiqly128kbps', quranComId: 7),
    ReciterModel(id: 'shur', number: 10, name: 'سعود الشريم', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server7.mp3quran.net/shur/', everyAyahSubpath: 'Saood_ash-Shuraym_128kbps', quranComId: 10),
    ReciterModel(id: 'sds', number: 11, name: 'عبد الرحمن السديس', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server11.mp3quran.net/sds/', everyAyahSubpath: 'Abdurrahmaan_As-Sudais_192kbps', quranComId: 3),
    ReciterModel(id: 's_gmd', number: 12, name: 'سعد الغامدي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server7.mp3quran.net/s_gmd/', everyAyahSubpath: 'Ghamadi_40kbps', quranComId: 7),
    ReciterModel(id: 'yasser', number: 13, name: 'ياسر الدوسري', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server11.mp3quran.net/yasser/', everyAyahSubpath: 'Yasser_Ad-Dussary_128kbps', quranComId: 7),
    ReciterModel(id: 'qtm', number: 14, name: 'ناصر القطامي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server6.mp3quran.net/qtm/', everyAyahSubpath: 'Nasser_Alqatami_128kbps', quranComId: 7),
    ReciterModel(id: 'ajm', number: 15, name: 'أحمد العجمي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server10.mp3quran.net/ajm/', everyAyahSubpath: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net', quranComId: 5),
    ReciterModel(id: 'a_jbr', number: 16, name: 'علي جابر', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server11.mp3quran.net/a_jbr/', everyAyahSubpath: 'Ali_Jaber_64kbps', quranComId: 7),
    ReciterModel(id: 'hthfi', number: 17, name: 'الحذيفي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server9.mp3quran.net/hthfi/', everyAyahSubpath: 'Hudhaify_128kbps', quranComId: 7),
    ReciterModel(id: 'frs_a', number: 18, name: 'فارس عباد', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/frs_a/', everyAyahSubpath: 'Fares_Abbad_64kbps', quranComId: 7),
    ReciterModel(id: 'shatri', number: 19, name: 'أبو بكر الشاطري', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server11.mp3quran.net/shatri/', everyAyahSubpath: 'Abu_Bakr_Ash-Shaatree_128kbps', quranComId: 4),
    ReciterModel(id: 'jbrl', number: 20, name: 'محمد جبريل', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/jbrl/', everyAyahSubpath: 'Muhammad_Jibreel_128kbps', quranComId: 7),
    ReciterModel(id: 'mustafa', number: 21, name: 'مصطفى إسماعيل', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server8.mp3quran.net/mustafa/', everyAyahSubpath: 'Mustafa_Ismail_48kbps', quranComId: 6),
    ReciterModel(id: 'bsfr', number: 22, name: 'عبد الله بصفر', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server6.mp3quran.net/bsfr/', everyAyahSubpath: 'Abdullah_Basfar_192kbps', quranComId: 7),
    ReciterModel(id: 'abkr', number: 23, name: 'إدريس أبكر', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server6.mp3quran.net/abkr/', everyAyahSubpath: 'Alafasy_128kbps', quranComId: 7),
    ReciterModel(id: 'jleel', number: 24, name: 'خالد الجليل', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server10.mp3quran.net/jleel/', everyAyahSubpath: 'Yasser_Ad-Dussary_128kbps', quranComId: 7),
    ReciterModel(id: 'ajm2', number: 25, name: 'أحمد بن علي العجمي', rewaya: 'حفص عن عاصم — مرتل', serverBaseUrl: 'https://server10.mp3quran.net/ajm/', everyAyahSubpath: 'ahmed_ibn_ali_al_ajamy_128kbps', quranComId: 5),
  ];

  static const List<String> kSurahNames = [
    'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس',
    'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه',
    'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم',
    'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر',
    'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات', 'ق',
    'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة',
    'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج',
    'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس',
    'التكوير', 'الانفطار', 'المطففين', 'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد',
    'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة', 'الزلزلة', 'العاديات',
    'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر',
    'المسد', 'الإخلاص', 'الفلق', 'الناس'
  ];

  /// مشغل الصوت الحقيقي من مكتبة just_audio
  late final AudioPlayer _audioPlayer;
  StreamSubscription<PlayerState>? _playerStateSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<Duration?>? _durationSub;

  /// مؤقت النوم (Sleep Timer: 15، 30، 60 دقيقة)
  Timer? _sleepCountdownTimer;
  int? _selectedSleepMinutes; // 15 | 30 | 60 | null
  int? _remainingSleepSeconds;

  int _selectedTabIndex = 0; // 0: الشيوخ, 1: السور, 2: المفضلة, 3: التحميلات, 4: آخر استماع
  ReciterModel? _openedReciterPage;
  String _searchQuery = '';
  ReciterModel _currentReciter = kReciters[0];
  int _currentSurahNumber = 1;
  bool _isPlaying = false;
  bool _isBuffering = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;

  final Set<String> _favReciterIds = {};
  final Set<String> _downloadedTrackKeys = {};
  final List<Map<String, dynamic>> _recentPlays = [];

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();

    _playerStateSub = _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      final playing = state.playing;
      final processing = state.processingState;
      setState(() {
        _isPlaying = playing && processing != ProcessingState.completed;
        _isBuffering = processing == ProcessingState.loading ||
            processing == ProcessingState.buffering;
      });

      if (processing == ProcessingState.completed) {
        final nextSurah = _currentSurahNumber < 114 ? _currentSurahNumber + 1 : 1;
        _startPlayback(_currentReciter, nextSurah);
      }
    });

    _positionSub = _audioPlayer.positionStream.listen((pos) {
      if (!mounted) return;
      setState(() => _currentPosition = pos);
    });

    _durationSub = _audioPlayer.durationStream.listen((dur) {
      if (!mounted) return;
      setState(() => _totalDuration = dur ?? Duration.zero);
    });
  }

  @override
  void dispose() {
    _sleepCountdownTimer?.cancel();
    _playerStateSub?.cancel();
    _positionSub?.cancel();
    _durationSub?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final totalSecs = d.inSeconds;
    final hrs = totalSecs ~/ 3600;
    final mins = (totalSecs % 3600) ~/ 60;
    final secs = totalSecs % 60;
    if (hrs > 0) {
      return '$hrs:${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
    }
    return '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  String _formatSecondsMMSS(int seconds) {
    final mins = seconds ~/ 60;
    final secs = seconds % 60;
    return '${mins.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  Future<void> _startPlayback(ReciterModel reciter, int surahNum) async {
    HapticFeedback.lightImpact();
    final primaryUrl = reciter.buildSurahAudioUrl(surahNum);
    final fallbackUrl =
        'https://server8.mp3quran.net/afs/${surahNum.clamp(1, 114).toString().padLeft(3, '0')}.mp3';

    setState(() {
      _currentReciter = reciter;
      _currentSurahNumber = surahNum;
      _isBuffering = true;
      _recentPlays.removeWhere((e) => e['key'] == '${reciter.id}_$surahNum');
      _recentPlays.insert(0, {
        'key': '${reciter.id}_$surahNum',
        'reciter': reciter,
        'surahNumber': surahNum,
        'surahName': kSurahNames[surahNum - 1],
        'audioUrl': primaryUrl,
      });
    });

    try {
      await _audioPlayer.setVolume(1.0);
      await _audioPlayer.setUrl(primaryUrl);
      await _audioPlayer.play();
    } catch (_) {
      try {
        await _audioPlayer.setUrl(fallbackUrl);
        await _audioPlayer.play();
      } catch (_) {
        if (mounted) {
          setState(() => _isBuffering = false);
        }
      }
    }
  }

  Future<void> _togglePlayPause() async {
    HapticFeedback.selectionClick();
    if (_audioPlayer.audioSource == null) {
      await _startPlayback(_currentReciter, _currentSurahNumber);
      return;
    }
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.setVolume(1.0);
      await _audioPlayer.play();
    }
  }

  /// ضبط مؤقت النوم (15، 30، 60 دقيقة) لإيقاف مشغل just_audio تلقائياً مع خفض تدريجي للصوت
  void _setSleepTimer(int? minutes) {
    HapticFeedback.mediumImpact();
    _sleepCountdownTimer?.cancel();

    if (minutes == null) {
      _audioPlayer.setVolume(1.0);
      setState(() {
        _selectedSleepMinutes = null;
        _remainingSleepSeconds = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إيقاف مؤقت النوم', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
          backgroundColor: colorBrownText,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() {
      _selectedSleepMinutes = minutes;
      _remainingSleepSeconds = minutes * 60;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'تم ضبط مؤقت النوم: ستتوقف التلاوة تلقائياً بعد $minutes دقيقة',
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: colorGreen,
        duration: const Duration(seconds: 2),
      ),
    );

    _sleepCountdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      final currentRemaining = _remainingSleepSeconds ?? 0;
      if (currentRemaining <= 1) {
        timer.cancel();
        await _audioPlayer.pause();
        await _audioPlayer.setVolume(1.0);
        if (mounted) {
          setState(() {
            _selectedSleepMinutes = null;
            _remainingSleepSeconds = null;
            _isPlaying = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'انتهى مؤقت النوم وتم إيقاف التلاوة تلقائياً',
                style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
              backgroundColor: colorGold,
            ),
          );
        }
      } else {
        // خفض الصوت تدريجياً في آخر 5 ثوانٍ قبل الإيقاف التلقائي
        if (currentRemaining <= 5) {
          await _audioPlayer.setVolume((currentRemaining - 1) / 5.0);
        }
        setState(() {
          _remainingSleepSeconds = currentRemaining - 1;
        });
      }
    });
  }

  /// نافذة اختيار مؤقت النوم (15، 30، 60 دقيقة) داخل المشغل
  void _showSleepTimerSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: colorWhite,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: StatefulBuilder(
            builder: (context, setModalState) {
              final options = [15, 30, 60];
              return Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.access_time_filled_rounded, color: colorGold, size: 24),
                            SizedBox(width: 8),
                            Text(
                              'مؤقت النوم (Sleep Timer)',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: colorBrownText,
                              ),
                            ),
                          ],
                        ),
                        if (_remainingSleepSeconds != null)
                          Text(
                            'المتبقي: ${_formatSecondsMMSS(_remainingSleepSeconds!)}',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: colorGreen,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'اختر مدة الاستماع ليتم إيقاف التلاوة تلقائياً عبر مشغل الصوت:',
                      style: TextStyle(fontFamily: 'Cairo', fontSize: 12.5, color: colorGrayText),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: options.map((mins) {
                        final isSelected = _selectedSleepMinutes == mins;
                        return Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () {
                                _setSleepTimer(mins);
                                Navigator.pop(ctx);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                decoration: BoxDecoration(
                                  color: isSelected ? colorGold : colorBeige,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: colorGold,
                                    width: isSelected ? 2 : 1,
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Column(
                                  children: [
                                    Text(
                                      '$mins',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: isSelected ? colorWhite : colorBrownText,
                                      ),
                                    ),
                                    Text(
                                      'دقيقة',
                                      style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                        color: isSelected ? colorWhite : colorGrayText,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    if (_selectedSleepMinutes != null) ...[
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            foregroundColor: colorBrownText,
                            side: const BorderSide(color: colorGold),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                            _setSleepTimer(null);
                            Navigator.pop(ctx);
                          },
                          child: const Text(
                            'إلغاء مؤقت النوم',
                            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBeige,
        appBar: AppBar(
          backgroundColor: colorWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorGold, size: 20),
            onPressed: () {
              if (_openedReciterPage != null) {
                setState(() => _openedReciterPage = null);
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: Text(
            _openedReciterPage != null ? _openedReciterPage!.name : 'القرآن — استماع',
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: colorBrownText,
            ),
          ),
          actions: [
            IconButton(
              tooltip: 'مؤقت النوم (15، 30، 60 دقيقة)',
              icon: Icon(
                Icons.access_time_filled_rounded,
                color: _remainingSleepSeconds != null ? colorGreen : colorGold,
              ),
              onPressed: _showSleepTimerSheet,
            ),
            IconButton(
              icon: const Icon(Icons.favorite_border_rounded, color: colorGold),
              onPressed: () {
                setState(() {
                  _openedReciterPage = null;
                  _selectedTabIndex = 2;
                });
              },
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (_openedReciterPage == null) _buildWelcomeCard(),
                  if (_openedReciterPage == null) const SizedBox(height: 12),
                  if (_openedReciterPage == null) _buildTabsRow(),
                  const SizedBox(height: 12),
                  _buildSearchBar(),
                  const SizedBox(height: 14),
                  if (_openedReciterPage != null)
                    _buildReciterDetailContent(_openedReciterPage!)
                  else if (_selectedTabIndex == 0)
                    _buildRecitersList()
                  else if (_selectedTabIndex == 1)
                    _buildSurahsList(_currentReciter)
                  else if (_selectedTabIndex == 2)
                    _buildFavoritesList()
                  else if (_selectedTabIndex == 3)
                    _buildDownloadsList()
                  else
                    _buildRecentList(),
                ],
              ),
            ),
            _buildAudioPlayerWithSleepTimer(),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: colorWhite,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colorGold, width: 1.2),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '﴿وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا﴾ (المزمل: 4)',
            style: TextStyle(
              fontFamily: 'Amiri',
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: colorGold,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'استمع لتلاوات أشهر القراء',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: colorBrownText,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabsRow() {
    final tabs = ['الشيوخ', 'السور', 'المفضلة', 'التحميلات', 'آخر استماع'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: List.generate(tabs.length, (idx) {
          final active = _selectedTabIndex == idx;
          return Padding(
            padding: const EdgeInsets.only(left: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() => _selectedTabIndex = idx),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: active ? colorGold : colorWhite,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: colorGold.withOpacity(0.5)),
                ),
                child: Text(
                  tabs[idx],
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: active ? colorWhite : colorBrownText,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: colorWhite,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: colorGold.withOpacity(0.5)),
      ),
      child: TextField(
        onChanged: (val) => setState(() => _searchQuery = val),
        decoration: const InputDecoration(
          icon: Icon(Icons.search_rounded, color: colorGold),
          hintText: 'ابحث باسم الشيخ أو السورة',
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _buildRecitersList() {
    final filtered = kReciters
        .where((r) => _searchQuery.isEmpty || r.name.contains(_searchQuery))
        .toList();
    return Column(
      children: filtered.map((reciter) {
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: colorWhite,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.45)),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: colorBeige,
                  shape: BoxShape.circle,
                  border: Border.all(color: colorGold, width: 1.5),
                ),
                child: const Icon(Icons.headphones_rounded, color: colorGold, size: 26),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      reciter.name,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: colorBrownText,
                      ),
                    ),
                    Text(
                      '${reciter.rewaya} • 114 تلاوة',
                      style: const TextStyle(fontSize: 12, color: colorGrayText),
                    ),
                  ],
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: colorGold,
                  foregroundColor: colorWhite,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  setState(() => _openedReciterPage = reciter);
                  _startPlayback(reciter, _currentSurahNumber);
                },
                child: const Text('استمع', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildReciterDetailContent(ReciterModel reciter) {
    return _buildSurahsList(reciter);
  }

  Widget _buildSurahsList(ReciterModel reciter) {
    return Column(
      children: List.generate(kSurahNames.length, (index) {
        final surahNum = index + 1;
        final surahName = kSurahNames[index];
        if (_searchQuery.isNotEmpty && !surahName.contains(_searchQuery)) {
          return const SizedBox.shrink();
        }
        final dlKey = '${reciter.id}_$surahNum';
        final isDownloaded = _downloadedTrackKeys.contains(dlKey);

        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: colorWhite,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: colorGold.withOpacity(0.35)),
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: colorBeige,
                  shape: BoxShape.circle,
                  border: Border.all(color: colorGold),
                ),
                child: Text(
                  '$surahNum',
                  style: const TextStyle(fontWeight: FontWeight.bold, color: colorBrownText),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'سورة $surahName',
                  style: const TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: colorBrownText,
                  ),
                ),
              ),
              IconButton(
                icon: Icon(
                  isDownloaded ? Icons.check_circle_rounded : Icons.download_rounded,
                  color: isDownloaded ? colorGreen : colorGold,
                ),
                onPressed: () {
                  setState(() => _downloadedTrackKeys.add(dlKey));
                },
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: colorGold,
                  foregroundColor: colorWhite,
                  elevation: 0,
                ),
                onPressed: () => _startPlayback(reciter, surahNum),
                child: const Text('استمع'),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildFavoritesList() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorGold.withOpacity(0.4)),
      ),
      child: Text(
        _favReciterIds.isEmpty
            ? 'اختر شيوخك أو سورك المفضلة للوصول السريع إليها.'
            : 'القراء المفضلون (${_favReciterIds.length})',
        style: const TextStyle(color: colorBrownText, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildDownloadsList() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorGold.withOpacity(0.4)),
      ),
      child: Text(
        'التلاوات المحملة للاستماع بدون إنترنت (${_downloadedTrackKeys.length})',
        style: const TextStyle(color: colorBrownText, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildRecentList() {
    return Column(
      children: _recentPlays.map((item) {
        final ReciterModel r = item['reciter'];
        final int sNum = item['surahNumber'];
        return ListTile(
          tileColor: colorWhite,
          title: Text('سورة ${item['surahName']}', style: const TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
          subtitle: Text(r.name),
          trailing: IconButton(
            icon: const Icon(Icons.play_circle_fill_rounded, color: colorGold, size: 32),
            onPressed: () => _startPlayback(r, sNum),
          ),
        );
      }).toList(),
    );
  }

  /// مشغل الصوت السفلي المزود بشريط التقدم وأزرار مؤقت النوم المباشرة (15، 30، 60 دقيقة)
  Widget _buildAudioPlayerWithSleepTimer() {
    final surahName = kSurahNames[_currentSurahNumber - 1];
    final maxSeconds = _totalDuration.inSeconds > 0 ? _totalDuration.inSeconds.toDouble() : 1.0;
    final currentSeconds = _currentPosition.inSeconds.clamp(0, _totalDuration.inSeconds > 0 ? _totalDuration.inSeconds : 1).toDouble();

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: const BoxDecoration(
        color: colorWhite,
        border: Border(top: BorderSide(color: colorGold, width: 1.5)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Icon(Icons.headphones_rounded, color: colorGold, size: 28),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Text(
                          'سورة $surahName',
                          style: const TextStyle(
                            fontFamily: 'Amiri',
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                            color: colorBrownText,
                          ),
                        ),
                        if (_isBuffering) ...[
                          const SizedBox(width: 8),
                          const Text(
                            'جاري التحميل...',
                            style: TextStyle(fontSize: 11, color: colorGold, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ],
                    ),
                    Text(
                      '${_currentReciter.name} • ${_formatDuration(_currentPosition)} / ${_formatDuration(_totalDuration)}',
                      style: const TextStyle(fontSize: 11.5, color: colorGrayText),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'السورة السابقة',
                icon: const Icon(Icons.skip_next_rounded, color: colorGold),
                onPressed: () {
                  final prev = _currentSurahNumber > 1 ? _currentSurahNumber - 1 : 114;
                  _startPlayback(_currentReciter, prev);
                },
              ),
              IconButton(
                icon: Icon(
                  _isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                  color: colorGold,
                  size: 40,
                ),
                onPressed: _togglePlayPause,
              ),
              IconButton(
                tooltip: 'السورة التالية',
                icon: const Icon(Icons.skip_previous_rounded, color: colorGold),
                onPressed: () {
                  final next = _currentSurahNumber < 114 ? _currentSurahNumber + 1 : 1;
                  _startPlayback(_currentReciter, next);
                },
              ),
              // أيقونة الساعة في شريط التحكم لفتح واجهة مؤقت النوم (15، 30، 60 دقيقة)
              IconButton(
                tooltip: 'مؤقت النوم (Sleep Timer)',
                icon: Icon(
                  Icons.access_time_filled_rounded,
                  color: _remainingSleepSeconds != null ? colorGreen : colorGold,
                  size: 24,
                ),
                onPressed: _showSleepTimerSheet,
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: colorGold,
              inactiveTrackColor: colorBeige,
              thumbColor: colorGold,
              trackHeight: 3,
            ),
            child: Slider(
              min: 0,
              max: maxSeconds,
              value: currentSeconds,
              onChanged: (val) {
                _audioPlayer.seek(Duration(seconds: val.toInt()));
              },
            ),
          ),
          // شريط مؤقت النوم المدمج داخل مشغل الصوت (15، 30، 60 دقيقة)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: colorBeige,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: colorGold.withOpacity(0.45)),
            ),
            child: Row(
              children: [
                const Icon(Icons.access_time_filled_rounded, color: colorGold, size: 18),
                const SizedBox(width: 6),
                Text(
                  _remainingSleepSeconds != null
                      ? 'مؤقت النوم (${_formatSecondsMMSS(_remainingSleepSeconds!)})'
                      : 'مؤقت النوم:',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: colorBrownText,
                  ),
                ),
                const Spacer(),
                ...[15, 30, 60].map((mins) {
                  final active = _selectedSleepMinutes == mins;
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => _setSleepTimer(active ? null : mins),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: active ? colorGold : colorWhite,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: colorGold),
                        ),
                        child: Text(
                          '$mins د',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 11.5,
                            fontWeight: FontWeight.bold,
                            color: active ? colorWhite : colorBrownText,
                          ),
                        ),
                      ),
                    ),
                  );
                }),
                if (_selectedSleepMinutes != null)
                  Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: InkWell(
                      onTap: () => _setSleepTimer(null),
                      child: const Icon(Icons.close_rounded, size: 18, color: colorGrayText),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
