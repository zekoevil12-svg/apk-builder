import 'package:flutter/material.dart';

/// خريطة مسارات أيقونات الأقسام في تطبيق «رِفْق | RIFQ»
class RifqIconAssets {
  static const String misbaha = 'assets/icons/menu/ic_misbaha.png';
  static const String mosque = 'assets/icons/menu/ic_mosque.png';
  static const String quran = 'assets/icons/menu/ic_quran.png';
  static const String wird = 'assets/icons/menu/ic_wird.png';
  static const String gharib = 'assets/icons/menu/ic_gharib.png';
  static const String tajweed = 'assets/icons/menu/ic_tajweed.png';
  static const String tadabbur = 'assets/icons/menu/ic_tadabbur.png';
  static const String hadith = 'assets/icons/menu/ic_hadith.png';
  static const String zakat = 'assets/icons/menu/ic_zakat.png';
  static const String hijri = 'assets/icons/menu/ic_hijri.png';
  static const String hajj = 'assets/icons/menu/ic_hajj.png';
  static const String ruqyah = 'assets/icons/menu/ic_ruqyah.png';
  static const String azkar = 'assets/icons/menu/ic_azkar.png';
  static const String graduation = 'assets/icons/menu/ic_graduation.png';
  static const String wudu = 'assets/icons/menu/ic_wudu.png';
  static const String trophy = 'assets/icons/menu/ic_trophy.png';
  static const String palmTree = 'assets/icons/menu/ic_palm_tree.png';
  static const String dailyReminders = 'assets/icons/menu/ic_morning.png';
  static const String womanFlower = 'assets/icons/menu/ic_woman_flower.png';
  static const String statistics = 'assets/icons/menu/ic_statistics.png';
  static const String user = 'assets/icons/menu/ic_user.png';
  static const String allahNames = 'assets/icons/menu/ic_allah_names.png';
  static const String settings = 'assets/icons/menu/ic_settings.png';
  static const String contact = 'assets/icons/menu/ic_contact.png';
  static const String home = 'assets/icons/menu/ic_home.png';
  static const String companions = 'assets/icons/menu/ic_companions.png';
  static const String wasaya = 'assets/icons/menu/ic_wasaya.png';
  static const String kidsStories = 'assets/icons/menu/ic_kids_stories.png';
  static const String fiqhMuyassar = 'assets/icons/menu/ic_fiqh_muyassar.png';
  static const String arbainNawawiya = 'assets/icons/menu/ic_arbain_nawawiya.png';
  static const String quranAudio = 'assets/icons/menu/ic_quran_audio.png';

  static String resolveBySectionName(String sectionName) {
    if (sectionName.contains('المسبحة')) return misbaha;
    if (sectionName.contains('الأربعون') || sectionName.contains('النووية')) return arbainNawawiya;
    if (sectionName.contains('وصايا')) return wasaya;
    if (sectionName.contains('الأطفال') || sectionName.contains('قصص الأطفال')) return kidsStories;
    if (sectionName.contains('الفقه الميسر') || sectionName.contains('الفقه')) return fiqhMuyassar;
    if (sectionName.contains('الصحابة')) return companions;
    if (sectionName.contains('المواقيت') || sectionName.contains('الصلاة')) return mosque;
    if (sectionName.contains('غريب القرآن')) return gharib;
    if (sectionName.contains('استماع')) return quranAudio;
    if (sectionName.contains('القرآن')) return quran;
    if (sectionName.contains('وِرد') || sectionName.contains('WIRD') || sectionName.contains('الورد')) return wird;
    if (sectionName.contains('التجويد')) return tajweed;
    if (sectionName.contains('آية وفائدة') || sectionName.contains('تدبر')) return tadabbur;
    if (sectionName.contains('الأحاديث')) return hadith;
    if (sectionName.contains('الزكاة') || sectionName.contains('المواريث')) return zakat;
    if (sectionName.contains('التقويم') || sectionName.contains('الصيام')) return hijri;
    if (sectionName.contains('الحج') || sectionName.contains('العمرة') || sectionName.contains('المطوّف')) return hajj;
    if (sectionName.contains('الرقية') || sectionName.contains('الطب النبوي')) return ruqyah;
    if (sectionName.contains('الأذكار') || sectionName.contains('حصن') || sectionName.contains('دعاء')) return azkar;
    if (sectionName.contains('التحفيظ')) return graduation;
    if (sectionName.contains('الوضوء')) return wudu;
    if (sectionName.contains('حصاد')) return trophy;
    if (sectionName.contains('غراس') || sectionName.contains('غرائب')) return palmTree;
    if (sectionName.contains('التذكيرات')) return dailyReminders;
    if (sectionName.contains('للمرأة')) return womanFlower;
    if (sectionName.contains('الإحصائيات')) return statistics;
    if (sectionName.contains('الملف الشخصي') || sectionName.contains('حسابي')) return user;
    if (sectionName.contains('أسماء الله')) return allahNames;
    if (sectionName.contains('الإعدادات')) return settings;
    if (sectionName.contains('تواصل') || sectionName.contains('المطور')) return contact;
    if (sectionName.contains('الرئيسية')) return home;
    return misbaha;
  }

  static IconData resolveVectorIcon(String sectionName) {
    if (sectionName.contains('المسبحة')) return Icons.grain_rounded;
    if (sectionName.contains('الأربعون') || sectionName.contains('النووية')) return Icons.menu_book_rounded;
    if (sectionName.contains('الأطفال')) return Icons.child_care_rounded;
    if (sectionName.contains('وصايا')) return Icons.auto_stories_rounded;
    if (sectionName.contains('الفقه')) return Icons.balance_rounded;
    if (sectionName.contains('الصحابة')) return Icons.groups_rounded;
    if (sectionName.contains('المواقيت') || sectionName.contains('الصلاة')) return Icons.mosque_rounded;
    if (sectionName.contains('غريب القرآن')) return Icons.manage_search_rounded;
    if (sectionName.contains('استماع')) return Icons.headphones_rounded;
    if (sectionName.contains('القرآن')) return Icons.import_contacts_rounded;
    if (sectionName.contains('وِرد') || sectionName.contains('WIRD') || sectionName.contains('الورد')) return Icons.bookmark_added_rounded;
    if (sectionName.contains('التجويد') || sectionName.contains('تدبر')) return Icons.graphic_eq_rounded;
    if (sectionName.contains('الأحاديث')) return Icons.library_books_rounded;
    if (sectionName.contains('الزكاة') || sectionName.contains('المواريث')) return Icons.calculate_rounded;
    if (sectionName.contains('التقويم') || sectionName.contains('الصيام')) return Icons.calendar_month_rounded;
    if (sectionName.contains('الحج') || sectionName.contains('العمرة')) return Icons.flight_takeoff_rounded;
    if (sectionName.contains('الرقية') || sectionName.contains('الطب')) return Icons.spa_rounded;
    if (sectionName.contains('الأذكار') || sectionName.contains('حصن') || sectionName.contains('دعاء')) return Icons.volunteer_activism_rounded;
    if (sectionName.contains('التحفيظ')) return Icons.school_rounded;
    if (sectionName.contains('الوضوء')) return Icons.water_drop_rounded;
    if (sectionName.contains('حصاد')) return Icons.trending_up_rounded;
    if (sectionName.contains('غراس') || sectionName.contains('غرائب')) return Icons.park_rounded;
    if (sectionName.contains('التذكيرات')) return Icons.lightbulb_rounded;
    if (sectionName.contains('للمرأة')) return Icons.favorite_rounded;
    if (sectionName.contains('الإحصائيات')) return Icons.pie_chart_rounded;
    if (sectionName.contains('الملف الشخصي') || sectionName.contains('حسابي')) return Icons.manage_accounts_rounded;
    if (sectionName.contains('أسماء الله')) return Icons.stars_rounded;
    if (sectionName.contains('الإعدادات')) return Icons.settings_rounded;
    if (sectionName.contains('تواصل') || sectionName.contains('المطور')) return Icons.code_rounded;
    if (sectionName.contains('الرئيسية')) return Icons.home_rounded;
    return Icons.auto_awesome_rounded;
  }

  static Color resolveAccentColor(String sectionName) {
    if (sectionName.contains('المسبحة') || sectionName.contains('للمرأة')) {
      return const Color(0xFFE99AC7);
    }
    if (sectionName.contains('الأذكار') ||
        sectionName.contains('حصن') ||
        sectionName.contains('دعاء') ||
        sectionName.contains('وِرد') ||
        sectionName.contains('الورد') ||
        sectionName.contains('المواقيت') ||
        sectionName.contains('الصلاة') ||
        sectionName.contains('التذكيرات') ||
        sectionName.contains('الوضوء') ||
        sectionName.contains('الإحصائيات')) {
      return const Color(0xFF72B7E8);
    }
    return const Color(0xFFE8B84A);
  }
}

/// ويدجت موحّد يعرض أيقونة القسم داخل ميدالية دائرية فاتحة جداً بإطار ذهبي هادئ
/// وألوان رِفْق البنفسجية/الزرقاء (#5B5FEF / #4145C7) مع لمسات ذهبية (#F4C047)
class RifqSectionIconWidget extends StatelessWidget {
  final String sectionName;
  final String? assetPath;
  final double size;

  const RifqSectionIconWidget({
    Key? key,
    required this.sectionName,
    this.assetPath,
    this.size = 54,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final resolvedAsset = assetPath ?? RifqIconAssets.resolveBySectionName(sectionName);
    final iconData = RifqIconAssets.resolveVectorIcon(sectionName);

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          center: Alignment(-0.3, -0.35),
          radius: 0.85,
          colors: [
            Color(0xFFFFFEFA),
            Color(0xFFF7F6FD),
            Color(0xFFEFEFF9),
          ],
        ),
        border: Border.all(
          color: const Color(0xFFDEB253),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF5B5FEF).withOpacity(0.06),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: EdgeInsets.all(size * 0.08),
      child: ClipOval(
        child: Image.asset(
          resolvedAsset,
          width: size * 0.82,
          height: size * 0.82,
          fit: BoxFit.contain,
          filterQuality: FilterQuality.high,
          errorBuilder: (context, error, stackTrace) {
            return Stack(
              alignment: Alignment.center,
              children: [
                Icon(
                  iconData,
                  size: size * 0.52,
                  color: const Color(0xFF5B5FEF),
                ),
                Positioned(
                  top: size * 0.12,
                  right: size * 0.14,
                  child: Container(
                    width: size * 0.14,
                    height: size * 0.14,
                    decoration: const BoxDecoration(
                      color: Color(0xFFF4C047),
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
