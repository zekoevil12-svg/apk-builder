export interface CapacitorConfig {
  appId: string;
  appName: string;
  webDir: string;
  server?: {
    androidScheme?: string;
    hostname?: string;
    allowNavigation?: string[];
  };
  plugins?: Record<string, Record<string, unknown>>;
}

const config: CapacitorConfig = {
  appId: 'com.rifq.app',
  appName: 'رِفْق | RIFQ',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    hostname: 'localhost',
  },
  plugins: {
    PrayerFocus: {
      enabledByDefault: false,
    },
  },
};

export default config;
