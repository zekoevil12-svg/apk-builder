import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import { initThemeOnBoot } from './context/ThemeContext.tsx';
import App from './App.tsx';
import './index.css';

// Apply saved theme tokens synchronously before mounting React to avoid FOUC
initThemeOnBoot();
if (typeof document !== 'undefined') {
  document.documentElement.setAttribute('lang', 'ar');
  document.documentElement.setAttribute('dir', 'rtl');
  document.documentElement.removeAttribute('data-rifq-lang');
  document.documentElement.removeAttribute('data-rifq-dir');
  try {
    localStorage.removeItem('rifq_app_language_v1');
    localStorage.removeItem('rifq_app_language_updated_at_v1');
  } catch {
    // ignore
  }
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);


