import {
  INITIAL_ARBAIN_HADITHS,
  ARBAIN_NAWAWIYA_SQLITE_DDL_SCHEMA,
  ArbainHadithItem,
  ArbainHadithSqliteRow,
  ArbainThemeCategory,
} from '../data/arbainNawawiyaData';

const ARBAIN_HADITHS_TABLE_KEY = 'rifq_sqlite_arbain_hadiths_v1';
const ARBAIN_FAVORITES_TABLE_KEY = 'rifq_sqlite_arbain_favorites_v1';
const ARBAIN_MEMORIZED_TABLE_KEY = 'rifq_sqlite_arbain_memorized_v1';
const ARBAIN_READ_COUNTS_KEY = 'rifq_sqlite_arbain_read_counts_v1';
const ARBAIN_SCHEMA_META_KEY = 'rifq_sqlite_arbain_schema_v1';

export function initArbainNawawiyaSqliteTables(): void {
  try {
    if (!localStorage.getItem(ARBAIN_SCHEMA_META_KEY)) {
      localStorage.setItem(ARBAIN_SCHEMA_META_KEY, ARBAIN_NAWAWIYA_SQLITE_DDL_SCHEMA.trim());
    }

    const existingRaw = localStorage.getItem(ARBAIN_HADITHS_TABLE_KEY);
    let shouldSeed = !existingRaw;
    if (existingRaw) {
      try {
        const parsed = JSON.parse(existingRaw);
        if (!Array.isArray(parsed) || parsed.length < INITIAL_ARBAIN_HADITHS.length) {
          shouldSeed = true;
        }
      } catch {
        shouldSeed = true;
      }
    }

    if (shouldSeed) {
      const rows: ArbainHadithSqliteRow[] = INITIAL_ARBAIN_HADITHS.map((item) => ({
        id: item.id,
        hadith_number: item.number,
        arabic_order_label: item.arabicOrderLabel,
        title: item.title,
        short_source: item.shortSource,
        full_takhrij: item.fullTakhrij,
        narrator: item.narrator,
        narrator_bio: item.narratorBio,
        hadith_text: item.hadithText,
        vocabulary_json: JSON.stringify(item.vocabulary),
        explanation: item.explanation,
        benefits_json: JSON.stringify(item.benefits),
        reference: item.reference,
        theme: item.theme,
      }));
      localStorage.setItem(ARBAIN_HADITHS_TABLE_KEY, JSON.stringify(rows));
    }

    if (!localStorage.getItem(ARBAIN_FAVORITES_TABLE_KEY)) {
      localStorage.setItem(ARBAIN_FAVORITES_TABLE_KEY, JSON.stringify([]));
    }

    if (!localStorage.getItem(ARBAIN_MEMORIZED_TABLE_KEY)) {
      localStorage.setItem(ARBAIN_MEMORIZED_TABLE_KEY, JSON.stringify([]));
    }
  } catch {
    // Fallback gracefully if storage quota is restricted
  }
}

export function loadArbainHadithsFromStorage(): ArbainHadithItem[] {
  try {
    initArbainNawawiyaSqliteTables();
    const raw = localStorage.getItem(ARBAIN_HADITHS_TABLE_KEY);
    if (!raw) return INITIAL_ARBAIN_HADITHS;
    const rows: ArbainHadithSqliteRow[] = JSON.parse(raw);
    if (!Array.isArray(rows) || rows.length < INITIAL_ARBAIN_HADITHS.length) {
      return INITIAL_ARBAIN_HADITHS;
    }
    return rows
      .map((row) => ({
        id: row.id,
        number: row.hadith_number,
        arabicOrderLabel: row.arabic_order_label,
        title: row.title,
        shortSource: row.short_source,
        fullTakhrij: row.full_takhrij,
        narrator: row.narrator,
        narratorBio: row.narrator_bio,
        hadithText: row.hadith_text,
        vocabulary: JSON.parse(row.vocabulary_json || '[]'),
        explanation: row.explanation,
        benefits: JSON.parse(row.benefits_json || '[]'),
        reference: row.reference,
        theme: row.theme,
      }))
      .sort((a, b) => a.number - b.number);
  } catch {
    return INITIAL_ARBAIN_HADITHS;
  }
}

export function loadArbainFavorites(): string[] {
  try {
    const raw = localStorage.getItem(ARBAIN_FAVORITES_TABLE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function toggleArbainFavoriteInStorage(hadithId: string): string[] {
  try {
    const current = loadArbainFavorites();
    const next = current.includes(hadithId)
      ? current.filter((id) => id !== hadithId)
      : [...current, hadithId];
    localStorage.setItem(ARBAIN_FAVORITES_TABLE_KEY, JSON.stringify(next));
    return next;
  } catch {
    return [];
  }
}

export function loadArbainMemorized(): string[] {
  try {
    const raw = localStorage.getItem(ARBAIN_MEMORIZED_TABLE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function toggleArbainMemorizedInStorage(hadithId: string): string[] {
  try {
    const current = loadArbainMemorized();
    const next = current.includes(hadithId)
      ? current.filter((id) => id !== hadithId)
      : [...current, hadithId];
    localStorage.setItem(ARBAIN_MEMORIZED_TABLE_KEY, JSON.stringify(next));
    return next;
  } catch {
    return [];
  }
}

export function loadArbainReadCounts(): Record<string, number> {
  try {
    const raw = localStorage.getItem(ARBAIN_READ_COUNTS_KEY);
    if (!raw) return {};
    return JSON.parse(raw) || {};
  } catch {
    return {};
  }
}

export function incrementArbainReadCount(hadithId: string): Record<string, number> {
  try {
    const counts = loadArbainReadCounts();
    counts[hadithId] = (counts[hadithId] || 0) + 1;
    localStorage.setItem(ARBAIN_READ_COUNTS_KEY, JSON.stringify(counts));
    return { ...counts };
  } catch {
    return {};
  }
}

export function resetArbainReadCount(hadithId: string): Record<string, number> {
  try {
    const counts = loadArbainReadCounts();
    counts[hadithId] = 0;
    localStorage.setItem(ARBAIN_READ_COUNTS_KEY, JSON.stringify(counts));
    return { ...counts };
  } catch {
    return {};
  }
}

/**
 * إزالة التشكيل لتسهيل البحث الفوري الذكي في متن الحديث والشرح
 */
export function normalizeArabicSearchText(input: string): string {
  return input
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
    .toLowerCase();
}

export function searchArbainHadithsInStorage(
  hadiths: ArbainHadithItem[],
  query: string,
  themeFilter: ArbainThemeCategory | 'all' = 'all',
  sourceFilter: string = 'all'
): ArbainHadithItem[] {
  const normQuery = normalizeArabicSearchText(query);

  return hadiths.filter((item) => {
    if (themeFilter !== 'all' && item.theme !== themeFilter) {
      return false;
    }

    if (sourceFilter !== 'all') {
      const combinedSource = `${item.shortSource} ${item.fullTakhrij}`;
      if (!combinedSource.includes(sourceFilter)) {
        return false;
      }
    }

    if (!normQuery) return true;

    // Check by hadith number if query is numeric
    if (String(item.number) === normQuery) return true;

    const searchableFields = [
      item.title,
      item.arabicOrderLabel,
      item.narrator,
      item.hadithText,
      item.explanation,
      item.shortSource,
      item.fullTakhrij,
      item.reference,
      ...item.benefits,
      ...item.vocabulary.map((v) => `${v.word} ${v.meaning}`),
    ].join(' ');

    return normalizeArabicSearchText(searchableFields).includes(normQuery);
  });
}
