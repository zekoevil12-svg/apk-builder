/**
 * خدمة التنبيهات المنبثقة اليومية للآيات القرآنية والأحاديث النبوية الشريفة
 * Daily Quranic Ayah & Prophetic Hadith Toast Notification Service
 */

export interface DailyToastItem {
  id: string;
  type: 'ayah' | 'hadith';
  text: string;
  source: string;
  surahOrBook: string;
  numberOrRef?: string | number;
  shownAt: string;
  benefit?: string;
}

export interface DailyAyahHadithToastConfig {
  enabled: boolean;
  contentType: 'both' | 'ayah_only' | 'hadith_only';
  triggerOnAppOpen: boolean;
  soundEnabled: boolean;
  autoDismissSeconds: number; // e.g. 10
  lastShownDate: string; // YYYY-MM-DD
  lastShownItem?: DailyToastItem;
  history: DailyToastItem[];
}

const STORAGE_KEY = 'rifq_daily_toast_ayah_hadith_v1';

export const AUTHENTIC_QURAN_VERSES: Omit<DailyToastItem, 'id' | 'shownAt'>[] = [
  {
    type: 'ayah',
    text: '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾',
    source: 'القرآن الكريم — سورة الرعد',
    surahOrBook: 'سورة الرعد',
    numberOrRef: 28,
    benefit: 'طريق طمأنينة القلب وسكينته بدوام ذكر الله ومراقبته في كل حين.',
  },
  {
    type: 'ayah',
    text: '﴿ وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا * وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ ﴾',
    source: 'القرآن الكريم — سورة الطلاق',
    surahOrBook: 'سورة الطلاق',
    numberOrRef: '2-3',
    benefit: 'تقوى الله مفتاح كل فرج وباب كل رزق حلال مبارك.',
  },
  {
    type: 'ayah',
    text: '﴿ وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ ﴾',
    source: 'القرآن الكريم — سورة البقرة',
    surahOrBook: 'سورة البقرة',
    numberOrRef: 186,
    benefit: 'بشارة عظيمة بقرب الله تعالى من عباده وإجابته لدعائهم بلا واسطة.',
  },
  {
    type: 'ayah',
    text: '﴿ فَإِنَّ مَعَ الْعُسْرِ يُسْرًا * إِنَّ مَعَ الْعُسْرِ يُسْرًا ﴾',
    source: 'القرآن الكريم — سورة الشرح',
    surahOrBook: 'سورة الشرح',
    numberOrRef: '5-6',
    benefit: 'وعد إلهي محكم بأن بعد كل ضيق فرجاً، ولن يغلب عسر يسرين.',
  },
  {
    type: 'ayah',
    text: '﴿ وَتَوَكَّلْ عَلَى الْحَيِّ الَّذِي لَا يَمُوتُ وَسَبِّحْ بِحَمْدِهِ ﴾',
    source: 'القرآن الكريم — سورة الفرقان',
    surahOrBook: 'سورة الفرقان',
    numberOrRef: 58,
    benefit: 'الاعتماد الكلي وتفويض الأمر لمن بيده مقاليد السماوات والأرض.',
  },
  {
    type: 'ayah',
    text: '﴿ فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ ﴾',
    source: 'القرآن الكريم — سورة البقرة',
    surahOrBook: 'سورة البقرة',
    numberOrRef: 152,
    benefit: 'أعظم شرف للعبد أن يذكره خالقه ومولاه في الملأ الأعلى.',
  },
  {
    type: 'ayah',
    text: '﴿ وَقُل رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا ﴾',
    source: 'القرآن الكريم — سورة الإسراء',
    surahOrBook: 'سورة الإسراء',
    numberOrRef: 24,
    benefit: 'بر الوالدين بالدعاء لهما بالرحمة والمغفرة في كل وقت وحين.',
  },
  {
    type: 'ayah',
    text: '﴿ رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ﴾',
    source: 'القرآن الكريم — سورة آل عمران',
    surahOrBook: 'سورة آل عمران',
    numberOrRef: 8,
    benefit: 'دعاء الراسخين في العلم لطلب الثبات على الهداية والرحمة.',
  },
  {
    type: 'ayah',
    text: '﴿ وَاصْبِرْ لِحُكْمِ رَبِّكَ فَإِنَّكَ بِأَعْيُنِنَا وَسَبِّحْ بِحَمْدِ رَبِّكَ حِينَ تَقُومُ ﴾',
    source: 'القرآن الكريم — سورة الطور',
    surahOrBook: 'سورة الطور',
    numberOrRef: 48,
    benefit: 'تسلية لكل مؤمن صابر، بأن عين الله ترعاه وتحوطه بعنايته.',
  },
  {
    type: 'ayah',
    text: '﴿ إِنَّ اللَّهَ مَعَ الَّذِينَ اتَّقَوا وَّالَّذِينَ هُم مُّحْسِنُونَ ﴾',
    source: 'القرآن الكريم — سورة النحل',
    surahOrBook: 'سورة النحل',
    numberOrRef: 128,
    benefit: 'المعية الإلهية الخاصة بالنصر والتأييد لأهل التقوى والإحسان.',
  },
  {
    type: 'ayah',
    text: '﴿ قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَى أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ ﴾',
    source: 'القرآن الكريم — سورة الزمر',
    surahOrBook: 'سورة الزمر',
    numberOrRef: 53,
    benefit: 'أرجى آية في كتاب الله تفتح أبواب التوبة والرجاء لكل مذنب.',
  },
  {
    type: 'ayah',
    text: '﴿ وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ وَإِنَّهَا لَكَبِيرَةٌ إِلَّا عَلَى الْخَاشِعِينَ ﴾',
    source: 'القرآن الكريم — سورة البقرة',
    surahOrBook: 'سورة البقرة',
    numberOrRef: 45,
    benefit: 'الصلاة والصبر هما حبل النجاة ومصدر القوة عند اشتداد الخطوب.',
  },
];

export const AUTHENTIC_PROPHETIC_HADITHS: Omit<DailyToastItem, 'id' | 'shownAt'>[] = [
  {
    type: 'hadith',
    text: '«عَجَبًا لِأَمْرِ الْمُؤْمِنِ، إِنَّ أَمْرَهُ كُلَّهُ خَيْرٌ، وَلَيْسَ ذَاكَ لِأَحَدٍ إِلَّا لِلْمُؤْمِنِ؛ إِنْ أَصَابَتْهُ سَرَّاءُ شَكَرَ فَكَانَ خَيْرًا لَهُ، وَإِنْ أَصَابَتْهُ ضَرَّاءُ صَبَرَ فَكَانَ خَيْرًا لَهُ»',
    source: 'صحيح مسلم (2999)',
    surahOrBook: 'صحيح مسلم',
    numberOrRef: 'رقم 2999',
    benefit: 'حياة المؤمن كلها ربح في الرخاء والشكر وفي الشدة والصبر.',
  },
  {
    type: 'hadith',
    text: '«مَنْ لَزِمَ الِاسْتِغْفَارَ جَعَلَ اللَّهُ لَهُ مِنْ كُلِّ ضِيقٍ مَخْرَجًا، وَمِنْ كُلِّ هَمٍّ فَرَجًا، وَرَزَقَهُ مِنْ حَيْثُ لَا يَحْتَسِبُ»',
    source: 'سنن أبي داود (1518) والمسند',
    surahOrBook: 'سنن أبي داود',
    numberOrRef: 'رقم 1518',
    benefit: 'كثرة الاستغفار تفتح المغاليق وتذهب الهموم وتجلب الأرزاق.',
  },
  {
    type: 'hadith',
    text: '«كَلِمَتَانِ خَفِيفَتَانِ عَلَى اللِّسَانِ، ثَقِيلَتَانِ فِي الْمِيزَانِ، حَبِيبَتَانِ إِلَى الرَّحْمَنِ: سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ»',
    source: 'صحيح البخاري (6406) ومسلم (2694)',
    surahOrBook: 'متفق عليه',
    numberOrRef: 'البخاري 6406',
    benefit: 'فضل عظيم وأجر جليل في كلمات يسيرة لا تأخذ ثوانٍ من يومك.',
  },
  {
    type: 'hadith',
    text: '«مَنْ صَلَّى عَلَيَّ صَلَاةً صَلَّى اللَّهُ عَلَيْهِ بِهَا عَشْرًا»',
    source: 'صحيح مسلم (384)',
    surahOrBook: 'صحيح مسلم',
    numberOrRef: 'رقم 384',
    benefit: 'بركة الصلاة على النبي ﷺ ينال بها العبد صلاة الله ومغفرته ورفع درجاته.',
  },
  {
    type: 'hadith',
    text: '«احْفَظِ اللَّهَ يَحْفَظْكَ، احْفَظِ اللَّهَ تَجِدْهُ تُجَاهَكَ، إِذَا سَأَلْتَ فَاسْأَلِ اللَّهَ، وَإِذَا اسْتَعَنْتَ فَاسْتَعِنْ بِاللَّهِ»',
    source: 'سنن الترمذي (2516) وصححه',
    surahOrBook: 'سنن الترمذي',
    numberOrRef: 'رقم 2516',
    benefit: 'وصية نبوية جامعة ترسم منهج العزة والتوحيد الخالص.',
  },
  {
    type: 'hadith',
    text: '«لَا يَقْعُدُ قَوْمٌ يَذْكُرُونَ اللَّهَ عَزَّ وَجَلَّ إِلَّا حَفَّتْهُمُ الْمَلَائِكَةُ، وَغَشِيَتْهُمُ الرَّحْمَةُ، وَنَزَلَتْ عَلَيْهِمِ السَّكِينَةُ، وَذَكَرَهُمُ اللَّهُ فِيمَنْ عِنْدَهُ»',
    source: 'صحيح مسلم (2700)',
    surahOrBook: 'صحيح مسلم',
    numberOrRef: 'رقم 2700',
    benefit: 'مجالس الذكر هي رياض الجنة في الأرض ومحط تنزل السكينة والرحمة.',
  },
  {
    type: 'hadith',
    text: '«خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ»',
    source: 'صحيح البخاري (5027)',
    surahOrBook: 'صحيح البخاري',
    numberOrRef: 'رقم 5027',
    benefit: 'أعلى مراتب الخيرية والشرف تكون بصحبة كتاب الله تعلماً وتعليماً.',
  },
  {
    type: 'hadith',
    text: '«تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ»',
    source: 'سنن الترمذي (1956) وصححه الألباني',
    surahOrBook: 'سنن الترمذي',
    numberOrRef: 'رقم 1956',
    benefit: 'ديننا الحنيف يجعل من حسن الخلق ولطافة اللقاء صدقة وأجراً.',
  },
  {
    type: 'hadith',
    text: '«الدُّعَاءُ هُوَ الْعِبَادَةُ»',
    source: 'سنن الترمذي (2969) وأبو داود',
    surahOrBook: 'سنن الترمذي',
    numberOrRef: 'رقم 2969',
    benefit: 'الدعاء يظهر كمال الافتقار إلى الله وحقيقة العبودية له سبحانه.',
  },
  {
    type: 'hadith',
    text: '«مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ»',
    source: 'صحيح مسلم (2699)',
    surahOrBook: 'صحيح مسلم',
    numberOrRef: 'رقم 2699',
    benefit: 'فضل طلب العلم الشرعي والنافع وأنه أيسر الطرق الموصلة للجنة.',
  },
];

const DEFAULT_CONFIG: DailyAyahHadithToastConfig = {
  enabled: true,
  contentType: 'both',
  triggerOnAppOpen: true,
  soundEnabled: true,
  autoDismissSeconds: 9,
  lastShownDate: '',
  history: [],
};

export function loadDailyAyahHadithToastConfig(): DailyAyahHadithToastConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_CONFIG };
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_CONFIG,
      ...parsed,
    };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}

export function saveDailyAyahHadithToastConfig(cfg: DailyAyahHadithToastConfig): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  } catch {
    // ignore
  }
}

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getRandomAyah(): Omit<DailyToastItem, 'id' | 'shownAt'> {
  const idx = Math.floor(Math.random() * AUTHENTIC_QURAN_VERSES.length);
  return AUTHENTIC_QURAN_VERSES[idx];
}

export function getRandomHadith(): Omit<DailyToastItem, 'id' | 'shownAt'> {
  const idx = Math.floor(Math.random() * AUTHENTIC_PROPHETIC_HADITHS.length);
  return AUTHENTIC_PROPHETIC_HADITHS[idx];
}

/**
 * Returns a chosen item for today based on configuration
 */
export function getDailyItemForToday(forceRandom = false): DailyToastItem {
  const cfg = loadDailyAyahHadithToastConfig();
  const todayStr = getTodayString();

  if (!forceRandom && cfg.lastShownItem && cfg.lastShownDate === todayStr) {
    return cfg.lastShownItem;
  }

  let baseItem: Omit<DailyToastItem, 'id' | 'shownAt'>;

  if (cfg.contentType === 'ayah_only') {
    baseItem = getRandomAyah();
  } else if (cfg.contentType === 'hadith_only') {
    baseItem = getRandomHadith();
  } else {
    // Choose based on day of month or random
    const dayOfMonth = new Date().getDate();
    if (dayOfMonth % 2 === 0) {
      baseItem = getRandomAyah();
    } else {
      baseItem = getRandomHadith();
    }
  }

  const item: DailyToastItem = {
    ...baseItem,
    id: `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    shownAt: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
  };

  return item;
}

/**
 * Dispatches a window-level event to render the Toast notification immediately
 */
export function emitDailyToastEvent(item: DailyToastItem): void {
  if (typeof window === 'undefined') return;
  const evt = new CustomEvent('rifq-daily-toast-show', {
    detail: { item },
  });
  window.dispatchEvent(evt);
}

/**
 * Checks if daily toast should fire today on app open, and triggers it
 */
export function checkAndTriggerDailyToast(): DailyToastItem | null {
  const cfg = loadDailyAyahHadithToastConfig();
  if (!cfg.enabled) return null;

  const todayStr = getTodayString();
  if (cfg.lastShownDate === todayStr) {
    // Already shown today
    return null;
  }

  const item = getDailyItemForToday(false);

  // Update config
  const nextHistory = [item, ...(cfg.history || [])].slice(0, 30);
  const updatedCfg: DailyAyahHadithToastConfig = {
    ...cfg,
    lastShownDate: todayStr,
    lastShownItem: item,
    history: nextHistory,
  };
  saveDailyAyahHadithToastConfig(updatedCfg);

  // Trigger event after a small delay so DOM is fully ready
  setTimeout(() => {
    emitDailyToastEvent(item);
  }, 1200);

  return item;
}

/**
 * Manually trigger a test toast (from Settings page)
 */
export function triggerManualTestToast(customType?: 'ayah' | 'hadith'): DailyToastItem {
  let base: Omit<DailyToastItem, 'id' | 'shownAt'>;
  if (customType === 'ayah') {
    base = getRandomAyah();
  } else if (customType === 'hadith') {
    base = getRandomHadith();
  } else {
    base = Math.random() > 0.5 ? getRandomAyah() : getRandomHadith();
  }

  const item: DailyToastItem = {
    ...base,
    id: `test_toast_${Date.now()}`,
    shownAt: 'الآن',
  };

  emitDailyToastEvent(item);
  return item;
}
