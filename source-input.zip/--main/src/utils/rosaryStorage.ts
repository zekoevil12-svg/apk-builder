// Real persistent LocalStorage management for Interactive 3D Rosary sessions and cycles
// STRICT ZERO-START: No fake users, no fake sessions, no seeded counts.

import { getTodayDateString, loadHistory, saveHistory, getTodayRecord } from './storage';
import { RosaryThemeId } from '../types';

export interface RosarySessionLog {
  id: string;
  dhikrText: string;
  count: number;
  target: number;
  cycles: number;
  timestamp: string; // Formatted date string
  rawDate: string; // ISO string
}

export interface RosaryState {
  currentCount: number;
  target: number;
  selectedDhikr: string;
  totalCycles: number;
  totalSessions: number;
  vibrationEnabled: boolean;
  soundEnabled: boolean;
  soundType: 'wood' | 'water' | 'golden_bell' | 'silent' | 'wooden_bead' | 'crystal_click' | 'soft_chime';
  lastActiveSessionId?: string;
  theme?: RosaryThemeId;
}

const ROSARY_STATE_KEY = 'mushaba_rosary_state_v2';
const ROSARY_HISTORY_KEY = 'mushaba_rosary_history_v2';

export const DEFAULT_DHIKR_LIST: { id: string; text: string; defaultTarget: number; title: string }[] = [
  { id: 'subhanallah', text: 'سُبْحَانَ اللَّهِ', defaultTarget: 33, title: 'التسبيح' },
  { id: 'alhamdulillah', text: 'الْحَمْدُ لِلَّهِ', defaultTarget: 33, title: 'التحميد' },
  { id: 'allahuakbar', text: 'اللَّهُ أَكْبَرُ', defaultTarget: 34, title: 'التكبير' },
  { id: 'lailahaillallah', text: 'لَا إِلَهَ إِلَّا اللَّهُ', defaultTarget: 100, title: 'التهليل' },
  { id: 'istighfar', text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', defaultTarget: 100, title: 'الاستغفار' },
  { id: 'salawat', text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ', defaultTarget: 100, title: 'الصلاة على النبي' },
  { id: 'hawqala', text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', defaultTarget: 100, title: 'الحوقلة' },
  { id: 'subhanallahi_wabihamdihi', text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ الْعَظِيمِ', defaultTarget: 100, title: 'تسبيح وبحمد' },
];

export function getDefaultRosaryState(): RosaryState {
  return {
    currentCount: 0,
    target: 100,
    selectedDhikr: 'سُبْحَانَ اللَّهِ',
    totalCycles: 0,
    totalSessions: 0,
    vibrationEnabled: true,
    soundEnabled: true,
    soundType: 'wooden_bead',
    theme: 'emerald',
  };
}

export function loadRosaryState(): RosaryState {
  try {
    const raw = localStorage.getItem(ROSARY_STATE_KEY);
    if (!raw) return getDefaultRosaryState();
    const parsed = JSON.parse(raw);
    return { ...getDefaultRosaryState(), ...parsed };
  } catch {
    return getDefaultRosaryState();
  }
}

export function saveRosaryState(state: RosaryState): void {
  try {
    localStorage.setItem(ROSARY_STATE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

export function syncRosaryWithUserSettings(settings: {
  rosaryDhikr?: string;
  rosaryTarget?: number;
  rosarySoundEnabled?: boolean;
  rosaryVibrationEnabled?: boolean;
  soundEnabled?: boolean;
  vibrationEnabled?: boolean;
  defaultTarget?: number;
  rosaryTheme?: RosaryThemeId;
}): void {
  try {
    const current = loadRosaryState();
    let updated = false;

    if (settings.rosaryDhikr && settings.rosaryDhikr !== current.selectedDhikr) {
      current.selectedDhikr = settings.rosaryDhikr;
      updated = true;
    }

    const targetVal = settings.rosaryTarget ?? settings.defaultTarget;
    if (targetVal && targetVal !== current.target) {
      current.target = targetVal;
      updated = true;
    }

    const soundVal = settings.rosarySoundEnabled ?? settings.soundEnabled;
    if (soundVal !== undefined && soundVal !== current.soundEnabled) {
      current.soundEnabled = soundVal;
      updated = true;
    }

    const vibVal = settings.rosaryVibrationEnabled ?? settings.vibrationEnabled;
    if (vibVal !== undefined && vibVal !== current.vibrationEnabled) {
      current.vibrationEnabled = vibVal;
      updated = true;
    }

    if (settings.rosaryTheme && settings.rosaryTheme !== current.theme) {
      current.theme = settings.rosaryTheme;
      updated = true;
    }

    if (updated) {
      saveRosaryState(current);
    }
  } catch {
    // ignore
  }
}

export function loadRosaryHistory(): RosarySessionLog[] {
  try {
    const raw = localStorage.getItem(ROSARY_HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveRosaryHistory(history: RosarySessionLog[]): void {
  try {
    localStorage.setItem(ROSARY_HISTORY_KEY, JSON.stringify(history));
  } catch {
    // ignore
  }
}

export function formatArabicDate(date: Date): string {
  try {
    return date.toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return date.toISOString().split('T')[0];
  }
}

/**
 * Record an actual bead increment in both the rosary state and the app's daily record.
 * Handles cycle completions when reaching target.
 */
export function recordRosaryIncrement(increment = 1, syncDirectlyToAppHistory = false): {
  newState: RosaryState;
  completedCycle: boolean;
  historyLog: RosarySessionLog[];
  todayCount: number;
  totalLifetimeCount: number;
} {
  const state = loadRosaryState();
  const nextCount = state.currentCount + increment;
  let completedCycle = false;
  let historyLog = loadRosaryHistory();

  // Load app history to read or update
  const history = loadHistory();
  const todayRecord = getTodayRecord(history);
  const hour = new Date().getHours();

  if (syncDirectlyToAppHistory) {
    todayRecord.totalCount += increment;
    todayRecord.freeCount += increment;
    todayRecord.hourlyCounts[hour] = (todayRecord.hourlyCounts[hour] || 0) + increment;
    todayRecord.dhikrCounts[state.selectedDhikr] = (todayRecord.dhikrCounts[state.selectedDhikr] || 0) + increment;

    // Track session on first count if session was 0
    if (state.totalSessions === 0) {
      state.totalSessions = 1;
      todayRecord.sessionsCount = Math.max(1, todayRecord.sessionsCount);
    }

    history[getTodayDateString()] = todayRecord;
    saveHistory(history);
  }

  // Check if current cycle was completed (target > 0 prevents division or cycle bug on open target)
  if (state.target > 0 && nextCount >= state.target) {
    completedCycle = true;
    state.totalCycles += 1;
    state.currentCount = 0; // reset for the next cycle

    // Log the completed cycle to user's real history
    const newLogItem: RosarySessionLog = {
      id: 'session-' + Date.now(),
      dhikrText: state.selectedDhikr,
      count: state.target,
      target: state.target,
      cycles: 1,
      timestamp: formatArabicDate(new Date()),
      rawDate: new Date().toISOString(),
    };

    historyLog = [newLogItem, ...historyLog.slice(0, 99)];
    saveRosaryHistory(historyLog);
  } else {
    state.currentCount = nextCount;
  }

  saveRosaryState(state);

  const totalLifetimeCount = Object.values(history).reduce((acc, r) => acc + (r.totalCount || 0), 0);

  return {
    newState: state,
    completedCycle,
    historyLog,
    todayCount: todayRecord.totalCount,
    totalLifetimeCount,
  };
}

/**
 * Reset current session count to 0 (upon user confirmation).
 */
export function resetCurrentSessionCount(): RosaryState {
  const state = loadRosaryState();
  state.currentCount = 0;
  saveRosaryState(state);
  return state;
}

/**
 * Clear all rosary data, sessions, and history completely (after explicit user confirmation).
 */
export function clearAllRosaryData(): { state: RosaryState; history: RosarySessionLog[] } {
  const cleanState = getDefaultRosaryState();
  saveRosaryState(cleanState);
  saveRosaryHistory([]);

  // Also clean today's history records
  const history = loadHistory();
  const today = getTodayDateString();
  history[today] = {
    date: today,
    totalCount: 0,
    sessionsCount: 0,
    completedAthkarCount: 0,
    freeCount: 0,
    hourlyCounts: new Array(24).fill(0),
    dhikrCounts: {},
  };
  saveHistory(history);

  return { state: cleanState, history: [] };
}

/**
 * Get real stats calculated directly from user activity.
 */
export function getRealRosaryStats(): {
  todayTasbeeh: number;
  totalCycles: number;
  totalSessions: number;
  totalLifetimeCount: number;
} {
  const state = loadRosaryState();
  const history = loadHistory();
  const today = getTodayDateString();
  const todayRecord = history[today];

  const todayTasbeeh = todayRecord ? todayRecord.totalCount : 0;
  const totalLifetimeCount = Object.values(history).reduce((acc, r) => acc + (r.totalCount || 0), 0);

  return {
    todayTasbeeh,
    totalCycles: state.totalCycles,
    totalSessions: state.totalSessions,
    totalLifetimeCount,
  };
}
