// High quality Web Audio API sound synthesizer for Tasbeeh beads and celebrations

export type MisbahaSoundType = 'wood' | 'water' | 'golden_bell' | 'silent' | 'wooden_bead' | 'crystal_click' | 'soft_chime';
export type MisbahaVibrationLevel = 'light' | 'medium' | 'strong' | 'none';

class SoundManager {
  private ctx: AudioContext | null = null;

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playBeadClick(volume = 0.75, type: MisbahaSoundType = 'wood') {
    if (type === 'silent' || volume <= 0) return;

    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const clampedVol = Math.max(0, Math.min(1, volume));
      const gainNode = this.ctx.createGain();
      gainNode.connect(this.ctx.destination);

      if (type === 'wood' || type === 'wooden_bead') {
        // خشبي (افتراضي): نقرة مسبحة خشبية دافئة وواقعية
        gainNode.gain.setValueAtTime(clampedVol * 0.85, now);
        const osc = this.ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(420, now);
        osc.frequency.exponentialRampToValueAtTime(165, now + 0.045);

        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.055);

        osc.connect(gainNode);
        osc.start(now);
        osc.stop(now + 0.055);
      } else if (type === 'water') {
        // ماء: قطرة ماء ندية نقية
        gainNode.gain.setValueAtTime(0.001, now);
        gainNode.gain.linearRampToValueAtTime(clampedVol * 0.7, now + 0.012);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(340, now);
        osc.frequency.exponentialRampToValueAtTime(760, now + 0.09);

        osc.connect(gainNode);
        osc.start(now);
        osc.stop(now + 0.14);
      } else if (type === 'golden_bell' || type === 'soft_chime') {
        // جرس ذهبي: رنين جرس ذهبي هادئ بترددات توافقية
        const freqs = [880, 1318.5, 1760];
        freqs.forEach((f, idx) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const bellGain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, now);

          const amp = (clampedVol * 0.45) / (idx + 1);
          bellGain.gain.setValueAtTime(amp, now);
          bellGain.gain.exponentialRampToValueAtTime(0.0008, now + 0.22 - idx * 0.04);

          osc.connect(bellGain);
          bellGain.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.23);
        });
      } else {
        // High crisp crystal click
        gainNode.gain.setValueAtTime(clampedVol * 0.8, now);
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, now);
        osc.frequency.exponentialRampToValueAtTime(800, now + 0.03);

        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

        osc.connect(gainNode);
        osc.start(now);
        osc.stop(now + 0.04);
      }
    } catch {
      // Audio playback failsafe
    }
  }

  triggerVibrationByLevel(level: MisbahaVibrationLevel = 'medium') {
    if (level === 'none') return;
    if (level === 'light') {
      this.triggerHaptic(15);
    } else if (level === 'medium') {
      this.triggerHaptic(35);
    } else if (level === 'strong') {
      this.triggerHaptic([55, 30, 65]);
    }
  }

  playCompletionChime(volume = 0.8) {
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Beautiful harmonic chord (F# - A# - C# - F)
      const frequencies = [554.37, 659.25, 830.61, 1108.73];
      frequencies.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0.001, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime((volume * 0.25) / (idx + 1), now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 0.8);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.85);
      });
    } catch {
      // ignore
    }
  }

  triggerHaptic(pattern: number | number[] = 25) {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // ignore
      }
    }
  }

  // Real alarm tone generator with gradual volume ramp up support
  startAlarmTone(gradual = false): () => void {
    try {
      this.initContext();
      if (!this.ctx) return () => {};

      let isRunning = true;
      let intervalId: ReturnType<typeof setInterval> | null = null;
      let currentVol = gradual ? 0.05 : 0.7;

      const playPulse = () => {
        if (!isRunning || !this.ctx) return;
        const now = this.ctx.currentTime;
        const notes = [587.33, 880, 1174.66]; // D5, A5, D6 melodious chime
        notes.forEach((freq, i) => {
          if (!this.ctx) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + i * 0.12);
          gain.gain.setValueAtTime(currentVol * 0.3, now + i * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.35);
          osc.connect(gain);
          gain.connect(this.ctx.destination);
          osc.start(now + i * 0.12);
          osc.stop(now + i * 0.12 + 0.4);
        });

        if (gradual && currentVol < 0.8) {
          currentVol = Math.min(0.8, currentVol + 0.03);
        }
      };

      playPulse();
      intervalId = setInterval(playPulse, 1400);

      return () => {
        isRunning = false;
        if (intervalId) clearInterval(intervalId);
      };
    } catch {
      return () => {};
    }
  }
}

export const soundManager = new SoundManager();
