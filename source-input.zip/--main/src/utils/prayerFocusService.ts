import { registerPlugin, Capacitor } from '@capacitor/core';
import { PrayerKey, DailyPrayerTracker, PrayerTrackingStatus } from '../types';
import { calculateAllPrayerData, formatPrayerTime } from './prayerCalculator';
import { getCurrentCity, getPrayerSettings } from './prayerScheduler';
import {
  triggerPushNotification,
  RIFQ_NOTIFICATION_CHANNELS,
  isNotificationChannelEnabled,
} from './notifications';
import { addNotification } from './storage';

export type FocusPrayerKey = Exclude<PrayerKey, 'sunrise'>;

export type PrayerFocusDuration = 10 | 15 | 20 | 30 | 'until_end_of_prayer' | number;

export interface ProtectedSystemAppItem {
  packageName: string;
  nameAr: string;
  reasonAr: string;
}

/**
 * Automatic Prayer Mode Settings (وضع الصلاة التلقائي):
 * - Zero manual app selection, zero installed-app scanning, zero icon extraction.
 * - Automatically locks ALL non-exempt apps when prayer time begins.
 */
export interface PrayerFocusSettings {
  enabled: boolean;
  accessibilityGranted: boolean;
  hasSeenAccessibilityExplanation: boolean;
  prayers: Record<FocusPrayerKey, boolean>;
  duration: PrayerFocusDuration;
  updatedAt: number;
}

export interface ScheduledFocusWindow {
  id: string;
  dateStr: string;
  prayerKey: FocusPrayerKey;
  prayerNameAr: string;
  startTimeMs: number;
  endTimeMs: number;
  startFormatted: string;
  endFormatted: string;
  durationMinutes: number;
  enabled: boolean;
}

export interface ActivePrayerFocusSession {
  prayerKey: FocusPrayerKey;
  prayerNameAr: string;
  startTimeMs: number;
  endTimeMs: number;
  remainingMs: number;
  remainingMinutes: number;
  remainingFormatted: string;
  currentForegroundPackage?: string;
}

export interface PendingPrayerHarvestPrompt {
  prayerKey: FocusPrayerKey;
  prayerNameAr: string;
  dateStr: string;
  endedAtMs: number;
}

export interface PrayerDeviceLockState {
  enabled: boolean;
  deviceOwnerAvailable: boolean;
  deviceOwnerActive: boolean;
  deviceAdminActive: boolean;
  lockTaskPermitted: boolean;
  lockTaskActive: boolean;
  lockTaskModeState: string;
  serviceEnabled: boolean;
  accessibilityGranted: boolean;
  activePrayer: string;
  prayerKey?: string;
  prayerNameAr?: string;
  adhanTimestamp: number;
  endTimestamp: number;
  remainingTime: number;
  startTimeMs?: number;
  endTimeMs?: number;
  remainingMs?: number;
  remainingMinutes?: number;
  isDeviceLocked: boolean;
  isDeviceUnlocked: boolean;
  lockStartTime: string;
  lockEndTime: string;
  durationMode: string;
  durationMinutes: number;
  prayerTogglesJson?: string;
  currentForegroundPackage: string;
  isActive: boolean;
  pendingHarvestPrayerKey?: string;
  pendingHarvestPrayerName?: string;
  pendingHarvestDate?: string;
}

export type PrayerFocusNativeStatus = PrayerDeviceLockState;

export interface PrayerFocusPluginInterface {
  isPrayerFocusServiceEnabled(): Promise<{
    enabled: boolean;
    granted: boolean;
    accessibilityGranted?: boolean;
    connected?: boolean;
    deviceOwnerActive?: boolean;
    deviceAdminActive?: boolean;
    lockTaskPermitted?: boolean;
  }>;
  checkAccessibilityPermission(): Promise<{
    enabled?: boolean;
    granted: boolean;
  }>;
  openAccessibilitySettings(): Promise<{ opened: boolean }>;
  openDeviceAdminSettings(): Promise<{ opened: boolean }>;
  getPrayerFocusStatus(): Promise<PrayerDeviceLockState>;
  getPrayerDeviceLockState(): Promise<PrayerDeviceLockState>;
  getFocusState(): Promise<PrayerDeviceLockState>;
  setPrayerFocusEnabled(options: { enabled: boolean }): Promise<{
    enabled: boolean;
    serviceEnabled: boolean;
    deviceOwnerActive?: boolean;
  }>;
  setPrayerFocusDuration(options: {
    minutes?: number;
    durationMode?: string;
  }): Promise<{
    durationMode: string;
    durationMinutes: number;
  }>;
  getCurrentForegroundPackage(): Promise<{ packageName: string }>;
  startPrayerFocus(options?: {
    prayerKey?: string;
    prayerNameAr?: string;
    durationMinutes?: number;
    endTimeMs?: number;
  }): Promise<{
    started: boolean;
    prayerKey: string;
    prayerNameAr: string;
    startTimeMs: number;
    endTimeMs: number;
    adhanTimestamp?: number;
    endTimestamp?: number;
    serviceEnabled: boolean;
    deviceOwnerActive?: boolean;
    lockTaskActive?: boolean;
  }>;
  stopPrayerFocus(): Promise<{ stopped: boolean }>;
  syncPrayerFocusConfig(payload: {
    enabled: boolean;
    durationMode: string;
    durationMinutes: number;
    prayerTogglesJson: string;
    scheduledWindowsJson: string;
    cityLat: number;
    cityLng: number;
    cityNameAr: string;
    calcMethod: string;
    madhab: string;
    manualOffsetsJson: string;
  }): Promise<{
    synced: boolean;
    serviceEnabled: boolean;
    accessibilityGranted: boolean;
    deviceOwnerActive?: boolean;
    deviceAdminActive?: boolean;
    lockTaskPermitted?: boolean;
  }>;
  clearPendingHarvestPrompt(): Promise<{ cleared: boolean }>;
}

const RegisteredPrayerFocusPlugin = registerPlugin<PrayerFocusPluginInterface>('PrayerFocus');

function getNativePrayerFocusPlugin(): PrayerFocusPluginInterface | null {
  try {
    if (Capacitor.isNativePlatform()) {
      return RegisteredPrayerFocusPlugin;
    }
    const win = window as unknown as {
      Capacitor?: { Plugins?: { PrayerFocus?: PrayerFocusPluginInterface } };
    };
    return win.Capacitor?.Plugins?.PrayerFocus || null;
  } catch {
    return null;
  }
}

export function isRunningOnAndroidNative(): boolean {
  try {
    return Capacitor.isNativePlatform() || Boolean(getNativePrayerFocusPlugin());
  } catch {
    return false;
  }
}

export const FOCUS_PRAYER_LIST: {
  key: FocusPrayerKey;
  nameAr: string;
  icon: string;
}[] = [
  { key: 'fajr', nameAr: 'الفجر', icon: '🌅' },
  { key: 'dhuhr', nameAr: 'الظهر', icon: '🕛' },
  { key: 'asr', nameAr: 'العصر', icon: '🌇' },
  { key: 'maghrib', nameAr: 'المغرب', icon: '🌆' },
  { key: 'isha', nameAr: 'العشاء', icon: '🌃' },
];

export const FOCUS_DURATION_OPTIONS: {
  value: PrayerFocusDuration;
  labelAr: string;
  descAr: string;
}[] = [
  {
    value: 20,
    labelAr: '20 دقيقة (الأساسي)',
    descAr: 'الافتراضي الرسمي • قفل الجهاز وقت الصلاة لمدة ٢٠ دقيقة بالضبط منذ الأذان (adhanTimestamp + 20m)',
  },
  {
    value: 15,
    labelAr: '15 دقيقة',
    descAr: 'قفل الجهاز وقت الصلاة لمدة ١٥ دقيقة منذ دخول وقت الأذان',
  },
  {
    value: 10,
    labelAr: '10 دقائق',
    descAr: 'قفل الجهاز وقت الصلاة لمدة ١٠ دقائق منذ دخول وقت الأذان',
  },
  {
    value: 30,
    labelAr: '30 دقيقة',
    descAr: 'قفل الجهاز وقت الصلاة لمدة ٣٠ دقيقة منذ دخول وقت الأذان',
  },
  {
    value: 'until_end_of_prayer',
    labelAr: 'طوال وقت الصلاة',
    descAr: 'يستمر قفل الجهاز طوال وقت الصلاة الفعلي حسب مواقيت رِفْق',
  },
];

/**
 * Mandatory protected Emergency / SOS & critical system functions that are NEVER blocked (Requirement 20).
 * Resolved dynamically in Android Native via TelecomManager, Emergency Intents, and DevicePolicyManager.
 */
export const PROTECTED_SYSTEM_APPS: ProtectedSystemAppItem[] = [
  {
    packageName: 'android.intent.action.EMERGENCY_DIAL',
    nameAr: 'مكالمات الطوارئ وخدمات النجدة (Emergency / SOS)',
    reasonAr: 'مسموحة دائماً للاتصال الفوري بالطوارئ وطلب النجدة في أي ظرف حتى داخل وضع Kiosk Lock Task',
  },
  {
    packageName: 'com.android.dialer',
    nameAr: 'الاتصال الهاتفي الطارئ (InCallUI / Telecom)',
    reasonAr: 'مسموح دائماً لإجراء واستقبال المكالمات الهاتفية الطارئة والضرورية',
  },
  {
    packageName: 'com.rifq.app',
    nameAr: 'شاشة الصلاة في رِفْق (PrayerLockActivity)',
    reasonAr: 'شاشة وضع قفل الجهاز وقت الصلاة التي تعرض وقت الأذان ووقت الانتهاء والوقت المتبقي',
  },
];

export const PRAYER_FOCUS_STORAGE_KEY = 'rifq_prayer_focus_settings_v1';
export const PRAYER_FOCUS_PENDING_HARVEST_KEY = 'rifq_prayer_focus_pending_harvest_v1';
export const PRAYER_FOCUS_DISMISSED_SESSION_KEY = 'rifq_prayer_focus_dismissed_session_v1';
export const PRAYER_TRACKER_STORAGE_KEY = 'rafiq_prayer_tracker_history';

export const DEFAULT_PRAYER_FOCUS_SETTINGS: PrayerFocusSettings = {
  enabled: false,
  accessibilityGranted: false,
  hasSeenAccessibilityExplanation: false,
  prayers: {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  },
  duration: 20,
  updatedAt: Date.now(),
};

export function loadPrayerFocusSettings(): PrayerFocusSettings {
  try {
    const raw = localStorage.getItem(PRAYER_FOCUS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_PRAYER_FOCUS_SETTINGS };
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_PRAYER_FOCUS_SETTINGS,
      ...parsed,
      prayers: {
        ...DEFAULT_PRAYER_FOCUS_SETTINGS.prayers,
        ...(parsed.prayers || {}),
      },
      duration: parsed.duration || 20,
    };
  } catch {
    return { ...DEFAULT_PRAYER_FOCUS_SETTINGS };
  }
}

export function savePrayerFocusSettings(
  partial: Partial<PrayerFocusSettings>,
  skipNativeWrite = false
): PrayerFocusSettings {
  const current = loadPrayerFocusSettings();

  const updated: PrayerFocusSettings = {
    ...current,
    ...partial,
    prayers: {
      ...current.prayers,
      ...(partial.prayers || {}),
    },
    updatedAt: Date.now(),
  };

  try {
    localStorage.setItem(PRAYER_FOCUS_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }

  if (!skipNativeWrite) {
    syncPrayerFocusWithNativeBridge(updated);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-prayer-focus-changed', { detail: updated })
    );
  }

  return updated;
}

// ═══════════════════════════════════════════════════════════════════════════
// Explicit React <-> Android Native Bridge APIs (Automatic Prayer Mode)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * 1. isPrayerFocusServiceEnabled()
 * Queries Android's Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES in real time.
 * Never claims the service is enabled if it is not actually enabled in Android Settings!
 */
export async function isPrayerFocusServiceEnabled(): Promise<boolean> {
  const plugin = getNativePrayerFocusPlugin();
  if (!plugin) {
    const cur = loadPrayerFocusSettings();
    if (cur.accessibilityGranted) {
      savePrayerFocusSettings({ accessibilityGranted: false }, true);
    }
    return false;
  }

  try {
    const res = await plugin.isPrayerFocusServiceEnabled();
    const realGranted = Boolean(res?.enabled ?? res?.granted);
    const current = loadPrayerFocusSettings();
    if (current.accessibilityGranted !== realGranted) {
      savePrayerFocusSettings({ accessibilityGranted: realGranted }, true);
    }
    return realGranted;
  } catch {
    return false;
  }
}

export const checkNativeAccessibilityPermission = isPrayerFocusServiceEnabled;

/**
 * 2. openAccessibilitySettings()
 * Opens Android's official Accessibility Settings screen so the user can manually enable RIFQ's service.
 */
export async function openAccessibilitySettings(): Promise<{ openedNative: boolean }> {
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      await plugin.openAccessibilitySettings();
      return { openedNative: true };
    } catch {
      return { openedNative: false };
    }
  }
  return { openedNative: false };
}

export const openNativeAccessibilitySettings = openAccessibilitySettings;

/**
 * 2.5. openDeviceAdminSettings()
 * Opens Android's official Device Administrator activation screen for PrayerDeviceAdminReceiver.
 */
export async function openDeviceAdminSettings(): Promise<{ openedNative: boolean }> {
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      await plugin.openDeviceAdminSettings();
      return { openedNative: true };
    } catch {
      return { openedNative: false };
    }
  }
  return { openedNative: false };
}

function formatHHMM(ms?: number): string {
  if (!ms || ms <= 0) return '';
  const d = new Date(ms);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/**
 * 3. getPrayerFocusStatus() / getPrayerDeviceLockState()
 * Retrieves the complete authoritative native PrayerDeviceLockState from Android and hydrates local state.
 * Note (Requirement 26): isDeviceLocked is NEVER true just because React UI displays a lock view;
 * it strictly reflects real Android Keyguard / Lock Task Mode state!
 */
export async function getPrayerFocusStatus(): Promise<PrayerDeviceLockState> {
  const plugin = getNativePrayerFocusPlugin();
  const local = loadPrayerFocusSettings();
  const activeLocal = getActivePrayerFocusSession();

  if (plugin) {
    try {
      const status = await plugin.getPrayerFocusStatus();
      const partialUpdate: Partial<PrayerFocusSettings> = {
        accessibilityGranted: Boolean(status.serviceEnabled || status.deviceOwnerActive),
      };
      if (typeof status.enabled === 'boolean') {
        partialUpdate.enabled = status.enabled;
      }
      if (status.durationMode) {
        partialUpdate.duration =
          status.durationMode === 'until_end_of_prayer'
            ? 'until_end_of_prayer'
            : Number(status.durationMode) || status.durationMinutes || 20;
      }
      if (status.prayerTogglesJson) {
        try {
          const parsedToggles = JSON.parse(status.prayerTogglesJson);
          if (parsedToggles && typeof parsedToggles === 'object') {
            partialUpdate.prayers = {
              ...local.prayers,
              ...parsedToggles,
            };
          }
        } catch {
          // ignore
        }
      }
      savePrayerFocusSettings(partialUpdate, true);
      return status;
    } catch {
      // fallback
    }
  }

  return {
    enabled: local.enabled,
    deviceOwnerAvailable: false,
    deviceOwnerActive: false,
    deviceAdminActive: false,
    lockTaskPermitted: false,
    lockTaskActive: false,
    lockTaskModeState: 'NONE',
    serviceEnabled: false,
    accessibilityGranted: false,
    activePrayer: activeLocal?.prayerKey || '',
    prayerKey: activeLocal?.prayerKey,
    prayerNameAr: activeLocal?.prayerNameAr,
    adhanTimestamp: activeLocal?.startTimeMs || 0,
    endTimestamp: activeLocal?.endTimeMs || 0,
    remainingTime: activeLocal?.remainingMs || 0,
    startTimeMs: activeLocal?.startTimeMs,
    endTimeMs: activeLocal?.endTimeMs,
    remainingMs: activeLocal?.remainingMs,
    remainingMinutes: activeLocal?.remainingMinutes,
    // Strictly false when not locked by real Android OS Keyguard / Lock Task Mode
    isDeviceLocked: false,
    isDeviceUnlocked: true,
    lockStartTime: formatHHMM(activeLocal?.startTimeMs),
    lockEndTime: formatHHMM(activeLocal?.endTimeMs),
    durationMode: String(local.duration),
    durationMinutes: typeof local.duration === 'number' ? local.duration : 20,
    currentForegroundPackage: '',
    isActive: false,
  };
}

export const getPrayerDeviceLockState = getPrayerFocusStatus;

/**
 * 4. setPrayerFocusEnabled(enabled)
 * Enables or disables Automatic Prayer Mode in both Native SharedPreferences and local settings.
 */
export async function setPrayerFocusEnabled(enabled: boolean): Promise<boolean> {
  savePrayerFocusSettings({ enabled });
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      const res = await plugin.setPrayerFocusEnabled({ enabled });
      return Boolean(res.enabled);
    } catch {
      // ignore
    }
  }
  return enabled;
}

/**
 * 5. setPrayerFocusDuration(duration)
 * Sets the focus duration (10, 15, 20, 30 minutes, or "until_end_of_prayer").
 */
export async function setPrayerFocusDuration(
  duration: PrayerFocusDuration
): Promise<PrayerFocusDuration> {
  savePrayerFocusSettings({ duration });
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      if (duration === 'until_end_of_prayer') {
        await plugin.setPrayerFocusDuration({
          durationMode: 'until_end_of_prayer',
          minutes: 0,
        });
      } else {
        await plugin.setPrayerFocusDuration({
          durationMode: String(duration),
          minutes: Number(duration),
        });
      }
    } catch {
      // ignore
    }
  }
  return duration;
}

/**
 * 6. getCurrentForegroundPackage()
 * Returns the foreground package name currently reported by Android's PrayerFocusAccessibilityService.
 */
export async function getCurrentForegroundPackage(): Promise<string> {
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      const res = await plugin.getCurrentForegroundPackage();
      return res?.packageName || '';
    } catch {
      return '';
    }
  }
  return '';
}

/**
 * 7. startPrayerFocus()
 * Starts an immediate real native Prayer Focus session for the specified prayer & duration.
 */
export async function startPrayerFocus(options?: {
  prayerKey?: FocusPrayerKey;
  prayerNameAr?: string;
  durationMinutes?: number;
}): Promise<boolean> {
  const settings = loadPrayerFocusSettings();
  const durationMins =
    options?.durationMinutes ||
    (typeof settings.duration === 'number' ? settings.duration : 20);
  const prayerKey = options?.prayerKey || 'dhuhr';
  const prayerNameAr =
    options?.prayerNameAr ||
    FOCUS_PRAYER_LIST.find((p) => p.key === prayerKey)?.nameAr ||
    'الصلاة';

  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      const res = await plugin.startPrayerFocus({
        prayerKey,
        prayerNameAr,
        durationMinutes: durationMins,
      });
      savePrayerFocusSettings({ enabled: true });
      return Boolean(res.started);
    } catch {
      return false;
    }
  }
  return false;
}

/**
 * 8. stopPrayerFocus()
 * Stops the currently active Prayer Focus session in Android Native.
 */
export async function stopPrayerFocus(): Promise<boolean> {
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      await plugin.stopPrayerFocus();
    } catch {
      // ignore
    }
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('rifq-prayer-focus-changed'));
  }
  return true;
}

function getLocalDateStr(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;
}

/**
 * Computes the actual astronomical start and end time of each prayer lock window
 * using RIFQ's single-source-of-truth prayerCalculator.
 */
export function calculateFocusWindowsForDate(
  targetDate: Date,
  focusSettings: PrayerFocusSettings = loadPrayerFocusSettings()
): ScheduledFocusWindow[] {
  const city = getCurrentCity();
  const prayerSettings = getPrayerSettings();
  const prayerData = calculateAllPrayerData(
    city.latitude,
    city.longitude,
    targetDate,
    prayerSettings
  );

  const tomorrowDate = new Date(targetDate.getTime() + 24 * 60 * 60 * 1000);
  const tomorrowData = calculateAllPrayerData(
    city.latitude,
    city.longitude,
    tomorrowDate,
    prayerSettings
  );

  const dateStr = getLocalDateStr(targetDate);
  const windows: ScheduledFocusWindow[] = [];

  for (const pMeta of FOCUS_PRAYER_LIST) {
    const pKey = pMeta.key;
    const startDate = prayerData.times[pKey];
    if (!startDate) continue;

    let naturalEndDate: Date;
    switch (pKey) {
      case 'fajr':
        naturalEndDate = prayerData.times.sunrise;
        break;
      case 'dhuhr':
        naturalEndDate = prayerData.times.asr;
        break;
      case 'asr':
        naturalEndDate = prayerData.times.maghrib;
        break;
      case 'maghrib':
        naturalEndDate = prayerData.times.isha;
        break;
      case 'isha': {
        const midNight = prayerData.sunnahTimes.middleOfTheNight;
        if (midNight && midNight.getTime() > startDate.getTime()) {
          naturalEndDate = midNight;
        } else {
          naturalEndDate = tomorrowData.times.fajr;
        }
        break;
      }
    }

    const startMs = startDate.getTime();
    const naturalEndMs = naturalEndDate.getTime();

    let endMs: number;
    if (focusSettings.duration === 'until_end_of_prayer') {
      endMs = naturalEndMs;
    } else {
      const fixedDurationMs = (Number(focusSettings.duration) || 20) * 60 * 1000;
      endMs = Math.min(naturalEndMs, startMs + fixedDurationMs);
    }

    const durationMinutes = Math.max(1, Math.round((endMs - startMs) / 60000));

    windows.push({
      id: `${dateStr}_${pKey}`,
      dateStr,
      prayerKey: pKey,
      prayerNameAr: pMeta.nameAr,
      startTimeMs: startMs,
      endTimeMs: endMs,
      startFormatted: formatPrayerTime(startDate, prayerSettings.timeFormat),
      endFormatted: formatPrayerTime(new Date(endMs), prayerSettings.timeFormat),
      durationMinutes,
      enabled: Boolean(focusSettings.prayers[pKey]),
    });
  }

  return windows;
}

/**
 * Syncs the current settings, city coordinates, calculation method, madhab, and calculated prayer windows
 * (today + tomorrow) with the Native Android Plugin so AccessibilityService and AlarmManager work 100% offline in the background.
 */
export function syncPrayerFocusWithNativeBridge(
  focusSettings: PrayerFocusSettings = loadPrayerFocusSettings()
): void {
  const now = new Date();
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const allWindows = [
    ...calculateFocusWindowsForDate(now, focusSettings),
    ...calculateFocusWindowsForDate(tomorrow, focusSettings),
  ];

  const city = getCurrentCity();
  const prayerSettings = getPrayerSettings();

  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    plugin
      .syncPrayerFocusConfig({
        enabled: focusSettings.enabled,
        durationMode: String(focusSettings.duration),
        durationMinutes:
          typeof focusSettings.duration === 'number' ? focusSettings.duration : 20,
        prayerTogglesJson: JSON.stringify(focusSettings.prayers),
        scheduledWindowsJson: JSON.stringify(allWindows),
        cityLat: city.latitude,
        cityLng: city.longitude,
        cityNameAr: city.nameAr,
        calcMethod: prayerSettings.method,
        madhab: prayerSettings.madhab,
        manualOffsetsJson: JSON.stringify(prayerSettings.manualOffsets || {}),
      })
      .then((res) => {
        if (typeof res?.serviceEnabled === 'boolean') {
          const cur = loadPrayerFocusSettings();
          if (cur.accessibilityGranted !== res.serviceEnabled) {
            savePrayerFocusSettings({ accessibilityGranted: res.serviceEnabled }, true);
          }
        }
      })
      .catch(() => {});
  }
}

export function isPrayerLoggedToday(
  dateStr: string,
  prayerKey: FocusPrayerKey
): boolean {
  const history = loadPrayerTrackerHistory();
  const status = history[dateStr]?.prayers?.[prayerKey];
  return status === 'mosque' || status === 'on_time' || status === 'late';
}

export function formatFocusRemainingText(remainingMs: number): string {
  const totalMinutes = Math.max(1, Math.ceil(remainingMs / 60000));
  if (totalMinutes < 60) {
    return `متبقي ${totalMinutes} ${
      totalMinutes === 1 ? 'دقيقة' : totalMinutes === 2 ? 'دقيقتان' : totalMinutes <= 10 ? 'دقائق' : 'دقيقة'
    }`;
  }
  const hrs = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  const hrsText = hrs === 1 ? 'ساعة' : hrs === 2 ? 'ساعتان' : 'ساعات';
  if (mins === 0) {
    return `متبقي ${hrs} ${hrsText}`;
  }
  return `متبقي ${hrs} ${hrsText} و ${mins} دقيقة`;
}

/**
 * Determines if Automatic Prayer Mode is currently inside an active prayer focus window based on RIFQ's real prayer times.
 */
export function getActivePrayerFocusSession(
  now: Date = new Date()
): ActivePrayerFocusSession | null {
  const settings = loadPrayerFocusSettings();
  if (!settings.enabled || !settings.accessibilityGranted) {
    return null;
  }

  const nowMs = now.getTime();
  let dismissedWindowId = '';
  try {
    dismissedWindowId = localStorage.getItem(PRAYER_FOCUS_DISMISSED_SESSION_KEY) || '';
  } catch {
    // ignore
  }

  const todayWindows = calculateFocusWindowsForDate(now, settings);
  const yesterday = new Date(nowMs - 24 * 60 * 60 * 1000);
  const yesterdayWindows = calculateFocusWindowsForDate(yesterday, settings);
  const candidateWindows = [...yesterdayWindows, ...todayWindows];

  for (const win of candidateWindows) {
    if (!win.enabled) continue;
    if (win.id === dismissedWindowId) continue;

    if (nowMs >= win.startTimeMs && nowMs < win.endTimeMs) {
      const remainingMs = Math.max(0, win.endTimeMs - nowMs);
      return {
        prayerKey: win.prayerKey,
        prayerNameAr: win.prayerNameAr,
        startTimeMs: win.startTimeMs,
        endTimeMs: win.endTimeMs,
        remainingMs,
        remainingMinutes: Math.max(1, Math.ceil(remainingMs / 60000)),
        remainingFormatted: formatFocusRemainingText(remainingMs),
      };
    }
  }

  return null;
}

export function dismissCurrentFocusWindow(dateStr: string, prayerKey: FocusPrayerKey): void {
  try {
    localStorage.setItem(PRAYER_FOCUS_DISMISSED_SESSION_KEY, `${dateStr}_${prayerKey}`);
  } catch {
    // ignore
  }
  stopPrayerFocus().catch(() => {});
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('rifq-prayer-focus-changed'));
  }
}

/**
 * Evaluates Prayer Focus Mode transitions (start notification & post-focus Harvest prompt).
 * Important: NEVER logs the prayer automatically when focus ends — only prompts the user!
 */
export async function checkPrayerFocusLifecycle(now: Date = new Date()): Promise<void> {
  const settings = loadPrayerFocusSettings();
  if (settings.enabled) {
    syncPrayerFocusWithNativeBridge(settings);
  }

  const serviceActive = await isPrayerFocusServiceEnabled();
  if (!settings.enabled || !serviceActive) return;

  const nowMs = now.getTime();
  const todayWindows = calculateFocusWindowsForDate(now, settings);

  for (const win of todayWindows) {
    if (!win.enabled) continue;

    const startDiff = nowMs - win.startTimeMs;
    const firedStartKey = `rifq_focus_start_notified_${win.id}`;
    if (startDiff >= 0 && startDiff <= 15 * 60 * 1000 && !localStorage.getItem(firedStartKey)) {
      localStorage.setItem(firedStartKey, 'true');

      if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan)) {
        await triggerPushNotification({
          title: 'تم تفعيل وضع الصلاة تلقائياً 🔒',
          message: `دخل وقت صلاة ${win.prayerNameAr} • تم قفل التطبيقات تلقائياً لتفرغك لأداء الصلاة بخشوع.`,
          tag: `prayer-focus-start-${win.id}`,
          screen: 'prayers',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhan,
        });
      }

      addNotification({
        title: 'تم تفعيل وضع الصلاة تلقائياً 🔒',
        message: `تم قفل التطبيقات تلقائياً لصلاة ${win.prayerNameAr}. ستُفتح التطبيقات تلقائياً فور انتهاء الوقت المحدد.`,
        time: 'الآن',
        read: false,
        type: 'reminder',
      });
    }

    // When focus window ends -> ask user whether they prayed (NEVER auto-log!)
    const endDiff = nowMs - win.endTimeMs;
    const promptedEndKey = `rifq_focus_end_prompted_${win.id}`;
    if (
      endDiff >= 0 &&
      endDiff <= 2 * 60 * 60 * 1000 &&
      !localStorage.getItem(promptedEndKey) &&
      !isPrayerLoggedToday(win.dateStr, win.prayerKey)
    ) {
      localStorage.setItem(promptedEndKey, 'true');
      savePendingHarvestPrompt({
        prayerKey: win.prayerKey,
        prayerNameAr: win.prayerNameAr,
        dateStr: win.dateStr,
        endedAtMs: win.endTimeMs,
      });
    }
  }

  // Also check if Native Android AlarmReceiver recorded a pending Harvest prompt while RIFQ was closed
  const plugin = getNativePrayerFocusPlugin();
  if (plugin) {
    try {
      const state = await plugin.getPrayerFocusStatus();
      if (state.pendingHarvestPrayerKey && state.pendingHarvestDate) {
        const pKey = state.pendingHarvestPrayerKey as FocusPrayerKey;
        if (!isPrayerLoggedToday(state.pendingHarvestDate, pKey)) {
          savePendingHarvestPrompt({
            prayerKey: pKey,
            prayerNameAr: state.pendingHarvestPrayerName || 'الصلاة',
            dateStr: state.pendingHarvestDate,
            endedAtMs: Date.now(),
          });
        }
        await plugin.clearPendingHarvestPrompt();
      }
    } catch {
      // ignore
    }
  }
}

export function loadPendingHarvestPrompt(): PendingPrayerHarvestPrompt | null {
  try {
    const raw = localStorage.getItem(PRAYER_FOCUS_PENDING_HARVEST_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as PendingPrayerHarvestPrompt;
  } catch {
    return null;
  }
}

export function savePendingHarvestPrompt(
  prompt: PendingPrayerHarvestPrompt | null
): void {
  try {
    if (!prompt) {
      localStorage.removeItem(PRAYER_FOCUS_PENDING_HARVEST_KEY);
    } else {
      localStorage.setItem(PRAYER_FOCUS_PENDING_HARVEST_KEY, JSON.stringify(prompt));
    }
  } catch {
    // ignore
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-prayer-harvest-prompt', { detail: prompt })
    );
  }
}

// ─── Unified Prayer Tracker & Worship Harvest / My Journey (رحلتي) Single Source of Truth ───

export function loadPrayerTrackerHistory(): Record<string, DailyPrayerTracker> {
  try {
    const saved = localStorage.getItem(PRAYER_TRACKER_STORAGE_KEY);
    return saved ? JSON.parse(saved) : {};
  } catch {
    return {};
  }
}

export function savePrayerTrackerStatus(
  dateStr: string,
  prayerKey: PrayerKey,
  status: PrayerTrackingStatus
): Record<string, DailyPrayerTracker> {
  const prev = loadPrayerTrackerHistory();
  const currentDay: DailyPrayerTracker = prev[dateStr] || {
    date: dateStr,
    prayers: {
      fajr: 'none',
      sunrise: 'none',
      dhuhr: 'none',
      asr: 'none',
      maghrib: 'none',
      isha: 'none',
    },
  };

  const next: Record<string, DailyPrayerTracker> = {
    ...prev,
    [dateStr]: {
      ...currentDay,
      prayers: {
        ...currentDay.prayers,
        [prayerKey]: status,
      },
    },
  };

  try {
    localStorage.setItem(PRAYER_TRACKER_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-prayer-tracker-updated', {
        detail: { dateStr, prayerKey, status, history: next },
      })
    );
  }

  return next;
}

export interface PrayerJourneyStats {
  totalPrayersLogged: number;
  fullFivePrayerDaysCount: number;
  currentJourneyDay: number;
  currentStreakDays: number;
  todayCompletedCount: number;
  todayPrayers: Record<FocusPrayerKey, boolean>;
}

export function calculatePrayerJourneyStats(
  history: Record<string, DailyPrayerTracker> = loadPrayerTrackerHistory(),
  now: Date = new Date()
): PrayerJourneyStats {
  const todayStr = getLocalDateStr(now);
  const todayRec = history[todayStr]?.prayers;

  const isDone = (s?: PrayerTrackingStatus) =>
    s === 'mosque' || s === 'on_time' || s === 'late';

  const todayPrayers: Record<FocusPrayerKey, boolean> = {
    fajr: isDone(todayRec?.fajr),
    dhuhr: isDone(todayRec?.dhuhr),
    asr: isDone(todayRec?.asr),
    maghrib: isDone(todayRec?.maghrib),
    isha: isDone(todayRec?.isha),
  };

  const todayCompletedCount = FOCUS_PRAYER_LIST.filter(
    (p) => todayPrayers[p.key]
  ).length;

  let totalPrayersLogged = 0;
  let fullFivePrayerDaysCount = 0;
  const activeDates: string[] = [];

  for (const [dateKey, dayTracker] of Object.entries(history)) {
    if (!dayTracker?.prayers) continue;
    const countForDay = FOCUS_PRAYER_LIST.filter((p) =>
      isDone(dayTracker.prayers[p.key])
    ).length;
    totalPrayersLogged += countForDay;
    if (countForDay > 0) {
      activeDates.push(dateKey);
    }
    if (countForDay === 5) {
      fullFivePrayerDaysCount += 1;
    }
  }

  let currentStreakDays = 0;
  const cursor = new Date(now);
  for (let i = 0; i < 365; i++) {
    const key = getLocalDateStr(cursor);
    const rec = history[key]?.prayers;
    const dayCount = rec
      ? FOCUS_PRAYER_LIST.filter((p) => isDone(rec[p.key])).length
      : 0;
    if (dayCount > 0) {
      currentStreakDays += 1;
    } else if (i > 0) {
      break;
    }
    cursor.setDate(cursor.getDate() - 1);
  }

  const currentJourneyDay = Math.max(1, activeDates.length || 1);

  return {
    totalPrayersLogged,
    fullFivePrayerDaysCount,
    currentJourneyDay,
    currentStreakDays,
    todayCompletedCount,
    todayPrayers,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// IN-APP PRAYER & REVERENCE MODE (وضع الصلاة والخشوع)
// ═══════════════════════════════════════════════════════════════════════════

export const IN_APP_PRAYER_MODE_STORAGE_KEY = 'rifq_in_app_prayer_mode_state_v1';

export interface InAppPrayerModeState {
  isActive: boolean;
  prayerKey: FocusPrayerKey;
  prayerNameAr: string;
  startTimeMs: number;
  endTimeMs: number;
  durationMinutes: number;
  isMinimized: boolean;
  blockedCount: number;
  todayDateKey: string;
}

export const DEFAULT_IN_APP_PRAYER_MODE_STATE: InAppPrayerModeState = {
  isActive: false,
  prayerKey: 'dhuhr',
  prayerNameAr: 'الظهر',
  startTimeMs: 0,
  endTimeMs: 0,
  durationMinutes: 20,
  isMinimized: false,
  blockedCount: 0,
  todayDateKey: '',
};

export function getInAppPrayerModeState(): InAppPrayerModeState {
  try {
    const raw = localStorage.getItem(IN_APP_PRAYER_MODE_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_IN_APP_PRAYER_MODE_STATE };
    const parsed = JSON.parse(raw) as InAppPrayerModeState;
    if (parsed.isActive && parsed.endTimeMs && Date.now() >= parsed.endTimeMs) {
      parsed.isActive = false;
      localStorage.setItem(IN_APP_PRAYER_MODE_STORAGE_KEY, JSON.stringify(parsed));
      if (typeof window !== 'undefined') {
        window.dispatchEvent(
          new CustomEvent('rifq-in-app-prayer-mode-changed', { detail: parsed })
        );
      }
    }
    return parsed;
  } catch {
    return { ...DEFAULT_IN_APP_PRAYER_MODE_STATE };
  }
}

export function saveInAppPrayerModeState(state: InAppPrayerModeState): void {
  try {
    localStorage.setItem(IN_APP_PRAYER_MODE_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-in-app-prayer-mode-changed', { detail: state })
    );
  }
}

export function startInAppPrayerMode(options?: {
  prayerKey?: FocusPrayerKey;
  prayerNameAr?: string;
  durationMinutes?: number;
}): InAppPrayerModeState {
  const now = new Date();
  const todayDateKey = getLocalDateStr(now);
  const prayerKey: FocusPrayerKey = options?.prayerKey || 'dhuhr';
  const prayerNameAr =
    options?.prayerNameAr ||
    FOCUS_PRAYER_LIST.find((p) => p.key === prayerKey)?.nameAr ||
    'الصلاة';
  const durationMinutes = options?.durationMinutes || 20;
  const startTimeMs = now.getTime();
  const endTimeMs = startTimeMs + durationMinutes * 60 * 1000;

  const state: InAppPrayerModeState = {
    isActive: true,
    prayerKey,
    prayerNameAr,
    startTimeMs,
    endTimeMs,
    durationMinutes,
    isMinimized: false,
    blockedCount: 0,
    todayDateKey,
  };

  saveInAppPrayerModeState(state);
  return state;
}

export function stopInAppPrayerMode(completedPrayed = false): InAppPrayerModeState {
  const current = getInAppPrayerModeState();
  if (completedPrayed && current.prayerKey) {
    const todayStr = current.todayDateKey || getLocalDateStr(new Date());
    savePrayerTrackerStatus(todayStr, current.prayerKey, 'on_time');
  }
  const updated: InAppPrayerModeState = {
    ...current,
    isActive: false,
  };
  saveInAppPrayerModeState(updated);
  return updated;
}

export function extendInAppPrayerMode(extraMinutes = 5): InAppPrayerModeState {
  const current = getInAppPrayerModeState();
  if (!current.isActive) return current;
  const updated: InAppPrayerModeState = {
    ...current,
    endTimeMs: current.endTimeMs + extraMinutes * 60 * 1000,
    durationMinutes: current.durationMinutes + extraMinutes,
  };
  saveInAppPrayerModeState(updated);
  return updated;
}

export function toggleInAppPrayerModeMinimized(minimized?: boolean): InAppPrayerModeState {
  const current = getInAppPrayerModeState();
  const nextMin = typeof minimized === 'boolean' ? minimized : !current.isMinimized;
  const updated: InAppPrayerModeState = {
    ...current,
    isMinimized: nextMin,
  };
  saveInAppPrayerModeState(updated);
  return updated;
}

export function incrementBlockedNotificationCount(): number {
  const current = getInAppPrayerModeState();
  if (!current.isActive) return 0;
  const nextCount = (current.blockedCount || 0) + 1;
  const updated: InAppPrayerModeState = {
    ...current,
    blockedCount: nextCount,
  };
  saveInAppPrayerModeState(updated);
  return nextCount;
}

export function isPrayerQuietModeActive(): boolean {
  const inAppState = getInAppPrayerModeState();
  if (inAppState.isActive && inAppState.endTimeMs > Date.now()) {
    return true;
  }
  return false;
}

