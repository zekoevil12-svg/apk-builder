import { OFFLINE_SURAHS, SURAH_LIST, SurahDetail } from '../data/quranData';
import { getSurahDetail } from './quranService';

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * بنية قاعدة البيانات (SQLite / IndexedDB Offline Schema) لـ «التصفح التفاعلي»
 * ═══════════════════════════════════════════════════════════════════════════
 * 1. جدول quran_ayahs:
 *    id | surah_id | ayah_number | ayah_text | page_number | juz_number
 *
 * 2. جدول quran_words:
 *    id | surah_id | ayah_number | word_index | word_text | word_text_without_tashkeel | position
 *
 * 3. جدول quiz_questions:
 *    id | surah_id | surah_name | ayah_number | page_number | juz_number | ayah_text
 *    word_id | word_index | word_text | word_text_without_tashkeel | difficulty
 *    masked_word_preview | missing_slots_json | created_at
 *
 * 4. جدول quiz_results:
 *    id | surah_id | surah_name | from_ayah | to_ayah | questions_count | difficulty
 *    score | correct_answers | wrong_answers | accuracy_percent | elapsed_seconds | mistakes | created_at
 */

export const SQLITE_DDL_SCHEMA = `-- 1. جدول الآيات القرآنية (مصحف المدينة - حفص عن عاصم)
CREATE TABLE IF NOT EXISTS quran_ayahs (
  id TEXT PRIMARY KEY,
  surah_id INTEGER NOT NULL,
  ayah_number INTEGER NOT NULL,
  ayah_text TEXT NOT NULL,
  page_number INTEGER NOT NULL,
  juz_number INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_quran_ayahs_surah ON quran_ayahs(surah_id, ayah_number);

-- 2. جدول كلمات القرآن المقطعة بدقة 100%
CREATE TABLE IF NOT EXISTS quran_words (
  id TEXT PRIMARY KEY,
  surah_id INTEGER NOT NULL,
  ayah_number INTEGER NOT NULL,
  word_index INTEGER NOT NULL,
  word_text TEXT NOT NULL,
  word_text_without_tashkeel TEXT NOT NULL,
  position INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_quran_words_surah_ayah ON quran_words(surah_id, ayah_number, word_index);

-- 3. جدول أسئلة التصفح التفاعلي الجاهزة للعمل دون اتصال (Offline)
CREATE TABLE IF NOT EXISTS quiz_questions (
  id TEXT PRIMARY KEY,
  surah_id INTEGER NOT NULL,
  surah_name TEXT NOT NULL,
  ayah_number INTEGER NOT NULL,
  page_number INTEGER NOT NULL,
  juz_number INTEGER NOT NULL,
  ayah_text TEXT NOT NULL,
  word_id TEXT NOT NULL,
  word_index INTEGER NOT NULL,
  word_text TEXT NOT NULL,
  word_text_without_tashkeel TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  masked_word_preview TEXT NOT NULL,
  missing_slots_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (word_id) REFERENCES quran_words(id)
);
CREATE INDEX IF NOT EXISTS idx_quiz_questions_lookup ON quiz_questions(surah_id, ayah_number, difficulty);

-- 4. جدول نتائج وسجل اختبارات التصفح التفاعلي
CREATE TABLE IF NOT EXISTS quiz_results (
  id TEXT PRIMARY KEY,
  surah_id INTEGER NOT NULL,
  surah_name TEXT NOT NULL,
  from_ayah INTEGER NOT NULL,
  to_ayah INTEGER NOT NULL,
  questions_count INTEGER NOT NULL,
  difficulty TEXT NOT NULL,
  score INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  wrong_answers INTEGER NOT NULL,
  accuracy_percent INTEGER NOT NULL,
  elapsed_seconds INTEGER NOT NULL,
  mistakes_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);`;

export interface QuranAyahRow {
  id: string; // `${surah_id}_${ayah_number}`
  surah_id: number;
  ayah_number: number;
  ayah_text: string;
  page_number: number;
  juz_number: number;
}

export interface QuranWordRow {
  id: string; // `${surah_id}_${ayah_number}_${word_index}`
  surah_id: number;
  ayah_number: number;
  word_index: number;
  word_text: string;
  word_text_without_tashkeel: string;
  position: number;
}

export type QuizDifficultyLevel = 'easy' | 'medium' | 'hard';

export interface LetterCluster {
  clusterIndex: number;
  clusterWithTashkeel: string; // الحرف مع تشكيله العثماني الأصلي
  baseLetter: string; // الحرف الأصلي بدون تشكيل
  normalizedLetter: string; // الحرف المعياري للمطابقة الدقيقة (مثلاً ٱ -> ا)
}

export interface MissingLetterSlot {
  slotId: string; // `${word_index}_${clusterIndex}`
  wordIndex: number;
  clusterIndex: number;
  originalClusterWithTashkeel: string;
  correctBaseLetter: string; // الحرف الصحيح للعرض على الأزرار
  normalizedCorrectLetter: string; // للتحقق الدقيق 100%
  options: string[]; // خيارات الحروف لهذا الموضع
}

export interface QuizQuestionRow {
  id: string; // `${surah_id}_${ayah_number}_${word_index}_${difficulty}`
  surah_id: number;
  surah_name: string;
  ayah_number: number;
  page_number: number;
  juz_number: number;
  ayah_text: string;
  word_id: string; // المفتاح المرتبط بجدول quran_words
  word_index: number;
  word_text: string;
  word_text_without_tashkeel: string;
  difficulty: QuizDifficultyLevel;
  masked_word_preview: string; // الكلمة مع الفراغ مثل: الْمُـ[؟]ـكُ
  missing_slots_json: string; // JSON serialized MissingLetterSlot[]
  missing_slots: MissingLetterSlot[];
  created_at: string;
}

export interface InteractiveBrowsingQuestion {
  questionIndex: number;
  questionRowId?: string;
  surah_id: number;
  surah_name: string;
  ayah_number: number;
  page_number: number;
  juz_number: number;
  ayah_text: string;
  previous_ayah?: QuranAyahRow;
  next_ayah?: QuranAyahRow;
  words: QuranWordRow[];
  wordClustersMap: Record<number, LetterCluster[]>; // word_index -> LetterCluster[]
  missingSlots: MissingLetterSlot[]; // الحروف الناقصة المطلوب إكمالها بالترتيب
}

export interface InteractiveQuizMistake {
  surah_id: number;
  surah_name: string;
  ayah_number: number;
  word_index: number;
  word_text: string;
  word_text_without_tashkeel: string;
  ayah_text: string;
  correct_letter: string;
  selected_wrong_letter: string;
  cluster_index: number;
}

export interface InteractiveQuizResultRow {
  id: string;
  surah_id: number;
  surah_name: string;
  from_ayah: number;
  to_ayah: number;
  questions_count: number;
  difficulty: QuizDifficultyLevel;
  score: number;
  correct_answers: number;
  wrong_answers: number;
  accuracy_percent: number;
  elapsed_seconds: number;
  mistakes: InteractiveQuizMistake[];
  created_at: string;
}

export interface InteractiveQuizSettings {
  fontSize: number;
  showTashkeel: boolean;
  enableSoundEffects: boolean;
  autoAdvanceQuestion: boolean;
  showContextAyahs: boolean;
}

export interface SqliteTablesStats {
  initialized: boolean;
  syncedSurahsCount: number;
  totalAyahsRows: number;
  totalWordsRows: number;
  totalQuizQuestionsRows: number;
  surahAyahsCount: number;
  surahWordsCount: number;
  surahQuestionsCount: number;
  sampleWords: QuranWordRow[];
  sampleQuestions: QuizQuestionRow[];
}

const IDB_NAME = 'rifq_quran_uthmani_sqlite_db_v2';
const IDB_VERSION = 2;
const STORE_AYAHS = 'quran_ayahs';
const STORE_WORDS = 'quran_words';
const STORE_QUESTIONS = 'quiz_questions';
const STORE_RESULTS = 'quiz_results';

const LS_RESULTS_KEY = 'rifq_interactive_browsing_quiz_results_v1';
const LS_SETTINGS_KEY = 'rifq_interactive_browsing_settings_v1';
const LS_SYNCED_SURAHS_KEY = 'rifq_interactive_synced_surahs_v2';
const LS_FULL_QURAN_SYNCED_KEY = 'rifq_interactive_full_quran_synced_v2';
const LS_DB_BOOTSTRAPPED_KEY = 'rifq_interactive_sqlite_bootstrapped_v2';

// In-memory fast cache for zero-lag low-end device performance
const memoryAyahsBySurah = new Map<number, QuranAyahRow[]>();
const memoryWordsBySurah = new Map<number, QuranWordRow[]>();
const memoryQuestionsBySurah = new Map<number, QuizQuestionRow[]>();

let bootstrapPromise: Promise<void> | null = null;

// ═══════════════════════════════════════════════════════════════════════════
// دوال معالجة وتقطيع النص القرآني العثماني بدقة 100%
// ═══════════════════════════════════════════════════════════════════════════

// رموز الوقف والضبط في الرسم العثماني التي لا تُعدّ كلمات مستقلة
const QURAN_PAUSE_SYMBOLS_REGEX = /^[\u06D6-\u06ED\u06DD\u06DE\u06E9\uFD3E\uFD3F]+$/;

/**
 * إزالة التشكيل والرموز العثمانية مع الحفاظ على الحروف العربية الأساسية فقط
 * لعمود word_text_without_tashkeel
 */
export function stripArabicTashkeel(text: string): string {
  if (!text) return '';
  return (
    text
      // تحويل ألف الوصل العثمانية (ٱ) إلى ألف عادية (ا)
      .replace(/\u0671/g, 'ا')
      // تحويل الألف الخنجرية (ـٰ) المسبوقة بفتحة أو حرف إلى إزالتها كعلامة تشكيل عثمانية
      .replace(/\u0670/g, '')
      // إزالة الحركات والتشكيل وعلامات الوقف العثمانية والمد والتطويل
      .replace(/[\u0610-\u061A\u064B-\u065F\u06D6-\u06ED\u0640\u06DD\u06DE\u06E9]/g, '')
      // إبقاء الحروف العربية فقط
      .replace(/[^\u0621-\u063A\u0641-\u064A]/g, '')
      .trim()
  );
}

/**
 * تطبيع الحرف للمقارنة الدقيقة بين ضغطة المستخدم والحرف الأصلي في الرسم العثماني
 */
export function normalizeArabicLetterForMatch(letter: string): string {
  const clean = stripArabicTashkeel(letter);
  if (!clean) return '';
  const ch = clean[0];
  if (ch === 'ٱ') return 'ا';
  return ch;
}

/**
 * تنظيف الكلمة من رموز الوقف الملتصقة بآخرها أو أولها مع الحفاظ على التشكيل العثماني الكامل
 */
export function cleanQuranWordToken(rawToken: string): string {
  return rawToken
    .replace(/^[\u06D6-\u06ED\u06DD\u06DE\u06E9﴿﴾()[\]]+/g, '')
    .replace(/[\u06D6-\u06ED\u06DD\u06DE\u06E9﴿﴾()[\]]+$/g, '')
    .trim();
}

/**
 * تقطيع الآية الكريمة إلى كلمات جدول quran_words بدقة 100%
 */
export function tokenizeAyahIntoWords(
  surah_id: number,
  ayah_number: number,
  ayah_text: string
): QuranWordRow[] {
  const rawTokens = (ayah_text || '').trim().split(/\s+/).filter(Boolean);
  const words: QuranWordRow[] = [];
  let wordIdx = 0;

  for (const token of rawTokens) {
    if (QURAN_PAUSE_SYMBOLS_REGEX.test(token)) {
      continue;
    }
    const cleanedWord = cleanQuranWordToken(token);
    if (!cleanedWord) continue;

    const withoutTashkeel = stripArabicTashkeel(cleanedWord);
    if (!withoutTashkeel) continue;

    words.push({
      id: `${surah_id}_${ayah_number}_${wordIdx}`,
      surah_id,
      ayah_number,
      word_index: wordIdx,
      word_text: cleanedWord,
      word_text_without_tashkeel: withoutTashkeel,
      position: wordIdx + 1,
    });
    wordIdx++;
  }

  return words;
}

/**
 * تقطيع الكلمة القرآنية الواحدة إلى عناقيد حروف (كل حرف أساسي + تشكيله العثماني الملازم له)
 */
export function splitWordIntoLetterClusters(wordText: string): LetterCluster[] {
  const clusters: LetterCluster[] = [];
  if (!wordText) return clusters;

  const isBaseArabicLetter = (ch: string): boolean => {
    const code = ch.charCodeAt(0);
    return (
      (code >= 0x0621 && code <= 0x063a) ||
      (code >= 0x0641 && code <= 0x064a) ||
      code === 0x0671
    );
  };

  let currentCluster = '';
  let currentBase = '';

  for (let i = 0; i < wordText.length; i++) {
    const ch = wordText[i];
    const code = ch.charCodeAt(0);
    if (code >= 0x06d6 && code <= 0x06ed && code !== 0x06e5 && code !== 0x06e6) {
      continue;
    }

    if (isBaseArabicLetter(ch)) {
      if (currentBase) {
        const displayBase = currentBase === '\u0671' ? 'ا' : currentBase;
        clusters.push({
          clusterIndex: clusters.length,
          clusterWithTashkeel: currentCluster,
          baseLetter: displayBase,
          normalizedLetter: normalizeArabicLetterForMatch(displayBase),
        });
      }
      currentBase = ch;
      currentCluster = ch;
    } else {
      if (currentBase) {
        currentCluster += ch;
      }
    }
  }

  if (currentBase) {
    const displayBase = currentBase === '\u0671' ? 'ا' : currentBase;
    clusters.push({
      clusterIndex: clusters.length,
      clusterWithTashkeel: currentCluster,
      baseLetter: displayBase,
      normalizedLetter: normalizeArabicLetterForMatch(displayBase),
    });
  }

  return clusters;
}

// ═══════════════════════════════════════════════════════════════════════════
// توليد الخيارات الذكية للحروف العربية وبناء صفوف جدول quiz_questions
// ═══════════════════════════════════════════════════════════════════════════

export const ALL_ARABIC_LETTERS: string[] = [
  'ا', 'أ', 'إ', 'آ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ',
  'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ',
  'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و',
  'ي', 'ة', 'ى', 'ء', 'ؤ', 'ئ',
];

const SIMILAR_ARABIC_LETTERS: Record<string, string[]> = {
  'ا': ['أ', 'إ', 'ل', 'آ', 'ى', 'و', 'ي'],
  'أ': ['إ', 'ا', 'آ', 'ؤ', 'ء', 'ئ', 'ع'],
  'إ': ['أ', 'ا', 'ئ', 'ء', 'آ', 'ي', 'ل'],
  'آ': ['أ', 'ا', 'إ', 'ء', 'ع', 'م', 'ل'],
  'ب': ['ت', 'ث', 'ن', 'ي', 'ف', 'م', 'د'],
  'ت': ['ب', 'ث', 'ة', 'ط', 'ن', 'ي', 'د'],
  'ث': ['ت', 'ب', 'س', 'ذ', 'ظ', 'ش', 'ن'],
  'ج': ['ح', 'خ', 'ع', 'غ', 'ق', 'د', 'ز'],
  'ح': ['ج', 'خ', 'ع', 'ه', 'غ', 'ص', 'م'],
  'خ': ['ح', 'ج', 'غ', 'ق', 'ع', 'ك', 'ف'],
  'د': ['ذ', 'ر', 'ز', 'ت', 'ط', 'ب', 'و'],
  'ذ': ['د', 'ز', 'ظ', 'ث', 'ر', 'ص', 'ض'],
  'ر': ['ز', 'و', 'د', 'ذ', 'ن', 'ل', 'ي'],
  'ز': ['ر', 'ذ', 'س', 'ص', 'د', 'ظ', 'ن'],
  'س': ['ش', 'ص', 'ث', 'ز', 'ض', 'ت', 'ن'],
  'ش': ['س', 'ث', 'ج', 'ص', 'ض', 'خ', 'ك'],
  'ص': ['ض', 'س', 'ط', 'ظ', 'ز', 'ع', 'ق'],
  'ض': ['ص', 'ظ', 'ط', 'ذ', 'د', 'س', 'ش'],
  'ط': ['ظ', 'ت', 'د', 'ص', 'ض', 'ق', 'ك'],
  'ظ': ['ط', 'ذ', 'ض', 'ص', 'ث', 'ز', 'د'],
  'ع': ['غ', 'ح', 'ء', 'أ', 'ه', 'ق', 'م'],
  'غ': ['ع', 'خ', 'ق', 'ح', 'ج', 'ف', 'ك'],
  'ف': ['ق', 'ب', 'غ', 'ك', 'م', 'و', 'ن'],
  'ق': ['ف', 'ك', 'غ', 'ع', 'ط', 'ص', 'خ'],
  'ك': ['ق', 'ل', 'ت', 'ف', 'ع', 'س', 'م'],
  'ل': ['ا', 'ك', 'ن', 'ر', 'م', 'ب', 'ي'],
  'م': ['ن', 'ب', 'و', 'ل', 'ف', 'ه', 'ع'],
  'ن': ['ب', 'ت', 'م', 'ل', 'ي', 'ر', 'و'],
  'ه': ['ة', 'ح', 'ع', 'أ', 'و', 'م', 'ا'],
  'و': ['ر', 'ي', 'ا', 'ؤ', 'م', 'ن', 'د'],
  'ي': ['ى', 'ب', 'ت', 'ن', 'ئ', 'و', 'ا'],
  'ة': ['ه', 'ت', 'ا', 'ى', 'ب', 'ن', 'ث'],
  'ى': ['ي', 'ا', 'ة', 'ئ', 'و', 'ن', 'ل'],
  'ء': ['أ', 'إ', 'ؤ', 'ئ', 'ع', 'ا', 'ه'],
  'ؤ': ['و', 'أ', 'ء', 'ئ', 'إ', 'ا', 'ن'],
  'ئ': ['ي', 'ء', 'إ', 'أ', 'ؤ', 'ى', 'ب'],
};

function generateLetterOptions(
  correctLetter: string,
  count: number,
  seed: number
): string[] {
  const normCorrect = normalizeArabicLetterForMatch(correctLetter) || correctLetter;
  const pool =
    SIMILAR_ARABIC_LETTERS[correctLetter] ||
    SIMILAR_ARABIC_LETTERS[normCorrect] ||
    ['ب', 'ت', 'م', 'ن', 'ل', 'س', 'ع', 'ق'];

  const chosen: string[] = [correctLetter];
  const usedNorm = new Set<string>([normCorrect, correctLetter]);

  for (let i = 0; i < pool.length && chosen.length < count; i++) {
    const candidate = pool[(i + seed) % pool.length];
    const normCand = normalizeArabicLetterForMatch(candidate);
    if (!usedNorm.has(normCand) && !usedNorm.has(candidate)) {
      usedNorm.add(normCand);
      usedNorm.add(candidate);
      chosen.push(candidate);
    }
  }

  for (let i = 0; i < ALL_ARABIC_LETTERS.length && chosen.length < count; i++) {
    const candidate = ALL_ARABIC_LETTERS[(i * 3 + seed) % ALL_ARABIC_LETTERS.length];
    const normCand = normalizeArabicLetterForMatch(candidate);
    if (!usedNorm.has(normCand) && !usedNorm.has(candidate)) {
      usedNorm.add(normCand);
      usedNorm.add(candidate);
      chosen.push(candidate);
    }
  }

  // ترتيب الخيارات بشكل متوازن وحتمي لثبات جدول quiz_questions
  const rotated: string[] = [];
  const offset = seed % chosen.length;
  for (let i = 0; i < chosen.length; i++) {
    rotated.push(chosen[(i + offset) % chosen.length]);
  }
  return rotated;
}

/**
 * تكوين معاينة نصية للكلمة مع مواضع الحروف المخفية [؟] لتخزينها في جدول quiz_questions
 */
function buildMaskedWordPreview(
  clusters: LetterCluster[],
  missingClusterIndices: Set<number>
): string {
  return clusters
    .map((c) => (missingClusterIndices.has(c.clusterIndex) ? '[؟]' : c.clusterWithTashkeel))
    .join('');
}

/**
 * بناء صفوف جدول quiz_questions لسورة كاملة انطلاقاً من جدولَي quran_ayahs و quran_words
 * بحيث تكون الأسئلة مهيأة مسبقاً ومخزنة للعمل Offline في جميع مستويات الصعوبة (easy, medium, hard)
 */
export function buildQuizQuestionsForSurah(
  surah_id: number,
  ayahRows: QuranAyahRow[],
  wordRows: QuranWordRow[]
): QuizQuestionRow[] {
  const surahMeta = SURAH_LIST.find((s) => s.number === surah_id) || SURAH_LIST[0];
  const wordsByAyah = new Map<number, QuranWordRow[]>();
  for (const w of wordRows) {
    const list = wordsByAyah.get(w.ayah_number) || [];
    list.push(w);
    wordsByAyah.set(w.ayah_number, list);
  }

  const questionRows: QuizQuestionRow[] = [];
  const nowIso = new Date().toISOString();
  const difficulties: QuizDifficultyLevel[] = ['easy', 'medium', 'hard'];

  for (const ayahRow of ayahRows) {
    const ayahWords = wordsByAyah.get(ayahRow.ayah_number) || [];
    const candidateWords: { word: QuranWordRow; clusters: LetterCluster[] }[] = [];

    for (const w of ayahWords) {
      const clusters = splitWordIntoLetterClusters(w.word_text);
      if (clusters.length >= 2) {
        candidateWords.push({ word: w, clusters });
      }
    }

    if (candidateWords.length === 0) continue;

    const richWords = candidateWords.filter((cw) => cw.clusters.length >= 3);
    const pool = richWords.length > 0 ? richWords : candidateWords;

    for (const difficulty of difficulties) {
      const optionsCount = difficulty === 'easy' ? 4 : difficulty === 'medium' ? 6 : 8;
      // توليد سؤال أو أكثر لكل آية بحسب طولها لضمان تغطية شاملة في جدول quiz_questions
      const wordsToIndexCount = Math.min(pool.length, 2);

      for (let wVariant = 0; wVariant < wordsToIndexCount; wVariant++) {
        const primaryIdx = (ayahRow.ayah_number + wVariant * 2) % pool.length;
        const primary = pool[primaryIdx];
        const missingSlots: MissingLetterSlot[] = [];
        const hiddenClusterSet = new Set<number>();

        if (difficulty === 'easy') {
          const cLen = primary.clusters.length;
          const targetClusterIdx =
            cLen > 2 ? (wVariant % 2 === 0 ? cLen - 1 : Math.floor(cLen / 2)) : cLen - 1;
          const cluster = primary.clusters[targetClusterIdx];
          hiddenClusterSet.add(cluster.clusterIndex);

          missingSlots.push({
            slotId: `${primary.word.word_index}_${cluster.clusterIndex}`,
            wordIndex: primary.word.word_index,
            clusterIndex: cluster.clusterIndex,
            originalClusterWithTashkeel: cluster.clusterWithTashkeel,
            correctBaseLetter: cluster.baseLetter,
            normalizedCorrectLetter: cluster.normalizedLetter,
            options: generateLetterOptions(
              cluster.baseLetter,
              optionsCount,
              surah_id + ayahRow.ayah_number + cluster.clusterIndex + wVariant
            ),
          });
        } else if (difficulty === 'medium') {
          if (primary.clusters.length >= 4) {
            const idx1 = Math.floor(primary.clusters.length / 2) - 1;
            const idx2 = primary.clusters.length - 1;
            for (const cIdx of [idx1, idx2]) {
              const cluster = primary.clusters[cIdx];
              hiddenClusterSet.add(cluster.clusterIndex);
              missingSlots.push({
                slotId: `${primary.word.word_index}_${cluster.clusterIndex}`,
                wordIndex: primary.word.word_index,
                clusterIndex: cluster.clusterIndex,
                originalClusterWithTashkeel: cluster.clusterWithTashkeel,
                correctBaseLetter: cluster.baseLetter,
                normalizedCorrectLetter: cluster.normalizedLetter,
                options: generateLetterOptions(
                  cluster.baseLetter,
                  optionsCount,
                  surah_id + ayahRow.ayah_number + cIdx + primary.word.word_index
                ),
              });
            }
          } else {
            const c1 = primary.clusters[primary.clusters.length - 1];
            hiddenClusterSet.add(c1.clusterIndex);
            missingSlots.push({
              slotId: `${primary.word.word_index}_${c1.clusterIndex}`,
              wordIndex: primary.word.word_index,
              clusterIndex: c1.clusterIndex,
              originalClusterWithTashkeel: c1.clusterWithTashkeel,
              correctBaseLetter: c1.baseLetter,
              normalizedCorrectLetter: c1.normalizedLetter,
              options: generateLetterOptions(
                c1.baseLetter,
                optionsCount,
                surah_id + ayahRow.ayah_number + 1
              ),
            });

            if (pool.length > 1) {
              const secondary = pool[(primaryIdx + 1) % pool.length];
              const c2 = secondary.clusters[secondary.clusters.length - 1];
              missingSlots.push({
                slotId: `${secondary.word.word_index}_${c2.clusterIndex}`,
                wordIndex: secondary.word.word_index,
                clusterIndex: c2.clusterIndex,
                originalClusterWithTashkeel: c2.clusterWithTashkeel,
                correctBaseLetter: c2.baseLetter,
                normalizedCorrectLetter: c2.normalizedLetter,
                options: generateLetterOptions(
                  c2.baseLetter,
                  optionsCount,
                  surah_id + ayahRow.ayah_number + 5
                ),
              });
            } else if (primary.clusters.length >= 2) {
              const c2 = primary.clusters[0];
              hiddenClusterSet.add(c2.clusterIndex);
              missingSlots.unshift({
                slotId: `${primary.word.word_index}_${c2.clusterIndex}`,
                wordIndex: primary.word.word_index,
                clusterIndex: c2.clusterIndex,
                originalClusterWithTashkeel: c2.clusterWithTashkeel,
                correctBaseLetter: c2.baseLetter,
                normalizedCorrectLetter: c2.normalizedLetter,
                options: generateLetterOptions(
                  c2.baseLetter,
                  optionsCount,
                  surah_id + ayahRow.ayah_number + 7
                ),
              });
            }
          }
        } else {
          // hard: 3 حروف مخفية
          const chosenPairs: { word: QuranWordRow; cluster: LetterCluster }[] = [];
          if (primary.clusters.length >= 5) {
            const indices = [1, Math.floor(primary.clusters.length / 2), primary.clusters.length - 1];
            for (const idx of Array.from(new Set(indices))) {
              chosenPairs.push({ word: primary.word, cluster: primary.clusters[idx] });
              hiddenClusterSet.add(idx);
            }
          } else {
            for (let wStep = 0; wStep < pool.length && chosenPairs.length < 3; wStep++) {
              const targetW = pool[(primaryIdx + wStep) % pool.length];
              const cLast = targetW.clusters[targetW.clusters.length - 1];
              if (
                !chosenPairs.some(
                  (p) =>
                    p.word.word_index === targetW.word.word_index &&
                    p.cluster.clusterIndex === cLast.clusterIndex
                )
              ) {
                chosenPairs.push({ word: targetW.word, cluster: cLast });
                if (targetW.word.word_index === primary.word.word_index) {
                  hiddenClusterSet.add(cLast.clusterIndex);
                }
              }
              if (chosenPairs.length < 3 && targetW.clusters.length >= 3) {
                const cMid = targetW.clusters[Math.floor(targetW.clusters.length / 2)];
                if (
                  !chosenPairs.some(
                    (p) =>
                      p.word.word_index === targetW.word.word_index &&
                      p.cluster.clusterIndex === cMid.clusterIndex
                  )
                ) {
                  chosenPairs.push({ word: targetW.word, cluster: cMid });
                  if (targetW.word.word_index === primary.word.word_index) {
                    hiddenClusterSet.add(cMid.clusterIndex);
                  }
                }
              }
            }
          }

          chosenPairs.sort((a, b) =>
            a.word.word_index !== b.word.word_index
              ? a.word.word_index - b.word.word_index
              : a.cluster.clusterIndex - b.cluster.clusterIndex
          );

          for (const pair of chosenPairs.slice(0, 3)) {
            missingSlots.push({
              slotId: `${pair.word.word_index}_${pair.cluster.clusterIndex}`,
              wordIndex: pair.word.word_index,
              clusterIndex: pair.cluster.clusterIndex,
              originalClusterWithTashkeel: pair.cluster.clusterWithTashkeel,
              correctBaseLetter: pair.cluster.baseLetter,
              normalizedCorrectLetter: pair.cluster.normalizedLetter,
              options: generateLetterOptions(
                pair.cluster.baseLetter,
                optionsCount,
                surah_id + ayahRow.ayah_number + pair.word.word_index + pair.cluster.clusterIndex
              ),
            });
          }
        }

        if (missingSlots.length > 0) {
          const maskedPreview = buildMaskedWordPreview(primary.clusters, hiddenClusterSet);
          const qRowId = `${surah_id}_${ayahRow.ayah_number}_${primary.word.word_index}_${difficulty}`;
          if (!questionRows.some((r) => r.id === qRowId)) {
            questionRows.push({
              id: qRowId,
              surah_id,
              surah_name: surahMeta.name,
              ayah_number: ayahRow.ayah_number,
              page_number: ayahRow.page_number,
              juz_number: ayahRow.juz_number,
              ayah_text: ayahRow.ayah_text,
              word_id: primary.word.id,
              word_index: primary.word.word_index,
              word_text: primary.word.word_text,
              word_text_without_tashkeel: primary.word.word_text_without_tashkeel,
              difficulty,
              masked_word_preview: maskedPreview,
              missing_slots_json: JSON.stringify(missingSlots),
              missing_slots: missingSlots,
              created_at: nowIso,
            });
          }
        }
      }
    }
  }

  return questionRows;
}

// ═══════════════════════════════════════════════════════════════════════════
// إدارة قاعدة البيانات المحلية (IndexedDB + LocalStorage SQLite Engine)
// ═══════════════════════════════════════════════════════════════════════════

function openQuranSqliteDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const request = window.indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_AYAHS)) {
          const ayahStore = db.createObjectStore(STORE_AYAHS, { keyPath: 'id' });
          ayahStore.createIndex('by_surah', 'surah_id', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_WORDS)) {
          const wordStore = db.createObjectStore(STORE_WORDS, { keyPath: 'id' });
          wordStore.createIndex('by_surah', 'surah_id', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_QUESTIONS)) {
          const qStore = db.createObjectStore(STORE_QUESTIONS, { keyPath: 'id' });
          qStore.createIndex('by_surah', 'surah_id', { unique: false });
          qStore.createIndex('by_surah_difficulty', ['surah_id', 'difficulty'], {
            unique: false,
          });
        }
        if (!db.objectStoreNames.contains(STORE_RESULTS)) {
          db.createObjectStore(STORE_RESULTS, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function markSurahSynced(surah_id: number): void {
  try {
    const synced = getSyncedSurahIds();
    if (!synced.includes(surah_id)) {
      synced.push(surah_id);
      localStorage.setItem(LS_SYNCED_SURAHS_KEY, JSON.stringify(synced));
    }
  } catch {
    // ignore
  }
}

export function getSyncedSurahIds(): number[] {
  try {
    const raw = localStorage.getItem(LS_SYNCED_SURAHS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return Object.keys(OFFLINE_SURAHS).map((n) => Number(n));
}

export function isFullQuranSyncedOffline(): boolean {
  try {
    return (
      localStorage.getItem(LS_FULL_QURAN_SYNCED_KEY) === 'true' ||
      getSyncedSurahIds().length >= 114
    );
  } catch {
    return false;
  }
}

async function saveSurahRowsToDb(
  surah_id: number,
  ayahRows: QuranAyahRow[],
  wordRows: QuranWordRow[],
  questionRows?: QuizQuestionRow[]
): Promise<QuizQuestionRow[]> {
  const effectiveQuestions =
    questionRows || buildQuizQuestionsForSurah(surah_id, ayahRows, wordRows);

  memoryAyahsBySurah.set(surah_id, ayahRows);
  memoryWordsBySurah.set(surah_id, wordRows);
  memoryQuestionsBySurah.set(surah_id, effectiveQuestions);
  markSurahSynced(surah_id);

  const db = await openQuranSqliteDb();
  if (!db) return effectiveQuestions;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_AYAHS, STORE_WORDS, STORE_QUESTIONS], 'readwrite');
      const ayahStore = tx.objectStore(STORE_AYAHS);
      const wordStore = tx.objectStore(STORE_WORDS);
      const questionStore = tx.objectStore(STORE_QUESTIONS);

      for (const row of ayahRows) {
        ayahStore.put(row);
      }
      for (const wRow of wordRows) {
        wordStore.put(wRow);
      }
      for (const qRow of effectiveQuestions) {
        questionStore.put(qRow);
      }

      tx.oncomplete = () => resolve(effectiveQuestions);
      tx.onerror = () => resolve(effectiveQuestions);
    } catch {
      resolve(effectiveQuestions);
    }
  });
}

async function loadSurahRowsFromDb(surah_id: number): Promise<{
  ayahs: QuranAyahRow[];
  words: QuranWordRow[];
  questions: QuizQuestionRow[];
} | null> {
  if (
    memoryAyahsBySurah.has(surah_id) &&
    memoryWordsBySurah.has(surah_id) &&
    memoryQuestionsBySurah.has(surah_id)
  ) {
    return {
      ayahs: memoryAyahsBySurah.get(surah_id)!,
      words: memoryWordsBySurah.get(surah_id)!,
      questions: memoryQuestionsBySurah.get(surah_id)!,
    };
  }

  const db = await openQuranSqliteDb();
  if (!db) return null;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_AYAHS, STORE_WORDS, STORE_QUESTIONS], 'readonly');
      const ayahIndex = tx.objectStore(STORE_AYAHS).index('by_surah');
      const wordIndex = tx.objectStore(STORE_WORDS).index('by_surah');
      const questionIndex = tx.objectStore(STORE_QUESTIONS).index('by_surah');

      const ayahReq = ayahIndex.getAll(IDBKeyRange.only(surah_id));
      const wordReq = wordIndex.getAll(IDBKeyRange.only(surah_id));
      const questionReq = questionIndex.getAll(IDBKeyRange.only(surah_id));

      tx.oncomplete = () => {
        const ayahs = (ayahReq.result || []) as QuranAyahRow[];
        const words = (wordReq.result || []) as QuranWordRow[];
        let questions = (questionReq.result || []) as QuizQuestionRow[];

        if (ayahs.length > 0 && words.length > 0) {
          ayahs.sort((a, b) => a.ayah_number - b.ayah_number);
          words.sort((a, b) =>
            a.ayah_number !== b.ayah_number
              ? a.ayah_number - b.ayah_number
              : a.word_index - b.word_index
          );
          if (questions.length === 0) {
            questions = buildQuizQuestionsForSurah(surah_id, ayahs, words);
          } else {
            questions = questions.map((q) => ({
              ...q,
              missing_slots:
                Array.isArray(q.missing_slots) && q.missing_slots.length > 0
                  ? q.missing_slots
                  : JSON.parse(q.missing_slots_json || '[]'),
            }));
          }
          memoryAyahsBySurah.set(surah_id, ayahs);
          memoryWordsBySurah.set(surah_id, words);
          memoryQuestionsBySurah.set(surah_id, questions);
          resolve({ ayahs, words, questions });
        } else {
          resolve(null);
        }
      };
      tx.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

/**
 * تحويل بيانات سورة كاملة إلى صفوف جداول quran_ayahs و quran_words و quiz_questions
 */
function buildSurahTablesFromDetail(detail: SurahDetail): {
  ayahs: QuranAyahRow[];
  words: QuranWordRow[];
  questions: QuizQuestionRow[];
} {
  const ayahRows: QuranAyahRow[] = [];
  const wordRows: QuranWordRow[] = [];

  for (const a of detail.ayahs) {
    if (a.text.startsWith('آية مباركة من سورة')) {
      continue;
    }
    const ayah_number = a.numberInSurah;
    const ayahRow: QuranAyahRow = {
      id: `${detail.number}_${ayah_number}`,
      surah_id: detail.number,
      ayah_number,
      ayah_text: a.text.trim(),
      page_number: a.page || detail.page || 1,
      juz_number: a.juz || detail.juz || 1,
    };
    ayahRows.push(ayahRow);

    const tokenized = tokenizeAyahIntoWords(detail.number, ayah_number, a.text);
    wordRows.push(...tokenized);
  }

  const questions = buildQuizQuestionsForSurah(detail.number, ayahRows, wordRows);
  return { ayahs: ayahRows, words: wordRows, questions };
}

/**
 * تهيئة قاعدة البيانات (Bootstrapping) وتعبئة الجداول الأساسية:
 * quran_ayahs + quran_words + quiz_questions
 * لجميع السور المدمجة Offline فور تشغيل التطبيق لضمان العمل الفوري دون اتصال بالإنترنت
 */
export async function initializeInteractiveQuizDatabase(): Promise<void> {
  if (bootstrapPromise) return bootstrapPromise;

  bootstrapPromise = (async () => {
    const offlineSurahNumbers = Object.keys(OFFLINE_SURAHS).map((n) => Number(n));
    for (const sNum of offlineSurahNumbers) {
      if (memoryWordsBySurah.has(sNum) && memoryQuestionsBySurah.has(sNum)) {
        continue;
      }
      const existing = await loadSurahRowsFromDb(sNum);
      if (existing && existing.words.length > 0 && existing.questions.length > 0) {
        continue;
      }
      const detail = OFFLINE_SURAHS[sNum];
      if (detail) {
        const built = buildSurahTablesFromDetail(detail);
        await saveSurahRowsToDb(sNum, built.ayahs, built.words, built.questions);
      }
    }
    try {
      localStorage.setItem(LS_DB_BOOTSTRAPPED_KEY, 'true');
    } catch {
      // ignore
    }
  })();

  return bootstrapPromise;
}

/**
 * جلب وتخزين سورة محددة في جداول quran_ayahs و quran_words و quiz_questions
 */
export async function ensureSurahInQuranTables(surah_id: number): Promise<{
  ayahs: QuranAyahRow[];
  words: QuranWordRow[];
  questions: QuizQuestionRow[];
}> {
  await initializeInteractiveQuizDatabase();

  // 1. الفحص في قاعدة البيانات المحلية (SQLite / IndexedDB)
  const cached = await loadSurahRowsFromDb(surah_id);
  if (cached && cached.ayahs.length > 0 && cached.words.length > 0) {
    return cached;
  }

  // 2. الجلب المباشر من API مصحف المدينة (رواية حفص عن عاصم)
  try {
    const response = await fetch(
      `https://api.alquran.cloud/v1/surah/${surah_id}/quran-uthmani`,
      { headers: { Accept: 'application/json' } }
    );
    if (response.ok) {
      const json = await response.json();
      if (json.code === 200 && json.data && Array.isArray(json.data.ayahs)) {
        const ayahRows: QuranAyahRow[] = [];
        const wordRows: QuranWordRow[] = [];

        for (let i = 0; i < json.data.ayahs.length; i++) {
          const rawAyah = json.data.ayahs[i];
          let text: string = (rawAyah.text || '').trim();
          if (
            surah_id !== 1 &&
            surah_id !== 9 &&
            i === 0 &&
            text.startsWith('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ')
          ) {
            text = text.replace('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', '').trim();
          } else if (
            surah_id !== 1 &&
            surah_id !== 9 &&
            i === 0 &&
            text.startsWith('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')
          ) {
            text = text.replace('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', '').trim();
          }

          const ayah_number = Number(rawAyah.numberInSurah) || i + 1;
          ayahRows.push({
            id: `${surah_id}_${ayah_number}`,
            surah_id,
            ayah_number,
            ayah_text: text,
            page_number: Number(rawAyah.page) || 1,
            juz_number: Number(rawAyah.juz) || 1,
          });

          const tokenized = tokenizeAyahIntoWords(surah_id, ayah_number, text);
          wordRows.push(...tokenized);
        }

        if (ayahRows.length > 0) {
          const questions = await saveSurahRowsToDb(surah_id, ayahRows, wordRows);
          return { ayahs: ayahRows, words: wordRows, questions };
        }
      }
    }
  } catch (err) {
    console.warn('Direct quran-uthmani fetch failed, trying cached surah service', err);
  }

  // 3. الجلب عبر خدمة القرآن المحلية أو السور المدمجة Offline
  const detail = await getSurahDetail(surah_id);
  const built = buildSurahTablesFromDetail(detail);
  if (built.ayahs.length > 0) {
    await saveSurahRowsToDb(surah_id, built.ayahs, built.words, built.questions);
    return built;
  }

  // 4. الملاذ الأخير إذا كان الجهاز غير متصل بالإنترنت إطلاقاً والسورة لم تُحمّل بعد
  const fallbackOffline = OFFLINE_SURAHS[surah_id] || OFFLINE_SURAHS[1];
  const fallbackBuilt = buildSurahTablesFromDetail(fallbackOffline);
  await saveSurahRowsToDb(
    fallbackOffline.number,
    fallbackBuilt.ayahs,
    fallbackBuilt.words,
    fallbackBuilt.questions
  );
  return fallbackBuilt;
}

/**
 * إحصائيات ومعاينة جداول SQLite (quran_words و quiz_questions) لعرضها والتحقق منها
 */
export async function getSqliteTablesOverview(surah_id: number): Promise<SqliteTablesStats> {
  await initializeInteractiveQuizDatabase();
  const { ayahs, words, questions } = await ensureSurahInQuranTables(surah_id);

  let totalAyahsRows = 0;
  let totalWordsRows = 0;
  let totalQuizQuestionsRows = 0;

  for (const [, list] of memoryAyahsBySurah) totalAyahsRows += list.length;
  for (const [, list] of memoryWordsBySurah) totalWordsRows += list.length;
  for (const [, list] of memoryQuestionsBySurah) totalQuizQuestionsRows += list.length;

  return {
    initialized: true,
    syncedSurahsCount: getSyncedSurahIds().length,
    totalAyahsRows,
    totalWordsRows,
    totalQuizQuestionsRows,
    surahAyahsCount: ayahs.length,
    surahWordsCount: words.length,
    surahQuestionsCount: questions.length,
    sampleWords: words.slice(0, 18),
    sampleQuestions: questions.slice(0, 12),
  };
}

/**
 * تحميل المصحف الكامل (114 سورة) من الـ API الرسمي:
 * https://api.alquran.cloud/v1/quran/quran-uthmani
 * وتخزينه في جداول quran_ayahs و quran_words و quiz_questions للعمل Offline بالكامل
 */
export async function downloadFullQuranUthmaniToDb(
  onProgress?: (percent: number, currentSurahName: string) => void
): Promise<boolean> {
  try {
    onProgress?.(5, 'جاري الاتصال بـ api.alquran.cloud/v1/quran/quran-uthmani ...');
    const response = await fetch('https://api.alquran.cloud/v1/quran/quran-uthmani', {
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) return false;

    onProgress?.(25, 'جاري قراءة المصحف العثماني الكامل وتجهيز جداول quran_words و quiz_questions...');
    const json = await response.json();
    const surahs = json?.data?.surahs;
    if (!Array.isArray(surahs) || surahs.length === 0) return false;

    for (let sIdx = 0; sIdx < surahs.length; sIdx++) {
      const s = surahs[sIdx];
      const surah_id = Number(s.number) || sIdx + 1;
      const surahName = s.name || SURAH_LIST[sIdx]?.name || `سورة ${surah_id}`;
      const ayahRows: QuranAyahRow[] = [];
      const wordRows: QuranWordRow[] = [];

      const rawAyahs = Array.isArray(s.ayahs) ? s.ayahs : [];
      for (let aIdx = 0; aIdx < rawAyahs.length; aIdx++) {
        const rawAyah = rawAyahs[aIdx];
        let text: string = (rawAyah.text || '').trim();
        if (
          surah_id !== 1 &&
          surah_id !== 9 &&
          aIdx === 0 &&
          text.startsWith('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ')
        ) {
          text = text.replace('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', '').trim();
        }

        const ayah_number = Number(rawAyah.numberInSurah) || aIdx + 1;
        ayahRows.push({
          id: `${surah_id}_${ayah_number}`,
          surah_id,
          ayah_number,
          ayah_text: text,
          page_number: Number(rawAyah.page) || 1,
          juz_number: Number(rawAyah.juz) || 1,
        });

        const tokenized = tokenizeAyahIntoWords(surah_id, ayah_number, text);
        wordRows.push(...tokenized);
      }

      const questionRows = buildQuizQuestionsForSurah(surah_id, ayahRows, wordRows);
      await saveSurahRowsToDb(surah_id, ayahRows, wordRows, questionRows);

      const pct = Math.min(99, Math.round(25 + ((sIdx + 1) / surahs.length) * 74));
      if (sIdx % 8 === 0 || sIdx === surahs.length - 1) {
        onProgress?.(
          pct,
          `تمت فهرسة ${surahName} في quran_words و quiz_questions (${sIdx + 1}/114)`
        );
      }
    }

    localStorage.setItem(LS_FULL_QURAN_SYNCED_KEY, 'true');
    onProgress?.(100, 'اكتملت تهيئة جداول quran_words و quiz_questions للمصحف كاملاً Offline');
    return true;
  } catch (err) {
    console.warn('Error downloading full quran-uthmani', err);
    return false;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// استعلام أسئلة «التصفح التفاعلي» من جداول quiz_questions و quran_words
// ═══════════════════════════════════════════════════════════════════════════

export async function generateInteractiveBrowsingQuestions(params: {
  surah_id: number;
  from_ayah: number;
  to_ayah: number;
  questions_count: number;
  difficulty: QuizDifficultyLevel;
}): Promise<InteractiveBrowsingQuestion[]> {
  const { surah_id, from_ayah, to_ayah, questions_count, difficulty } = params;
  const surahMeta = SURAH_LIST.find((s) => s.number === surah_id) || SURAH_LIST[0];
  const { ayahs, words, questions: storedQuestions } = await ensureSurahInQuranTables(surah_id);

  const minAyah = Math.max(1, Math.min(from_ayah, to_ayah));
  const maxAyah = Math.min(surahMeta.numberOfAyahs, Math.max(from_ayah, to_ayah));

  const ayahByNumber = new Map<number, QuranAyahRow>();
  for (const a of ayahs) {
    ayahByNumber.set(a.ayah_number, a);
  }

  const wordsByAyah = new Map<number, QuranWordRow[]>();
  for (const w of words) {
    const list = wordsByAyah.get(w.ayah_number) || [];
    list.push(w);
    wordsByAyah.set(w.ayah_number, list);
  }

  // جلب الأسئلة المطابقة للنطاق ومستوى الصعوبة مباشرة من جدول quiz_questions المحفوظ Offline
  const matchingStoredQuestions = storedQuestions.filter(
    (q) =>
      q.difficulty === difficulty &&
      q.ayah_number >= minAyah &&
      q.ayah_number <= maxAyah &&
      q.missing_slots &&
      q.missing_slots.length > 0
  );

  const effectivePool =
    matchingStoredQuestions.length > 0
      ? matchingStoredQuestions
      : storedQuestions.filter((q) => q.difficulty === difficulty);

  const resultQuestions: InteractiveBrowsingQuestion[] = [];

  if (effectivePool.length > 0) {
    for (let qIdx = 0; qIdx < questions_count; qIdx++) {
      const qRow = effectivePool[qIdx % effectivePool.length];
      const ayahWords = wordsByAyah.get(qRow.ayah_number) || [];
      const wordClustersMap: Record<number, LetterCluster[]> = {};
      for (const w of ayahWords) {
        wordClustersMap[w.word_index] = splitWordIntoLetterClusters(w.word_text);
      }

      resultQuestions.push({
        questionIndex: qIdx,
        questionRowId: qRow.id,
        surah_id: qRow.surah_id,
        surah_name: qRow.surah_name || surahMeta.name,
        ayah_number: qRow.ayah_number,
        page_number: qRow.page_number,
        juz_number: qRow.juz_number,
        ayah_text: qRow.ayah_text,
        previous_ayah: ayahByNumber.get(qRow.ayah_number - 1),
        next_ayah: ayahByNumber.get(qRow.ayah_number + 1),
        words: ayahWords,
        wordClustersMap,
        missingSlots: qRow.missing_slots,
      });
    }
    return resultQuestions;
  }

  return resultQuestions;
}

// ═══════════════════════════════════════════════════════════════════════════
// حفظ واسترجاع نتائج الاختبارات والإعدادات في SQLite / IndexedDB
// ═══════════════════════════════════════════════════════════════════════════

export async function saveInteractiveQuizResult(
  result: InteractiveQuizResultRow
): Promise<void> {
  try {
    const existing = loadInteractiveQuizResultsSync();
    const updated = [result, ...existing.filter((r) => r.id !== result.id)].slice(0, 100);
    localStorage.setItem(LS_RESULTS_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }

  const db = await openQuranSqliteDb();
  if (!db) return;

  return new Promise((resolve) => {
    try {
      const tx = db.transaction([STORE_RESULTS], 'readwrite');
      tx.objectStore(STORE_RESULTS).put(result);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export function loadInteractiveQuizResultsSync(): InteractiveQuizResultRow[] {
  try {
    const raw = localStorage.getItem(LS_RESULTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // ignore
  }
  return [];
}

export function loadInteractiveQuizSettings(): InteractiveQuizSettings {
  try {
    const raw = localStorage.getItem(LS_SETTINGS_KEY);
    if (raw) {
      return {
        fontSize: 28,
        showTashkeel: true,
        enableSoundEffects: true,
        autoAdvanceQuestion: true,
        showContextAyahs: true,
        ...JSON.parse(raw),
      };
    }
  } catch {
    // ignore
  }
  return {
    fontSize: 28,
    showTashkeel: true,
    enableSoundEffects: true,
    autoAdvanceQuestion: true,
    showContextAyahs: true,
  };
}

export function saveInteractiveQuizSettings(settings: InteractiveQuizSettings): void {
  try {
    localStorage.setItem(LS_SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}
