import { RosaryThemeId } from '../types';

export interface RosaryTheme {
  id: RosaryThemeId;
  nameAr: string;
  subtitleAr: string;
  icon: string;
  previewColor: string; // Primary hex
  accentColor: string;  // Hex for glow / ripples
  // SVG gradients for 3D beads
  beadGradient: {
    stop0: string;
    stop25: string;
    stop60: string;
    stop85: string;
    stop100: string;
  };
  activeBeadGradient: {
    stop0: string;
    stop25: string;
    stop60: string;
    stop88: string;
    stop100: string;
  };
  bottomAmbientStroke: string;
  // Classic mode styles & central elements
  buttonGradient: string;
  buttonShadow: string;
  buttonActiveShadow: string;
  ringGradient: {
    start: string;
    middle: string;
    end: string;
  };
  numberColor: string;
  targetTextColor: string;
  cardIconBg: string;
  cardIconText: string;
  chipActiveBg: string;
  particleColors: string[];
}

export const ROSARY_THEMES: RosaryTheme[] = [
  {
    id: 'gold',
    nameAr: 'بنفسجي ووردي (رفق)',
    subtitleAr: 'الهوية البصرية العصرية لتطبيق رفق (افتراضي)',
    icon: 'gold',
    previewColor: '#5B5FEF',
    accentColor: '#E99AC7',
    beadGradient: {
      stop0: '#EEEEFF',
      stop25: '#9EA1F7',
      stop60: '#5B5FEF',
      stop85: '#4145C7',
      stop100: '#25263A',
    },
    activeBeadGradient: {
      stop0: '#FFFFFF',
      stop25: '#F7CEE5',
      stop60: '#E99AC7',
      stop88: '#5B5FEF',
      stop100: '#4145C7',
    },
    bottomAmbientStroke: '#E99AC7',
    buttonGradient: 'from-[#5B5FEF] to-[#4145C7]',
    buttonShadow: 'shadow-[0_10px_28px_rgba(91,95,239,0.35)]',
    buttonActiveShadow: 'shadow-[0_4px_16px_rgba(91,95,239,0.55)]',
    ringGradient: {
      start: '#E99AC7',
      middle: '#5B5FEF',
      end: '#4145C7',
    },
    numberColor: '#5B5FEF',
    targetTextColor: '#77798C',
    cardIconBg: 'bg-[#EEEEFF]',
    cardIconText: 'text-[#4145C7]',
    chipActiveBg: 'bg-[#5B5FEF] text-white',
    particleColors: ['#5B5FEF', '#E99AC7', '#72B7E8', '#E8B84A', '#4145C7', '#FFFFFF'],
  },
  {
    id: 'emerald',
    nameAr: 'ذهبي وبنفسجي',
    subtitleAr: 'تدرج ذهبي دافئ مع البنفسجي العصري',
    icon: 'emerald',
    previewColor: '#E8B84A',
    accentColor: '#5B5FEF',
    beadGradient: {
      stop0: '#FDF3D7',
      stop25: '#F2CF78',
      stop60: '#E8B84A',
      stop85: '#C7962B',
      stop100: '#25263A',
    },
    activeBeadGradient: {
      stop0: '#FFFFFF',
      stop25: '#FAE3A7',
      stop60: '#E8B84A',
      stop88: '#5B5FEF',
      stop100: '#4145C7',
    },
    bottomAmbientStroke: '#E8B84A',
    buttonGradient: 'from-[#5B5FEF] to-[#4145C7]',
    buttonShadow: 'shadow-[0_10px_28px_rgba(91,95,239,0.35)]',
    buttonActiveShadow: 'shadow-[0_4px_16px_rgba(91,95,239,0.55)]',
    ringGradient: {
      start: '#E8B84A',
      middle: '#5B5FEF',
      end: '#4145C7',
    },
    numberColor: '#5B5FEF',
    targetTextColor: '#77798C',
    cardIconBg: 'bg-[#EEEEFF]',
    cardIconText: 'text-[#4145C7]',
    chipActiveBg: 'bg-[#5B5FEF] text-white',
    particleColors: ['#E8B84A', '#5B5FEF', '#72B7E8', '#E99AC7', '#FFFFFF'],
  },
  {
    id: 'sapphire',
    nameAr: 'أزرق سماوي هادئ',
    subtitleAr: 'أزرق صافي مريح للعين مع لمسة بنفسجية',
    icon: 'sapphire',
    previewColor: '#72B7E8',
    accentColor: '#5B5FEF',
    beadGradient: {
      stop0: '#EBF5FC',
      stop25: '#9ACEF0',
      stop60: '#72B7E8',
      stop85: '#5B5FEF',
      stop100: '#25263A',
    },
    activeBeadGradient: {
      stop0: '#FFFFFF',
      stop25: '#B6DCF6',
      stop60: '#72B7E8',
      stop88: '#5B5FEF',
      stop100: '#4145C7',
    },
    bottomAmbientStroke: '#72B7E8',
    buttonGradient: 'from-[#5B5FEF] to-[#4145C7]',
    buttonShadow: 'shadow-[0_10px_28px_rgba(91,95,239,0.35)]',
    buttonActiveShadow: 'shadow-[0_4px_16px_rgba(91,95,239,0.55)]',
    ringGradient: {
      start: '#72B7E8',
      middle: '#5B5FEF',
      end: '#4145C7',
    },
    numberColor: '#5B5FEF',
    targetTextColor: '#77798C',
    cardIconBg: 'bg-[#EEEEFF]',
    cardIconText: 'text-[#4145C7]',
    chipActiveBg: 'bg-[#5B5FEF] text-white',
    particleColors: ['#72B7E8', '#5B5FEF', '#E99AC7', '#E8B84A', '#FFFFFF'],
  },
  {
    id: 'brown',
    nameAr: 'بنفسجي داكن',
    subtitleAr: 'تدرج بنفسجي رصين وهادئ',
    icon: 'brown',
    previewColor: '#4145C7',
    accentColor: '#72B7E8',
    beadGradient: {
      stop0: '#EEEEFF',
      stop25: '#7B7FF2',
      stop60: '#4145C7',
      stop85: '#25263A',
      stop100: '#1B1C2B',
    },
    activeBeadGradient: {
      stop0: '#FFFFFF',
      stop25: '#EEEEFF',
      stop60: '#5B5FEF',
      stop88: '#4145C7',
      stop100: '#25263A',
    },
    bottomAmbientStroke: '#72B7E8',
    buttonGradient: 'from-[#5B5FEF] to-[#4145C7]',
    buttonShadow: 'shadow-[0_10px_28px_rgba(91,95,239,0.35)]',
    buttonActiveShadow: 'shadow-[0_4px_16px_rgba(91,95,239,0.55)]',
    ringGradient: {
      start: '#72B7E8',
      middle: '#5B5FEF',
      end: '#4145C7',
    },
    numberColor: '#4145C7',
    targetTextColor: '#77798C',
    cardIconBg: 'bg-[#EEEEFF]',
    cardIconText: 'text-[#4145C7]',
    chipActiveBg: 'bg-[#4145C7] text-white',
    particleColors: ['#5B5FEF', '#4145C7', '#72B7E8', '#E8B84A', '#FFFFFF'],
  },
  {
    id: 'rose',
    nameAr: 'وردي ناعم',
    subtitleAr: 'تدرج وردي وبنفسجي لطيف ومريح للعين',
    icon: 'rose',
    previewColor: '#E99AC7',
    accentColor: '#5B5FEF',
    beadGradient: {
      stop0: '#FDF2F8',
      stop25: '#F2B8D8',
      stop60: '#E99AC7',
      stop85: '#5B5FEF',
      stop100: '#4145C7',
    },
    activeBeadGradient: {
      stop0: '#FFFFFF',
      stop25: '#F9D5E9',
      stop60: '#E99AC7',
      stop88: '#5B5FEF',
      stop100: '#4145C7',
    },
    bottomAmbientStroke: '#E99AC7',
    buttonGradient: 'from-[#5B5FEF] to-[#4145C7]',
    buttonShadow: 'shadow-[0_10px_28px_rgba(91,95,239,0.35)]',
    buttonActiveShadow: 'shadow-[0_4px_16px_rgba(91,95,239,0.55)]',
    ringGradient: {
      start: '#E99AC7',
      middle: '#5B5FEF',
      end: '#4145C7',
    },
    numberColor: '#5B5FEF',
    targetTextColor: '#77798C',
    cardIconBg: 'bg-[#EEEEFF]',
    cardIconText: 'text-[#4145C7]',
    chipActiveBg: 'bg-[#5B5FEF] text-white',
    particleColors: ['#E99AC7', '#5B5FEF', '#72B7E8', '#E8B84A', '#FFFFFF'],
  },
];

export function getRosaryTheme(themeId?: RosaryThemeId): RosaryTheme {
  if (themeId === 'amber' || themeId === 'onyx') {
    return ROSARY_THEMES.find((t) => t.id === 'brown') || ROSARY_THEMES[0];
  }
  if (themeId === 'pearl') {
    return ROSARY_THEMES.find((t) => t.id === 'rose') || ROSARY_THEMES[0];
  }
  const found = ROSARY_THEMES.find((t) => t.id === themeId);
  return found || ROSARY_THEMES[0];
}
