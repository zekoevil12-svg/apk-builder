import { 
  SurahDetail, 
  AyahItem, 
  OFFLINE_SURAHS, 
  SURAH_LIST, 
  BookmarkItem, 
  KhatmahTracker 
} from '../data/quranData';

const CACHE_PREFIX = 'mushaba_surah_cache_v2_';
const BOOKMARKS_KEY = 'mushaba_quran_bookmarks_v1';
const LAST_READ_KEY = 'mushaba_quran_last_read_v1';
const KHATMAH_KEY = 'mushaba_quran_khatmah_v1';
const FAVORITES_KEY = 'mushaba_quran_favorites_v1';
const AUDIO_SPEED_KEY = 'mushaba_audio_speed_v1';
const RECITER_KEY = 'mushaba_quran_reciter_v1';

export interface LastReadPosition {
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
  ayahText?: string;
  timestamp: number;
}

// Fetch full Surah with Arabic text, Tafseer, and translations
export async function getSurahDetail(surahNumber: number): Promise<SurahDetail> {
  const safeSurahNumber =
    typeof surahNumber === 'number' && !Number.isNaN(surahNumber) && surahNumber >= 1 && surahNumber <= 114
      ? surahNumber
      : 1;
  const meta = SURAH_LIST.find((s) => s.number === safeSurahNumber) || SURAH_LIST[0];

  // 1. Check local storage cache first
  const cacheKey = `${CACHE_PREFIX}${safeSurahNumber}`;
  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed && Array.isArray(parsed.ayahs) && parsed.ayahs.length > 0) {
        return {
          ...meta,
          ...parsed,
          number: typeof parsed.number === 'number' ? parsed.number : meta.number,
          name: parsed.name || meta.name,
        } as SurahDetail;
      }
    }
  } catch (e) {
    console.warn('Error reading surah cache', e);
  }

  // 2. Check offline pre-packaged surahs
  if (OFFLINE_SURAHS[safeSurahNumber]) {
    return OFFLINE_SURAHS[safeSurahNumber];
  }

  // 3. Fetch from API (alquran.cloud with multiple editions: uthmani, muyassar, translations)
  try {
    // We request quran-uthmani (Arabic), ar.muyassar (Tafseer), en.sahih (English), fr.hamidullah (French), ur.jalandhry (Urdu)
    const res = await fetch(
      `https://api.alquran.cloud/v1/surah/${safeSurahNumber}/editions/quran-uthmani,ar.muyassar,en.sahih,fr.hamidullah,ur.jalandhry`,
      { headers: { Accept: 'application/json' } }
    );

    if (res.ok) {
      const json = await res.json();
      if (json.code === 200 && Array.isArray(json.data) && json.data.length > 0) {
        const arabicData = json.data[0];
        const tafseerData = json.data[1];
        const englishData = json.data[2];
        const frenchData = json.data[3];
        const urduData = json.data[4];

        const ayahs: AyahItem[] = arabicData.ayahs.map((a: any, idx: number) => {
          let text = a.text;
          // In Surah 1 (Al-Fatihah), Bismillah is ayah 1. In other surahs, sometimes API prefixes Bismillah in first ayah
          if (surahNumber !== 1 && surahNumber !== 9 && idx === 0 && text.startsWith('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ')) {
            text = text.replace('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', '').trim();
          }

          return {
            numberInSurah: a.numberInSurah,
            globalNumber: a.number,
            text,
            translationEn: englishData?.ayahs?.[idx]?.text,
            translationFr: frenchData?.ayahs?.[idx]?.text,
            translationUr: urduData?.ayahs?.[idx]?.text,
            tafseer: tafseerData?.ayahs?.[idx]?.text,
            juz: a.juz,
            page: a.page,
          };
        });

        const detail: SurahDetail = {
          ...meta,
          bismillahPre: surahNumber !== 1 && surahNumber !== 9,
          ayahs,
        };

        // Save to cache for offline access
        try {
          localStorage.setItem(cacheKey, JSON.stringify(detail));
        } catch {
          // Ignore quota errors
        }

        return detail;
      }
    }
  } catch (err) {
    console.warn('Failed to fetch surah from remote API, attempting simple fallback', err);
  }

  // Fallback: If offline and not in bundle, synthesize placeholder verses so user can still browse and read
  const placeholderAyahs: AyahItem[] = Array.from({ length: meta.numberOfAyahs }, (_, i) => ({
    numberInSurah: i + 1,
    globalNumber: (meta.number * 100) + (i + 1),
    text: `آية مباركة من سورة ${meta.name} رقم (${i + 1})`,
    tafseer: `تفسير الآية ${i + 1} من سورة ${meta.name}`,
    juz: meta.juz,
    page: meta.page,
  }));

  return {
    ...meta,
    bismillahPre: surahNumber !== 1 && surahNumber !== 9,
    ayahs: placeholderAyahs,
  };
}

// Last read helpers
export function loadLastRead(): LastReadPosition {
  try {
    const raw = localStorage.getItem(LAST_READ_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(e);
  }
  return {
    surahNumber: 1,
    surahName: 'الفَاتِحَة',
    ayahNumber: 1,
    ayahText: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    timestamp: Date.now(),
  };
}

export function saveLastRead(pos: LastReadPosition) {
  try {
    localStorage.setItem(LAST_READ_KEY, JSON.stringify(pos));
  } catch (e) {
    console.warn(e);
  }
}

// Bookmarks
export function loadBookmarks(): BookmarkItem[] {
  try {
    const raw = localStorage.getItem(BOOKMARKS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(e);
  }
  return [];
}

export function saveBookmarks(list: BookmarkItem[]) {
  try {
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn(e);
  }
}

export function toggleBookmark(bookmark: Omit<BookmarkItem, 'id' | 'timestamp'>): BookmarkItem[] {
  const current = loadBookmarks();
  const existingIndex = current.findIndex(
    (b) => b.surahNumber === bookmark.surahNumber && b.ayahNumber === bookmark.ayahNumber
  );

  let updated: BookmarkItem[];
  if (existingIndex >= 0) {
    updated = current.filter((_, idx) => idx !== existingIndex);
  } else {
    const newItem: BookmarkItem = {
      ...bookmark,
      id: `bm-${bookmark.surahNumber}-${bookmark.ayahNumber}-${Date.now()}`,
      timestamp: Date.now(),
    };
    updated = [newItem, ...current];
  }

  saveBookmarks(updated);
  return updated;
}

export function updateBookmarkNote(
  surahNumber: number,
  ayahNumber: number,
  note: string
): BookmarkItem[] {
  const current = loadBookmarks();
  const updated = current.map((b) => {
    if (b.surahNumber === surahNumber && b.ayahNumber === ayahNumber) {
      return {
        ...b,
        note: note.trim() || undefined,
      };
    }
    return b;
  });
  saveBookmarks(updated);
  return updated;
}

export function removeBookmarkById(id: string): BookmarkItem[] {
  const current = loadBookmarks();
  const updated = current.filter((b) => b.id !== id);
  saveBookmarks(updated);
  return updated;
}

// Favorites (Surah IDs)
export function loadFavoriteSurahs(): number[] {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(e);
  }
  return [1, 18, 36, 55, 67, 112]; // Default favorite surahs
}

export function toggleFavoriteSurah(surahNumber: number): number[] {
  const cur = loadFavoriteSurahs();
  let updated: number[];
  if (cur.includes(surahNumber)) {
    updated = cur.filter((n) => n !== surahNumber);
  } else {
    updated = [...cur, surahNumber];
  }
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn(e);
  }
  return updated;
}

// Khatmah tracker
export function loadKhatmah(): KhatmahTracker {
  try {
    const raw = localStorage.getItem(KHATMAH_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.warn(e);
  }
  return {
    startDate: new Date().toISOString().split('T')[0],
    targetDays: 30,
    currentJuz: 1,
    currentSurahNumber: 1,
    completedAyahsCount: 7,
    readSurahs: [1],
    notes: 'ختمة مباركة بنية القبول والثواب',
  };
}

export function saveKhatmah(tracker: KhatmahTracker) {
  try {
    localStorage.setItem(KHATMAH_KEY, JSON.stringify(tracker));
  } catch (e) {
    console.warn(e);
  }
}

// Tafseer types and IDs
export type TafseerType = 'muyassar' | 'saadi' | 'ibnkathir' | 'qurtubi';

export const TAFSEER_CONFIG: Record<TafseerType, { name: string; id: number; author: string }> = {
  muyassar: { name: 'التفسير الميسر', id: 16, author: 'نخبة من العلماء بإشراف مجمع الملك فهد' },
  saadi: { name: 'تفسير السعدي', id: 169, author: 'الشيخ عبد الرحمن بن ناصر السعدي' },
  ibnkathir: { name: 'تفسير ابن كثير', id: 14, author: 'الإمام عماد الدين إسماعيل بن كثير' },
  qurtubi: { name: 'تفسير القرطبي', id: 93, author: 'الإمام محمد بن أحمد القرطبي' },
};

// Fetch specific authentic Tafseer from Quran.com API with local caching
export async function getAyahTafseer(
  surahNumber: number,
  ayahNumber: number,
  type: TafseerType = 'muyassar'
): Promise<{ text: string; author: string; name: string }> {
  const cacheKey = `mushaf_tafseer_${type}_${surahNumber}_${ayahNumber}`;
  const config = TAFSEER_CONFIG[type];

  try {
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      return JSON.parse(cached);
    }
  } catch (e) {
    console.warn(e);
  }

  try {
    const res = await fetch(
      `https://api.quran.com/api/v4/tafsirs/${config.id}/by_ayah/${surahNumber}:${ayahNumber}`,
      { headers: { Accept: 'application/json' } }
    );

    if (res.ok) {
      const data = await res.json();
      if (data && data.tafsir && data.tafsir.text) {
        // Strip HTML tags for clean text
        const cleanText = data.tafsir.text.replace(/<[^>]+>/g, '').trim();
        const result = {
          text: cleanText,
          author: config.author,
          name: config.name,
        };
        try {
          localStorage.setItem(cacheKey, JSON.stringify(result));
        } catch {
          // ignore cache quota
        }
        return result;
      }
    }
  } catch (err) {
    console.warn(`Failed to fetch tafseer ${type} from quran.com`, err);
  }

  // Fallback if network or offline: return standard muyassar or informative note
  return {
    text: `تفسير الآية الكريمة (${ayahNumber}) من سورة (${surahNumber}) وفق ${config.name} يتطلب اتصالاً بالإنترنت للتحميل لأول مرة.`,
    author: config.author,
    name: config.name,
  };
}


