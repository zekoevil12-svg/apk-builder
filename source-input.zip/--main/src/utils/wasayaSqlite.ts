import {
  WASAYA_CATEGORIES,
  INITIAL_WASAYA_ITEMS,
  WASAYA_SQLITE_DDL_SCHEMA,
  WasayaCategory,
  WasayaCategoryId,
  WasiyaItem,
  WasayaCategorySqliteRow,
  WasayaSqliteRow,
  WasayaFavoriteSqliteRow,
} from '../data/wasayaData';

const WASAYA_IDB_NAME = 'rifq_wasaya_sqlite_v1';
const WASAYA_IDB_VERSION = 1;
const STORE_CATEGORIES = 'categories';
const STORE_WASAYA = 'wasaya';
const STORE_FAVORITES = 'favorites';

const LS_WASAYA_CATEGORIES_KEY = 'rifq_sqlite_wasaya_categories_v1';
const LS_WASAYA_TABLE_KEY = 'rifq_sqlite_wasaya_table_v1';
const LS_WASAYA_FAVORITES_KEY = 'rifq_sqlite_wasaya_favorites_v1';

let memoryCategories: WasayaCategorySqliteRow[] | null = null;
let memoryWasaya: WasayaSqliteRow[] | null = null;
let memoryFavorites: WasayaFavoriteSqliteRow[] | null = null;

function normalizeArabicForSearch(text: string): string {
  return text
    .replace(/[\u0617-\u061A\u064B-\u0652\u0670]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function syncWasayaToIndexedDb(
  categories: WasayaCategorySqliteRow[],
  wasaya: WasayaSqliteRow[],
  favorites: WasayaFavoriteSqliteRow[]
): void {
  if (typeof window === 'undefined' || !('indexedDB' in window)) return;
  try {
    const request = window.indexedDB.open(WASAYA_IDB_NAME, WASAYA_IDB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_CATEGORIES)) {
        db.createObjectStore(STORE_CATEGORIES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_WASAYA)) {
        const store = db.createObjectStore(STORE_WASAYA, { keyPath: 'id' });
        store.createIndex('category_id', 'category_id', { unique: false });
        store.createIndex('order_number', 'order_number', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_FAVORITES)) {
        const favStore = db.createObjectStore(STORE_FAVORITES, { keyPath: 'id' });
        favStore.createIndex('wasiya_id', 'wasiya_id', { unique: true });
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      try {
        const tx = db.transaction(
          [STORE_CATEGORIES, STORE_WASAYA, STORE_FAVORITES],
          'readwrite'
        );
        const catStore = tx.objectStore(STORE_CATEGORIES);
        const wasayaStore = tx.objectStore(STORE_WASAYA);
        const favStore = tx.objectStore(STORE_FAVORITES);

        catStore.clear();
        categories.forEach((c) => catStore.put(c));

        wasayaStore.clear();
        wasaya.forEach((w) => wasayaStore.put(w));

        favStore.clear();
        favorites.forEach((f) => favStore.put(f));
      } catch {
        // ignore IndexedDB transaction error in restricted frames
      }
    };
  } catch {
    // ignore
  }
}

export function initWasayaSqliteTables(): {
  categories: WasayaCategorySqliteRow[];
  wasaya: WasayaSqliteRow[];
  favorites: WasayaFavoriteSqliteRow[];
} {
  let favRows: WasayaFavoriteSqliteRow[] = [];
  try {
    const rawFav = localStorage.getItem(LS_WASAYA_FAVORITES_KEY);
    if (rawFav) {
      const parsed = JSON.parse(rawFav);
      if (Array.isArray(parsed)) {
        favRows = parsed.filter((r) => r && typeof r.wasiya_id === 'string');
      }
    }
  } catch {
    favRows = [];
  }

  const categoryRows: WasayaCategorySqliteRow[] = WASAYA_CATEGORIES.map((c) => ({
    id: c.id,
    name: c.name,
    icon: c.icon,
    description: c.description,
  }));

  const wasayaRows: WasayaSqliteRow[] = INITIAL_WASAYA_ITEMS.map((item) => ({
    id: item.id,
    category_id: item.category_id,
    title: item.title,
    subtopic: item.subtopic,
    text: item.text,
    source: item.source,
    book: item.book,
    narrator: item.narrator,
    hadith_number: item.hadith_number,
    grade: item.grade,
    explanation: item.explanation,
    lessons: JSON.stringify(item.lessons),
    order_number: item.order_number,
  }));

  memoryCategories = categoryRows;
  memoryWasaya = wasayaRows;
  memoryFavorites = favRows;

  try {
    localStorage.setItem(LS_WASAYA_CATEGORIES_KEY, JSON.stringify(categoryRows));
    localStorage.setItem(LS_WASAYA_TABLE_KEY, JSON.stringify(wasayaRows));
    localStorage.setItem(LS_WASAYA_FAVORITES_KEY, JSON.stringify(favRows));
  } catch {
    // ignore storage quota errors
  }

  syncWasayaToIndexedDb(categoryRows, wasayaRows, favRows);

  return {
    categories: categoryRows,
    wasaya: wasayaRows,
    favorites: favRows,
  };
}

function rowToWasiyaItem(
  row: WasayaSqliteRow,
  favSet: Set<string>
): WasiyaItem & { isFavorite: boolean } {
  let lessons: string[] = [];
  try {
    const parsed = JSON.parse(row.lessons);
    if (Array.isArray(parsed)) {
      lessons = parsed;
    }
  } catch {
    lessons = [];
  }

  return {
    id: row.id,
    category_id: row.category_id as WasayaCategoryId,
    title: row.title,
    subtopic: row.subtopic,
    text: row.text,
    source: row.source,
    book: row.book,
    narrator: row.narrator,
    hadith_number: row.hadith_number,
    grade: row.grade,
    explanation: row.explanation,
    lessons,
    order_number: row.order_number,
    isFavorite: favSet.has(row.id),
  };
}

export function loadWasayaCategoriesFromStorage(): (WasayaCategory & { count: number })[] {
  const tables =
    memoryCategories && memoryWasaya && memoryFavorites
      ? { categories: memoryCategories, wasaya: memoryWasaya, favorites: memoryFavorites }
      : initWasayaSqliteTables();

  return WASAYA_CATEGORIES.map((cat) => {
    const count = tables.wasaya.filter((w) => w.category_id === cat.id).length;
    return {
      ...cat,
      count,
    };
  });
}

export function loadWasayaFromStorage(): (WasiyaItem & { isFavorite: boolean })[] {
  const tables =
    memoryCategories && memoryWasaya && memoryFavorites
      ? { categories: memoryCategories, wasaya: memoryWasaya, favorites: memoryFavorites }
      : initWasayaSqliteTables();

  const favSet = new Set(tables.favorites.map((f) => f.wasiya_id));
  return [...tables.wasaya]
    .sort((a, b) => a.order_number - b.order_number)
    .map((row) => rowToWasiyaItem(row, favSet));
}

export function loadWasayaByCategoryFromStorage(
  categoryId: WasayaCategoryId
): (WasiyaItem & { isFavorite: boolean })[] {
  return loadWasayaFromStorage().filter((item) => item.category_id === categoryId);
}

export function loadWasayaFavorites(): string[] {
  const tables =
    memoryCategories && memoryWasaya && memoryFavorites
      ? { categories: memoryCategories, wasaya: memoryWasaya, favorites: memoryFavorites }
      : initWasayaSqliteTables();
  return tables.favorites.map((f) => f.wasiya_id);
}

export function loadFavoriteWasayaItems(): (WasiyaItem & { isFavorite: boolean })[] {
  return loadWasayaFromStorage().filter((w) => w.isFavorite);
}

export function toggleWasayaFavorite(wasiyaId: string): {
  favoriteIds: string[];
  isFavorite: boolean;
} {
  const tables = initWasayaSqliteTables();
  const exists = tables.favorites.some((f) => f.wasiya_id === wasiyaId);
  let updatedFavs: WasayaFavoriteSqliteRow[];

  if (exists) {
    updatedFavs = tables.favorites.filter((f) => f.wasiya_id !== wasiyaId);
  } else {
    updatedFavs = [
      ...tables.favorites,
      {
        id: `fav_${wasiyaId}`,
        wasiya_id: wasiyaId,
        added_at: new Date().toISOString(),
      },
    ];
  }

  memoryFavorites = updatedFavs;

  try {
    localStorage.setItem(LS_WASAYA_FAVORITES_KEY, JSON.stringify(updatedFavs));
  } catch {
    // ignore
  }

  syncWasayaToIndexedDb(tables.categories, tables.wasaya, updatedFavs);

  return {
    favoriteIds: updatedFavs.map((f) => f.wasiya_id),
    isFavorite: !exists,
  };
}

export function searchWasayaInStorage(
  query: string,
  categoryFilter: WasayaCategoryId | 'all' = 'all',
  bookFilter: string = 'all'
): (WasiyaItem & { isFavorite: boolean })[] {
  let list = loadWasayaFromStorage();

  if (categoryFilter !== 'all') {
    list = list.filter((w) => w.category_id === categoryFilter);
  }

  if (bookFilter !== 'all') {
    list = list.filter((w) => w.book.includes(bookFilter) || w.source.includes(bookFilter));
  }

  const normalized = normalizeArabicForSearch(query || '');
  if (!normalized) {
    return list;
  }

  return list.filter((w) => {
    const corpus = normalizeArabicForSearch(
      [
        w.title,
        w.subtopic,
        w.text,
        w.source,
        w.book,
        w.narrator,
        w.hadith_number,
        w.grade,
        w.explanation,
        ...w.lessons,
      ].join(' ')
    );
    return corpus.includes(normalized);
  });
}

export function getDailyWasiyaFromStorage(): WasiyaItem & { isFavorite: boolean } {
  const all = loadWasayaFromStorage();
  const now = new Date();
  const startOfYear = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - startOfYear.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
  return all[dayOfYear % all.length] || all[0];
}

export function getWasayaSqliteStats() {
  const tables = initWasayaSqliteTables();
  return {
    categoriesCount: tables.categories.length,
    wasayaCount: tables.wasaya.length,
    favoritesCount: tables.favorites.length,
    ddlSchema: WASAYA_SQLITE_DDL_SCHEMA,
  };
}
