import { TareekhunaEvent, TareekhunaEra, TAREEKHUNA_EVENTS } from '../data/tareekhunaData';

const FAVORITES_STORAGE_KEY = 'rifq_tareekhuna_favorites_v1';
const READ_STORAGE_KEY = 'rifq_tareekhuna_read_v1';

export interface TareekhunaQuizQuestion {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
  era: TareekhunaEra;
  badge: string;
}

export function getSavedHistoryIds(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function isHistoryIdSaved(id: string): boolean {
  const list = getSavedHistoryIds();
  return list.includes(id);
}

export function toggleSavedHistoryId(id: string): boolean {
  try {
    const current = getSavedHistoryIds();
    const index = current.indexOf(id);
    let updated: string[];
    let isSaved: boolean;
    if (index >= 0) {
      updated = current.filter((x) => x !== id);
      isSaved = false;
    } else {
      updated = [...current, id];
      isSaved = true;
    }
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('rifq-tareekhuna-favorites-changed', { detail: { id, isSaved } }));
    return isSaved;
  } catch {
    return false;
  }
}

export function getReadHistoryIds(): string[] {
  try {
    const raw = localStorage.getItem(READ_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function markHistoryAsRead(id: string): void {
  try {
    const current = getReadHistoryIds();
    if (!current.includes(id)) {
      current.push(id);
      localStorage.setItem(READ_STORAGE_KEY, JSON.stringify(current));
    }
  } catch {
    // ignore
  }
}

export function getTodayHistoryEvents(
  day: number,
  month: number,
  events: TareekhunaEvent[] = TAREEKHUNA_EVENTS
): TareekhunaEvent[] {
  // 1. Exact match on day and month
  const exact = events.filter((e) => e.hijriDay === day && e.hijriMonth === month);
  if (exact.length > 0) return exact;

  // 2. Fallback to events in the current month
  const inMonth = events.filter((e) => e.hijriMonth === month);
  if (inMonth.length > 0) return inMonth.slice(0, 3);

  // 3. Fallback to featured
  return events.filter((e) => e.featured).slice(0, 3);
}

export function formatHistoryShareText(event: TareekhunaEvent): string {
  const figures = event.keyFigures?.length ? `\n👤 أبرز الشخصيات: ${event.keyFigures.join('، ')}` : '';
  const lessons = event.lessons?.length ? `\n\n💡 من الدروس والعِبر:\n${event.lessons.map((l) => `• ${l}`).join('\n')}` : '';
  const refs = event.references ? `\n\n📚 المصدر: ${event.references}` : '';

  return `📜 من تاريخنا الإسلامي العظيم | تطبيق رِفْق
━━━━━━━━━━━━━━━━━━━━
📌 ${event.title}
🗓️ التاريخ: ${event.hijriDay} من الشهر ${event.hijriMonth} (${event.hijriYear} / ${event.gregorianYear})
📍 المكان: ${event.location}
${figures}

📖 القصة والموجز:
${event.summary}

${event.fullStory}${lessons}${refs}
━━━━━━━━━━━━━━━━━━━━
🌱 تطبيق رِفْق — رفيقك اليومي للذكر والتاريخ والعبادة`;
}

export const TAREEKHUNA_QUIZ_QUESTIONS: TareekhunaQuizQuestion[] = [
  {
    id: 'quiz-1',
    question: 'في أي سنة هجرية وقعت غزوة بدر الكبرى الملقبة بـ «يوم الفرقان»؟',
    options: ['السنة الأولى للهجرة', 'السنة الثانية للهجرة (17 رمضان)', 'السنة الثالثة للهجرة', 'السنة الخامسة للهجرة'],
    correctIndex: 1,
    explanation: 'وقعت غزوة بدر الكبرى في 17 رمضان من السنة الثانية للهجرة، وكانت أول معركة فاصلة أعز الله بها الإسلام والمسلمين.',
    era: 'prophetic',
    badge: 'غزوات فاصلة',
  },
  {
    id: 'quiz-2',
    question: 'من هو الصحابي الذي أشار على الفاروق عمر باعتماد الهجرة النبوية بداية للتاريخ الإسلامي؟',
    options: ['عثمان بن عفان', 'علي بن أبي طالب رضي الله عنه', 'أبو بكر الصديق', 'سعد بن أبي وقاص'],
    correctIndex: 1,
    explanation: 'أشار الإمام علي بن أبي طالب رضي الله عنه على عمر بن الخطاب بالهجرة لأنها فرّقت بين الحق والباطل، فاستحسن عمر والصحابة ذلك.',
    era: 'rashidun',
    badge: 'التقويم الهجري',
  },
  {
    id: 'quiz-3',
    question: 'قائد معركة القادسية التي فُتحت بعدها بلاد العراق وفارس هو الصحابي الجليل:',
    options: ['خالد بن الوليد', 'سعد بن أبي وقاص رضي الله عنه', 'أبو عبيدة بن الجراح', 'عمرو بن العاص'],
    correctIndex: 1,
    explanation: 'سعد بن أبي وقاص خال النبي ﷺ قاد جيش المسلمين في القادسية عام 15 هـ محققاً نصراً تاريخياً كسر شوكة الإمبراطورية الفارسية.',
    era: 'rashidun',
    badge: 'معارك كبرى',
  },
  {
    id: 'quiz-4',
    question: 'من هي المرأة الصالحة التي أنشأت جامع وجامعة القرويين بفاس كأقدم جامعة مستمرة في العالم؟',
    options: ['شجرة الدر', 'زبيدة بنت جعفر', 'فاطمة الفهرية (أم البنين)', 'رفيدة الأسلمية'],
    correctIndex: 2,
    explanation: 'السيدة فاطمة بنت محمد الفهرية القرشية شيدت جامع وجامعة القرويين بفاس عام 245 هـ (859 م) من مالها كاملاً ابتغاء مرضاة الله.',
    era: 'andalus_maghreb',
    badge: 'عمارة وحضارة',
  },
  {
    id: 'quiz-5',
    question: 'في أي معركة تاريخية تم تحرير القدس الشريف عام 583 هـ على يد صلاح الدين الأيوبي؟',
    options: ['معركة حطين', 'معركة عين جالوت', 'معركة اليرموك', 'معركة الزلاقة'],
    correctIndex: 0,
    explanation: 'معركة حطين الشهيرة (24 ربيع الثاني 583 هـ) انتصر فيها السلطان الناصر صلاح الدين وطهّر المسجد الأقصى والقدس من الاحتلال الصليبي.',
    era: 'abbasid',
    badge: 'تحرير القدس',
  },
  {
    id: 'quiz-6',
    question: 'القائد الشاب الذي فتح القسطنطينية عام 857 هـ (1453 م) وحقق بشارة النبي ﷺ هو:',
    options: ['سليمان القانوني', 'محمد الفاتح (السلطان محمد الثاني)', 'سليم الأول', 'بايزيد الأول'],
    correctIndex: 1,
    explanation: 'السلطان العثماني محمد الفاتح فتح القسطنطينية وعمره 21 عاماً، متحققةً فيه بشارة النبي ﷺ: «لتفتحن القسطنطينية فلنعم الأمير أميرها ولنعم الجيش ذلك الجيش».',
    era: 'civilization_science',
    badge: 'بشارة نبوية',
  },
  {
    id: 'quiz-7',
    question: 'من هو القائد المسلم الذي أوقف زحف المغول التتار وهزمهم في معركة عين جالوت عام 658 هـ؟',
    options: ['سيف الدين قطز والظاهر بيبرس', 'صلاح الدين الأيوبي', 'نور الدين زنكي', 'ألب أرسلان'],
    correctIndex: 0,
    explanation: 'السلطان المظفر سيف الدين قطز وبجانبه ركن الدين بيبرس خاضا معركة عين جالوت في 25 رمضان 658 هـ وصرخ صيحته الشهيرة «واإسلاماه»، فكسر أسطورة الجيش المغولي الذي لا يُقهر.',
    era: 'abbasid',
    badge: 'حماية الأمة',
  },
  {
    id: 'quiz-8',
    question: 'دار الحكمة، الصرح العلمي العالمي الذي قاد العصر الذهبي للترجمة والعلوم، أُسس في مدينة:',
    options: ['دمشق', 'قرطبة', 'القاهرة', 'بغداد عاصمة الخلافة العباسية'],
    correctIndex: 3,
    explanation: 'تأسست دار الحكمة في بغداد في عهد هارون الرشيد وازدهرت مع المأمون، وكانت مركزاً رائداً عالمياً للترجمة والعلوم والفلك والرياضيات.',
    era: 'abbasid',
    badge: 'النهضة العلمية',
  },
  {
    id: 'quiz-9',
    question: 'من صاحب كتاب «الرسالة» الذي أسس أول علم منهجي لأصول الفقه في تاريخ الإسلام؟',
    options: ['الإمام أبو حنيفة النعمان', 'الإمام مالك بن أنس', 'الإمام محمد بن إدريس الشافعي', 'الإمام أحمد بن حنبل'],
    correctIndex: 2,
    explanation: 'الإمام الشافعي ألف كتاب «الرسالة» ووضع فيه الضوابط المنهجية لاستنباط الأحكام الشرعية وقواعد الجمع بين النصوص والقياس.',
    era: 'abbasid',
    badge: 'أعلام الفقه',
  },
  {
    id: 'quiz-10',
    question: 'أي معركة تاريخية ثبّتت الوجود الإسلامي في الأندلس لأكثر من ثلاثة قرون بقيادة يوسف بن تاشفين؟',
    options: ['معركة الزلاقة (479 هـ)', 'معركة بلاط الشهداء', 'معركة الأرك', 'معركة العقاب'],
    correctIndex: 0,
    explanation: 'معركة الزلاقة في 12 رجب 479 هـ قادها أمير المسلمين يوسف بن تاشفين قائد المرابطين بطلب من ملوك الطوائف، فهزم ألفونسو السادس وحمى الأندلس.',
    era: 'andalus_maghreb',
    badge: 'تاريخ الأندلس',
  },
];
