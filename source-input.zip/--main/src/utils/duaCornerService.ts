import { DuaItem, DEFAULT_DUA_ITEMS, DuaCategory } from '../data/duaCornerData';

const CUSTOM_DUAS_STORAGE_KEY = 'rifq_custom_duas_v1';
const DUA_FAVORITES_STORAGE_KEY = 'rifq_dua_favorites_v1';
const DUA_RECITED_COUNTS_KEY = 'rifq_dua_recited_counts_v1';

export function getCustomDuas(): DuaItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_DUAS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveCustomDua(dua: Omit<DuaItem, 'id' | 'isCustom' | 'createdAt'> & { id?: string }): DuaItem {
  const customDuas = getCustomDuas();
  const id = dua.id || `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const existingIdx = customDuas.findIndex((d) => d.id === id);

  const newDuaItem: DuaItem = {
    ...dua,
    id,
    isCustom: true,
    createdAt: new Date().toISOString(),
  };

  let updated: DuaItem[];
  if (existingIdx >= 0) {
    updated = [...customDuas];
    updated[existingIdx] = newDuaItem;
  } else {
    updated = [newDuaItem, ...customDuas];
  }

  localStorage.setItem(CUSTOM_DUAS_STORAGE_KEY, JSON.stringify(updated));
  window.dispatchEvent(new CustomEvent('rifq-custom-duas-changed', { detail: { id, item: newDuaItem } }));
  return newDuaItem;
}

export function deleteCustomDua(id: string): void {
  try {
    const current = getCustomDuas();
    const updated = current.filter((d) => d.id !== id);
    localStorage.setItem(CUSTOM_DUAS_STORAGE_KEY, JSON.stringify(updated));
    // also remove from favorites if was favorited
    removeDuaFavorite(id);
    window.dispatchEvent(new CustomEvent('rifq-custom-duas-changed', { detail: { id, deleted: true } }));
  } catch {
    // ignore
  }
}

export function getAllDuas(): DuaItem[] {
  const custom = getCustomDuas();
  return [...custom, ...DEFAULT_DUA_ITEMS];
}

export function getDuaFavorites(): string[] {
  try {
    const raw = localStorage.getItem(DUA_FAVORITES_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function isDuaFavorite(id: string): boolean {
  const list = getDuaFavorites();
  return list.includes(id);
}

export function toggleDuaFavorite(id: string): boolean {
  try {
    const current = getDuaFavorites();
    const idx = current.indexOf(id);
    let updated: string[];
    let isFav: boolean;
    if (idx >= 0) {
      updated = current.filter((x) => x !== id);
      isFav = false;
    } else {
      updated = [...current, id];
      isFav = true;
    }
    localStorage.setItem(DUA_FAVORITES_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent('rifq-dua-favorites-changed', { detail: { id, isFav } }));
    return isFav;
  } catch {
    return false;
  }
}

export function removeDuaFavorite(id: string): void {
  try {
    const current = getDuaFavorites();
    if (current.includes(id)) {
      const updated = current.filter((x) => x !== id);
      localStorage.setItem(DUA_FAVORITES_STORAGE_KEY, JSON.stringify(updated));
      window.dispatchEvent(new CustomEvent('rifq-dua-favorites-changed', { detail: { id, isFav: false } }));
    }
  } catch {
    // ignore
  }
}

export function getDuaRecitedCounts(): Record<string, number> {
  try {
    const raw = localStorage.getItem(DUA_RECITED_COUNTS_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function incrementDuaRecitedCount(id: string): number {
  try {
    const counts = getDuaRecitedCounts();
    const newCount = (counts[id] || 0) + 1;
    counts[id] = newCount;
    localStorage.setItem(DUA_RECITED_COUNTS_KEY, JSON.stringify(counts));
    return newCount;
  } catch {
    return 1;
  }
}

export function formatDuaShareText(dua: DuaItem): string {
  const virtueText = dua.virtue ? `\n💡 الفضل والمناسبة: ${dua.virtue}` : '';
  const sourceText = dua.source ? `\n📖 المصدر: ${dua.source}` : '';

  return `🤲 دعاء مبارك | تطبيق رِفْق
━━━━━━━━━━━━━━━━━━━━
📌 ${dua.title}

« ${dua.arabic} »
${sourceText}${virtueText}
━━━━━━━━━━━━━━━━━━━━
🌱 تطبيق رِفْق — ركن الدعاء والمناجاة`;
}
