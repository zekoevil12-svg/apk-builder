import { registerPlugin, Capacitor, PluginListenerHandle } from '@capacitor/core';
import { WidgetType, WidgetSize, WidgetTheme } from '../types';
import {
  loadHistory,
  getTodayRecord,
  recordTasbeehCount,
  calculateStreaks,
  calculateTotalLifetimeTasbeeh,
  loadSettings,
  loadCustomAthkar,
  getTodayDateString,
} from './storage';
import { getCurrentCity, getPrayerSettings } from './prayerScheduler';

export type WidgetTargetPrayer =
  | 'next'
  | 'fajr'
  | 'sunrise'
  | 'dhuhr'
  | 'asr'
  | 'maghrib'
  | 'isha';

export type WidgetStatsMode =
  | 'today_count'
  | 'streak'
  | 'lifetime'
  | 'completed_athkar';

export interface WidgetStudioConfig {
  type: WidgetType;
  size: WidgetSize;
  theme: WidgetTheme;
  customDhikr: string;
  targetPrayer: WidgetTargetPrayer;
  statsMode: WidgetStatsMode;
}

export interface InstalledNativeWidgetInstance {
  appWidgetId: number;
  providerType: WidgetType;
  type: WidgetType;
  size: WidgetSize | 'auto';
  effectiveSize: WidgetSize;
  theme: WidgetTheme;
  customDhikr: string;
  targetPrayer?: WidgetTargetPrayer;
  statsMode?: WidgetStatsMode;
}

export interface NativeWidgetsStatus {
  isNativeAndroid: boolean;
  supported: boolean;
  installedCount: number;
  instances: InstalledNativeWidgetInstance[];
  globalConfig?: {
    type: WidgetType;
    size: WidgetSize | 'auto';
    theme: WidgetTheme;
    customDhikr: string;
    targetPrayer: WidgetTargetPrayer;
    statsMode: WidgetStatsMode;
  };
}

export interface PinWidgetResult {
  isNativeAndroid: boolean;
  supported: boolean;
  requested: boolean;
  reason: string;
}

const WIDGET_STUDIO_STORAGE_KEY = 'rifq_widget_studio_config_v1';

export function loadSavedWidgetStudioConfig(): WidgetStudioConfig {
  const settings = loadSettings();
  const fallback: WidgetStudioConfig = {
    type: 'tasbeeh',
    size: 'medium',
    theme: 'navy',
    customDhikr: settings.rosaryDhikr || 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    targetPrayer: 'next',
    statsMode: 'today_count',
  };

  try {
    const raw = localStorage.getItem(WIDGET_STUDIO_STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return {
      type: ['tasbeeh', 'prayer', 'dhikr', 'multi'].includes(parsed.type)
        ? parsed.type
        : fallback.type,
      size: ['small', 'medium', 'large'].includes(parsed.size)
        ? parsed.size
        : fallback.size,
      theme: ['navy', 'gold', 'midnight', 'cream'].includes(parsed.theme)
        ? parsed.theme
        : fallback.theme,
      customDhikr:
        typeof parsed.customDhikr === 'string' && parsed.customDhikr.trim().length > 0
          ? parsed.customDhikr.trim()
          : fallback.customDhikr,
      targetPrayer: [
        'next',
        'fajr',
        'sunrise',
        'dhuhr',
        'asr',
        'maghrib',
        'isha',
      ].includes(parsed.targetPrayer)
        ? parsed.targetPrayer
        : fallback.targetPrayer,
      statsMode: [
        'today_count',
        'streak',
        'lifetime',
        'completed_athkar',
      ].includes(parsed.statsMode)
        ? parsed.statsMode
        : fallback.statsMode,
    };
  } catch {
    return fallback;
  }
}

export function saveLocalWidgetStudioConfig(config: WidgetStudioConfig): void {
  try {
    localStorage.setItem(WIDGET_STUDIO_STORAGE_KEY, JSON.stringify(config));
  } catch {
    // ignore
  }
}

interface RifqWidgetsPluginInterface {
  isRequestPinAppWidgetSupported(): Promise<{
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  getInstalledWidgetsStatus(): Promise<{
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  saveGlobalWidgetPreferences(options: {
    type: WidgetType;
    size: WidgetSize | 'auto';
    theme: WidgetTheme;
    dhikrText: string;
    targetPrayer: WidgetTargetPrayer;
    statsMode: WidgetStatsMode;
    applyToInstalled?: boolean;
  }): Promise<{
    saved: boolean;
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  openWidgetConfigActivity(options: {
    appWidgetId?: number;
    type?: WidgetType;
    size?: WidgetSize | 'auto';
    theme?: WidgetTheme;
    dhikrText?: string;
    targetPrayer?: WidgetTargetPrayer;
    statsMode?: WidgetStatsMode;
  }): Promise<{
    opened: boolean;
    error?: string;
  }>;
  requestPinWidget(options: {
    type: WidgetType;
    size: WidgetSize | 'auto';
    theme: WidgetTheme;
    dhikrText?: string;
    targetPrayer?: WidgetTargetPrayer;
    statsMode?: WidgetStatsMode;
  }): Promise<{
    supported: boolean;
    requested: boolean;
    reason: string;
  }>;
  syncWidgetState(payload: {
    uid: string;
    todayCount: number;
    dailyGoal: number;
    streakDays: number;
    lifetimeTotal: number;
    completedAthkarToday: number;
    activeDhikr: string;
    vibrationEnabled: boolean;
    cityNameAr: string;
    cityLat: number;
    cityLng: number;
    calcMethod: string;
    madhab: string;
    timeFormat: string;
    hijriAdjustment: number;
    manualOffsetsJson: string;
    customAthkarJson: string;
  }): Promise<{
    synced: boolean;
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  consumePendingWidgetIncrements(): Promise<{
    pendingDeltaCount: number;
    dhikrDeltasJson: string;
    dateStr: string;
    uid: string;
    lastNativeMutationAt: number;
    todayTotalCount: number;
  }>;
  updateInstanceConfig(options: {
    appWidgetId: number;
    type?: WidgetType;
    size?: WidgetSize | 'auto';
    theme?: WidgetTheme;
    dhikrText?: string;
    targetPrayer?: WidgetTargetPrayer;
    statsMode?: WidgetStatsMode;
  }): Promise<{
    updated: boolean;
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  refreshAllWidgets(): Promise<{
    refreshed: boolean;
    supported: boolean;
    installedCount: number;
    instances: InstalledNativeWidgetInstance[];
    globalConfig?: NativeWidgetsStatus['globalConfig'];
  }>;
  addListener(
    eventName:
      | 'rifqWidgetTasbeehIncremented'
      | 'rifqWidgetPinned'
      | 'rifqWidgetConfigSaved',
    listenerFunc: (data: any) => void
  ): Promise<PluginListenerHandle>;
}

const RegisteredRifqWidgets = registerPlugin<RifqWidgetsPluginInterface>('RifqWidgets');

function getNativeWidgetsPlugin(): RifqWidgetsPluginInterface | null {
  try {
    if (Capacitor.isNativePlatform()) {
      return RegisteredRifqWidgets;
    }
    const win = window as unknown as {
      Capacitor?: { Plugins?: { RifqWidgets?: RifqWidgetsPluginInterface } };
    };
    return win.Capacitor?.Plugins?.RifqWidgets || null;
  } catch {
    return null;
  }
}

export function isRunningOnNativeAndroidForWidgets(): boolean {
  try {
    return (
      (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') ||
      Boolean(getNativeWidgetsPlugin())
    );
  } catch {
    return false;
  }
}

function getActiveAccountUidFromStorage(): string {
  try {
    return localStorage.getItem('rifq_active_account_uid_v1') || 'guest';
  } catch {
    return 'guest';
  }
}

let isConsumingNativeIncrements = false;

/**
 * Atomically consumes any `+` Tasbeeh increments made on the Android Home Screen Widget
 * while RIFQ was closed or in the background, and records them into RIFQ's real history
 * (which automatically triggers Firebase Firestore sync if logged in).
 */
export async function consumePendingWidgetIncrementsFromNative(): Promise<number> {
  if (isConsumingNativeIncrements) return 0;
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) return 0;

  isConsumingNativeIncrements = true;
  try {
    const res = await plugin.consumePendingWidgetIncrements();
    const totalDelta = Number(res?.pendingDeltaCount || 0);
    if (totalDelta <= 0) {
      return 0;
    }

    const activeUid = getActiveAccountUidFromStorage();
    const deltaUid = res.uid || 'guest';
    if (deltaUid !== activeUid && deltaUid !== 'guest') {
      return 0;
    }

    const todayStr = getTodayDateString();
    if (res.dateStr && res.dateStr !== todayStr) {
      return 0;
    }

    let applied = 0;
    try {
      const dhikrMap = JSON.parse(res.dhikrDeltasJson || '{}') as Record<string, number>;
      const entries = Object.entries(dhikrMap);
      if (entries.length > 0) {
        for (const [dhikrText, count] of entries) {
          const num = Number(count || 0);
          if (num > 0) {
            recordTasbeehCount(dhikrText, num, false);
            applied += num;
          }
        }
      }
    } catch {
      // fallback below
    }

    if (applied < totalDelta) {
      const remainder = totalDelta - applied;
      const settings = loadSettings();
      recordTasbeehCount(
        settings.rosaryDhikr || 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
        remainder,
        false
      );
      applied += remainder;
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('storage'));
      window.dispatchEvent(
        new CustomEvent('rifq-widget-increments-merged', {
          detail: { addedCount: applied },
        })
      );
    }

    return applied;
  } catch {
    return 0;
  } finally {
    isConsumingNativeIncrements = false;
  }
}

/**
 * Synchronizes RIFQ's real local & Firebase-backed data (Tasbeeh counter, streak, goal,
 * active Dhikr, custom Athkar, city coordinates, prayer calculation method, madhab, and Hijri adjustment)
 * with the Native Android Home Screen Widgets (`SharedPreferences`).
 */
export async function syncWidgetStateWithNative(): Promise<NativeWidgetsStatus> {
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return {
      isNativeAndroid: false,
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }

  try {
    await consumePendingWidgetIncrementsFromNative();

    const uid = getActiveAccountUidFromStorage();
    const history = loadHistory();
    const todayRec = getTodayRecord(history);
    const streaks = calculateStreaks(history);
    const lifetimeTotal = calculateTotalLifetimeTasbeeh(history);
    const settings = loadSettings();
    const studioCfg = loadSavedWidgetStudioConfig();
    const city = getCurrentCity();
    const prayerSettings = getPrayerSettings();
    const customAthkar = loadCustomAthkar();

    const res = await plugin.syncWidgetState({
      uid,
      todayCount: todayRec.totalCount || 0,
      dailyGoal: settings.dailyGoal || 100,
      streakDays: streaks.currentStreak || 0,
      lifetimeTotal,
      completedAthkarToday: todayRec.completedAthkarCount || 0,
      activeDhikr:
        studioCfg.customDhikr ||
        settings.rosaryDhikr ||
        'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
      vibrationEnabled: settings.vibrationEnabled !== false,
      cityNameAr: city.nameAr || 'القاهرة',
      cityLat: city.latitude,
      cityLng: city.longitude,
      calcMethod: prayerSettings.method || 'Egyptian',
      madhab: prayerSettings.madhab || 'shafi',
      timeFormat: prayerSettings.timeFormat || '12h',
      hijriAdjustment: prayerSettings.hijriAdjustment || 0,
      manualOffsetsJson: JSON.stringify(prayerSettings.manualOffsets || {}),
      customAthkarJson: JSON.stringify(customAthkar || []),
    });

    return {
      isNativeAndroid: true,
      supported: Boolean(res?.supported),
      installedCount: Number(res?.installedCount || 0),
      instances: Array.isArray(res?.instances) ? res.instances : [],
      globalConfig: res?.globalConfig,
    };
  } catch {
    return {
      isNativeAndroid: isRunningOnNativeAndroidForWidgets(),
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }
}

/**
 * Persists the user's selected widget preferences (prayer, dhikr, stats mode, type, size, theme)
 * from the 'Widget Settings' page to both `localStorage` and Android Native `SharedPreferences`
 * so the `AppWidgetProvider`s immediately read and render them.
 */
export async function saveWidgetStudioConfigToPreferences(
  config: WidgetStudioConfig,
  applyToInstalled: boolean = true
): Promise<NativeWidgetsStatus> {
  saveLocalWidgetStudioConfig(config);

  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return {
      isNativeAndroid: false,
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }

  try {
    await syncWidgetStateWithNative();
    const res = await plugin.saveGlobalWidgetPreferences({
      type: config.type,
      size: config.size,
      theme: config.theme,
      dhikrText: config.customDhikr,
      targetPrayer: config.targetPrayer,
      statsMode: config.statsMode,
      applyToInstalled,
    });

    return {
      isNativeAndroid: true,
      supported: Boolean(res?.supported),
      installedCount: Number(res?.installedCount || 0),
      instances: Array.isArray(res?.instances) ? res.instances : [],
      globalConfig: res?.globalConfig,
    };
  } catch {
    return getInstalledNativeWidgetsStatus();
  }
}

/**
 * Opens the native Android `RifqWidgetConfigActivity` directly from the 'Widget Settings' page.
 */
export async function openNativeWidgetConfigActivity(options?: {
  appWidgetId?: number;
  config?: WidgetStudioConfig;
}): Promise<{ opened: boolean; error?: string }> {
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return { opened: false, error: 'NOT_ANDROID_NATIVE' };
  }

  const cfg = options?.config || loadSavedWidgetStudioConfig();
  try {
    await syncWidgetStateWithNative();
    return await plugin.openWidgetConfigActivity({
      appWidgetId: options?.appWidgetId,
      type: cfg.type,
      size: cfg.size,
      theme: cfg.theme,
      dhikrText: cfg.customDhikr,
      targetPrayer: cfg.targetPrayer,
      statsMode: cfg.statsMode,
    });
  } catch (e: any) {
    return { opened: false, error: e?.message || 'CONFIG_ACTIVITY_ERROR' };
  }
}

/**
 * Queries real Android `AppWidgetManager` for placed widget instances and `SharedPreferences` global config.
 */
export async function getInstalledNativeWidgetsStatus(): Promise<NativeWidgetsStatus> {
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return {
      isNativeAndroid: false,
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }

  try {
    const res = await plugin.getInstalledWidgetsStatus();
    return {
      isNativeAndroid: true,
      supported: Boolean(res?.supported),
      installedCount: Number(res?.installedCount || 0),
      instances: Array.isArray(res?.instances) ? res.instances : [],
      globalConfig: res?.globalConfig,
    };
  } catch {
    return {
      isNativeAndroid: isRunningOnNativeAndroidForWidgets(),
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }
}

/**
 * Requests the Android Launcher to pin a real Home Screen Widget via `AppWidgetManager.requestPinAppWidget()`.
 */
export async function requestPinNativeWidget(options: {
  type: WidgetType;
  size: WidgetSize | 'auto';
  theme: WidgetTheme;
  dhikrText?: string;
  targetPrayer?: WidgetTargetPrayer;
  statsMode?: WidgetStatsMode;
}): Promise<PinWidgetResult> {
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return {
      isNativeAndroid: false,
      supported: false,
      requested: false,
      reason: 'NOT_ANDROID_NATIVE',
    };
  }

  try {
    await syncWidgetStateWithNative();
    const res = await plugin.requestPinWidget(options);
    return {
      isNativeAndroid: true,
      supported: Boolean(res?.supported),
      requested: Boolean(res?.requested),
      reason: res?.reason || '',
    };
  } catch (e: any) {
    return {
      isNativeAndroid: true,
      supported: false,
      requested: false,
      reason: e?.message || 'PIN_ERROR',
    };
  }
}

/**
 * Updates an individual placed Home Screen Widget instance (`appWidgetId`) in `SharedPreferences`
 * without affecting other widgets.
 */
export async function updateNativeWidgetInstanceConfig(options: {
  appWidgetId: number;
  type?: WidgetType;
  size?: WidgetSize | 'auto';
  theme?: WidgetTheme;
  dhikrText?: string;
  targetPrayer?: WidgetTargetPrayer;
  statsMode?: WidgetStatsMode;
}): Promise<NativeWidgetsStatus> {
  const plugin = getNativeWidgetsPlugin();
  if (!plugin) {
    return {
      isNativeAndroid: false,
      supported: false,
      installedCount: 0,
      instances: [],
    };
  }

  try {
    const res = await plugin.updateInstanceConfig(options);
    return {
      isNativeAndroid: true,
      supported: Boolean(res?.supported),
      installedCount: Number(res?.installedCount || 0),
      instances: Array.isArray(res?.instances) ? res.instances : [],
      globalConfig: res?.globalConfig,
    };
  } catch {
    return getInstalledNativeWidgetsStatus();
  }
}

let bridgeInitialized = false;

/**
 * Initializes automatic two-way synchronization between RIFQ React App, Firebase Cloud Sync,
 * and Android Native Home Screen Widgets (`SharedPreferences`).
 */
export function initNativeWidgetsBridge(): void {
  if (bridgeInitialized || typeof window === 'undefined') return;
  bridgeInitialized = true;

  syncWidgetStateWithNative().catch(() => {});

  const handleDataChanged = () => {
    syncWidgetStateWithNative().catch(() => {});
  };

  const handleVisibilityOrFocus = () => {
    if (document.visibilityState === 'visible') {
      syncWidgetStateWithNative().catch(() => {});
    }
  };

  window.addEventListener('rifq-local-data-mutated', handleDataChanged);
  window.addEventListener('rifq-user-data-synced', handleDataChanged);
  window.addEventListener('focus', handleVisibilityOrFocus);
  document.addEventListener('visibilitychange', handleVisibilityOrFocus);

  const plugin = getNativeWidgetsPlugin();
  if (plugin) {
    plugin
      .addListener('rifqWidgetTasbeehIncremented', () => {
        consumePendingWidgetIncrementsFromNative().catch(() => {});
      })
      .catch(() => {});

    plugin
      .addListener('rifqWidgetPinned', (data) => {
        window.dispatchEvent(
          new CustomEvent('rifq-native-widget-pinned', { detail: data })
        );
        syncWidgetStateWithNative().catch(() => {});
      })
      .catch(() => {});

    plugin
      .addListener('rifqWidgetConfigSaved', (data) => {
        if (data) {
          const current = loadSavedWidgetStudioConfig();
          const updated: WidgetStudioConfig = {
            type: ['tasbeeh', 'prayer', 'dhikr', 'multi'].includes(data.type)
              ? data.type
              : current.type,
            size: ['small', 'medium', 'large'].includes(data.size)
              ? data.size
              : current.size,
            theme: ['navy', 'gold', 'midnight', 'cream'].includes(data.theme)
              ? data.theme
              : current.theme,
            customDhikr: data.customDhikr || current.customDhikr,
            targetPrayer: data.targetPrayer || current.targetPrayer,
            statsMode: data.statsMode || current.statsMode,
          };
          saveLocalWidgetStudioConfig(updated);
        }
        window.dispatchEvent(
          new CustomEvent('rifq-native-widget-config-saved', { detail: data })
        );
        syncWidgetStateWithNative().catch(() => {});
      })
      .catch(() => {});
  }
}
