import { db } from './firebase';
import {
  doc,
  getDoc,
  setDoc,
  deleteDoc,
  collection,
  getDocs,
  query,
  orderBy,
} from 'firebase/firestore';
import {
  SEERAH_ALL_CHAPTERS,
  SEERAH_PERIODS,
  SEERAH_FIGURES,
  SEERAH_PLACES,
  SEERAH_CANONICAL_SOURCES,
  SeerahChapter,
  SeerahFigure,
  SeerahPlace,
  SeerahFavoriteItem,
  SeerahFavoriteType,
  SeerahReadingProgress,
  SeerahSearchResult,
  SeerahPeriodId,
} from '../data/seerah';

const LOCAL_FAVORITES_KEY = 'rifq_seerah_favorites_v1';
const LOCAL_PROGRESS_KEY = 'rifq_seerah_reading_progress_v1';
const LOCAL_CHAPTERS_CACHE_KEY = 'rifq_seerah_cloud_chapters_cache_v1';

// Admin email authorized to manage Seerah content in Firestore
const ADMIN_EMAILS = ['mo.abdullah262007@gmail.com'];

export function isSeerahAdmin(email?: string | null): boolean {
  if (!email) return false;
  return ADMIN_EMAILS.includes(email.trim().toLowerCase());
}

// In-memory cache for lazy-loaded chapters
let memoryChaptersCache: SeerahChapter[] | null = null;
const chapterDetailCache = new Map<string, SeerahChapter>();

/**
 * Load chapters list (merges canonical scholarly encyclopedia with any Firestore admin additions/edits)
 */
export async function fetchSeerahChaptersList(includeDrafts = false): Promise<SeerahChapter[]> {
  if (memoryChaptersCache && !includeDrafts) {
    return memoryChaptersCache.filter((c) => c.status === 'published');
  }

  let cloudChapters: SeerahChapter[] = [];
  try {
    const q = query(collection(db, 'prophetic_biography_chapters'), orderBy('order', 'asc'));
    const snap = await getDocs(q);
    if (!snap.empty) {
      cloudChapters = snap.docs.map((d) => ({
        ...(d.data() as SeerahChapter),
        id: d.id,
      }));
      try {
        localStorage.setItem(LOCAL_CHAPTERS_CACHE_KEY, JSON.stringify(cloudChapters));
      } catch {
        // ignore quota
      }
    }
  } catch {
    try {
      const raw = localStorage.getItem(LOCAL_CHAPTERS_CACHE_KEY);
      if (raw) cloudChapters = JSON.parse(raw);
    } catch {
      // ignore
    }
  }

  const mergedMap = new Map<string, SeerahChapter>();
  for (const ch of SEERAH_ALL_CHAPTERS) {
    mergedMap.set(ch.id, ch);
  }
  for (const cCh of cloudChapters) {
    if (cCh && cCh.id && cCh.title) {
      mergedMap.set(cCh.id, cCh);
    }
  }

  const merged = Array.from(mergedMap.values()).sort((a, b) => a.order - b.order);
  memoryChaptersCache = merged;
  for (const ch of merged) {
    chapterDetailCache.set(ch.id, ch);
  }

  return includeDrafts ? merged : merged.filter((c) => c.status === 'published');
}

/**
 * Lazy-load a single chapter by ID with full sections and subsections
 */
export async function fetchSeerahChapterById(chapterId: string): Promise<SeerahChapter | null> {
  if (chapterDetailCache.has(chapterId)) {
    return chapterDetailCache.get(chapterId) || null;
  }

  const canonical = SEERAH_ALL_CHAPTERS.find((c) => c.id === chapterId);
  if (canonical) {
    chapterDetailCache.set(chapterId, canonical);
  }

  try {
    const ref = doc(db, 'prophetic_biography_chapters', chapterId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = { ...(snap.data() as SeerahChapter), id: snap.id };
      chapterDetailCache.set(chapterId, data);
      return data;
    }
  } catch {
    // Offline fallback uses canonical or cached chapter
  }

  return canonical || null;
}

export function getSeerahPeriods() {
  return SEERAH_PERIODS;
}

export function getSeerahFigures(): SeerahFigure[] {
  return SEERAH_FIGURES;
}

export function getSeerahPlaces(): SeerahPlace[] {
  return SEERAH_PLACES;
}

export function getSeerahSources() {
  return SEERAH_CANONICAL_SOURCES;
}

/**
 * Full-text search across all chapters, sections, subsections, verses, hadiths, figures, and places
 */
export function searchSeerahContent(
  rawQuery: string,
  chapters: SeerahChapter[] = SEERAH_ALL_CHAPTERS
): SeerahSearchResult[] {
  const q = rawQuery.trim();
  if (!q) return [];

  const normalize = (str: string) =>
    str
      .replace(/[\u064B-\u065F\u0670]/g, '') // strip harakat
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .toLowerCase();

  const normQuery = normalize(q);
  const results: SeerahSearchResult[] = [];

  // 1. Search Figures
  for (const fig of SEERAH_FIGURES) {
    const haystack = normalize(
      `${fig.name} ${fig.fullName} ${fig.titleOrKunya} ${fig.summary} ${fig.biographyParagraphs.join(' ')}`
    );
    if (haystack.includes(normQuery)) {
      results.push({
        id: `res_fig_${fig.id}`,
        type: 'figure',
        typeLabel: 'شخصية من السيرة',
        title: `${fig.name} (${fig.honorific})`,
        subtitle: fig.titleOrKunya,
        snippet: fig.summary,
        figureId: fig.id,
      });
    }
  }

  // 2. Search Places
  for (const plc of SEERAH_PLACES) {
    const haystack = normalize(
      `${plc.name} ${plc.modernLocation} ${plc.summary} ${plc.historicalSignificance.join(' ')}`
    );
    if (haystack.includes(normQuery)) {
      results.push({
        id: `res_plc_${plc.id}`,
        type: 'place',
        typeLabel: 'مكان ومعلم تاريخي',
        title: plc.name,
        subtitle: plc.modernLocation,
        snippet: plc.summary,
        placeId: plc.id,
      });
    }
  }

  // 3. Search Chapters, Sections, Subsections, Verses, and Hadiths
  for (const ch of chapters) {
    if (ch.status !== 'published') continue;

    if (
      normalize(`${ch.title} ${ch.subtitle} ${ch.summary} ${ch.periodTitle}`).includes(normQuery)
    ) {
      results.push({
        id: `res_ch_${ch.id}`,
        type: 'chapter',
        typeLabel: `فصل (${ch.hijriYear})`,
        title: ch.title,
        subtitle: ch.subtitle,
        snippet: ch.summary,
        chapterId: ch.id,
      });
    }

    for (const sec of ch.sections) {
      const secText = sec.paragraphs.join(' ');
      if (normalize(`${sec.title} ${sec.subtitle || ''} ${secText}`).includes(normQuery)) {
        results.push({
          id: `res_sec_${ch.id}_${sec.id}`,
          type: 'section',
          typeLabel: 'مبحث تفصيلي',
          title: sec.title,
          subtitle: ch.title,
          snippet: sec.paragraphs[0] || ch.summary,
          chapterId: ch.id,
          sectionId: sec.id,
        });
      }

      if (sec.subsections) {
        for (const sub of sec.subsections) {
          const subText = sub.paragraphs.join(' ');
          if (normalize(`${sub.title} ${subText}`).includes(normQuery)) {
            results.push({
              id: `res_sub_${ch.id}_${sub.id}`,
              type: 'subsection',
              typeLabel: 'فرع تفصيلي',
              title: sub.title,
              subtitle: `${ch.title} — ${sec.title}`,
              snippet: sub.paragraphs[0] || '',
              chapterId: ch.id,
              sectionId: sec.id,
            });
          }
        }
      }
    }

    for (const v of ch.verses) {
      if (normalize(`${v.surahName} ${v.text} ${v.contextNote || ''}`).includes(normQuery)) {
        results.push({
          id: `res_v_${ch.id}_${v.id}`,
          type: 'verse',
          typeLabel: `آية قرآنية (سورة ${v.surahName}: ${v.ayahNumbers})`,
          title: `سورة ${v.surahName} (${v.ayahNumbers})`,
          subtitle: ch.title,
          snippet: v.text,
          chapterId: ch.id,
        });
      }
    }

    for (const h of ch.hadiths) {
      if (normalize(`${h.text} ${h.source} ${h.narrator || ''}`).includes(normQuery)) {
        results.push({
          id: `res_h_${ch.id}_${h.id}`,
          type: 'hadith',
          typeLabel: `حديث نبوي (${h.source})`,
          title: `حديث شريف — ${h.source}`,
          subtitle: ch.title,
          snippet: h.text,
          chapterId: ch.id,
        });
      }
    }
  }

  return results.slice(0, 60);
}

/**
 * Favorites Management (Real Firestore linked to UID + LocalStorage cache)
 */
export async function loadSeerahFavorites(uid?: string | null): Promise<SeerahFavoriteItem[]> {
  let localFavs: SeerahFavoriteItem[] = [];
  try {
    const raw = localStorage.getItem(`${LOCAL_FAVORITES_KEY}_${uid || 'guest'}`);
    if (raw) localFavs = JSON.parse(raw);
  } catch {
    localFavs = [];
  }

  if (!uid) return localFavs;

  try {
    const colRef = collection(db, 'users', uid, 'prophetic_biography_favorites');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      const cloudFavs = snap.docs.map((d) => d.data() as SeerahFavoriteItem);
      const mergedMap = new Map<string, SeerahFavoriteItem>();
      for (const f of [...localFavs, ...cloudFavs]) {
        if (f?.id) mergedMap.set(f.id, f);
      }
      const merged = Array.from(mergedMap.values()).sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      );
      localStorage.setItem(`${LOCAL_FAVORITES_KEY}_${uid}`, JSON.stringify(merged));
      return merged;
    }
  } catch {
    // Return localFavs if offline
  }

  return localFavs;
}

export async function toggleSeerahFavorite(
  uid: string | null | undefined,
  item: {
    type: SeerahFavoriteType;
    targetId: string;
    chapterId?: string;
    title: string;
    subtitle: string;
    periodTitle?: string;
  }
): Promise<{ favorites: SeerahFavoriteItem[]; isAdded: boolean }> {
  const favId = `${item.type}_${item.targetId}`;
  const current = await loadSeerahFavorites(uid);
  const exists = current.some((f) => f.id === favId);

  let updated: SeerahFavoriteItem[];
  if (exists) {
    updated = current.filter((f) => f.id !== favId);
  } else {
    const newFav: SeerahFavoriteItem = {
      id: favId,
      userId: uid || 'guest',
      type: item.type,
      targetId: item.targetId,
      chapterId: item.chapterId,
      title: item.title,
      subtitle: item.subtitle,
      periodTitle: item.periodTitle,
      createdAt: new Date().toISOString(),
    };
    updated = [newFav, ...current];
  }

  try {
    localStorage.setItem(`${LOCAL_FAVORITES_KEY}_${uid || 'guest'}`, JSON.stringify(updated));
  } catch {
    // ignore
  }

  if (uid) {
    try {
      const userFavDoc = doc(db, 'users', uid, 'prophetic_biography_favorites', favId);
      const rootFavDoc = doc(db, 'prophetic_biography_favorites', `${uid}_${favId}`);
      if (exists) {
        await deleteDoc(userFavDoc);
        await deleteDoc(rootFavDoc).catch(() => {});
      } else {
        const favObj = updated[0];
        await setDoc(userFavDoc, favObj);
        await setDoc(rootFavDoc, favObj).catch(() => {});
      }
    } catch {
      // Offline mode: local storage is already updated
    }
  }

  return { favorites: updated, isAdded: !exists };
}

/**
 * Reading Progress Management ("تابع من حيث توقفت")
 */
export async function loadSeerahReadingProgress(
  uid?: string | null
): Promise<SeerahReadingProgress | null> {
  let localProg: SeerahReadingProgress | null = null;
  try {
    const raw = localStorage.getItem(`${LOCAL_PROGRESS_KEY}_${uid || 'guest'}`);
    if (raw) localProg = JSON.parse(raw);
  } catch {
    localProg = null;
  }

  if (!uid) return localProg;

  try {
    const userProgRef = doc(db, 'users', uid, 'prophetic_biography_progress', 'current');
    const snap = await getDoc(userProgRef);
    if (snap.exists()) {
      const cloudProg = snap.data() as SeerahReadingProgress;
      if (
        !localProg ||
        new Date(cloudProg.updatedAt).getTime() >= new Date(localProg.updatedAt).getTime()
      ) {
        localStorage.setItem(`${LOCAL_PROGRESS_KEY}_${uid}`, JSON.stringify(cloudProg));
        return cloudProg;
      }
    }
  } catch {
    // Offline fallback
  }

  return localProg;
}

export async function saveSeerahReadingProgress(
  uid: string | null | undefined,
  update: {
    lastChapterId: string;
    lastChapterTitle: string;
    lastSectionId?: string;
    lastSectionTitle?: string;
    scrollPercent?: number;
    markChapterCompleted?: boolean;
  }
): Promise<SeerahReadingProgress> {
  const existing = await loadSeerahReadingProgress(uid);
  const completedSet = new Set<string>(existing?.completedChapterIds || []);
  if (update.markChapterCompleted) {
    completedSet.add(update.lastChapterId);
  }

  const nextProgress: SeerahReadingProgress = {
    userId: uid || 'guest',
    lastChapterId: update.lastChapterId,
    lastChapterTitle: update.lastChapterTitle,
    lastSectionId: update.lastSectionId ?? existing?.lastSectionId ?? '',
    lastSectionTitle: update.lastSectionTitle ?? existing?.lastSectionTitle ?? '',
    scrollPercent: update.scrollPercent ?? existing?.scrollPercent ?? 0,
    completedChapterIds: Array.from(completedSet),
    updatedAt: new Date().toISOString(),
  };

  try {
    localStorage.setItem(`${LOCAL_PROGRESS_KEY}_${uid || 'guest'}`, JSON.stringify(nextProgress));
  } catch {
    // ignore
  }

  if (uid) {
    try {
      const userProgRef = doc(db, 'users', uid, 'prophetic_biography_progress', 'current');
      const rootProgRef = doc(db, 'prophetic_biography_progress', uid);
      await setDoc(userProgRef, nextProgress, { merge: true });
      await setDoc(rootProgRef, nextProgress, { merge: true }).catch(() => {});
    } catch {
      // Offline fallback
    }
  }

  return nextProgress;
}

/**
 * Admin-only functions to save/update/delete chapters in Firestore
 */
export async function adminSaveSeerahChapter(
  chapter: SeerahChapter
): Promise<{ success: boolean; message: string }> {
  try {
    const updated: SeerahChapter = {
      ...chapter,
      updatedAt: new Date().toISOString(),
    };
    const ref = doc(db, 'prophetic_biography_chapters', chapter.id);
    await setDoc(ref, updated, { merge: true });
    memoryChaptersCache = null;
    chapterDetailCache.set(chapter.id, updated);
    return { success: true, message: 'تم حفظ الفصل في قاعدة بيانات السيرة النبوية بنجاح' };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'تعذر حفظ الفصل في Firestore (تحقق من صلاحيات المشرف)',
    };
  }
}

export async function adminDeleteSeerahChapter(
  chapterId: string
): Promise<{ success: boolean; message: string }> {
  try {
    const ref = doc(db, 'prophetic_biography_chapters', chapterId);
    await deleteDoc(ref);
    memoryChaptersCache = null;
    chapterDetailCache.delete(chapterId);
    return { success: true, message: 'تم حذف الفصل من Firestore بنجاح' };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'تعذر حذف الفصل',
    };
  }
}

export async function adminSyncAllCanonicalChaptersToFirestore(): Promise<{
  success: boolean;
  message: string;
}> {
  try {
    for (const ch of SEERAH_ALL_CHAPTERS) {
      const ref = doc(db, 'prophetic_biography_chapters', ch.id);
      await setDoc(ref, ch, { merge: true });
    }
    for (const fig of SEERAH_FIGURES) {
      const ref = doc(db, 'prophetic_biography_figures', fig.id);
      await setDoc(ref, fig, { merge: true });
    }
    for (const plc of SEERAH_PLACES) {
      const ref = doc(db, 'prophetic_biography_places', plc.id);
      await setDoc(ref, plc, { merge: true });
    }
    for (const src of SEERAH_CANONICAL_SOURCES) {
      const ref = doc(db, 'prophetic_biography_sources', src.id);
      await setDoc(ref, src, { merge: true });
    }
    memoryChaptersCache = null;
    return {
      success: true,
      message: 'تمت مزامنة الفصول الـ 24 والشخصيات والأماكن والمصادر إلى Firestore بنجاح ✅',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'تعذرت المزامنة مع Firestore',
    };
  }
}
