// System Permissions Manager for "رِفْق | RIFQ"
// Real 100% Native OS & Browser Permissions System
// Supports Web, PWA, Android, iOS & Flutter bridges

import {
  NotificationManager,
  sendTestNotification,
  openSystemNotificationSettings,
  isNativeAndroidPlatform,
} from './notifications';

export type PermissionKey = 
  | 'location' 
  | 'notifications' 
  | 'microphone' 
  | 'storage' 
  | 'camera' 
  | 'contacts' 
  | 'biometric' 
  | 'calendar';

export type PermissionStatus = 
  | 'granted' 
  | 'denied' 
  | 'restricted' 
  | 'limited' 
  | 'permanentlyDenied' 
  | 'provisional' 
  | 'prompt' 
  | 'not_requested';

export interface PermissionRecord {
  status: PermissionStatus;
  lastPromptedAt?: number;
  grantedAt?: number;
  deniedCount?: number;
}

export interface NotificationPreferences {
  adhan: boolean;
  athkar: boolean;
  hadithOfTheDay: boolean;
  dailyChallenge: boolean;
}

export interface PermissionDefinition {
  key: PermissionKey;
  titleAr: string;
  shortDescAr: string;
  detailedReasonAr: string;
  icon: string;
  isMandatoryForCoreFeatures: boolean;
  iosPlistKey: string;
  iosUsageDescription: string;
  androidPermissionKey: string;
  androidVersionNotes?: string;
  badgeText: string;
  fallbackTextAr: string;
}

export const PERMISSIONS_CONFIG: Record<PermissionKey, PermissionDefinition> = {
  location: {
    key: 'location',
    titleAr: 'الوصول إلى الموقع الجغرافي',
    shortDescAr: 'لتحديد مواقيت الصلاة بدقة في مدينتك وتحديد اتجاه القبلة الصحيح',
    detailedReasonAr: 'نستخدم إحداثيات موقعك الجغرافي عند استخدام التطبيق فقط (When In Use) لحساب زوايا الشمس بدقة متناهية وفق أدق المعادلات الفلكية المعتمدة، وتوجيه بوصلة القبلة نحو الكعبة المشرفة في مكة المكرمة. لا نقوم بتتبع موقعك في الخلفية مطلقاً.',
    icon: 'compass',
    isMandatoryForCoreFeatures: true,
    iosPlistKey: 'NSLocationWhenInUseUsageDescription',
    iosUsageDescription: 'نحتاج موقعك لعرض مواقيت الصلاة بدقة وتحديد اتجاه القبلة',
    androidPermissionKey: 'android.permission.ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION',
    androidVersionNotes: 'Foreground only (When In Use)',
    badgeText: 'مواقيت الصلاة والقبلة',
    fallbackTextAr: 'يمكنك إدخال اسم مدينتك يدوياً دون الحاجة لتحديد الموقع التلقائي.'
  },
  notifications: {
    key: 'notifications',
    titleAr: 'تفعيل إشعارات الأذان والأذكار',
    shortDescAr: 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.',
    detailedReasonAr: 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة في شريط إشعارات الجهاز ومركز التذكيرات داخل التطبيق. يمكنك تخصيص أو إيقاف أي قناة إشعارات في أي وقت من الإعدادات.',
    icon: 'bell',
    isMandatoryForCoreFeatures: true,
    iosPlistKey: 'NSUserNotificationUsageDescription',
    iosUsageDescription: 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.',
    androidPermissionKey: 'android.permission.POST_NOTIFICATIONS',
    androidVersionNotes: 'إلزامي في Android 13+ (API 33)',
    badgeText: 'الأذان والأذكار',
    fallbackTextAr: 'إشعارات الجهاز متوقفة — يمكنك الضغط على «السماح بالإشعارات» لفتح إعدادات التطبيق وتفعيلها.'
  },
  microphone: {
    key: 'microphone',
    titleAr: 'الميكروفون للتسبيح الصوتي',
    shortDescAr: 'لتسبيح الأذكار بصوتك. صوتك لا يُسجَّل ولا يُرسَل لأي جهة',
    detailedReasonAr: 'يسمح ميكروفون الجهاز بالتعرف الصوتي على أذكارك المباركة وزيادة العداد تلقائياً دون لمس الشاشة. المعالجة تتم محلياً بنسبة 100% داخل جهازك ولا يتم تسجيل أو تخزين أو مشاركة أي مقطع صوتي على الإطلاق.',
    icon: 'mic',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'NSMicrophoneUsageDescription',
    iosUsageDescription: 'نحتاج الميكروفون للتسبيح الصوتي، صوتك لا يُسجَّل',
    androidPermissionKey: 'android.permission.RECORD_AUDIO',
    badgeText: 'تسبيح ذكي بدون لمس',
    fallbackTextAr: 'يمكنك استخدام المسبحة المركزية اللمسية بالكامل بدون ميكروفون.'
  },
  storage: {
    key: 'storage',
    titleAr: 'تخزين الصوتيات والملفات (Offline)',
    shortDescAr: 'لتحميل القرآن والأذان والاستماع بدون إنترنت',
    detailedReasonAr: 'يتيح للتطبيق حفظ تلاوات القرآن الكريم الكاملة بصوت مشاهير القراء وأصوات الأذان المختلفة محلياً في الذاكرة المؤقتة لجهازك لتعمل في أي وقت دون الحاجة لاتصال إنترنت.',
    icon: 'download',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'App Cache / Document Storage',
    iosUsageDescription: 'لحفظ المقاطع الصوتية المصرح بها للاستماع دون اتصال',
    androidPermissionKey: 'android.permission.READ_MEDIA_AUDIO / WRITE_EXTERNAL_STORAGE',
    androidVersionNotes: 'Android 13+ يقتصر على الملفات الصوتية فقط',
    badgeText: 'الاستماع بدون إنترنت',
    fallbackTextAr: 'يعمل التطبيق مع التلاوات المباشرة عبر الإنترنت دون تخزين دائم.'
  },
  camera: {
    key: 'camera',
    titleAr: 'الكاميرا',
    shortDescAr: 'لإضافة صورة بروفايل ومسح رموز QR',
    detailedReasonAr: 'تُستخدم الكاميرا فقط عند رغبتك بالتقاط صورة شخصية للملف التعريفي أو مسح رمز QR لمشاركة قائمة أذكار أو حلقة تسبيح مع أصدقائك. لا تُفتح الكاميرا إلا بطلب مباشر منك.',
    icon: 'camera',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'NSCameraUsageDescription',
    iosUsageDescription: 'لإضافة صورة بروفايل ومسح رموز QR',
    androidPermissionKey: 'android.permission.CAMERA',
    badgeText: 'عند الحاجة الفعلية فقط',
    fallbackTextAr: 'يمكنك اختيار أيقونة رمزية للملف الشخصي دون استخدام الكاميرا.'
  },
  contacts: {
    key: 'contacts',
    titleAr: 'جهات الاتصال',
    shortDescAr: 'لدعوة أصدقائك للتطبيق ومشاركة الأجر',
    detailedReasonAr: 'تُطلب فقط وبشكل حصري عند الضغط على زر "دعوة صديق" أو "مشاركة الورد"، لمساعدتك في اختيار صديق من دفتر هاتفك لإرسال رسالة الدعوة. لا يتم تحميل أو رفع أي جهة اتصال لأي خادم.',
    icon: 'users',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'NSContactsUsageDescription',
    iosUsageDescription: 'لدعوة أصدقائك للتطبيق',
    androidPermissionKey: 'android.permission.READ_CONTACTS',
    badgeText: 'عند دعوة صديق فقط',
    fallbackTextAr: 'يمكنك نسخ رابط التطبيق ومشاركته يدوياً عبر أي تطبيق تفضله.'
  },
  biometric: {
    key: 'biometric',
    titleAr: 'البصمة والوجه (Biometric)',
    shortDescAr: 'لحماية التطبيق وقفل الأذكار الخاصة والورد',
    detailedReasonAr: 'تُستخدم البصمة أو ميزة التعرف على الوجه كطبقة أمان اختيارية إضافية لفتح التطبيق أو الدخول إلى صفحة أذكاري الخاصة ومذكراتي الروحية.',
    icon: 'fingerprint',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'NSFaceIDUsageDescription',
    iosUsageDescription: 'لحماية التطبيق بالبصمة أو التعرف على الوجه',
    androidPermissionKey: 'android.permission.USE_BIOMETRIC',
    badgeText: 'تفعيل من الإعدادات فقط',
    fallbackTextAr: 'يمكنك استخدام رمز المرور التقليدي (PIN) لحماية التطبيق.'
  },
  calendar: {
    key: 'calendar',
    titleAr: 'التقويم الإسلامي',
    shortDescAr: 'لإضافة المواقيت والمناسبات الإسلامية لتقويمك',
    detailedReasonAr: 'تمكنك من تصدير مواقيت الصلوات وتنبيهات صيام الأيام البيض، عاشوراء، وعرفة، والمناسبات الدينية الكبرى إلى تطبيق التقويم الأساسي بهاتفك.',
    icon: 'calendar',
    isMandatoryForCoreFeatures: false,
    iosPlistKey: 'NSCalendarsUsageDescription',
    iosUsageDescription: 'لإضافة المواقيت والمناسبات للتقويم',
    androidPermissionKey: 'android.permission.READ_CALENDAR / WRITE_CALENDAR',
    badgeText: 'إضافة المناسبات للتقويم',
    fallbackTextAr: 'المناسبات والتقويم الهجري متاحة بالكامل داخل التطبيق.'
  }
};

// SharedPreferences & localStorage keys required by Specification 【9】
export const PERMISSION_STORAGE_KEYS: Record<PermissionKey, string> = {
  location: 'location_permission_status',
  notifications: 'notification_permission_status',
  microphone: 'microphone_permission_status',
  storage: 'storage_permission_status',
  camera: 'camera_permission_status',
  contacts: 'contacts_permission_status',
  biometric: 'biometric_permission_status',
  calendar: 'calendar_permission_status'
};

const LEGACY_STORAGE_KEY = 'mushaba_permissions_state_v2';
const NOTIFICATION_PREFS_KEY = 'mushaba_notification_prefs_v1';
const HAS_SEEN_FLOW_KEY = 'mushaba_has_completed_permissions_flow_v2';
const APP_LANGUAGE_KEY = 'mushaba_selected_language_v1';

export const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * Reads individual permission status from storage (shared_preferences / localStorage)
 */
export function getSavedPermissionStatus(key: PermissionKey): PermissionStatus {
  try {
    const specificKey = PERMISSION_STORAGE_KEYS[key];
    const val = localStorage.getItem(specificKey);
    if (val && ['granted', 'denied', 'restricted', 'limited', 'permanentlyDenied', 'provisional', 'prompt', 'not_requested'].includes(val)) {
      return val as PermissionStatus;
    }
    const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacy) {
      const parsed = JSON.parse(legacy);
      if (parsed[key]?.status) return parsed[key].status;
    }
  } catch {
    // ignore
  }
  return 'not_requested';
}

/**
 * Loads all permissions states from persistent storage
 */
export function loadAllPermissionsState(): Record<PermissionKey, PermissionRecord> {
  const initial: Record<PermissionKey, PermissionRecord> = {
    location: { status: 'not_requested' },
    notifications: { status: 'not_requested' },
    microphone: { status: 'not_requested' },
    storage: { status: 'not_requested' },
    camera: { status: 'not_requested' },
    contacts: { status: 'not_requested' },
    biometric: { status: 'not_requested' },
    calendar: { status: 'not_requested' },
  };

  try {
    // 1. Read from specific keys
    (Object.keys(initial) as PermissionKey[]).forEach(k => {
      initial[k].status = getSavedPermissionStatus(k);
    });

    // 2. Supplement timestamps from legacy JSON if available
    const raw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      (Object.keys(initial) as PermissionKey[]).forEach(k => {
        if (parsed[k]) {
          initial[k].lastPromptedAt = parsed[k].lastPromptedAt;
          initial[k].grantedAt = parsed[k].grantedAt;
          initial[k].deniedCount = parsed[k].deniedCount;
        }
      });
    }
    return initial;
  } catch {
    return initial;
  }
}

/**
 * Saves permission state in both specific key and consolidated store
 */
export function savePermissionState(key: PermissionKey, status: PermissionStatus): void {
  try {
    // 1. Save to specific shared_preferences key (e.g. location_permission_status)
    const specificKey = PERMISSION_STORAGE_KEYS[key];
    localStorage.setItem(specificKey, status);

    // 2. Save to consolidated store
    const current = loadAllPermissionsState();
    const prev = current[key] || { status: 'not_requested' };
    const deniedCount = (status === 'denied' || status === 'permanentlyDenied') 
      ? (prev.deniedCount || 0) + 1 
      : (prev.deniedCount || 0);

    current[key] = {
      status,
      lastPromptedAt: Date.now(),
      grantedAt: status === 'granted' ? Date.now() : prev.grantedAt,
      deniedCount
    };

    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(current));

    // 3. Dispatch custom event for UI reactivity
    window.dispatchEvent(new CustomEvent('rifq_permission_changed', { detail: { key, status } }));
  } catch (e) {
    console.warn('Could not persist permission state:', e);
  }
}

/**
 * Checks real runtime permission status from the browser / OS environment
 */
export async function checkRealPermissionStatus(key: PermissionKey): Promise<PermissionStatus> {
  // If running inside Flutter WebView bridge
  if (typeof window !== 'undefined' && (window as unknown as { FlutterPermissionsChannel?: { postMessage: (msg: string) => void } }).FlutterPermissionsChannel) {
    // Flutter channel will report status
  }

  // Web / Browser runtime checks
  try {
    if (key === 'notifications') {
      const detailed = await NotificationManager.getDetailedStatus();
      if (detailed.granted) {
        savePermissionState('notifications', 'granted');
        return 'granted';
      }
      if (detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied') {
        savePermissionState('notifications', 'permanentlyDenied');
        return 'permanentlyDenied';
      }
      return 'prompt';
    }

    if (key === 'location') {
      if (!('geolocation' in navigator)) return 'denied';
      if (navigator.permissions && navigator.permissions.query) {
        try {
          const res = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
          if (res.state === 'granted') {
            savePermissionState('location', 'granted');
            return 'granted';
          }
          if (res.state === 'denied') {
            savePermissionState('location', 'permanentlyDenied');
            return 'permanentlyDenied';
          }
          return 'prompt';
        } catch {
          // fallback to stored state
        }
      }
    }

    if (key === 'microphone') {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return 'denied';
      if (navigator.permissions && navigator.permissions.query) {
        try {
          const res = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          if (res.state === 'granted') {
            savePermissionState('microphone', 'granted');
            return 'granted';
          }
          if (res.state === 'denied') {
            savePermissionState('microphone', 'permanentlyDenied');
            return 'permanentlyDenied';
          }
          return 'prompt';
        } catch {
          // fallback
        }
      }
    }

    if (key === 'storage') {
      if (navigator.storage && navigator.storage.persisted) {
        const isPersisted = await navigator.storage.persisted();
        if (isPersisted) {
          savePermissionState('storage', 'granted');
          return 'granted';
        }
      }
    }
  } catch (e) {
    console.debug('Error querying real permission:', e);
  }

  return getSavedPermissionStatus(key);
}

/**
 * Opens device/app system settings (openAppSettings)
 * If in Flutter bridge: communicates with Flutter openAppSettings()
 * If in browser: provides guided modal / instructions to unblock in browser/OS settings
 */
export function openAppSettings(key?: PermissionKey): {
  openedDirectly: boolean;
  instructions: { title: string; steps: string[] };
} {
  if (isNativeAndroidPlatform()) {
    openSystemNotificationSettings();
    return {
      openedDirectly: true,
      instructions: {
        title: 'فتح إعدادات إشعارات التطبيق في Android',
        steps: [
          'تم فتح صفحة إعدادات إشعارات تطبيق «رِفْق» في نظام Android.',
          'فعّل خيار «السماح بالإشعارات» (Allow notifications) ثم ارجع للتطبيق.',
        ],
      },
    };
  }

  // Check Flutter Bridge
  const win = window as unknown as { FlutterPermissionsChannel?: { postMessage: (msg: string) => void } };
  if (win.FlutterPermissionsChannel) {
    try {
      win.FlutterPermissionsChannel.postMessage(JSON.stringify({ action: 'openAppSettings', key }));
      return {
        openedDirectly: true,
        instructions: {
          title: 'فتح إعدادات التطبيق',
          steps: ['جاري فتح إعدادات التطبيق في هاتفك...', 'قم بتفعيل الإذن المطلوب ثم ارجع للتطبيق.']
        }
      };
    } catch {
      // fallback
    }
  }

  // Device-specific browser guidance
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);

  let steps: string[] = [];
  if (isIOS) {
    steps = [
      'افتح «إعدادات الهاتف» (Settings).',
      'انزل لأسفل واختر متصفحك (Safari أو Chrome).',
      'انقر على «الموقع» أو «الميكروفون» أو «الإشعارات» واختر «السماح» (Allow).',
      'أو انقر على أيقونة «aA» بجانب شريط العنوان في Safari واختر «إعدادات موقع الويب».'
    ];
  } else if (isAndroid) {
    steps = [
      'انقر على أيقونة القفل أو الضبط (🔒 أو ⚙️) الموجودة بجانب شريط عنوان المتصفح بالأعلى.',
      'اختر «أذونات الموقع» (Permissions).',
      'قم بتفعيل «الموقع» أو «الإشعارات» أو «الميكروفون».',
      'أعد تحميل الصفحة وسيعمل الإذن فوراً.'
    ];
  } else {
    steps = [
      'انقر على أيقونة القفل (🔒) أو الإعدادات في شريط العنوان بالمتصفح.',
      'قم بتغيير الإذن من «حظر» إلى «سماح».',
      'حدّث الصفحة لتفعيل الميزة مباشرة.'
    ];
  }

  return {
    openedDirectly: false,
    instructions: {
      title: 'كيفية تفعيل الإذن من إعدادات المتصفح والجهاز',
      steps
    }
  };
}

export function canPromptPermissionAgain(key: PermissionKey): boolean {
  const status = getSavedPermissionStatus(key);
  if (status === 'granted') return false;
  if (status === 'permanentlyDenied') return false; // Must use openAppSettings
  const state = loadAllPermissionsState()[key];
  if (!state || !state.lastPromptedAt) return true;
  const elapsed = Date.now() - state.lastPromptedAt;
  return elapsed >= SEVEN_DAYS_MS;
}

export function hasCompletedPermissionsFlow(): boolean {
  try {
    return localStorage.getItem(HAS_SEEN_FLOW_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setCompletedPermissionsFlow(): void {
  try {
    localStorage.setItem(HAS_SEEN_FLOW_KEY, 'true');
  } catch {
    // Ignored
  }
}

export function resetPermissionsFlowForTesting(): void {
  try {
    localStorage.removeItem(HAS_SEEN_FLOW_KEY);
    localStorage.removeItem(LEGACY_STORAGE_KEY);
    (Object.values(PERMISSION_STORAGE_KEYS)).forEach(k => {
      localStorage.removeItem(k);
    });
  } catch {
    // Ignored
  }
}

export function loadNotificationPreferences(): NotificationPreferences {
  const defaults: NotificationPreferences = {
    adhan: true,
    athkar: true,
    hadithOfTheDay: true,
    dailyChallenge: true
  };
  try {
    const raw = localStorage.getItem(NOTIFICATION_PREFS_KEY);
    return raw ? { ...defaults, ...JSON.parse(raw) } : defaults;
  } catch {
    return defaults;
  }
}

export function saveNotificationPreferences(prefs: Partial<NotificationPreferences>): void {
  const current = loadNotificationPreferences();
  const updated = { ...current, ...prefs };
  try {
    localStorage.setItem(NOTIFICATION_PREFS_KEY, JSON.stringify(updated));
  } catch {
    // Ignored
  }
}

export function loadAppLanguage(): string {
  try {
    return localStorage.getItem(APP_LANGUAGE_KEY) || 'ar';
  } catch {
    return 'ar';
  }
}

export function saveAppLanguage(lang: string): void {
  try {
    localStorage.setItem(APP_LANGUAGE_KEY, lang);
  } catch {
    // Ignored
  }
}

// =========================================================================
// REAL 100% OPERATING SYSTEM & BROWSER PERMISSION CALLERS WITH SYSTEM DIALOGS
// =========================================================================

/**
 * 1. REAL LOCATION PERMISSION CALLER
 * Triggers native system dialog: Permission.location.request() / navigator.geolocation.getCurrentPosition
 * When granted: Saves coords, updates prayer calculations, sets city.
 * When denied / permanentlyDenied: handles graceful fallback to manual city selection.
 */
export async function requestLocationPermission(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  coords?: { latitude: number; longitude: number; accuracy?: number };
  cityName?: string;
  error?: string;
  isPermanentlyDenied?: boolean;
}> {
  if (!('geolocation' in navigator)) {
    savePermissionState('location', 'denied');
    return { 
      status: 'denied', 
      granted: false, 
      error: 'المتصفح أو النظام لا يدعم خدمة تحديد المواقع GPS.' 
    };
  }

  // Query actual permissions API if available
  if (navigator.permissions && navigator.permissions.query) {
    try {
      const q = await navigator.permissions.query({ name: 'geolocation' as PermissionName });
      if (q.state === 'denied') {
        savePermissionState('location', 'permanentlyDenied');
        return {
          status: 'permanentlyDenied',
          granted: false,
          isPermanentlyDenied: true,
          error: 'تم حظر إذن الموقع نهائياً في إعدادات جهازك. يمكنك تفعيله من الإعدادات أو اختيار مدينتك يدوياً.'
        };
      }
    } catch {
      // continue
    }
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const coords = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy
        };

        // Save real coordinates into application storage
        try {
          const userCoords = {
            lat: coords.latitude,
            lng: coords.longitude,
            cityName: 'موقعي الحالي (GPS)',
            updatedAt: Date.now()
          };
          localStorage.setItem('mushaba_user_coords_v1', JSON.stringify(userCoords));

          // Also set city location structure for prayer calculator
          const detectedCity = {
            id: 'gps-current-detected',
            nameAr: 'موقعي الحالي',
            nameEn: 'Current Location',
            countryAr: 'إحداثيات GPS',
            countryEn: 'GPS Coordinates',
            latitude: coords.latitude,
            longitude: coords.longitude,
            regionCategory: 'world'
          };
          localStorage.setItem('rafiq_current_city', JSON.stringify(detectedCity));

          // Notify prayer times calculator of update
          window.dispatchEvent(new Event('storage'));
        } catch {
          // ignore
        }

        savePermissionState('location', 'granted');
        resolve({
          status: 'granted',
          granted: true,
          coords,
          cityName: 'موقعي الحالي'
        });
      },
      (err) => {
        let status: PermissionStatus = 'denied';
        let errorMsg = 'تعذر الوصول إلى موقعك الجغرافي.';
        let isPermanentlyDenied = false;

        if (err.code === 1) { // PERMISSION_DENIED
          // User clicked Deny or system blocked it
          status = 'permanentlyDenied';
          isPermanentlyDenied = true;
          errorMsg = 'تم رفض الإذن. لا تقلق، يمكنك تفعيله من الإعدادات أو اختيار مدينتك يدوياً بكل سهولة.';
        } else if (err.code === 2) { // POSITION_UNAVAILABLE
          status = 'denied';
          errorMsg = 'إشارة الـ GPS غير متوفرة حالياً. تأكد من تفعيل خدمة الموقع بالجهاز.';
        } else if (err.code === 3) { // TIMEOUT
          status = 'denied';
          errorMsg = 'انتهت مهلة طلب الموقع. يمكنك إعادة المحاولة.';
        }

        savePermissionState('location', status);
        resolve({
          status,
          granted: false,
          isPermanentlyDenied,
          error: errorMsg
        });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  });
}

/**
 * 2. REAL NOTIFICATION PERMISSION CALLER
 * Triggers native system dialog: Permission.notification.request() / Notification.requestPermission()
 * When granted: Fires a real test notification on the user's phone / screen!
 * When permanentlyDenied: Guides user to device settings.
 */
export async function requestNotificationPermissionNative(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  isPermanentlyDenied?: boolean;
  error?: string;
}> {
  try {
    const granted = await NotificationManager.requestPermission();
    if (granted) {
      savePermissionState('notifications', 'granted');
      await sendTestNotification();
      return { status: 'granted', granted: true };
    }

    const detailed = await NotificationManager.getDetailedStatus();
    const isPermDenied = Boolean(
      detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied'
    );
    const nextStatus: PermissionStatus = isPermDenied ? 'permanentlyDenied' : 'denied';
    savePermissionState('notifications', nextStatus);

    return {
      status: nextStatus,
      granted: false,
      isPermanentlyDenied: isPermDenied,
      error: 'إشعارات الجهاز متوقفة — اضغط على «السماح بالإشعارات» لفتح إعدادات التطبيق وتفعيلها.',
    };
  } catch (err) {
    savePermissionState('notifications', 'denied');
    return {
      status: 'denied',
      granted: false,
      error: (err as Error)?.message || 'إشعارات الجهاز متوقفة — تعذر طلب إذن الإشعارات.',
    };
  }
}

/**
 * 3. REAL MICROPHONE PERMISSION CALLER
 * Triggers native system dialog: Permission.microphone.request() / navigator.mediaDevices.getUserMedia
 * When granted: tests real audio stream input, then releases tracks.
 */
export async function requestMicrophonePermission(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  isPermanentlyDenied?: boolean;
  error?: string;
}> {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    savePermissionState('microphone', 'denied');
    return {
      status: 'denied',
      granted: false,
      error: 'المتصفح لا يدعم الوصول إلى الميكروفون'
    };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    // Validate that stream has active audio tracks
    const audioTracks = stream.getAudioTracks();
    const isActive = audioTracks.length > 0 && audioTracks[0].readyState === 'live';

    // Safely release hardware microphone immediately
    audioTracks.forEach(track => track.stop());

    if (isActive) {
      savePermissionState('microphone', 'granted');
      return { status: 'granted', granted: true };
    } else {
      savePermissionState('microphone', 'denied');
      return { status: 'denied', granted: false, error: 'تعذر تنشيط مسار الميكروفون' };
    }
  } catch (err: unknown) {
    const error = err as { name?: string; message?: string };
    const isPermanentlyDenied = error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError';
    const status: PermissionStatus = isPermanentlyDenied ? 'permanentlyDenied' : 'denied';

    savePermissionState('microphone', status);
    return {
      status,
      granted: false,
      isPermanentlyDenied,
      error: isPermanentlyDenied 
        ? 'تم رفض إذن الميكروفون من النظام. التطبيق يتيح لك التسبيح اليدوي المريح دائماً.'
        : 'تعذر تشغيل الميكروفون حالياً.'
    };
  }
}

/**
 * 4. REAL STORAGE PERMISSION CALLER
 * Triggers persistent storage: Permission.storage.request() / navigator.storage.persist()
 * When granted: ensures offline Quran & Adhan cache won't be cleared by OS eviction.
 */
export async function requestStoragePermission(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  persisted: boolean;
}> {
  let persisted = false;
  try {
    if (navigator.storage && navigator.storage.persist) {
      persisted = await navigator.storage.persist();
    }
    // Test Cache Storage
    if ('caches' in window) {
      const cache = await caches.open('rifq_offline_audio_v1');
      await cache.put(
        new Request('/_cache_test_ping'),
        new Response('OK', { headers: { 'content-type': 'text/plain' } })
      );
    }
    savePermissionState('storage', 'granted');
    return { status: 'granted', granted: true, persisted };
  } catch {
    // LocalStorage / IndexedDB is always available as fallback
    savePermissionState('storage', 'granted');
    return { status: 'granted', granted: true, persisted };
  }
}

/**
 * 5. CAMERA PERMISSION CALLER
 */
export async function requestCameraPermission(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  isPermanentlyDenied?: boolean;
  error?: string;
}> {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    savePermissionState('camera', 'denied');
    return { status: 'denied', granted: false, error: 'المتصفح لا يدعم الوصول للكاميرا' };
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
    stream.getTracks().forEach(t => t.stop());
    savePermissionState('camera', 'granted');
    return { status: 'granted', granted: true };
  } catch (e: unknown) {
    const error = e as { name?: string };
    const isPermanentlyDenied = error.name === 'NotAllowedError';
    const status: PermissionStatus = isPermanentlyDenied ? 'permanentlyDenied' : 'denied';
    savePermissionState('camera', status);
    return {
      status,
      granted: false,
      isPermanentlyDenied,
      error: 'تم رفض الوصول للكاميرا.'
    };
  }
}

/**
 * 6. CONTACTS PERMISSION CALLER
 */
export async function requestContactsPermission(): Promise<{
  status: PermissionStatus;
  granted: boolean;
  error?: string;
}> {
  if ('contacts' in navigator && 'ContactsManager' in window) {
    try {
      const props = ['name', 'tel'];
      await (navigator as unknown as { contacts: { select: (p: string[], opts?: { multiple?: boolean }) => Promise<unknown> } }).contacts.select(props, { multiple: false });
      savePermissionState('contacts', 'granted');
      return { status: 'granted', granted: true };
    } catch {
      savePermissionState('contacts', 'denied');
      return { status: 'denied', granted: false, error: 'تم إلغاء اختيار جهة الاتصال' };
    }
  }

  if (navigator.share) {
    try {
      await navigator.share({
        title: 'رِفْق | RIFQ',
        text: 'انضم إليّ في تطبيق «رِفْق | RIFQ» وشاركني أجر الأذكار ومواقيت الصلاة المباركة! 🕌',
        url: window.location.href
      });
      savePermissionState('contacts', 'granted');
      return { status: 'granted', granted: true };
    } catch {
      savePermissionState('contacts', 'prompt');
      return { status: 'prompt', granted: false, error: 'تم إلغاء المشاركة' };
    }
  }

  savePermissionState('contacts', 'denied');
  return { status: 'denied', granted: false, error: 'مشاركة جهات الاتصال غير مدعومة مباشرة في هذا المتصفح' };
}

/**
 * 7. BIOMETRICS CHECKER
 */
export async function checkBiometricSupport(): Promise<boolean> {
  if (typeof window !== 'undefined' && window.PublicKeyCredential) {
    try {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch {
      return false;
    }
  }
  return false;
}
