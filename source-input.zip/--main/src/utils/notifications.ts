import { Capacitor, registerPlugin, PluginListenerHandle } from '@capacitor/core';
import { UserSettings, WardType, PrayerSoundMode, ScreenType } from '../types';
import { soundManager } from './audio';
import { playPrayerSound, triggerHaptic } from './prayerAudio';
import { addNotification, loadSettings, saveSettings } from './storage';
import { MORNING_ATHKAR, EVENING_ATHKAR } from '../data/athkarData';

const LAST_MORNING_REMINDER_DATE_KEY = 'mushaba_last_morning_reminder_date_v1';
const LAST_EVENING_REMINDER_DATE_KEY = 'mushaba_last_evening_reminder_date_v1';
const LAST_SLEEP_REMINDER_DATE_KEY = 'mushaba_last_sleep_reminder_date_v1';
const UNIFIED_NOTIF_SETTINGS_KEY = 'rifq_unified_notification_settings_v2';
const FIRED_NOTIFICATIONS_REGISTRY_KEY = 'rifq_fired_notifications_registry_v2';

export type PermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

let swRegistration: ServiceWorkerRegistration | null = null;
let nextPrecisionTimeoutId: ReturnType<typeof setTimeout> | null = null;
let nativeListenersRegistered = false;
let lastKnownNativeStatus: NativeNotificationStatusResult | null = null;
let cachedExtraPrayerItems: ScheduledSwNotificationItem[] = [];

/**
 * Official Android Notification Channels for «رِفْق | RIFQ».
 * Includes both new canonical IDs (rifq_adhkar, rifq_prayer, rifq_updates) and aliases (azkar, adhan).
 */
export const RIFQ_NOTIFICATION_CHANNELS = {
  general: 'rifq_general',
  adhan: 'rifq_prayer',
  prayer: 'rifq_prayer',
  quran: 'rifq_quran',
  azkar: 'rifq_adhkar',
  adhkar: 'rifq_adhkar',
  reminders: 'rifq_reminders',
  updates: 'rifq_updates',
} as const;

export interface AndroidChannelStatus {
  id: string;
  nameAr: string;
  descriptionAr: string;
  systemEnabled: boolean;
  appEnabled: boolean;
  effectiveEnabled: boolean;
}

export interface NativeNotificationStatusResult {
  granted: boolean;
  systemNotificationsEnabled: boolean;
  areNotificationsEnabled?: boolean;
  postNotificationsPermission: 'granted' | 'denied' | 'prompt';
  permanentlyBlocked: boolean;
  sdkInt: number;
  canScheduleExactAlarms: boolean;
  channels: AndroidChannelStatus[];
}

export interface RifqNotificationsPluginInterface {
  getNotificationStatus(): Promise<NativeNotificationStatusResult>;
  requestNotificationPermission(): Promise<NativeNotificationStatusResult>;
  openNotificationSettings(options?: { channelId?: string }): Promise<{ opened: boolean; error?: string }>;
  showSystemNotification(options: {
    id?: string;
    notificationId?: number;
    channelId?: string;
    title: string;
    body: string;
    screen?: string;
    ward?: string;
    dhikrId?: string;
    signatureKey?: string;
    bypassChannelCheck?: boolean;
    recordInApp?: boolean;
  }): Promise<{ displayed: boolean; notificationId: number; channelId: string; reason?: string }>;
  sendTestSystemNotification(options?: {
    title?: string;
    body?: string;
    screen?: string;
  }): Promise<{ displayed: boolean; notificationId?: number; reason?: string; error?: string }>;
  syncScheduledNotifications(options: {
    scheduleItems: ScheduledSwNotificationItem[];
    channels: Record<string, boolean>;
    quietHours?: { enabled: boolean; start: string; end: string };
    firedKeys?: string[];
  }): Promise<{ synced: boolean; scheduledCount: number }>;
  setChannelEnabled(options: { channelId: string; enabled: boolean }): Promise<{ channelId: string; enabled: boolean }>;
  cancelScheduledNotification(options: { id: string }): Promise<{ cancelled: boolean }>;
  consumePendingEvents(): Promise<{
    pendingNotifications: Array<{
      id: string;
      title: string;
      message: string;
      screen?: string;
      ward?: string;
      dhikrId?: string;
      signatureKey?: string;
      timestamp: number;
    }>;
    pendingNavigation: {
      screen?: string;
      ward?: string;
      dhikrId?: string;
      notificationId?: string;
    } | null;
  }>;
  addListener(
    eventName: 'notificationTapped',
    listenerFunc: (data: {
      screen?: string;
      ward?: string;
      dhikrId?: string;
      notificationId?: string;
    }) => void
  ): Promise<PluginListenerHandle>;
  addListener(
    eventName: 'systemNotificationFired',
    listenerFunc: (data: {
      id: string;
      title: string;
      message: string;
      screen?: string;
      ward?: string;
      dhikrId?: string;
      signatureKey?: string;
      timestamp: number;
    }) => void
  ): Promise<PluginListenerHandle>;
}

const RifqNotificationsNative = registerPlugin<RifqNotificationsPluginInterface>('RifqNotifications');

export function isNativeAndroidPlatform(): boolean {
  try {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

export function normalizeRifqChannelId(rawId?: string): string {
  if (!rawId) return RIFQ_NOTIFICATION_CHANNELS.general;
  if (rawId === 'rifq_azkar' || rawId === 'rifq_adhkar') return 'rifq_adhkar';
  if (rawId === 'rifq_adhan' || rawId === 'rifq_prayer') return 'rifq_prayer';
  if (rawId === 'rifq_quran') return 'rifq_quran';
  if (rawId === 'rifq_reminders') return 'rifq_reminders';
  if (rawId === 'rifq_updates') return 'rifq_updates';
  return 'rifq_general';
}

export interface UnifiedNotificationSettings {
  adhanChannelEnabled: boolean;
  quranChannelEnabled: boolean;
  azkarChannelEnabled: boolean;
  remindersChannelEnabled: boolean;
  updatesChannelEnabled: boolean;
  morningAthkarEnabled: boolean;
  morningAthkarTime: string; // "06:30"
  eveningAthkarEnabled: boolean;
  eveningAthkarTime: string; // "17:30"
  sleepAthkarEnabled: boolean;
  sleepAthkarTime: string; // "22:00"
  ayahOfTheDayEnabled: boolean;
  ayahOfTheDayTime: string; // "08:00"
  faidaOfTheDayEnabled: boolean;
  faidaOfTheDayTime: string; // "16:00"
  quranWirdReminderEnabled: boolean;
  quranWirdReminderTime: string; // "19:00"
  duaOfTheDayEnabled: boolean;
  duaOfTheDayTime: string; // "14:00"
  journeyReminderEnabled?: boolean;
  journeyReminderTime?: string;
  harvestReminderEnabled?: boolean;
  harvestReminderTime?: string;
  updatedAt: number;
}

export const DEFAULT_UNIFIED_NOTIFICATION_SETTINGS: UnifiedNotificationSettings = {
  adhanChannelEnabled: true,
  quranChannelEnabled: true,
  azkarChannelEnabled: true,
  remindersChannelEnabled: true,
  updatesChannelEnabled: true,
  morningAthkarEnabled: true,
  morningAthkarTime: '06:30',
  eveningAthkarEnabled: true,
  eveningAthkarTime: '17:30',
  sleepAthkarEnabled: true,
  sleepAthkarTime: '22:00',
  ayahOfTheDayEnabled: true,
  ayahOfTheDayTime: '08:00',
  faidaOfTheDayEnabled: true,
  faidaOfTheDayTime: '16:00',
  quranWirdReminderEnabled: true,
  quranWirdReminderTime: '19:00',
  duaOfTheDayEnabled: true,
  duaOfTheDayTime: '14:00',
  updatedAt: 0,
};

// ─── Authentic Daily Quran Verses, Benefits (Fawaid), and Prophetic Duas ───
export const DAILY_AYAH_LIST: { ayah: string; surah: string; number: number }[] = [
  { ayah: '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾', surah: 'سورة الرعد', number: 28 },
  { ayah: '﴿ وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا * وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ ﴾', surah: 'سورة الطلاق', number: 2 },
  { ayah: '﴿ وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ ﴾', surah: 'سورة البقرة', number: 186 },
  { ayah: '﴿ فَإِنَّ مَعَ الْعُسْرِ يُسْرًا * إِنَّ مَعَ الْعُسْرِ يُسْرًا ﴾', surah: 'سورة الشرح', number: 5 },
  { ayah: '﴿ فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ ﴾', surah: 'سورة البقرة', number: 152 },
  { ayah: '﴿ وَاصْبِرْ لِحُكْمِ رَبِّكَ فَإِنَّكَ بِأَعْيُنِنَا وَسَبِّحْ بِحَمْدِ رَبِّكَ حِينَ تَقُومُ ﴾', surah: 'سورة الطور', number: 48 },
  { ayah: '﴿ رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ﴾', surah: 'سورة آل عمران', number: 8 },
  { ayah: '﴿ وَقُل رَّبِّ زِدْنِي عِلْمًا ﴾', surah: 'سورة طه', number: 114 },
  { ayah: '﴿ إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا ﴾', surah: 'سورة الأحزاب', number: 56 },
  { ayah: '﴿ وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا ﴾', surah: 'سورة الأحزاب', number: 35 },
];

export const DAILY_FAIDA_LIST: { title: string; body: string; source: string }[] = [
  {
    title: 'فائدة اليوم • مفتاح الفرج والرزق',
    body: 'من جمع بين تقوى الله في أمره والتوكل الصادق عليه؛ كفاه الله كل ما أهمّه من أمر دينه ودنياه وفتح له أبواب الفرج من حيث لا يحتسب.',
    source: 'تفسير السعدي — سورة الطلاق: ٢',
  },
  {
    title: 'فائدة اليوم • سرّ القرب في آية الدعاء',
    body: 'في كل أسئلة القرآن يأتي الجواب بـ(قُل) إلا في آية الدعاء قال سبحانه مباشرة: ﴿فَإِنِّي قَرِيبٌ﴾ إشعاراً برفع الحجاب وشدة القرب من العبد الداعي.',
    source: 'بدائع الفوائد لابن القيم — البقرة: ١٨٦',
  },
  {
    title: 'فائدة اليوم • لن يغلب عسرٌ يسرين',
    body: 'تكرر تعريف (العسر) فكان واحداً، وتكرر تنكير (اليسر) فكان يسرين؛ قال النبي ﷺ: «لن يغلب عسرٌ يسرين».',
    source: 'تفسير ابن كثير — سورة الشرح: ٥',
  },
  {
    title: 'فائدة اليوم • جلاء القلوب بالذكر',
    body: 'قال ابن القيم رحمه الله: «في القلب قسوة لا يذيبها إلا ذكر الله تعالى، فينبغي للعبد أن يداوي قسوة قلبه بذكر الله».',
    source: 'الوابل الصيب لابن القيم',
  },
  {
    title: 'فائدة اليوم • بركة القرآن في اليوم والليلة',
    body: 'من افتتح يومه بتلاوة شيء من كتاب الله بتدبر؛ بورك له في وقته وعمله، وكان القرآن ربيعاً لقلبه ونوراً لصدره.',
    source: 'الأذكار للنووي',
  },
  {
    title: 'فائدة اليوم • دعوة ذي النون للمكروب',
    body: 'جمعت ﴿لَا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ﴾ توحيد الله، وتنزيهه، والاعتراف بالتقصير، فكانت سبباً لنجاة كل مؤمن.',
    source: 'الفوائد لابن القيم — الأنبياء: ٨٧',
  },
  {
    title: 'فائدة اليوم • القلب السليم',
    body: 'القلب السليم هو الذي سلم من الشرك والغل والحقد والحسد، فصار خالصاً لله محبةً وإنابةً وتوكلاً.',
    source: 'تفسير ابن كثير — الشعراء: ٨٩',
  },
];

export const DAILY_PROPHETIC_DUAS: { title: string; body: string; source: string }[] = [
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى»',
    source: 'رواه مسلم (2721)',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ»',
    source: 'رواه الترمذي (2140)',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ»',
    source: 'رواه أبو داود (1522)',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ»',
    source: 'متفق عليه',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا»',
    source: 'رواه ابن ماجه (925)',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ اصْرِفْ قُلُوبَنَا عَلَى طَاعَتِكَ»',
    source: 'رواه مسلم (2654)',
  },
  {
    title: 'دعاء اليوم المأثور 🤲',
    body: '«اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي»',
    source: 'رواه الترمذي (3513)',
  },
];

function getLocalTodayString(now = new Date()): string {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function hasNotificationFired(signatureKey: string): boolean {
  try {
    const raw = localStorage.getItem(FIRED_NOTIFICATIONS_REGISTRY_KEY);
    if (!raw) return false;
    const map = JSON.parse(raw) as Record<string, number>;
    return Boolean(map[signatureKey]);
  } catch {
    return false;
  }
}

export function markNotificationFired(signatureKey: string): void {
  try {
    const raw = localStorage.getItem(FIRED_NOTIFICATIONS_REGISTRY_KEY);
    const map: Record<string, number> = raw ? JSON.parse(raw) : {};
    const nowMs = Date.now();
    // Prune entries older than 3 days to keep storage clean
    for (const k of Object.keys(map)) {
      if (nowMs - map[k] > 3 * 24 * 60 * 60 * 1000) {
        delete map[k];
      }
    }
    map[signatureKey] = nowMs;
    localStorage.setItem(FIRED_NOTIFICATIONS_REGISTRY_KEY, JSON.stringify(map));

    // Also inform Service Worker so it doesn't duplicate
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then((reg) => {
          reg.active?.postMessage({
            type: 'MARK_NOTIFICATION_FIRED',
            signatureKey,
          });
        })
        .catch(() => {});
    }
  } catch {
    // ignore
  }
}

/**
 * Loads the single source of truth for notification settings, migrating & syncing legacy keys
 */
export function loadUnifiedNotificationSettings(): UnifiedNotificationSettings {
  try {
    const userSettings = loadSettings();
    const rawUnified = localStorage.getItem(UNIFIED_NOTIF_SETTINGS_KEY);
    const parsedUnified: Partial<UnifiedNotificationSettings> = rawUnified
      ? JSON.parse(rawUnified)
      : {};

    const adhanRaw =
      localStorage.getItem('notif_channel_rifq_prayer') ??
      localStorage.getItem('notif_channel_rifq_adhan');
    const quranRaw = localStorage.getItem('notif_channel_rifq_quran');
    const azkarRaw =
      localStorage.getItem('notif_channel_rifq_adhkar') ??
      localStorage.getItem('notif_channel_rifq_azkar');
    const remindersRaw = localStorage.getItem('notif_channel_rifq_reminders');
    const updatesRaw = localStorage.getItem('notif_channel_rifq_updates');

    const adhanChannelEnabled =
      adhanRaw !== null
        ? adhanRaw === 'true'
        : parsedUnified.adhanChannelEnabled ?? DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.adhanChannelEnabled;

    const quranChannelEnabled =
      quranRaw !== null
        ? quranRaw === 'true'
        : parsedUnified.quranChannelEnabled ?? DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.quranChannelEnabled;

    const azkarChannelEnabled =
      azkarRaw !== null
        ? azkarRaw === 'true'
        : parsedUnified.azkarChannelEnabled ?? DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.azkarChannelEnabled;

    const remindersChannelEnabled =
      remindersRaw !== null
        ? remindersRaw === 'true'
        : parsedUnified.remindersChannelEnabled ??
          DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.remindersChannelEnabled;

    const updatesChannelEnabled =
      updatesRaw !== null
        ? updatesRaw === 'true'
        : parsedUnified.updatesChannelEnabled ??
          DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.updatesChannelEnabled;

    return {
      ...DEFAULT_UNIFIED_NOTIFICATION_SETTINGS,
      ...parsedUnified,
      adhanChannelEnabled,
      quranChannelEnabled,
      azkarChannelEnabled,
      remindersChannelEnabled,
      updatesChannelEnabled,
      morningAthkarTime:
        parsedUnified.morningAthkarTime ||
        userSettings.morningReminderTime ||
        DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.morningAthkarTime,
      eveningAthkarTime:
        parsedUnified.eveningAthkarTime ||
        userSettings.eveningReminderTime ||
        DEFAULT_UNIFIED_NOTIFICATION_SETTINGS.eveningAthkarTime,
    };
  } catch {
    return { ...DEFAULT_UNIFIED_NOTIFICATION_SETTINGS };
  }
}

/**
 * Saves unified notification settings and synchronizes all dependent stores, Android AlarmManager, and Service Worker immediately
 */
export function saveUnifiedNotificationSettings(
  partial: Partial<UnifiedNotificationSettings>
): UnifiedNotificationSettings {
  const current = loadUnifiedNotificationSettings();
  const mergedWithoutTimestamp: UnifiedNotificationSettings = {
    ...current,
    ...partial,
  };

  const hasChanged =
    JSON.stringify({ ...current, updatedAt: 0 }) !==
    JSON.stringify({ ...mergedWithoutTimestamp, updatedAt: 0 });

  const updated: UnifiedNotificationSettings = {
    ...mergedWithoutTimestamp,
    updatedAt: hasChanged ? Date.now() : current.updatedAt || Date.now(),
  };

  try {
    localStorage.setItem(UNIFIED_NOTIF_SETTINGS_KEY, JSON.stringify(updated));

    // Sync both canonical & legacy channel keys
    localStorage.setItem('notif_channel_rifq_prayer', String(updated.adhanChannelEnabled));
    localStorage.setItem('notif_channel_rifq_adhan', String(updated.adhanChannelEnabled));
    localStorage.setItem('notif_channel_rifq_quran', String(updated.quranChannelEnabled));
    localStorage.setItem('notif_channel_rifq_adhkar', String(updated.azkarChannelEnabled));
    localStorage.setItem('notif_channel_rifq_azkar', String(updated.azkarChannelEnabled));
    localStorage.setItem('notif_channel_rifq_reminders', String(updated.remindersChannelEnabled));
    localStorage.setItem('notif_channel_rifq_updates', String(updated.updatesChannelEnabled));

    // Sync with mushaba_settings_v1 so SettingsView and App.tsx stay 100% consistent
    const currentUserSettings = loadSettings();
    const anyReminderActive =
      updated.azkarChannelEnabled ||
      updated.remindersChannelEnabled ||
      updated.quranChannelEnabled;

    const nextUserSettings: UserSettings = {
      ...currentUserSettings,
      morningReminderTime: updated.morningAthkarTime,
      eveningReminderTime: updated.eveningAthkarTime,
      remindersEnabled:
        partial.azkarChannelEnabled !== undefined || partial.remindersChannelEnabled !== undefined
          ? anyReminderActive
          : currentUserSettings.remindersEnabled,
    };
    saveSettings(nextUserSettings);

    // Also keep DailyReminders list times for morning/evening/sleep in sync if they exist
    const rawDailyList = localStorage.getItem('rifq_daily_reminders_list_v1');
    if (rawDailyList) {
      try {
        const list = JSON.parse(rawDailyList);
        if (Array.isArray(list)) {
          const syncedList = list.map((item: { id: string; time: string; enabled: boolean }) => {
            if (item.id === 'rem_morning_athkar') {
              return {
                ...item,
                time: updated.morningAthkarTime,
                enabled: updated.azkarChannelEnabled && updated.morningAthkarEnabled,
              };
            }
            if (item.id === 'rem_evening_athkar') {
              return {
                ...item,
                time: updated.eveningAthkarTime,
                enabled: updated.azkarChannelEnabled && updated.eveningAthkarEnabled,
              };
            }
            if (item.id === 'rem_sleep_athkar') {
              return {
                ...item,
                time: updated.sleepAthkarTime,
                enabled: updated.azkarChannelEnabled && updated.sleepAthkarEnabled,
              };
            }
            return item;
          });
          localStorage.setItem('rifq_daily_reminders_list_v1', JSON.stringify(syncedList));
        }
      } catch {
        // ignore
      }
    }

    // Broadcast global event only when settings actually changed
    if (hasChanged && typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-notification-settings-changed', { detail: updated })
      );
    }

    // Sync with Android Native AlarmManager & Service Worker immediately
    syncFullNotificationScheduleWithServiceWorker();
  } catch (e) {
    console.warn('Error saving unified notification settings:', e);
  }

  return updated;
}

export function subscribeToNotificationSettings(
  callback: (settings: UnifiedNotificationSettings) => void
): () => void {
  if (typeof window === 'undefined') return () => {};
  const handler = (e: Event) => {
    const customEvent = e as CustomEvent<UnifiedNotificationSettings>;
    callback(customEvent.detail || loadUnifiedNotificationSettings());
  };
  window.addEventListener('rifq-notification-settings-changed', handler);
  return () => window.removeEventListener('rifq-notification-settings-changed', handler);
}

/**
 * Checks whether the environment supports notifications (Native Android or Web Notification API)
 */
export function isNotificationSupported(): boolean {
  if (isNativeAndroidPlatform()) return true;
  return typeof window !== 'undefined' && 'Notification' in window;
}

/**
 * Queries the real Android Native or Browser notification permission state asynchronously
 */
export async function refreshNativeNotificationStatus(): Promise<NativeNotificationStatusResult | null> {
  if (!isNativeAndroidPlatform()) return null;
  try {
    const status = await RifqNotificationsNative.getNotificationStatus();
    lastKnownNativeStatus = status;
    return status;
  } catch {
    return lastKnownNativeStatus;
  }
}

/**
 * Gets the current synchronous notification permission state
 */
export function getNotificationPermission(): PermissionState {
  if (isNativeAndroidPlatform()) {
    if (lastKnownNativeStatus) {
      if (lastKnownNativeStatus.granted) return 'granted';
      if (lastKnownNativeStatus.permanentlyBlocked || lastKnownNativeStatus.postNotificationsPermission === 'denied') {
        return 'denied';
      }
      return 'default';
    }
    // Trigger async refresh in background
    refreshNativeNotificationStatus();
  }

  if (!isNotificationSupported()) {
    return 'unsupported';
  }
  if (typeof window !== 'undefined' && 'Notification' in window) {
    return Notification.permission;
  }
  return 'default';
}

/**
 * Dispatches navigation inside RIFQ when a user taps an Android System Notification
 */
function dispatchDeepLinkFromNotification(nav: {
  screen?: string;
  ward?: string;
  dhikrId?: string;
}): void {
  if (typeof window === 'undefined') return;
  if (nav.ward) {
    window.dispatchEvent(
      new CustomEvent('mushaba-navigate-ward', {
        detail: { wardType: nav.ward as WardType },
      })
    );
    return;
  }
  if (nav.screen === 'moment_dhikr') {
    window.dispatchEvent(
      new CustomEvent('rifq-navigate-moment-dhikr', {
        detail: { dhikrId: nav.dhikrId },
      })
    );
    return;
  }
  if (nav.screen === 'prayers') {
    window.dispatchEvent(new CustomEvent('rifq-navigate-prayers'));
    return;
  }
  if (nav.screen) {
    window.dispatchEvent(
      new CustomEvent('rifq-navigate-screen', {
        detail: { screen: nav.screen as ScreenType, dhikrId: nav.dhikrId },
      })
    );
  }
}

/**
 * Consumes any background notifications fired by Android AlarmManager / FCM while the app was closed
 * and records them into RIFQ's In-App Notification Center ("مركز التذكيرات والإشعارات"),
 * and processes any pending deep-link navigation from tapping an Android notification.
 */
export async function syncPendingNativeNotificationEvents(): Promise<void> {
  if (!isNativeAndroidPlatform()) return;
  try {
    await refreshNativeNotificationStatus();
    const res = await RifqNotificationsNative.consumePendingEvents();

    if (Array.isArray(res.pendingNotifications) && res.pendingNotifications.length > 0) {
      // Process oldest first so newest ends up on top of the Notification Center
      const sorted = [...res.pendingNotifications].sort((a, b) => a.timestamp - b.timestamp);
      for (const item of sorted) {
        if (item.signatureKey) {
          markNotificationFired(item.signatureKey);
        }
        addNotification({
          id: item.id || `native_${item.timestamp}`,
          title: item.title,
          message: item.message,
          time: 'الآن',
          read: false,
          type: 'reminder',
          actionWard: (item.ward || undefined) as WardType | undefined,
          actionScreen: (item.screen || undefined) as ScreenType | undefined,
          actionDhikrId: item.dhikrId || undefined,
          signatureKey: item.signatureKey || undefined,
        });
      }
    }

    if (res.pendingNavigation && (res.pendingNavigation.screen || res.pendingNavigation.ward)) {
      dispatchDeepLinkFromNotification(res.pendingNavigation);
    }
  } catch (e) {
    console.debug('syncPendingNativeNotificationEvents skipped:', e);
  }
}

/**
 * Initializes Android Native Notification listeners & Web Service Worker registration
 */
export async function initPushNotifications(): Promise<ServiceWorkerRegistration | null> {
  if (isNativeAndroidPlatform()) {
    try {
      await refreshNativeNotificationStatus();
      if (!nativeListenersRegistered) {
        nativeListenersRegistered = true;

        await RifqNotificationsNative.addListener('notificationTapped', (data) => {
          dispatchDeepLinkFromNotification(data);
        });

        await RifqNotificationsNative.addListener('systemNotificationFired', (data) => {
          if (data.signatureKey) {
            markNotificationFired(data.signatureKey);
          }
          addNotification({
            id: data.id || `native_${data.timestamp}`,
            title: data.title,
            message: data.message,
            time: 'الآن',
            read: false,
            type: 'reminder',
            actionWard: (data.ward || undefined) as WardType | undefined,
            actionScreen: (data.screen || undefined) as ScreenType | undefined,
            actionDhikrId: data.dhikrId || undefined,
            signatureKey: data.signatureKey || undefined,
          });
        });

        window.addEventListener('focus', () => {
          syncPendingNativeNotificationEvents();
        });
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') {
            syncPendingNativeNotificationEvents();
          }
        });
      }

      await syncPendingNativeNotificationEvents();
      syncFullNotificationScheduleWithServiceWorker();
    } catch (e) {
      console.debug('Native Android notification init error:', e);
    }
  }

  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
    return null;
  }

  try {
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    swRegistration = reg;

    if ('periodicSync' in reg) {
      try {
        await (
          reg as unknown as {
            periodicSync: { register: (tag: string, opts: { minInterval: number }) => Promise<void> };
          }
        ).periodicSync.register('rifq-periodic-notifications', {
          minInterval: 15 * 60 * 1000,
        });
      } catch {
        // Periodic sync optional
      }
    }

    syncFullNotificationScheduleWithServiceWorker();
    return reg;
  } catch (err) {
    console.debug('ServiceWorker registration skipped or failed:', err);
    return null;
  }
}

/**
 * Requests Android 13+ POST_NOTIFICATIONS runtime permission (or Browser Notification permission)
 */
export async function requestNotificationPermission(): Promise<PermissionState> {
  if (isNativeAndroidPlatform()) {
    try {
      const status = await RifqNotificationsNative.requestNotificationPermission();
      lastKnownNativeStatus = status;
      if (status.granted) {
        await initPushNotifications();
        syncFullNotificationScheduleWithServiceWorker();
        return 'granted';
      }
      return status.postNotificationsPermission === 'denied' || status.permanentlyBlocked
        ? 'denied'
        : 'default';
    } catch (err) {
      console.error('Failed to request native Android notification permission:', err);
      return 'denied';
    }
  }

  if (!isNotificationSupported()) {
    return 'unsupported';
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      await initPushNotifications();
      syncFullNotificationScheduleWithServiceWorker();
    }
    return permission;
  } catch (err) {
    console.error('Failed to request notification permission:', err);
    return Notification.permission;
  }
}

/**
 * Opens Android's native App Notification Settings (or specific NotificationChannel settings)
 */
export async function openSystemNotificationSettings(channelId?: string): Promise<boolean> {
  if (isNativeAndroidPlatform()) {
    try {
      const res = await RifqNotificationsNative.openNotificationSettings(
        channelId ? { channelId: normalizeRifqChannelId(channelId) } : undefined
      );
      return Boolean(res.opened);
    } catch {
      return false;
    }
  }
  return false;
}

export interface PushNotificationPayload {
  title: string;
  message: string;
  ward?: WardType;
  screen?: ScreenType;
  dhikrId?: string;
  tag?: string;
  channelId?: string;
  signatureKey?: string;
  bypassChannelCheck?: boolean;
  recordInCenter?: boolean;
}

/**
 * Dispatches a real Android System Notification (via RifqNotificationsPlugin)
 * or Web Push Notification, and optionally records it in the In-App Notification Center.
 *
 * IMPORTANT: Returns true ONLY if the external System Notification (A) was actually displayed!
 */
export async function triggerPushNotification({
  title,
  message,
  ward,
  screen,
  dhikrId,
  tag,
  channelId,
  signatureKey,
  bypassChannelCheck = false,
  recordInCenter = false,
}: PushNotificationPayload): Promise<boolean> {
  const effectiveChannelId = normalizeRifqChannelId(
    channelId || (ward ? RIFQ_NOTIFICATION_CHANNELS.adhkar : RIFQ_NOTIFICATION_CHANNELS.reminders)
  );

  // ── Block Non-Essential Notifications during Prayer Mode (وضع الصلاة والخشوع) ──
  const isEssentialPrayerAlert =
    effectiveChannelId === RIFQ_NOTIFICATION_CHANNELS.prayer ||
    effectiveChannelId === 'rifq_prayer' ||
    effectiveChannelId === 'rifq_adhan';

  if (!isEssentialPrayerAlert) {
    try {
      const rawMode = typeof localStorage !== 'undefined' ? localStorage.getItem('rifq_in_app_prayer_mode_state_v1') : null;
      if (rawMode) {
        const parsedMode = JSON.parse(rawMode);
        if (parsedMode.isActive && parsedMode.endTimeMs && parsedMode.endTimeMs > Date.now()) {
          // Increment blocked notifications counter for the active prayer session
          parsedMode.blockedCount = (parsedMode.blockedCount || 0) + 1;
          localStorage.setItem('rifq_in_app_prayer_mode_state_v1', JSON.stringify(parsedMode));
          if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('rifq-in-app-prayer-mode-changed', { detail: parsedMode }));
          }

          // Silently log to in-app notification center so user can review it later peacefully
          if (recordInCenter) {
            addNotification({
              title,
              message: `(محجوب أثناء الصلاة) ${message}`,
              time: 'الآن',
              read: false,
              type: 'reminder',
              actionWard: ward,
              actionScreen: screen || (ward ? 'ward' : undefined),
              actionDhikrId: dhikrId,
              signatureKey,
            });
          }
          return false; // Suppressed for prayer focus
        }
      }
    } catch {
      // ignore
    }
  }

  // Check channel state unless explicitly bypassed (e.g., for test notification)
  if (!bypassChannelCheck && effectiveChannelId !== RIFQ_NOTIFICATION_CHANNELS.general) {
    if (!isNotificationChannelEnabled(effectiveChannelId)) {
      return false;
    }
  }

  // Record in RIFQ In-App Notification Center ("مركز التذكيرات والإشعارات") if requested
  if (recordInCenter) {
    addNotification({
      title,
      message,
      time: 'الآن',
      read: false,
      type: 'reminder',
      actionWard: ward,
      actionScreen: screen || (ward ? 'ward' : undefined),
      actionDhikrId: dhikrId,
      signatureKey,
    });
  }

  // Trigger sound & haptic if enabled in user settings
  const userSettings = loadSettings();
  if (userSettings.soundEnabled !== false) {
    soundManager.playCompletionChime(0.6);
  }
  if (userSettings.vibrationEnabled !== false) {
    soundManager.triggerHaptic([100, 50, 150]);
  }

  const notificationTag = tag || (ward ? `athkar-${ward}` : `rifq-notif-${Date.now()}`);
  const resolvedScreen: ScreenType | undefined = screen || (ward ? 'ward' : undefined);

  // ── A.1: Android Native System Notification (Status Bar, Notification Shade, Lock Screen) ──
  if (isNativeAndroidPlatform()) {
    try {
      const res = await RifqNotificationsNative.showSystemNotification({
        id: notificationTag,
        channelId: effectiveChannelId,
        title,
        body: message,
        screen: resolvedScreen || '',
        ward: ward || '',
        dhikrId: dhikrId || '',
        signatureKey: signatureKey || '',
        bypassChannelCheck,
        recordInApp: false, // Already handled above or by caller
      });
      await refreshNativeNotificationStatus();
      return Boolean(res.displayed);
    } catch (err) {
      console.error('Native Android notification dispatch failed:', err);
      return false;
    }
  }

  // ── A.2: Web / PWA System Notification Fallback ──
  if (typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') {
    return false;
  }

  const targetUrl = resolvedScreen
    ? `/?screen=${resolvedScreen}${ward ? `&ward=${ward}` : ''}${dhikrId ? `&dhikrId=${dhikrId}` : ''}`
    : '/';

  const swNotificationOptions: NotificationOptions & {
    renotify?: boolean;
    vibrate?: number[];
  } = {
    body: message,
    tag: notificationTag,
    renotify: true,
    icon: '/assets/icons/ic_notification.png',
    badge: '/assets/icons/ic_notification.png',
    vibrate: [120, 60, 160],
    data: {
      ward,
      screen: resolvedScreen,
      dhikrId,
      channelId: effectiveChannelId,
      url: targetUrl,
      timestamp: Date.now(),
    },
    lang: 'ar',
    dir: 'rtl',
  };

  try {
    if (swRegistration && 'showNotification' in swRegistration) {
      await swRegistration.showNotification(title, swNotificationOptions);
      return true;
    }

    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      const readyReg = await navigator.serviceWorker.ready.catch(() => null);
      if (readyReg && 'showNotification' in readyReg) {
        swRegistration = readyReg;
        await readyReg.showNotification(title, swNotificationOptions);
        return true;
      }
    }

    const notification = new Notification(title, {
      body: message,
      tag: notificationTag,
      icon: '/assets/icons/ic_notification.png',
      lang: 'ar',
      dir: 'rtl',
    });
    notification.onclick = () => {
      window.focus();
      dispatchDeepLinkFromNotification({
        screen: resolvedScreen,
        ward,
        dhikrId,
      });
      notification.close();
    };

    return true;
  } catch (err) {
    try {
      const fallback = new Notification(title, {
        body: message,
        tag: notificationTag,
      });
      fallback.onclick = () => {
        window.focus();
        dispatchDeepLinkFromNotification({
          screen: resolvedScreen,
          ward,
          dhikrId,
        });
        fallback.close();
      };
      return true;
    } catch (innerErr) {
      console.error('Error sending push notification:', err, innerErr);
      return false;
    }
  }
}

/**
 * Sends a real test notification to BOTH:
 * 1) Android System Notification Shade (outside the app)
 * 2) In-App Notification Center ("مركز التذكيرات والإشعارات")
 *
 * Returns true ONLY if the external System Notification actually succeeded!
 */
export async function sendTestNotification(): Promise<boolean> {
  const title = '🔔 إشعار تجريبي — رِفْق | RIFQ';
  const message =
    'تم إرسال هذا الإشعار الحقيقي إلى شريط إشعارات جهازك ومركز التذكيرات في تطبيق رِفْق بنجاح.';

  if (isNativeAndroidPlatform()) {
    try {
      const res = await RifqNotificationsNative.sendTestSystemNotification({
        title,
        body: message,
        screen: 'daily_reminders',
      });
      await refreshNativeNotificationStatus();
      if (!res.displayed) {
        return false;
      }
      // Record in In-App Notification Center as well so both A and B are verified
      addNotification({
        title,
        message,
        time: 'الآن',
        read: false,
        type: 'general',
        actionScreen: 'daily_reminders',
      });
      return true;
    } catch {
      return false;
    }
  }

  const perm = getNotificationPermission();
  if (perm !== 'granted') {
    return false;
  }

  const systemDisplayed = await triggerPushNotification({
    title,
    message,
    screen: 'daily_reminders',
    channelId: RIFQ_NOTIFICATION_CHANNELS.general,
    tag: `rifq-test-notification-${Date.now()}`,
    bypassChannelCheck: true,
    recordInCenter: false,
  });

  if (systemDisplayed) {
    addNotification({
      title,
      message,
      time: 'الآن',
      read: false,
      type: 'general',
      actionScreen: 'daily_reminders',
    });
  }

  return systemDisplayed;
}

export function isNotificationChannelEnabled(channelId: string): boolean {
  try {
    const normalized = normalizeRifqChannelId(channelId);
    const val =
      localStorage.getItem(`notif_channel_${normalized}`) ??
      localStorage.getItem(`notif_channel_${channelId}`);
    return val === null ? true : val === 'true';
  } catch {
    return true;
  }
}

export function setNotificationChannelEnabled(channelId: string, enabled: boolean): void {
  try {
    const normalized = normalizeRifqChannelId(channelId);
    localStorage.setItem(`notif_channel_${normalized}`, String(enabled));
    localStorage.setItem(`notif_channel_${channelId}`, String(enabled));

    const partial: Partial<UnifiedNotificationSettings> = {};
    if (normalized === 'rifq_prayer') {
      partial.adhanChannelEnabled = enabled;
    } else if (normalized === 'rifq_quran') {
      partial.quranChannelEnabled = enabled;
    } else if (normalized === 'rifq_adhkar') {
      partial.azkarChannelEnabled = enabled;
    } else if (normalized === 'rifq_reminders') {
      partial.remindersChannelEnabled = enabled;
    } else if (normalized === 'rifq_updates') {
      partial.updatesChannelEnabled = enabled;
    }

    saveUnifiedNotificationSettings(partial);

    if (isNativeAndroidPlatform()) {
      RifqNotificationsNative.setChannelEnabled({
        channelId: normalized,
        enabled,
      }).catch(() => {});
    }

    // If channel was disabled, close any active notifications belonging to that channel
    if (!enabled && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then(async (reg) => {
          if ('getNotifications' in reg) {
            const activeNotifs = await reg.getNotifications();
            for (const n of activeNotifs) {
              if (
                normalizeRifqChannelId(n.data?.channelId) === normalized ||
                (n.tag && n.tag.startsWith(channelId))
              ) {
                n.close();
              }
            }
          }
        })
        .catch(() => {});
    }
  } catch {
    // ignore
  }
}

function timeStringToMinutes(timeStr: string): number {
  if (!timeStr || !timeStr.includes(':')) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Checks scheduled Morning, Evening, and Sleep Athkar reminders against current time and triggers them
 */
export async function checkAndFireScheduledReminders(
  settings: UserSettings,
  onReminderTriggered: (info: { title: string; message: string; ward: WardType; signatureKey: string }) => void
): Promise<void> {
  const unified = loadUnifiedNotificationSettings();

  // Respect both master reminders toggle and the Adhkar channel toggle
  if (!settings.remindersEnabled || !unified.azkarChannelEnabled) return;

  const now = new Date();
  const todayDate = getLocalTodayString(now);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // 1. Check Morning Athkar Reminder
  if (unified.morningAthkarEnabled) {
    const morningTime = settings.morningReminderTime || unified.morningAthkarTime || '06:30';
    const morningMinutes = timeStringToMinutes(morningTime);
    const morningSignature = `${todayDate}_morning_${morningTime}`;
    const lastMorningFired = localStorage.getItem(LAST_MORNING_REMINDER_DATE_KEY);

    const isMorningWindow =
      currentMinutes >= morningMinutes && currentMinutes <= morningMinutes + 180;

    if (
      isMorningWindow &&
      lastMorningFired !== morningSignature &&
      !hasNotificationFired(morningSignature)
    ) {
      localStorage.setItem(LAST_MORNING_REMINDER_DATE_KEY, morningSignature);
      markNotificationFired(morningSignature);

      const title = 'حان وقت أذكار الصباح ☀️';
      const pickedMorning = MORNING_ATHKAR[now.getDate() % MORNING_ATHKAR.length];
      const message =
        pickedMorning?.text ||
        'حصّن يومك ونفسك بأذكار الصباح المباركة وافتتح نهارك بذكر الله وتوفيقه.';

      if (settings.pushNotificationsEnabled !== false) {
        await triggerPushNotification({
          title,
          message,
          ward: 'morning',
          screen: 'ward',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          signatureKey: morningSignature,
          tag: `rifq-azkar-morning-${todayDate}`,
        });
      }

      onReminderTriggered({
        title,
        message,
        ward: 'morning',
        signatureKey: morningSignature,
      });
    }
  }

  // 2. Check Evening Athkar Reminder
  if (unified.eveningAthkarEnabled) {
    const eveningTime = settings.eveningReminderTime || unified.eveningAthkarTime || '17:30';
    const eveningMinutes = timeStringToMinutes(eveningTime);
    const eveningSignature = `${todayDate}_evening_${eveningTime}`;
    const lastEveningFired = localStorage.getItem(LAST_EVENING_REMINDER_DATE_KEY);

    const isEveningWindow =
      currentMinutes >= eveningMinutes &&
      currentMinutes <= Math.min(1439, eveningMinutes + 180);

    if (
      isEveningWindow &&
      lastEveningFired !== eveningSignature &&
      !hasNotificationFired(eveningSignature)
    ) {
      localStorage.setItem(LAST_EVENING_REMINDER_DATE_KEY, eveningSignature);
      markNotificationFired(eveningSignature);

      const title = 'حان وقت أذكار المساء 🌙';
      const pickedEvening = EVENING_ATHKAR[now.getDate() % EVENING_ATHKAR.length];
      const message =
        pickedEvening?.text ||
        'أمسينا وأمسى الملك لله، بادر بقراءة ورد المساء لتحصين النفس والسكينة.';

      if (settings.pushNotificationsEnabled !== false) {
        await triggerPushNotification({
          title,
          message,
          ward: 'evening',
          screen: 'ward',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          signatureKey: eveningSignature,
          tag: `rifq-azkar-evening-${todayDate}`,
        });
      }

      onReminderTriggered({
        title,
        message,
        ward: 'evening',
        signatureKey: eveningSignature,
      });
    }
  }

  // 3. Check Sleep Athkar Reminder
  if (unified.sleepAthkarEnabled) {
    const sleepTime = unified.sleepAthkarTime || '22:00';
    const sleepMinutes = timeStringToMinutes(sleepTime);
    const sleepSignature = `${todayDate}_sleep_${sleepTime}`;
    const lastSleepFired = localStorage.getItem(LAST_SLEEP_REMINDER_DATE_KEY);

    const isSleepWindow =
      currentMinutes >= sleepMinutes &&
      currentMinutes <= Math.min(1439, sleepMinutes + 120);

    if (
      isSleepWindow &&
      lastSleepFired !== sleepSignature &&
      !hasNotificationFired(sleepSignature)
    ) {
      localStorage.setItem(LAST_SLEEP_REMINDER_DATE_KEY, sleepSignature);
      markNotificationFired(sleepSignature);

      const title = 'حان وقت أذكار النوم 🌌';
      const message =
        'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا — اختم يومك بأذكار النوم وآية الكرسي لراحة القلب.';

      if (settings.pushNotificationsEnabled !== false) {
        await triggerPushNotification({
          title,
          message,
          ward: 'sleep',
          screen: 'ward',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          signatureKey: sleepSignature,
          tag: `rifq-azkar-sleep-${todayDate}`,
        });
      }

      onReminderTriggered({
        title,
        message,
        ward: 'sleep',
        signatureKey: sleepSignature,
      });
    }
  }
}

/**
 * Checks and fires automatic notifications for:
 * - آية اليوم (Ayah of the Day)
 * - فائدة اليوم (Faida of the Day)
 * - تذكير الورد القرآني (Quran Daily Wird)
 * - دعاء اليوم المأثور (Prophetic Dua of the Day)
 */
export async function checkAndFireQuranAndDailyBenefitNotifications(
  onNotificationAdded?: () => void
): Promise<void> {
  const unified = loadUnifiedNotificationSettings();
  const now = new Date();
  const todayDate = getLocalTodayString(now);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000
  );

  // ── 1. آية اليوم (Ayah of the Day) ──
  if (unified.quranChannelEnabled && unified.ayahOfTheDayEnabled) {
    const targetMins = timeStringToMinutes(unified.ayahOfTheDayTime || '08:00');
    const sig = `${todayDate}_ayah_of_day_${unified.ayahOfTheDayTime}`;

    if (
      currentMinutes >= targetMins &&
      currentMinutes <= targetMins + 120 &&
      !hasNotificationFired(sig)
    ) {
      markNotificationFired(sig);
      const item = DAILY_AYAH_LIST[dayOfYear % DAILY_AYAH_LIST.length];
      const title = '📖 آية اليوم — رِفْق';
      const message = `${item.ayah} (${item.surah}: ${item.number})`;

      await triggerPushNotification({
        title,
        message,
        screen: 'tadabbur',
        channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
        signatureKey: sig,
        tag: `rifq-ayah-of-day-${todayDate}`,
      });

      addNotification({
        title,
        message,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'tadabbur',
        signatureKey: sig,
      });
      if (onNotificationAdded) onNotificationAdded();
    }
  }

  // ── 2. فائدة اليوم (Faida of the Day) ──
  if (unified.quranChannelEnabled && unified.faidaOfTheDayEnabled) {
    const targetMins = timeStringToMinutes(unified.faidaOfTheDayTime || '16:00');
    const sig = `${todayDate}_faida_of_day_${unified.faidaOfTheDayTime}`;

    if (
      currentMinutes >= targetMins &&
      currentMinutes <= targetMins + 120 &&
      !hasNotificationFired(sig)
    ) {
      markNotificationFired(sig);
      const item = DAILY_FAIDA_LIST[dayOfYear % DAILY_FAIDA_LIST.length];
      const title = `💡 ${item.title}`;
      const message = `${item.body} (${item.source})`;

      await triggerPushNotification({
        title,
        message,
        screen: 'tadabbur',
        channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
        signatureKey: sig,
        tag: `rifq-faida-of-day-${todayDate}`,
      });

      addNotification({
        title,
        message,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'tadabbur',
        signatureKey: sig,
      });
      if (onNotificationAdded) onNotificationAdded();
    }
  }

  // ── 3. تذكير الورد القرآني اليومي (Daily Quran Wird) ──
  if (unified.quranChannelEnabled && unified.quranWirdReminderEnabled) {
    const targetMins = timeStringToMinutes(unified.quranWirdReminderTime || '19:00');
    const sig = `${todayDate}_quran_wird_${unified.quranWirdReminderTime}`;

    if (
      currentMinutes >= targetMins &&
      currentMinutes <= targetMins + 120 &&
      !hasNotificationFired(sig)
    ) {
      markNotificationFired(sig);
      const title = '🕌 تذكير الورد القرآني اليومي';
      const message =
        'اجعل لقلبك نصيباً من كتاب الله اليوم؛ ولو صفحة واحدة تنير بها يومك وصحيفة عملك.';

      await triggerPushNotification({
        title,
        message,
        screen: 'quran',
        channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
        signatureKey: sig,
        tag: `rifq-quran-wird-${todayDate}`,
      });

      addNotification({
        title,
        message,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'quran',
        signatureKey: sig,
      });
      if (onNotificationAdded) onNotificationAdded();
    }
  }

  // ── 4. دعاء اليوم المأثور (Daily Prophetic Dua) ──
  if (unified.remindersChannelEnabled && unified.duaOfTheDayEnabled) {
    const targetMins = timeStringToMinutes(unified.duaOfTheDayTime || '14:00');
    const sig = `${todayDate}_dua_of_day_${unified.duaOfTheDayTime}`;

    if (
      currentMinutes >= targetMins &&
      currentMinutes <= targetMins + 120 &&
      !hasNotificationFired(sig)
    ) {
      markNotificationFired(sig);
      const item = DAILY_PROPHETIC_DUAS[dayOfYear % DAILY_PROPHETIC_DUAS.length];
      const title = item.title;
      const message = `${item.body} — ${item.source}`;

      await triggerPushNotification({
        title,
        message,
        screen: 'hisn_almuslim',
        channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
        signatureKey: sig,
        tag: `rifq-dua-of-day-${todayDate}`,
      });

      addNotification({
        title,
        message,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'hisn_almuslim',
        signatureKey: sig,
      });
      if (onNotificationAdded) onNotificationAdded();
    }
  }
}

export interface PrayerNotificationPayload {
  prayerNameAr: string;
  cityName: string;
  timeFormatted: string;
  mode: PrayerSoundMode;
  audioUrl?: string;
  muadhinName?: string;
  isPreReminder?: boolean;
  signatureKey?: string;
  bypassChannelCheck?: boolean;
}

/**
 * Dispatches an instant prayer Adhan notification (Android System Notification + Audio)
 */
export async function triggerPrayerAdhanNotification({
  prayerNameAr,
  cityName,
  timeFormatted,
  mode,
  audioUrl,
  muadhinName,
  isPreReminder,
  signatureKey,
  bypassChannelCheck = false,
}: PrayerNotificationPayload): Promise<boolean> {
  if (!bypassChannelCheck && !isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.prayer)) {
    return false;
  }

  const title = isPreReminder
    ? `اقترب موعد صلاة ${prayerNameAr} ⏳`
    : `حان الآن وقت صلاة ${prayerNameAr} 🕌`;

  const message = isPreReminder
    ? `تبقى دقائق يسيرة على أذان ${prayerNameAr} (${timeFormatted}) بتوقيت ${cityName}. استعد بالوضوء والصلاة.`
    : `دخل الآن وقت صلاة ${prayerNameAr} (${timeFormatted}) بتوقيت ${cityName} • حي على الصلاة، حي على الفلاح`;

  // 1. Play designated audio mode (Full Adhan, Takbeer, Chime, or Silent)
  playPrayerSound(
    mode,
    audioUrl,
    `أذان ${prayerNameAr} (${muadhinName || 'المؤذن'})`,
    undefined,
    undefined,
    prayerNameAr
  );
  triggerHaptic([200, 100, 300, 100, 200]);

  const todayStr = getLocalTodayString();
  const notificationTag = `prayer-${prayerNameAr}-${todayStr}-${isPreReminder ? 'pre' : 'main'}`;

  // 2.A: Android Native System Notification
  if (isNativeAndroidPlatform()) {
    try {
      const res = await RifqNotificationsNative.showSystemNotification({
        id: notificationTag,
        channelId: RIFQ_NOTIFICATION_CHANNELS.prayer,
        title,
        body: message,
        screen: 'prayers',
        signatureKey: signatureKey || '',
        bypassChannelCheck,
        recordInApp: false,
      });
      await refreshNativeNotificationStatus();
      return Boolean(res.displayed);
    } catch {
      return false;
    }
  }

  // 2.B: Browser / ServiceWorker Notification
  if (typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') {
    return false;
  }

  const swOptions: NotificationOptions & {
    renotify?: boolean;
    vibrate?: number[];
    actions?: Array<{ action: string; title: string }>;
  } = {
    body: message,
    tag: notificationTag,
    renotify: true,
    lang: 'ar',
    dir: 'rtl',
    icon: '/assets/icons/ic_notification.png',
    badge: '/assets/icons/ic_notification.png',
    vibrate: [200, 100, 300, 100, 200],
    actions: isPreReminder
      ? undefined
      : [
          { action: 'play_adhan', title: '🔊 بدء الأذان' },
          { action: 'stop_adhan', title: '🔇 إيقاف الأذان' },
        ],
    data: {
      screen: 'prayers',
      channelId: RIFQ_NOTIFICATION_CHANNELS.prayer,
      prayerNameAr,
      cityName,
      timeFormatted,
      url: '/?screen=prayers',
    },
  };

  try {
    if (swRegistration && 'showNotification' in swRegistration) {
      await swRegistration.showNotification(title, swOptions);
      return true;
    }

    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      const readyReg = await navigator.serviceWorker.ready.catch(() => null);
      if (readyReg && 'showNotification' in readyReg) {
        swRegistration = readyReg;
        await readyReg.showNotification(title, swOptions);
        return true;
      }
    }

    const browserNotification = new Notification(title, {
      body: message,
      tag: notificationTag,
      lang: 'ar',
      dir: 'rtl',
      icon: '/assets/icons/ic_notification.png',
    });
    browserNotification.onclick = () => {
      window.focus();
      window.dispatchEvent(new CustomEvent('rifq-navigate-prayers'));
      browserNotification.close();
    };
    return true;
  } catch (err) {
    try {
      const fallbackNotification = new Notification(title, {
        body: message,
        tag: notificationTag,
      });
      fallbackNotification.onclick = () => {
        window.focus();
        window.dispatchEvent(new CustomEvent('rifq-navigate-prayers'));
        fallbackNotification.close();
      };
      return true;
    } catch (innerErr) {
      console.debug('Prayer notification display error:', err, innerErr);
      return false;
    }
  }
}

export interface ScheduledSwNotificationItem {
  id: string;
  signatureKey: string;
  channelId: string;
  title: string;
  body: string;
  timestamp: number; // Epoch ms
  timeHHMM?: string;
  repeatDaily?: boolean;
  enabled?: boolean;
  tag: string;
  screen?: string;
  ward?: string;
  dhikrId?: string;
  prayerKey?: string;
  prayerNameAr?: string;
  cityName?: string;
  timeFormatted?: string;
  isPrayerAdhan?: boolean;
}

/**
 * Builds the complete list of today's & tomorrow's scheduled notifications across all modules
 * and synchronizes it with BOTH:
 * 1) Android Native AlarmManager (RifqNotificationsNative.syncScheduledNotifications)
 * 2) Web Service Worker (IndexedDB background worker)
 */
export function syncFullNotificationScheduleWithServiceWorker(
  extraPrayerItems?: ScheduledSwNotificationItem[]
): void {
  if (typeof window === 'undefined') return;

  if (Array.isArray(extraPrayerItems) && extraPrayerItems.length > 0) {
    cachedExtraPrayerItems = extraPrayerItems;
  }

  try {
    const unified = loadUnifiedNotificationSettings();
    const userSettings = loadSettings();
    const now = new Date();
    const todayStr = getLocalTodayString(now);
    const dayOfYear = Math.floor(
      (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000
    );

    const scheduleItems: ScheduledSwNotificationItem[] = [];

    const makeTimestampForToday = (timeStr: string): number => {
      const [h, m] = (timeStr || '00:00').split(':').map(Number);
      const dt = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h || 0, m || 0, 0, 0);
      return dt.getTime();
    };

    // 1. Morning / Evening / Sleep Athkar
    if (userSettings.remindersEnabled && unified.azkarChannelEnabled) {
      if (unified.morningAthkarEnabled) {
        const tStr = userSettings.morningReminderTime || unified.morningAthkarTime || '06:30';
        scheduleItems.push({
          id: 'azkar_morning',
          signatureKey: `${todayStr}_morning_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          title: 'حان وقت أذكار الصباح ☀️',
          body: 'حصّن يومك ونفسك بأذكار الصباح المباركة وافتتح نهارك بذكر الله وتوفيقه.',
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-azkar-morning-${todayStr}`,
          screen: 'ward',
          ward: 'morning',
        });
      }

      if (unified.eveningAthkarEnabled) {
        const tStr = userSettings.eveningReminderTime || unified.eveningAthkarTime || '17:30';
        scheduleItems.push({
          id: 'azkar_evening',
          signatureKey: `${todayStr}_evening_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          title: 'حان وقت أذكار المساء 🌙',
          body: 'أمسينا وأمسى الملك لله، بادر بقراءة ورد المساء لتحصين النفس والسكينة.',
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-azkar-evening-${todayStr}`,
          screen: 'ward',
          ward: 'evening',
        });
      }

      if (unified.sleepAthkarEnabled) {
        const tStr = unified.sleepAthkarTime || '22:00';
        scheduleItems.push({
          id: 'azkar_sleep',
          signatureKey: `${todayStr}_sleep_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
          title: 'حان وقت أذكار النوم 🌌',
          body: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا — اختم يومك بأذكار النوم وآية الكرسي لراحة القلب.',
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-azkar-sleep-${todayStr}`,
          screen: 'ward',
          ward: 'sleep',
        });
      }
    }

    // 2. Quran Channel: Ayah of the Day, Faida of the Day, Daily Quran Wird
    if (unified.quranChannelEnabled) {
      if (unified.ayahOfTheDayEnabled) {
        const tStr = unified.ayahOfTheDayTime || '08:00';
        const ayahItem = DAILY_AYAH_LIST[dayOfYear % DAILY_AYAH_LIST.length];
        scheduleItems.push({
          id: 'quran_ayah_of_day',
          signatureKey: `${todayStr}_ayah_of_day_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
          title: '📖 آية اليوم — رِفْق',
          body: `${ayahItem.ayah} (${ayahItem.surah}: ${ayahItem.number})`,
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-ayah-of-day-${todayStr}`,
          screen: 'tadabbur',
        });
      }

      if (unified.faidaOfTheDayEnabled) {
        const tStr = unified.faidaOfTheDayTime || '16:00';
        const faidaItem = DAILY_FAIDA_LIST[dayOfYear % DAILY_FAIDA_LIST.length];
        scheduleItems.push({
          id: 'quran_faida_of_day',
          signatureKey: `${todayStr}_faida_of_day_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
          title: `💡 ${faidaItem.title}`,
          body: `${faidaItem.body} (${faidaItem.source})`,
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-faida-of-day-${todayStr}`,
          screen: 'tadabbur',
        });
      }

      if (unified.quranWirdReminderEnabled) {
        const tStr = unified.quranWirdReminderTime || '19:00';
        scheduleItems.push({
          id: 'quran_daily_wird',
          signatureKey: `${todayStr}_quran_wird_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
          title: '🕌 تذكير الورد القرآني اليومي',
          body: 'اجعل لقلبك نصيباً من كتاب الله اليوم؛ ولو صفحة واحدة تنير بها يومك وصحيفة عملك.',
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-quran-wird-${todayStr}`,
          screen: 'quran',
        });
      }
    }

    // 3. Prophetic Dua of the Day & Custom Daily Reminders
    let quietHoursPayload = { enabled: false, start: '23:00', end: '04:30' };
    try {
      const rawPrefs = localStorage.getItem('rifq_daily_reminders_prefs_v1');
      if (rawPrefs) {
        const parsedPrefs = JSON.parse(rawPrefs);
        quietHoursPayload = {
          enabled: Boolean(parsedPrefs.quietHoursEnabled),
          start: parsedPrefs.quietHoursStart || '23:00',
          end: parsedPrefs.quietHoursEnd || '04:30',
        };
      }
    } catch {
      // ignore
    }

    if (unified.remindersChannelEnabled) {
      if (unified.duaOfTheDayEnabled) {
        const tStr = unified.duaOfTheDayTime || '14:00';
        const duaItem = DAILY_PROPHETIC_DUAS[dayOfYear % DAILY_PROPHETIC_DUAS.length];
        scheduleItems.push({
          id: 'dua_of_day',
          signatureKey: `${todayStr}_dua_of_day_${tStr}`,
          channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
          title: duaItem.title,
          body: `${duaItem.body} — ${duaItem.source}`,
          timestamp: makeTimestampForToday(tStr),
          timeHHMM: tStr,
          repeatDaily: true,
          enabled: true,
          tag: `rifq-dua-of-day-${todayStr}`,
          screen: 'hisn_almuslim',
        });
      }

      // Include custom/daily reminders from rifq_daily_reminders_list_v1
      try {
        const rawPrefs = localStorage.getItem('rifq_daily_reminders_prefs_v1');
        const prefs = rawPrefs ? JSON.parse(rawPrefs) : { masterEnabled: true, systemPushEnabled: true };
        const rawList = localStorage.getItem('rifq_daily_reminders_list_v1');
        if (prefs.masterEnabled !== false && prefs.systemPushEnabled !== false && rawList) {
          const list = JSON.parse(rawList);
          const todayDay = now.getDay();
          if (Array.isArray(list)) {
            for (const rem of list) {
              if (!rem.enabled) continue;
              if (Array.isArray(rem.daysOfWeek) && !rem.daysOfWeek.includes(todayDay)) continue;
              if (
                rem.id === 'rem_morning_athkar' ||
                rem.id === 'rem_evening_athkar' ||
                rem.id === 'rem_sleep_athkar'
              ) {
                continue;
              }
              scheduleItems.push({
                id: `daily_rem_${rem.id}`,
                signatureKey: `${todayStr}_${rem.id}_${rem.time}`,
                channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
                title: `تذكير رِفْق • ${rem.title}`,
                body: rem.dhikrOrDuaText,
                timestamp: makeTimestampForToday(rem.time),
                timeHHMM: rem.time,
                repeatDaily: true,
                enabled: true,
                tag: `daily-rem-${rem.id}-${todayStr}`,
                screen: rem.linkedWard ? 'ward' : 'daily_reminders',
                ward: rem.linkedWard,
              });
            }
          }
        }
      } catch {
        // ignore
      }
    }

    // 4. 5-Daily Moment Dhikr Notifications
    if (unified.azkarChannelEnabled) {
      try {
        const rawDhikrSettings = localStorage.getItem('rifq_dhikr_notification_settings_v1');
        const dhikrSettings = rawDhikrSettings
          ? JSON.parse(rawDhikrSettings)
          : {
              enabled: true,
              fajrTime: '05:00',
              duhaTime: '09:00',
              dhuhrTime: '13:00',
              asrTime: '17:00',
              nightTime: '21:00',
            };
        if (dhikrSettings.enabled !== false) {
          const slots = [
            {
              slot: 'fajr',
              time: dhikrSettings.fajrTime || '05:00',
              title: '🌅 رِفْق | بداية يومك بذكر الله',
              body: '«أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ»',
            },
            {
              slot: 'duha',
              time: dhikrSettings.duhaTime || '09:00',
              title: '☀️ رِفْق | لا تنسَ ذكر الله',
              body: '«سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ»',
            },
            {
              slot: 'dhuhr',
              time: dhikrSettings.dhuhrTime || '13:00',
              title: '🕛 رِفْق | وقت الذكر',
              body: '«لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ»',
            },
            {
              slot: 'asr',
              time: dhikrSettings.asrTime || '17:00',
              title: '🌇 رِفْق | ذكر المساء',
              body: '«أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ ربِّ العالمين»',
            },
            {
              slot: 'night',
              time: dhikrSettings.nightTime || '21:00',
              title: '🌙 رِفْق | قبل النوم',
              body: '«بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا»',
            },
          ];

          for (const s of slots) {
            scheduleItems.push({
              id: `moment_${s.slot}`,
              signatureKey: `${todayStr}_moment_${s.slot}_${s.time}`,
              channelId: RIFQ_NOTIFICATION_CHANNELS.adhkar,
              title: s.title,
              body: s.body,
              timestamp: makeTimestampForToday(s.time),
              timeHHMM: s.time,
              repeatDaily: true,
              enabled: true,
              tag: `rifq-moment-dhikr-${s.slot}-${todayStr}`,
              screen: 'moment_dhikr',
            });
          }
        }
      } catch {
        // ignore
      }
    }

    // 5. Merge prayer items (today's & tomorrow's prayer times & pre-Adhan reminders)
    const effectivePrayerItems = extraPrayerItems || cachedExtraPrayerItems;
    if (Array.isArray(effectivePrayerItems) && effectivePrayerItems.length > 0 && unified.adhanChannelEnabled) {
      scheduleItems.push(...effectivePrayerItems);
    }

    // Collect already fired keys
    let firedRegistry: Record<string, number> = {};
    try {
      const rawReg = localStorage.getItem(FIRED_NOTIFICATIONS_REGISTRY_KEY);
      if (rawReg) firedRegistry = JSON.parse(rawReg);
    } catch {
      firedRegistry = {};
    }

    // Arm a precision foreground timer for the very next upcoming notification today
    if (nextPrecisionTimeoutId) {
      clearTimeout(nextPrecisionTimeoutId);
      nextPrecisionTimeoutId = null;
    }

    const nowMs = Date.now();
    const upcomingItems = scheduleItems
      .filter((item) => item.timestamp > nowMs && !firedRegistry[item.signatureKey])
      .sort((a, b) => a.timestamp - b.timestamp);

    if (upcomingItems.length > 0) {
      const nextDelay = Math.max(500, upcomingItems[0].timestamp - nowMs + 250);
      if (nextDelay <= 2 * 60 * 60 * 1000) {
        nextPrecisionTimeoutId = setTimeout(() => {
          window.dispatchEvent(new CustomEvent('rifq-run-scheduled-checks-now'));
        }, nextDelay);
      }
    }

    const channelsMap: Record<string, boolean> = {
      rifq_prayer: unified.adhanChannelEnabled,
      rifq_adhan: unified.adhanChannelEnabled,
      rifq_quran: unified.quranChannelEnabled,
      rifq_adhkar: unified.azkarChannelEnabled,
      rifq_azkar: unified.azkarChannelEnabled,
      rifq_reminders: unified.remindersChannelEnabled,
      rifq_updates: unified.updatesChannelEnabled,
    };

    // 6.A: Sync with Android Native AlarmManager so reminders fire when app is closed / screen is off / after reboot
    if (isNativeAndroidPlatform()) {
      RifqNotificationsNative.syncScheduledNotifications({
        scheduleItems,
        channels: channelsMap,
        quietHours: quietHoursPayload,
        firedKeys: Object.keys(firedRegistry),
      }).catch((err) => {
        console.debug('Native Android schedule sync error:', err);
      });
    }

    // 6.B: Post full schedule to Service Worker for Web/PWA background monitoring
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.ready
        .then((reg) => {
          reg.active?.postMessage({
            type: 'SYNC_FULL_SCHEDULE',
            scheduleItems,
            firedKeys: Object.keys(firedRegistry),
            channels: channelsMap,
          });
        })
        .catch(() => {});
    }
  } catch (e) {
    console.debug('Failed to sync full notification schedule:', e);
  }
}

/**
 * ══════════════════════════════════════════════════════════════════════════
 * NotificationManager — المدير المركزي الحقيقي للإشعارات في «رِفْق | RIFQ»
 * يجمع بين Android System Notifications (شريط إشعارات الجهاز) و Notification Center داخل التطبيق
 * ══════════════════════════════════════════════════════════════════════════
 */
export class NotificationManager {
  static readonly generalChannelId = 'rifq_general';
  static readonly adhanChannelId = 'rifq_prayer';
  static readonly prayerChannelId = 'rifq_prayer';
  static readonly quranChannelId = 'rifq_quran';
  static readonly azkarChannelId = 'rifq_adhkar';
  static readonly adhkarChannelId = 'rifq_adhkar';
  static readonly remindersChannelId = 'rifq_reminders';
  static readonly updatesChannelId = 'rifq_updates';

  static async init(): Promise<void> {
    await initPushNotifications();
  }

  static async getDetailedStatus(): Promise<NativeNotificationStatusResult> {
    if (isNativeAndroidPlatform()) {
      const nativeStatus = await refreshNativeNotificationStatus();
      if (nativeStatus) {
        return nativeStatus;
      }
    }

    const supported = isNotificationSupported();
    const perm = supported && typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'denied';
    const granted = perm === 'granted';
    const permanentlyBlocked = perm === 'denied';
    const unified = loadUnifiedNotificationSettings();

    return {
      granted,
      systemNotificationsEnabled: granted,
      postNotificationsPermission: granted ? 'granted' : permanentlyBlocked ? 'denied' : 'prompt',
      permanentlyBlocked,
      sdkInt: 33,
      canScheduleExactAlarms: true,
      channels: [
        {
          id: 'rifq_general',
          nameAr: 'إشعارات رِفْق العامة',
          descriptionAr: 'التنبيهات والإشعارات العامة والتجريبية في تطبيق رِفْق',
          systemEnabled: granted,
          appEnabled: true,
          effectiveEnabled: granted,
        },
        {
          id: 'rifq_adhkar',
          nameAr: 'الأذكار اليومية',
          descriptionAr: 'تنبيهات أذكار الصباح والمساء وأذكار النوم وذكر اللحظة',
          systemEnabled: granted,
          appEnabled: unified.azkarChannelEnabled,
          effectiveEnabled: granted && unified.azkarChannelEnabled,
        },
        {
          id: 'rifq_prayer',
          nameAr: 'مواقيت الصلاة والأذان',
          descriptionAr: 'تنبيهات دخول وقت الصلاة والتذكير قبل الأذان ووضع الصلاة',
          systemEnabled: granted,
          appEnabled: unified.adhanChannelEnabled,
          effectiveEnabled: granted && unified.adhanChannelEnabled,
        },
        {
          id: 'rifq_reminders',
          nameAr: 'التذكيرات والأدعية اليومية',
          descriptionAr: 'التذكيرات اليومية المخصصة ودعاء اليوم المأثور والتسبيح',
          systemEnabled: granted,
          appEnabled: unified.remindersChannelEnabled,
          effectiveEnabled: granted && unified.remindersChannelEnabled,
        },
        {
          id: 'rifq_quran',
          nameAr: 'الورد القرآني وآية وفائدة اليوم',
          descriptionAr: 'تذكير الورد القرآني اليومي وآية اليوم وفائدة اليوم',
          systemEnabled: granted,
          appEnabled: unified.quranChannelEnabled,
          effectiveEnabled: granted && unified.quranChannelEnabled,
        },
        {
          id: 'rifq_updates',
          nameAr: 'التحديثات والرسائل العامة',
          descriptionAr: 'إشعارات التحديثات والرسائل الإيمانية العامة عبر السحابة',
          systemEnabled: granted,
          appEnabled: unified.updatesChannelEnabled,
          effectiveEnabled: granted && unified.updatesChannelEnabled,
        },
      ],
    };
  }

  static async areNotificationsEnabled(): Promise<boolean> {
    if (isNativeAndroidPlatform()) {
      const status = await refreshNativeNotificationStatus();
      return Boolean(status?.granted);
    }
    if (!isNotificationSupported()) return false;
    return Notification.permission === 'granted';
  }

  static async isPermanentlyBlockedInSystem(): Promise<boolean> {
    if (isNativeAndroidPlatform()) {
      const status = await refreshNativeNotificationStatus();
      if (!status) return false;
      return Boolean(status.permanentlyBlocked || !status.systemNotificationsEnabled);
    }
    if (!isNotificationSupported()) return false;
    return Notification.permission === 'denied';
  }

  static async requestPermission(): Promise<boolean> {
    const res = await requestNotificationPermission();
    return res === 'granted';
  }

  static async openSettings(channelId?: string): Promise<boolean> {
    return await openSystemNotificationSettings(channelId);
  }

  static isChannelEnabled(channelId: string): boolean {
    return isNotificationChannelEnabled(channelId);
  }

  static setChannelEnabled(channelId: string, enabled: boolean): void {
    setNotificationChannelEnabled(channelId, enabled);
  }

  static async showNotification(params: {
    id: number;
    title: string;
    body: string;
    channelId?: string;
    screen?: ScreenType;
    ward?: WardType;
    dhikrId?: string;
    payload?: string;
    bypassChannelCheck?: boolean;
    recordInCenter?: boolean;
  }): Promise<boolean> {
    const enabled = await NotificationManager.areNotificationsEnabled();
    if (!enabled) {
      return false;
    }

    const chId = normalizeRifqChannelId(params.channelId || NotificationManager.generalChannelId);
    if (
      !params.bypassChannelCheck &&
      chId !== NotificationManager.generalChannelId &&
      !NotificationManager.isChannelEnabled(chId)
    ) {
      return false;
    }

    return await triggerPushNotification({
      title: params.title,
      message: params.body,
      channelId: chId,
      screen: params.screen,
      ward: params.ward,
      dhikrId: params.dhikrId,
      bypassChannelCheck: params.bypassChannelCheck,
      recordInCenter: params.recordInCenter ?? true,
      tag: `${chId}-${params.id}-${Date.now()}`,
    });
  }
}
