import { db, doc, getDoc, setDoc } from './firebase';
import {
  loadHistory,
  saveHistory,
  loadSettings,
  saveSettings,
  loadFavorites,
  saveFavorites,
  loadCustomAthkar,
  saveCustomAthkar,
  loadWardProgress,
  saveWardProgress,
  getDefaultSettings,
  getTodayDateString,
  calculateTotalLifetimeTasbeeh,
  calculateStreaks,
  calculateRank,
  setStorageCloudHydrationLock,
} from './storage';
import {
  exportMisbahaUserPayload,
  hydrateMisbahaUserPayload,
  invalidateMisbahaMemoryCache,
  MisbahaCloudPayload,
} from './misbahaSqlite';
import {
  loadRosaryState,
  saveRosaryState,
  loadRosaryHistory,
  saveRosaryHistory,
  getDefaultRosaryState,
  RosaryState,
  RosarySessionLog,
} from './rosaryStorage';
import {
  loadUnifiedNotificationSettings,
  saveUnifiedNotificationSettings,
  UnifiedNotificationSettings,
} from './notifications';
import { loadHadithFavorites, saveHadithFavorites } from './hadithStorage';
import { evaluateAchievementBadges } from './achievementBadges';
import { DailyRecord, DhikrItem, UserSettings } from '../types';

export interface SyncResult {
  success: boolean;
  message: string;
  syncedAt: number;
  mutationId?: string;
}

export interface IsolatedAccountSnapshot {
  uid: string;
  savedAt: number;
  settings: UserSettings;
  notificationSettings: UnifiedNotificationSettings;
  history: Record<string, DailyRecord>;
  favorites: string[];
  customAthkar: DhikrItem[];
  wardProgressByDate: Record<string, Record<string, number>>;
  hisnFavAthkar: string[];
  hisnFavChapters: number[];
  hadithFavorites: string[];
  misbaha: MisbahaCloudPayload;
  rosaryState: RosaryState;
  rosaryHistory: RosarySessionLog[];
}

const PRE_SYNC_BACKUP_KEY = 'mushaba_pre_sync_backup';
const ACCOUNT_SNAPSHOT_PREFIX = 'rifq_user_isolated_store_';
const ACTIVE_ACCOUNT_UID_KEY = 'rifq_active_account_uid_v1';

let lastLocalMutationId = '';
const recentLocalMutationIds = new Set<string>();
let activeCloudSyncCount = 0;

export function getLastLocalMutationId(): string {
  return lastLocalMutationId;
}

export function hasLocalMutationId(mutationId: string): boolean {
  if (!mutationId) return false;
  return mutationId === lastLocalMutationId || recentLocalMutationIds.has(mutationId);
}

export function isCloudSyncInProgress(): boolean {
  return activeCloudSyncCount > 0;
}

function registerLocalMutationId(mutationId: string): void {
  lastLocalMutationId = mutationId;
  recentLocalMutationIds.add(mutationId);
  if (recentLocalMutationIds.size > 100) {
    const first = recentLocalMutationIds.values().next().value;
    if (first) recentLocalMutationIds.delete(first);
  }
}

export function getActiveStoredAccountUid(): string {
  try {
    return localStorage.getItem(ACTIVE_ACCOUNT_UID_KEY) || 'guest';
  } catch {
    return 'guest';
  }
}

export function setActiveStoredAccountUid(uid: string): void {
  try {
    localStorage.setItem(ACTIVE_ACCOUNT_UID_KEY, uid || 'guest');
  } catch {
    // ignore
  }
}

function loadHisnFavAthkar(): string[] {
  try {
    const raw = localStorage.getItem('rifq_hisn_fav_athkar');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveHisnFavAthkar(ids: string[]): void {
  try {
    localStorage.setItem('rifq_hisn_fav_athkar', JSON.stringify(ids));
  } catch {
    // ignore
  }
}

function loadHisnFavChapters(): number[] {
  try {
    const raw = localStorage.getItem('rifq_hisn_fav_chapters');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveHisnFavChapters(ids: number[]): void {
  try {
    localStorage.setItem('rifq_hisn_fav_chapters', JSON.stringify(ids));
  } catch {
    // ignore
  }
}

/**
 * Collect current active user's full Misbaha, Athkar, and Settings state
 */
export function captureCurrentLocalSnapshot(uid: string): IsolatedAccountSnapshot {
  const today = getTodayDateString();
  const currentWard = loadWardProgress();
  return {
    uid,
    savedAt: Date.now(),
    settings: loadSettings(),
    notificationSettings: loadUnifiedNotificationSettings(),
    history: loadHistory(),
    favorites: loadFavorites(),
    customAthkar: loadCustomAthkar(),
    wardProgressByDate: {
      [today]: currentWard,
    },
    hisnFavAthkar: loadHisnFavAthkar(),
    hisnFavChapters: loadHisnFavChapters(),
    hadithFavorites: loadHadithFavorites(),
    misbaha: exportMisbahaUserPayload(),
    rosaryState: loadRosaryState(),
    rosaryHistory: loadRosaryHistory(),
  };
}

/**
 * Save a user's isolated snapshot in localStorage so switching accounts offline or online never mixes data
 */
export function saveIsolatedAccountSnapshot(uid: string, snapshot?: IsolatedAccountSnapshot): void {
  try {
    const data = snapshot || captureCurrentLocalSnapshot(uid);
    localStorage.setItem(`${ACCOUNT_SNAPSHOT_PREFIX}${uid}`, JSON.stringify(data));
  } catch (e) {
    console.warn('Could not save isolated account snapshot:', e);
  }
}

export function loadIsolatedAccountSnapshot(uid: string): IsolatedAccountSnapshot | null {
  try {
    const raw = localStorage.getItem(`${ACCOUNT_SNAPSHOT_PREFIX}${uid}`);
    if (!raw) return null;
    return JSON.parse(raw) as IsolatedAccountSnapshot;
  } catch {
    return null;
  }
}

/**
 * Apply an isolated snapshot (or clean fresh state for a new user) to active local storage
 * without triggering recursive mutation writebacks.
 */
export function applyIsolatedSnapshotToActiveStorage(
  uid: string,
  snapshot: Partial<IsolatedAccountSnapshot> | null
): void {
  setStorageCloudHydrationLock(true);
  try {
    const today = getTodayDateString();
    const cleanHistory: Record<string, DailyRecord> = {
      [today]: {
        date: today,
        totalCount: 0,
        sessionsCount: 0,
        completedAthkarCount: 0,
        freeCount: 0,
        hourlyCounts: new Array(24).fill(0),
        dhikrCounts: {},
      },
    };

    const currentExistingSettings = loadSettings();
    const deviceOnboardingCompleted = Boolean(
      currentExistingSettings.hasCompletedOnboarding ||
        snapshot?.settings?.hasCompletedOnboarding ||
        localStorage.getItem('rifq_onboarding_completed_v1') === 'true'
    );
    if (deviceOnboardingCompleted) {
      try {
        localStorage.setItem('rifq_onboarding_completed_v1', 'true');
      } catch {
        // ignore
      }
    }

    const nextSettings: UserSettings = {
      ...getDefaultSettings(),
      ...(snapshot?.settings || {}),
      hasCompletedOnboarding: deviceOnboardingCompleted,
    };
    const nextHistory: Record<string, DailyRecord> =
      snapshot?.history && Object.keys(snapshot.history).length > 0
        ? { ...snapshot.history }
        : { ...cleanHistory };
    if (!nextHistory[today]) {
      nextHistory[today] = cleanHistory[today];
    }
    const nextFavorites = Array.isArray(snapshot?.favorites)
      ? snapshot.favorites
      : ['q-1', 's-1'];
    const nextCustomAthkar = Array.isArray(snapshot?.customAthkar)
      ? snapshot.customAthkar
      : [];
    const nextWardToday =
      snapshot?.wardProgressByDate?.[today] || {};
    const nextHisnAthkar = Array.isArray(snapshot?.hisnFavAthkar)
      ? snapshot.hisnFavAthkar
      : [];
    const nextHisnChapters = Array.isArray(snapshot?.hisnFavChapters)
      ? snapshot.hisnFavChapters
      : [];
    const nextHadithFavs = Array.isArray(snapshot?.hadithFavorites)
      ? snapshot.hadithFavorites
      : [];
    const nextRosaryState = {
      ...getDefaultRosaryState(),
      ...(snapshot?.rosaryState || {}),
    };
    const nextRosaryHistory = Array.isArray(snapshot?.rosaryHistory)
      ? snapshot.rosaryHistory
      : [];

    saveSettings(nextSettings);
    saveHistory(nextHistory);
    saveFavorites(nextFavorites);
    saveCustomAthkar(nextCustomAthkar);
    saveWardProgress(nextWardToday);
    saveHisnFavAthkar(nextHisnAthkar);
    saveHisnFavChapters(nextHisnChapters);
    saveHadithFavorites(nextHadithFavs);
    saveRosaryState(nextRosaryState);
    saveRosaryHistory(nextRosaryHistory);

    hydrateMisbahaUserPayload(snapshot?.misbaha || null);

    if (snapshot?.notificationSettings) {
      saveUnifiedNotificationSettings(snapshot.notificationSettings);
    }
  } finally {
    setStorageCloudHydrationLock(false);
  }

  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-user-data-synced', {
        detail: { uid, timestamp: Date.now() },
      })
    );
  }
}

/**
 * Switch the active account context cleanly when logging in, logging out, or switching accounts.
 * Saves the outgoing account's snapshot, and hydrates the incoming account's isolated snapshot.
 */
export function switchActiveUserStorageContext(newUid: string): {
  previousUid: string;
  hadExistingSnapshotForNewUser: boolean;
} {
  const prevUid = getActiveStoredAccountUid();
  if (prevUid !== newUid) {
    // 1. Save outgoing user's data into their isolated slot
    saveIsolatedAccountSnapshot(prevUid);
    // 2. Clear in-memory Misbaha SQLite cache so it doesn't leak across accounts
    invalidateMisbahaMemoryCache();
  }

  setActiveStoredAccountUid(newUid);
  const existingSnapshot = loadIsolatedAccountSnapshot(newUid);

  if (prevUid !== newUid) {
    if (existingSnapshot) {
      applyIsolatedSnapshotToActiveStorage(newUid, existingSnapshot);
      return { previousUid: prevUid, hadExistingSnapshotForNewUser: true };
    } else if (prevUid !== 'guest') {
      // Switching directly from Account A to a brand-new Account B on this device:
      // Reset active storage to clean defaults so Account A's Misbaha & Athkar never leak into Account B!
      applyIsolatedSnapshotToActiveStorage(newUid, null);
      return { previousUid: prevUid, hadExistingSnapshotForNewUser: false };
    }
  }

  return {
    previousUid: prevUid,
    hadExistingSnapshotForNewUser: Boolean(existingSnapshot),
  };
}

/**
 * Creates a local backup before synchronizing with the cloud
 */
function createPreSyncBackup(): void {
  try {
    const backupData = {
      timestamp: Date.now(),
      history: localStorage.getItem('mushaba_history_v1'),
      settings: localStorage.getItem('mushaba_settings_v1'),
      favorites: localStorage.getItem('mushaba_favorites_v1'),
      customAthkar: localStorage.getItem('mushaba_custom_athkar_v1'),
      hadithFavorites: localStorage.getItem('rafiq_hadith_favorites'),
    };
    localStorage.setItem(PRE_SYNC_BACKUP_KEY, JSON.stringify(backupData));
  } catch (e) {
    console.warn('Could not create local pre-sync backup', e);
  }
}

/**
 * Apply a remote Firestore document snapshot directly to the active user's local storage in real-time
 */
export function applyCloudSnapshotToLocal(uid: string, cloudData: Record<string, any>): void {
  if (!cloudData) return;

  const today = getTodayDateString();
  const currentLocal = captureCurrentLocalSnapshot(uid);

  const cloudAthkar = cloudData.athkarData || {};
  const cloudMisbaha = cloudData.misbahaData || {};

  const cloudSettingsObj = (cloudData.settings || {}) as Partial<UserSettings>;
  const resolvedThemeId = (cloudData.themeId || cloudSettingsObj.themeId || currentLocal.settings.themeId || 'default') as UserSettings['themeId'];
  const resolvedThemeMode = (cloudData.themeMode || cloudSettingsObj.themeMode || currentLocal.settings.themeMode || 'light') as UserSettings['themeMode'];

  const deviceOnboardingCompleted = Boolean(
    currentLocal.settings.hasCompletedOnboarding ||
      cloudSettingsObj.hasCompletedOnboarding ||
      localStorage.getItem('rifq_onboarding_completed_v1') === 'true'
  );

  const mergedSettings: UserSettings = {
    ...currentLocal.settings,
    ...cloudSettingsObj,
    hasCompletedOnboarding: deviceOnboardingCompleted,
    themeId: resolvedThemeId,
    themeMode: resolvedThemeMode,
    themeUpdatedAt: (cloudData.themeUpdatedAt || cloudSettingsObj.themeUpdatedAt || currentLocal.settings.themeUpdatedAt) as string | undefined,
  };

  const mergedNotificationSettings: UnifiedNotificationSettings = {
    ...currentLocal.notificationSettings,
    ...(cloudData.notificationSettings || {}),
  };

  const cloudHistory = (cloudAthkar.history || cloudData.history || {}) as Record<string, DailyRecord>;
  const cloudFavorites = (cloudAthkar.favorites || cloudData.favorites || currentLocal.favorites) as string[];
  const cloudCustomAthkar = (cloudAthkar.customAthkar || cloudData.customAthkar || currentLocal.customAthkar) as DhikrItem[];
  const cloudWardByDate = (cloudAthkar.wardProgress || cloudData.wardProgress || currentLocal.wardProgressByDate) as Record<string, Record<string, number>>;
  const cloudHisnFavAthkar = (cloudAthkar.hisnFavAthkar || currentLocal.hisnFavAthkar) as string[];
  const cloudHisnFavChapters = (cloudAthkar.hisnFavChapters || currentLocal.hisnFavChapters) as number[];
  const cloudHadithFavs = (cloudAthkar.hadithFavorites || cloudData.hadithFavorites || currentLocal.hadithFavorites) as string[];

  const snapshotToApply: IsolatedAccountSnapshot = {
    uid,
    savedAt: Date.now(),
    settings: mergedSettings,
    notificationSettings: mergedNotificationSettings,
    history: Object.keys(cloudHistory).length > 0 ? cloudHistory : currentLocal.history,
    favorites: cloudFavorites,
    customAthkar: cloudCustomAthkar,
    wardProgressByDate: {
      ...currentLocal.wardProgressByDate,
      ...cloudWardByDate,
      [today]: {
        ...(currentLocal.wardProgressByDate[today] || {}),
        ...(cloudWardByDate?.[today] || {}),
      },
    },
    hisnFavAthkar: cloudHisnFavAthkar,
    hisnFavChapters: cloudHisnFavChapters,
    hadithFavorites: cloudHadithFavs,
    misbaha: {
      sessions: Array.isArray(cloudMisbaha.sessions)
        ? cloudMisbaha.sessions
        : currentLocal.misbaha.sessions,
      customAdhkar: Array.isArray(cloudMisbaha.customAdhkar)
        ? cloudMisbaha.customAdhkar
        : currentLocal.misbaha.customAdhkar,
      dailyStats: Array.isArray(cloudMisbaha.dailyStats)
        ? cloudMisbaha.dailyStats
        : currentLocal.misbaha.dailyStats,
      settings: {
        ...currentLocal.misbaha.settings,
        ...(cloudMisbaha.settings || {}),
        id: 1,
      },
      streak: {
        ...currentLocal.misbaha.streak,
        ...(cloudMisbaha.streak || {}),
        id: 1,
      },
    },
    rosaryState: {
      ...currentLocal.rosaryState,
      ...(cloudMisbaha.rosaryState || {}),
    },
    rosaryHistory: Array.isArray(cloudMisbaha.rosaryHistory)
      ? cloudMisbaha.rosaryHistory
      : currentLocal.rosaryHistory,
  };

  applyIsolatedSnapshotToActiveStorage(uid, snapshotToApply);
  saveIsolatedAccountSnapshot(uid, snapshotToApply);
}

/**
 * Push the current user's Misbaha, Athkar, and Settings directly to Firestore (used for real-time live sync)
 */
export async function pushUserDataToFirestore(uid: string): Promise<SyncResult> {
  activeCloudSyncCount += 1;
  try {
    if (!uid) {
      return { success: false, message: 'المستخدم غير مسجل الدخول', syncedAt: Date.now() };
    }

    const snap = captureCurrentLocalSnapshot(uid);
    saveIsolatedAccountSnapshot(uid, snap);

    const totalTasbeeh = Math.max(
      calculateTotalLifetimeTasbeeh(snap.history),
      snap.misbaha.dailyStats.reduce((sum, r) => sum + (r.total_count || 0), 0)
    );
    const { currentStreak, longestStreak } = calculateStreaks(snap.history);
    const rank = calculateRank(totalTasbeeh);
    const completedAthkar = Object.values(snap.history).reduce(
      (sum, r) => sum + (r.completedAthkarCount || 0),
      0
    );

    const mutationId = `mut_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    registerLocalMutationId(mutationId);

    const userDocRef = doc(db, 'users', uid);
    await setDoc(
      userDocRef,
      {
        uid,
        themeId: snap.settings.themeId || 'default',
        themeMode: snap.settings.themeMode || 'light',
        themeUpdatedAt: snap.settings.themeUpdatedAt || new Date().toISOString(),
        settings: snap.settings,
        notificationSettings: snap.notificationSettings,
        history: snap.history,
        favorites: snap.favorites,
        customAthkar: snap.customAthkar,
        hadithFavorites: snap.hadithFavorites,
        wardProgress: snap.wardProgressByDate,
        misbahaData: {
          sessions: snap.misbaha.sessions.slice(0, 150),
          customAdhkar: snap.misbaha.customAdhkar,
          dailyStats: snap.misbaha.dailyStats.slice(-180),
          settings: snap.misbaha.settings,
          streak: snap.misbaha.streak,
          rosaryState: snap.rosaryState,
          rosaryHistory: snap.rosaryHistory.slice(0, 100),
        },
        athkarData: {
          history: snap.history,
          customAthkar: snap.customAthkar,
          favorites: snap.favorites,
          wardProgress: snap.wardProgressByDate,
          hisnFavAthkar: snap.hisnFavAthkar,
          hisnFavChapters: snap.hisnFavChapters,
          hadithFavorites: snap.hadithFavorites,
        },
        stats: {
          totalTasbeeh,
          currentStreak: Math.max(currentStreak, snap.misbaha.streak.current_streak || 0),
          longestStreak: Math.max(longestStreak, snap.misbaha.streak.longest_streak || 0),
          completedAthkar,
          rank: rank.name,
          hadithsRead: snap.hadithFavorites.length,
          customAthkarCount: snap.customAthkar.length + snap.misbaha.customAdhkar.length,
          unlockedBadges: evaluateAchievementBadges(snap.history).unlockedBadges.map((b) => b.id),
        },
        lastMutationId: mutationId,
        lastSyncedAt: Date.now(),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    return {
      success: true,
      message: 'تمت مزامنة بيانات المسبحة والأذكار والإعدادات لحظياً ✅',
      syncedAt: Date.now(),
      mutationId,
    };
  } catch (error: unknown) {
    const err = error as Error;
    return {
      success: false,
      message: err?.message || 'تم الحفظ محلياً وستتم المزامنة عند توفر الاتصال',
      syncedAt: Date.now(),
    };
  } finally {
    activeCloudSyncCount = Math.max(0, activeCloudSyncCount - 1);
  }
}

/**
 * Perform a full two-way synchronization between the user's isolated LocalStorage and Firebase Firestore
 */
export async function syncUserDataWithFirestore(uid: string): Promise<SyncResult> {
  activeCloudSyncCount += 1;
  try {
    if (!uid) {
      return { success: false, message: 'المستخدم غير مسجل الدخول', syncedAt: Date.now() };
    }

    createPreSyncBackup();

    const userDocRef = doc(db, 'users', uid);
    const snap = await getDoc(userDocRef);

    const localSnap = captureCurrentLocalSnapshot(uid);

    if (!snap.exists() || (!snap.data()?.misbahaData && !snap.data()?.history && !snap.data()?.settings)) {
      // Brand new cloud document for this user: upload their isolated snapshot
      return await pushUserDataToFirestore(uid);
    }

    const cloudData = snap.data();
    const cloudAthkar = cloudData.athkarData || {};
    const cloudMisbaha = cloudData.misbahaData || {};

    // 1. Merge History for this specific user (Dates: combine daily records, highest counts win)
    const cloudHistory = (cloudAthkar.history || cloudData.history || {}) as Record<string, DailyRecord>;
    const mergedHistory: Record<string, DailyRecord> = { ...localSnap.history };

    for (const [date, cloudRecord] of Object.entries(cloudHistory)) {
      if (!mergedHistory[date]) {
        mergedHistory[date] = cloudRecord;
      } else {
        const localRec = mergedHistory[date];
        mergedHistory[date] = {
          date,
          totalCount: Math.max(localRec.totalCount || 0, cloudRecord.totalCount || 0),
          sessionsCount: Math.max(localRec.sessionsCount || 0, cloudRecord.sessionsCount || 0),
          completedAthkarCount: Math.max(
            localRec.completedAthkarCount || 0,
            cloudRecord.completedAthkarCount || 0
          ),
          freeCount: Math.max(localRec.freeCount || 0, cloudRecord.freeCount || 0),
          hourlyCounts: (localRec.hourlyCounts || new Array(24).fill(0)).map((cnt, idx) =>
            Math.max(cnt || 0, (cloudRecord.hourlyCounts && cloudRecord.hourlyCounts[idx]) || 0)
          ),
          dhikrCounts: {
            ...(cloudRecord.dhikrCounts || {}),
            ...(localRec.dhikrCounts || {}),
          },
        };
      }
    }

    // 2. Merge Misbaha Daily Stats for this specific user
    const cloudDailyStats = Array.isArray(cloudMisbaha.dailyStats) ? cloudMisbaha.dailyStats : [];
    const dailyStatsMap = new Map<string, any>();
    for (const row of localSnap.misbaha.dailyStats) {
      dailyStatsMap.set(row.date, { ...row });
    }
    for (const cRow of cloudDailyStats) {
      if (!cRow?.date) continue;
      const existing = dailyStatsMap.get(cRow.date);
      if (!existing || (cRow.total_count || 0) > (existing.total_count || 0)) {
        dailyStatsMap.set(cRow.date, { ...cRow });
      }
    }

    // 3. Merge Misbaha Sessions by ID
    const cloudSessions = Array.isArray(cloudMisbaha.sessions) ? cloudMisbaha.sessions : [];
    const sessionsMap = new Map<string, any>();
    for (const s of [...cloudSessions, ...localSnap.misbaha.sessions]) {
      if (s?.id) sessionsMap.set(s.id, s);
    }
    const mergedMisbahaSessions = Array.from(sessionsMap.values()).sort((a, b) =>
      String(b.created_at || '').localeCompare(String(a.created_at || ''))
    );

    // 4. Merge Misbaha Custom Adhkar by ID
    const cloudCustomMisbaha = Array.isArray(cloudMisbaha.customAdhkar) ? cloudMisbaha.customAdhkar : [];
    const customMisbahaMap = new Map<string, any>();
    for (const c of [...cloudCustomMisbaha, ...localSnap.misbaha.customAdhkar]) {
      if (c?.id) customMisbahaMap.set(c.id, c);
    }
    const mergedMisbahaCustom = Array.from(customMisbahaMap.values());

    // 5. Merge Athkar Favorites & Custom Athkar
    const cloudFavorites = (cloudAthkar.favorites || cloudData.favorites || []) as string[];
    const mergedFavorites = Array.from(new Set([...localSnap.favorites, ...cloudFavorites]));

    const cloudCustomAthkar = (cloudAthkar.customAthkar || cloudData.customAthkar || []) as DhikrItem[];
    const customAthkarMap = new Map<string, DhikrItem>();
    cloudCustomAthkar.forEach((item) => {
      if (item?.id) customAthkarMap.set(item.id, item);
    });
    localSnap.customAthkar.forEach((item) => {
      if (item?.id) customAthkarMap.set(item.id, item);
    });
    const mergedCustomAthkar = Array.from(customAthkarMap.values());

    // 6. Merge Ward Progress & Hisn Favorites
    const today = getTodayDateString();
    const cloudWardAll = (cloudAthkar.wardProgress || cloudData.wardProgress || {}) as Record<
      string,
      Record<string, number>
    >;
    const cloudWardToday = cloudWardAll[today] || {};
    const localWardToday = localSnap.wardProgressByDate[today] || {};
    const mergedWardToday: Record<string, number> = { ...cloudWardToday };
    for (const [dhikrId, cnt] of Object.entries(localWardToday)) {
      mergedWardToday[dhikrId] = Math.max(cnt || 0, mergedWardToday[dhikrId] || 0);
    }

    const mergedHisnAthkar = Array.from(
      new Set([...localSnap.hisnFavAthkar, ...(cloudAthkar.hisnFavAthkar || [])])
    );
    const mergedHisnChapters = Array.from(
      new Set([...localSnap.hisnFavChapters, ...(cloudAthkar.hisnFavChapters || [])])
    );
    const mergedHadithFavs = Array.from(
      new Set([
        ...localSnap.hadithFavorites,
        ...(cloudAthkar.hadithFavorites || cloudData.hadithFavorites || []),
      ])
    );

    // 7. Settings & Theme Conflict Resolution Strategy:
    // - Compare themeUpdatedAt between local and cloud (or use cloud's saved theme if user switched accounts).
    // - If the user had customized a non-default theme locally more recently than the cloud timestamp, keep local choice and sync it up.
    const cloudSettingsObj = (cloudData.settings || {}) as Partial<UserSettings>;
    const cloudThemeId = (cloudData.themeId || cloudSettingsObj.themeId) as UserSettings['themeId'];
    const cloudThemeMode = (cloudData.themeMode || cloudSettingsObj.themeMode) as UserSettings['themeMode'];
    const cloudThemeTime = new Date(cloudData.themeUpdatedAt || cloudSettingsObj.themeUpdatedAt || 0).getTime();
    const localThemeTime = new Date(localSnap.settings.themeUpdatedAt || 0).getTime();

    const useLocalTheme =
      localThemeTime > cloudThemeTime &&
      Boolean(localSnap.settings.themeId) &&
      (!cloudThemeId || cloudThemeId === 'default' || localThemeTime > cloudThemeTime);

    const deviceOnboardingCompleted = Boolean(
      localSnap.settings.hasCompletedOnboarding ||
        cloudSettingsObj.hasCompletedOnboarding ||
        localStorage.getItem('rifq_onboarding_completed_v1') === 'true'
    );

    const mergedSettings: UserSettings = {
      ...localSnap.settings,
      ...cloudSettingsObj,
      hasCompletedOnboarding: deviceOnboardingCompleted,
      themeId: useLocalTheme
        ? localSnap.settings.themeId || 'default'
        : cloudThemeId || localSnap.settings.themeId || 'default',
      themeMode: useLocalTheme
        ? localSnap.settings.themeMode || 'light'
        : cloudThemeMode || localSnap.settings.themeMode || 'light',
      themeUpdatedAt: useLocalTheme
        ? localSnap.settings.themeUpdatedAt
        : (cloudData.themeUpdatedAt || cloudSettingsObj.themeUpdatedAt || localSnap.settings.themeUpdatedAt),
    };

    const mergedNotificationSettings: UnifiedNotificationSettings = {
      ...localSnap.notificationSettings,
      ...(cloudData.notificationSettings || {}),
    };

    const mergedMisbahaSettings = {
      ...localSnap.misbaha.settings,
      ...(cloudMisbaha.settings || {}),
      total_cycles: Math.max(
        localSnap.misbaha.settings.total_cycles || 0,
        cloudMisbaha.settings?.total_cycles || 0
      ),
      id: 1,
    };

    const mergedSnapshot: IsolatedAccountSnapshot = {
      uid,
      savedAt: Date.now(),
      settings: mergedSettings,
      notificationSettings: mergedNotificationSettings,
      history: mergedHistory,
      favorites: mergedFavorites,
      customAthkar: mergedCustomAthkar,
      wardProgressByDate: {
        ...cloudWardAll,
        [today]: mergedWardToday,
      },
      hisnFavAthkar: mergedHisnAthkar,
      hisnFavChapters: mergedHisnChapters,
      hadithFavorites: mergedHadithFavs,
      misbaha: {
        sessions: mergedMisbahaSessions,
        customAdhkar: mergedMisbahaCustom,
        dailyStats: Array.from(dailyStatsMap.values()),
        settings: mergedMisbahaSettings,
        streak: {
          ...localSnap.misbaha.streak,
          ...(cloudMisbaha.streak || {}),
          id: 1,
        },
      },
      rosaryState: {
        ...localSnap.rosaryState,
        ...(cloudMisbaha.rosaryState || {}),
      },
      rosaryHistory: Array.isArray(cloudMisbaha.rosaryHistory)
        ? cloudMisbaha.rosaryHistory
        : localSnap.rosaryHistory,
    };

    // Apply merged data to local active storage and save isolated snapshot
    applyIsolatedSnapshotToActiveStorage(uid, mergedSnapshot);
    saveIsolatedAccountSnapshot(uid, mergedSnapshot);

    // Push unified state back to Firestore
    await pushUserDataToFirestore(uid);

    return {
      success: true,
      message: 'تمت المزامنة السحابية لبيانات المسبحة والأذكار والإعدادات بنجاح ✅',
      syncedAt: Date.now(),
    };
  } catch (error: unknown) {
    const err = error as Error;
    const errMsg = err?.message || '';
    const isOffline =
      errMsg.includes('unavailable') || errMsg.includes('offline') || errMsg.includes('network');
    console.warn('Cloud synchronization note:', errMsg);
    return {
      success: false,
      message: isOffline
        ? 'تم حفظ بياناتك محلياً في جهازك (وضع عدم الاتصال)، وستتم المزامنة السحابية تلقائياً فور توفر الاتصال ☁️'
        : errMsg || 'تعذرت المزامنة السحابية مؤقتاً',
      syncedAt: Date.now(),
    };
  } finally {
    activeCloudSyncCount = Math.max(0, activeCloudSyncCount - 1);
  }
}
