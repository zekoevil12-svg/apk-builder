import { DailyRecord } from '../types';
import { calculateStreaks, calculateTotalLifetimeTasbeeh } from './storage';

const UNLOCKED_BADGES_STORAGE_KEY = 'rifq_achievement_badges_v1';

export type BadgeCategory = 'streak' | 'athkar' | 'tasbeeh';

export interface AchievementBadgeDefinition {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  category: BadgeCategory;
  targetValue: number;
  unitLabel: string;
  accentColor: string;
  isFeatured7Day?: boolean;
}

export interface AchievementBadgeStatus extends AchievementBadgeDefinition {
  isUnlocked: boolean;
  currentValue: number;
  progressPercent: number;
  unlockedAt?: string;
  timesEarned?: number;
}

export interface SevenDayChallengeProgress {
  currentStreak: number;
  longestStreak: number;
  daysInCurrentCycle: number; // 0..7
  completedSevenDayCycles: number;
  remainingDaysForNextBadge: number;
  isSevenDayBadgeUnlocked: boolean;
  lastSevenDaysChain: {
    dayIndex: number; // 1..7
    label: string;
    isCompleted: boolean;
    isCurrentTarget: boolean;
  }[];
}

export const ACHIEVEMENT_BADGES_CATALOG: AchievementBadgeDefinition[] = [
  {
    id: 'streak_7_days',
    title: 'وسام المواظب السبعي',
    subtitle: 'إكمال 7 أيام متتالية من الأذكار',
    description: 'يُمنح للمواظب الذي أتمّ 7 أيام متتالية دون انقطاع في قراءة الأذكار والتسبيح اليومي.',
    icon: '🏅',
    category: 'streak',
    targetValue: 7,
    unitLabel: 'أيام متتالية',
    accentColor: '#E8B84A',
    isFeatured7Day: true,
  },
  {
    id: 'streak_3_days',
    title: 'بداية النور',
    subtitle: '3 أيام متتالية من الذكر',
    description: 'أول خطوة راسخة في طريق المواظبة بإتمام 3 أيام متتالية من الأذكار.',
    icon: '🌱',
    category: 'streak',
    targetValue: 3,
    unitLabel: 'أيام متتالية',
    accentColor: '#4CAF82',
  },
  {
    id: 'streak_14_days',
    title: 'درع السكينة',
    subtitle: '14 يوماً متتالياً (أسبوعان)',
    description: 'مكافأة إتمام أسبوعين كاملين (14 يوماً متتالياً) من المحافظة اليومية على الأذكار.',
    icon: '🛡️',
    category: 'streak',
    targetValue: 14,
    unitLabel: 'يوماً متتالياً',
    accentColor: '#5B5FEF',
  },
  {
    id: 'streak_21_days',
    title: 'نجم الاستقامة',
    subtitle: '21 يوماً متتالياً من الأذكار',
    description: 'إتمام 3 أسابيع متصلة من الذكر اليومي حتى يصبح الذكر سجيةً وعادةً راسخة.',
    icon: '🌟',
    category: 'streak',
    targetValue: 21,
    unitLabel: 'يوماً متتالياً',
    accentColor: '#72B7E8',
  },
  {
    id: 'streak_30_days',
    title: 'تاج الذاكرين الشهري',
    subtitle: '30 يوماً متتالياً من الأذكار',
    description: 'وسام الشرف الرفيع لإتمام شهر كامل (30 يوماً متتالياً) من الأذكار والتسبيح.',
    icon: '👑',
    category: 'streak',
    targetValue: 30,
    unitLabel: 'يوماً متتالياً',
    accentColor: '#E8B84A',
  },
  {
    id: 'athkar_wards_7',
    title: 'حافظ الأوراد السبعة',
    subtitle: 'إتمام 7 أوراد يومية مكتملة',
    description: 'يُمنح عند إكمال 7 أوراد يومية (أذكار الصباح أو المساء أو النوم) بالكامل.',
    icon: '📿',
    category: 'athkar',
    targetValue: 7,
    unitLabel: 'أوراد مكتملة',
    accentColor: '#4CAF82',
  },
  {
    id: 'tasbeeh_1000',
    title: 'الألفية المباركة',
    subtitle: 'إتمام 1,000 تسبيحة وذكر',
    description: 'يُمنح عند الوصول إلى 1,000 تسبيحة في سجل حصاد الأعمال.',
    icon: '💎',
    category: 'tasbeeh',
    targetValue: 1000,
    unitLabel: 'تسبيحة',
    accentColor: '#5B5FEF',
  },
  {
    id: 'tasbeeh_5000',
    title: 'غراس الجنان',
    subtitle: 'إتمام 5,000 تسبيحة وذكر',
    description: 'يُمنح للذاكرين الله كثيراً عند بلوغ 5,000 تسبيحة موثقة في حصاد الأعمال.',
    icon: '🌴',
    category: 'tasbeeh',
    targetValue: 5000,
    unitLabel: 'تسبيحة',
    accentColor: '#E99AC7',
  },
];

interface StoredBadgeRecord {
  unlockedAt: string;
  timesEarned?: number;
}

function loadStoredUnlockedBadges(): Record<string, StoredBadgeRecord> {
  try {
    const raw = localStorage.getItem(UNLOCKED_BADGES_STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, StoredBadgeRecord>;
  } catch {
    return {};
  }
}

function saveStoredUnlockedBadges(records: Record<string, StoredBadgeRecord>): void {
  try {
    localStorage.setItem(UNLOCKED_BADGES_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // ignore quota issues
  }
}

/**
 * Evaluates user's real history to compute 7-day consecutive Athkar challenge progress
 * and all unlocked/in-progress achievement badges.
 */
export function evaluateAchievementBadges(history: Record<string, DailyRecord>): {
  badges: AchievementBadgeStatus[];
  unlockedBadges: AchievementBadgeStatus[];
  sevenDayChallenge: SevenDayChallengeProgress;
} {
  const { currentStreak, longestStreak } = calculateStreaks(history);
  const bestStreak = Math.max(currentStreak, longestStreak);
  const totalTasbeeh = calculateTotalLifetimeTasbeeh(history);
  const totalCompletedWards = Object.values(history).reduce(
    (acc, rec) => acc + (rec?.completedAthkarCount || 0),
    0
  );

  // Count how many 7-day consecutive cycles have been achieved in bestStreak
  const completedSevenDayCycles = Math.floor(bestStreak / 7);
  const Stored = loadStoredUnlockedBadges();
  let storedMutated = false;
  const nowDateStr = new Date().toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  const badges: AchievementBadgeStatus[] = ACHIEVEMENT_BADGES_CATALOG.map((def) => {
    let currentValue = 0;
    if (def.category === 'streak') {
      currentValue = bestStreak;
    } else if (def.category === 'athkar') {
      currentValue = totalCompletedWards;
    } else if (def.category === 'tasbeeh') {
      currentValue = totalTasbeeh;
    }

    const meetsCriteria = currentValue >= def.targetValue;
    const previouslyUnlocked = Boolean(Stored[def.id]);
    const isUnlocked = meetsCriteria || previouslyUnlocked;

    if (meetsCriteria && !Stored[def.id]) {
      Stored[def.id] = {
        unlockedAt: nowDateStr,
        timesEarned: def.id === 'streak_7_days' ? Math.max(1, completedSevenDayCycles) : 1,
      };
      storedMutated = true;
    } else if (
      def.id === 'streak_7_days' &&
      Stored[def.id] &&
      completedSevenDayCycles > (Stored[def.id].timesEarned || 1)
    ) {
      Stored[def.id].timesEarned = completedSevenDayCycles;
      storedMutated = true;
    }

    const progressPercent = isUnlocked
      ? 100
      : Math.min(100, Math.round((currentValue / def.targetValue) * 100));

    return {
      ...def,
      isUnlocked,
      currentValue,
      progressPercent,
      unlockedAt: Stored[def.id]?.unlockedAt,
      timesEarned:
        def.id === 'streak_7_days'
          ? Math.max(completedSevenDayCycles, isUnlocked ? 1 : 0)
          : isUnlocked
          ? 1
          : 0,
    };
  });

  if (storedMutated) {
    saveStoredUnlockedBadges(Stored);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rifq-badges-updated'));
    }
  }

  const isSevenDayBadgeUnlocked = badges.find((b) => b.id === 'streak_7_days')?.isUnlocked || false;

  // Calculate visual 7-day cycle progress (1..7)
  // If user has currentStreak >= 7 and is on an exact multiple of 7 (e.g., 7, 14), show 7/7 completed!
  const daysInCurrentCycle =
    currentStreak === 0
      ? 0
      : currentStreak % 7 === 0
      ? 7
      : currentStreak % 7;

  const remainingDaysForNextBadge =
    daysInCurrentCycle === 7 ? 0 : 7 - daysInCurrentCycle;

  const dayNames = [
    'اليوم 1',
    'اليوم 2',
    'اليوم 3',
    'اليوم 4',
    'اليوم 5',
    'اليوم 6',
    'اليوم 7',
  ];

  const lastSevenDaysChain = dayNames.map((label, idx) => {
    const dayIndex = idx + 1;
    const isCompleted = dayIndex <= daysInCurrentCycle;
    const isCurrentTarget = dayIndex === daysInCurrentCycle + 1;
    return {
      dayIndex,
      label,
      isCompleted,
      isCurrentTarget,
    };
  });

  return {
    badges,
    unlockedBadges: badges.filter((b) => b.isUnlocked),
    sevenDayChallenge: {
      currentStreak,
      longestStreak: bestStreak,
      daysInCurrentCycle,
      completedSevenDayCycles: Math.max(completedSevenDayCycles, isSevenDayBadgeUnlocked ? 1 : 0),
      remainingDaysForNextBadge,
      isSevenDayBadgeUnlocked,
      lastSevenDaysChain,
    },
  };
}
