import {
  FIQH_MUYASSAR_CATEGORIES,
  INITIAL_FIQH_MUYASSAR_TOPICS,
  FIQH_MUYASSAR_SQLITE_DDL_SCHEMA,
  FiqhMuyassarCategory,
  FiqhMuyassarCategoryId,
  FiqhMuyassarTopic,
  FiqhCategorySqliteRow,
  FiqhTopicSqliteRow,
  FiqhFavoriteSqliteRow,
} from '../data/fiqhMuyassarData';

const STORAGE_KEYS = {
  CATEGORIES: 'rifq_sqlite_fiqh_categories_v1',
  TOPICS: 'rifq_sqlite_fiqh_topics_v1',
  FAVORITES: 'rifq_sqlite_fiqh_favorites_v1',
  SCHEMA_VERSION: 'rifq_sqlite_fiqh_schema_v1',
};

export function initFiqhMuyassarSqliteTables(): void {
  try {
    const existingVersion = localStorage.getItem(STORAGE_KEYS.SCHEMA_VERSION);
    if (!existingVersion) {
      localStorage.setItem(STORAGE_KEYS.SCHEMA_VERSION, FIQH_MUYASSAR_SQLITE_DDL_SCHEMA);
    }

    const rawCategories = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!rawCategories) {
      const rows: FiqhCategorySqliteRow[] = FIQH_MUYASSAR_CATEGORIES.map((c) => ({
        id: c.id,
        name: c.name,
        subtitle: c.subtitle,
        description: c.description,
        subtopics_json: JSON.stringify(c.subtopics),
        order_number: c.orderNumber,
      }));
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(rows));
    }

    const rawFavorites = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    let favRows: FiqhFavoriteSqliteRow[] = [];
    if (rawFavorites) {
      favRows = JSON.parse(rawFavorites);
    } else {
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify([]));
    }
    const favSet = new Set(favRows.map((f) => f.topic_id));

    const rawTopics = localStorage.getItem(STORAGE_KEYS.TOPICS);
    const parsedExisting: FiqhTopicSqliteRow[] = rawTopics ? JSON.parse(rawTopics) : [];

    if (!rawTopics || parsedExisting.length < INITIAL_FIQH_MUYASSAR_TOPICS.length) {
      const rows: FiqhTopicSqliteRow[] = INITIAL_FIQH_MUYASSAR_TOPICS.map((t) => ({
        id: t.id,
        category_id: t.categoryId,
        subtopic: t.subtopic,
        title: t.title,
        ruling_badge: t.rulingBadge,
        summary: t.summary,
        definition_and_explanation: t.definitionAndExplanation,
        conditions_and_pillars_json: JSON.stringify(t.conditionsAndPillars),
        quran_ayah: t.quranEvidence?.ayah || '',
        quran_surah: t.quranEvidence?.surahAndNumber || '',
        sunnah_hadith: t.sunnahEvidence.hadith,
        sunnah_source: t.sunnahEvidence.source,
        important_masail_json: JSON.stringify(t.importantMasail),
        fiqh_reference: t.fiqhReference,
        order_number: t.orderNumber,
        is_favorite: favSet.has(t.id) ? 1 : 0,
      }));
      localStorage.setItem(STORAGE_KEYS.TOPICS, JSON.stringify(rows));
    }
  } catch (e) {
    console.error('Failed to initialize Fiqh Muyassar SQLite tables:', e);
  }
}

export function loadFiqhMuyassarCategoriesFromStorage(): FiqhMuyassarCategory[] {
  initFiqhMuyassarSqliteTables();
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) return FIQH_MUYASSAR_CATEGORIES;
    const rows: FiqhCategorySqliteRow[] = JSON.parse(raw);
    return rows
      .sort((a, b) => a.order_number - b.order_number)
      .map((r) => ({
        id: r.id as FiqhMuyassarCategoryId,
        name: r.name,
        subtitle: r.subtitle,
        description: r.description,
        subtopics: JSON.parse(r.subtopics_json || '[]'),
        orderNumber: r.order_number,
      }));
  } catch {
    return FIQH_MUYASSAR_CATEGORIES;
  }
}

export function loadFiqhMuyassarFavorites(): string[] {
  initFiqhMuyassarSqliteTables();
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (!raw) return [];
    const rows: FiqhFavoriteSqliteRow[] = JSON.parse(raw);
    return rows.map((r) => r.topic_id);
  } catch {
    return [];
  }
}

export function loadFiqhMuyassarTopicsFromStorage(): FiqhMuyassarTopic[] {
  initFiqhMuyassarSqliteTables();
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TOPICS);
    const favIds = new Set(loadFiqhMuyassarFavorites());
    if (!raw) {
      return INITIAL_FIQH_MUYASSAR_TOPICS.map((t) => ({
        ...t,
        isFavorite: favIds.has(t.id),
      }));
    }
    const rows: FiqhTopicSqliteRow[] = JSON.parse(raw);
    return rows
      .sort((a, b) => a.order_number - b.order_number)
      .map((r) => ({
        id: r.id,
        categoryId: r.category_id as FiqhMuyassarCategoryId,
        subtopic: r.subtopic,
        title: r.title,
        rulingBadge: r.ruling_badge as FiqhMuyassarTopic['rulingBadge'],
        summary: r.summary,
        definitionAndExplanation: r.definition_and_explanation,
        conditionsAndPillars: JSON.parse(r.conditions_and_pillars_json || '[]'),
        quranEvidence: r.quran_ayah
          ? {
              ayah: r.quran_ayah,
              surahAndNumber: r.quran_surah,
            }
          : undefined,
        sunnahEvidence: {
          hadith: r.sunnah_hadith,
          source: r.sunnah_source,
        },
        importantMasail: JSON.parse(r.important_masail_json || '[]'),
        fiqhReference: r.fiqh_reference,
        orderNumber: r.order_number,
        isFavorite: favIds.has(r.id) || r.is_favorite === 1,
      }));
  } catch {
    return INITIAL_FIQH_MUYASSAR_TOPICS;
  }
}

export function loadFiqhTopicsByCategoryFromStorage(
  categoryId: FiqhMuyassarCategoryId
): FiqhMuyassarTopic[] {
  return loadFiqhMuyassarTopicsFromStorage().filter((t) => t.categoryId === categoryId);
}

export function toggleFiqhMuyassarFavorite(topicId: string): {
  favorites: string[];
  isFavorite: boolean;
} {
  initFiqhMuyassarSqliteTables();
  try {
    const rawFavs = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    const favRows: FiqhFavoriteSqliteRow[] = rawFavs ? JSON.parse(rawFavs) : [];
    const existsIndex = favRows.findIndex((r) => r.topic_id === topicId);
    let isFavorite = false;

    if (existsIndex >= 0) {
      favRows.splice(existsIndex, 1);
      isFavorite = false;
    } else {
      favRows.push({
        id: `fiqh_fav_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        topic_id: topicId,
        added_at: new Date().toISOString(),
      });
      isFavorite = true;
    }

    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favRows));

    const rawTopics = localStorage.getItem(STORAGE_KEYS.TOPICS);
    if (rawTopics) {
      const topicRows: FiqhTopicSqliteRow[] = JSON.parse(rawTopics);
      const updated = topicRows.map((row) =>
        row.id === topicId ? { ...row, is_favorite: isFavorite ? 1 : 0 } : row
      );
      localStorage.setItem(STORAGE_KEYS.TOPICS, JSON.stringify(updated));
    }

    return {
      favorites: favRows.map((r) => r.topic_id),
      isFavorite,
    };
  } catch {
    return { favorites: [], isFavorite: false };
  }
}

function normalizeArabicText(text: string): string {
  return text
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
    .toLowerCase();
}

export function searchFiqhMuyassarInStorage(
  query: string,
  categoryFilter: FiqhMuyassarCategoryId | 'all' = 'all',
  rulingFilter: string = 'all'
): FiqhMuyassarTopic[] {
  const all = loadFiqhMuyassarTopicsFromStorage();
  const normalizedQuery = normalizeArabicText(query);

  return all.filter((item) => {
    if (categoryFilter !== 'all' && item.categoryId !== categoryFilter) {
      return false;
    }
    if (rulingFilter !== 'all' && item.rulingBadge !== rulingFilter) {
      return false;
    }
    if (!normalizedQuery) return true;

    const haystack = normalizeArabicText(
      [
        item.title,
        item.subtopic,
        item.rulingBadge,
        item.summary,
        item.definitionAndExplanation,
        item.conditionsAndPillars.join(' '),
        item.quranEvidence?.ayah || '',
        item.quranEvidence?.surahAndNumber || '',
        item.sunnahEvidence.hadith,
        item.sunnahEvidence.source,
        item.importantMasail.join(' '),
        item.fiqhReference,
      ].join(' ')
    );

    return haystack.includes(normalizedQuery);
  });
}

export function getDailyFiqhTopicFromStorage(): FiqhMuyassarTopic {
  const all = loadFiqhMuyassarTopicsFromStorage();
  if (all.length === 0) return INITIAL_FIQH_MUYASSAR_TOPICS[0];
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );
  return all[dayOfYear % all.length];
}
