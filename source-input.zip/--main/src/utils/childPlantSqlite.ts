import { addNotification } from './storage';
import { triggerPushNotification } from './notifications';

export interface ChildRow {
  id: string;
  name: string;
  birth_date: string;
  gender: 'male' | 'female';
  photo_path: string | null;
  created_at: string;
}

export interface MeasurementRow {
  id: string;
  child_id: string;
  date: string;
  height: number | null;
  weight: number | null;
  head_circumference: number | null;
  notes: string;
  created_at: string;
}

export interface AppointmentRow {
  id: string;
  child_id: string;
  title: string;
  date: string;
  time: string;
  doctor_name: string;
  notes: string;
  reminder_enabled: number;
  created_at: string;
}

export interface NoteRow {
  id: string;
  child_id: string;
  title: string;
  content: string;
  created_at: string;
}

export interface ActivityRow {
  id: string;
  child_id: string;
  type: 'measurement' | 'appointment' | 'note' | 'birthday';
  ref_id: string;
  title: string;
  subtitle: string;
  date: string;
  created_at: string;
}

export interface ChildPlantDatabaseState {
  children: ChildRow[];
  measurements: MeasurementRow[];
  appointments: AppointmentRow[];
  notes: NoteRow[];
  activities: ActivityRow[];
  selectedChildId: string | null;
  darkMode: boolean;
  pinEnabled: boolean;
  pinCode: string | null;
  firedReminders: string[];
}

export interface CalculatedChildAge {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalMonths: number;
  formattedArabic: string;
  stageIndex: 0 | 1 | 2 | 3 | 4;
  stageTitle: string;
  stageDescription: string;
  visualScale: number;
  isBirthdayToday: boolean;
}

const CHILD_PLANT_DB_KEY = 'rifq_muslim_woman_child_plant_sqlite_v1';

const DEFAULT_DB_STATE: ChildPlantDatabaseState = {
  children: [],
  measurements: [],
  appointments: [],
  notes: [],
  activities: [],
  selectedChildId: null,
  darkMode: false,
  pinEnabled: false,
  pinCode: null,
  firedReminders: [],
};

export function loadChildPlantDb(): ChildPlantDatabaseState {
  try {
    const raw = localStorage.getItem(CHILD_PLANT_DB_KEY);
    if (!raw) return { ...DEFAULT_DB_STATE };
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_DB_STATE,
      ...parsed,
      children: Array.isArray(parsed?.children) ? parsed.children : [],
      measurements: Array.isArray(parsed?.measurements) ? parsed.measurements : [],
      appointments: Array.isArray(parsed?.appointments) ? parsed.appointments : [],
      notes: Array.isArray(parsed?.notes) ? parsed.notes : [],
      activities: Array.isArray(parsed?.activities) ? parsed.activities : [],
      firedReminders: Array.isArray(parsed?.firedReminders) ? parsed.firedReminders : [],
    };
  } catch {
    return { ...DEFAULT_DB_STATE };
  }
}

export function saveChildPlantDb(state: ChildPlantDatabaseState): void {
  try {
    localStorage.setItem(CHILD_PLANT_DB_KEY, JSON.stringify(state));
  } catch {
    // ignore storage errors
  }
}

export function formatDateDMY(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.slice(0, 10).split('-');
  if (parts.length !== 3) return dateStr;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

export function calculateChildAge(birthDateStr: string): CalculatedChildAge {
  const now = new Date();
  const birth = new Date(birthDateStr);
  if (Number.isNaN(birth.getTime())) {
    return {
      years: 0,
      months: 0,
      days: 0,
      totalDays: 0,
      totalMonths: 0,
      formattedArabic: 'أقل من يوم',
      stageIndex: 0,
      stageTitle: 'البداية: بذرة وبرعم أولي',
      stageDescription: 'مرحلة الرعاية الأولى والدفء الأسري.',
      visualScale: 0.85,
      isBirthdayToday: false,
    };
  }

  let years = now.getFullYear() - birth.getFullYear();
  let months = now.getMonth() - birth.getMonth();
  let days = now.getDate() - birth.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    days += prevMonth.getDate();
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  years = Math.max(0, years);
  months = Math.max(0, months);
  days = Math.max(0, days);

  const totalDays = Math.max(0, Math.floor((now.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24)));
  const totalMonths = years * 12 + months;

  const parts: string[] = [];
  if (years > 0) parts.push(`${years} سنة`);
  if (months > 0) parts.push(`${months} شهر`);
  if (days > 0 || parts.length === 0) parts.push(`${days} يوم`);

  let stageIndex: 0 | 1 | 2 | 3 | 4 = 0;
  let stageTitle = 'البداية: بذرة وبرعم أولي';
  let stageDescription = 'مرحلة التواصل البصري والسمعي مع الأم والابتسامة الاجتماعية.';
  let visualScale = 0.85;

  if (totalMonths >= 48) {
    stageIndex = 4;
    stageTitle = 'مرحلة متقدمة: شجرة صغيرة';
    stageDescription = 'مرحلة الاعتماد التدريجي في المهارات اليومية وبناء الصداقات والتعلم.';
    visualScale = 1.15;
  } else if (totalMonths >= 24) {
    stageIndex = 3;
    stageTitle = 'مرحلة أكبر: نبتة كبيرة مورقة';
    stageDescription = 'مرحلة تكوين الجمل القصيرة واللعب الحركي وتنمية المهارات الاجتماعية.';
    visualScale = 1.08;
  } else if (totalMonths >= 12) {
    stageIndex = 2;
    stageTitle = 'نمو متزايد: نبتة أكثر نمواً';
    stageDescription = 'مرحلة الخطوات المستقلة ونطق الكلمات الأولى والتفاعل الأسري.';
    visualScale = 1.0;
  } else if (totalMonths >= 6) {
    stageIndex = 1;
    stageTitle = 'مرحلة لاحقة: نبتة صغيرة';
    stageDescription = 'مرحلة الجلوس المتوازن والانتباه للأصوات والألوان المحيطة.';
    visualScale = 0.92;
  }

  const isBirthdayToday =
    years > 0 &&
    now.getMonth() === birth.getMonth() &&
    now.getDate() === birth.getDate();

  return {
    years,
    months,
    days,
    totalDays,
    totalMonths,
    formattedArabic: parts.join(' و '),
    stageIndex,
    stageTitle,
    stageDescription,
    visualScale,
    isBirthdayToday,
  };
}

export function deleteAllChildDataFromSqlite(
  db: ChildPlantDatabaseState,
  childId: string
): ChildPlantDatabaseState {
  const remainingChildren = db.children.filter((c) => c.id !== childId);
  const updated: ChildPlantDatabaseState = {
    ...db,
    children: remainingChildren,
    measurements: db.measurements.filter((m) => m.child_id !== childId),
    appointments: db.appointments.filter((a) => a.child_id !== childId),
    notes: db.notes.filter((n) => n.child_id !== childId),
    activities: db.activities.filter((act) => act.child_id !== childId),
    selectedChildId: remainingChildren[0]?.id || null,
  };
  saveChildPlantDb(updated);
  return updated;
}

export async function scheduleRealChildAppointmentNotification(_appt: AppointmentRow): Promise<void> {
  // Handled by periodic checkAndFireChildAppointmentNotifications
}

export async function checkAndFireChildAppointmentNotifications(
  onFired?: () => void
): Promise<void> {
  try {
    const db = loadChildPlantDb();
    if (!db.appointments || db.appointments.length === 0) return;

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const currentHm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    let changed = false;
    for (const appt of db.appointments) {
      if (!appt.reminder_enabled) continue;
      if (appt.date !== todayStr) continue;
      const sig = `child_appt_${appt.id}_${appt.date}_${appt.time}`;
      if (db.firedReminders.includes(sig)) continue;

      if (currentHm >= (appt.time || '09:00')) {
        db.firedReminders.push(sig);
        changed = true;
        const child = db.children.find((c) => c.id === appt.child_id);
        const title = `موعد طفل: ${appt.title}`;
        const message = `${child?.name ? `للطفل ${child.name} — ` : ''}الساعة ${appt.time}${
          appt.doctor_name ? ` (${appt.doctor_name})` : ''
        }`;

        addNotification({
          title,
          message,
          time: 'الآن',
          read: false,
          type: 'reminder',
          actionScreen: 'muslim_woman',
          signatureKey: sig,
        });

        await triggerPushNotification({
          title,
          message,
          tag: sig,
          screen: 'muslim_woman',
        }).catch(() => {});
      }
    }

    if (changed) {
      saveChildPlantDb(db);
      if (onFired) onFired();
    }
  } catch {
    // ignore
  }
}
