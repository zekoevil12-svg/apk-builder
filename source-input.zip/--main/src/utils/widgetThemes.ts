import React from 'react';
import { WidgetTheme } from '../types';

export interface WidgetThemeStyles {
  container: string;
  containerStyle: React.CSSProperties;
  badge: string;
  badgeText: string;
  accentText: string;
  highlightBadge: string;
  subCard: string;
  subtleButton: string;
  activeChip: string;
  primaryText: string;
  secondaryText: string;
  button: string;
  buttonIcon: string;
  progressBarBg: string;
  progressBarFill: string;
  ringTrack: string;
  ringFill: string;
  border: string;
  divider: string;
}

export const WIDGET_THEMES: Record<WidgetTheme, WidgetThemeStyles> = {
  navy: {
    container: 'text-white shadow-xl',
    containerStyle: {
      background: 'linear-gradient(135deg, #4338CA 0%, #3730A3 50%, #312E81 100%)',
      color: '#FFFFFF',
    },
    badge: 'bg-white/15 border border-white/25',
    badgeText: 'text-[#FFFBEB]',
    accentText: 'text-[#FDE047]',
    highlightBadge: 'bg-black/25 text-[#FDE047] border border-white/20',
    subCard: 'bg-black/25 border border-white/15',
    subtleButton: 'bg-white/15 hover:bg-white/25 text-[#FEF08A] border border-white/20',
    activeChip: 'bg-[#FACC15] text-[#1E1B4B] font-black shadow-2xs',
    primaryText: 'text-white',
    secondaryText: 'text-[#E0E7FF]',
    button:
      'bg-gradient-to-r from-[#E8B84A] to-[#F3CE75] text-[#1E1B4B] hover:opacity-95 active:scale-95 shadow-md shadow-black/20',
    buttonIcon: 'text-[#1E1B4B]',
    progressBarBg: 'bg-white/20',
    progressBarFill: 'bg-[#FACC15]',
    ringTrack: 'rgba(255, 255, 255, 0.22)',
    ringFill: '#FACC15',
    border: 'border border-white/25',
    divider: 'border-white/15',
  },
  gold: {
    container: 'text-[#1E2035] shadow-lg',
    containerStyle: {
      background: 'linear-gradient(135deg, #FFFDF7 0%, #FEF9E7 55%, #FDE68A 100%)',
      color: '#1E2035',
    },
    badge: 'bg-[#78350F] text-white border border-[#78350F]/20',
    badgeText: 'text-white',
    accentText: 'text-[#92400E]',
    highlightBadge: 'bg-[#FEF3C7] text-[#78350F] border border-[#D97706]/35',
    subCard: 'bg-[#FFF8EB] border border-[#E5C98B]',
    subtleButton: 'bg-[#FEF3C7] hover:bg-[#FDE68A] text-[#78350F] border border-[#D97706]/35',
    activeChip: 'bg-[#78350F] text-white font-black shadow-2xs',
    primaryText: 'text-[#1E2035]',
    secondaryText: 'text-[#4A3B2C]',
    button:
      'bg-[#78350F] hover:bg-[#5C280B] text-white active:scale-95 shadow-md shadow-[#78350F]/20',
    buttonIcon: 'text-[#FDE68A]',
    progressBarBg: 'bg-[#E5C98B]/50',
    progressBarFill: 'bg-[#92400E]',
    ringTrack: 'rgba(120, 53, 15, 0.16)',
    ringFill: '#92400E',
    border: 'border border-[#D97706]/35',
    divider: 'border-[#D97706]/25',
  },
  midnight: {
    container: 'text-white shadow-xl',
    containerStyle: {
      background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 55%, #27354F 100%)',
      color: '#FFFFFF',
    },
    badge: 'bg-[#38BDF8]/20 border border-[#38BDF8]/40',
    badgeText: 'text-[#E0F2FE]',
    accentText: 'text-[#7DD3FC]',
    highlightBadge: 'bg-black/35 text-[#FDE047] border border-white/15',
    subCard: 'bg-black/30 border border-white/15',
    subtleButton: 'bg-white/15 hover:bg-white/25 text-[#E0F2FE] border border-white/20',
    activeChip: 'bg-[#38BDF8] text-[#0F172A] font-black shadow-2xs',
    primaryText: 'text-white',
    secondaryText: 'text-[#CBD5E1]',
    button:
      'bg-[#4F46E5] hover:bg-[#4338CA] text-white active:scale-95 shadow-md shadow-black/30',
    buttonIcon: 'text-white',
    progressBarBg: 'bg-white/15',
    progressBarFill: 'bg-[#38BDF8]',
    ringTrack: 'rgba(255, 255, 255, 0.15)',
    ringFill: '#38BDF8',
    border: 'border border-white/20',
    divider: 'border-white/15',
  },
  cream: {
    container: 'text-[#1E2035] shadow-md',
    containerStyle: {
      background: 'linear-gradient(135deg, #FFFFFF 0%, #F8F9FE 60%, #EEF0FF 100%)',
      color: '#1E2035',
    },
    badge: 'bg-[#E0E7FF] border border-[#4338CA]/25',
    badgeText: 'text-[#312E81]',
    accentText: 'text-[#3730A3]',
    highlightBadge: 'bg-[#EEF0FF] text-[#312E81] border border-[#4338CA]/30',
    subCard: 'bg-[#F1F3FA] border border-[#CBD5E1]',
    subtleButton: 'bg-[#E0E7FF] hover:bg-[#C7D2FE] text-[#312E81] border border-[#4338CA]/25',
    activeChip: 'bg-[#3730A3] text-white font-black shadow-2xs',
    primaryText: 'text-[#1E2035]',
    secondaryText: 'text-[#43465E]',
    button: 'bg-[#4338CA] text-white hover:bg-[#312E81] active:scale-95 shadow-sm',
    buttonIcon: 'text-white',
    progressBarBg: 'bg-[#CBD5E1]',
    progressBarFill: 'bg-[#4338CA]',
    ringTrack: 'rgba(55, 48, 163, 0.15)',
    ringFill: '#4338CA',
    border: 'border border-[#CBD5E1]',
    divider: 'border-[#CBD5E1]',
  },
};
