import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useMemo,
  useCallback,
} from 'react';
import {
  ThemeId,
  ThemeMode,
  RifqThemeTokens,
  RifqThemeDefinition,
  RIFQ_THEMES,
  RIFQ_THEME_LIST,
  isValidThemeId,
  isValidThemeMode,
  resolveThemeTokens,
} from '../theme/themes';
import { loadSettings, saveSettings } from '../utils/storage';
import { auth, db, doc, setDoc } from '../utils/firebase';

export interface ThemeContextValue {
  themeId: ThemeId;
  themeMode: ThemeMode;
  isDark: boolean;
  systemPrefersDark: boolean;
  theme: {
    id: ThemeId;
    mode: ThemeMode;
    isDark: boolean;
    definition: RifqThemeDefinition;
    colors: RifqThemeTokens;
  };
  availableThemes: RifqThemeDefinition[];
  setThemeId: (id: ThemeId) => void;
  setThemeMode: (mode: ThemeMode) => void;
  setThemeAndMode: (id: ThemeId, mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function detectSystemDark(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
}

/**
 * Apply theme tokens to :root CSS variables and HTML attributes synchronously
 * to prevent any flash of unstyled content.
 */
export function applyThemeTokensToDom(
  themeId: ThemeId,
  themeMode: ThemeMode,
  tokens: RifqThemeTokens,
  isDark: boolean
): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;

  root.setAttribute('data-rifq-theme', themeId);
  root.setAttribute('data-rifq-mode', isDark ? 'dark' : 'light');
  root.setAttribute('data-rifq-theme-mode-setting', themeMode);

  if (isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  // Central Design Tokens CSS Custom Properties
  root.style.setProperty('--theme-background', tokens.background);
  root.style.setProperty('--theme-background-secondary', tokens.backgroundSecondary);
  root.style.setProperty('--theme-surface', tokens.surface);
  root.style.setProperty('--theme-surface-elevated', tokens.surfaceElevated);
  root.style.setProperty('--theme-card', tokens.card || tokens.surface);
  root.style.setProperty('--theme-primary', tokens.primary);
  root.style.setProperty('--theme-primary-light', tokens.primaryLight);
  root.style.setProperty('--theme-primary-dark', tokens.primaryDark);
  root.style.setProperty('--theme-secondary', tokens.secondary);
  root.style.setProperty('--theme-accent', tokens.accent);
  root.style.setProperty('--theme-text', tokens.text);
  root.style.setProperty('--theme-text-secondary', tokens.textSecondary);
  root.style.setProperty('--theme-text-muted', tokens.textMuted);
  root.style.setProperty('--theme-border', tokens.border);
  root.style.setProperty('--theme-divider', tokens.divider);
  root.style.setProperty('--theme-success', tokens.success);
  root.style.setProperty('--theme-warning', tokens.warning);
  root.style.setProperty('--theme-error', tokens.error);
  root.style.setProperty('--theme-info', tokens.info);
  root.style.setProperty('--theme-overlay', tokens.overlay);
  root.style.setProperty('--theme-shadow', tokens.shadow);
  root.style.setProperty('--theme-shadow-soft', tokens.shadowSoft);
  root.style.setProperty('--theme-shadow-strong', tokens.shadowStrong);
  root.style.setProperty('--theme-icon', tokens.icon);
  root.style.setProperty('--theme-icon-primary', tokens.primary);
  root.style.setProperty('--theme-icon-secondary', tokens.secondary);
  root.style.setProperty('--theme-icon-accent', tokens.accent);
  root.style.setProperty(
    '--theme-icon-rose-gold',
    themeId === 'girly' ? '#CFA06A' : tokens.accent
  );
  root.style.setProperty(
    '--theme-icon-lavender',
    themeId === 'girly' ? '#B98CC8' : tokens.secondary
  );
  root.style.setProperty(
    '--theme-icon-cream',
    themeId === 'girly' ? (isDark ? '#2B1D25' : '#FFF8FA') : tokens.surface
  );
  root.style.setProperty('--theme-button-text', tokens.buttonText);
  root.style.setProperty('--theme-header-gradient', tokens.headerGradient);
  root.style.setProperty('--theme-hero-gradient', tokens.heroGradient);
  root.style.setProperty('--theme-input-bg', tokens.inputBg);
  root.style.setProperty('--theme-input-border', tokens.inputBorder);

  // Sync legacy RIFQ variables
  root.style.setProperty('--rifq-primary', tokens.primary);
  root.style.setProperty('--rifq-primary-dark', tokens.primaryDark);
  root.style.setProperty('--rifq-secondary-bg', tokens.primaryLight);
  root.style.setProperty('--rifq-accent-gold', tokens.accent);
  root.style.setProperty('--rifq-accent-blue', tokens.secondary);
  root.style.setProperty('--rifq-bg', tokens.background);
  root.style.setProperty('--rifq-card', tokens.surface);
  root.style.setProperty('--rifq-text-primary', tokens.text);
  root.style.setProperty('--rifq-text-secondary', tokens.textMuted);
  root.style.setProperty('--rifq-border', tokens.border);
  root.style.setProperty('--rifq-success', tokens.success);
  root.style.setProperty('--rifq-warning', tokens.warning);
  root.style.setProperty('--rifq-error', tokens.error);

  if (document.body) {
    document.body.style.backgroundColor = tokens.background;
    document.body.style.color = tokens.text;
  }

  // Update mobile status bar theme-color meta tag
  const metaThemeColor = document.querySelector('meta[name="theme-color"]');
  if (metaThemeColor) {
    metaThemeColor.setAttribute('content', tokens.surface);
  }

  // Broadcast reactive theme update for any dynamic SVG icons or listeners
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-theme-changed', {
        detail: { themeId, themeMode, isDark, tokens },
      })
    );
  }
}

/**
 * Synchronously initialize and apply the saved theme before the first React render
 * to eliminate any Flash of Unstyled Theme (FOUC).
 */
export function initThemeOnBoot(): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  try {
    const saved = loadSettings();
    const bootThemeId: ThemeId = isValidThemeId(saved.themeId) ? saved.themeId : 'default';
    const bootThemeMode: ThemeMode = isValidThemeMode(saved.themeMode) ? saved.themeMode : 'light';
    const sysDark = detectSystemDark();
    const resolved = resolveThemeTokens(bootThemeId, bootThemeMode, sysDark);
    applyThemeTokensToDom(bootThemeId, bootThemeMode, resolved.tokens, resolved.isDark);
  } catch {
    // Fallback to default light tokens
    const fallback = resolveThemeTokens('default', 'light', false);
    applyThemeTokensToDom('default', 'light', fallback.tokens, false);
  }
}

// Execute immediately upon module load before React mounts
initThemeOnBoot();

export const ThemeProvider: React.FC<{
  children: React.ReactNode;
  externalSettingsThemeId?: ThemeId;
  externalSettingsThemeMode?: ThemeMode;
  onUpdateUserSettings?: (partial: {
    themeId: ThemeId;
    themeMode: ThemeMode;
    themeUpdatedAt: string;
  }) => void;
}> = ({
  children,
  externalSettingsThemeId,
  externalSettingsThemeMode,
  onUpdateUserSettings,
}) => {
  const [themeId, setThemeIdState] = useState<ThemeId>(() => {
    const saved = loadSettings();
    return isValidThemeId(saved.themeId) ? saved.themeId : 'default';
  });

  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    const saved = loadSettings();
    return isValidThemeMode(saved.themeMode) ? saved.themeMode : 'light';
  });

  const [systemPrefersDark, setSystemPrefersDark] = useState<boolean>(detectSystemDark);

  // Sync with external settings state if changed from outside (e.g., account switch or cloud hydration)
  useEffect(() => {
    if (externalSettingsThemeId && isValidThemeId(externalSettingsThemeId)) {
      setThemeIdState(externalSettingsThemeId);
    }
  }, [externalSettingsThemeId]);

  useEffect(() => {
    if (externalSettingsThemeMode && isValidThemeMode(externalSettingsThemeMode)) {
      setThemeModeState(externalSettingsThemeMode);
    }
  }, [externalSettingsThemeMode]);

  // Listen to OS / Android dark mode changes for "system" (تلقائي حسب النظام)
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      setSystemPrefersDark(e.matches);
    };

    if (typeof mediaQuery.addEventListener === 'function') {
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, []);

  // Listen to account switch / cloud sync hydration events so User B never sees User A's theme
  useEffect(() => {
    const handleSyncHydrated = () => {
      const fresh = loadSettings();
      const nextId = isValidThemeId(fresh.themeId) ? fresh.themeId : 'default';
      const nextMode = isValidThemeMode(fresh.themeMode) ? fresh.themeMode : 'light';
      setThemeIdState(nextId);
      setThemeModeState(nextMode);
    };

    window.addEventListener('rifq-user-data-synced', handleSyncHydrated);
    return () => window.removeEventListener('rifq-user-data-synced', handleSyncHydrated);
  }, []);

  const resolved = useMemo(
    () => resolveThemeTokens(themeId, themeMode, systemPrefersDark),
    [themeId, themeMode, systemPrefersDark]
  );

  // Apply tokens to DOM whenever resolved theme changes
  useEffect(() => {
    applyThemeTokensToDom(themeId, themeMode, resolved.tokens, resolved.isDark);
  }, [themeId, themeMode, resolved]);

  const persistThemeSelection = useCallback(
    (nextId: ThemeId, nextMode: ThemeMode) => {
      const nowIso = new Date().toISOString();
      const currentSettings = loadSettings();
      const updatedSettings = {
        ...currentSettings,
        themeId: nextId,
        themeMode: nextMode,
        themeUpdatedAt: nowIso,
      };
      saveSettings(updatedSettings);

      if (onUpdateUserSettings) {
        onUpdateUserSettings({
          themeId: nextId,
          themeMode: nextMode,
          themeUpdatedAt: nowIso,
        });
      }

      // If authenticated in Firebase, persist themeId & themeMode in users/{uid} in background
      const currentUser = auth.currentUser;
      if (currentUser?.uid) {
        const userRef = doc(db, 'users', currentUser.uid);
        setDoc(
          userRef,
          {
            themeId: nextId,
            themeMode: nextMode,
            themeUpdatedAt: nowIso,
            updatedAt: nowIso,
            settings: updatedSettings,
          },
          { merge: true }
        ).catch(() => {
          // Offline mode: Firestore will sync when back online
        });
      }
    },
    [onUpdateUserSettings]
  );

  const setThemeId = useCallback(
    (nextId: ThemeId) => {
      if (!isValidThemeId(nextId)) return;
      // When selecting "night" theme directly, if mode was light, keep mode or let night theme render dark
      // When selecting "day" or "girly" theme directly while in dark mode, switch mode to light so user sees the signature light palette immediately
      let nextMode = themeMode;
      if ((nextId === 'day' || nextId === 'girly') && themeMode === 'dark') {
        nextMode = 'light';
        setThemeModeState('light');
      }
      // Synchronously update DOM attributes & CSS variables before React re-renders dynamic icons
      const nextResolved = resolveThemeTokens(nextId, nextMode, systemPrefersDark);
      applyThemeTokensToDom(nextId, nextMode, nextResolved.tokens, nextResolved.isDark);
      setThemeIdState(nextId);
      persistThemeSelection(nextId, nextMode);
    },
    [themeMode, systemPrefersDark, persistThemeSelection]
  );

  const setThemeMode = useCallback(
    (nextMode: ThemeMode) => {
      if (!isValidThemeMode(nextMode)) return;
      let nextId = themeId;
      // If user was on "night" (which is inherently dark) and explicitly clicks "☀️ فاتح", switch themeId to default or day if needed, or let them preview light
      if (nextMode === 'light' && themeId === 'night') {
        nextId = 'default';
        setThemeIdState('default');
      }
      const nextResolved = resolveThemeTokens(nextId, nextMode, systemPrefersDark);
      applyThemeTokensToDom(nextId, nextMode, nextResolved.tokens, nextResolved.isDark);
      setThemeModeState(nextMode);
      persistThemeSelection(nextId, nextMode);
    },
    [themeId, systemPrefersDark, persistThemeSelection]
  );

  const setThemeAndMode = useCallback(
    (nextId: ThemeId, nextMode: ThemeMode) => {
      if (!isValidThemeId(nextId) || !isValidThemeMode(nextMode)) return;
      const nextResolved = resolveThemeTokens(nextId, nextMode, systemPrefersDark);
      applyThemeTokensToDom(nextId, nextMode, nextResolved.tokens, nextResolved.isDark);
      setThemeIdState(nextId);
      setThemeModeState(nextMode);
      persistThemeSelection(nextId, nextMode);
    },
    [systemPrefersDark, persistThemeSelection]
  );

  const value = useMemo<ThemeContextValue>(
    () => ({
      themeId,
      themeMode,
      isDark: resolved.isDark,
      systemPrefersDark,
      theme: {
        id: themeId,
        mode: themeMode,
        isDark: resolved.isDark,
        definition: resolved.themeDef,
        colors: resolved.tokens,
      },
      availableThemes: RIFQ_THEME_LIST,
      setThemeId,
      setThemeMode,
      setThemeAndMode,
    }),
    [
      themeId,
      themeMode,
      resolved,
      systemPrefersDark,
      setThemeId,
      setThemeMode,
      setThemeAndMode,
    ]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return ctx;
}

/**
 * Safe reactive theme hook for dynamic SVG icons, medallions, and navigation elements.
 * Subscribes directly to ThemeContext when inside ThemeProvider, and falls back to
 * listening for 'rifq-theme-changed' DOM events if rendered in a standalone tree.
 */
export function useSafeTheme(): {
  themeId: ThemeId;
  themeMode: ThemeMode;
  isDark: boolean;
  isGirly: boolean;
  colors: RifqThemeTokens;
} {
  const ctx = useContext(ThemeContext);
  const [fallbackState, setFallbackState] = useState<{
    themeId: ThemeId;
    themeMode: ThemeMode;
    isDark: boolean;
  }>(() => {
    if (typeof document !== 'undefined') {
      const domTheme = document.documentElement.getAttribute('data-rifq-theme');
      const domMode = document.documentElement.getAttribute('data-rifq-theme-mode-setting');
      const domDark = document.documentElement.getAttribute('data-rifq-mode') === 'dark';
      return {
        themeId: isValidThemeId(domTheme) ? domTheme : 'default',
        themeMode: isValidThemeMode(domMode) ? domMode : 'light',
        isDark: domDark,
      };
    }
    return { themeId: 'default', themeMode: 'light', isDark: false };
  });

  useEffect(() => {
    if (ctx || typeof window === 'undefined') return;
    const handleThemeEvent = (e: Event) => {
      const custom = e as CustomEvent<{
        themeId: ThemeId;
        themeMode: ThemeMode;
        isDark: boolean;
      }>;
      if (custom.detail) {
        setFallbackState({
          themeId: custom.detail.themeId,
          themeMode: custom.detail.themeMode,
          isDark: custom.detail.isDark,
        });
      }
    };
    window.addEventListener('rifq-theme-changed', handleThemeEvent);
    return () => window.removeEventListener('rifq-theme-changed', handleThemeEvent);
  }, [ctx]);

  if (ctx) {
    return {
      themeId: ctx.themeId,
      themeMode: ctx.themeMode,
      isDark: ctx.isDark,
      isGirly: ctx.themeId === 'girly',
      colors: ctx.theme.colors,
    };
  }

  const resolvedFallback = resolveThemeTokens(
    fallbackState.themeId,
    fallbackState.themeMode,
    fallbackState.isDark
  );
  return {
    themeId: fallbackState.themeId,
    themeMode: fallbackState.themeMode,
    isDark: resolvedFallback.isDark,
    isGirly: fallbackState.themeId === 'girly',
    colors: resolvedFallback.tokens,
  };
}
