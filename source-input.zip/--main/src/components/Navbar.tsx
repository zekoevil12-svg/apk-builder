import React, { useState } from 'react';
import { Menu, Bell, Share2, Check } from 'lucide-react';
import { ScreenType } from '../types';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { getSavedUserAvatar } from '../utils/firebase';
import { RifqLogo } from './RifqLogo';
import { shareRifqApp } from '../utils/shareRifq';
import { RifqSectionIcon, ProfileSectionSvg } from './Home/RifqSectionIcons';

interface NavbarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  onOpenSidebar: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  onOpenSidebar,
  onOpenNotifications,
  unreadCount,
}) => {
  const { currentUser, userProfile, openAuthModal } = useAuth();
  const { themeId, isDark } = useTheme();
  const isGirly = themeId === 'girly';
  const [copiedToast, setCopiedToast] = useState(false);

  const handleProfileClick = () => {
    if (currentUser) {
      onNavigate('profile');
    } else {
      openAuthModal('login');
    }
  };

  const photoUrl = userProfile?.photoURL || getSavedUserAvatar(currentUser?.uid) || currentUser?.photoURL;
  const isEmojiAvatar = photoUrl?.startsWith('emoji:');
  const emojiChar = isEmojiAvatar ? photoUrl.replace('emoji:', '') : '';

  const handleShareApp = async () => {
    const res = await shareRifqApp();
    if (res === 'copied') {
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2200);
    }
  };

  // Screen Arabic display title
  const getScreenTitle = () => {
    switch (currentScreen) {
      case 'home':
        return 'الرئيسية';
      case 'tasbeeh':
        return 'المسبحة المركزية';
      case 'prayers':
        return 'مواقيت الصلاة';
      case 'quran':
        return 'القرآن الكريم';
      case 'quran_audio':
        return 'القرآن — استماع';
      case 'daily_reminders':
        return 'التذكيرات اليومية';
      case 'wird':
      case 'ward':
        return 'وِرد | WIRD';
      case 'gharib_quran':
        return 'غريب القرآن';
      case 'tajweed':
        return 'أحكام التجويد التفاعلية';
      case 'tadabbur':
        return 'آية وفائدة (تدبرات)';
      case 'zakat_mawarith':
        return 'الزكاة والمواريث';
      case 'hijri_fasting':
        return 'التقويم والصيام';
      case 'hajj_umrah':
        return 'دليل الحج والعمرة';
      case 'ruqyah_medicine':
        return 'الرقية والطب النبوي';
      case 'hadith':
        return 'الأحاديث النبوية';
      case 'arbain_nawawiya':
        return 'الأربعون النووية';
      case 'companions_stories':
        return 'قصص الصحابة';
      case 'prophetic_biography':
        return 'السيرة النبوية ﷺ';
      case 'our_history':
        return 'تاريخنا الإسلامي';
      case 'kids_stories':
        return 'قصص الأطفال';
      case 'my_journey':
        return 'رحلتي الإيمانية';
      case 'wasaya':
        return 'وصايا الرسول ﷺ';
      case 'fiqh_muyassar':
        return 'الفقه الميسر';
      case 'athkar':
      case 'hisn_almuslim':
      case 'moment_dhikr':
        return 'موسوعة الأذكار';
      case 'dua_corner':
        return 'ركن الدعاء والمناجاة';
      case 'wudu_prayer':
        return '🕌 تعلّم الوضوء والصلاة';
      case 'athar_tayyib':
        return 'أثر طيّب';
      case 'amana':
        return 'أمانة';
      case 'harvest':
        return 'حصاد الأعمال';
      case 'muslim_woman':
        return 'رِفْق للمرأة';
      case 'asmaa_allah':
        return 'أسماء الله الحسنى';
      case 'stats':
        return 'سجل الإحصائيات';
      case 'profile':
        return 'الملف الشخصي';
      case 'settings':
        return 'الإعدادات';
      case 'credits':
        return 'تواصل المطور';
      case 'widgets':
        return 'ويدجت الهاتف';
      case 'admin':
        return 'لوحة الإدارة';
      default:
        return 'الرئيسية';
    }
  };

  return (
    <header className="sticky top-0 z-30 w-full bg-[#FFFFFF] border-b border-[#E6E6F0] shadow-[0_2px_10px_rgba(37,38,58,0.03)] backdrop-blur-md transition-colors duration-250" dir="rtl">
      {/* Top Modern Subtle Accent Line */}
      <div
        className="h-[2.5px] w-full bg-gradient-to-r from-[#5B5FEF] via-[#72B7E8] to-[#E99AC7]"
        style={{ background: 'var(--theme-header-gradient)' }}
      />

      {/* Copied Link Toast */}
      {copiedToast && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-[#25263A] text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1.5 border border-[#5B5FEF]/40 animate-fade-in z-50">
          <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
          <span>تم نسخ رابط التطبيق للمشاركة!</span>
        </div>
      )}
      
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Right side (in RTL): Hamburger Menu Drawer button */}
        <div className="flex items-center gap-1.5">
          <button
            id="btn-sidebar-menu"
            type="button"
            onClick={onOpenSidebar}
            aria-label="القائمة الجانبية"
            className="p-2 rounded-2xl text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors focus:outline-hidden cursor-pointer"
            style={isGirly ? { color: '#D98FA8' } : undefined}
          >
            <Menu className="w-6 h-6 stroke-[2.3]" />
          </button>
        </div>

        {/* Center: Title with matching section icon or Rifq emblem */}
        <div 
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 cursor-pointer select-none group"
          title="الانتقال إلى الرئيسية"
        >
          {currentScreen === 'home' ? (
            <RifqLogo key={`header-logo-${themeId}-${isDark}`} size={26} variant="emblem" className="group-hover:scale-105 transition-transform" />
          ) : (
            <span
              className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0"
              style={isGirly ? { borderColor: '#CFA06A', boxShadow: '0 2px 6px rgba(185, 140, 200, 0.22)' } : undefined}
            >
              <RifqSectionIcon key={`header-icon-${currentScreen}-${themeId}-${isDark}`} screenId={currentScreen} size={20} />
            </span>
          )}
          <span className="text-lg sm:text-xl font-black text-[#25263A] tracking-tight font-tajawal">
            {getScreenTitle()}
          </span>
          {currentScreen === 'home' && (
            <span
              className="text-[11px] font-black text-[#5B5FEF] px-1.5 py-0.5 rounded-md bg-[#EEEEFF] border border-[#E6E6F0]"
              style={isGirly ? { borderColor: '#DFC5EB', color: '#B56582' } : undefined}
            >
              رِفْـق
            </span>
          )}
        </div>

        {/* Left side (in RTL): Notifications & Share icons */}
        <div className="flex items-center gap-1">
          {/* Share Button */}
          <button
            id="btn-share-header"
            type="button"
            onClick={handleShareApp}
            aria-label="مشاركة التطبيق"
            title="مشاركة التطبيق"
            className="p-2 rounded-2xl text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
            style={isGirly ? { color: '#B98CC8' } : undefined}
          >
            <Share2 className="w-5 h-5 stroke-[2.2]" />
          </button>

          {/* Notifications Bell */}
          <button
            id="btn-notifications"
            type="button"
            onClick={onOpenNotifications}
            aria-label="الإشعارات والتذكيرات"
            title="الإشعارات والتذكيرات"
            className="relative p-2 rounded-2xl text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
            style={isGirly ? { color: '#CFA06A' } : undefined}
          >
            <Bell className="w-5 h-5 stroke-[2.2]" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 left-1.5 bg-[#5B5FEF] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {unreadCount}
              </span>
            )}
          </button>

          {/* User Profile avatar */}
          <button
            id="btn-user-profile"
            type="button"
            onClick={handleProfileClick}
            aria-label={currentUser ? 'الملف الشخصي' : 'تسجيل الدخول'}
            className="p-1 rounded-full border border-[#E6E6F0] hover:border-[#5B5FEF] bg-[#F7F7FC] transition-all cursor-pointer mr-0.5"
            style={isGirly ? { borderColor: '#CFA06A' } : undefined}
          >
            <div className="w-7 h-7 rounded-full bg-white flex items-center justify-center overflow-hidden text-xs font-bold text-[#5B5FEF]">
              {currentUser && photoUrl && !isEmojiAvatar ? (
                <img src={photoUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : currentUser && isEmojiAvatar ? (
                <span className="text-sm select-none">{emojiChar}</span>
              ) : (
                <ProfileSectionSvg key={`header-profile-${themeId}-${isDark}`} size={20} />
              )}
            </div>
          </button>
        </div>
      </div>
    </header>
  );
};


