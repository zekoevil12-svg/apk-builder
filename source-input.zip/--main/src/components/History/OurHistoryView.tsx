import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  TareekhunaEvent,
  TareekhunaEra,
  TareekhunaCategory,
  TAREEKHUNA_EVENTS,
  TAREEKHUNA_ERAS,
  TAREEKHUNA_CATEGORIES,
  HIJRI_MONTHS_LIST,
} from '../../data/tareekhunaData';
import {
  getSavedHistoryIds,
  toggleSavedHistoryId,
  isHistoryIdSaved,
  formatHistoryShareText,
  TAREEKHUNA_QUIZ_QUESTIONS,
  TareekhunaQuizQuestion,
} from '../../utils/tareekhunaService';
import { getHijriDate } from '../../utils/prayerCalculator';
import { soundManager } from '../../utils/audio';
import { useTheme } from '../../context/ThemeContext';
import { OurHistorySectionSvg } from '../Home/RifqSectionIcons';

interface OurHistoryViewProps {
  onBack: () => void;
  initialEventId?: string | null;
}

type HistoryTab =
  | 'all'
  | 'timeline'
  | 'on_this_day'
  | 'battles'
  | 'scholars'
  | 'civilization'
  | 'quiz'
  | 'favorites';

export const OurHistoryView: React.FC<OurHistoryViewProps> = ({ onBack, initialEventId }) => {
  const { isDark } = useTheme();

  // Tab State
  const [activeTab, setActiveTab] = useState<HistoryTab>('all');
  const [selectedEra, setSelectedEra] = useState<TareekhunaEra | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEvent, setSelectedEvent] = useState<TareekhunaEvent | null>(() => {
    if (initialEventId) {
      return TAREEKHUNA_EVENTS.find((e) => e.id === initialEventId) || null;
    }
    return null;
  });

  // Saved Favorites State
  const [savedIds, setSavedIds] = useState<string[]>(getSavedHistoryIds);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // Current Hijri Date for "On This Day"
  const todayHijri = useMemo(() => {
    try {
      return getHijriDate(new Date());
    } catch {
      return { day: 1, month: 1, year: 1447, dayName: 'اليوم', formatted: '1 محرم 1447 هـ', monthName: 'محرم' };
    }
  }, []);

  const [selectedHijriMonth, setSelectedHijriMonth] = useState<number>(todayHijri.month);

  // Sync favorites on storage events
  useEffect(() => {
    const handleFavChange = () => setSavedIds(getSavedHistoryIds());
    window.addEventListener('rifq-tareekhuna-favorites-changed', handleFavChange);
    return () => window.removeEventListener('rifq-tareekhuna-favorites-changed', handleFavChange);
  }, []);

  // Filtered Events
  const filteredEvents = useMemo(() => {
    let list = [...TAREEKHUNA_EVENTS];

    // Filter by Tab
    if (activeTab === 'timeline') {
      if (selectedEra !== 'all') {
        list = list.filter((e) => e.era === selectedEra);
      }
    } else if (activeTab === 'battles') {
      list = list.filter((e) => e.category === 'battle_conquest');
    } else if (activeTab === 'scholars') {
      list = list.filter((e) => e.category === 'scholar_personality');
    } else if (activeTab === 'civilization') {
      list = list.filter((e) => e.category === 'civilization');
    } else if (activeTab === 'on_this_day') {
      list = list.filter((e) => e.hijriMonth === selectedHijriMonth);
      // Sort by day in month
      list.sort((a, b) => a.hijriDay - b.hijriDay);
    } else if (activeTab === 'favorites') {
      list = list.filter((e) => savedIds.includes(e.id));
    }

    // Filter by Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          e.summary.toLowerCase().includes(q) ||
          e.location.toLowerCase().includes(q) ||
          e.hijriYear.toLowerCase().includes(q) ||
          e.gregorianYear.toLowerCase().includes(q) ||
          e.keyFigures?.some((fig) => fig.toLowerCase().includes(q))
      );
    }

    return list;
  }, [activeTab, selectedEra, selectedHijriMonth, savedIds, searchQuery]);

  // "Today in History" Events
  const todayExactEvents = useMemo(() => {
    return TAREEKHUNA_EVENTS.filter(
      (e) => e.hijriDay === todayHijri.day && e.hijriMonth === todayHijri.month
    );
  }, [todayHijri]);

  const handleToggleFavorite = useCallback(
    (id: string, e?: React.MouseEvent) => {
      e?.stopPropagation();
      soundManager.triggerHaptic(20);
      const isSaved = toggleSavedHistoryId(id);
      setSavedIds(getSavedHistoryIds());
      setCopyFeedback(isSaved ? 'تمت الإضافة إلى المحفوظات 🤍' : 'تمت الإزالة من المحفوظات');
      setTimeout(() => setCopyFeedback(null), 2200);
    },
    []
  );

  const handleShare = useCallback(
    async (event: TareekhunaEvent, e?: React.MouseEvent) => {
      e?.stopPropagation();
      soundManager.triggerHaptic(25);
      const text = formatHistoryShareText(event);

      if (navigator.share) {
        try {
          await navigator.share({
            title: event.title,
            text,
          });
          return;
        } catch {
          // fallback to clipboard
        }
      }

      try {
        await navigator.clipboard.writeText(text);
        setCopyFeedback('تم نسخ تفاصيل القصة لمشاركتها 📋');
        setTimeout(() => setCopyFeedback(null), 2500);
      } catch {
        // ignore
      }
    },
    []
  );

  // Quiz State
  const [quizState, setQuizState] = useState<{
    currentIndex: number;
    selectedOption: number | null;
    isAnswered: boolean;
    score: number;
    isFinished: boolean;
  }>({
    currentIndex: 0,
    selectedOption: null,
    isAnswered: false,
    score: 0,
    isFinished: false,
  });

  const handleQuizAnswer = (optionIndex: number) => {
    if (quizState.isAnswered) return;
    const currentQ = TAREEKHUNA_QUIZ_QUESTIONS[quizState.currentIndex];
    const isCorrect = optionIndex === currentQ.correctIndex;

    if (isCorrect) {
      soundManager.playBeadClick(0.9, 'golden_bell');
      soundManager.triggerHaptic([30]);
    } else {
      soundManager.playBeadClick(0.6, 'wood');
      soundManager.triggerHaptic([40, 60, 40]);
    }

    setQuizState((prev) => ({
      ...prev,
      selectedOption: optionIndex,
      isAnswered: true,
      score: isCorrect ? prev.score + 1 : prev.score,
    }));
  };

  const handleNextQuizQuestion = () => {
    soundManager.triggerHaptic(20);
    if (quizState.currentIndex + 1 >= TAREEKHUNA_QUIZ_QUESTIONS.length) {
      setQuizState((prev) => ({ ...prev, isFinished: true }));
    } else {
      setQuizState((prev) => ({
        ...prev,
        currentIndex: prev.currentIndex + 1,
        selectedOption: null,
        isAnswered: false,
      }));
    }
  };

  const handleRestartQuiz = () => {
    soundManager.triggerHaptic(25);
    setQuizState({
      currentIndex: 0,
      selectedOption: null,
      isAnswered: false,
      score: 0,
      isFinished: false,
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-28 pt-2 select-none animate-fade-in" dir="rtl">
      {/* Toast Feedback */}
      {copyFeedback && (
        <div className="fixed bottom-24 sm:bottom-20 right-1/2 translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-full text-xs font-black shadow-2xl border border-[#5B5FEF]/40 flex items-center gap-2 animate-fade-in pointer-events-none whitespace-nowrap">
          <span>{copyFeedback}</span>
        </div>
      )}

      {/* ── Top Header & Hero Card ── */}
      <div className="bg-gradient-to-br from-[#FAF8F5] via-[#FFFFFF] to-[#F3EDE2] dark:from-[#1D1E30] dark:via-[#1A1B2D] dark:to-[#252238] rounded-3xl p-5 sm:p-7 border border-[#E9E1D2] dark:border-[#38324F] shadow-sm relative overflow-hidden">
        {/* Decorative Watermark & Glow */}
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-[#D4AF37]/10 dark:bg-[#D4AF37]/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute top-4 left-4 opacity-15 pointer-events-none">
          <OurHistorySectionSvg size={88} />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <button
              onClick={onBack}
              aria-label="العودة للرئيسية"
              className="w-10 h-10 rounded-2xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#363852] text-[#25263A] dark:text-white flex items-center justify-center hover:border-[#5B5FEF] hover:text-[#5B5FEF] transition-all cursor-pointer shadow-xs shrink-0"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#D4AF37]/15 text-[#B8860B] dark:text-[#E5C158] border border-[#D4AF37]/30">
                  قسم رقم 6 · جديد
                </span>
                <span className="text-xs text-[#77798C] dark:text-[#A0A2BA] font-medium">
                  {todayHijri.formatted}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-[#25263A] dark:text-white font-cairo mt-1">
                تاريخنا الإسلامي العظيم
              </h1>
              <p className="text-xs sm:text-sm text-[#77798C] dark:text-[#A0A2BA] font-medium mt-1">
                محطات، معارك فاصلة، أئمة وأعلام، وحضارة أضاءت مشارق الأرض ومغاربها
              </p>
            </div>
          </div>

          {/* Quick Counter Chips */}
          <div className="flex items-center gap-2 self-stretch md:self-auto overflow-x-auto pb-1 md:pb-0">
            <div className="px-3 py-2 rounded-2xl bg-white/90 dark:bg-[#24253B] border border-[#E9E1D2] dark:border-[#38324F] flex flex-col items-center justify-center min-w-[70px]">
              <span className="text-base font-black text-[#B8860B] dark:text-[#E5C158]">
                {TAREEKHUNA_EVENTS.length}+
              </span>
              <span className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] font-bold">
                محطة موثقة
              </span>
            </div>
            <div className="px-3 py-2 rounded-2xl bg-white/90 dark:bg-[#24253B] border border-[#E9E1D2] dark:border-[#38324F] flex flex-col items-center justify-center min-w-[70px]">
              <span className="text-base font-black text-[#5B5FEF]">
                {TAREEKHUNA_ERAS.length}
              </span>
              <span className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] font-bold">
                عصور كبرى
              </span>
            </div>
            <div className="px-3 py-2 rounded-2xl bg-white/90 dark:bg-[#24253B] border border-[#E9E1D2] dark:border-[#38324F] flex flex-col items-center justify-center min-w-[70px]">
              <span className="text-base font-black text-[#0D9488]">
                {savedIds.length}
              </span>
              <span className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] font-bold">
                محفوظة لك
              </span>
            </div>
          </div>
        </div>

        {/* ── Search Bar ── */}
        <div className="relative mt-5">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن معركة، شخصية (صلاح الدين، البخاري...)، مكان، أو سنة هجرية..."
            className="w-full h-11 pr-11 pl-10 rounded-2xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#363852] text-xs font-bold text-[#25263A] dark:text-white placeholder-[#989AA8] focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all shadow-xs"
          />
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#77798C] pointer-events-none">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <line x1="21" y1="21" x2="16.65" y2="16.65" />
            </svg>
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#77798C] hover:text-[#25263A] dark:hover:text-white text-xs font-bold"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* ── Highlight Banner: حدث في مثل هذا اليوم من تاريخنا ── */}
      {activeTab !== 'quiz' && (
        <div className="bg-gradient-to-r from-[#FFFDF8] via-[#FAF6EC] to-[#F4ECE0] dark:from-[#232135] dark:via-[#26243A] dark:to-[#1E1C2C] rounded-2xl p-4 sm:p-5 border border-[#E8D9BD] dark:border-[#423C58] shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between gap-3 mb-2.5">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-[#D4AF37]/20 text-[#B8860B] dark:text-[#E5C158] flex items-center justify-center text-sm">
                🌟
              </span>
              <div>
                <h2 className="text-sm sm:text-base font-black text-[#25263A] dark:text-white font-cairo">
                  حدث في مثل هذا اليوم ({todayHijri.day} {todayHijri.monthName})
                </h2>
                <span className="text-[11px] text-[#77798C] dark:text-[#A0A2BA] font-medium">
                  أبرز المحطات الإسلامية المرتبطة بهذا التاريخ المبارك
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setActiveTab('on_this_day');
                setSelectedHijriMonth(todayHijri.month);
              }}
              className="text-xs font-black text-[#B8860B] dark:text-[#E5C158] hover:underline flex items-center gap-1 shrink-0"
            >
              <span>تصفح الأشهر</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6" />
              </svg>
            </button>
          </div>

          {todayExactEvents.length > 0 ? (
            <div className="space-y-2 mt-3">
              {todayExactEvents.map((event) => (
                <div
                  key={event.id}
                  onClick={() => setSelectedEvent(event)}
                  className="bg-white/80 dark:bg-[#1E1F35]/80 hover:bg-white dark:hover:bg-[#1E1F35] p-3 rounded-xl border border-[#E9DFCE] dark:border-[#38334E] flex items-center justify-between gap-3 cursor-pointer transition-all hover:shadow-xs group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-xl shrink-0">{event.icon || '📜'}</span>
                    <div className="truncate">
                      <h4 className="text-xs sm:text-sm font-bold text-[#25263A] dark:text-white truncate group-hover:text-[#B8860B] transition-colors">
                        {event.title}
                      </h4>
                      <span className="text-[11px] text-[#77798C] dark:text-[#A0A2BA]">
                        {event.hijriYear} ({event.gregorianYear}) · {event.location}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-[#5B5FEF] shrink-0">
                    اقرأ القصة ←
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-[#77798C] dark:text-[#A0A2BA] mt-1 leading-relaxed">
              استكشف أبرز أحداث شهر {todayHijri.monthName} وباقي شهور السنة الهجرية من خلال تبويب «تقويم الأشهر والأيام».
            </p>
          )}
        </div>
      )}

      {/* ── Navigation Tabs ── */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-[#E6E6F0] dark:border-[#2D2E45] px-1">
        {(
          [
            { id: 'all', label: 'الكل والموجز', icon: '🌟' },
            { id: 'timeline', label: 'خط العصور الزمني', icon: '⏳' },
            { id: 'on_this_day', label: 'تقويم الشهور والأيام', icon: '🗓️' },
            { id: 'battles', label: 'غزوات وفتوحات', icon: '⚔️' },
            { id: 'scholars', label: 'أعلام وعلماء', icon: '📖' },
            { id: 'civilization', label: 'حضارة وعمارة', icon: '🏛️' },
            { id: 'quiz', label: 'مسابقة تاريخنا', icon: '🏆' },
            { id: 'favorites', label: `المحفوظات (${savedIds.length})`, icon: '🤍' },
          ] as { id: HistoryTab; label: string; icon: string }[]
        ).map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                soundManager.triggerHaptic(15);
                setActiveTab(tab.id);
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-[#25263A] text-white dark:bg-[#D4AF37] dark:text-[#181824] shadow-xs'
                  : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#25263A] dark:hover:text-white border border-[#E6E6F0] dark:border-[#363852]'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ── Sub-Filters: Eras Timeline Filter ── */}
      {activeTab === 'timeline' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-[#25263A] dark:text-white font-cairo">
              العصور التاريخية الكبرى:
            </h3>
            <span className="text-xs text-[#77798C]">اضغط على أي عصر لعرض محطاته</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            <button
              onClick={() => setSelectedEra('all')}
              className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                selectedEra === 'all'
                  ? 'bg-[#25263A] text-white border-[#25263A] shadow-xs'
                  : 'bg-white dark:bg-[#25263A] text-[#25263A] dark:text-white border-[#E6E6F0] dark:border-[#363852] hover:border-[#D4AF37]'
              }`}
            >
              <div className="text-base mb-1">🌍</div>
              <div className="text-xs font-black">جميع العصور</div>
              <div className="text-[10px] text-[#A0A2BA] mt-0.5">كامل التاريخ الإسلامي</div>
            </button>

            {TAREEKHUNA_ERAS.map((era) => {
              const isSelected = selectedEra === era.id;
              return (
                <button
                  key={era.id}
                  onClick={() => {
                    soundManager.triggerHaptic(15);
                    setSelectedEra(era.id);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-br from-[#25263A] to-[#1E1F35] text-white border-[#D4AF37] shadow-sm'
                      : 'bg-white dark:bg-[#25263A] text-[#25263A] dark:text-white border-[#E6E6F0] dark:border-[#363852] hover:border-[#D4AF37]'
                  }`}
                >
                  <div className="text-base mb-1">{era.icon}</div>
                  <div className="text-xs font-black truncate">{era.title}</div>
                  <div className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] mt-0.5 line-clamp-1">
                    {era.subtitle}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Sub-Filters: Hijri Months for On This Day ── */}
      {activeTab === 'on_this_day' && (
        <div className="space-y-3 animate-fade-in bg-white dark:bg-[#202136] p-4 rounded-2xl border border-[#E6E6F0] dark:border-[#32344D]">
          <div className="flex items-center justify-between">
            <h3 className="text-xs sm:text-sm font-black text-[#25263A] dark:text-white font-cairo">
              اختر الشهر الهجري لتصفح أحداثه:
            </h3>
            <span className="text-[11px] text-[#77798C] dark:text-[#A0A2BA]">
              {HIJRI_MONTHS_LIST.find((m) => m.number === selectedHijriMonth)?.isSacred
                ? 'من الأشهر الحُرُم 🌙'
                : 'شهر هجري مبارك'}
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {HIJRI_MONTHS_LIST.map((month) => {
              const isSelected = selectedHijriMonth === month.number;
              const isCurrent = todayHijri.month === month.number;
              return (
                <button
                  key={month.number}
                  onClick={() => {
                    soundManager.triggerHaptic(15);
                    setSelectedHijriMonth(month.number);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 relative ${
                    isSelected
                      ? 'bg-[#D4AF37] text-[#181824] shadow-xs'
                      : 'bg-[#F7F7FC] dark:bg-[#282942] text-[#25263A] dark:text-[#DFE0EC] hover:bg-[#EAEAF5]'
                  }`}
                >
                  {isCurrent && (
                    <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#5B5FEF]" />
                  )}
                  {month.nameAr}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-[#77798C] dark:text-[#A0A2BA] bg-[#FAF8F5] dark:bg-[#1A1B2D] p-2.5 rounded-xl border border-[#EFE8DD] dark:border-[#2C2E46]">
            💡 {HIJRI_MONTHS_LIST.find((m) => m.number === selectedHijriMonth)?.meaningAr}
          </p>
        </div>
      )}

      {/* ── Quiz View ── */}
      {activeTab === 'quiz' && (
        <div className="bg-white dark:bg-[#1E1F35] rounded-3xl p-5 sm:p-7 border border-[#E6E6F0] dark:border-[#32344D] shadow-sm space-y-6 animate-fade-in">
          {!quizState.isFinished ? (
            <>
              {/* Quiz Header & Progress */}
              <div className="flex items-center justify-between border-b border-[#E6E6F0] dark:border-[#2F304A] pb-4">
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 rounded-full bg-[#D4AF37]/15 text-[#B8860B] dark:text-[#E5C158] flex items-center justify-center text-sm font-black">
                    🏆
                  </span>
                  <div>
                    <h3 className="text-sm font-black text-[#25263A] dark:text-white font-cairo">
                      مسابقة تاريخنا الثقافية
                    </h3>
                    <span className="text-[11px] text-[#77798C]">
                      السؤال {quizState.currentIndex + 1} من {TAREEKHUNA_QUIZ_QUESTIONS.length}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-[#0D9488]">
                    النقاط: {quizState.score}
                  </span>
                  <div className="w-20 h-2 bg-[#F0F0F5] dark:bg-[#282942] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#D4AF37] transition-all duration-300"
                      style={{
                        width: `${((quizState.currentIndex + 1) / TAREEKHUNA_QUIZ_QUESTIONS.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Question Card */}
              {(() => {
                const q = TAREEKHUNA_QUIZ_QUESTIONS[quizState.currentIndex];
                return (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#5B5FEF]/10 text-[#5B5FEF]">
                        {q.badge}
                      </span>
                    </div>

                    <h4 className="text-base sm:text-lg font-black text-[#25263A] dark:text-white font-cairo leading-relaxed">
                      {q.question}
                    </h4>

                    {/* Options */}
                    <div className="space-y-2.5 pt-2">
                      {q.options.map((opt, idx) => {
                        const isSelected = quizState.selectedOption === idx;
                        const isCorrect = idx === q.correctIndex;
                        let optionStyle =
                          'bg-[#FAF8F5] dark:bg-[#25263E] border-[#EAE3D5] dark:border-[#383A57] text-[#25263A] dark:text-white hover:border-[#D4AF37]';

                        if (quizState.isAnswered) {
                          if (isCorrect) {
                            optionStyle =
                              'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-bold';
                          } else if (isSelected) {
                            optionStyle =
                              'bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-800 dark:text-rose-200 font-bold';
                          } else {
                            optionStyle = 'opacity-60 bg-gray-50 dark:bg-[#1E1F35] border-transparent';
                          }
                        }

                        return (
                          <button
                            key={idx}
                            disabled={quizState.isAnswered}
                            onClick={() => handleQuizAnswer(idx)}
                            className={`w-full p-3.5 rounded-2xl border text-right text-xs sm:text-sm font-bold transition-all cursor-pointer flex items-center justify-between ${optionStyle}`}
                          >
                            <span>{opt}</span>
                            {quizState.isAnswered && (
                              <span>{isCorrect ? '✅' : isSelected ? '❌' : ''}</span>
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanation */}
                    {quizState.isAnswered && (
                      <div className="p-3.5 rounded-2xl bg-[#F6F5FD] dark:bg-[#22233C] border border-[#5B5FEF]/30 text-xs text-[#25263A] dark:text-[#E2E3F3] leading-relaxed animate-fade-in space-y-2">
                        <div className="font-black text-[#5B5FEF]">💡 توضيح تاريخي:</div>
                        <p>{q.explanation}</p>
                        <div className="pt-2 flex justify-end">
                          <button
                            onClick={handleNextQuizQuestion}
                            className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-black hover:bg-[#474BCD] transition-colors cursor-pointer"
                          >
                            {quizState.currentIndex + 1 >= TAREEKHUNA_QUIZ_QUESTIONS.length
                              ? 'عرض النتيجة النهائية 🎯'
                              : 'السؤال التالي ←'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </>
          ) : (
            /* Finished Screen */
            <div className="text-center py-6 space-y-4 animate-fade-in">
              <div className="text-5xl">🏆</div>
              <h3 className="text-xl font-black text-[#25263A] dark:text-white font-cairo">
                أحسنت! أتممت مسابقة تاريخنا
              </h3>
              <p className="text-sm text-[#77798C] dark:text-[#A0A2BA]">
                نتيجتك:{' '}
                <span className="font-black text-xl text-[#B8860B] dark:text-[#E5C158]">
                  {quizState.score}
                </span>{' '}
                من {TAREEKHUNA_QUIZ_QUESTIONS.length}
              </p>

              <div className="inline-block px-4 py-2 rounded-full bg-[#D4AF37]/15 text-[#B8860B] dark:text-[#E5C158] font-black text-xs border border-[#D4AF37]/30">
                {quizState.score >= 8
                  ? '🏅 وسام مؤرخ رِفْق المتميز'
                  : quizState.score >= 5
                  ? '📜 وسام الباحث التاريخي'
                  : '🌱 وسام محب التاريخ الإسلامي'}
              </div>

              <div className="pt-4 flex items-center justify-center gap-3">
                <button
                  onClick={handleRestartQuiz}
                  className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] text-white text-xs font-black hover:bg-[#474BCD] transition-colors cursor-pointer"
                >
                  إعادة المسابقة 🔄
                </button>
                <button
                  onClick={() => setActiveTab('all')}
                  className="px-5 py-2.5 rounded-2xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#363852] text-xs font-black text-[#25263A] dark:text-white hover:border-[#5B5FEF] transition-colors cursor-pointer"
                >
                  العودة للموسوعة 📜
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Events Grid / List ── */}
      {activeTab !== 'quiz' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-black text-[#77798C] dark:text-[#A0A2BA]">
              عرض {filteredEvents.length} حدث ومحطة
            </span>
          </div>

          {filteredEvents.length === 0 ? (
            <div className="bg-white dark:bg-[#1E1F35] rounded-3xl p-8 text-center border border-[#E6E6F0] dark:border-[#2F304A] space-y-3">
              <div className="text-4xl">🔍</div>
              <h4 className="text-base font-black text-[#25263A] dark:text-white font-cairo">
                {activeTab === 'favorites'
                  ? 'لا توجد محطات محفوظة بعد'
                  : 'لم نجد نتائج مطابقة لبحثك'}
              </h4>
              <p className="text-xs text-[#77798C] max-w-sm mx-auto">
                {activeTab === 'favorites'
                  ? 'يمكنك حفظ أي حدث تاريخي بالضغط على علامة القلب 🤍 للرجوع إليه في أي وقت.'
                  : 'جرب البحث بكلمات أخرى أو اختر عصراً أو تصنيفاً مختلفاً.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredEvents.map((event) => {
                const isSaved = savedIds.includes(event.id);
                const eraMeta = TAREEKHUNA_ERAS.find((era) => era.id === event.era);
                const categoryMeta = TAREEKHUNA_CATEGORIES.find((cat) => cat.id === event.category);

                return (
                  <div
                    key={event.id}
                    onClick={() => {
                      soundManager.triggerHaptic(15);
                      setSelectedEvent(event);
                    }}
                    className="bg-white dark:bg-[#1E1F35] rounded-2xl p-4 sm:p-5 border border-[#EBE6DC] dark:border-[#32344F] hover:border-[#D4AF37] dark:hover:border-[#D4AF37] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between group relative overflow-hidden"
                  >
                    {/* Top Era / Category Accent Bar */}
                    <div
                      className="absolute top-0 left-0 right-0 h-1"
                      style={{ backgroundColor: eraMeta?.color || '#D4AF37' }}
                    />

                    <div>
                      {/* Meta Tags */}
                      <div className="flex items-center justify-between gap-2 mb-2.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className="px-2 py-0.5 rounded-full text-[10px] font-black text-white"
                            style={{ backgroundColor: eraMeta?.color || '#5B5FEF' }}
                          >
                            {eraMeta?.title}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#F4F4F8] dark:bg-[#282942] text-[#55566B] dark:text-[#C5C7DD]">
                            {categoryMeta?.icon} {categoryMeta?.title}
                          </span>
                        </div>

                        {/* Action buttons (Bookmark & Share) */}
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={(e) => handleToggleFavorite(event.id, e)}
                            aria-label="حفظ في المفضلة"
                            className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#F2ECE0] flex items-center justify-center text-xs transition-colors cursor-pointer"
                          >
                            {isSaved ? '❤️' : '🤍'}
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleShare(event, e)}
                            aria-label="مشاركة القصة"
                            className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#F2ECE0] flex items-center justify-center text-xs text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="18" cy="5" r="3" />
                              <circle cx="6" cy="12" r="3" />
                              <circle cx="18" cy="19" r="3" />
                              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                              <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Title & Icon */}
                      <div className="flex items-start gap-2.5">
                        <span className="text-2xl shrink-0 mt-0.5">{event.icon || '📜'}</span>
                        <h4 className="text-sm sm:text-base font-black text-[#25263A] dark:text-white font-cairo leading-snug group-hover:text-[#B8860B] transition-colors">
                          {event.title}
                        </h4>
                      </div>

                      {/* Date & Location */}
                      <div className="flex items-center gap-2 text-[11px] text-[#77798C] dark:text-[#A0A2BA] font-medium mt-2">
                        <span className="font-bold text-[#D4AF37]">{event.hijriYear}</span>
                        <span>·</span>
                        <span>{event.gregorianYear}</span>
                        <span>·</span>
                        <span className="truncate">{event.location}</span>
                      </div>

                      {/* Summary */}
                      <p className="text-xs text-[#52546A] dark:text-[#B9BACD] leading-relaxed mt-2.5 line-clamp-3">
                        {event.summary}
                      </p>

                      {/* Key Figures badges */}
                      {event.keyFigures && event.keyFigures.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap mt-3 pt-2.5 border-t border-[#F2ECE0] dark:border-[#2C2E46]">
                          <span className="text-[10px] text-[#888A9E] font-medium">أعلام:</span>
                          {event.keyFigures.slice(0, 3).map((fig, idx) => (
                            <span
                              key={idx}
                              className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#FAF8F5] dark:bg-[#282942] text-[#25263A] dark:text-[#DFE0EC]"
                            >
                              {fig}
                            </span>
                          ))}
                          {event.keyFigures.length > 3 && (
                            <span className="text-[10px] text-[#888A9E]">
                              +{event.keyFigures.length - 3}
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Bottom CTA */}
                    <div className="flex items-center justify-between text-xs font-black text-[#5B5FEF] dark:text-[#8D90FF] pt-3 mt-2 border-t border-[#F5F2EB] dark:border-[#2B2C44]">
                      <span>اقرأ القصة والدروس</span>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <polyline points="15 18 9 12 15 6" />
                      </svg>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ── Event Details Modal / Drawer ── */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5" dir="rtl">
          {/* Backdrop */}
          <div
            onClick={() => setSelectedEvent(null)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
          />

          {/* Modal Container */}
          <div className="relative w-full max-w-2xl bg-white dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#383A57] flex flex-col max-h-[90vh] z-10 animate-scale-up overflow-hidden">
            {/* Header */}
            <div className="p-5 border-b border-[#EAE4D8] dark:border-[#30324E] bg-gradient-to-br from-[#FAF8F5] via-white to-[#F6EFE3] dark:from-[#25263E] dark:via-[#1E1F35] dark:to-[#222137] relative">
              <button
                onClick={() => setSelectedEvent(null)}
                aria-label="إغلاق"
                className="absolute top-4 left-4 w-8 h-8 rounded-full bg-white dark:bg-[#2B2C46] border border-[#E6E6F0] dark:border-[#3A3C5C] text-[#25263A] dark:text-white flex items-center justify-center hover:border-[#D4AF37] transition-colors cursor-pointer"
              >
                ✕
              </button>

              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#D4AF37]/20 text-[#B8860B] dark:text-[#E5C158]">
                  {TAREEKHUNA_ERAS.find((e) => e.id === selectedEvent.era)?.title}
                </span>
                <span className="text-xs text-[#77798C] dark:text-[#A0A2BA]">
                  {selectedEvent.hijriYear} ({selectedEvent.gregorianYear}) · {selectedEvent.location}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-3xl shrink-0">{selectedEvent.icon || '📜'}</span>
                <h3 className="text-lg sm:text-xl font-black text-[#25263A] dark:text-white font-cairo leading-snug">
                  {selectedEvent.title}
                </h3>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-5 overflow-y-auto space-y-5 text-[#25263A] dark:text-white">
              {/* Summary Highlight */}
              <div className="p-3.5 rounded-2xl bg-[#FFFDF8] dark:bg-[#25263E] border border-[#EFE5D3] dark:border-[#3C3E5E] text-xs sm:text-sm font-semibold leading-relaxed text-[#564933] dark:text-[#E5DBCC]">
                {selectedEvent.summary}
              </div>

              {/* Full Story */}
              <div>
                <h4 className="text-xs font-black text-[#B8860B] dark:text-[#E5C158] uppercase tracking-wider mb-2 font-cairo flex items-center gap-1.5">
                  <span>📖</span>
                  <span>القصة التاريخية الموثقة:</span>
                </h4>
                <p className="text-xs sm:text-sm leading-relaxed text-[#35374E] dark:text-[#D1D2E5] whitespace-pre-line text-justify font-amiri text-[15px] sm:text-[16px]">
                  {selectedEvent.fullStory}
                </p>
              </div>

              {/* Key Figures */}
              {selectedEvent.keyFigures && selectedEvent.keyFigures.length > 0 && (
                <div>
                  <h4 className="text-xs font-black text-[#5B5FEF] dark:text-[#8D90FF] uppercase tracking-wider mb-2 font-cairo flex items-center gap-1.5">
                    <span>👤</span>
                    <span>أبرز الشخصيات المشاركة:</span>
                  </h4>
                  <div className="flex items-center gap-2 flex-wrap">
                    {selectedEvent.keyFigures.map((fig, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 rounded-xl bg-[#F6F5FD] dark:bg-[#282944] border border-[#5B5FEF]/20 text-xs font-bold text-[#25263A] dark:text-white"
                      >
                        {fig}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Lessons & Insights */}
              {selectedEvent.lessons && selectedEvent.lessons.length > 0 && (
                <div>
                  <h4 className="text-xs font-black text-[#0D9488] dark:text-[#2DD4BF] uppercase tracking-wider mb-2 font-cairo flex items-center gap-1.5">
                    <span>💡</span>
                    <span>من الدروس والعِبر المستفادة:</span>
                  </h4>
                  <div className="space-y-2">
                    {selectedEvent.lessons.map((lesson, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#F0FDF4] dark:bg-[#1A2E26] border border-[#DCFCE7] dark:border-[#24483B] text-xs font-medium text-[#166534] dark:text-[#86EFAC]"
                      >
                        <span className="shrink-0 mt-0.5">✦</span>
                        <span>{lesson}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* References */}
              {selectedEvent.references && (
                <div className="pt-3 border-t border-[#EAE4D8] dark:border-[#30324E] text-[11px] text-[#77798C] dark:text-[#A0A2BA] flex items-center gap-2">
                  <span className="font-bold">📚 المصادر:</span>
                  <span>{selectedEvent.references}</span>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#EAE4D8] dark:border-[#30324E] bg-[#FAF8F5] dark:bg-[#202138] flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleToggleFavorite(selectedEvent.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                    savedIds.includes(selectedEvent.id)
                      ? 'bg-rose-50 text-rose-600 border border-rose-200 dark:bg-rose-950/40 dark:border-rose-800'
                      : 'bg-white dark:bg-[#2B2C46] border border-[#E6E6F0] dark:border-[#3A3C5C] text-[#25263A] dark:text-white hover:border-[#D4AF37]'
                  }`}
                >
                  <span>{savedIds.includes(selectedEvent.id) ? '❤️' : '🤍'}</span>
                  <span>{savedIds.includes(selectedEvent.id) ? 'محفوظ' : 'حفظ في المفضلة'}</span>
                </button>

                <button
                  onClick={() => handleShare(selectedEvent)}
                  className="px-4 py-2 rounded-xl bg-white dark:bg-[#2B2C46] border border-[#E6E6F0] dark:border-[#3A3C5C] text-xs font-black text-[#5B5FEF] hover:bg-[#5B5FEF]/5 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="18" cy="5" r="3" />
                    <circle cx="6" cy="12" r="3" />
                    <circle cx="18" cy="19" r="3" />
                    <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                    <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                  </svg>
                  <span>مشاركة</span>
                </button>
              </div>

              <button
                onClick={() => setSelectedEvent(null)}
                className="px-5 py-2 rounded-xl bg-[#25263A] dark:bg-[#D4AF37] text-white dark:text-[#181824] text-xs font-black hover:opacity-90 transition-opacity cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default OurHistoryView;
