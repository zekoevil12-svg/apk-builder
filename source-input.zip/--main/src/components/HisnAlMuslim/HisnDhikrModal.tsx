import React, { useState } from 'react';
import { X, Copy, Share2, Star, Check, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { HisnDhikrItem } from '../../data/hisnAlMuslimData';

interface HisnDhikrModalProps {
  dhikr: HisnDhikrItem;
  chapterTitle: string;
  isFavorite: boolean;
  onToggleFavorite: (dhikrId: string) => void;
  onClose: () => void;
}

export const HisnDhikrModal: React.FC<HisnDhikrModalProps> = ({
  dhikr,
  chapterTitle,
  isFavorite,
  onToggleFavorite,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [fontSize, setFontSize] = useState(24); // default Amiri 24px as requested
  const [counter, setCounter] = useState(0);

  const targetCount = dhikr.repetition || 1;
  const isCompleted = counter >= targetCount;

  const handleCopy = () => {
    let copyText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}`;
    if (dhikr.narrator) copyText += `\n👤 الراوي: ${dhikr.narrator}`;
    if (dhikr.grade) copyText += `\n⚖️ درجة الحديث: ${dhikr.grade}`;
    if (dhikr.virtue) copyText += `\n✨ الفضل: ${dhikr.virtue}`;
    copyText += `\n\nمن كتاب حصن المسلم — تطبيق رِفْق | RIFQ`;

    navigator.clipboard.writeText(copyText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleShare = async () => {
    let shareText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}`;
    if (dhikr.narrator) shareText += `\n👤 الراوي: ${dhikr.narrator}`;
    if (dhikr.virtue) shareText += `\n✨ الفضل: ${dhikr.virtue}`;
    shareText += `\n\nمن كتاب حصن المسلم — تطبيق رِفْق | RIFQ`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `حصن المسلم — ${chapterTitle}`,
          text: shareText,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  const handleIncrement = () => {
    if (counter < targetCount) {
      setCounter(prev => prev + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-[#FFFFFF] rounded-2xl border-2 border-[#5B5FEF] shadow-2xl overflow-hidden"
        dir="rtl"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gradient-to-r from-[#FFFFFF] via-[#F7F7FC] to-[#EEEEFF] border-b border-[#E6E6F0]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#5B5FEF]" />
            <h3 className="font-cairo font-bold text-base text-[#25263A] line-clamp-1">
              {chapterTitle}
            </h3>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Font size adjustments */}
            <button
              onClick={() => setFontSize(prev => Math.min(prev + 2, 34))}
              className="p-1.5 rounded-lg text-[#25263A] hover:bg-[#EEEEFF] transition-colors"
              title="تكبير الخط"
              aria-label="تكبير الخط"
            >
              <ZoomIn className="w-4 h-4 text-[#5B5FEF]" />
            </button>
            <button
              onClick={() => setFontSize(prev => Math.max(prev - 2, 18))}
              className="p-1.5 rounded-lg text-[#25263A] hover:bg-[#EEEEFF] transition-colors"
              title="تصغير الخط"
              aria-label="تصغير الخط"
            >
              <ZoomOut className="w-4 h-4 text-[#5B5FEF]" />
            </button>

            {/* Favorite toggle */}
            <button
              onClick={() => onToggleFavorite(dhikr.id)}
              className="p-1.5 rounded-lg hover:bg-[#EEEEFF] transition-colors"
              title="المفضلة"
            >
              <Star
                className={`w-5 h-5 transition-colors ${
                  isFavorite ? 'text-amber-500 fill-amber-500' : 'text-[#77798C]'
                }`}
              />
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#77798C] hover:text-[#25263A] hover:bg-black/5 transition-colors"
              aria-label="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Main Dhikr Card */}
          <div className="relative p-6 sm:p-7 rounded-xl bg-gradient-to-b from-[#FFFFFF] to-[#F7F7FC] border border-[#5B5FEF] shadow-sm">
            <div className="text-center font-amiri font-bold text-[#25263A] leading-loose selection:bg-[#5B5FEF]/30"
              style={{ fontSize: `${fontSize}px` }}
            >
              «{dhikr.text}»
            </div>
          </div>

          {/* Interactive Repetition Tracker if more than 1 repetition */}
          {targetCount > 1 && (
            <div className="p-4 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between">
              <div>
                <p className="font-cairo text-xs text-[#77798C]">التكرار المطلوب</p>
                <p className="font-cairo font-bold text-sm text-[#25263A]">
                  {targetCount} مرات (المكتمل: {counter})
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCounter(0)}
                  disabled={counter === 0}
                  className="p-2 rounded-lg text-[#77798C] hover:text-[#25263A] hover:bg-black/5 disabled:opacity-40"
                  title="إعادة ضبط العداد"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button
                  onClick={handleIncrement}
                  disabled={isCompleted}
                  className={`px-4 py-2 rounded-xl font-cairo font-bold text-sm shadow-sm transition-transform active:scale-95 flex items-center gap-2 ${
                    isCompleted
                      ? 'bg-[#5B5FEF] text-white'
                      : 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white hover:brightness-105'
                  }`}
                >
                  {isCompleted ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>اكتمل التكرار</span>
                    </>
                  ) : (
                    <span>تكرار ({counter}/{targetCount})</span>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Section: Source Breakdown (الكتاب، الرقم، الراوي، الدرجة) */}
          <div className="space-y-2 rounded-xl p-4 bg-[#FFFFFF] border border-[#E6E6F0] shadow-xs text-right">
            <div className="flex items-center gap-2 text-xs font-cairo font-bold text-[#5B5FEF]">
              <span>📖</span>
              <span>المصدر والتوثيق</span>
            </div>
            <p className="font-cairo text-xs sm:text-sm text-[#25263A] leading-relaxed">
              {dhikr.source}
            </p>

            {dhikr.narrator && (
              <div className="flex items-center gap-2 pt-1 border-t border-[#E6E6F0] font-cairo text-xs text-[#77798C]">
                <span className="text-[#5B5FEF]">الراوي:</span>
                <span className="text-[#25263A] font-semibold">{dhikr.narrator}</span>
              </div>
            )}

            {dhikr.grade && (
              <div className="flex items-center gap-2 font-cairo text-xs text-[#77798C]">
                <span className="text-[#5B5FEF]">درجة الحديث:</span>
                <span className="inline-block px-2 py-0.5 rounded-md bg-[#4CAF82]/12 text-[#4CAF82] font-semibold border border-[#4CAF82]/40">
                  {dhikr.grade}
                </span>
              </div>
            )}
          </div>

          {/* Section: Virtue (الفضل الشرعي) */}
          {dhikr.virtue && (
            <div className="rounded-xl p-4 bg-[#EEEEFF]/60 border border-[#E6E6F0]/70 text-right space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-cairo font-bold text-[#4145C7]">
                <span>✨</span>
                <span>فضل هذا الذكر</span>
              </div>
              <p className="font-cairo text-xs sm:text-sm text-[#25263A] leading-relaxed">
                {dhikr.virtue}
              </p>
            </div>
          )}
        </div>

        {/* Modal Bottom Actions Bar */}
        <div className="flex items-center justify-between p-4 bg-[#F7F7FC] border-t border-[#E6E6F0]">
          <div className="flex items-center gap-2">
            {/* Copy Button */}
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs sm:text-sm shadow-xs hover:brightness-105 transition-transform active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>نسخ</span>
                </>
              )}
            </button>

            {/* Share Button */}
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs sm:text-sm shadow-xs hover:bg-[#F7F7FC] transition-transform active:scale-95"
            >
              <Share2 className="w-4 h-4 text-[#5B5FEF]" />
              <span>مشاركة</span>
            </button>
          </div>

          <button
            onClick={() => onToggleFavorite(dhikr.id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs sm:text-sm font-cairo font-semibold transition-colors ${
              isFavorite
                ? 'bg-[#EEEEFF]/70 border-amber-300 text-[#4145C7]'
                : 'bg-white border-[#E6E6F0] text-[#77798C] hover:bg-gray-50'
            }`}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
            <span>{isFavorite ? 'في المفضلة' : 'تفضيل'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
