import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowRight, 
  Search, 
  Star, 
  BookOpen, 
  X,
  Sparkles,
  Share2,
  Copy,
  Check,
  Eye,
  SlidersHorizontal,
  BookmarkCheck
} from 'lucide-react';
import { 
  HISN_ALMUSLIM_CHAPTERS, 
  HISN_CATEGORIES, 
  HisnChapter,
  HisnDhikrItem
} from '../../data/hisnAlMuslimData';
import { HisnChapterDetailView } from './HisnChapterDetailView';
import { HisnDhikrModal } from './HisnDhikrModal';

interface HisnAlMuslimMainViewProps {
  onBack: () => void;
}

const STORAGE_FAVORITES_KEY = 'rifq_hisn_fav_athkar';
const STORAGE_CHAPTER_FAVORITES_KEY = 'rifq_hisn_fav_chapters';

type SearchScope = 'all' | 'chapters' | 'athkar' | 'sources';

// Arabic text normalization for smart and resilient searching
function normalizeArabic(text: string): string {
  if (!text) return '';
  return text
    // Remove diacritics / tashkeel
    .replace(/[\u064B-\u065F\u0670\u0617-\u061A]/g, '')
    // Remove tatweel / kashida
    .replace(/\u0640/g, '')
    // Normalize alifs
    .replace(/[أإآٱ]/g, 'ا')
    // Normalize taa marbuta
    .replace(/ة/g, 'ه')
    // Normalize yaa / alif maqsura
    .replace(/ى/g, 'ي')
    // Remove punctuation that might obstruct matching
    .replace(/[.,،؛:؟!«»"']/g, ' ')
    .toLowerCase()
    .trim();
}

// Highlight matched search tokens in text
function HighlightedText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;

  const tokens = query.trim().split(/\s+/).filter(Boolean).map(normalizeArabic);
  if (tokens.length === 0) return <>{text}</>;

  // Build a regex matching the raw words roughly
  // To preserve original tashkeel, we split text by spaces and check normalized tokens
  const words = text.split(/(\s+)/);

  return (
    <>
      {words.map((part, index) => {
        const normPart = normalizeArabic(part);
        const isMatched = tokens.some(token => normPart.includes(token));

        if (isMatched && normPart.length > 0) {
          return (
            <mark
              key={index}
              className="bg-[#EEEEFF] text-[#25263A] font-bold rounded px-1 py-0.5 border-b border-[#5B5FEF]"
            >
              {part}
            </mark>
          );
        }
        return <span key={index}>{part}</span>;
      })}
    </>
  );
}

const POPULAR_SEARCHES = [
  'الصباح والمساء',
  'أذكار النوم',
  'الهم والحزن',
  'سيد الاستغفار',
  'الاستخارة',
  'الرقية الشرعية',
  'دعاء السفر',
  'البخاري'
];

export const HisnAlMuslimMainView: React.FC<HisnAlMuslimMainViewProps> = ({ onBack }) => {
  const [selectedChapter, setSelectedChapter] = useState<HisnChapter | null>(null);
  const [selectedDhikrForModal, setSelectedDhikrForModal] = useState<{
    dhikr: HisnDhikrItem;
    chapterTitle: string;
  } | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchScope, setSearchScope] = useState<SearchScope>('all');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [copiedDhikrId, setCopiedDhikrId] = useState<string | null>(null);

  // Favorites state persisted locally (100% offline)
  const [favoriteAthkarIds, setFavoriteAthkarIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_FAVORITES_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [favoriteChapterIds, setFavoriteChapterIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CHAPTER_FAVORITES_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_FAVORITES_KEY, JSON.stringify(favoriteAthkarIds));
    } catch {
      // storage quota or private mode
    }
  }, [favoriteAthkarIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHAPTER_FAVORITES_KEY, JSON.stringify(favoriteChapterIds));
    } catch {
      // ignore
    }
  }, [favoriteChapterIds]);

  useEffect(() => {
    const handleAccountSync = () => {
      try {
        const savedAthkar = localStorage.getItem(STORAGE_FAVORITES_KEY);
        setFavoriteAthkarIds(savedAthkar ? JSON.parse(savedAthkar) : []);
        const savedChapters = localStorage.getItem(STORAGE_CHAPTER_FAVORITES_KEY);
        setFavoriteChapterIds(savedChapters ? JSON.parse(savedChapters) : []);
      } catch {
        // ignore
      }
    };
    window.addEventListener('rifq-user-data-synced', handleAccountSync);
    return () => window.removeEventListener('rifq-user-data-synced', handleAccountSync);
  }, []);

  const handleToggleFavoriteDhikr = (id: string) => {
    setFavoriteAthkarIds(prev => {
      const next = prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id];
      window.setTimeout(() => {
        window.dispatchEvent(new CustomEvent('rifq-local-data-mutated', { detail: { domain: 'athkar' } }));
      }, 0);
      return next;
    });
  };

  const handleToggleFavoriteChapter = (id: number) => {
    setFavoriteChapterIds(prev => {
      const next = prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id];
      window.setTimeout(() => {
        window.dispatchEvent(new CustomEvent('rifq-local-data-mutated', { detail: { domain: 'athkar' } }));
      }, 0);
      return next;
    });
  };

  const handleCopyDhikr = (dhikr: HisnDhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const copyText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}\nمن كتاب حصن المسلم — تطبيق رِفْق | RIFQ`;
    navigator.clipboard.writeText(copyText);
    setCopiedDhikrId(dhikr.id);
    setTimeout(() => setCopiedDhikrId(null), 2000);
  };

  const handleShareDhikr = async (dhikr: HisnDhikrItem, chapterTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}\nمن باب: ${chapterTitle}\n\nتطبيق رِفْق | RIFQ — حصن المسلم`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `حصن المسلم — ${chapterTitle}`,
          text: shareText,
        });
      } catch {
        // user cancelled
      }
    } else {
      navigator.clipboard.writeText(shareText);
      setCopiedDhikrId(dhikr.id);
      setTimeout(() => setCopiedDhikrId(null), 2000);
    }
  };

  // Normalized search query tokens
  const normQuery = useMemo(() => normalizeArabic(searchQuery), [searchQuery]);
  const queryTokens = useMemo(() => {
    return normQuery.split(/\s+/).filter(Boolean);
  }, [normQuery]);

  const isSearching = searchQuery.trim().length > 0;

  // Live search result evaluation:
  // 1. Matched Chapters
  const matchedChapters = useMemo(() => {
    if (!isSearching) {
      // Regular browsing filter
      return HISN_ALMUSLIM_CHAPTERS.filter(chapter => {
        if (selectedCategory !== 'الكل' && chapter.category !== selectedCategory) {
          return false;
        }
        if (showOnlyFavorites) {
          const isChapterFav = favoriteChapterIds.includes(chapter.id);
          const hasFavDhikr = chapter.athkar.some(d => favoriteAthkarIds.includes(d.id));
          if (!isChapterFav && !hasFavDhikr) return false;
        }
        return true;
      });
    }

    // When searching, find chapters where title, category or any dhikr matches
    return HISN_ALMUSLIM_CHAPTERS.filter(chapter => {
      const normTitle = normalizeArabic(chapter.title);
      const normCategory = normalizeArabic(chapter.category);

      const titleMatches = queryTokens.every(token => normTitle.includes(token));
      const categoryMatches = queryTokens.every(token => normCategory.includes(token));

      if (searchScope === 'chapters') {
        return titleMatches || categoryMatches;
      }

      // If scope is 'all', check title, category or content
      if (titleMatches || categoryMatches) return true;

      if (searchScope === 'all') {
        return chapter.athkar.some(dhikr => {
          const normText = normalizeArabic(dhikr.text);
          const normSource = normalizeArabic(dhikr.source);
          return queryTokens.every(token => normText.includes(token) || normSource.includes(token));
        });
      }

      return false;
    });
  }, [isSearching, selectedCategory, showOnlyFavorites, favoriteChapterIds, favoriteAthkarIds, queryTokens, searchScope]);

  // 2. Matched Athkar directly (flattened with chapter info for live athkar feed)
  const matchedAthkar = useMemo(() => {
    if (!isSearching) return [];
    if (searchScope === 'chapters') return [];

    const results: { chapter: HisnChapter; dhikr: HisnDhikrItem }[] = [];

    for (const chapter of HISN_ALMUSLIM_CHAPTERS) {
      for (const dhikr of chapter.athkar) {
        const normText = normalizeArabic(dhikr.text);
        const normSource = normalizeArabic(dhikr.source);
        const normNarrator = normalizeArabic(dhikr.narrator || '');
        const normVirtue = normalizeArabic(dhikr.virtue || '');
        const normChapter = normalizeArabic(chapter.title);

        let matches = false;

        if (searchScope === 'athkar') {
          // Only text and virtue
          matches = queryTokens.every(t => normText.includes(t) || normVirtue.includes(t));
        } else if (searchScope === 'sources') {
          // Source, narrator, book
          matches = queryTokens.every(t => normSource.includes(t) || normNarrator.includes(t));
        } else {
          // 'all'
          matches = queryTokens.every(
            t => normText.includes(t) || 
                 normSource.includes(t) || 
                 normNarrator.includes(t) || 
                 normVirtue.includes(t) ||
                 normChapter.includes(t)
          );
        }

        if (matches) {
          results.push({ chapter, dhikr });
        }
      }
    }

    return results;
  }, [isSearching, searchScope, queryTokens]);

  // If a chapter is selected, show Screen 2
  if (selectedChapter) {
    return (
      <HisnChapterDetailView
        chapter={selectedChapter}
        onBack={() => setSelectedChapter(null)}
        favorites={favoriteAthkarIds}
        onToggleFavorite={handleToggleFavoriteDhikr}
        chapterFavorites={favoriteChapterIds}
        onToggleChapterFavorite={handleToggleFavoriteChapter}
      />
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-200" dir="rtl">
      {/* 1. Top Header Bar */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-sm">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="رجوع"
            aria-label="رجوع"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          {/* Real PNG Icon badge */}
          <div className="w-12 h-12 rounded-full bg-white border-2 border-[#5B5FEF] p-1 flex items-center justify-center shadow-xs shrink-0 overflow-hidden">
            <img
              src="/assets/hisn_almuslim/icons/default.png"
              alt="حصن المسلم"
              className="w-full h-full object-contain"
            />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                حصن المسلم
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] text-[11px] font-cairo font-bold border border-[#E6E6F0]">
                أذكار الكتاب والسنة
              </span>
            </div>
            <p className="font-cairo text-xs text-[#77798C] mt-0.5">
              للشيخ سعيد بن علي بن وهف القحطاني رحمه الله
            </p>
          </div>
        </div>

        {/* Favorite filter button */}
        <button
          onClick={() => setShowOnlyFavorites(prev => !prev)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs sm:text-sm font-cairo font-semibold transition-all ${
            showOnlyFavorites
              ? 'bg-[#EEEEFF] border-amber-400 text-[#4145C7] shadow-xs'
              : 'bg-white border-[#E6E6F0] text-[#77798C] hover:bg-[#F7F7FC]'
          }`}
          title="عرض المفضلة فقط"
        >
          <Star className={`w-4 h-4 ${showOnlyFavorites ? 'fill-amber-500 text-amber-500' : ''}`} />
          <span className="hidden sm:inline">المفضلة</span>
        </button>
      </div>

      {/* 2. Welcome Card (البطاقة الترحيبية - hidden when actively searching to give full focus to live results) */}
      {!isSearching && (
        <div className="relative p-6 sm:p-7 rounded-2xl bg-gradient-to-br from-[#FFFFFF] via-[#F7F7FC] to-[#EEEEFF] border-2 border-[#5B5FEF] shadow-md overflow-hidden text-center">
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-[#EEEEFF] rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-[#EEEEFF] rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <div className="inline-flex items-center justify-center gap-2 px-3 py-1 rounded-full bg-white/80 border border-[#E6E6F0] shadow-2xs mx-auto">
              <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
              <span className="font-cairo font-bold text-xs text-[#25263A]">فضل الذكر في كتاب الله وسنة نبيه</span>
            </div>

            {/* Ayah */}
            <div className="space-y-1">
              <p className="font-amiri font-bold text-xl sm:text-2xl text-[#25263A] leading-relaxed">
                ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا اذْكُرُوا اللَّهَ ذِكْرًا كَثِيرًا﴾
              </p>
              <p className="font-cairo text-xs text-[#77798C]">
                [سورة الأحزاب: 41]
              </p>
            </div>

            <div className="w-16 h-0.5 bg-[#5B5FEF]/40 mx-auto" />

            {/* Hadith */}
            <div className="space-y-1">
              <p className="font-amiri text-lg sm:text-xl text-[#25263A]">
                «مَثَلُ الَّذِي يَذْكُرُ رَبَّهُ وَالَّذِي لاَ يَذْكُرُ رَبَّهُ مَثَلُ الْحَيِّ وَالْمَيِّتِ»
              </p>
              <p className="font-cairo text-xs text-[#77798C]">
                [صحيح البخاري: 6407]
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 3. Advanced Live Search Box */}
      <div className="space-y-3">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث حيّاً في نصوص الأذكار، أو عناوين الأبواب، أو الرواة والمصادر..."
            className="w-full pl-11 pr-12 py-3.5 sm:py-4 rounded-2xl bg-white border-2 border-[#5B5FEF] text-[#25263A] font-cairo placeholder-[#77798C] focus:outline-none focus:ring-4 focus:ring-[#5B5FEF]/20 shadow-md text-sm sm:text-base transition-all"
            autoComplete="off"
            spellCheck="false"
          />
          <Search className="w-5 h-5 text-[#5B5FEF] absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 p-1.5 rounded-full hover:bg-[#F7F7FC] text-[#77798C] hover:text-[#25263A] transition-colors"
              title="مسح البحث"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Scope Filters & Live Stats Bar */}
        {isSearching ? (
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-white border border-[#E6E6F0] shadow-xs">
            {/* Scope tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              <span className="font-cairo text-xs font-bold text-[#77798C] pl-1 shrink-0">نطاق البحث:</span>
              <button
                onClick={() => setSearchScope('all')}
                className={`px-3 py-1 rounded-lg font-cairo text-xs font-bold transition-colors ${
                  searchScope === 'all'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                }`}
              >
                الكل ({matchedChapters.length + matchedAthkar.length})
              </button>
              <button
                onClick={() => setSearchScope('chapters')}
                className={`px-3 py-1 rounded-lg font-cairo text-xs font-bold transition-colors ${
                  searchScope === 'chapters'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                }`}
              >
                الأبواب ({matchedChapters.length})
              </button>
              <button
                onClick={() => setSearchScope('athkar')}
                className={`px-3 py-1 rounded-lg font-cairo text-xs font-bold transition-colors ${
                  searchScope === 'athkar'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                }`}
              >
                نصوص الأذكار ({matchedAthkar.length})
              </button>
              <button
                onClick={() => setSearchScope('sources')}
                className={`px-3 py-1 rounded-lg font-cairo text-xs font-bold transition-colors ${
                  searchScope === 'sources'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                }`}
              >
                المصادر والرواة
              </button>
            </div>

            {/* Clear Button */}
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs font-cairo text-[#5B5FEF] hover:underline font-bold mr-auto px-2"
            >
              إلغاء البحث
            </button>
          </div>
        ) : (
          /* Popular Search Suggestions */
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs font-cairo">
            <span className="text-[#77798C] shrink-0 font-semibold">اقتراحات:</span>
            {POPULAR_SEARCHES.map(term => (
              <button
                key={term}
                onClick={() => setSearchQuery(term)}
                className="px-2.5 py-1 rounded-lg bg-white border border-[#E6E6F0] text-[#25263A] hover:bg-[#F7F7FC] hover:border-[#5B5FEF] shrink-0 transition-colors shadow-2xs"
              >
                {term}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Category Filter Pills (shown during regular browsing) */}
      {!isSearching && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {HISN_CATEGORIES.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3.5 py-1.5 rounded-xl font-cairo font-bold text-xs whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'bg-white text-[#77798C] border border-[#E6E6F0] hover:border-[#5B5FEF] hover:text-[#25263A]'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      )}

      {/* 4. Live Search Results Display */}
      {isSearching ? (
        <div className="space-y-6">
          {/* Matched Chapters Section */}
          {(searchScope === 'all' || searchScope === 'chapters') && matchedChapters.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-cairo font-bold text-sm sm:text-base text-[#25263A] flex items-center gap-2">
                  <BookmarkCheck className="w-4 h-4 text-[#5B5FEF]" />
                  <span>الأبواب المطابقة ({matchedChapters.length})</span>
                </h2>
                <span className="text-xs font-cairo text-[#77798C]">اضغط لفتح الباب</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {matchedChapters.map(chapter => {
                  const isFav = favoriteChapterIds.includes(chapter.id);
                  const iconSrc = `/assets/hisn_almuslim/icons/${chapter.iconName}`;

                  return (
                    <div
                      key={chapter.id}
                      onClick={() => setSelectedChapter(chapter)}
                      className="relative p-3.5 rounded-2xl bg-white border-2 border-[#E6E6F0] hover:border-[#5B5FEF] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 group"
                    >
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavoriteChapter(chapter.id);
                        }}
                        className="absolute top-2.5 left-2.5 p-1 rounded-lg text-gray-400 hover:text-amber-500 transition-colors z-10"
                        title="مفضلة الباب"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            isFav ? 'fill-amber-500 text-amber-500' : 'text-gray-300'
                          }`}
                        />
                      </button>

                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        {/* 60px White Circle with Thin Gold Border & Real PNG Icon */}
                        <div className="w-[52px] h-[52px] rounded-full bg-white border border-[#E6E6F0] p-1 flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-105 transition-transform overflow-hidden">
                          <img
                            src={iconSrc}
                            alt={chapter.title}
                            className="w-full h-full object-contain"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/assets/hisn_almuslim/icons/default.png';
                            }}
                          />
                        </div>

                        <div className="flex-1 min-w-0 pr-1">
                          <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A] leading-snug truncate group-hover:text-[#5B5FEF] transition-colors">
                            <HighlightedText text={chapter.title} query={searchQuery} />
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[11px] font-cairo px-2 py-0.5 rounded-md bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]">
                              {chapter.category}
                            </span>
                            <span className="font-cairo text-xs text-[#77798C]">
                              {chapter.athkar.length} أذكار
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Matched Athkar Texts Section */}
          {(searchScope === 'all' || searchScope === 'athkar' || searchScope === 'sources') && matchedAthkar.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-cairo font-bold text-sm sm:text-base text-[#25263A] flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
                  <span>الأذكار والأدعية المطابقة ({matchedAthkar.length})</span>
                </h2>
                <span className="text-xs font-cairo text-[#77798C]">عرض حي للنصوص</span>
              </div>

              <div className="space-y-4">
                {matchedAthkar.map(({ chapter, dhikr }) => {
                  const isFav = favoriteAthkarIds.includes(dhikr.id);
                  const isCopied = copiedDhikrId === dhikr.id;

                  return (
                    <div
                      key={dhikr.id}
                      onClick={() => setSelectedDhikrForModal({ dhikr, chapterTitle: chapter.title })}
                      className="group relative p-5 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden text-right"
                    >
                      {/* Chapter Badge with Real PNG icon */}
                      <div className="flex items-center justify-between mb-3 border-b border-[#E6E6F0] pb-2.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedChapter(chapter);
                          }}
                          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
                          title="الانتقال إلى هذا الباب"
                        >
                          <div className="w-6 h-6 rounded-full bg-white border border-[#E6E6F0] p-0.5 flex items-center justify-center shrink-0 overflow-hidden">
                            <img
                              src={`/assets/hisn_almuslim/icons/${chapter.iconName}`}
                              alt={chapter.title}
                              className="w-full h-full object-contain"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = '/assets/hisn_almuslim/icons/default.png';
                              }}
                            />
                          </div>
                          <span className="font-cairo font-bold text-xs text-[#5B5FEF] hover:underline">
                            من باب: {chapter.title}
                          </span>
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleFavoriteDhikr(dhikr.id);
                          }}
                          className="p-1 rounded-lg hover:bg-[#F7F7FC] transition-colors"
                          title="المفضلة"
                        >
                          <Star
                            className={`w-4 h-4 ${
                              isFav ? 'fill-amber-500 text-amber-500' : 'text-[#77798C]'
                            }`}
                          />
                        </button>
                      </div>

                      {/* Dhikr text in Amiri font with highlighted terms */}
                      <div className="font-amiri font-bold text-lg sm:text-xl text-[#25263A] leading-loose my-2 selection:bg-[#5B5FEF]/30">
                        «<HighlightedText text={dhikr.text} query={searchQuery} />»
                      </div>

                      {/* Source breakdown */}
                      <div className="mt-3 pt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-t border-[#E6E6F0]">
                        <p className="font-cairo text-xs text-[#77798C]">
                          📖 المصدر: <span className="text-[#25263A] font-semibold"><HighlightedText text={dhikr.source} query={searchQuery} /></span>
                        </p>

                        {dhikr.narrator && (
                          <span className="font-cairo text-xs text-[#77798C]">
                            الراوي: <span className="font-semibold text-[#25263A]"><HighlightedText text={dhikr.narrator} query={searchQuery} /></span>
                          </span>
                        )}
                      </div>

                      {/* Actions row */}
                      <div className="mt-3.5 flex items-center justify-end gap-2 pt-2 border-t border-[#E6E6F0]">
                        <button
                          onClick={(e) => handleCopyDhikr(dhikr, e)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs shadow-xs hover:brightness-105 transition-transform active:scale-95"
                        >
                          {isCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-white" />
                              <span>تم النسخ</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>نسخ</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={(e) => handleShareDhikr(dhikr, chapter.title, e)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#E6E6F0] text-[#25263A] font-cairo font-bold text-xs shadow-xs hover:bg-[#F7F7FC] transition-transform active:scale-95"
                        >
                          <Share2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                          <span>مشاركة</span>
                        </button>

                        <button
                          onClick={() => setSelectedDhikrForModal({ dhikr, chapterTitle: chapter.title })}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-xs hover:bg-[#EEEEFF] transition-transform active:scale-95"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#5B5FEF]" />
                          <span>عرض الذكر والفضل</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* No results during search */}
          {matchedChapters.length === 0 && matchedAthkar.length === 0 && (
            <div className="p-8 text-center bg-white rounded-2xl border-2 border-dashed border-[#E6E6F0] space-y-3">
              <BookOpen className="w-10 h-10 text-[#5B5FEF] mx-auto opacity-60" />
              <p className="font-cairo font-bold text-base text-[#25263A]">
                لم يتم العثور على نتائج تطابق «{searchQuery}»
              </p>
              <p className="font-cairo text-xs text-[#77798C]">
                جرّب البحث بكلمة أخرى، مثل: «الحمد»، «النوم»، «المسجد»، أو اسم أحد الرواة.
              </p>
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-xs hover:bg-[#EEEEFF] transition-colors"
              >
                مسح البحث والعودة
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Regular Browsing Grid (شبكة الأبواب 2xN) */
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {matchedChapters.map(chapter => {
            const isFav = favoriteChapterIds.includes(chapter.id);
            const iconSrc = `/assets/hisn_almuslim/icons/${chapter.iconName}`;

            return (
              <div
                key={chapter.id}
                onClick={() => setSelectedChapter(chapter)}
                className="relative p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs hover:shadow-md hover:border-[#5B5FEF] transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 group"
              >
                {/* Top/Side Favorite Star */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleToggleFavoriteChapter(chapter.id);
                  }}
                  className="absolute top-2.5 left-2.5 p-1.5 rounded-lg text-gray-400 hover:text-amber-500 transition-colors z-10"
                  title="مفضلة الباب"
                >
                  <Star
                    className={`w-4 h-4 ${
                      isFav ? 'fill-amber-500 text-amber-500' : 'text-gray-300 group-hover:text-gray-400'
                    }`}
                  />
                </button>

                <div className="flex items-center gap-3.5 flex-1 min-w-0">
                  {/* 60px White Circle with Thin Gold Border & Real PNG Icon */}
                  <div className="w-[60px] h-[60px] rounded-full bg-white border border-[#E6E6F0] p-1.5 flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-105 transition-transform overflow-hidden">
                    <img
                      src={iconSrc}
                      alt={chapter.title}
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/assets/hisn_almuslim/icons/default.png';
                      }}
                    />
                  </div>

                  {/* Chapter Title and Count */}
                  <div className="flex-1 min-w-0 pr-1">
                    <h3 className="font-cairo font-bold text-base text-[#25263A] leading-snug truncate group-hover:text-[#5B5FEF] transition-colors">
                      {chapter.title}
                    </h3>
                    <p className="font-cairo text-xs text-[#77798C] mt-1">
                      عدد الأذكار: {chapter.athkar.length}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Screen 3: Dhikr Detail Modal when opened from search results */}
      {selectedDhikrForModal && (
        <HisnDhikrModal
          dhikr={selectedDhikrForModal.dhikr}
          chapterTitle={selectedDhikrForModal.chapterTitle}
          isFavorite={favoriteAthkarIds.includes(selectedDhikrForModal.dhikr.id)}
          onToggleFavorite={handleToggleFavoriteDhikr}
          onClose={() => setSelectedDhikrForModal(null)}
        />
      )}
    </div>
  );
};
