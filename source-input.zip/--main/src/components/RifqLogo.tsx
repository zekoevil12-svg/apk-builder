import React, { useId } from 'react';
import { useSafeTheme } from '../context/ThemeContext';

interface RifqLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'full' | 'emblem' | 'horizontal';
  animated?: boolean;
  withGlow?: boolean;
  darkMode?: boolean;
}

export const RifqLogo: React.FC<RifqLogoProps> = ({
  className = '',
  size = 180,
  variant = 'full',
  animated = false,
  withGlow = false,
  darkMode = false,
}) => {
  const { themeId, isDark, isGirly } = useSafeTheme();
  const effectiveDark = darkMode || isDark;
  const rawId = useId().replace(/:/g, '');
  const scope = `${rawId}_${themeId}_${effectiveDark ? 'd' : 'l'}`;

  // Dimensions and layout
  const viewBox = variant === 'horizontal' ? '0 0 420 120' : '0 0 320 380';
  const width = size;
  const height = variant === 'horizontal' 
    ? (typeof size === 'number' ? size * (120 / 420) : 'auto')
    : (typeof size === 'number' ? size * (380 / 320) : 'auto');

  const goldGradId = `goldGrad_${scope}`;
  const goldBorderGradId = `goldBorderGrad_${scope}`;
  const navyGradId = `navyGrad_${scope}`;
  const lightNavyGradId = `lightNavyGrad_${scope}`;
  const archBgGradId = `archBgGrad_${scope}`;
  const softShadowId = `softShadow_${scope}`;
  const goldGlowFilterId = `goldGlowFilter_${scope}`;
  const pageGradLeftId = `pageGradLeft_${scope}`;
  const pageGradRightId = `pageGradRight_${scope}`;

  const primaryColor = isGirly ? '#D98FA8' : '#5B5FEF';
  const roseGoldColor = isGirly ? '#CFA06A' : '#E8B84A';
  const lavenderColor = isGirly ? '#B98CC8' : '#5B5FEF';
  const darkInkColor = isGirly ? '#49343D' : '#25263A';

  return (
    <div 
      className={`inline-flex items-center justify-center select-none ${animated ? 'transition-transform duration-500 hover:scale-105' : ''} ${className}`}
      style={{ width, height }}
    >
      <svg
        key={`logo-${variant}-${themeId}-${effectiveDark}`}
        viewBox={viewBox}
        width="100%"
        height="100%"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        data-rifq-icon-theme={themeId}
        className="overflow-visible drop-shadow-sm"
      >
        <defs>
          {/* Accent Gold / Rose Gold Gradients */}
          <linearGradient id={goldGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={isGirly ? '#F2D5B3' : '#F3CE75'} />
            <stop offset="35%" stopColor={isGirly ? '#FAEBDD' : '#FAE3A7'} />
            <stop offset="70%" stopColor={isGirly ? '#CFA06A' : '#E8B84A'} />
            <stop offset="100%" stopColor={isGirly ? '#B88652' : '#E8B84A'} />
          </linearGradient>

          <linearGradient id={goldBorderGradId} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={isGirly ? '#B98CC8' : '#72B7E8'} />
            <stop offset="50%" stopColor={isGirly ? '#D98FA8' : '#5B5FEF'} />
            <stop offset="100%" stopColor={isGirly ? '#CFA06A' : '#4145C7'} />
          </linearGradient>

          {/* Primary Purple / Soft Rose Gradients */}
          <linearGradient id={navyGradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={isGirly ? '#D98FA8' : '#5B5FEF'} />
            <stop offset="50%" stopColor={isGirly ? '#B98CC8' : '#4145C7'} />
            <stop offset="100%" stopColor={isGirly ? '#7D4663' : '#25263A'} />
          </linearGradient>

          <linearGradient id={lightNavyGradId} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={isGirly ? '#B98CC8' : '#72B7E8'} />
            <stop offset="100%" stopColor={isGirly ? '#D98FA8' : '#5B5FEF'} />
          </linearGradient>

          {/* Soft Lavender-White / Warm Blush-Cream Background inside Arch */}
          <radialGradient id={archBgGradId} cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={effectiveDark ? (isGirly ? '#2B1D25' : '#25263A') : '#FFFFFF'} />
            <stop offset="85%" stopColor={effectiveDark ? (isGirly ? '#21161C' : '#1E1F30') : (isGirly ? '#FFF8FA' : '#F7F7FC')} />
            <stop offset="100%" stopColor={effectiveDark ? (isGirly ? '#1A1216' : '#171826') : (isGirly ? '#FCEEF3' : '#EEEEFF')} />
          </radialGradient>

          {/* Soft 3D Drop Shadows */}
          <filter id={softShadowId} x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="5" floodColor={darkInkColor} floodOpacity="0.14" />
          </filter>

          <filter id={goldGlowFilterId} x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="8" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          {/* Quran Page Gradient */}
          <linearGradient id={pageGradLeftId} x1="100%" y1="0%" x2="0%" y2="0%">
            <stop offset="0%" stopColor={isGirly ? '#F2DCE4' : '#E6E6F0'} />
            <stop offset="30%" stopColor={isGirly ? '#FFF8FA' : '#F7F7FC'} />
            <stop offset="100%" stopColor="#FFFFFF" />
          </linearGradient>

          <linearGradient id={pageGradRightId} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={isGirly ? '#F2DCE4' : '#E6E6F0'} />
            <stop offset="30%" stopColor={isGirly ? '#FFF8FA' : '#F7F7FC'} />
            <stop offset="100%" stopColor="#FFFFFF" />
          </linearGradient>
        </defs>

        {/* Optional Ambient Primary Halo */}
        {withGlow && (
          <circle
            cx={variant === 'horizontal' ? 60 : 160}
            cy={variant === 'horizontal' ? 60 : 130}
            r={variant === 'horizontal' ? 60 : 120}
            fill={`url(#${lightNavyGradId})`}
            opacity="0.2"
            filter={`url(#${goldGlowFilterId})`}
          />
        )}

        {/* ─── EMBLEM CONTENT (ARCH + MOSQUE + QURAN + CRESCENT) ─── */}
        <g transform={variant === 'horizontal' ? 'scale(0.55) translate(10, 10)' : 'translate(0, 0)'}>
          {/* Main Arched Mihrab Doorway Frame */}
          <g filter={`url(#${softShadowId})`}>
            {/* Outer Arch Border */}
            <path
              d="M 60,250 L 60,140 C 60,75 110,25 160,25 C 210,25 260,75 260,140 L 260,250 C 260,258 254,264 246,264 L 74,264 C 66,264 60,258 60,250 Z"
              fill={`url(#${goldBorderGradId})`}
            />

            {/* Inner Arch Body */}
            <path
              d="M 66,246 L 66,140 C 66,80 112,32 160,32 C 208,32 254,80 254,140 L 254,246 C 254,252 250,256 244,256 L 76,256 C 70,256 66,252 66,246 Z"
              fill={`url(#${archBgGradId})`}
              stroke={roseGoldColor}
              strokeWidth="2"
            />

            {/* Delicate Arch Inset Guideline */}
            <path
              d="M 74,242 L 74,142 C 74,88 116,42 160,42 C 204,42 246,88 246,142 L 246,242"
              fill="none"
              stroke={lavenderColor}
              strokeWidth="0.8"
              strokeDasharray="3 2"
              opacity="0.45"
            />
          </g>

          {/* Subtle Arabesque / Sacred Geometry Stars in the Arch Upper Sky */}
          <g opacity="0.16" stroke={lavenderColor} strokeWidth="0.7">
            <circle cx="160" cy="110" r="55" />
            <circle cx="160" cy="110" r="35" />
            <polygon points="160,70 172,100 200,110 172,120 160,150 148,120 120,110 148,100" />
            <polygon points="160,75 167,97 195,110 167,123 160,145 153,123 125,110 153,97" transform="rotate(45 160 110)" />
          </g>

          {/* ─── MOSQUE (MINARETS + DOME) ─── */}
          <g id="mosque-group" filter={`url(#${softShadowId})`}>
            {/* Left Minaret */}
            <g id="left-minaret">
              {/* Base / Tower */}
              <rect x="88" y="115" width="14" height="90" rx="1.5" fill={`url(#${navyGradId})`} />
              {/* Balcony ring 1 */}
              <rect x="86" y="150" width="18" height="4" rx="1" fill={`url(#${goldGradId})`} />
              {/* Balcony ring 2 (upper) */}
              <rect x="85" y="112" width="20" height="5" rx="1" fill={`url(#${goldGradId})`} />
              {/* Spire / Cone */}
              <polygon points="95,82 89,112 101,112" fill={`url(#${lightNavyGradId})`} />
              {/* Finial / Crescent on Left Minaret */}
              <circle cx="95" cy="79" r="2.5" fill={`url(#${goldGradId})`} />
              <path d="M 94,76 A 2.5 2.5 0 0 1 97,78" stroke={`url(#${goldGradId})`} strokeWidth="1" />
            </g>

            {/* Right Minaret */}
            <g id="right-minaret">
              {/* Base / Tower */}
              <rect x="218" y="115" width="14" height="90" rx="1.5" fill={`url(#${navyGradId})`} />
              {/* Balcony ring 1 */}
              <rect x="216" y="150" width="18" height="4" rx="1" fill={`url(#${goldGradId})`} />
              {/* Balcony ring 2 (upper) */}
              <rect x="215" y="112" width="20" height="5" rx="1" fill={`url(#${goldGradId})`} />
              {/* Spire / Cone */}
              <polygon points="225,82 219,112 231,112" fill={`url(#${lightNavyGradId})`} />
              {/* Finial / Crescent on Right Minaret */}
              <circle cx="225" cy="79" r="2.5" fill={`url(#${goldGradId})`} />
              <path d="M 224,76 A 2.5 2.5 0 0 1 227,78" stroke={`url(#${goldGradId})`} strokeWidth="1" />
            </g>

            {/* Central Mosque Structure / Wall */}
            <path
              d="M 102,150 L 218,150 L 218,205 L 102,205 Z"
              fill={`url(#${navyGradId})`}
            />

            {/* Mosque Arched Doorway / Gateway */}
            <path
              d="M 146,205 L 146,175 C 146,165 152,160 160,160 C 168,160 174,165 174,175 L 174,205 Z"
              fill={darkInkColor}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1.5"
            />
            {/* Small Side Arched Windows on Mosque Wall */}
            <path
              d="M 116,192 L 116,176 C 116,170 120,167 124,167 C 128,167 132,170 132,176 L 132,192 Z"
              fill={darkInkColor}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1"
            />
            <path
              d="M 188,192 L 188,176 C 188,170 192,167 196,167 C 200,167 204,170 204,176 L 204,192 Z"
              fill={darkInkColor}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1"
            />

            {/* Central Grand Dome */}
            <path
              d="M 120,150 C 120,105 145,86 160,80 C 175,86 200,105 200,150 Z"
              fill={`url(#${lightNavyGradId})`}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1.5"
            />
            {/* Dome 3D Highlight Rib */}
            <path
              d="M 160,81 C 166,102 172,125 170,150"
              fill="none"
              stroke={`url(#${goldGradId})`}
              strokeWidth="0.8"
              opacity="0.8"
            />
            <path
              d="M 160,81 C 154,102 148,125 150,150"
              fill="none"
              stroke={`url(#${goldGradId})`}
              strokeWidth="0.8"
              opacity="0.8"
            />

            {/* Golden Crescent and Star Topping the Central Dome */}
            <g id="dome-crescent" transform="translate(160, 68)">
              {/* Crescent */}
              <path
                d="M 0,-14 A 9 9 0 1 1 -5,-3 A 7 7 0 1 0 0,-14 Z"
                fill={`url(#${goldGradId})`}
                filter={`url(#${softShadowId})`}
              />
              {/* Radiant 5-point Star */}
              <polygon
                points="4,-8 5.5,-4 9.5,-4 6.5,-2 7.5,2 4.5,-0.5 1.5,2 2.5,-2 -0.5,-4 3.5,-4"
                fill={`url(#${goldGradId})`}
                transform="scale(0.8) translate(5, -6)"
              />
            </g>
          </g>

          {/* ─── OPEN QURAN (HOLY BOOK AT BASE) ─── */}
          <g id="quran-group" filter={`url(#${softShadowId})`} transform="translate(0, 5)">
            {/* Rehal (X-Stand / Bookrest) */}
            <path
              d="M 112,238 L 138,218 L 160,225 L 182,218 L 208,238 L 195,244 L 160,230 L 125,244 Z"
              fill={`url(#${goldGradId})`}
              stroke={roseGoldColor}
              strokeWidth="1"
            />

            {/* Book Cover Base */}
            <path
              d="M 100,214 C 125,217 150,214 160,219 C 170,214 195,217 220,214 L 216,224 C 195,226 170,222 160,227 C 150,222 125,226 104,224 Z"
              fill={`url(#${navyGradId})`}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1.2"
            />

            {/* Left Page */}
            <path
              d="M 104,212 C 124,203 145,208 160,216 C 160,195 145,190 106,198 Z"
              fill={`url(#${pageGradLeftId})`}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1.2"
            />
            {/* Left Page Text Lines */}
            <path d="M 118,203 C 132,201 146,204 153,208" stroke={roseGoldColor} strokeWidth="0.9" strokeLinecap="round" opacity="0.8" />
            <path d="M 115,207 C 130,205 144,208 152,212" stroke={lavenderColor} strokeWidth="0.8" strokeLinecap="round" opacity="0.6" />

            {/* Right Page */}
            <path
              d="M 216,212 C 196,203 175,208 160,216 C 160,195 175,190 214,198 Z"
              fill={`url(#${pageGradRightId})`}
              stroke={`url(#${goldGradId})`}
              strokeWidth="1.2"
            />
            {/* Right Page Text Lines */}
            <path d="M 167,208 C 174,204 188,201 202,203" stroke={roseGoldColor} strokeWidth="0.9" strokeLinecap="round" opacity="0.8" />
            <path d="M 168,212 C 176,208 190,205 205,207" stroke={lavenderColor} strokeWidth="0.8" strokeLinecap="round" opacity="0.6" />

            {/* Golden Bookmark Ribbon */}
            <path
              d="M 160,216 Q 160,234 163,240 L 159,237 L 157,240 Q 158,234 160,216 Z"
              fill={`url(#${goldGradId})`}
              stroke={roseGoldColor}
              strokeWidth="0.5"
            />
          </g>
        </g>

        {/* ─── TYPOGRAPHY & ISLAMIC STAR DIVIDER ─── */}
        {variant === 'full' && (
          <g id="typography-vertical">
            {/* Arabic Title "رِفْق" */}
            <text
              x="160"
              y="308"
              textAnchor="middle"
              fill={primaryColor}
              style={{
                fontFamily: "'Amiri', 'Tajawal', serif",
                fontSize: '44px',
                fontWeight: 900,
                letterSpacing: '2px',
                filter: isGirly
                  ? 'drop-shadow(0 2px 4px rgba(185,140,200,0.22))'
                  : 'drop-shadow(0 2px 4px rgba(91,95,239,0.16))'
              }}
            >
              رِفْـق
            </text>

            {/* Latin Title "RIFQ" */}
            <text
              x="160"
              y="336"
              textAnchor="middle"
              fill={darkInkColor}
              style={{
                fontFamily: "'Tajawal', 'Montserrat', sans-serif",
                fontSize: '19px',
                fontWeight: 800,
                letterSpacing: '6px',
              }}
            >
              RIFQ
            </text>

            {/* Decorative 8-pointed Rub el Hizb / Islamic Star Divider */}
            <g transform="translate(160, 360)">
              {/* Left Line */}
              <line x1="-55" y1="0" x2="-14" y2="0" stroke={`url(#${goldGradId})`} strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="-57" cy="0" r="1.5" fill={`url(#${goldGradId})`} />

              {/* Central Eight-pointed Star (Rub el Hizb) */}
              <g transform="scale(0.85)">
                <rect x="-6" y="-6" width="12" height="12" fill={`url(#${goldGradId})`} rx="1" />
                <rect x="-6" y="-6" width="12" height="12" fill={`url(#${goldGradId})`} rx="1" transform="rotate(45)" />
                <circle cx="0" cy="0" r="2" fill={lavenderColor} />
              </g>

              {/* Right Line */}
              <line x1="14" y1="0" x2="55" y2="0" stroke={`url(#${goldGradId})`} strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="57" cy="0" r="1.5" fill={`url(#${goldGradId})`} />
            </g>
          </g>
        )}

        {/* Horizontal Layout (For Navbar / App Bar) */}
        {variant === 'horizontal' && (
          <g transform="translate(145, 20)">
            {/* Arabic Name "رِفْق" */}
            <text
              x="0"
              y="48"
              fill={primaryColor}
              style={{
                fontFamily: "'Amiri', 'Tajawal', serif",
                fontSize: '38px',
                fontWeight: 900,
                letterSpacing: '1px',
              }}
            >
              رِفْـق
            </text>

            {/* Separator Pipe */}
            <text
              x="85"
              y="44"
              fill={roseGoldColor}
              style={{
                fontSize: '24px',
                fontWeight: 300,
              }}
            >
              |
            </text>

            {/* Latin Name "RIFQ" */}
            <text
              x="105"
              y="46"
              fill={darkInkColor}
              style={{
                fontFamily: "'Tajawal', 'Montserrat', sans-serif",
                fontSize: '24px',
                fontWeight: 800,
                letterSpacing: '3px',
              }}
            >
              RIFQ
            </text>

            {/* Subtitle tag / Motto */}
            <g transform="translate(0, 68)">
              <rect x="0" y="0" width="190" height="20" rx="6" fill={isGirly ? '#FCEEF3' : '#EEEEFF'} />
              <text
                x="95"
                y="14"
                textAnchor="middle"
                fill={isGirly ? '#B56582' : '#4145C7'}
                style={{
                  fontFamily: "'Tajawal', sans-serif",
                  fontSize: '11px',
                  fontWeight: 700,
                }}
              >
                الرفيق القرآني والأذكار المباركة
              </text>
            </g>
          </g>
        )}
      </svg>
    </div>
  );
};
