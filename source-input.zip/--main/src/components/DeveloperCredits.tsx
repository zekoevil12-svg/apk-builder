import React, { useState } from 'react';
import { 
  Code2, 
  Send, 
  Bot, 
  Mail, 
  ExternalLink, 
  Sparkles,
  Heart,
  Copy,
  Check,
  ChevronLeft
} from 'lucide-react';

interface DeveloperCreditsProps {
  compact?: boolean;
  className?: string;
  onOpenFullCredits?: () => void;
}

export const DeveloperCredits: React.FC<DeveloperCreditsProps> = ({
  compact = false,
  className = '',
  onOpenFullCredits,
}) => {
  const telegramChannelUrl = 'https://t.me/RafiqAlMuslim1';
  const telegramBotUrl = 'https://t.me/Quuran4_bot';
  const developerEmail = 'mo.abdullah262007@gmail.com';
  const developerName = 'محمد عبدالله';
  const botUsername = '@Quuran4_bot';

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (e: React.MouseEvent, text: string, key: string) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  if (compact) {
    return (
      <div 
        className={`w-full text-center py-4 px-3 text-xs text-[#77798C] font-tajawal select-none ${className}`}
        dir="rtl"
      >
        <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5 text-[11px]">
          <span className="flex items-center gap-1 font-bold text-[#25263A]">
            <Code2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>المطور:</span>
            <span className="text-[#4145C7] font-black">{developerName}</span>
          </span>
          <span className="text-gray-300">•</span>
          <a
            href={telegramChannelUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#4145C7] hover:text-[#4145C7] transition-colors flex items-center gap-1 font-bold hover:underline cursor-pointer"
            title="فتح قناة رفيق المسلم على تيليجرام"
          >
            <Send className="w-3 h-3 text-[#2AABEE]" />
            <span>قناة رفيق المسلم</span>
          </a>
          <span className="text-gray-300">•</span>
          <a
            href={telegramBotUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#4145C7] hover:text-[#4145C7] transition-colors flex items-center gap-1 font-bold hover:underline cursor-pointer"
            title="فتح بوت رِفْق على تيليجرام"
          >
            <Bot className="w-3 h-3 text-[#2AABEE]" />
            <span>{botUsername}</span>
          </a>
          <span className="text-gray-300">•</span>
          <a
            href={`mailto:${developerEmail}`}
            className="text-[#77798C] hover:text-[#4145C7] transition-colors flex items-center gap-1 font-bold hover:underline cursor-pointer"
            title="مراسلة المطور عبر البريد الإلكتروني"
          >
            <Mail className="w-3 h-3 text-[#4145C7]" />
            <span>{developerEmail}</span>
          </a>
          {onOpenFullCredits && (
            <>
              <span className="text-gray-300">•</span>
              <button
                onClick={onOpenFullCredits}
                className="text-[#4145C7] hover:text-[#4145C7] font-bold flex items-center gap-0.5 hover:underline cursor-pointer"
              >
                <span>القسم المخصص</span>
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`w-full bg-gradient-to-br from-white via-[#F7F7FC] to-amber-50/40 rounded-3xl p-5 sm:p-6 shadow-sm hover:shadow-md transition-all border border-[#E6E6F0] relative overflow-hidden font-tajawal select-none ${className}`}
      dir="rtl"
    >
      {/* Top decorative gradient bar */}
      <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-[#4145C7] via-[#E8B84A] to-[#4145C7]" />

      {/* Header section */}
      <div className="flex items-center justify-between pb-3.5 border-b border-[#E6E6F0]/90 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#4145C7]/15 to-[#E8B84A]/20 text-[#4145C7] flex items-center justify-center border border-[#E6E6F0] shadow-2xs">
            <Code2 className="w-5 h-5 text-[#4145C7]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-black text-[#4145C7]">
                حقوق وتواصل المطور
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] text-[10px] font-bold border border-[#E6E6F0]">
                تطبيق رِفْق | RIFQ
              </span>
            </div>
            <p className="text-xs text-[#77798C] mt-0.5 flex items-center gap-1">
              <span>برمجة وتطوير رِفْق لوجه الله تعالى</span>
              <Sparkles className="w-3 h-3 text-[#5B5FEF]" />
            </p>
          </div>
        </div>

        {onOpenFullCredits && (
          <button
            onClick={onOpenFullCredits}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-bold shadow-xs hover:brightness-105 transition-all cursor-pointer shrink-0"
          >
            <span>فتح القسم الخاص</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Developer Information Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3.5">
        
        {/* 1. Developer Name Card */}
        <div className="bg-white/90 p-3.5 rounded-2xl border border-[#E6E6F0]/80 hover:border-[#E6E6F0] transition-all shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-[#4145C7] flex items-center justify-center text-base font-bold border border-blue-100">
              <Code2 className="w-4 h-4 text-[#4145C7]" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-gray-400 block">المطور:</span>
              <span className="text-xs font-black text-[#25263A]">
                {developerName}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#4145C7] bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100">
            مطور التطبيق
          </span>
        </div>

        {/* 2. Telegram Channel Card */}
        <div className="bg-white/90 hover:bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]/80 hover:border-[#2AABEE]/40 hover:shadow-xs transition-all shadow-2xs flex items-center justify-between group">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-[#2AABEE] flex items-center justify-center text-base shrink-0 border border-sky-100 group-hover:scale-105 transition-transform">
              <Send className="w-4 h-4 text-[#2AABEE]" />
            </div>
            <div className="truncate">
              <span className="text-[10px] font-bold text-gray-400 block">قناة رفيق المسلم على تيليجرام:</span>
              <a
                href={telegramChannelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-black text-[#4145C7] hover:text-[#2AABEE] transition-colors truncate block"
              >
                قناة رفيق المسلم
              </a>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={(e) => handleCopy(e, telegramChannelUrl, 'ch')}
              title="نسخ الرابط"
              className="p-1 rounded-md text-gray-400 hover:text-[#77798C] hover:bg-gray-100"
            >
              {copiedKey === 'ch' ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <a
              href={telegramChannelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[11px] font-bold text-[#2AABEE] bg-sky-50 px-2 py-1 rounded-lg border border-sky-100 hover:bg-sky-100 transition-colors cursor-pointer"
            >
              <span>فتح</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* 3. Telegram Bot Card */}
        <div className="bg-white/90 hover:bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]/80 hover:border-indigo-300 hover:shadow-xs transition-all shadow-2xs flex items-center justify-between group">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-base shrink-0 border border-indigo-100 group-hover:scale-105 transition-transform">
              <Bot className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="truncate">
              <span className="text-[10px] font-bold text-gray-400 block">بوت رِفْق:</span>
              <a
                href={telegramBotUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-black text-[#4145C7] hover:text-indigo-600 transition-colors font-mono tracking-tight truncate block" 
                dir="ltr"
              >
                {botUsername}
              </a>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={(e) => handleCopy(e, botUsername, 'bot')}
              title="نسخ اسم البوت"
              className="p-1 rounded-md text-gray-400 hover:text-[#77798C] hover:bg-gray-100"
            >
              {copiedKey === 'bot' ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <a
              href={telegramBotUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-[11px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg border border-indigo-100 hover:bg-indigo-100 transition-colors cursor-pointer"
            >
              <span>بدء</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* 4. Developer Email Card */}
        <div className="bg-white/90 hover:bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]/80 hover:border-[#E6E6F0] hover:shadow-xs transition-all shadow-2xs flex items-center justify-between group">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center text-base shrink-0 border border-[#E6E6F0] group-hover:scale-105 transition-transform">
              <Mail className="w-4 h-4 text-[#4145C7]" />
            </div>
            <div className="truncate">
              <span className="text-[10px] font-bold text-gray-400 block">البريد الإلكتروني للمطور:</span>
              <a
                href={`mailto:${developerEmail}`}
                className="text-xs font-bold text-[#25263A] hover:text-[#4145C7] transition-colors truncate block font-mono text-[11px]" 
                dir="ltr"
              >
                {developerEmail}
              </a>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={(e) => handleCopy(e, developerEmail, 'email')}
              title="نسخ البريد الإلكتروني"
              className="p-1 rounded-md text-gray-400 hover:text-[#77798C] hover:bg-gray-100"
            >
              {copiedKey === 'email' ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <a
              href={`mailto:${developerEmail}`}
              className="flex items-center gap-1 text-[11px] font-bold text-[#4145C7] bg-[#EEEEFF] px-2 py-1 rounded-lg border border-[#E6E6F0] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
            >
              <span>مراسلة</span>
              <Mail className="w-3 h-3" />
            </a>
          </div>
        </div>

      </div>
    </div>
  );
};
