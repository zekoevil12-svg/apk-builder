import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  DuaItem,
  DuaCategory,
  DUA_CATEGORIES,
} from '../../data/duaCornerData';
import {
  getAllDuas,
  getDuaFavorites,
  toggleDuaFavorite,
  saveCustomDua,
  deleteCustomDua,
  formatDuaShareText,
  incrementDuaRecitedCount,
  getDuaRecitedCounts,
} from '../../utils/duaCornerService';
import { soundManager } from '../../utils/audio';
import { useTheme } from '../../context/ThemeContext';
import { DuaCornerSectionSvg } from '../Home/RifqSectionIcons';
import { DuaAnalyticsCharts } from './DuaAnalyticsCharts';

interface DuaCornerViewProps {
  onBack: () => void;
  initialCategory?: DuaCategory;
}

export const DuaCornerView: React.FC<DuaCornerViewProps> = ({ onBack, initialCategory = 'all' }) => {
  const { isDark } = useTheme();

  // State
  const [selectedCategory, setSelectedCategory] = useState<DuaCategory | 'favorites' | 'analytics'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [allDuas, setAllDuas] = useState<DuaItem[]>(getAllDuas);
  const [favorites, setFavorites] = useState<string[]>(getDuaFavorites);
  const [recitedCounts, setRecitedCounts] = useState<Record<string, number>>(getDuaRecitedCounts);
  const [activeDuaCounters, setActiveDuaCounters] = useState<Record<string, number>>({});
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);
  const [fontSizeLevel, setFontSizeLevel] = useState<'normal' | 'large' | 'huge'>('normal');

  // Modal State for Adding / Editing Custom Dua
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDua, setEditingDua] = useState<DuaItem | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formArabic, setFormArabic] = useState('');
  const [formCategory, setFormCategory] = useState<DuaCategory>('custom');
  const [formSource, setFormSource] = useState('');
  const [formVirtue, setFormVirtue] = useState('');
  const [formCount, setFormCount] = useState<number>(3);

  // Sync when custom duas or favorites change
  useEffect(() => {
    const handleCustomChange = () => setAllDuas(getAllDuas());
    const handleFavChange = () => setFavorites(getDuaFavorites());

    window.addEventListener('rifq-custom-duas-changed', handleCustomChange);
    window.addEventListener('rifq-dua-favorites-changed', handleFavChange);
    return () => {
      window.removeEventListener('rifq-custom-duas-changed', handleCustomChange);
      window.removeEventListener('rifq-dua-favorites-changed', handleFavChange);
    };
  }, []);

  const showToast = useCallback((msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => {
      setFeedbackToast((prev) => (prev === msg ? null : prev));
    }, 2500);
  }, []);

  // Daily Featured Dua (Deterministic by Day of Year)
  const dailyFeaturedDua = useMemo(() => {
    if (allDuas.length === 0) return null;
    const dayOfYear = Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
    const idx = Math.abs(dayOfYear) % allDuas.length;
    return allDuas[idx];
  }, [allDuas]);

  // Filtered List
  const filteredDuas = useMemo(() => {
    let list = [...allDuas];

    // Category or Favorites Filter
    if (selectedCategory === 'favorites') {
      list = list.filter((d) => favorites.includes(d.id));
    } else if (selectedCategory !== 'all') {
      list = list.filter((d) => d.category === selectedCategory);
    }

    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.arabic.toLowerCase().includes(q) ||
          (d.source && d.source.toLowerCase().includes(q)) ||
          (d.virtue && d.virtue.toLowerCase().includes(q))
      );
    }

    return list;
  }, [allDuas, selectedCategory, favorites, searchQuery]);

  // Stats
  const customDuasCount = useMemo(() => allDuas.filter((d) => d.isCustom).length, [allDuas]);

  // Favorite toggle handler
  const handleToggleFav = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    soundManager.triggerHaptic(20);
    const isNowFav = toggleDuaFavorite(id);
    setFavorites(getDuaFavorites());
    showToast(isNowFav ? 'تمت إضافة الدعاء للمفضلة 🤍' : 'تمت الإزالة من المفضلة');
  };

  // Share handler
  const handleShareDua = async (dua: DuaItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    soundManager.triggerHaptic(25);
    const text = formatDuaShareText(dua);

    if (navigator.share) {
      try {
        await navigator.share({
          title: dua.title,
          text,
        });
        return;
      } catch {
        // fallback
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      showToast('تم نسخ نص الدعاء لمشاركته 📋');
    } catch {
      // ignore
    }
  };

  // Copy handler
  const handleCopyArabicOnly = async (text: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    soundManager.triggerHaptic(20);
    try {
      await navigator.clipboard.writeText(text);
      showToast('تم نسخ نص الدعاء 📋');
    } catch {
      // ignore
    }
  };

  // Recitation Clicker
  const handleDuaClickCount = (dua: DuaItem) => {
    const target = dua.recommendedCount || 3;
    const current = activeDuaCounters[dua.id] || 0;
    const next = current + 1;

    soundManager.playBeadClick(0.75, 'golden_bell');
    soundManager.triggerHaptic(25);

    if (next >= target) {
      soundManager.playBeadClick(0.9, 'water');
      soundManager.triggerHaptic([35, 50, 35]);
      incrementDuaRecitedCount(dua.id);
      setRecitedCounts(getDuaRecitedCounts());
      showToast('تقبّل الله منك طاعتك ودعاءك 🤲');
      setActiveDuaCounters((prev) => ({ ...prev, [dua.id]: 0 }));
    } else {
      setActiveDuaCounters((prev) => ({ ...prev, [dua.id]: next }));
    }
  };

  // Open Modal for New Dua
  const handleOpenAddModal = () => {
    setEditingDua(null);
    setFormTitle('');
    setFormArabic('');
    setFormCategory('custom');
    setFormSource('دعاء خاص');
    setFormVirtue('');
    setFormCount(3);
    setIsModalOpen(true);
  };

  // Open Modal for Edit Dua
  const handleOpenEditModal = (dua: DuaItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setEditingDua(dua);
    setFormTitle(dua.title);
    setFormArabic(dua.arabic);
    setFormCategory(dua.category);
    setFormSource(dua.source || 'دعاء خاص');
    setFormVirtue(dua.virtue || '');
    setFormCount(dua.recommendedCount || 3);
    setIsModalOpen(true);
  };

  // Delete Custom Dua
  const handleDeleteDua = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    soundManager.triggerHaptic(30);
    if (window.confirm('هل تود حذف هذا الدعاء الخاص من قائمتك؟')) {
      deleteCustomDua(id);
      showToast('تم حذف الدعاء بنجاح');
    }
  };

  // Save Modal Submit
  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formArabic.trim()) {
      showToast('يرجى كتابة عنوان الدعاء ونصه');
      return;
    }

    soundManager.triggerHaptic(30);
    saveCustomDua({
      id: editingDua ? editingDua.id : undefined,
      title: formTitle.trim(),
      arabic: formArabic.trim(),
      category: formCategory,
      source: formSource.trim() || 'دعاء خاص',
      virtue: formVirtue.trim() || undefined,
      recommendedCount: Number(formCount) || 3,
    });

    setIsModalOpen(false);
    showToast(editingDua ? 'تم تعديل الدعاء بنجاح ✨' : 'تم حفظ دعائك الخاص بنجاح 🤲');
  };

  const getDuaTextClass = () => {
    if (fontSizeLevel === 'huge') return 'text-xl sm:text-2xl leading-[2.2]';
    if (fontSizeLevel === 'large') return 'text-lg sm:text-xl leading-[2]';
    return 'text-base sm:text-lg leading-[1.9]';
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-28 pt-2 select-none animate-fade-in" dir="rtl">
      {/* Toast Feedback */}
      {feedbackToast && (
        <div className="fixed bottom-24 sm:bottom-20 right-1/2 translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-full text-xs font-black shadow-2xl border border-[#5B5FEF]/40 flex items-center gap-2 animate-fade-in pointer-events-none whitespace-nowrap">
          <span>{feedbackToast}</span>
        </div>
      )}

      {/* ── Top Header & Hero Card ── */}
      <div className="bg-gradient-to-br from-[#FAF8F5] via-[#FFFFFF] to-[#F1EDFF] dark:from-[#1D1E30] dark:via-[#1A1B2D] dark:to-[#27233B] rounded-3xl p-5 sm:p-7 border border-[#E9E4F5] dark:border-[#38324F] shadow-sm relative overflow-hidden">
        {/* Decorative Background Medallion */}
        <div className="absolute -top-10 -left-10 w-44 h-44 bg-[#5B5FEF]/10 dark:bg-[#5B5FEF]/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute top-4 left-4 opacity-15 pointer-events-none">
          <DuaCornerSectionSvg size={92} />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <button
              onClick={onBack}
              aria-label="العودة للرئيسية"
              className="w-10 h-10 rounded-2xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#363852] text-[#25263A] dark:text-white flex items-center justify-center hover:border-[#5B5FEF] hover:text-[#5B5FEF] transition-all cursor-pointer shadow-xs shrink-0"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#5B5FEF]/15 text-[#5B5FEF] border border-[#5B5FEF]/30">
                  قسم ركن الدعاء · باب الرجاء
                </span>
                <span className="text-xs text-[#77798C] dark:text-[#A0A2BA] font-medium">
                  «وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ»
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-[#25263A] dark:text-white font-cairo mt-1">
                ركن الدعاء والمناجاة
              </h1>
              <p className="text-xs sm:text-sm text-[#77798C] dark:text-[#A0A2BA] font-medium mt-1">
                أدعية قرآنية ونبوية مقسمة حسب حاجتك، مع ركن خاص لأدعيتك ومناجاتك
              </p>
            </div>
          </div>

          {/* Quick Counter Chips & Add Button */}
          <div className="flex items-center gap-2 self-stretch md:self-auto flex-wrap">
            <button
              onClick={handleOpenAddModal}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#787CFF] text-white text-xs font-black shadow-md hover:shadow-lg hover:scale-102 active:scale-98 transition-all flex items-center gap-2 cursor-pointer shrink-0"
            >
              <span className="text-base leading-none">+</span>
              <span>أضف دعاءً خاصاً</span>
            </button>

            <div className="px-3 py-2 rounded-2xl bg-white/90 dark:bg-[#24253B] border border-[#E9E4F5] dark:border-[#38324F] flex flex-col items-center justify-center min-w-[65px]">
              <span className="text-base font-black text-[#5B5FEF]">
                {allDuas.length}
              </span>
              <span className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] font-bold">
                دعاء مبارك
              </span>
            </div>
            <div className="px-3 py-2 rounded-2xl bg-white/90 dark:bg-[#24253B] border border-[#E9E4F5] dark:border-[#38324F] flex flex-col items-center justify-center min-w-[65px]">
              <span className="text-base font-black text-[#E11D48]">
                {favorites.length}
              </span>
              <span className="text-[10px] text-[#77798C] dark:text-[#A0A2BA] font-bold">
                في المفضلة
              </span>
            </div>
          </div>
        </div>

        {/* ── Search Bar & Font Sizer ── */}
        <div className="mt-5 flex items-center gap-2.5">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن دعاء (للرزق، للشفاء، للوالدين، تفريج الهم...)"
              className="w-full h-11 pr-11 pl-10 rounded-2xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#363852] text-xs font-bold text-[#25263A] dark:text-white placeholder-[#989AA8] focus:outline-none focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/20 transition-all shadow-xs"
            />
            <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#77798C] pointer-events-none">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8" />
                <line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
            </div>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#77798C] hover:text-[#25263A] dark:hover:text-white text-xs font-bold"
              >
                مسح
              </button>
            )}
          </div>

          {/* Font Size Toggle Button */}
          <div className="flex items-center gap-1 bg-white dark:bg-[#25263A] p-1 rounded-2xl border border-[#E6E6F0] dark:border-[#363852] shrink-0">
            <button
              onClick={() => {
                soundManager.triggerHaptic(15);
                setFontSizeLevel(
                  fontSizeLevel === 'normal' ? 'large' : fontSizeLevel === 'large' ? 'huge' : 'normal'
                );
              }}
              title="تغيير حجم خط الأدعية"
              className="px-2.5 py-1.5 rounded-xl text-xs font-black text-[#5B5FEF] hover:bg-[#F2F3FF] dark:hover:bg-[#32344F] transition-colors flex items-center gap-1"
            >
              <span>أ</span>
              <span className="text-[10px] opacity-70">
                {fontSizeLevel === 'normal' ? 'عادي' : fontSizeLevel === 'large' ? 'كبير' : 'أكبر'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* ── Daily Featured Dua Highlight Card ── */}
      {dailyFeaturedDua && selectedCategory === 'all' && !searchQuery && (
        <div className="bg-gradient-to-r from-[#FAF8F3] via-[#FFFDF8] to-[#F5EFE3] dark:from-[#252336] dark:via-[#26243A] dark:to-[#1E1C2C] rounded-2xl p-4 sm:p-5 border border-[#E9DFCE] dark:border-[#423C58] shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between gap-3 mb-2.5">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full bg-[#D4AF37]/20 text-[#B8860B] dark:text-[#E5C158] flex items-center justify-center text-sm font-black">
                ✨
              </span>
              <div>
                <h2 className="text-xs sm:text-sm font-black text-[#25263A] dark:text-white font-cairo">
                  دعاء اليوم المختار: {dailyFeaturedDua.title}
                </h2>
                <span className="text-[11px] text-[#77798C] dark:text-[#A0A2BA]">
                  {dailyFeaturedDua.source}
                </span>
              </div>
            </div>

            <button
              onClick={() => handleToggleFav(dailyFeaturedDua.id)}
              className="text-base p-1.5 rounded-full hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
            >
              {favorites.includes(dailyFeaturedDua.id) ? '❤️' : '🤍'}
            </button>
          </div>

          <p className="font-amiri text-lg sm:text-xl text-[#34354A] dark:text-[#E4E5F5] leading-relaxed text-justify mt-2 mb-3 font-bold">
            « {dailyFeaturedDua.arabic} »
          </p>

          <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E8D9BD] dark:border-[#38334E] text-xs">
            <span className="text-[#888A9E] text-[11px] truncate">
              {dailyFeaturedDua.virtue || 'دعاء عظيم النفع والأثر'}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => handleCopyArabicOnly(dailyFeaturedDua.arabic)}
                className="text-[#5B5FEF] font-bold text-xs hover:underline"
              >
                نسخ
              </button>
              <button
                onClick={() => handleShareDua(dailyFeaturedDua)}
                className="text-[#5B5FEF] font-bold text-xs hover:underline"
              >
                مشاركة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Category Tabs ── */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-[#E6E6F0] dark:border-[#2D2E45] px-1">
        {/* All Tab */}
        <button
          onClick={() => {
            soundManager.triggerHaptic(15);
            setSelectedCategory('all');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
            selectedCategory === 'all'
              ? 'bg-[#25263A] text-white dark:bg-[#5B5FEF] dark:text-white shadow-xs'
              : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#25263A] dark:hover:text-white border border-[#E6E6F0] dark:border-[#363852]'
          }`}
        >
          <span>🤲</span>
          <span>الكل ({allDuas.length})</span>
        </button>

        {/* Favorites Tab */}
        <button
          onClick={() => {
            soundManager.triggerHaptic(15);
            setSelectedCategory('favorites');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
            selectedCategory === 'favorites'
              ? 'bg-[#E11D48] text-white shadow-xs'
              : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#E11D48] border border-[#E6E6F0] dark:border-[#363852]'
          }`}
        >
          <span>❤️</span>
          <span>المفضلة ({favorites.length})</span>
        </button>

        {/* Analytics Tab */}
        <button
          onClick={() => {
            soundManager.triggerHaptic(15);
            setSelectedCategory('analytics');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
            selectedCategory === 'analytics'
              ? 'bg-gradient-to-r from-[#5B5FEF] to-[#787CFF] text-white shadow-xs'
              : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#5B5FEF] border border-[#E6E6F0] dark:border-[#363852]'
          }`}
        >
          <span>📊</span>
          <span>إحصائيات ورسوم بيانية</span>
        </button>

        {/* Custom Duas Tab */}
        <button
          onClick={() => {
            soundManager.triggerHaptic(15);
            setSelectedCategory('custom');
          }}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
            selectedCategory === 'custom'
              ? 'bg-[#DB2777] text-white shadow-xs'
              : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#DB2777] border border-[#E6E6F0] dark:border-[#363852]'
          }`}
        >
          <span>✍️</span>
          <span>أدعيتي الخاصة ({customDuasCount})</span>
        </button>

        {/* Categorized Tabs */}
        {DUA_CATEGORIES.filter((c) => c.id !== 'all' && c.id !== 'custom').map((cat) => {
          const isActive = selectedCategory === cat.id;
          const count = allDuas.filter((d) => d.category === cat.id).length;
          return (
            <button
              key={cat.id}
              onClick={() => {
                soundManager.triggerHaptic(15);
                setSelectedCategory(cat.id);
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-black transition-all cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-[#25263A] text-white dark:bg-[#5B5FEF] dark:text-white shadow-xs'
                  : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#A0A2BA] hover:text-[#25263A] dark:hover:text-white border border-[#E6E6F0] dark:border-[#363852]'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.name} ({count})</span>
            </button>
          );
        })}
      </div>

      {/* ── Category Description Bar ── */}
      {selectedCategory !== 'all' && selectedCategory !== 'favorites' && selectedCategory !== 'analytics' && (
        <div className="px-3 py-2 rounded-xl bg-[#F8F8FC] dark:bg-[#202136] border border-[#EAEAF2] dark:border-[#30324D] flex items-center justify-between text-xs text-[#52546A] dark:text-[#B9BACD]">
          <span>
            {DUA_CATEGORIES.find((c) => c.id === selectedCategory)?.description}
          </span>
          <span className="font-bold text-[#5B5FEF]">
            {filteredDuas.length} دعاء
          </span>
        </div>
      )}

      {/* ── Analytics View or Duas Cards List ── */}
      {selectedCategory === 'analytics' ? (
        <DuaAnalyticsCharts
          allDuas={allDuas}
          favorites={favorites}
          recitedCounts={recitedCounts}
        />
      ) : (
        <div className="space-y-4">
        {filteredDuas.length === 0 ? (
          <div className="bg-white dark:bg-[#1E1F35] rounded-3xl p-8 text-center border border-[#E6E6F0] dark:border-[#2F304A] space-y-3">
            <div className="text-4xl">🤲</div>
            <h4 className="text-base font-black text-[#25263A] dark:text-white font-cairo">
              {selectedCategory === 'favorites'
                ? 'لا توجد أدعية في المفضلة بعد'
                : selectedCategory === 'custom'
                ? 'لم تضف أي أدعية خاصة بعد'
                : 'لم نجد أدعية مطابقة لبحثك'}
            </h4>
            <p className="text-xs text-[#77798C] max-w-sm mx-auto">
              {selectedCategory === 'favorites'
                ? 'اضغط على رمز القلب 🤍 بجانب أي دعاء لحفظه والرجوع إليه بسرعة.'
                : selectedCategory === 'custom'
                ? 'اضغط على زر «أضف دعاءً خاصاً» لتدوين مناجاتك وأدعيتك الخاصة في رِفْق.'
                : 'جرب البحث بكلمات أخرى أو تصفح الأقسام المختلفة.'}
            </p>

            {selectedCategory === 'custom' && (
              <button
                onClick={handleOpenAddModal}
                className="mt-2 px-5 py-2.5 rounded-2xl bg-[#5B5FEF] text-white text-xs font-black shadow-md hover:bg-[#474BCD] transition-colors"
              >
                + كتابة دعائي الخاص
              </button>
            )}
          </div>
        ) : (
          filteredDuas.map((dua) => {
            const isFav = favorites.includes(dua.id);
            const categoryMeta = DUA_CATEGORIES.find((c) => c.id === dua.category);
            const targetCount = dua.recommendedCount || 3;
            const currentCount = activeDuaCounters[dua.id] || 0;
            const totalRecited = recitedCounts[dua.id] || 0;

            return (
              <div
                key={dua.id}
                className="bg-white dark:bg-[#1E1F35] rounded-2xl p-5 border border-[#EAE6F2] dark:border-[#32344F] shadow-xs hover:shadow-md transition-all duration-200 relative overflow-hidden"
              >
                {/* Accent line on right */}
                <div
                  className="absolute top-0 bottom-0 right-0 w-1.5 rounded-r-2xl"
                  style={{ backgroundColor: categoryMeta?.color || '#5B5FEF' }}
                />

                {/* Card Header: Category, Title, Action buttons */}
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className="px-2.5 py-0.5 rounded-full text-[10px] font-black text-white"
                      style={{ backgroundColor: categoryMeta?.color || '#5B5FEF' }}
                    >
                      {categoryMeta?.icon} {categoryMeta?.name}
                    </span>
                    <h3 className="text-sm sm:text-base font-black text-[#25263A] dark:text-white font-cairo">
                      {dua.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Custom Dua Edit & Delete */}
                    {dua.isCustom && (
                      <>
                        <button
                          type="button"
                          onClick={(e) => handleOpenEditModal(dua, e)}
                          title="تعديل الدعاء"
                          className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#EFE8DD] text-[#77798C] hover:text-[#5B5FEF] flex items-center justify-center text-xs transition-colors cursor-pointer"
                        >
                          ✏️
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleDeleteDua(dua.id, e)}
                          title="حذف الدعاء"
                          className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-rose-50 text-[#77798C] hover:text-rose-600 flex items-center justify-center text-xs transition-colors cursor-pointer"
                        >
                          🗑️
                        </button>
                      </>
                    )}

                    {/* Bookmark */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleFav(dua.id, e)}
                      title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                      className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#F2ECE0] flex items-center justify-center text-xs transition-colors cursor-pointer"
                    >
                      {isFav ? '❤️' : '🤍'}
                    </button>

                    {/* Share */}
                    <button
                      type="button"
                      onClick={(e) => handleShareDua(dua, e)}
                      title="مشاركة الدعاء"
                      className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#F2ECE0] flex items-center justify-center text-xs text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="18" cy="5" r="3" />
                        <circle cx="6" cy="12" r="3" />
                        <circle cx="18" cy="19" r="3" />
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                      </svg>
                    </button>

                    {/* Copy */}
                    <button
                      type="button"
                      onClick={(e) => handleCopyArabicOnly(dua.arabic, e)}
                      title="نسخ نص الدعاء"
                      className="w-8 h-8 rounded-full bg-[#FAF8F5] dark:bg-[#272840] hover:bg-[#F2ECE0] flex items-center justify-center text-xs text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer"
                    >
                      📋
                    </button>
                  </div>
                </div>

                {/* Main Arabic Text */}
                <div
                  onClick={() => handleDuaClickCount(dua)}
                  className="bg-[#FCFCFE] dark:bg-[#1A1B2D] p-4 sm:p-5 rounded-2xl border border-[#ECEAF5] dark:border-[#2C2E46] cursor-pointer hover:border-[#5B5FEF]/50 transition-all group"
                >
                  <p className={`font-amiri font-bold text-[#2A2B42] dark:text-[#E8E9FA] text-justify select-text ${getDuaTextClass()}`}>
                    « {dua.arabic} »
                  </p>

                  <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-[#F0EFF8] dark:border-[#27283E] text-xs">
                    <span className="text-[11px] text-[#77798C] dark:text-[#9EA0B5]">
                      📖 {dua.source}
                    </span>

                    {/* Recitation Pill */}
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-[#77798C]">اضغط للترديد:</span>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-[#5B5FEF]/10 text-[#5B5FEF] group-hover:bg-[#5B5FEF] group-hover:text-white transition-colors">
                        {currentCount} / {targetCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Virtue or Notes */}
                {dua.virtue && (
                  <div className="flex items-start gap-2 mt-3 text-xs text-[#63657D] dark:text-[#ACB0C8] bg-[#F9F9FD] dark:bg-[#23243B] p-2.5 rounded-xl border border-[#EAE9F5] dark:border-[#2F304B]">
                    <span className="text-sm shrink-0">💡</span>
                    <span className="leading-relaxed">{dua.virtue}</span>
                  </div>
                )}

                {/* Total Recited count if any */}
                {totalRecited > 0 && (
                  <div className="mt-2 text-left">
                    <span className="text-[10px] text-[#8C8EA5]">
                      قرأته {totalRecited} مرة بحمد الله
                    </span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
      )}

      {/* ── Add / Edit Custom Dua Modal ── */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5" dir="rtl">
          {/* Backdrop */}
          <div
            onClick={() => setIsModalOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
          />

          {/* Modal Dialog */}
          <div className="relative w-full max-w-lg bg-white dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#383A57] flex flex-col max-h-[92vh] z-10 animate-scale-up overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 border-b border-[#EAE4D8] dark:border-[#30324E] bg-gradient-to-br from-[#FAF8F5] via-white to-[#F2EDFF] dark:from-[#25263E] dark:via-[#1E1F35] dark:to-[#25233B] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-full bg-[#5B5FEF]/15 text-[#5B5FEF] flex items-center justify-center text-sm font-black">
                  ✍️
                </span>
                <h3 className="text-base font-black text-[#25263A] dark:text-white font-cairo">
                  {editingDua ? 'تعديل دعائك الخاص' : 'إضافة دعاء خاص جديد'}
                </h3>
              </div>

              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white dark:bg-[#2B2C46] border border-[#E6E6F0] dark:border-[#3A3C5C] text-[#25263A] dark:text-white flex items-center justify-center hover:border-[#5B5FEF] transition-colors cursor-pointer text-sm"
              >
                ✕
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveModal} className="p-5 overflow-y-auto space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#25263A] dark:text-[#DFE0EC] mb-1.5">
                  عنوان الدعاء أو المناسبة *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="مثلاً: دعاء التوفيق في دراستي، دعاء لأمي وأبي..."
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F8F8FC] dark:bg-[#282942] border border-[#E6E6F0] dark:border-[#363854] text-xs font-bold text-[#25263A] dark:text-white focus:outline-none focus:border-[#5B5FEF]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] dark:text-[#DFE0EC] mb-1.5">
                  نص الدعاء المبارك *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formArabic}
                  onChange={(e) => setFormArabic(e.target.value)}
                  placeholder="اكتب هنا كلمات دعائك ومناجاتك الخالصة لله تعالى..."
                  className="w-full p-3.5 rounded-xl bg-[#F8F8FC] dark:bg-[#282942] border border-[#E6E6F0] dark:border-[#363854] text-xs font-bold text-[#25263A] dark:text-white focus:outline-none focus:border-[#5B5FEF] leading-relaxed resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#25263A] dark:text-[#DFE0EC] mb-1.5">
                    موضوع الدعاء
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as DuaCategory)}
                    className="w-full h-11 px-3 rounded-xl bg-[#F8F8FC] dark:bg-[#282942] border border-[#E6E6F0] dark:border-[#363854] text-xs font-bold text-[#25263A] dark:text-white focus:outline-none focus:border-[#5B5FEF]"
                  >
                    {DUA_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.icon} {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#25263A] dark:text-[#DFE0EC] mb-1.5">
                    تكرار الترديد المفضل
                  </label>
                  <select
                    value={formCount}
                    onChange={(e) => setFormCount(Number(e.target.value))}
                    className="w-full h-11 px-3 rounded-xl bg-[#F8F8FC] dark:bg-[#282942] border border-[#E6E6F0] dark:border-[#363854] text-xs font-bold text-[#25263A] dark:text-white focus:outline-none focus:border-[#5B5FEF]"
                  >
                    <option value={1}>مرة واحدة (1)</option>
                    <option value={3}>3 مرات</option>
                    <option value={7}>7 مرات</option>
                    <option value={10}>10 مرات</option>
                    <option value={33}>33 مرة</option>
                    <option value={100}>100 مرة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] dark:text-[#DFE0EC] mb-1.5">
                  ملاحظة أو فضل خاص (اختياري)
                </label>
                <input
                  type="text"
                  value={formVirtue}
                  onChange={(e) => setFormVirtue(e.target.value)}
                  placeholder="مثلاً: أدعو به عند السجود أو يوم الجمعة..."
                  className="w-full h-11 px-3.5 rounded-xl bg-[#F8F8FC] dark:bg-[#282942] border border-[#E6E6F0] dark:border-[#363854] text-xs font-bold text-[#25263A] dark:text-white focus:outline-none focus:border-[#5B5FEF]"
                />
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-[#EAE4D8] dark:border-[#30324E]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-white dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#383A57] text-xs font-bold text-[#25263A] dark:text-white hover:bg-gray-50 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-black hover:bg-[#474BCD] transition-colors cursor-pointer shadow-sm"
                >
                  {editingDua ? 'حفظ التعديلات' : 'حفظ الدعاء 🤲'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
export default DuaCornerView;
