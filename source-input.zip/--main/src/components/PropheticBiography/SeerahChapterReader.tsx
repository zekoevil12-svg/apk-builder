import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  BookOpen,
  Heart,
  Share2,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Sparkles,
  Library,
  AlertTriangle,
  UserCheck,
  ChevronRight,
  ChevronLeft,
  List,
  Type,
  AlignJustify,
  Sun,
  Check,
  Edit3,
  Trash2,
} from 'lucide-react';
import {
  SeerahChapter,
  SeerahFigure,
  SeerahPlace,
  SeerahFavoriteType,
} from '../../data/seerah';

interface SeerahChapterReaderProps {
  chapter: SeerahChapter;
  prevChapter: SeerahChapter | null;
  nextChapter: SeerahChapter | null;
  figures: SeerahFigure[];
  places: SeerahPlace[];
  initialSectionId?: string;
  isChapterFavorite: boolean;
  isSectionFavorite: (secId: string) => boolean;
  isCompleted: boolean;
  isAdmin: boolean;
  onBackToIndex: () => void;
  onSelectChapter: (chapterId: string, sectionId?: string) => void;
  onToggleFavorite: (item: {
    type: SeerahFavoriteType;
    targetId: string;
    chapterId?: string;
    title: string;
    subtitle: string;
    periodTitle?: string;
  }) => void;
  onSaveProgress: (sectionId: string, sectionTitle: string, markCompleted?: boolean) => void;
  onOpenFigure: (fig: SeerahFigure) => void;
  onOpenPlace: (plc: SeerahPlace) => void;
  onAdminEdit?: (ch: SeerahChapter) => void;
  onAdminDelete?: (chapterId: string) => void;
}

type FontSizeLevel = 'sm' | 'md' | 'lg' | 'xl';
type LineSpacingLevel = 'normal' | 'relaxed' | 'loose';
type ReaderPaperTheme = 'cream' | 'white' | 'soft';

export const SeerahChapterReader: React.FC<SeerahChapterReaderProps> = ({
  chapter,
  prevChapter,
  nextChapter,
  figures,
  places,
  initialSectionId,
  isChapterFavorite,
  isSectionFavorite,
  isCompleted,
  isAdmin,
  onBackToIndex,
  onSelectChapter,
  onToggleFavorite,
  onSaveProgress,
  onOpenFigure,
  onOpenPlace,
  onAdminEdit,
  onAdminDelete,
}) => {
  const [fontSize, setFontSize] = useState<FontSizeLevel>(() => {
    return (localStorage.getItem('rifq_seerah_font_size') as FontSizeLevel) || 'lg';
  });
  const [lineSpacing, setLineSpacing] = useState<LineSpacingLevel>(() => {
    return (localStorage.getItem('rifq_seerah_line_spacing') as LineSpacingLevel) || 'relaxed';
  });
  const [paperTheme, setPaperTheme] = useState<ReaderPaperTheme>(() => {
    return (localStorage.getItem('rifq_seerah_paper_theme') as ReaderPaperTheme) || 'cream';
  });
  const [activeSectionId, setActiveSectionId] = useState<string>(
    initialSectionId || chapter.sections[0]?.id || ''
  );
  const [showToc, setShowToc] = useState(true);
  const [copiedFeedback, setCopiedFeedback] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('rifq_seerah_font_size', fontSize);
  }, [fontSize]);

  useEffect(() => {
    localStorage.setItem('rifq_seerah_line_spacing', lineSpacing);
  }, [lineSpacing]);

  useEffect(() => {
    localStorage.setItem('rifq_seerah_paper_theme', paperTheme);
  }, [paperTheme]);

  useEffect(() => {
    const firstSec = chapter.sections[0];
    if (initialSectionId) {
      setActiveSectionId(initialSectionId);
      const secObj = chapter.sections.find((s) => s.id === initialSectionId);
      if (secObj) {
        onSaveProgress(secObj.id, secObj.title);
      }
      setTimeout(() => {
        const el = document.getElementById(`seerah-sec-${initialSectionId}`);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 120);
    } else if (firstSec) {
      setActiveSectionId(firstSec.id);
      onSaveProgress(firstSec.id, firstSec.title);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [chapter.id, initialSectionId]);

  const chapterFigures = figures.filter((f) => chapter.figureIds.includes(f.id));
  const chapterPlaces = places.filter((p) => chapter.placeIds.includes(p.id));

  const fontSizeClass: Record<FontSizeLevel, string> = {
    sm: 'text-[15px]',
    md: 'text-[17px]',
    lg: 'text-[19px]',
    xl: 'text-[22px]',
  };

  const lineSpacingClass: Record<LineSpacingLevel, string> = {
    normal: 'leading-[1.85]',
    relaxed: 'leading-[2.15]',
    loose: 'leading-[2.45]',
  };

  const paperBgClass: Record<ReaderPaperTheme, string> = {
    cream: 'bg-[#FFFDF7] border-[#E8B84A]/35',
    white: 'bg-[#FFFFFF] border-[#E6E6F0]',
    soft: 'bg-[#F7F7FC] border-[#5B5FEF]/25',
  };

  const handleShare = async (customTitle?: string, customExcerpt?: string) => {
    const sourceText = chapter.sources.map((s) => s.bookTitle).join(' ، ');
    const shareTitle = customTitle || `${chapter.title} — السيرة النبوية في تطبيق رِفْق`;
    const shareBody = `🕌 ${chapter.title}\n${customTitle ? `📌 ${customTitle}\n` : ''}🗓️ ${chapter.hijriYear} — 📍 ${chapter.locationName}\n\n«${customExcerpt || chapter.summary}»\n\n📚 المراجع: ${sourceText}\n— من موسوعة السيرة النبوية في تطبيق رِفْق | RIFQ`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareBody,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(shareBody);
      setCopiedFeedback('تم نسخ مقتطف الفصل مع المصدر لمشاركته ✅');
      setTimeout(() => setCopiedFeedback(null), 3000);
    } catch {
      // ignore
    }
  };

  const jumpToSection = (secId: string, secTitle: string) => {
    setActiveSectionId(secId);
    onSaveProgress(secId, secTitle);
    const el = document.getElementById(`seerah-sec-${secId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="space-y-5 animate-fade-in font-tajawal pb-10" dir="rtl">
      {/* Top Navigation & Quick Actions Bar */}
      <div className="bg-white rounded-2xl p-3.5 border border-[#E6E6F0] shadow-2xs flex flex-wrap items-center justify-between gap-3 sticky top-14 z-30">
        <button
          type="button"
          onClick={onBackToIndex}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] hover:text-[#5B5FEF] text-xs font-black border border-[#E6E6F0] transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>فهرس فصول السيرة النبوية</span>
        </button>

        {/* Reader Settings Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Font Size */}
          <div className="flex items-center bg-[#F7F7FC] border border-[#E6E6F0] rounded-xl p-1">
            <span className="text-[10px] font-bold text-[#77798C] px-2 flex items-center gap-1">
              <Type className="w-3.5 h-3.5 text-[#5B5FEF]" />
              <span>الخط:</span>
            </span>
            {(
              [
                { id: 'sm', label: 'أ-' },
                { id: 'md', label: 'أ' },
                { id: 'lg', label: 'أ+' },
                { id: 'xl', label: 'أ++' },
              ] as { id: FontSizeLevel; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setFontSize(opt.id)}
                className={`px-2 py-1 rounded-lg text-xs font-black transition-all cursor-pointer ${
                  fontSize === opt.id
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'text-[#77798C] hover:text-[#25263A]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Line Spacing */}
          <div className="flex items-center bg-[#F7F7FC] border border-[#E6E6F0] rounded-xl p-1">
            <span className="text-[10px] font-bold text-[#77798C] px-1.5 flex items-center gap-1">
              <AlignJustify className="w-3.5 h-3.5 text-[#5B5FEF]" />
            </span>
            {(
              [
                { id: 'normal', label: 'عادي' },
                { id: 'relaxed', label: 'مريح' },
                { id: 'loose', label: 'واسع' },
              ] as { id: LineSpacingLevel; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setLineSpacing(opt.id)}
                className={`px-2 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  lineSpacing === opt.id
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'text-[#77798C] hover:text-[#25263A]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Paper Theme */}
          <div className="flex items-center bg-[#F7F7FC] border border-[#E6E6F0] rounded-xl p-1">
            <Sun className="w-3.5 h-3.5 text-[#E8B84A] mx-1.5" />
            {(
              [
                { id: 'cream', label: 'ورق كريمي' },
                { id: 'white', label: 'أبيض' },
                { id: 'soft', label: 'هادئ' },
              ] as { id: ReaderPaperTheme; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setPaperTheme(opt.id)}
                className={`px-2 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  paperTheme === opt.id
                    ? 'bg-[#E8B84A] text-[#25263A] shadow-2xs'
                    : 'text-[#77798C] hover:text-[#25263A]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {copiedFeedback && (
        <div className="p-3.5 rounded-2xl bg-[#4CAF82]/15 border border-[#4CAF82]/40 text-[#25263A] text-xs font-black flex items-center justify-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-[#4CAF82]" />
          <span>{copiedFeedback}</span>
        </div>
      )}

      {/* Chapter Book Cover Header */}
      <div className="bg-gradient-to-br from-[#5B5FEF] via-[#4A4ED9] to-[#3639A8] text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-[#E6E6F0] relative overflow-hidden">
        {/* Non-figurative Islamic geometric arch & gold ornament */}
        <div className="absolute -top-20 -left-20 w-72 h-72 rounded-full bg-[#E8B84A]/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-72 h-72 rounded-full bg-white/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#E8B84A] text-[#25263A] text-xs font-black shadow-2xs">
                المرحلة: {chapter.periodTitle}
              </span>
              <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-bold text-amber-200 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                <span>{chapter.hijriYear}</span>
                {chapter.gregorianYear && <span>({chapter.gregorianYear})</span>}
              </span>
              <span className="px-3 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-300" />
                <span>{chapter.locationName}</span>
              </span>
              <span className="px-3 py-1 rounded-full bg-white/10 text-xs font-bold text-white/90 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-300" />
                <span>{chapter.readingTimeMinutes} دقيقة قراءة</span>
              </span>
            </div>

            {/* Favorite, Share, Complete, and Admin Controls */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  onToggleFavorite({
                    type: 'chapter',
                    targetId: chapter.id,
                    chapterId: chapter.id,
                    title: chapter.title,
                    subtitle: `${chapter.hijriYear} • ${chapter.locationName}`,
                    periodTitle: chapter.periodTitle,
                  })
                }
                className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 border transition-all cursor-pointer ${
                  isChapterFavorite
                    ? 'bg-rose-500 text-white border-rose-400 shadow-sm'
                    : 'bg-white/15 hover:bg-white/25 text-white border-white/25'
                }`}
              >
                <Heart className={`w-4 h-4 ${isChapterFavorite ? 'fill-white' : ''}`} />
                <span>{isChapterFavorite ? 'في المفضلة' : 'حفظ الفصل'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleShare()}
                className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/25 text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>مشاركة</span>
              </button>

              {isAdmin && onAdminEdit && (
                <button
                  type="button"
                  onClick={() => onAdminEdit(chapter)}
                  className="p-2 rounded-xl bg-amber-400 text-[#25263A] hover:bg-amber-300 cursor-pointer"
                  title="تعديل الفصل (Admin)"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
              )}
              {isAdmin && onAdminDelete && chapter.id.startsWith('ch_custom_') && (
                <button
                  type="button"
                  onClick={() => onAdminDelete(chapter.id)}
                  className="p-2 rounded-xl bg-rose-500 text-white hover:bg-rose-600 cursor-pointer"
                  title="حذف الفصل (Admin)"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div>
            <h1 className="text-xl sm:text-3xl font-black font-cairo text-white leading-snug">
              {chapter.title}
            </h1>
            <p className="text-sm sm:text-base text-amber-200 font-bold mt-2 leading-relaxed">
              {chapter.subtitle}
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white/10 border border-white/15 text-xs sm:text-sm text-white/95 leading-relaxed">
            <span className="font-black text-amber-300 ml-1">خلاصة الفصل:</span>
            {chapter.summary}
          </div>
        </div>
      </div>

      {/* Chapter Internal Table of Contents (Chapter -> Sections -> Subsections) */}
      <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black font-cairo text-[#25263A] flex items-center gap-2">
            <List className="w-4 h-4 text-[#5B5FEF]" />
            <span>فهرس مباحث وأقسام هذا الفصل ({chapter.sections.length} مباحث تفصيلية)</span>
          </h3>
          <button
            type="button"
            onClick={() => setShowToc(!showToc)}
            className="text-xs font-black text-[#5B5FEF] hover:underline cursor-pointer"
          >
            {showToc ? 'إخفاء الفهرس' : 'إظهار الفهرس'}
          </button>
        </div>

        {showToc && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-[#E6E6F0]">
            {chapter.sections.map((sec, idx) => {
              const isActive = activeSectionId === sec.id;
              return (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => jumpToSection(sec.id, sec.title)}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-start gap-2.5 ${
                    isActive
                      ? 'bg-[#EEEEFF] border-[#5B5FEF] shadow-2xs'
                      : 'bg-[#F7F7FC] hover:bg-[#EEEEFF]/50 border-[#E6E6F0]'
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black shrink-0 mt-0.5 ${
                      isActive ? 'bg-[#5B5FEF] text-white' : 'bg-white text-[#5B5FEF] border border-[#E6E6F0]'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-black text-[#25263A] line-clamp-1">
                      {sec.title}
                    </div>
                    {sec.subsections && sec.subsections.length > 0 && (
                      <div className="text-[10px] text-[#5B5FEF] font-bold mt-0.5">
                        يضم {sec.subsections.length} فروع تفصيلية
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Main E-Book Reading Canvas: Sections & Subsections */}
      <div className="space-y-6">
        {chapter.sections.map((sec, secIdx) => {
          const secFav = isSectionFavorite(sec.id);
          return (
            <article
              key={sec.id}
              id={`seerah-sec-${sec.id}`}
              onMouseEnter={() => {
                setActiveSectionId(sec.id);
                onSaveProgress(sec.id, sec.title);
              }}
              className={`rounded-3xl p-6 sm:p-8 border shadow-xs transition-colors space-y-5 scroll-mt-32 ${paperBgClass[paperTheme]}`}
            >
              {/* Section Header */}
              <div className="flex items-start justify-between gap-3 border-b border-[#E6E6F0] pb-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-[#EEEEFF] text-[#5B5FEF] text-[11px] font-black">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>
                      المبحث {secIdx + 1} من {chapter.sections.length}
                    </span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-black font-cairo text-[#25263A]">
                    {sec.title}
                  </h2>
                  {sec.subtitle && (
                    <p className="text-xs sm:text-sm font-bold text-[#5B5FEF]">{sec.subtitle}</p>
                  )}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      onToggleFavorite({
                        type: 'section',
                        targetId: sec.id,
                        chapterId: chapter.id,
                        title: sec.title,
                        subtitle: chapter.title,
                        periodTitle: chapter.periodTitle,
                      })
                    }
                    className={`p-2 rounded-xl border transition-all cursor-pointer ${
                      secFav
                        ? 'bg-rose-50 text-rose-600 border-rose-200'
                        : 'bg-white text-[#77798C] border-[#E6E6F0] hover:text-rose-500'
                    }`}
                    title="حفظ هذا المبحث في المفضلة"
                  >
                    <Heart className={`w-4 h-4 ${secFav ? 'fill-rose-500 text-rose-500' : ''}`} />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleShare(sec.title, sec.paragraphs[0])}
                    className="p-2 rounded-xl bg-white text-[#77798C] hover:text-[#5B5FEF] border border-[#E6E6F0] cursor-pointer"
                    title="مشاركة هذا المبحث"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Section Paragraphs */}
              <div className="space-y-4">
                {sec.paragraphs.map((para, pIdx) => (
                  <p
                    key={pIdx}
                    className={`${fontSizeClass[fontSize]} ${lineSpacingClass[lineSpacing]} text-[#25263A] font-medium text-justify`}
                  >
                    {para}
                  </p>
                ))}
              </div>

              {/* Subsections (Chapter -> Sections -> Subsections) */}
              {sec.subsections && sec.subsections.length > 0 && (
                <div className="space-y-4 pt-2">
                  {sec.subsections.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-5 rounded-2xl bg-white/85 border-r-4 border-r-[#5B5FEF] border border-[#E6E6F0] space-y-3"
                    >
                      <h3 className="text-base sm:text-lg font-black font-cairo text-[#4145C7] flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#E8B84A]" />
                        <span>{sub.title}</span>
                      </h3>
                      {sub.paragraphs.map((sp, spIdx) => (
                        <p
                          key={spIdx}
                          className={`${fontSizeClass[fontSize]} ${lineSpacingClass[lineSpacing]} text-[#25263A] text-justify`}
                        >
                          {sp}
                        </p>
                      ))}
                      {sub.scholarlyNote && (
                        <div className="p-3.5 rounded-xl bg-amber-50/90 border border-amber-300/70 text-xs sm:text-sm text-amber-950 font-bold flex items-start gap-2.5 leading-relaxed">
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-1" />
                          <span>{sub.scholarlyNote}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Scholarly Verification Notes for Section */}
              {sec.scholarlyNotes && sec.scholarlyNotes.length > 0 && (
                <div className="space-y-2.5 pt-2">
                  {sec.scholarlyNotes.map((note, nIdx) => (
                    <div
                      key={nIdx}
                      className="p-4 rounded-2xl bg-amber-50/90 border border-amber-300/80 text-xs sm:text-sm text-amber-950 font-bold flex items-start gap-2.5 leading-relaxed"
                    >
                      <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div>{note}</div>
                    </div>
                  ))}
                </div>
              )}
            </article>
          );
        })}
      </div>

      {/* Quranic Verses Related to the Chapter */}
      {chapter.verses.length > 0 && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E6E6F0] shadow-xs space-y-4">
          <h3 className="text-base sm:text-lg font-black font-cairo text-[#25263A] flex items-center gap-2 border-b border-[#E6E6F0] pb-3">
            <span className="text-xl">📜</span>
            <span>الآيات القرآنية المتعلقة بأحداث الفصل</span>
          </h3>

          <div className="space-y-4">
            {chapter.verses.map((v) => (
              <div
                key={v.id}
                className="p-5 rounded-2xl bg-gradient-to-l from-[#FFFDF7] via-[#FFFBEB]/50 to-[#EEEEFF]/30 border border-[#E8B84A]/50 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="px-3 py-1 rounded-xl bg-[#E8B84A]/20 text-[#25263A] border border-[#E8B84A]/40 text-xs font-black">
                    سورة {v.surahName} (رقم السورة: {v.surahNumber}) — الآيات: {v.ayahNumbers}
                  </span>
                </div>
                <p className="text-lg sm:text-xl font-bold text-[#25263A] leading-[2.2] font-cairo">
                  ﴿ {v.text} ﴾
                </p>
                {v.contextNote && (
                  <p className="text-xs font-bold text-[#5B5FEF] bg-white/80 px-3 py-2 rounded-xl border border-[#E6E6F0]">
                    💡 {v.contextNote}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Authentic Prophetic Hadiths Related to the Chapter */}
      {chapter.hadiths.length > 0 && (
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E6E6F0] shadow-xs space-y-4">
          <h3 className="text-base sm:text-lg font-black font-cairo text-[#25263A] flex items-center gap-2 border-b border-[#E6E6F0] pb-3">
            <span className="text-xl">🕌</span>
            <span>الأحاديث النبوية والآثار الصحيحة المتعلقة بالحدث</span>
          </h3>

          <div className="space-y-4">
            {chapter.hadiths.map((h) => (
              <div
                key={h.id}
                className="p-5 rounded-2xl bg-[#F7F7FC] border border-[#5B5FEF]/30 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  {h.narrator && (
                    <span className="text-xs font-black text-[#5B5FEF]">
                      راوي الحديث: {h.narrator}
                    </span>
                  )}
                  <span className="px-2.5 py-1 rounded-lg bg-[#4CAF82]/15 text-[#4CAF82] text-xs font-black">
                    الدرجة: {h.grade}
                  </span>
                </div>
                <p className="text-base sm:text-lg font-bold text-[#25263A] leading-[2.05]">
                  {h.text}
                </p>
                <div className="pt-2 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-2 text-xs text-[#77798C] font-bold">
                  <span>📚 المصدر: {h.source}</span>
                  {h.reference && <span>({h.reference})</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Linked Figures & Places Cards */}
      {(chapterFigures.length > 0 || chapterPlaces.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Figures */}
          {chapterFigures.length > 0 && (
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-2xs space-y-3">
              <h4 className="text-sm font-black font-cairo text-[#25263A] flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#5B5FEF]" />
                <span>الشخصيات المرتبطة بهذا الفصل (اضغط للتفاصيل)</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {chapterFigures.map((fig) => (
                  <button
                    key={fig.id}
                    type="button"
                    onClick={() => onOpenFigure(fig)}
                    className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] hover:border-[#5B5FEF] text-right transition-all cursor-pointer flex items-center gap-2"
                  >
                    <span className="w-2 h-2 rounded-full bg-[#5B5FEF]" />
                    <div>
                      <div className="text-xs font-black text-[#25263A]">{fig.name}</div>
                      <div className="text-[10px] text-[#77798C] font-bold">{fig.honorific}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Places */}
          {chapterPlaces.length > 0 && (
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-2xs space-y-3">
              <h4 className="text-sm font-black font-cairo text-[#25263A] flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#4CAF82]" />
                <span>الأماكن والمعالم المرتبطة بالحدث (اضغط للتفاصيل)</span>
              </h4>
              <div className="flex flex-wrap gap-2">
                {chapterPlaces.map((plc) => (
                  <button
                    key={plc.id}
                    type="button"
                    onClick={() => onOpenPlace(plc)}
                    className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#4CAF82]/10 border border-[#E6E6F0] hover:border-[#4CAF82] text-right transition-all cursor-pointer flex items-center gap-2"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#4CAF82]" />
                    <div>
                      <div className="text-xs font-black text-[#25263A]">{plc.name}</div>
                      <div className="text-[10px] text-[#77798C] font-bold">{plc.regionLabel}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Lessons & Benefits */}
      {chapter.lessons.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] shadow-2xs space-y-3">
          <h3 className="text-base font-black font-cairo text-[#25263A] flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#E8B84A]" />
            <span>الدروس والفوائد التربوية والتشريعية من الفصل</span>
          </h3>
          <div className="grid grid-cols-1 gap-2.5">
            {chapter.lessons.map((lesson, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-2xl bg-[#FFFDF7] border border-[#E8B84A]/35 flex items-start gap-2.5 text-sm font-bold text-[#25263A]"
              >
                <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0 mt-1" />
                <span>{lesson}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sources & References */}
      <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-2xs space-y-3">
        <h3 className="text-sm font-black font-cairo text-[#25263A] flex items-center gap-2">
          <Library className="w-4 h-4 text-[#5B5FEF]" />
          <span>المصادر والمراجع المعتمدة لهذا الفصل</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {chapter.sources.map((src) => (
            <div
              key={src.id}
              className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-right"
            >
              <div className="text-xs font-black text-[#25263A]">{src.bookTitle}</div>
              <div className="text-[11px] text-[#77798C] font-bold mt-0.5">{src.author}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Mark Chapter Completed & Prev / Next Chapter Navigation */}
      <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs font-bold text-[#77798C]">
            هل أتممت قراءة هذا الفصل من السيرة النبوية؟
          </div>
          <button
            type="button"
            onClick={() => {
              const lastSec = chapter.sections[chapter.sections.length - 1];
              onSaveProgress(
                lastSec?.id || '',
                lastSec?.title || chapter.title,
                true
              );
            }}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              isCompleted
                ? 'bg-[#4CAF82] text-white shadow-xs'
                : 'bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#5B5FEF] hover:text-white'
            }`}
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>
              {isCompleted
                ? 'تم إتمام قراءة هذا الفصل بحمد الله ✓'
                : 'تحديد الفصل كمقروء وحفظ التقدم'}
            </span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-[#E6E6F0]">
          {prevChapter ? (
            <button
              type="button"
              onClick={() => onSelectChapter(prevChapter.id)}
              className="p-4 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] hover:border-[#5B5FEF] text-right transition-all flex items-center gap-3 cursor-pointer"
            >
              <ChevronRight className="w-5 h-5 text-[#5B5FEF] shrink-0" />
              <div className="min-w-0">
                <div className="text-[10px] font-bold text-[#77798C]">الفصل السابق</div>
                <div className="text-xs font-black text-[#25263A] truncate">
                  {prevChapter.title}
                </div>
              </div>
            </button>
          ) : (
            <div />
          )}

          {nextChapter ? (
            <button
              type="button"
              onClick={() => {
                const lastSec = chapter.sections[chapter.sections.length - 1];
                onSaveProgress(lastSec?.id || '', lastSec?.title || chapter.title, true);
                onSelectChapter(nextChapter.id);
              }}
              className="p-4 rounded-2xl bg-gradient-to-l from-[#5B5FEF] to-[#4145C7] text-white text-left transition-all flex items-center justify-between gap-3 cursor-pointer shadow-xs hover:opacity-95"
            >
              <div className="min-w-0 text-right">
                <div className="text-[10px] font-bold text-amber-200">الانتقال إلى الفصل التالي</div>
                <div className="text-xs font-black text-white truncate">{nextChapter.title}</div>
              </div>
              <ChevronLeft className="w-5 h-5 text-amber-300 shrink-0" />
            </button>
          ) : (
            <button
              type="button"
              onClick={onBackToIndex}
              className="p-4 rounded-2xl bg-[#4CAF82] text-white text-center font-black text-xs cursor-pointer"
            >
              العودة إلى فهرس الكتاب الكامل
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
