import React, { useState } from 'react';
import {
  X,
  Heart,
  BookOpen,
  MapPin,
  UserCheck,
  Sparkles,
  CheckCircle2,
  Library,
  Save,
  CloudUpload,
} from 'lucide-react';
import {
  SeerahFigure,
  SeerahPlace,
  SeerahChapter,
  SeerahPeriodId,
  SEERAH_PERIODS,
} from '../../data/seerah';

interface FigureModalProps {
  figure: SeerahFigure | null;
  chapters: SeerahChapter[];
  isFavorite: boolean;
  onClose: () => void;
  onToggleFavorite: () => void;
  onOpenChapter: (chapterId: string) => void;
}

export const FigureDetailModal: React.FC<FigureModalProps> = ({
  figure,
  chapters,
  isFavorite,
  onClose,
  onToggleFavorite,
  onOpenChapter,
}) => {
  if (!figure) return null;

  const relatedChapters = chapters.filter((c) => figure.relatedChapterIds.includes(c.id));

  return (
    <div
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fade-in font-tajawal"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="bg-[#FFFFFF] border border-[#E6E6F0] rounded-3xl max-w-2xl w-full max-h-[88vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4D51DF] to-[#3E42B8] p-5 sm:p-6 text-white relative overflow-hidden">
          <div className="absolute -top-12 -left-12 w-40 h-40 rounded-full bg-[#E8B84A]/15 blur-2xl pointer-events-none" />
          <div className="relative z-10 flex items-start justify-between gap-3">
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/15 border border-white/20 text-[11px] font-black text-amber-200 mb-2">
                <UserCheck className="w-3.5 h-3.5" />
                <span>{figure.categoryLabel}</span>
              </span>
              <h3 className="text-xl sm:text-2xl font-black font-cairo text-white">
                {figure.name}{' '}
                <span className="text-amber-300 text-base font-bold">({figure.honorific})</span>
              </h3>
              <p className="text-xs text-white/85 font-bold mt-1">{figure.fullName}</p>
              <p className="text-[11px] text-amber-200 font-bold mt-0.5">{figure.titleOrKunya}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={onToggleFavorite}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  isFavorite
                    ? 'bg-rose-500 text-white border-rose-400'
                    : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
                }`}
                title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
              </button>
              <button
                type="button"
                onClick={onClose}
                className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5 text-right">
          {/* Summary */}
          <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-sm text-[#25263A] font-bold leading-relaxed">
            {figure.summary}
          </div>

          {/* Biography Paragraphs */}
          <div className="space-y-3">
            <h4 className="text-sm font-black font-cairo text-[#4145C7] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#5B5FEF]" />
              <span>سيرته ومناقبه في السيرة النبوية</span>
            </h4>
            {figure.biographyParagraphs.map((p, idx) => (
              <p key={idx} className="text-sm text-[#25263A] leading-[1.95] text-justify">
                {p}
              </p>
            ))}
          </div>

          {/* Key Roles */}
          <div className="space-y-2.5">
            <h4 className="text-sm font-black font-cairo text-[#4145C7] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#E8B84A]" />
              <span>أبرز المواقف والأدوار في السيرة</span>
            </h4>
            <ul className="space-y-2">
              {figure.keyRolesInSeerah.map((role, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 text-xs sm:text-sm text-[#25263A] bg-[#FFFDF7] p-3 rounded-xl border border-[#E8B84A]/30"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0 mt-0.5" />
                  <span>{role}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Authentic Virtue Hadith */}
          {figure.authenticVirtueOrHadith && (
            <div className="p-4 rounded-2xl bg-gradient-to-l from-[#EEEEFF]/80 to-[#FFFDF7] border border-[#5B5FEF]/30 space-y-2">
              <div className="text-xs font-black text-[#5B5FEF]">
                📜 من الثابت في فضله ومناقبه:
              </div>
              <p className="text-sm font-bold text-[#25263A] leading-relaxed">
                {figure.authenticVirtueOrHadith.text}
              </p>
              <div className="text-[11px] font-bold text-[#4CAF82]">
                المصدر: {figure.authenticVirtueOrHadith.source}
              </div>
            </div>
          )}

          {/* Related Chapters */}
          {relatedChapters.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-black text-[#77798C] uppercase">
                فصول السيرة المرتبطة بهذه الشخصية ({relatedChapters.length}):
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {relatedChapters.map((ch) => (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenChapter(ch.id);
                    }}
                    className="p-3 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] hover:border-[#5B5FEF] text-right transition-all cursor-pointer"
                  >
                    <div className="text-xs font-black text-[#25263A] line-clamp-1">{ch.title}</div>
                    <div className="text-[10px] text-[#5B5FEF] font-bold mt-0.5">
                      {ch.hijriYear} • اضغط لقراءة الفصل ←
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sources */}
          <div className="pt-3 border-t border-[#E6E6F0] flex flex-wrap items-center gap-2 text-[11px] text-[#77798C]">
            <Library className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span className="font-black">المراجع المعتمدة:</span>
            <span>{figure.sources.join(' ، ')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

interface PlaceModalProps {
  place: SeerahPlace | null;
  chapters: SeerahChapter[];
  isFavorite: boolean;
  onClose: () => void;
  onToggleFavorite: () => void;
  onOpenChapter: (chapterId: string) => void;
}

export const PlaceDetailModal: React.FC<PlaceModalProps> = ({
  place,
  chapters,
  isFavorite,
  onClose,
  onToggleFavorite,
  onOpenChapter,
}) => {
  if (!place) return null;

  const relatedChapters = chapters.filter((c) => place.relatedChapterIds.includes(c.id));

  return (
    <div
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fade-in font-tajawal"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="bg-[#FFFFFF] border border-[#E6E6F0] rounded-3xl max-w-2xl w-full max-h-[88vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-gradient-to-l from-[#4145C7] via-[#5B5FEF] to-[#4CAF82]/90 p-5 sm:p-6 text-white relative overflow-hidden">
          <div className="relative z-10 flex items-start justify-between gap-3">
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/15 border border-white/20 text-[11px] font-black text-amber-200 mb-2">
                <MapPin className="w-3.5 h-3.5" />
                <span>{place.regionLabel}</span>
              </span>
              <h3 className="text-xl sm:text-2xl font-black font-cairo text-white">{place.name}</h3>
              <p className="text-xs text-white/90 font-bold mt-1">{place.modernLocation}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={onToggleFavorite}
                className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                  isFavorite
                    ? 'bg-rose-500 text-white border-rose-400'
                    : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
                }`}
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
              </button>
              <button
                type="button"
                onClick={onClose}
                className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-5 text-right">
          <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-sm text-[#25263A] font-bold leading-relaxed">
            {place.summary}
          </div>

          {place.distanceNote && (
            <div className="p-3.5 rounded-2xl bg-[#FFFDF7] border border-[#E8B84A]/40 text-xs font-bold text-[#25263A] flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#E8B84A] shrink-0" />
              <span>{place.distanceNote}</span>
            </div>
          )}

          <div className="space-y-2.5">
            <h4 className="text-sm font-black font-cairo text-[#4145C7]">
              الأهمية التاريخية والأحداث النبوية في هذا المعلم:
            </h4>
            <ul className="space-y-2">
              {place.historicalSignificance.map((pt, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 text-xs sm:text-sm text-[#25263A] bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]"
                >
                  <CheckCircle2 className="w-4 h-4 text-[#5B5FEF] shrink-0 mt-0.5" />
                  <span>{pt}</span>
                </li>
              ))}
            </ul>
          </div>

          {relatedChapters.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-black text-[#77798C]">
                فصول السيرة المرتبطة بهذا المكان ({relatedChapters.length}):
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {relatedChapters.map((ch) => (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenChapter(ch.id);
                    }}
                    className="p-3 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] hover:border-[#5B5FEF] text-right transition-all cursor-pointer"
                  >
                    <div className="text-xs font-black text-[#25263A] line-clamp-1">{ch.title}</div>
                    <div className="text-[10px] text-[#5B5FEF] font-bold mt-0.5">
                      {ch.hijriYear} • قراءة الفصل ←
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="pt-3 border-t border-[#E6E6F0] flex flex-wrap items-center gap-2 text-[11px] text-[#77798C]">
            <Library className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span className="font-black">المراجع:</span>
            <span>{place.sources.join(' ، ')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

interface AdminModalProps {
  isOpen: boolean;
  initialChapter?: SeerahChapter | null;
  totalChaptersCount: number;
  onClose: () => void;
  onSaveChapter: (chapter: SeerahChapter) => Promise<void>;
  onSyncAllToCloud: () => Promise<void>;
}

export const AdminChapterModal: React.FC<AdminModalProps> = ({
  isOpen,
  initialChapter,
  totalChaptersCount,
  onClose,
  onSaveChapter,
  onSyncAllToCloud,
}) => {
  const [title, setTitle] = useState(initialChapter?.title || '');
  const [subtitle, setSubtitle] = useState(initialChapter?.subtitle || '');
  const [period, setPeriod] = useState<SeerahPeriodId>(initialChapter?.period || 'pre_mission');
  const [hijriYear, setHijriYear] = useState(initialChapter?.hijriYear || '');
  const [gregorianYear, setGregorianYear] = useState(initialChapter?.gregorianYear || '');
  const [locationName, setLocationName] = useState(initialChapter?.locationName || 'مكة المكرمة');
  const [summary, setSummary] = useState(initialChapter?.summary || '');
  const [sectionTitle, setSectionTitle] = useState(
    initialChapter?.sections?.[0]?.title || 'المبحث الأول'
  );
  const [sectionBody, setSectionBody] = useState(
    initialChapter?.sections?.[0]?.paragraphs?.join('\n\n') || ''
  );
  const [sourceBook, setSourceBook] = useState(
    initialChapter?.sources?.[0]?.bookTitle || 'صحيح البخاري / سيرة ابن هشام'
  );
  const [status, setStatus] = useState<'published' | 'draft'>(
    initialChapter?.status || 'published'
  );
  const [saving, setSaving] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim()) return;
    setSaving(true);
    const periodObj = SEERAH_PERIODS.find((p) => p.id === period) || SEERAH_PERIODS[0];
    const id = initialChapter?.id || `ch_custom_${Date.now()}`;
    const newChapter: SeerahChapter = {
      id,
      slug: initialChapter?.slug || `chapter-${Date.now()}`,
      order: initialChapter?.order || totalChaptersCount + 1,
      period,
      periodTitle: periodObj.title,
      hijriYear: hijriYear.trim() || periodObj.dateRange,
      gregorianYear: gregorianYear.trim() || '',
      locationName: locationName.trim() || 'الحجاز',
      title: title.trim(),
      subtitle: subtitle.trim(),
      summary: summary.trim(),
      readingTimeMinutes: initialChapter?.readingTimeMinutes || 15,
      sections: initialChapter?.sections?.length
        ? initialChapter.sections
        : [
            {
              id: `sec_${Date.now()}`,
              order: 1,
              title: sectionTitle.trim() || 'تفصيل الحدث',
              paragraphs: sectionBody
                .split('\n')
                .map((p) => p.trim())
                .filter(Boolean),
            },
          ],
      verses: initialChapter?.verses || [],
      hadiths: initialChapter?.hadiths || [],
      lessons: initialChapter?.lessons || [],
      figureIds: initialChapter?.figureIds || [],
      placeIds: initialChapter?.placeIds || [],
      sources: initialChapter?.sources?.length
        ? initialChapter.sources
        : [{ id: `src_${Date.now()}`, bookTitle: sourceBook.trim(), author: 'مصدر معتمد' }],
      status,
      createdAt: initialChapter?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await onSaveChapter(newChapter);
    setSaving(false);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fade-in font-tajawal"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="bg-white border border-[#E6E6F0] rounded-3xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-5 sm:p-6 shadow-2xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
          <h3 className="text-base font-black font-cairo text-[#25263A]">
            ⚙️ لوحة المشرف (Admin) — إدارة فصول السيرة النبوية
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-[#F7F7FC] text-[#77798C] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#EEEEFF]/60 border border-[#5B5FEF]/30 flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs font-bold text-[#25263A]">
            مزامنة الموسوعة الكاملة (24 فصلاً والشخصيات والأماكن) إلى Firestore:
          </div>
          <button
            type="button"
            disabled={saving}
            onClick={async () => {
              setSaving(true);
              await onSyncAllToCloud();
              setSaving(false);
            }}
            className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-black flex items-center gap-1.5 cursor-pointer hover:bg-[#4A4ED9] disabled:opacity-50"
          >
            <CloudUpload className="w-4 h-4" />
            <span>مزامنة الموسوعة مع Firestore</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-right">
          <div>
            <label className="text-xs font-black text-[#25263A]">عنوان الفصل:</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: الفصل الخامس والعشرون: ..."
              className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
            />
          </div>

          <div>
            <label className="text-xs font-black text-[#25263A]">العنوان الفرعي:</label>
            <input
              type="text"
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-black text-[#25263A]">المرحلة الزمنية:</label>
              <select
                value={period}
                onChange={(e) => setPeriod(e.target.value as SeerahPeriodId)}
                className="w-full mt-1 px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
              >
                {SEERAH_PERIODS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.order}. {p.title}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-black text-[#25263A]">حالة النشر:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'published' | 'draft')}
                className="w-full mt-1 px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
              >
                <option value="published">منشور (Published)</option>
                <option value="draft">مسودة مخفية (Draft)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-black text-[#25263A]">التاريخ الهجري:</label>
              <input
                type="text"
                value={hijriYear}
                onChange={(e) => setHijriYear(e.target.value)}
                placeholder="مثال: رمضان 2 هـ"
                className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
              />
            </div>
            <div>
              <label className="text-xs font-black text-[#25263A]">المكان:</label>
              <input
                type="text"
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-black text-[#25263A]">ملخص الفصل:</label>
            <textarea
              rows={2}
              required
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
            />
          </div>

          {!initialChapter && (
            <>
              <div>
                <label className="text-xs font-black text-[#25263A]">عنوان المبحث الأول:</label>
                <input
                  type="text"
                  value={sectionTitle}
                  onChange={(e) => setSectionTitle(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
                />
              </div>
              <div>
                <label className="text-xs font-black text-[#25263A]">
                  النص التفصيلي (افصل بين الفقرات بسطر جديد):
                </label>
                <textarea
                  rows={4}
                  required
                  value={sectionBody}
                  onChange={(e) => setSectionBody(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
                />
              </div>
              <div>
                <label className="text-xs font-black text-[#25263A]">المصدر الموثق:</label>
                <input
                  type="text"
                  required
                  value={sourceBook}
                  onChange={(e) => setSourceBook(e.target.value)}
                  className="w-full mt-1 px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-xs bg-[#F7F7FC]"
                />
              </div>
            </>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#77798C] cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 rounded-xl bg-[#4CAF82] text-white text-xs font-black flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الفصل في Firestore</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
