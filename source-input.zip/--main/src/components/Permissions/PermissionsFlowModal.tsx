import React, { useState } from 'react';
import { 
  Compass, 
  Bell, 
  Mic, 
  Download, 
  ShieldCheck, 
  MapPin, 
  Settings, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw,
  Info,
  X
} from 'lucide-react';
import { 
  requestLocationPermission, 
  requestNotificationPermissionNative, 
  requestMicrophonePermission, 
  requestStoragePermission,
  setCompletedPermissionsFlow,
  savePermissionState,
  loadNotificationPreferences,
  saveNotificationPreferences,
  NotificationPreferences,
  openAppSettings,
  PermissionStatus
} from '../../utils/permissionManager';
import { CitySelectorModal } from '../Prayers/CitySelectorModal';
import { CityLocation } from '../../types';

interface PermissionsFlowModalProps {
  onComplete: () => void;
  onOpenCitySelector?: () => void;
}

export const PermissionsFlowModal: React.FC<PermissionsFlowModalProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState<number>(0); // 0: Location, 1: Notifications, 2: Microphone, 3: Storage
  const [isLoading, setIsLoading] = useState(false);
  const [resultStatus, setResultStatus] = useState<{
    type: 'success' | 'denied' | 'permanentlyDenied' | null;
    message: string;
    details?: string;
  }>({ type: null, message: '' });
  
  const [showSettingsGuidance, setShowSettingsGuidance] = useState<{
    isOpen: boolean;
    title: string;
    steps: string[];
  }>({ isOpen: false, title: '', steps: [] });

  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(loadNotificationPreferences);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [currentCity, setCurrentCity] = useState<CityLocation>(() => {
    try {
      const saved = localStorage.getItem('rafiq_current_city');
      return saved ? JSON.parse(saved) : {
        id: 'eg-cairo',
        nameAr: 'القاهرة',
        nameEn: 'Cairo',
        countryAr: 'مصر',
        countryEn: 'Egypt',
        latitude: 30.0444,
        longitude: 31.2357,
        regionCategory: 'egypt'
      };
    } catch {
      return {
        id: 'eg-cairo',
        nameAr: 'القاهرة',
        nameEn: 'Cairo',
        countryAr: 'مصر',
        countryEn: 'Egypt',
        latitude: 30.0444,
        longitude: 31.2357,
        regionCategory: 'egypt'
      };
    }
  });

  const totalSteps = 4;

  const nextStep = () => {
    setResultStatus({ type: null, message: '' });
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      finishFlow();
    }
  };

  const finishFlow = () => {
    setCompletedPermissionsFlow();
    onComplete();
  };

  // 1. LOCATION PERMISSION HANDLER
  const handleAllowLocation = async () => {
    setIsLoading(true);
    setResultStatus({ type: null, message: '' });

    try {
      const res = await requestLocationPermission();
      if (res.granted && res.coords) {
        setResultStatus({
          type: 'success',
          message: 'تم تحديد موقعك بنجاح! تم تحديث مواقيت الصلاة والقبلة.',
          details: `الإحداثيات: ${res.coords.latitude.toFixed(4)}°, ${res.coords.longitude.toFixed(4)}°`
        });
        setTimeout(() => {
          nextStep();
        }, 1200);
      } else if (res.isPermanentlyDenied) {
        setResultStatus({
          type: 'permanentlyDenied',
          message: res.error || 'تم حظر إذن الموقع من إعدادات النظام.',
          details: 'يمكنك فتح الإعدادات لتفعيله، أو اختيار مدينتك يدوياً فوراً.'
        });
      } else {
        setResultStatus({
          type: 'denied',
          message: res.error || 'لم يتم منح إذن الموقع.',
          details: 'يمكنك إدخال اسم مدينتك يدوياً بسهولة ودون أي مشاكل.'
        });
      }
    } catch (e) {
      setResultStatus({
        type: 'denied',
        message: 'حدث خطأ أثناء طلب الإذن من نظام التشغيل.',
        details: (e as Error)?.message
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 2. NOTIFICATIONS PERMISSION HANDLER
  const handleAllowNotifications = async () => {
    setIsLoading(true);
    setResultStatus({ type: null, message: '' });

    try {
      saveNotificationPreferences(notificationPrefs);
      const res = await requestNotificationPermissionNative();

      if (res.granted) {
        setResultStatus({
          type: 'success',
          message: 'تم تفعيل إشعارات الجهاز بنجاح!',
          details: 'تم إرسال إشعار تجريبي لشريط إشعارات هاتفك وتفعيل تذكيرات الأذكار والمواقيت.'
        });
        setTimeout(() => {
          nextStep();
        }, 1200);
      } else {
        setResultStatus({
          type: 'permanentlyDenied',
          message: 'إشعارات الجهاز متوقفة',
          details: 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.'
        });
      }
    } catch (e) {
      setResultStatus({
        type: 'permanentlyDenied',
        message: 'إشعارات الجهاز متوقفة',
        details: (e as Error)?.message || 'اضغط على «السماح بالإشعارات» لفتح إعدادات التطبيق.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 3. MICROPHONE PERMISSION HANDLER
  const handleAllowMicrophone = async () => {
    setIsLoading(true);
    setResultStatus({ type: null, message: '' });

    try {
      const res = await requestMicrophonePermission();
      if (res.granted) {
        setResultStatus({
          type: 'success',
          message: 'تم اختبار الميكروفون بنجاح!',
          details: 'التسبيح الصوتي جاهز. صوتك يعالج محلياً 100% ولا يتم تسجيله.'
        });
        setTimeout(() => {
          nextStep();
        }, 1200);
      } else if (res.isPermanentlyDenied) {
        setResultStatus({
          type: 'permanentlyDenied',
          message: 'الميكروفون محظور في إعدادات جهازك.',
          details: 'المسبحة اللمسية التفاعلية متاحة دائماً بدون ميكروفون.'
        });
      } else {
        setResultStatus({
          type: 'denied',
          message: 'لم يتم منح إذن الميكروفون.',
          details: 'يمكنك المتابعة مع المسبحة اليدوية الكلاسيكية في أي وقت.'
        });
      }
    } catch (e) {
      setResultStatus({
        type: 'denied',
        message: 'تعذر الوصول إلى الميكروفون.',
        details: (e as Error)?.message
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 4. STORAGE PERMISSION HANDLER
  const handleAllowStorage = async () => {
    setIsLoading(true);
    setResultStatus({ type: null, message: '' });

    try {
      const res = await requestStoragePermission();
      if (res.granted) {
        setResultStatus({
          type: 'success',
          message: 'تم تهيئة التخزين الدائم للصوتيات بنجاح!',
          details: 'يمكنك الاستماع للتلاوات والأذان دون الحاجة لاتصال بالإنترنت.'
        });
        setTimeout(() => {
          finishFlow();
        }, 1200);
      } else {
        setResultStatus({
          type: 'denied',
          message: 'التخزين غير دائم.',
          details: 'يمكنك الاستماع للتلاوات مباشرة عبر الإنترنت.'
        });
      }
    } catch (e) {
      setResultStatus({
        type: 'denied',
        message: 'حدث خطأ في إذن التخزين.',
        details: (e as Error)?.message
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenSettingsAction = () => {
    const permKeys: ('location' | 'notifications' | 'microphone' | 'storage')[] = [
      'location', 'notifications', 'microphone', 'storage'
    ];
    const guidance = openAppSettings(permKeys[currentStep]);
    setShowSettingsGuidance({
      isOpen: true,
      title: guidance.instructions.title,
      steps: guidance.instructions.steps
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md" dir="rtl">
      <div className="relative w-full max-w-md bg-[#F7F7FC] rounded-3xl shadow-2xl overflow-hidden flex flex-col border-2 border-[#E6E6F0] animate-fade-in text-[#25263A]">
        
        {/* Top Header with Progress & Skip */}
        <div className="px-6 pt-5 pb-2 flex items-center justify-between border-b border-amber-900/10">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black text-[#4145C7] bg-blue-100/90 px-3 py-1 rounded-full border border-blue-300">
              إذن {currentStep + 1} من {totalSteps}
            </span>
          </div>

          <button
            type="button"
            onClick={finishFlow}
            className="text-xs font-bold text-[#77798C] hover:text-[#4145C7] px-2.5 py-1 rounded-lg hover:bg-stone-200/60 transition-colors cursor-pointer"
          >
            تخطي الكل
          </button>
        </div>

        {/* Modal Body */}
        <div className="px-6 py-6 flex flex-col items-center text-center flex-1">
          
          {/* ─────────────────────────────────────────────────────────────
              SCREEN 1: LOCATION
             ───────────────────────────────────────────────────────────── */}
          {currentStep === 0 && (
            <div className="w-full flex flex-col items-center animate-fade-in">
              <div className="relative mb-5">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#72B7E8] via-[#E8B84A] to-[#F7F7FC] p-1 shadow-md flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#F7F7FC] flex items-center justify-center border-2 border-white">
                    <Compass className="w-12 h-12 text-[#4145C7]" />
                  </div>
                </div>
                <div className="absolute -bottom-2.5 bg-[#4145C7] text-amber-300 text-[10px] font-black px-3 py-0.5 rounded-full border border-amber-400">
                  مواقيت الصلاة والقبلة
                </div>
              </div>

              <h3 className="text-2xl font-black text-[#4145C7] mb-2 font-tajawal">
                الوصول إلى الموقع الجغرافي
              </h3>

              <p className="text-sm text-[#77798C] leading-relaxed mb-4">
                لحساب مواقيت الصلاة الدقيقة وفق موقعك وتوجيه بوصلة القبلة نحو الكعبة المشرفة بدقة
              </p>

              <div className="w-full bg-white/80 rounded-2xl p-3 border border-[#E6E6F0]/80 text-right text-xs text-[#77798C] space-y-1 mb-4">
                <div className="flex items-center gap-2 text-[#4145C7] font-bold">
                  <ShieldCheck className="w-4 h-4 text-[#5B5FEF]" />
                  <span>حماية خصوصيتك (When In Use):</span>
                </div>
                <p className="text-[11px] leading-relaxed text-[#77798C] pr-6">
                  يُطلب الإذن فقط أثناء استخدام التطبيق. لا يتم تتبعك في الخلفية ولا تُحفظ إحداثياتك خارج جهازك.
                </p>
              </div>

              <div className="w-full bg-blue-50/70 rounded-2xl p-2.5 border border-blue-200 text-right text-xs text-blue-900 flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-blue-700 shrink-0" />
                <span className="text-[11px]">
                  <strong>البديل المتاح:</strong> يمكنك إدخال مدينتك يدوياً دون الحاجة لتحديد الموقع التلقائي.
                </span>
              </div>
            </div>
          )}

          {/* ─────────────────────────────────────────────────────────────
              SCREEN 2: NOTIFICATIONS
             ───────────────────────────────────────────────────────────── */}
          {currentStep === 1 && (
            <div className="w-full flex flex-col items-center animate-fade-in">
              <div className="relative mb-5">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#72B7E8] via-[#E8B84A] to-[#F7F7FC] p-1 shadow-md flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#F7F7FC] flex items-center justify-center border-2 border-white">
                    <Bell className="w-12 h-12 text-[#4145C7]" />
                  </div>
                </div>
                <div className="absolute -bottom-2.5 bg-[#4145C7] text-amber-300 text-[10px] font-black px-3 py-0.5 rounded-full border border-amber-400">
                  الأذان والأذكار
                </div>
              </div>

              <h3 className="text-2xl font-black text-[#4145C7] mb-2 font-tajawal">
                تفعيل الإشعارات والتنبيهات
              </h3>

              <p className="text-sm text-[#77798C] leading-relaxed mb-4">
                اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.
              </p>

              {/* Notification Preferences */}
              <div className="w-full bg-white/80 rounded-2xl p-3 border border-[#E6E6F0] text-right space-y-1.5 mb-4">
                <label className="flex items-center justify-between p-1 hover:bg-stone-50 rounded-xl cursor-pointer">
                  <span className="text-xs font-bold text-stone-700">تنبيهات الأذان والصلوات الخمس</span>
                  <input
                    type="checkbox"
                    checked={notificationPrefs.adhan}
                    onChange={(e) => setNotificationPrefs(p => ({ ...p, adhan: e.target.checked }))}
                    className="w-4 h-4 accent-[#4145C7] rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-1 hover:bg-stone-50 rounded-xl cursor-pointer">
                  <span className="text-xs font-bold text-stone-700">أذكار الصباح والمساء</span>
                  <input
                    type="checkbox"
                    checked={notificationPrefs.athkar}
                    onChange={(e) => setNotificationPrefs(p => ({ ...p, athkar: e.target.checked }))}
                    className="w-4 h-4 accent-[#4145C7] rounded cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-1 hover:bg-stone-50 rounded-xl cursor-pointer">
                  <span className="text-xs font-bold text-stone-700">حديث شريف يومي</span>
                  <input
                    type="checkbox"
                    checked={notificationPrefs.hadithOfTheDay}
                    onChange={(e) => setNotificationPrefs(p => ({ ...p, hadithOfTheDay: e.target.checked }))}
                    className="w-4 h-4 accent-[#4145C7] rounded cursor-pointer"
                  />
                </label>
              </div>

              <div className="w-full bg-blue-50/70 rounded-2xl p-2.5 border border-blue-200 text-right text-xs text-blue-900 flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-blue-700 shrink-0" />
                <span className="text-[11px]">
                  <strong>البديل المتاح:</strong> عند الرفض سيعمل التطبيق بالكامل بدون إشعارات خارجية في الخلفية.
                </span>
              </div>
            </div>
          )}

          {/* ─────────────────────────────────────────────────────────────
              SCREEN 3: MICROPHONE
             ───────────────────────────────────────────────────────────── */}
          {currentStep === 2 && (
            <div className="w-full flex flex-col items-center animate-fade-in">
              <div className="relative mb-5">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#72B7E8] via-[#E8B84A] to-[#F7F7FC] p-1 shadow-md flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#F7F7FC] flex items-center justify-center border-2 border-white">
                    <Mic className="w-12 h-12 text-[#4145C7]" />
                  </div>
                </div>
                <div className="absolute -bottom-2.5 bg-[#4145C7] text-amber-300 text-[10px] font-black px-3 py-0.5 rounded-full border border-amber-400">
                  تسبيح ذكي بدون لمس
                </div>
              </div>

              <h3 className="text-2xl font-black text-[#4145C7] mb-2 font-tajawal">
                الميكروفون للتسبيح الصوتي
              </h3>

              <p className="text-sm text-[#77798C] leading-relaxed mb-4">
                لتسبيح الأذكار بصوتك وزيادة العداد تلقائياً. صوتك لا يُسجَّل ولا يُرسَل لأي جهة
              </p>

              <div className="w-full bg-white/80 rounded-2xl p-3 border border-[#E6E6F0]/80 text-right text-xs text-[#77798C] space-y-1 mb-4">
                <div className="flex items-center gap-2 text-[#4145C7] font-bold">
                  <ShieldCheck className="w-4 h-4 text-[#5B5FEF]" />
                  <span>معالجة صوتية فورية داخل جهازك:</span>
                </div>
                <p className="text-[11px] leading-relaxed text-[#77798C] pr-6">
                  التعرف على كلمات التسبيح يتم محلياً 100%. لا يتم حفظ أي ملفات صوتية إطلاقاً.
                </p>
              </div>

              <div className="w-full bg-blue-50/70 rounded-2xl p-2.5 border border-blue-200 text-right text-xs text-blue-900 flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-blue-700 shrink-0" />
                <span className="text-[11px]">
                  <strong>البديل المتاح:</strong> المسبحة اللمسية التفاعلية متوفرة دائماً وتعمل بكفاءة تامة بدون ميكروفون.
                </span>
              </div>
            </div>
          )}

          {/* ─────────────────────────────────────────────────────────────
              SCREEN 4: STORAGE
             ───────────────────────────────────────────────────────────── */}
          {currentStep === 3 && (
            <div className="w-full flex flex-col items-center animate-fade-in">
              <div className="relative mb-5">
                <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-[#72B7E8] via-[#E8B84A] to-[#F7F7FC] p-1 shadow-md flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#F7F7FC] flex items-center justify-center border-2 border-white">
                    <Download className="w-12 h-12 text-[#4145C7]" />
                  </div>
                </div>
                <div className="absolute -bottom-2.5 bg-[#4145C7] text-amber-300 text-[10px] font-black px-3 py-0.5 rounded-full border border-amber-400">
                  الاستماع بدون إنترنت
                </div>
              </div>

              <h3 className="text-2xl font-black text-[#4145C7] mb-2 font-tajawal">
                تخزين الصوتيات (Offline)
              </h3>

              <p className="text-sm text-[#77798C] leading-relaxed mb-4">
                لحفظ تلاوات القرآن الكريم وأصوات الأذان محلياً والاستماع في أي وقت دون اتصال بالإنترنت
              </p>

              <div className="w-full bg-white/80 rounded-2xl p-3 border border-[#E6E6F0]/80 text-right text-xs text-[#77798C] space-y-1 mb-4">
                <div className="flex items-center gap-2 text-[#4145C7] font-bold">
                  <ShieldCheck className="w-4 h-4 text-[#5B5FEF]" />
                  <span>تخزين مخصص للوسائط الدينية:</span>
                </div>
                <p className="text-[11px] leading-relaxed text-[#77798C] pr-6">
                  يقتصر الإذن على تخزين الصوتيات الخاصة بالتطبيق فقط، ولا يصل لأي من ملفاتك الشخصية.
                </p>
              </div>

              <div className="w-full bg-blue-50/70 rounded-2xl p-2.5 border border-blue-200 text-right text-xs text-blue-900 flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-blue-700 shrink-0" />
                <span className="text-[11px]">
                  <strong>البديل المتاح:</strong> يمكنك الاستماع المباشر للتلاوات عبر الإنترنت دون تخزينها محلياً.
                </span>
              </div>
            </div>
          )}

          {/* Feedback & Result Status Banner */}
          {resultStatus.type && (
            <div className={`w-full p-3.5 rounded-2xl border text-right mb-4 animate-fade-in ${
              resultStatus.type === 'success'
                ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-emerald-950'
                : 'bg-[#EEEEFF] border-amber-300 text-amber-950'
            }`}>
              <div className="flex items-start gap-2">
                {resultStatus.type === 'success' ? (
                  <CheckCircle2 className="w-5 h-5 text-[#4CAF82] shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-[#4145C7] shrink-0 mt-0.5" />
                )}
                <div>
                  <h4 className="font-bold text-xs">{resultStatus.message}</h4>
                  {resultStatus.details && (
                    <p className="text-[11px] text-[#77798C] mt-0.5 leading-relaxed">{resultStatus.details}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="w-full space-y-2">
            {/* If permanently denied, show the openAppSettings button */}
            {resultStatus.type === 'permanentlyDenied' ? (
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleOpenSettingsAction}
                  className="w-full py-3.5 px-4 rounded-2xl bg-[#4145C7] hover:bg-[#4145C7] text-white font-black text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Settings className="w-5 h-5 text-amber-300" />
                  <span>{currentStep === 1 ? 'السماح بالإشعارات' : 'فتح إعدادات الجهاز لتفعيل الإذن'}</span>
                </button>

                {currentStep === 0 && (
                  <button
                    type="button"
                    onClick={() => setShowCityPicker(true)}
                    className="w-full py-2.5 px-4 rounded-2xl bg-stone-200/80 hover:bg-stone-300/80 text-[#25263A] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MapPin className="w-4 h-4 text-[#4145C7]" />
                    <span>اختيار المدينة يدوياً فوراً</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={nextStep}
                  className="w-full py-2 px-4 text-xs font-bold text-[#77798C] hover:text-[#25263A] transition-colors"
                >
                  المتابعة بالبديل بدون تفعيل
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={
                    currentStep === 0 ? handleAllowLocation :
                    currentStep === 1 ? handleAllowNotifications :
                    currentStep === 2 ? handleAllowMicrophone :
                    handleAllowStorage
                  }
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] hover:brightness-105 active:scale-98 text-white font-black text-base shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  {isLoading ? (
                    <RefreshCw className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      {currentStep === 0 && <Compass className="w-5 h-5" />}
                      {currentStep === 1 && <Bell className="w-5 h-5" />}
                      {currentStep === 2 && <Mic className="w-5 h-5" />}
                      {currentStep === 3 && <Download className="w-5 h-5" />}
                    </>
                  )}
                  <span>
                    {isLoading 
                      ? 'جاري استدعاء إذن النظام...' 
                      : 'السماح والمتابعة'}
                  </span>
                </button>

                {/* Secondary Alternative Action */}
                {currentStep === 0 ? (
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={() => {
                      savePermissionState('location', 'prompt');
                      setShowCityPicker(true);
                    }}
                    className="w-full py-2.5 px-4 rounded-2xl bg-transparent hover:bg-stone-200/60 text-[#77798C] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MapPin className="w-4 h-4 text-[#77798C]" />
                    <span>تحديد المدينة يدوياً</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={nextStep}
                    className="w-full py-2.5 px-4 rounded-2xl bg-transparent hover:bg-stone-200/60 text-[#77798C] font-bold text-xs transition-colors cursor-pointer"
                  >
                    المتابعة بدون تفعيل
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Dots Indicator */}
          <div className="flex items-center justify-center gap-2 mt-5">
            {[0, 1, 2, 3].map((stepIdx) => (
              <div
                key={stepIdx}
                className={`h-2 rounded-full transition-all duration-300 ${
                  stepIdx === currentStep
                    ? 'w-7 bg-[#5B5FEF]'
                    : stepIdx < currentStep
                    ? 'w-2 bg-[#4145C7]'
                    : 'w-2 bg-stone-300'
                }`}
              />
            ))}
          </div>

        </div>

      </div>

      {/* Device Settings Guidance Modal */}
      {showSettingsGuidance.isOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md" dir="rtl">
          <div className="bg-[#F7F7FC] rounded-3xl p-6 max-w-sm w-full border-2 border-[#E6E6F0] shadow-2xl animate-fade-in text-[#25263A]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-[#4145C7] font-black">
                <Settings className="w-5 h-5 text-[#5B5FEF]" />
                <h4 className="text-base">{showSettingsGuidance.title}</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowSettingsGuidance(s => ({ ...s, isOpen: false }))}
                className="p-1 rounded-full hover:bg-stone-200 text-[#77798C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#77798C] mb-4 leading-relaxed">
              نظراً لأن الإذن تم حظره سابقاً من إعدادات المتصفح أو الجهاز، يتطلب النظام تفعيله يدوياً عبر الخطوات التالية:
            </p>

            <div className="space-y-2 mb-6">
              {showSettingsGuidance.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2.5 bg-white/70 p-2.5 rounded-xl border border-[#E6E6F0]">
                  <span className="w-5 h-5 rounded-full bg-[#4145C7] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <span className="text-xs text-stone-700 leading-relaxed">{step}</span>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setShowSettingsGuidance(s => ({ ...s, isOpen: false }));
                // Re-test permission after user comes back
                if (currentStep === 0) handleAllowLocation();
                else if (currentStep === 1) handleAllowNotifications();
                else if (currentStep === 2) handleAllowMicrophone();
                else handleAllowStorage();
              }}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-black text-xs shadow-md"
            >
              تم تفعيل الإذن - إعادة الفحص الآن
            </button>
          </div>
        </div>
      )}

      {/* Manual City Selection Modal */}
      {showCityPicker && (
        <CitySelectorModal
          isOpen={showCityPicker}
          onClose={() => {
            setShowCityPicker(false);
            nextStep();
          }}
          currentCity={currentCity}
          onSelectCity={(selectedCity) => {
            setCurrentCity(selectedCity);
            try {
              localStorage.setItem('rafiq_current_city', JSON.stringify(selectedCity));
            } catch {
              // Ignored
            }
            setShowCityPicker(false);
            nextStep();
          }}
          onUseGps={handleAllowLocation}
          isLocatingGps={isLoading}
          gpsError={null}
        />
      )}
    </div>
  );
};
