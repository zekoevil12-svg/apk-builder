import React, { useState, useMemo } from 'react';
import {
  ArrowRight,
  Calculator,
  Coins,
  Scale,
  Calendar,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  BookOpen,
} from 'lucide-react';
import { ScreenType } from '../../types';
import { ZakatMawarithSectionSvg } from '../Home/RifqSectionIcons';

interface ZakatMawarithViewProps {
  onBack: () => void;
  onNavigate?: (screen: ScreenType) => void;
}

interface HawlRecord {
  id: string;
  label: string;
  amount: number;
  currency: string;
  startDate: string; // YYYY-MM-DD
  isPaid: boolean;
}

export const ZakatMawarithView: React.FC<ZakatMawarithViewProps> = ({ onBack, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'zakat' | 'fitr_hawl' | 'mawarith'>('zakat');

  // ── 1. Zakat Calculator State ──
  const [currency, setCurrency] = useState<string>('ج.م / ر.س');
  const [gold24Price, setGold24Price] = useState<number>(3600);
  const [silverPrice, setSilverPrice] = useState<number>(45);
  const [nisabStandard, setNisabStandard] = useState<'gold' | 'silver'>('gold');

  // Assets
  const [cashSavings, setCashSavings] = useState<number>(0);
  const [gold24Grams, setGold24Grams] = useState<number>(0);
  const [gold21Grams, setGold21Grams] = useState<number>(0);
  const [gold18Grams, setGold18Grams] = useState<number>(0);
  const [silverGrams, setSilverGrams] = useState<number>(0);
  const [tradeGoodsValue, setTradeGoodsValue] = useState<number>(0);
  const [receivableDebts, setReceivableDebts] = useState<number>(0);
  const [immediateLiabilities, setImmediateLiabilities] = useState<number>(0);

  // ── 2. Zakat Al-Fitr & Hawl Tracker State ──
  const [familyMembersCount, setFamilyMembersCount] = useState<number>(4);
  const [saaCostPerPerson, setSaaCostPerPerson] = useState<number>(50);
  const [hawlRecords, setHawlRecords] = useState<HawlRecord[]>(() => {
    try {
      const raw = localStorage.getItem('rifq_zakat_hawl_records');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [newHawlLabel, setNewHawlLabel] = useState('');
  const [newHawlAmount, setNewHawlAmount] = useState<number>(0);
  const [newHawlStart, setNewHawlStart] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // ── 3. Mawarith (Islamic Inheritance) Calculator State ──
  const [estateTotal, setEstateTotal] = useState<number>(120000);
  const [funeralAndDebts, setFuneralAndDebts] = useState<number>(0);
  const [willAmount, setWillAmount] = useState<number>(0);
  const [deceasedGender, setDeceasedGender] = useState<'male' | 'female'>('male');
  const [hasHusband, setHasHusband] = useState<boolean>(false);
  const [wivesCount, setWivesCount] = useState<number>(1);
  const [hasFather, setHasFather] = useState<boolean>(true);
  const [hasMother, setHasMother] = useState<boolean>(true);
  const [sonsCount, setSonsCount] = useState<number>(2);
  const [daughtersCount, setDaughtersCount] = useState<number>(1);
  const [fullBrothersCount, setFullBrothersCount] = useState<number>(0);
  const [fullSistersCount, setFullSistersCount] = useState<number>(0);

  // ── Zakat Computations ──
  const zakatResult = useMemo(() => {
    const pureGoldGrams =
      gold24Grams + (gold21Grams * 21) / 24 + (gold18Grams * 18) / 24;
    const goldValue = pureGoldGrams * gold24Price;
    const silverValue = silverGrams * silverPrice;

    const totalAssets =
      cashSavings + goldValue + silverValue + tradeGoodsValue + receivableDebts;
    const netZakatable = Math.max(0, totalAssets - immediateLiabilities);

    const goldNisabValue = 85 * gold24Price;
    const silverNisabValue = 595 * silverPrice;
    const activeNisab = nisabStandard === 'gold' ? goldNisabValue : silverNisabValue;

    const reachedNisab = netZakatable >= activeNisab && activeNisab > 0;
    const zakatDue = reachedNisab ? netZakatable * 0.025 : 0;

    return {
      pureGoldGrams,
      goldValue,
      silverValue,
      totalAssets,
      netZakatable,
      goldNisabValue,
      silverNisabValue,
      activeNisab,
      reachedNisab,
      zakatDue,
    };
  }, [
    cashSavings,
    gold24Grams,
    gold21Grams,
    gold18Grams,
    silverGrams,
    tradeGoodsValue,
    receivableDebts,
    immediateLiabilities,
    gold24Price,
    silverPrice,
    nisabStandard,
  ]);

  // ── Hawl Helpers ──
  const addHawlRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHawlLabel.trim() || newHawlAmount <= 0) return;
    const item: HawlRecord = {
      id: `hawl_${Date.now()}`,
      label: newHawlLabel.trim(),
      amount: newHawlAmount,
      currency,
      startDate: newHawlStart,
      isPaid: false,
    };
    const updated = [item, ...hawlRecords];
    setHawlRecords(updated);
    localStorage.setItem('rifq_zakat_hawl_records', JSON.stringify(updated));
    setNewHawlLabel('');
    setNewHawlAmount(0);
  };

  const toggleHawlPaid = (id: string) => {
    const updated = hawlRecords.map((r) =>
      r.id === id ? { ...r, isPaid: !r.isPaid } : r
    );
    setHawlRecords(updated);
    localStorage.setItem('rifq_zakat_hawl_records', JSON.stringify(updated));
  };

  const deleteHawlRecord = (id: string) => {
    const updated = hawlRecords.filter((r) => r.id !== id);
    setHawlRecords(updated);
    localStorage.setItem('rifq_zakat_hawl_records', JSON.stringify(updated));
  };

  // ── Mawarith (Islamic Inheritance) Shariah Engine ──
  const mawarithResult = useMemo(() => {
    const afterDebts = Math.max(0, estateTotal - funeralAndDebts);
    const maxAllowedWill = afterDebts / 3;
    const effectiveWill = Math.min(willAmount, maxAllowedWill);
    const netEstate = Math.max(0, afterDebts - effectiveWill);

    const hasDescendants = sonsCount > 0 || daughtersCount > 0;
    const hasMaleAscendantOrDescendant = sonsCount > 0 || hasFather;
    const siblingsTotal = fullBrothersCount + fullSistersCount;

    interface HeirShare {
      heir: string;
      count: number;
      shareType: string;
      fractionLabel: string;
      amountTotal: number;
      amountPerPerson: number;
      quranRef: string;
    }

    // Calculate fixed shares (الفروض) in 24-base shares
    let spouseShare = 0; // out of 1
    let spouseLabel = '';
    let spouseRef = '';

    if (deceasedGender === 'male' && wivesCount > 0) {
      spouseShare = hasDescendants ? 1 / 8 : 1 / 4;
      spouseLabel = hasDescendants ? 'الثُّمُن (١/٨) لوجود الفرع الوارث' : 'الرُّبُع (١/٤) لعدم الفرع الوارث';
      spouseRef = 'سورة النساء: ١٢';
    } else if (deceasedGender === 'female' && hasHusband) {
      spouseShare = hasDescendants ? 1 / 4 : 1 / 2;
      spouseLabel = hasDescendants ? 'الرُّبُع (١/٤) لوجود الفرع الوارث' : 'النِّصْف (١/٢) لعدم الفرع الوارث';
      spouseRef = 'سورة النساء: ١٢';
    }

    let motherShare = 0;
    let motherLabel = '';
    if (hasMother) {
      if (hasDescendants || siblingsTotal >= 2) {
        motherShare = 1 / 6;
        motherLabel = 'السُّدُس (١/٦) لوجود الفرع الوارث أو جمع من الإخوة';
      } else {
        motherShare = 1 / 3;
        motherLabel = 'الثُّلُث (١/٣) لعدم الفرع الوارث والجمع من الإخوة';
      }
    }

    let fatherFixedShare = 0;
    let fatherLabel = '';
    if (hasFather) {
      if (sonsCount > 0) {
        fatherFixedShare = 1 / 6;
        fatherLabel = 'السُّدُس (١/٦) فرضاً لوجود الابن الذكر';
      } else if (daughtersCount > 0) {
        fatherFixedShare = 1 / 6;
        fatherLabel = 'السُّدُس (١/٦) فرضاً + الباقي تعصيباً';
      } else {
        fatherFixedShare = 0;
        fatherLabel = 'الباقي تعصيباً لعدم الفرع الوارث';
      }
    }

    let daughtersFixedShare = 0;
    let daughtersLabel = '';
    if (sonsCount === 0 && daughtersCount > 0) {
      if (daughtersCount === 1) {
        daughtersFixedShare = 1 / 2;
        daughtersLabel = 'النِّصْف (١/٢) فرضاً لانفرادها وعدم المعصب';
      } else {
        daughtersFixedShare = 2 / 3;
        daughtersLabel = 'الثُّلُثَان (٢/٣) فرضاً لتعددهن وعدم المعصب';
      }
    }

    const totalFixed = spouseShare + motherShare + fatherFixedShare + daughtersFixedShare;
    // Handle Awl (العول) if fixed shares exceed 1
    const awlFactor = totalFixed > 1 ? 1 / totalFixed : 1;

    const shares: HeirShare[] = [];

    if (deceasedGender === 'male' && wivesCount > 0) {
      const amt = netEstate * spouseShare * awlFactor;
      shares.push({
        heir: wivesCount === 1 ? 'الزوجة' : `الزوجات (${wivesCount})`,
        count: wivesCount,
        shareType: 'فرض',
        fractionLabel: spouseLabel,
        amountTotal: amt,
        amountPerPerson: amt / wivesCount,
        quranRef: spouseRef,
      });
    } else if (deceasedGender === 'female' && hasHusband) {
      const amt = netEstate * spouseShare * awlFactor;
      shares.push({
        heir: 'الزوج',
        count: 1,
        shareType: 'فرض',
        fractionLabel: spouseLabel,
        amountTotal: amt,
        amountPerPerson: amt,
        quranRef: spouseRef,
      });
    }

    if (hasMother) {
      const amt = netEstate * motherShare * awlFactor;
      shares.push({
        heir: 'الأم',
        count: 1,
        shareType: 'فرض',
        fractionLabel: motherLabel,
        amountTotal: amt,
        amountPerPerson: amt,
        quranRef: 'سورة النساء: ١١',
      });
    }

    const remainder = Math.max(0, netEstate * (1 - totalFixed * awlFactor));

    if (sonsCount > 0) {
      if (hasFather) {
        const fatherAmt = netEstate * fatherFixedShare * awlFactor;
        shares.push({
          heir: 'الأب',
          count: 1,
          shareType: 'فرض',
          fractionLabel: fatherLabel,
          amountTotal: fatherAmt,
          amountPerPerson: fatherAmt,
          quranRef: 'سورة النساء: ١١',
        });
      }
      const totalUnits = sonsCount * 2 + daughtersCount;
      const unitValue = totalUnits > 0 ? remainder / totalUnits : 0;
      const sonsAmt = unitValue * 2 * sonsCount;
      shares.push({
        heir: `الأبناء الذكور (${sonsCount})`,
        count: sonsCount,
        shareType: 'تعصيب',
        fractionLabel: 'للذكر مثل حظ الأنثيين من الباقي',
        amountTotal: sonsAmt,
        amountPerPerson: sonsAmt / sonsCount,
        quranRef: 'سورة النساء: ١١',
      });
      if (daughtersCount > 0) {
        const dAmt = unitValue * daughtersCount;
        shares.push({
          heir: `البنات (${daughtersCount})`,
          count: daughtersCount,
          shareType: 'تعصيب بالغير',
          fractionLabel: 'للذكر مثل حظ الأنثيين مع الأبناء',
          amountTotal: dAmt,
          amountPerPerson: dAmt / daughtersCount,
          quranRef: 'سورة النساء: ١١',
        });
      }
    } else {
      // No sons
      if (daughtersCount > 0) {
        const dAmt = netEstate * daughtersFixedShare * awlFactor;
        shares.push({
          heir: daughtersCount === 1 ? 'البنت' : `البنات (${daughtersCount})`,
          count: daughtersCount,
          shareType: 'فرض',
          fractionLabel: daughtersLabel,
          amountTotal: dAmt,
          amountPerPerson: dAmt / daughtersCount,
          quranRef: 'سورة النساء: ١١',
        });
      }

      if (hasFather) {
        const fatherAmt = netEstate * fatherFixedShare * awlFactor + remainder;
        shares.push({
          heir: 'الأب',
          count: 1,
          shareType: daughtersCount > 0 ? 'فرض + تعصيب' : 'تعصيب',
          fractionLabel: fatherLabel,
          amountTotal: fatherAmt,
          amountPerPerson: fatherAmt,
          quranRef: 'سورة النساء: ١١',
        });
      } else if (!hasMaleAscendantOrDescendant && siblingsTotal > 0) {
        // Brothers/sisters inherit when neither son nor father exists
        if (fullBrothersCount > 0) {
          const units = fullBrothersCount * 2 + fullSistersCount;
          const uVal = remainder / units;
          const broAmt = uVal * 2 * fullBrothersCount;
          shares.push({
            heir: `الإخوة الأشقاء (${fullBrothersCount})`,
            count: fullBrothersCount,
            shareType: 'تعصيب',
            fractionLabel: 'الباقي تعصيباً (للذكر مثل حظ الأنثيين)',
            amountTotal: broAmt,
            amountPerPerson: broAmt / fullBrothersCount,
            quranRef: 'سورة النساء: ١٧٦',
          });
          if (fullSistersCount > 0) {
            const sisAmt = uVal * fullSistersCount;
            shares.push({
              heir: `الأخوات الشقيقات (${fullSistersCount})`,
              count: fullSistersCount,
              shareType: 'تعصيب بالغير',
              fractionLabel: 'مع الإخوة الأشقاء للذكر مثل حظ الأنثيين',
              amountTotal: sisAmt,
              amountPerPerson: sisAmt / fullSistersCount,
              quranRef: 'سورة النساء: ١٧٦',
            });
          }
        } else if (fullSistersCount > 0) {
          const sisAmt = remainder;
          shares.push({
            heir: `الأخوات الشقيقات (${fullSistersCount})`,
            count: fullSistersCount,
            shareType: daughtersCount > 0 ? 'تعصيب مع الغير' : 'فرض',
            fractionLabel:
              daughtersCount > 0
                ? 'الباقي تعصيباً مع البنات'
                : fullSistersCount === 1
                ? 'النِّصْف فرضاً'
                : 'الثُّلُثَان فرضاً',
            amountTotal: sisAmt,
            amountPerPerson: sisAmt / fullSistersCount,
            quranRef: 'سورة النساء: ١٧٦',
          });
        }
      }
    }

    const blockedNotes: string[] = [];
    if (hasMaleAscendantOrDescendant && siblingsTotal > 0) {
      blockedNotes.push(
        'حُجب الإخوة والأخوات الشقيقات حجباً كاملاً (حجب حرمان) لوجود الأب أو الابن الذكر باتفاق العلماء.'
      );
    }

    return {
      afterDebts,
      effectiveWill,
      willExceeded: willAmount > maxAllowedWill,
      netEstate,
      shares,
      blockedNotes,
    };
  }, [
    estateTotal,
    funeralAndDebts,
    willAmount,
    deceasedGender,
    hasHusband,
    wivesCount,
    hasFather,
    hasMother,
    sonsCount,
    daughtersCount,
    fullBrothersCount,
    fullSistersCount,
  ]);

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 select-none" dir="rtl">
      {/* الشريط العلوي + شريط التنقل السريع بين أقسام الفقه */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-3.5 sticky top-0 z-30 shadow-2xs space-y-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              aria-label="رجوع"
            >
              <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
            </button>
            <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
              <ZakatMawarithSectionSvg size={28} />
            </div>
            <div>
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                حاسبة الزكاة والصدقات والمواريث
              </h1>
              <p className="text-xs text-[#77798C]">
                حساب دقيق لنصاب الزكاة الشرعي وموعد الحول الهجري وقسمة المواريث
              </p>
            </div>
          </div>

          {onNavigate && (
            <div className="hidden md:flex items-center gap-1.5 text-xs font-cairo font-bold">
              <button
                type="button"
                onClick={() => onNavigate('hijri_fasting')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                التقويم والصيام
              </button>
              <button
                type="button"
                onClick={() => onNavigate('hajj_umrah')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                المطوّف الذكي
              </button>
              <button
                type="button"
                onClick={() => onNavigate('ruqyah_medicine')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                الرقية والطب النبوي
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* التبويبات الثلاثة */}
        <div className="grid grid-cols-3 gap-2.5 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('zakat')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'zakat'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            زكاة المال والذهب والتجارة
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('fitr_hawl')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'fitr_hawl'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            زكاة الفطر وسجل الحول
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('mawarith')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'mawarith'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            حاسبة المواريث الشرعية
          </button>
        </div>

        {/* ═════════════════════════════════════════════════════════════════
            ١. حاسبة زكاة المال والذهب والفضة وعروض التجارة
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'zakat' && (
          <div className="space-y-5">
            {/* إعدادات سعر الذهب والفضة والنصاب */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2 border-b border-[#F7F7FC] pb-3">
                <h2 className="font-cairo font-bold text-base text-[#25263A] flex items-center gap-2">
                  <Coins className="w-5 h-5 text-[#5B5FEF]" />
                  <span>١. معيار النصاب الشرعي وأسعار الذهب والفضة اليوم</span>
                </h2>
                <span className="text-xs text-[#4145C7] font-bold">
                  نصاب الذهب: ٨٥ جرام عيار ٢٤ · نصاب الفضة: ٥٩٥ جرام
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    سعر جرام الذهب (عيار ٢٤)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={gold24Price}
                    onChange={(e) => setGold24Price(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold text-[#25263A]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    سعر جرام الفضة الخالصة
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={silverPrice}
                    onChange={(e) => setSilverPrice(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold text-[#25263A]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    حساب النصاب بناءً على
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setNisabStandard('gold')}
                      className={`py-2.5 rounded-xl text-xs font-cairo font-bold border cursor-pointer ${
                        nisabStandard === 'gold'
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      نصاب الذهب (٨٥ج)
                    </button>
                    <button
                      type="button"
                      onClick={() => setNisabStandard('silver')}
                      className={`py-2.5 rounded-xl text-xs font-cairo font-bold border cursor-pointer ${
                        nisabStandard === 'silver'
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      نصاب الفضة (٥٩٥ج)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* إدخال الأموال والأصول الزكوية */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <h2 className="font-cairo font-bold text-base text-[#25263A] border-b border-[#F7F7FC] pb-3">
                ٢. أدخل أموالك وممتلكاتك التي حال عليها الحول
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    النقد والمدخرات البنكية الجاهزة
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={cashSavings || ''}
                    placeholder="0"
                    onChange={(e) => setCashSavings(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    قيمة عروض التجارة والأسهم الاستثمارية
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={tradeGoodsValue || ''}
                    placeholder="0"
                    onChange={(e) => setTradeGoodsValue(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
              </div>

              {/* أوزان الذهب والفضة */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#4145C7] mb-1">
                    ذهب عيار ٢٤ (جرام)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={gold24Grams || ''}
                    placeholder="0"
                    onChange={(e) => setGold24Grams(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#4145C7] mb-1">
                    ذهب عيار ٢١ (جرام)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={gold21Grams || ''}
                    placeholder="0"
                    onChange={(e) => setGold21Grams(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#4145C7] mb-1">
                    ذهب عيار ١٨ (جرام)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={gold18Grams || ''}
                    placeholder="0"
                    onChange={(e) => setGold18Grams(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#77798C] mb-1">
                    فضة خالصة (جرام)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={silverGrams || ''}
                    placeholder="0"
                    onChange={(e) => setSilverGrams(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#4CAF82] mb-1">
                    ديون لك عند الغير مرجوّة السداد (+)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={receivableDebts || ''}
                    placeholder="0"
                    onChange={(e) => setReceivableDebts(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#D95C6A] mb-1">
                    ديون والتزامات حالّة واجبة السداد (-)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={immediateLiabilities || ''}
                    placeholder="0"
                    onChange={(e) => setImmediateLiabilities(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
              </div>
            </div>

            {/* بطاقة النتيجة النهائية للزكاة */}
            <div className="bg-gradient-to-br from-[#25263A] via-[#25263A] to-[#25263A] text-white rounded-3xl p-6 border-2 border-[#5B5FEF] shadow-md space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/15 pb-3">
                <div>
                  <span className="text-xs text-[#E8B84A] font-cairo font-bold">
                    ملخص الوعاء الزكوي (ربع العشر ٢.٥٪)
                  </span>
                  <h3 className="font-cairo font-bold text-xl text-white mt-0.5">
                    صافي المال الخاضع للزكاة:{' '}
                    <span className="font-mono text-[#E8B84A]">
                      {zakatResult.netZakatable.toLocaleString('ar-EG', {
                        maximumFractionDigits: 2,
                      })}
                    </span>
                  </h3>
                </div>
                <div className="text-xs text-amber-100 font-mono">
                  قيمة النصاب المعتمد:{' '}
                  {zakatResult.activeNisab.toLocaleString('ar-EG', {
                    maximumFractionDigits: 0,
                  })}
                </div>
              </div>

              {zakatResult.reachedNisab ? (
                <div className="bg-white/10 rounded-2xl p-4 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-8 h-8 text-emerald-400 shrink-0" />
                    <div>
                      <p className="font-cairo font-bold text-sm text-emerald-300">
                        بلغ المال النصاب الشرعي — تجب فيه الزكاة عند تمام الحول
                      </p>
                      <p className="text-xs text-white/80 mt-0.5">
                        مقدار الزكاة الواجبة (٢.٥٪ من صافي الوعاء الزكوي)
                      </p>
                    </div>
                  </div>
                  <div className="text-2xl font-mono font-bold text-[#E8B84A]">
                    {zakatResult.zakatDue.toLocaleString('ar-EG', {
                      maximumFractionDigits: 2,
                    })}
                  </div>
                </div>
              ) : (
                <div className="bg-white/10 rounded-2xl p-4 border border-white/20 flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-amber-300 shrink-0" />
                  <p className="text-xs sm:text-sm text-amber-100">
                    لم يبلغ صافي المال قيمة النصاب الشرعي المحدد ({zakatResult.activeNisab.toLocaleString('ar-EG')})، فلا تجب فيه الزكاة، ويُستحب التطوع بالصدقة.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            ٢. زكاة الفطر وسجل الحول الهجري
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'fitr_hawl' && (
          <div className="space-y-5">
            {/* حاسبة زكاة الفطر */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <h2 className="font-cairo font-bold text-base text-[#25263A] border-b border-[#F7F7FC] pb-3">
                حاسبة زكاة الفطر (صاعٌ من طعام عن كل مسلم)
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    عدد أفراد الأسرة
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={familyMembersCount}
                    onChange={(e) => setFamilyMembersCount(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    قيمة الفرد الواحد نقداً (أو تكلفة الصاع)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={saaCostPerPerson}
                    onChange={(e) => setSaaCostPerPerson(Math.max(1, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#5B5FEF] text-center">
                  <span className="text-xs text-[#4145C7] font-bold block">
                    المجموع الواجب إخراجه:
                  </span>
                  <span className="font-cairo font-bold text-sm text-[#25263A]">
                    {(familyMembersCount * 2.75).toFixed(1)} كجم قمح/أرز · أو{' '}
                    <strong className="font-mono text-[#4CAF82]">
                      {(familyMembersCount * saaCostPerPerson).toLocaleString('ar-EG')}
                    </strong>
                  </span>
                </div>
              </div>
            </div>

            {/* سجل متابعة الحول الهجري */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <div className="border-b border-[#F7F7FC] pb-3">
                <h2 className="font-cairo font-bold text-base text-[#25263A] flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-[#5B5FEF]" />
                  <span>سجل حساب موعد الحول الهجري (٣٥٤ يوماً قمرياً)</span>
                </h2>
                <p className="text-xs text-[#77798C] mt-0.5">
                  سجّل تاريخ بلوغ مالك النصاب ليحسب التطبيق موعد استحقاق الزكاة بعد مرور حول هجري كامل
                </p>
              </div>

              <form onSubmit={addHawlRecord} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input
                  type="text"
                  value={newHawlLabel}
                  onChange={(e) => setNewHawlLabel(e.target.value)}
                  placeholder="وصف المال (مثال: مدخرات البنك)"
                  className="bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-xs text-[#25263A]"
                />
                <input
                  type="number"
                  min={1}
                  value={newHawlAmount || ''}
                  onChange={(e) => setNewHawlAmount(Math.max(0, Number(e.target.value)))}
                  placeholder="قيمة المبلغ"
                  className="bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-xs font-mono"
                />
                <input
                  type="date"
                  value={newHawlStart}
                  onChange={(e) => setNewHawlStart(e.target.value)}
                  className="bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0] text-xs font-mono"
                />
                <button
                  type="submit"
                  className="py-2.5 px-4 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة للسجل</span>
                </button>
              </form>

              <div className="space-y-2.5">
                {hawlRecords.length === 0 ? (
                  <p className="text-xs text-center text-[#77798C] py-4">
                    لا توجد سجلات حول محفوظة حالياً. أضف مالك لمتابعة موعد حوله الهجري.
                  </p>
                ) : (
                  hawlRecords.map((rec) => {
                    const startMs = new Date(rec.startDate).getTime();
                    const dueMs = startMs + 354 * 24 * 60 * 60 * 1000; // 354 days Hijri year
                    const dueDateStr = new Date(dueMs).toLocaleDateString('ar-EG');
                    const daysRemaining = Math.ceil((dueMs - Date.now()) / (1000 * 60 * 60 * 24));
                    const zakatVal = rec.amount * 0.025;

                    return (
                      <div
                        key={rec.id}
                        className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <h4 className="font-cairo font-bold text-sm text-[#25263A]">
                            {rec.label} —{' '}
                            <span className="font-mono text-[#4145C7]">
                              {rec.amount.toLocaleString('ar-EG')}
                            </span>
                          </h4>
                          <p className="text-xs text-[#77798C] mt-0.5">
                            بداية الحول: {rec.startDate} · موعد إخراج الزكاة: {dueDateStr} · مقدار الزكاة:{' '}
                            <strong className="text-[#4CAF82] font-mono">
                              {zakatVal.toLocaleString('ar-EG')}
                            </strong>
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#4145C7]">
                            {rec.isPaid
                              ? 'تم الإخراج'
                              : daysRemaining <= 0
                              ? 'حالَ الحول الآن'
                              : `متبقي ${daysRemaining} يوم`}
                          </span>
                          <button
                            type="button"
                            onClick={() => toggleHawlPaid(rec.id)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer ${
                              rec.isPaid
                                ? 'bg-[#5B5FEF] text-white'
                                : 'bg-white border border-[#E6E6F0] text-[#25263A]'
                            }`}
                          >
                            {rec.isPaid ? 'مدفوعة ✓' : 'تحديد كمدفوعة'}
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteHawlRecord(rec.id)}
                            className="p-1.5 rounded-xl text-[#D95C6A] hover:bg-[#D95C6A]/10 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            ٣. حاسبة المواريث الشرعية (وفق آيات سورة النساء)
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'mawarith' && (
          <div className="space-y-5">
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <div className="border-b border-[#F7F7FC] pb-3">
                <h2 className="font-cairo font-bold text-base text-[#25263A] flex items-center gap-2">
                  <Scale className="w-5 h-5 text-[#5B5FEF]" />
                  <span>بيانات التركة والورثة الشرعيين</span>
                </h2>
                <p className="text-xs text-[#77798C] mt-0.5">
                  ﴿ يُوصِيكُمُ اللَّهُ فِي أَوْلَادِكُمْ ۖ لِلذَّكَرِ مِثْلُ حَظِّ الْأُنثَيَيْنِ ﴾ [سورة النساء: ١١]
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#25263A] mb-1">
                    إجمالي التركة قبل الديون
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={estateTotal}
                    onChange={(e) => setEstateTotal(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#D95C6A] mb-1">
                    الديون وتكاليف التجهيز
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={funeralAndDebts}
                    onChange={(e) => setFuneralAndDebts(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-cairo font-bold text-[#4145C7] mb-1">
                    الوصية لغير وارث (بحد أقصى الثلث)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={willAmount}
                    onChange={(e) => setWillAmount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3.5 py-2 rounded-xl border border-[#E6E6F0] text-sm font-mono font-bold"
                  />
                </div>
              </div>

              {/* جنس المتوفى والزوج/الزوجة والأبوان */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-bold mb-1">المتوفى</label>
                  <select
                    value={deceasedGender}
                    onChange={(e) => setDeceasedGender(e.target.value as 'male' | 'female')}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-bold"
                  >
                    <option value="male">ذكر (متوفى)</option>
                    <option value="female">أنثى (متوفاة)</option>
                  </select>
                </div>

                {deceasedGender === 'male' ? (
                  <div>
                    <label className="block text-xs font-bold mb-1">عدد الزوجات</label>
                    <input
                      type="number"
                      min={0}
                      max={4}
                      value={wivesCount}
                      onChange={(e) =>
                        setWivesCount(Math.min(4, Math.max(0, Number(e.target.value))))
                      }
                      className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-mono font-bold"
                    />
                  </div>
                ) : (
                  <div className="flex items-center gap-2 pt-5">
                    <input
                      type="checkbox"
                      id="hasHusband"
                      checked={hasHusband}
                      onChange={(e) => setHasHusband(e.target.checked)}
                      className="w-4 h-4 accent-[#E8B84A]"
                    />
                    <label htmlFor="hasHusband" className="text-xs font-bold">
                      الزوج على قيد الحياة
                    </label>
                  </div>
                )}

                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="hasFather"
                    checked={hasFather}
                    onChange={(e) => setHasFather(e.target.checked)}
                    className="w-4 h-4 accent-[#E8B84A]"
                  />
                  <label htmlFor="hasFather" className="text-xs font-bold">
                    الأب حيّ
                  </label>
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <input
                    type="checkbox"
                    id="hasMother"
                    checked={hasMother}
                    onChange={(e) => setHasMother(e.target.checked)}
                    className="w-4 h-4 accent-[#E8B84A]"
                  />
                  <label htmlFor="hasMother" className="text-xs font-bold">
                    الأم حيّة
                  </label>
                </div>
              </div>

              {/* الأبناء والإخوة */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-bold mb-1">عدد الأبناء الذكور</label>
                  <input
                    type="number"
                    min={0}
                    value={sonsCount}
                    onChange={(e) => setSonsCount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">عدد البنات</label>
                  <input
                    type="number"
                    min={0}
                    value={daughtersCount}
                    onChange={(e) => setDaughtersCount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">الإخوة الأشقاء</label>
                  <input
                    type="number"
                    min={0}
                    value={fullBrothersCount}
                    onChange={(e) => setFullBrothersCount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1">الأخوات الشقيقات</label>
                  <input
                    type="number"
                    min={0}
                    value={fullSistersCount}
                    onChange={(e) => setFullSistersCount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-[#F7F7FC] px-3 py-2 rounded-xl border border-[#E6E6F0] text-xs font-mono font-bold"
                  />
                </div>
              </div>
            </div>

            {/* جدول توزيع الأنصبة الشرعية */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2 border-b border-[#F7F7FC] pb-3">
                <h3 className="font-cairo font-bold text-base text-[#25263A]">
                  جدول القسمة الشرعية للتركة
                </h3>
                <span className="text-xs font-mono font-bold text-[#4CAF82]">
                  صافي التركة القابل للقسمة: {mawarithResult.netEstate.toLocaleString('ar-EG')}
                </span>
              </div>

              {mawarithResult.willExceeded && (
                <div className="bg-[#D95C6A]/10 border border-[#D95C6A]/30 rounded-xl p-3 text-xs text-[#D95C6A] font-bold">
                  تنبيه فقهي: تم تخفيض الوصية تلقائياً إلى الثلث ({mawarithResult.effectiveWill.toLocaleString('ar-EG')}) لقوله ﷺ: «الثلث والثلث كثير».
                </div>
              )}

              <div className="space-y-2.5">
                {mawarithResult.shares.map((s) => (
                  <div
                    key={s.heir}
                    className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-cairo font-bold text-sm text-[#25263A]">
                          {s.heir}
                        </span>
                        <span className="text-xs text-[#4145C7] font-bold">
                          · {s.shareType} ({s.fractionLabel})
                        </span>
                      </div>
                      <span className="text-[11px] text-[#77798C]">الدليل: {s.quranRef}</span>
                    </div>
                    <div className="text-left">
                      <div className="font-mono font-bold text-base text-[#4CAF82]">
                        {s.amountTotal.toLocaleString('ar-EG', { maximumFractionDigits: 2 })}
                      </div>
                      {s.count > 1 && (
                        <div className="text-[11px] text-[#77798C] font-mono">
                          نصيب الفرد: {s.amountPerPerson.toLocaleString('ar-EG', { maximumFractionDigits: 2 })}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {mawarithResult.blockedNotes.map((note, idx) => (
                <div
                  key={idx}
                  className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0] text-xs text-[#25263A]"
                >
                  <strong>بيان الحجب الشرعي:</strong> {note}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
