import React, { useState, useMemo } from 'react';
import {
  ArrowRight,
  Calendar,
  Moon,
  Sun,
  CheckCircle2,
  Plus,
  Minus,
  Bell,
  Sparkles,
  Check,
} from 'lucide-react';
import { getHijriDate } from '../../utils/prayerCalculator';
import { ScreenType } from '../../types';
import { HijriFastingSectionSvg } from '../Home/RifqSectionIcons';

interface HijriFastingViewProps {
  onBack: () => void;
  onNavigate?: (screen: ScreenType) => void;
}

const HIJRI_MONTHS = [
  { number: 1, name: 'محرّم', virtue: 'أفضل الصيام بعد رمضان شهر الله المحرم، وفيه يوم عاشوراء (١٠ محرم).' },
  { number: 2, name: 'صفر', virtue: 'يُستحب فيه صيام الأيام البيض والاثنين والخميس كسائر الشهور.' },
  { number: 3, name: 'ربيع الأول', virtue: 'شهر مبارك وُلد فيه النبي ﷺ وبُعث وهاجر، ويُشرع فيه صيام الاثنين والخميس.' },
  { number: 4, name: 'ربيع الآخر', virtue: 'يُشرع فيه المحافظة على صيام ثلاثة أيام من كل شهر.' },
  { number: 5, name: 'جمادى الأولى', virtue: 'اغتنام صيام التطوع والأيام البيض (١٣، ١٤، ١٥).' },
  { number: 6, name: 'جمادى الآخرة', virtue: 'المداومة على نوافل الصيام والاثنين والخميس.' },
  { number: 7, name: 'رجب', virtue: 'من الأشهر الحُرُم الأربعة التي عظّم الله حرمتها.' },
  { number: 8, name: 'شعبان', virtue: 'كان النبي ﷺ يصوم شعبان إلا قليلاً، وترفع فيه الأعمال إلى الله.' },
  { number: 9, name: 'رمضان', virtue: 'شهر الصيام المفروض والقرآن والعتق من النيران وليلة القدر.' },
  { number: 10, name: 'شوّال', virtue: 'من صام رمضان ثم أتبعه ستاً من شوال كان كصيام الدهر.' },
  { number: 11, name: 'ذو القعدة', virtue: 'أول الأشهر الحرم المتوالية ومن أشهر الحج المعلومات.' },
  { number: 12, name: 'ذو الحجة', virtue: 'فيه العشر الأوائل خير أيام الدنيا، وصيام يوم عرفة (٩ ذي الحجة) يكفر سنتين.' },
];

interface IslamicOccasion {
  id: string;
  title: string;
  hijriDateStr: string;
  month: number;
  day: number;
  fastingRule: string;
  hadith: string;
  source: string;
}

const ISLAMIC_OCCASIONS: IslamicOccasion[] = [
  {
    id: 'ashura',
    title: 'تاسوعاء وعاشوراء',
    hijriDateStr: '٩ و ١٠ محرّم',
    month: 1,
    day: 10,
    fastingRule: 'سنة مؤكدة (يكفّر السنة الماضية)',
    hadith: '«صِيَامُ يَوْمِ عَاشُورَاءَ أَحْتَسِبُ عَلَى اللَّهِ أَنْ يُكَفِّرَ السَّنَةَ الَّتِي قَبْلَهُ»',
    source: 'صحيح مسلم',
  },
  {
    id: 'ayyam_beed',
    title: 'الأيام البيض من كل شهر هجري',
    hijriDateStr: '١٣ و ١٤ و ١٥ من كل شهر',
    month: 0,
    day: 13,
    fastingRule: 'سنة نبوية ثابتة (كصيام الدهر)',
    hadith: '«أَوْصَانِي خَلِيلِي ﷺ بِثَلَاثٍ: صِيَامِ ثَلَاثَةِ أَيَّامٍ مِنْ كُلِّ شَهْرٍ، وَرَكْعَتَيِ الضُّحَى، وَأَنْ أُوتِرَ قَبْلَ أَنْ أَنَامَ»',
    source: 'متفق عليه',
  },
  {
    id: 'monday_thursday',
    title: 'صيام يومي الاثنين والخميس',
    hijriDateStr: 'كل أسبوع',
    month: 0,
    day: 0,
    fastingRule: 'سنة مستحبة (تُعرض فيهما الأعمال)',
    hadith: '«تُعْرَضُ الأَعْمَالُ يَوْمَ الاِثْنَيْنِ وَالْخَمِيسِ، فَأُحِبُّ أَنْ يُعْرَضَ عَمَلِي وَأَنَا صَائِمٌ»',
    source: 'جامع الترمذي (صحيح)',
  },
  {
    id: 'ramadan',
    title: 'حلول شهر رمضان المبارك',
    hijriDateStr: '١ رمضان',
    month: 9,
    day: 1,
    fastingRule: 'فرض عين على كل مسلم مكلف',
    hadith: '«مَنْ صَامَ رَمَضَانَ إِيمَانًا وَاحْتِسَابًا غُفِرَ لَهُ مَا تَقَدَّمَ مِنْ ذَنْبِهِ»',
    source: 'متفق عليه',
  },
  {
    id: 'shawwal_six',
    title: 'صيام الست من شوّال',
    hijriDateStr: '٢ — ٣٠ شوّال',
    month: 10,
    day: 2,
    fastingRule: 'سنة مستحبة بعد عيد الفطر',
    hadith: '«مَنْ صَامَ رَمَضَانَ ثُمَّ أَتْبَعَهُ سِتًّا مِنْ شَوَّالٍ، كَانَ كَصِيَامِ الدَّهْرِ»',
    source: 'صحيح مسلم',
  },
  {
    id: 'arafah',
    title: 'يوم عرفة (لغير الحاج)',
    hijriDateStr: '٩ ذو الحجة',
    month: 12,
    day: 9,
    fastingRule: 'سنة مؤكدة (يكفّر سنتين)',
    hadith: '«صِيَامُ يَوْمِ عَرَفَةَ أَحْتَسِبُ عَلَى اللَّهِ أَنْ يُكَفِّرَ السَّنَةَ الَّتِي قَبْلَهُ وَالسَّنَةَ الَّتِي بَعْدَهُ»',
    source: 'صحيح مسلم',
  },
];

interface QadaState {
  totalDaysOwed: number;
  completedDates: string[];
  voluntaryFastDates: string[];
  remindersEnabled: boolean;
}

export const HijriFastingView: React.FC<HijriFastingViewProps> = ({ onBack, onNavigate }) => {
  const todayHijri = useMemo(() => getHijriDate(new Date()), []);
  const todayIso = useMemo(() => new Date().toISOString().split('T')[0], []);

  const [activeTab, setActiveTab] = useState<'calendar' | 'qada' | 'occasions'>('calendar');
  const [selectedMonth, setSelectedMonth] = useState<number>(todayHijri.month || 3);

  const [qadaState, setQadaState] = useState<QadaState>(() => {
    try {
      const raw = localStorage.getItem('rifq_hijri_fasting_state');
      if (raw) return JSON.parse(raw);
    } catch {
      // ignore
    }
    return {
      totalDaysOwed: 5,
      completedDates: [],
      voluntaryFastDates: [],
      remindersEnabled: true,
    };
  });

  const saveQadaState = (next: QadaState) => {
    setQadaState(next);
    localStorage.setItem('rifq_hijri_fasting_state', JSON.stringify(next));
  };

  const remainingQadaDays = Math.max(
    0,
    qadaState.totalDaysOwed - qadaState.completedDates.length
  );

  const isTodayFastedVoluntary = qadaState.voluntaryFastDates.includes(todayIso);

  const toggleTodayVoluntaryFast = () => {
    const exists = qadaState.voluntaryFastDates.includes(todayIso);
    const nextDates = exists
      ? qadaState.voluntaryFastDates.filter((d) => d !== todayIso)
      : [todayIso, ...qadaState.voluntaryFastDates];
    saveQadaState({ ...qadaState, voluntaryFastDates: nextDates });
  };

  const recordOneQadaDayToday = () => {
    if (qadaState.completedDates.length >= qadaState.totalDaysOwed) return;
    const label = `${todayIso} (${todayHijri.formatted})`;
    saveQadaState({
      ...qadaState,
      completedDates: [label, ...qadaState.completedDates],
    });
  };

  const activeMonthMeta =
    HIJRI_MONTHS.find((m) => m.number === selectedMonth) || HIJRI_MONTHS[0];

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 select-none" dir="rtl">
      {/* الشريط العلوي */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-3.5 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              aria-label="رجوع"
            >
              <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
            </button>
            <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
              <HijriFastingSectionSvg size={28} />
            </div>
            <div>
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                التقويم الهجري والمناسبات والصيام
              </h1>
              <p className="text-xs text-[#77798C]">
                مواعيد صيام الأيام البيض وعاشوراء وعرفة وسجل قضاء الأيام الفائتة
              </p>
            </div>
          </div>

          {onNavigate && (
            <div className="hidden md:flex items-center gap-1.5 text-xs font-cairo font-bold">
              <button
                type="button"
                onClick={() => onNavigate('zakat_mawarith')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                الزكاة والمواريث
              </button>
              <button
                type="button"
                onClick={() => onNavigate('hajj_umrah')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                المطوّف الذكي
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* بطاقة التاريخ الهجري اليوم وحالة الصيام */}
        <div className="bg-gradient-to-br from-[#25263A] via-[#25263A] to-[#25263A] text-white rounded-3xl p-5 sm:p-6 border-2 border-[#5B5FEF] shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <span className="text-xs font-cairo font-bold text-[#E8B84A]">
              التاريخ الهجري والميلادي اليوم
            </span>
            <h2 className="font-cairo font-bold text-xl sm:text-2xl text-white">
              {todayHijri.formatted}
            </h2>
            <p className="text-xs text-amber-100/85">
              الموافق: {new Date().toLocaleDateString('ar-EG', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={toggleTodayVoluntaryFast}
              className={`px-4 py-2.5 rounded-2xl font-cairo font-bold text-xs flex items-center gap-2 cursor-pointer transition-all ${
                isTodayFastedVoluntary
                  ? 'bg-[#5B5FEF] text-white border border-[#4CAF82]/40'
                  : 'bg-[#5B5FEF] text-[#25263A] hover:brightness-105'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isTodayFastedVoluntary ? 'صائم اليوم بتوفيق الله ✓' : 'تسجيل صيام اليوم'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                saveQadaState({
                  ...qadaState,
                  remindersEnabled: !qadaState.remindersEnabled,
                })
              }
              className="px-3.5 py-2.5 rounded-2xl bg-white/10 border border-[#E6E6F0] text-xs font-cairo font-bold text-amber-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              <span>
                {qadaState.remindersEnabled ? 'تنبيهات الصيام مفعّلة' : 'تفعيل تنبيهات الصيام'}
              </span>
            </button>
          </div>
        </div>

        {/* التبويبات */}
        <div className="grid grid-cols-3 gap-2.5 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('calendar')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'calendar'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            التقويم والأيام البيض
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('qada')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'qada'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            سجل القضاء والصيام ({remainingQadaDays})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('occasions')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'occasions'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            مواسم الصيام والمناسبات
          </button>
        </div>

        {/* ── ١. التقويم الهجري والأيام البيض ── */}
        {activeTab === 'calendar' && (
          <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-5">
            {/* اختيار الشهر الهجري */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {HIJRI_MONTHS.map((m) => (
                <button
                  key={m.number}
                  type="button"
                  onClick={() => setSelectedMonth(m.number)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold whitespace-nowrap border cursor-pointer ${
                    selectedMonth === m.number
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  {m.number}. {m.name}
                </button>
              ))}
            </div>

            <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="font-cairo font-bold text-base text-[#25263A]">
                  شهر {activeMonthMeta.name} — {todayHijri.year} هـ
                </h3>
                <p className="text-xs text-[#77798C] mt-0.5">{activeMonthMeta.virtue}</p>
              </div>
              <span className="text-xs font-cairo font-bold text-[#4CAF82]">
                الأيام البيض: ١٣ · ١٤ · ١٥ {activeMonthMeta.name}
              </span>
            </div>

            {/* شبكة أيام الشهر الهجري (1 إلى 30) مع تمييز الأيام البيض وعاشوراء وعرفة */}
            <div className="grid grid-cols-5 sm:grid-cols-6 gap-2.5">
              {Array.from({ length: 30 }, (_, idx) => idx + 1).map((dayNum) => {
                const isWhiteDay = dayNum === 13 || dayNum === 14 || dayNum === 15;
                const isToday =
                  selectedMonth === todayHijri.month && dayNum === todayHijri.day;
                const isAshura = selectedMonth === 1 && (dayNum === 9 || dayNum === 10);
                const isArafah = selectedMonth === 12 && dayNum === 9;

                return (
                  <div
                    key={dayNum}
                    className={`p-3 rounded-2xl border text-center transition-all ${
                      isToday
                        ? 'bg-[#25263A] text-[#E8B84A] border-[#5B5FEF] ring-2 ring-[#5B5FEF]/40'
                        : isWhiteDay || isAshura || isArafah
                        ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-[#4145C7]'
                        : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A]'
                    }`}
                  >
                    <div className="font-mono font-bold text-base">{dayNum}</div>
                    <div className="text-[10px] font-cairo font-bold mt-0.5">
                      {isToday
                        ? 'اليوم'
                        : isArafah
                        ? 'يوم عرفة'
                        : isAshura
                        ? dayNum === 10
                          ? 'عاشوراء'
                          : 'تاسوعاء'
                        : isWhiteDay
                        ? 'يوم أبيض'
                        : activeMonthMeta.name}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── ٢. سجل قضاء الأيام الفائتة من رمضان ── */}
        {activeTab === 'qada' && (
          <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F7F7FC] pb-4">
              <div>
                <h2 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                  سجل قضاء الأيام الفائتة من رمضان
                </h2>
                <p className="text-xs text-[#77798C]">
                  حدد إجمالي الأيام التي عليك قضاؤها وسجّل كل يوم تقضيه ليُحفظ في جهازك
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#25263A]">إجمالي أيام القضاء:</span>
                <button
                  type="button"
                  onClick={() =>
                    saveQadaState({
                      ...qadaState,
                      totalDaysOwed: Math.max(0, qadaState.totalDaysOwed - 1),
                    })
                  }
                  className="w-8 h-8 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-mono font-bold text-base">
                  {qadaState.totalDaysOwed}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    saveQadaState({
                      ...qadaState,
                      totalDaysOwed: qadaState.totalDaysOwed + 1,
                    })
                  }
                  className="w-8 h-8 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0]">
                <span className="text-xs text-[#77798C] block">إجمالي الأيام</span>
                <span className="font-mono font-bold text-xl text-[#25263A]">
                  {qadaState.totalDaysOwed}
                </span>
              </div>
              <div className="bg-[#4CAF82]/12 p-4 rounded-2xl border border-[#4CAF82]/30">
                <span className="text-xs text-[#4CAF82] font-bold block">تم قضاؤه</span>
                <span className="font-mono font-bold text-xl text-[#4CAF82]">
                  {qadaState.completedDates.length}
                </span>
              </div>
              <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#5B5FEF]">
                <span className="text-xs text-[#4145C7] font-bold block">المتبقي عليك</span>
                <span className="font-mono font-bold text-xl text-[#D95C6A]">
                  {remainingQadaDays}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between flex-wrap gap-3 bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0]">
              <p className="text-xs font-cairo font-bold text-[#25263A]">
                هل أتممت صيام يوم قضاء؟ سجّله الآن ليُخصم من الأيام المتبقية:
              </p>
              <button
                type="button"
                onClick={recordOneQadaDayToday}
                disabled={remainingQadaDays === 0}
                className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer disabled:opacity-40"
              >
                + تسجيل إتمام يوم قضاء
              </button>
            </div>

            {qadaState.completedDates.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-cairo font-bold text-[#77798C]">
                  سجل أيام القضاء المنجزة:
                </h4>
                <div className="space-y-1.5">
                  {qadaState.completedDates.map((dateStr, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between px-3.5 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs"
                    >
                      <span className="font-bold text-[#4CAF82]">
                        ✓ اليوم رقم {i + 1} — {dateStr}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          saveQadaState({
                            ...qadaState,
                            completedDates: qadaState.completedDates.filter(
                              (_, idx) => idx !== i
                            ),
                          })
                        }
                        className="text-[#D95C6A] text-[11px] hover:underline cursor-pointer"
                      >
                        حذف
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── ٣. مواسم الصيام والمناسبات الإسلامية بالدليل الصحيح ── */}
        {activeTab === 'occasions' && (
          <div className="space-y-3.5">
            {ISLAMIC_OCCASIONS.map((occ) => (
              <div
                key={occ.id}
                className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-2.5"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="font-cairo font-bold text-base text-[#25263A]">
                    {occ.title}
                  </h3>
                  <span className="text-xs font-cairo font-bold text-[#4145C7]">
                    الموعد: {occ.hijriDateStr} · {occ.fastingRule}
                  </span>
                </div>
                <p className="font-amiri text-lg text-[#25263A] bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0] leading-relaxed">
                  {occ.hadith}
                </p>
                <div className="text-xs text-[#77798C]">
                  المصدر: <strong className="text-[#4CAF82]">{occ.source}</strong>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
