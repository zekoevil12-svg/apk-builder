import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  FiqhMuyassarCategoryId,
  FiqhMuyassarTopic,
} from '../../data/fiqhMuyassarData';
import {
  initFiqhMuyassarSqliteTables,
  loadFiqhMuyassarCategoriesFromStorage,
  loadFiqhTopicsByCategoryFromStorage,
  loadFiqhMuyassarTopicsFromStorage,
  loadFiqhMuyassarFavorites,
  toggleFiqhMuyassarFavorite,
  searchFiqhMuyassarInStorage,
  getDailyFiqhTopicFromStorage,
} from '../../utils/fiqhMuyassarSqlite';

interface FiqhMuyassarViewProps {
  onBack: () => void;
  initialTopicId?: string | null;
  initialCategoryId?: FiqhMuyassarCategoryId | null;
}

type FiqhSubScreen = 'home' | 'category' | 'detail' | 'search' | 'favorites';

/**
 * أيقونة قسم «الفقه الميسر»: ميزان العدالة + كتاب الفقه المفتوح (SVG ذهبي فخم بدون إيموجي)
 */
export const FiqhScaleBookSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 38,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <defs>
      <linearGradient id="fiqhGoldGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#E8B84A" />
        <stop offset="50%" stopColor="#E8B84A" />
        <stop offset="100%" stopColor="#4145C7" />
      </linearGradient>
    </defs>
    <circle cx="24" cy="24" r="22" fill="#F7F7FC" stroke="url(#fiqhGoldGrad)" strokeWidth="2" />
    {/* عمود الميزان والعارضة العلوية */}
    <path d="M24 8V29" stroke="url(#fiqhGoldGrad)" strokeWidth="2.2" strokeLinecap="round" />
    <circle cx="24" cy="8" r="2" fill="#4CAF82" />
    <path d="M12 13H36" stroke="url(#fiqhGoldGrad)" strokeWidth="2" strokeLinecap="round" />
    {/* كفتا الميزان */}
    <path d="M12 13L9 21H15L12 13Z" stroke="#5B5FEF" strokeWidth="1.5" strokeLinejoin="round" />
    <path d="M8.5 21C8.5 22.8 10 24 12 24C14 24 15.5 22.8 15.5 21H8.5Z" fill="url(#fiqhGoldGrad)" />
    <path d="M36 13L33 21H39L36 13Z" stroke="#5B5FEF" strokeWidth="1.5" strokeLinejoin="round" />
    <path d="M32.5 21C32.5 22.8 34 24 36 24C38 24 39.5 22.8 39.5 21H32.5Z" fill="url(#fiqhGoldGrad)" />
    {/* الكتاب المفتوح أسفل الميزان */}
    <path
      d="M12 30C12 28.9 12.9 28 14 28H22C23.1 28 24 28.9 24 30V39C24 38.2 23.2 37.5 22 37.5H13.5C12.7 37.5 12 36.8 12 36V30Z"
      fill="#FFFFFF"
      stroke="url(#fiqhGoldGrad)"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    <path
      d="M36 30C36 28.9 35.1 28 34 28H26C24.9 28 24 28.9 24 30V39C24 38.2 24.8 37.5 26 37.5H34.5C35.3 37.5 36 36.8 36 36V30Z"
      fill="#FFFFFF"
      stroke="url(#fiqhGoldGrad)"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    <path d="M15 32.5H21M27 32.5H33" stroke="#4CAF82" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

/**
 * أيقونات SVG مخصصة بمقاس (48×48) للتصنيفات الفقهية الثمانية بدون أي إيموجي
 */
export const FiqhCategorySvg48: React.FC<{
  categoryId: FiqhMuyassarCategoryId;
  size?: number;
}> = ({ categoryId, size = 48 }) => {
  const gold = '#E8B84A';
  const lightGold = '#E8B84A';
  const green = '#4CAF82';
  const beige = '#F7F7FC';

  switch (categoryId) {
    case 'tahara':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* قطرة ماء طهور وإبريق وضوء */}
          <path
            d="M24 11C24 11 15 21.5 15 28C15 32.97 19.03 37 24 37C28.97 37 33 32.97 33 28C33 21.5 24 11 24 11Z"
            fill={lightGold}
            fillOpacity="0.22"
            stroke={gold}
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <path d="M20 29C20 31.5 21.8 33.2 24 33.2" stroke={green} strokeWidth="2" strokeLinecap="round" />
          <circle cx="24" cy="23" r="2" fill={green} />
        </svg>
      );
    case 'salah':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* محراب وقبة مسجد ومئذنة */}
          <path d="M12 36H36" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
          <path
            d="M16 36V24C16 19.2 19.6 15.5 24 15.5C28.4 15.5 32 19.2 32 24V36"
            fill={lightGold}
            fillOpacity="0.2"
            stroke={gold}
            strokeWidth="2.2"
          />
          <path d="M24 11V15.5" stroke={green} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M20.5 36V27.5C20.5 25.5 22 24 24 24C26 24 27.5 25.5 27.5 27.5V36" stroke={green} strokeWidth="1.9" />
        </svg>
      );
    case 'zakah':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* دنانير ذهبية وسنبلة نماء وبركة */}
          <circle cx="20" cy="27" r="7.5" fill={lightGold} fillOpacity="0.28" stroke={gold} strokeWidth="2" />
          <circle cx="29" cy="21" r="6.5" fill="#FFFFFF" stroke={gold} strokeWidth="2" />
          <path d="M29 18.5V23.5M26.5 21H31.5" stroke={green} strokeWidth="1.8" strokeLinecap="round" />
          <path d="M14 35C18 33 26 33 34 35" stroke={green} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'siyam':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* هلال الصيام وفانوس رمضان */}
          <path
            d="M29.5 14.5C25.2 14.5 21.8 18 21.8 22.3C21.8 26.6 25.2 30.1 29.5 30.1C31.2 30.1 32.7 29.5 34 28.6C32.3 32.5 28.4 35.2 23.9 35.2C17.8 35.2 12.8 30.2 12.8 24.1C12.8 18 17.8 13 23.9 13C26 13 27.9 13.5 29.5 14.5Z"
            fill={lightGold}
            fillOpacity="0.28"
            stroke={gold}
            strokeWidth="2.1"
            strokeLinejoin="round"
          />
          <circle cx="31" cy="19" r="2.2" fill={green} />
        </svg>
      );
    case 'hajj':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* الكعبة المشرفة وحزامها الذهبي بدون لون بني في الأيقونة */}
          <rect x="14" y="14" width="20" height="21" rx="2.5" fill="#FFFFFF" stroke={gold} strokeWidth="2.2" />
          <path d="M14 20.5H34" stroke={lightGold} strokeWidth="2.8" />
          <rect x="25" y="25" width="4.5" height="7" rx="1" fill={green} />
          <path d="M11 35H37" stroke={green} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'nikah':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* حلقتان متداخلتان رمز الميثاق الغليظ والمودة */}
          <circle cx="20" cy="25" r="7.5" fill={lightGold} fillOpacity="0.2" stroke={gold} strokeWidth="2.2" />
          <circle cx="28" cy="25" r="7.5" fill={lightGold} fillOpacity="0.2" stroke={green} strokeWidth="2.2" />
          <path d="M24 13L26 15.5L24 18L22 15.5L24 13Z" fill={gold} />
        </svg>
      );
    case 'muamalat':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* ميزان المعاملات والعقود المالية */}
          <path d="M24 12V34M17 34H31" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M13 18H35" stroke={gold} strokeWidth="2" strokeLinecap="round" />
          <path d="M13 18L10 25H16L13 18Z" fill={lightGold} fillOpacity="0.3" stroke={green} strokeWidth="1.6" />
          <path d="M35 18L32 25H38L35 18Z" fill={lightGold} fillOpacity="0.3" stroke={green} strokeWidth="1.6" />
        </svg>
      );
    case 'atima':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* صحفة الطعام الطيب وغطاؤها الإسلامي */}
          <path d="M11 30H37" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
          <path
            d="M14 30C14 23.9 18.5 19 24 19C29.5 19 34 23.9 34 30"
            fill={lightGold}
            fillOpacity="0.25"
            stroke={gold}
            strokeWidth="2.1"
          />
          <circle cx="24" cy="16.5" r="2" fill={green} />
          <path d="M16 30L18 35H30L32 30" stroke={green} strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );
  }
};

export const FiqhMuyassarView: React.FC<FiqhMuyassarViewProps> = ({
  onBack,
  initialTopicId = null,
  initialCategoryId = null,
}) => {
  const [subScreen, setSubScreen] = useState<FiqhSubScreen>('home');
  const [previousScreen, setPreviousScreen] = useState<FiqhSubScreen>('home');
  const [categories, setCategories] = useState(() => loadFiqhMuyassarCategoriesFromStorage());
  const [allTopics, setAllTopics] = useState<FiqhMuyassarTopic[]>(() => loadFiqhMuyassarTopicsFromStorage());
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadFiqhMuyassarFavorites());

  const [selectedCategoryId, setSelectedCategoryId] = useState<FiqhMuyassarCategoryId>(
    initialCategoryId || 'tahara'
  );
  const [selectedSubtopic, setSelectedSubtopic] = useState<string>('all');
  const [selectedTopicId, setSelectedTopicId] = useState<string>(
    initialTopicId || 'tahara-1'
  );

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchCategoryFilter, setSearchCategoryFilter] = useState<FiqhMuyassarCategoryId | 'all'>('all');
  const [searchRulingFilter, setSearchRulingFilter] = useState<string>('all');

  // Detail expandable sections state
  const [openExplanation, setOpenExplanation] = useState(true);
  const [openConditions, setOpenConditions] = useState(true);
  const [openEvidence, setOpenEvidence] = useState(true);
  const [openMasail, setOpenMasail] = useState(true);
  const [openReference, setOpenReference] = useState(true);

  // Font scale & dark mode
  const [fontScale, setFontScale] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_fiqh_font_scale');
    return saved ? parseFloat(saved) : 1;
  });
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('rifq_fiqh_dark_mode') === '1';
  });

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2600);
  }, []);

  useEffect(() => {
    initFiqhMuyassarSqliteTables();
    setCategories(loadFiqhMuyassarCategoriesFromStorage());
    setAllTopics(loadFiqhMuyassarTopicsFromStorage());
    setFavoriteIds(loadFiqhMuyassarFavorites());
  }, []);

  useEffect(() => {
    if (initialTopicId) {
      setSelectedTopicId(initialTopicId);
      setSubScreen('detail');
    } else if (initialCategoryId) {
      setSelectedCategoryId(initialCategoryId);
      setSubScreen('category');
    }
  }, [initialTopicId, initialCategoryId]);

  const dailyTopic = useMemo(() => getDailyFiqhTopicFromStorage(), [allTopics]);

  const selectedCategory = useMemo(
    () => categories.find((c) => c.id === selectedCategoryId) || categories[0],
    [categories, selectedCategoryId]
  );

  const categoryTopics = useMemo(() => {
    const items = loadFiqhTopicsByCategoryFromStorage(selectedCategoryId);
    if (selectedSubtopic === 'all') return items;
    return items.filter((t) => t.subtopic === selectedSubtopic);
  }, [selectedCategoryId, selectedSubtopic, allTopics, favoriteIds]);

  const selectedTopic = useMemo(
    () => allTopics.find((t) => t.id === selectedTopicId) || allTopics[0],
    [allTopics, selectedTopicId]
  );

  const searchResults = useMemo(
    () => searchFiqhMuyassarInStorage(searchQuery, searchCategoryFilter, searchRulingFilter),
    [searchQuery, searchCategoryFilter, searchRulingFilter, allTopics, favoriteIds]
  );

  const favoriteTopics = useMemo(
    () => allTopics.filter((t) => favoriteIds.includes(t.id)),
    [allTopics, favoriteIds]
  );

  const handleToggleFavorite = useCallback(
    (topicId: string, e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      const result = toggleFiqhMuyassarFavorite(topicId);
      setFavoriteIds(result.favorites);
      setAllTopics(loadFiqhMuyassarTopicsFromStorage());
      showToast(result.isFavorite ? 'تم حفظ المسألة الفقهية في المفضلة' : 'تمت إزالة المسألة من المفضلة');
    },
    [showToast]
  );

  const formatTopicShareText = (topic: FiqhMuyassarTopic) => {
    const quranLine = topic.quranEvidence
      ? `\n• الدليل من القرآن: ${topic.quranEvidence.ayah} [${topic.quranEvidence.surahAndNumber}]`
      : '';
    return [
      `【الفقه الميسر | تطبيق رِفْق】`,
      `الباب: ${topic.subtopic} — ${topic.title}`,
      `الحكم الشرعي: ${topic.rulingBadge}`,
      ``,
      `• الخلاصة الفقهية:`,
      topic.summary,
      ``,
      `• البيان والتفصيل:`,
      topic.definitionAndExplanation,
      quranLine,
      `• الدليل من السنة: ${topic.sunnahEvidence.hadith}`,
      `(${topic.sunnahEvidence.source})`,
      ``,
      `• المرجع الفقهي: ${topic.fiqhReference}`,
    ]
      .filter(Boolean)
      .join('\n');
  };

  const handleCopyTopic = useCallback(
    async (topic: FiqhMuyassarTopic, e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      const text = formatTopicShareText(topic);
      try {
        await navigator.clipboard.writeText(text);
        showToast('تم نسخ المسألة والحكم الفقهي مع الدليل والمصدر');
      } catch {
        showToast('تم تجهيز النص للنسخ');
      }
    },
    [showToast]
  );

  const handleShareTopic = useCallback(
    async (topic: FiqhMuyassarTopic, e?: React.MouseEvent) => {
      if (e) e.stopPropagation();
      const text = formatTopicShareText(topic);
      if (navigator.share) {
        try {
          await navigator.share({
            title: `الفقه الميسر: ${topic.title}`,
            text,
          });
          return;
        } catch {
          // user cancelled or fallback to copy
        }
      }
      await handleCopyTopic(topic);
    },
    [handleCopyTopic]
  );

  const cycleFontScale = () => {
    const next = fontScale >= 1.3 ? 0.9 : Number((fontScale + 0.1).toFixed(1));
    setFontScale(next);
    localStorage.setItem('rifq_fiqh_font_scale', String(next));
    showToast(`حجم الخط: ${Math.round(next * 100)}%`);
  };

  const toggleDarkMode = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    localStorage.setItem('rifq_fiqh_dark_mode', next ? '1' : '0');
  };

  const openCategoryScreen = (catId: FiqhMuyassarCategoryId) => {
    setSelectedCategoryId(catId);
    setSelectedSubtopic('all');
    setPreviousScreen('home');
    setSubScreen('category');
  };

  const openDetailScreen = (topic: FiqhMuyassarTopic, from: FiqhSubScreen) => {
    setSelectedTopicId(topic.id);
    setPreviousScreen(from);
    setSubScreen('detail');
  };

  const handleHeaderBack = () => {
    if (subScreen === 'home') {
      onBack();
    } else if (subScreen === 'detail') {
      setSubScreen(previousScreen === 'detail' ? 'category' : previousScreen);
    } else {
      setSubScreen('home');
    }
  };

  // Theme colors matching Rifq identity (#E8B84A, #F7F7FC, #25263A, #77798C, #4CAF82)
  const bgMain = isDarkMode ? 'bg-[#25263A]' : 'bg-[#F7F7FC]';
  const bgCard = isDarkMode ? 'bg-[#25263A]' : 'bg-[#FFFFFF]';
  const bgSubtle = isDarkMode ? 'bg-[#25263A]' : 'bg-[#F7F7FC]';
  const textPrimary = isDarkMode ? 'text-[#F7F7FC]' : 'text-[#25263A]';
  const textSecondary = isDarkMode ? 'text-[#BDB3A7]' : 'text-[#77798C]';
  const borderGold = isDarkMode ? 'border-[#E6E6F0]' : 'border-[#5B5FEF]';

  return (
    <div
      dir="rtl"
      className={`min-h-screen pb-28 transition-colors duration-200 font-cairo ${bgMain} ${textPrimary}`}
    >
      {/* الشريط العلوي الموحد */}
      <header
        className={`sticky top-0 z-30 border-b ${borderGold} ${
          isDarkMode ? 'bg-[#25263A]/95' : 'bg-[#F7F7FC]/95'
        } backdrop-blur-md px-4 py-3 shadow-sm`}
      >
        <div className="max-w-3xl mx-auto flex items-center justify-between gap-2">
          {/* يمين: رجوع + العنوان */}
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              type="button"
              onClick={handleHeaderBack}
              aria-label="رجوع"
              className={`w-10 h-10 rounded-xl border ${borderGold} ${bgCard} flex items-center justify-center transition-transform active:scale-95 cursor-pointer shrink-0`}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M9 18L15 12L9 6"
                  stroke="#5B5FEF"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
            <FiqhScaleBookSvg size={34} className="shrink-0" />
            <div className="truncate">
              <h1 className="font-cairo font-bold text-[18px] sm:text-[20px] text-[#5B5FEF] leading-tight truncate">
                {subScreen === 'home' && 'الفقه الميسر'}
                {subScreen === 'category' && `فقه ${selectedCategory.name}`}
                {subScreen === 'detail' && selectedTopic.subtopic}
                {subScreen === 'search' && 'البحث في الفقه الميسر'}
                {subScreen === 'favorites' && 'المفضلة الفقهية'}
              </h1>
              <p className={`text-[11px] ${textSecondary} truncate`}>
                {subScreen === 'home' && 'أحكام الفقه الإسلامي موثقة بالدليل من الكتاب والسنة'}
                {subScreen === 'category' && `${categoryTopics.length} مسألة وحكم موثق`}
                {subScreen === 'detail' && selectedTopic.title}
                {subScreen === 'search' && 'بحث فوري في الأبواب والمسائل والأدلة'}
                {subScreen === 'favorites' && `${favoriteTopics.length} مسألة محفوظة`}
              </p>
            </div>
          </div>

          {/* يسار: بحث + مفضلة + حجم الخط + الوضع الليلي */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setSubScreen(subScreen === 'search' ? 'home' : 'search')}
              aria-label="بحث"
              className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
                subScreen === 'search'
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                  : `${bgCard} ${borderGold} text-[#5B5FEF]`
              }`}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <circle
                  cx="11"
                  cy="11"
                  r="7"
                  stroke="currentColor"
                  strokeWidth="2.2"
                />
                <path
                  d="M20 20L16.35 16.35"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            <button
              type="button"
              onClick={() => setSubScreen(subScreen === 'favorites' ? 'home' : 'favorites')}
              aria-label="المفضلة"
              className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
                subScreen === 'favorites'
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                  : `${bgCard} ${borderGold} text-[#5B5FEF]`
              }`}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                  stroke="currentColor"
                  strokeWidth="2"
                  fill={favoriteIds.length > 0 && subScreen !== 'favorites' ? '#E8B84A' : 'none'}
                />
              </svg>
            </button>

            <button
              type="button"
              onClick={cycleFontScale}
              aria-label="تكبير الخط"
              className={`w-9 h-9 rounded-xl border ${borderGold} ${bgCard} flex items-center justify-center text-[#5B5FEF] font-bold text-[12px] cursor-pointer`}
            >
              ع+
            </button>

            <button
              type="button"
              onClick={toggleDarkMode}
              aria-label="الوضع الليلي"
              className={`w-9 h-9 rounded-xl border ${borderGold} ${bgCard} flex items-center justify-center text-[#5B5FEF] cursor-pointer`}
            >
              {isDarkMode ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="5" stroke="#5B5FEF" strokeWidth="2" />
                  <path
                    d="M12 2V4M12 20V22M4.93 4.93L6.34 6.34M17.66 17.66L19.07 19.07M2 12H4M20 12H22M4.93 19.07L6.34 17.66M17.66 6.34L19.07 4.93"
                    stroke="#5B5FEF"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"
                    stroke="#5B5FEF"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* إشعار النسخ والحفظ */}
      {toastMessage && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-2xl shadow-lg border border-[#5B5FEF] text-[13px] font-bold flex items-center gap-2">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#5B5FEF" strokeWidth="2" />
            <path d="M8 12.5L10.8 15.3L16 9.5" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span>{toastMessage}</span>
        </div>
      )}

      <main className="max-w-3xl mx-auto px-4 pt-4 space-y-5">
        {/* ==================== الشاشة 1: الرئيسية ==================== */}
        {subScreen === 'home' && (
          <>
            {/* البطاقة الترحيبية الملكية */}
            <section
              className={`rounded-2xl border ${borderGold} ${bgCard} p-5 shadow-sm relative overflow-hidden`}
            >
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0 shadow-inner">
                  <FiqhScaleBookSvg size={44} />
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="font-cairo font-bold text-[19px] text-[#5B5FEF]">
                    موسوعة الفقه الميسر في ضوء الكتاب والسنة
                  </h2>
                  <p
                    className="font-amiri text-[18px] text-[#4CAF82] mt-1 leading-relaxed"
                    style={{ fontSize: `${18 * fontScale}px` }}
                  >
                    قَالَ رَسُولُ اللَّهِ ﷺ: «مَنْ يُرِدِ اللَّهُ بِهِ خَيْرًا يُفَقِّهْهُ فِي الدِّينِ»
                  </p>
                  <p className={`text-[12px] ${textSecondary} mt-1`}>
                    متفق عليه: صحيح البخاري (71)، وصحيح مسلم (1037) عن معاوية بن أبي سفيان رضي الله عنهما
                  </p>
                </div>
              </div>

              {/* إحصاء حقيقي للأبواب والمسائل الموثقة */}
              <div className={`mt-4 pt-3.5 border-t border-[#E6E6F0] grid grid-cols-3 gap-2 text-center`}>
                <div className={`rounded-xl ${bgSubtle} py-2 px-3`}>
                  <div className="font-bold text-[17px] text-[#5B5FEF]">{categories.length}</div>
                  <div className={`text-[11px] ${textSecondary}`}>أبواب فقهية كبرى</div>
                </div>
                <div className={`rounded-xl ${bgSubtle} py-2 px-3`}>
                  <div className="font-bold text-[17px] text-[#4CAF82]">{allTopics.length}</div>
                  <div className={`text-[11px] ${textSecondary}`}>مسألة وحكم بالدليل</div>
                </div>
                <div className={`rounded-xl ${bgSubtle} py-2 px-3`}>
                  <div className="font-bold text-[17px] text-[#5B5FEF]">{favoriteIds.length}</div>
                  <div className={`text-[11px] ${textSecondary}`}>في مفضلتك الفقهية</div>
                </div>
              </div>
            </section>

            {/* بطاقة مسألة اليوم الفقهية */}
            {dailyTopic && (
              <section
                className={`rounded-2xl border-2 border-[#5B5FEF] ${bgCard} p-5 shadow-sm space-y-3`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#4CAF82]" />
                    <span className="font-bold text-[14px] text-[#5B5FEF]">
                      مسألة اليوم الفقهية • {dailyTopic.subtopic}
                    </span>
                  </div>
                  <span className="text-[12px] font-bold text-[#4CAF82]">
                    الحكم: {dailyTopic.rulingBadge}
                  </span>
                </div>

                <h3
                  className="font-bold text-[17px] leading-snug"
                  style={{ fontSize: `${17 * fontScale}px` }}
                >
                  {dailyTopic.title}
                </h3>

                <p
                  className={`${textSecondary} text-[14px] leading-relaxed`}
                  style={{ fontSize: `${14 * fontScale}px` }}
                >
                  {dailyTopic.summary}
                </p>

                <div className={`rounded-xl ${bgSubtle} p-3.5 border border-[#E6E6F0]`}>
                  <p
                    className="font-amiri text-[17px] leading-loose text-[#4CAF82]"
                    style={{ fontSize: `${17 * fontScale}px` }}
                  >
                    {dailyTopic.quranEvidence
                      ? `${dailyTopic.quranEvidence.ayah} (${dailyTopic.quranEvidence.surahAndNumber})`
                      : dailyTopic.sunnahEvidence.hadith}
                  </p>
                  <p className={`text-[11px] ${textSecondary} mt-1`}>
                    المصدر: {dailyTopic.fiqhReference}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-1 gap-2">
                  <button
                    type="button"
                    onClick={() => openDetailScreen(dailyTopic, 'home')}
                    className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-bold text-[13px] hover:bg-[#4145C7] transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <span>قراءة التفصيل والأدلة</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => handleCopyTopic(dailyTopic, e)}
                      aria-label="نسخ المسألة"
                      className={`w-9 h-9 rounded-xl border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#5B5FEF] cursor-pointer`}
                    >
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                        <rect x="9" y="9" width="11" height="11" rx="2" stroke="currentColor" strokeWidth="2" />
                        <path d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5" stroke="currentColor" strokeWidth="2" />
                      </svg>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleShareTopic(dailyTopic, e)}
                      aria-label="مشاركة المسألة"
                      className={`w-9 h-9 rounded-xl border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#4CAF82] cursor-pointer`}
                    >
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                        <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2" />
                        <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
                        <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2" />
                        <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="currentColor" strokeWidth="2" />
                      </svg>
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleToggleFavorite(dailyTopic.id, e)}
                      aria-label="حفظ في المفضلة"
                      className={`w-9 h-9 rounded-xl border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#5B5FEF] cursor-pointer`}
                    >
                      <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                        <path
                          d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                          stroke="currentColor"
                          strokeWidth="2"
                          fill={favoriteIds.includes(dailyTopic.id) ? '#E8B84A' : 'none'}
                        />
                      </svg>
                    </button>
                  </div>
                </div>
              </section>
            )}

            {/* شبكة التصنيفات الفقهية الثمانية (2 عمود) */}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="font-bold text-[17px] text-[#5B5FEF]">
                  أبواب الفقه الميسر (8 أبواب معتمدة)
                </h2>
                <button
                  type="button"
                  onClick={() => setSubScreen('search')}
                  className="text-[13px] font-bold text-[#4CAF82] hover:underline cursor-pointer"
                >
                  تصفح جميع المسائل ({allTopics.length})
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {categories.map((cat) => {
                  const count = allTopics.filter((t) => t.categoryId === cat.id).length;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => openCategoryScreen(cat.id)}
                      className={`text-right rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer flex flex-col justify-between gap-3`}
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="shrink-0">
                          <FiqhCategorySvg48 categoryId={cat.id} size={48} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="font-bold text-[16px] text-[#5B5FEF]">
                              كتاب {cat.name}
                            </h3>
                            <span className={`text-[12px] font-bold text-[#4CAF82]`}>
                              {count} مسائل
                            </span>
                          </div>
                          <p className={`text-[12px] ${textSecondary} mt-1 line-clamp-2 leading-relaxed`}>
                            {cat.subtitle}
                          </p>
                        </div>
                      </div>

                      {/* عرض المباحث الفرعية للباب */}
                      <div className={`pt-2.5 border-t border-[#E6E6F0] flex flex-wrap gap-1.5`}>
                        {cat.subtopics.map((sub) => (
                          <span
                            key={sub}
                            className={`text-[11px] ${bgSubtle} ${textPrimary} px-2 py-0.5 rounded-lg border border-[#E6E6F0]`}
                          >
                            {sub}
                          </span>
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          </>
        )}

        {/* ==================== الشاشة 2: قائمة مسائل الباب الفقهي ==================== */}
        {subScreen === 'category' && (
          <section className="space-y-4">
            {/* بطاقة تعريف الباب الفقهي */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm`}>
              <div className="flex items-center gap-3.5">
                <FiqhCategorySvg48 categoryId={selectedCategory.id} size={52} />
                <div className="flex-1 min-w-0">
                  <h2 className="font-bold text-[18px] text-[#5B5FEF]">
                    كتاب {selectedCategory.name}
                  </h2>
                  <p className={`text-[13px] ${textSecondary} mt-0.5 leading-relaxed`}>
                    {selectedCategory.description}
                  </p>
                </div>
              </div>

              {/* تصفية بالمباحث الفرعية داخل الباب */}
              <div className="mt-4 pt-3 border-t border-[#E6E6F0] flex items-center gap-2 overflow-x-auto pb-1">
                <button
                  type="button"
                  onClick={() => setSelectedSubtopic('all')}
                  className={`px-3 py-1.5 rounded-xl text-[12px] font-bold shrink-0 border transition-colors cursor-pointer ${
                    selectedSubtopic === 'all'
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : `${bgSubtle} ${textPrimary} border-[#E6E6F0]`
                  }`}
                >
                  جميع المباحث ({loadFiqhTopicsByCategoryFromStorage(selectedCategory.id).length})
                </button>
                {selectedCategory.subtopics.map((sub) => (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSelectedSubtopic(sub)}
                    className={`px-3 py-1.5 rounded-xl text-[12px] font-bold shrink-0 border transition-colors cursor-pointer ${
                      selectedSubtopic === sub
                        ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                        : `${bgSubtle} ${textPrimary} border-[#E6E6F0]`
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* قائمة بطاقات المسائل الفقهية */}
            <div className="space-y-3.5">
              {categoryTopics.map((topic, index) => {
                const isFav = favoriteIds.includes(topic.id);
                return (
                  <div
                    key={topic.id}
                    onClick={() => openDetailScreen(topic, 'category')}
                    className={`rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm hover:shadow-md transition-all cursor-pointer space-y-3`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-7 h-7 rounded-lg bg-[#F7F7FC] border border-[#5B5FEF] text-[#25263A] font-bold text-[12px] flex items-center justify-center">
                          {index + 1}
                        </span>
                        <span className="text-[12px] font-bold text-[#5B5FEF]">
                          مبحث: {topic.subtopic}
                        </span>
                      </div>
                      <span className="text-[12px] font-bold text-[#4CAF82]">
                        الحكم: {topic.rulingBadge}
                      </span>
                    </div>

                    <h3
                      className="font-bold text-[16px] leading-snug"
                      style={{ fontSize: `${16 * fontScale}px` }}
                    >
                      {topic.title}
                    </h3>

                    <p
                      className={`text-[13.5px] ${textSecondary} leading-relaxed`}
                      style={{ fontSize: `${13.5 * fontScale}px` }}
                    >
                      {topic.summary}
                    </p>

                    {/* الدليل المختصر */}
                    <div className={`rounded-xl ${bgSubtle} p-3 border border-[#E6E6F0]`}>
                      <p
                        className="font-amiri text-[16px] text-[#4CAF82] leading-relaxed"
                        style={{ fontSize: `${16 * fontScale}px` }}
                      >
                        {topic.quranEvidence
                          ? `${topic.quranEvidence.ayah} (${topic.quranEvidence.surahAndNumber})`
                          : topic.sunnahEvidence.hadith}
                      </p>
                      <p className={`text-[11px] ${textSecondary} mt-1`}>
                        المصدر: {topic.fiqhReference}
                      </p>
                    </div>

                    {/* شريط أزرار البطاقة */}
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[12px] font-bold text-[#5B5FEF] flex items-center gap-1">
                        <span>عرض الشروط والأدلة والمسائل</span>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                          <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={(e) => handleCopyTopic(topic, e)}
                          aria-label="نسخ"
                          className={`w-8 h-8 rounded-lg border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#5B5FEF] cursor-pointer`}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                            <rect x="9" y="9" width="11" height="11" rx="2" stroke="currentColor" strokeWidth="2" />
                            <path d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5" stroke="currentColor" strokeWidth="2" />
                          </svg>
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleShareTopic(topic, e)}
                          aria-label="مشاركة"
                          className={`w-8 h-8 rounded-lg border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#4CAF82] cursor-pointer`}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                            <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2" />
                            <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
                            <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2" />
                            <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="currentColor" strokeWidth="2" />
                          </svg>
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleToggleFavorite(topic.id, e)}
                          aria-label="مفضلة"
                          className={`w-8 h-8 rounded-lg border ${borderGold} ${bgSubtle} flex items-center justify-center text-[#5B5FEF] cursor-pointer`}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                            <path
                              d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                              stroke="currentColor"
                              strokeWidth="2"
                              fill={isFav ? '#E8B84A' : 'none'}
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* ==================== الشاشة 3: تفاصيل المسألة الفقهية ==================== */}
        {subScreen === 'detail' && selectedTopic && (
          <section className="space-y-4">
            {/* البطاقة الرئيسية لعنوان المسألة والحكم */}
            <div className={`rounded-2xl border-2 border-[#5B5FEF] ${bgCard} p-5 shadow-sm space-y-3`}>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[13px] font-bold text-[#5B5FEF]">
                  كتاب {categories.find((c) => c.id === selectedTopic.categoryId)?.name} • مبحث {selectedTopic.subtopic}
                </span>
                <span className="text-[13px] font-bold text-[#4CAF82]">
                  الحكم الشرعي: {selectedTopic.rulingBadge}
                </span>
              </div>

              <h2
                className="font-bold text-[20px] leading-snug"
                style={{ fontSize: `${20 * fontScale}px` }}
              >
                {selectedTopic.title}
              </h2>

              <div className={`rounded-xl ${bgSubtle} p-3.5 border border-[#E6E6F0]`}>
                <div className="text-[12px] font-bold text-[#5B5FEF] mb-1">الخلاصة الفقهية الجامعة:</div>
                <p
                  className="text-[15px] leading-relaxed font-semibold"
                  style={{ fontSize: `${15 * fontScale}px` }}
                >
                  {selectedTopic.summary}
                </p>
              </div>
            </div>

            {/* 1. البيان والتأصيل الفقهي الميسر */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenExplanation(!openExplanation)}
                className="w-full px-4 py-3.5 flex items-center justify-between text-right cursor-pointer"
              >
                <span className="font-bold text-[15px] text-[#5B5FEF]">
                  1. البيان والتأصيل الفقهي الميسر
                </span>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className={`transition-transform ${openExplanation ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9L12 15L18 9" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {openExplanation && (
                <div className="px-4 pb-4 pt-1 border-t border-[#E6E6F0]">
                  <p
                    className="text-[15px] leading-loose"
                    style={{ fontSize: `${15 * fontScale}px` }}
                  >
                    {selectedTopic.definitionAndExplanation}
                  </p>
                </div>
              )}
            </div>

            {/* 2. الشروط والأركان والضوابط الشرعية */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenConditions(!openConditions)}
                className="w-full px-4 py-3.5 flex items-center justify-between text-right cursor-pointer"
              >
                <span className="font-bold text-[15px] text-[#5B5FEF]">
                  2. الشروط والأركان والضوابط الشرعية ({selectedTopic.conditionsAndPillars.length})
                </span>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className={`transition-transform ${openConditions ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9L12 15L18 9" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {openConditions && (
                <div className="px-4 pb-4 pt-2 border-t border-[#E6E6F0] space-y-2.5">
                  {selectedTopic.conditionsAndPillars.map((cond, idx) => (
                    <div key={idx} className="flex items-start gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#5B5FEF] text-white font-bold text-[12px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p
                        className="text-[14.5px] leading-relaxed flex-1"
                        style={{ fontSize: `${14.5 * fontScale}px` }}
                      >
                        {cond}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 3. الأدلة الشرعية من الكتاب والسنة */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenEvidence(!openEvidence)}
                className="w-full px-4 py-3.5 flex items-center justify-between text-right cursor-pointer"
              >
                <span className="font-bold text-[15px] text-[#5B5FEF]">
                  3. الأدلة الشرعية من القرآن الكريم والسنة النبوية
                </span>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className={`transition-transform ${openEvidence ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9L12 15L18 9" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {openEvidence && (
                <div className="px-4 pb-4 pt-2 border-t border-[#E6E6F0] space-y-3">
                  {selectedTopic.quranEvidence && (
                    <div className={`rounded-xl ${bgSubtle} p-3.5 border border-[#E6E6F0]`}>
                      <div className="text-[12px] font-bold text-[#5B5FEF] mb-1">
                        من القرآن الكريم:
                      </div>
                      <p
                        className="font-amiri text-[19px] leading-loose text-[#4CAF82]"
                        style={{ fontSize: `${19 * fontScale}px` }}
                      >
                        {selectedTopic.quranEvidence.ayah}
                      </p>
                      <div className={`text-[12px] ${textSecondary} mt-1`}>
                        [{selectedTopic.quranEvidence.surahAndNumber}]
                      </div>
                    </div>
                  )}

                  <div className={`rounded-xl ${bgSubtle} p-3.5 border border-[#E6E6F0]`}>
                    <div className="text-[12px] font-bold text-[#5B5FEF] mb-1">
                      من السنة النبوية الصحيحة:
                    </div>
                    <p
                      className="font-amiri text-[18px] leading-loose"
                      style={{ fontSize: `${18 * fontScale}px` }}
                    >
                      {selectedTopic.sunnahEvidence.hadith}
                    </p>
                    <div className="text-[12px] font-bold text-[#4CAF82] mt-1.5">
                      التخريج: {selectedTopic.sunnahEvidence.source}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 4. مسائل وتنبيهات فقهية مهمة */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenMasail(!openMasail)}
                className="w-full px-4 py-3.5 flex items-center justify-between text-right cursor-pointer"
              >
                <span className="font-bold text-[15px] text-[#5B5FEF]">
                  4. مسائل وتنبيهات فقهية مهمة ({selectedTopic.importantMasail.length})
                </span>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className={`transition-transform ${openMasail ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9L12 15L18 9" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {openMasail && (
                <div className="px-4 pb-4 pt-2 border-t border-[#E6E6F0] space-y-2.5">
                  {selectedTopic.importantMasail.map((masala, idx) => (
                    <div key={idx} className="flex items-start gap-2.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#5B5FEF] shrink-0 mt-2" />
                      <p
                        className="text-[14.5px] leading-relaxed flex-1"
                        style={{ fontSize: `${14.5 * fontScale}px` }}
                      >
                        {masala}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 5. المصدر والتوثيق الفقهي المعتمد */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenReference(!openReference)}
                className="w-full px-4 py-3.5 flex items-center justify-between text-right cursor-pointer"
              >
                <span className="font-bold text-[15px] text-[#5B5FEF]">
                  5. المصدر والتوثيق الفقهي المعتمد
                </span>
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className={`transition-transform ${openReference ? 'rotate-180' : ''}`}
                >
                  <path d="M6 9L12 15L18 9" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {openReference && (
                <div className="px-4 pb-4 pt-2 border-t border-[#E6E6F0]">
                  <p className="text-[14px] font-bold text-[#4CAF82]">
                    {selectedTopic.fiqhReference}
                  </p>
                </div>
              )}
            </div>

            {/* شريط الأدوات السفلي للمسألة */}
            <div className={`rounded-2xl border ${borderGold} ${bgCard} p-3.5 flex items-center justify-around gap-2 shadow-sm`}>
              <button
                type="button"
                onClick={() => handleCopyTopic(selectedTopic)}
                className="flex flex-col items-center gap-1 text-[12px] font-bold text-[#5B5FEF] cursor-pointer"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <rect x="9" y="9" width="11" height="11" rx="2" stroke="currentColor" strokeWidth="2" />
                  <path d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5" stroke="currentColor" strokeWidth="2" />
                </svg>
                <span>نسخ المسألة</span>
              </button>

              <button
                type="button"
                onClick={() => handleShareTopic(selectedTopic)}
                className="flex flex-col items-center gap-1 text-[12px] font-bold text-[#4CAF82] cursor-pointer"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2" />
                  <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
                  <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2" />
                  <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="currentColor" strokeWidth="2" />
                </svg>
                <span>مشاركة</span>
              </button>

              <button
                type="button"
                onClick={() => handleToggleFavorite(selectedTopic.id)}
                className="flex flex-col items-center gap-1 text-[12px] font-bold text-[#5B5FEF] cursor-pointer"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill={favoriteIds.includes(selectedTopic.id) ? '#E8B84A' : 'none'}
                  />
                </svg>
                <span>{favoriteIds.includes(selectedTopic.id) ? 'في المفضلة' : 'حفظ للمفضلة'}</span>
              </button>

              <button
                type="button"
                onClick={cycleFontScale}
                className="flex flex-col items-center gap-1 text-[12px] font-bold text-[#25263A] dark:text-[#F7F7FC] cursor-pointer"
              >
                <span className="text-[16px] font-bold text-[#5B5FEF]">ع+</span>
                <span>حجم الخط</span>
              </button>
            </div>
          </section>
        )}

        {/* ==================== الشاشة 4: البحث الفوري ==================== */}
        {subScreen === 'search' && (
          <section className="space-y-4">
            <div className={`rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm space-y-3`}>
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث في المسائل، الشروط، الأدلة، أو الأحكام الفقهية..."
                  className={`w-full rounded-xl border ${borderGold} ${bgSubtle} pr-10 pl-10 py-3 text-[14px] focus:outline-none focus:ring-2 focus:ring-[#5B5FEF]`}
                />
                <svg
                  width="18"
                  height="18"
                  viewBox="0 0 24 24"
                  fill="none"
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#5B5FEF]"
                >
                  <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                  <path d="M20 20L16.35 16.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-[#77798C] hover:text-[#25263A] cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* فلتر الأبواب الفقهية */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                <button
                  type="button"
                  onClick={() => setSearchCategoryFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-[12px] font-bold shrink-0 border cursor-pointer ${
                    searchCategoryFilter === 'all'
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : `${bgSubtle} ${textPrimary} border-[#E6E6F0]`
                  }`}
                >
                  كل الأبواب
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSearchCategoryFilter(cat.id)}
                    className={`px-3 py-1.5 rounded-xl text-[12px] font-bold shrink-0 border cursor-pointer ${
                      searchCategoryFilter === cat.id
                        ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                        : `${bgSubtle} ${textPrimary} border-[#E6E6F0]`
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="text-[13px] font-bold text-[#5B5FEF]">
              نتائج البحث ({searchResults.length} مسألة موثقة)
            </div>

            <div className="space-y-3">
              {searchResults.map((topic) => (
                <div
                  key={topic.id}
                  onClick={() => openDetailScreen(topic, 'search')}
                  className={`rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm hover:shadow-md transition-all cursor-pointer space-y-2`}
                >
                  <div className="flex items-center justify-between text-[12px] font-bold">
                    <span className="text-[#5B5FEF]">
                      كتاب {categories.find((c) => c.id === topic.categoryId)?.name} • {topic.subtopic}
                    </span>
                    <span className="text-[#4CAF82]">{topic.rulingBadge}</span>
                  </div>
                  <h3 className="font-bold text-[16px]">{topic.title}</h3>
                  <p className={`text-[13px] ${textSecondary} line-clamp-2`}>{topic.summary}</p>
                  <div className={`text-[11px] ${textSecondary}`}>المصدر: {topic.fiqhReference}</div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ==================== الشاشة 5: المفضلة الفقهية ==================== */}
        {subScreen === 'favorites' && (
          <section className="space-y-3.5">
            {favoriteTopics.length === 0 ? (
              <div className={`rounded-2xl border ${borderGold} ${bgCard} p-8 text-center space-y-3`}>
                <div className="w-16 h-16 mx-auto rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                  <FiqhScaleBookSvg size={38} />
                </div>
                <h3 className="font-bold text-[17px] text-[#5B5FEF]">
                  لا توجد مسائل محفوظة في المفضلة بعد
                </h3>
                <p className={`text-[13px] ${textSecondary} max-w-md mx-auto`}>
                  يمكنك حفظ أي مسألة أو حكم فقهي بالضغط على أيقونة القلب للرجوع إليها في أي وقت بدون إنترنت.
                </p>
                <button
                  type="button"
                  onClick={() => setSubScreen('home')}
                  className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-bold text-[13px] cursor-pointer"
                >
                  استعراض أبواب الفقه الميسر
                </button>
              </div>
            ) : (
              favoriteTopics.map((topic) => (
                <div
                  key={topic.id}
                  onClick={() => openDetailScreen(topic, 'favorites')}
                  className={`rounded-2xl border ${borderGold} ${bgCard} p-4 shadow-sm hover:shadow-md transition-all cursor-pointer space-y-2.5`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-[#5B5FEF]">
                      كتاب {categories.find((c) => c.id === topic.categoryId)?.name} • {topic.subtopic}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => handleToggleFavorite(topic.id, e)}
                      className="text-[12px] font-bold text-[#D95C6A] hover:underline cursor-pointer"
                    >
                      إزالة من المفضلة
                    </button>
                  </div>
                  <h3 className="font-bold text-[16px]">{topic.title}</h3>
                  <p className={`text-[13px] ${textSecondary}`}>{topic.summary}</p>
                  <div className={`text-[11px] text-[#4CAF82] font-bold`}>{topic.fiqhReference}</div>
                </div>
              ))
            )}
          </section>
        )}
      </main>
    </div>
  );
};
