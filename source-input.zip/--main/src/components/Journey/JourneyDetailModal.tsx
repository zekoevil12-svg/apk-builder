import React, { useState, useMemo } from 'react';
import {
  X,
  Check,
  Lock,
  Sparkles,
  Calendar,
  Award,
  Layers,
  Target,
  Flame,
  ExternalLink,
  RotateCcw,
  Play,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { ScreenType, WardType } from '../../types';
import {
  ComputedJourneySummary,
  ComputedDayStatus,
  ComputedTaskItem,
  startOrSelectJourney,
  toggleJourneyDayTask,
  resetJourneyEnrollment,
} from '../../utils/myJourneyService';
import { JourneySectionSvg } from '../Home/RifqSectionIcons';

interface JourneyDetailModalProps {
  journey: ComputedJourneySummary;
  onClose: () => void;
  onRefresh: () => void;
  onNavigate: (screen: ScreenType) => void;
  onSelectWard?: (ward: WardType) => void;
  onShowToast: (msg: string) => void;
}

export const JourneyDetailModal: React.FC<JourneyDetailModalProps> = ({
  journey,
  onClose,
  onRefresh,
  onNavigate,
  onSelectWard,
  onShowToast,
}) => {
  const [selectedDayNum, setSelectedDayNum] = useState<number>(journey.currentDayNumber || 1);
  const [confirmReset, setConfirmReset] = useState(false);

  const selectedDay: ComputedDayStatus = useMemo(() => {
    return (
      journey.days.find((d) => d.dayNumber === selectedDayNum) ||
      journey.todayDayStatus ||
      journey.days[0]
    );
  }, [journey, selectedDayNum]);

  const handleStartOrResume = () => {
    const wasEnrolled = journey.isEnrolled;
    startOrSelectJourney(journey.definition.id);
    onRefresh();
    if (!wasEnrolled) {
      setSelectedDayNum(1);
      onShowToast(`تم بدء «${journey.definition.title}» بنجاح! بارك الله في خطواتك 🌱`);
    } else {
      setSelectedDayNum(journey.currentDayNumber);
      onShowToast(`تم تحديد «${journey.definition.title}» كرحلتك الحالية النشطة`);
    }
  };

  const handleResetJourney = () => {
    resetJourneyEnrollment(journey.definition.id);
    setConfirmReset(false);
    setSelectedDayNum(1);
    onRefresh();
    onShowToast('تمت إعادة ضبط الرحلة للبدء من اليوم الأول');
  };

  const handleToggleTask = (task: ComputedTaskItem) => {
    if (!journey.isEnrolled) {
      onShowToast('اضغط على «ابدأ الرحلة» أولاً لتفعيل مهام الأيام');
      return;
    }
    if (selectedDay.dayNumber > journey.maxUnlockedDayNumber) {
      onShowToast('لا يمكن تسجيل أيام مستقبلية كمكتملة قبل حلول يومها الفعلي 🔒');
      return;
    }

    const res = toggleJourneyDayTask(
      journey.definition.id,
      selectedDay.dayNumber,
      task.id
    );
    if (!res.success && res.message) {
      onShowToast(res.message);
      return;
    }
    onRefresh();
    if (!task.isCompleted) {
      onShowToast(`تقبل الله طاعتك: تم إنجاز «${task.title}» ✓`);
    }
  };

  const handleOpenLinkedSection = (task: ComputedTaskItem) => {
    if (task.linkedWard && onSelectWard) {
      onClose();
      onSelectWard(task.linkedWard);
      return;
    }
    if (task.linkedScreen) {
      onClose();
      onNavigate(task.linkedScreen);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in"
      dir="rtl"
    >
      <div className="bg-[#F7F7FC] w-full max-w-2xl max-h-[92vh] rounded-t-3xl sm:rounded-3xl border border-[#E6E6F0] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-br from-[#FFFFFF] via-[#F7F7FC] to-[#EEEEFF] p-5 border-b border-[#E6E6F0] flex items-start justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs flex items-center justify-center text-2xl shrink-0">
              <span>{journey.definition.iconEmoji}</span>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#EEEEFF] text-[#5B5FEF] border border-[#5B5FEF]/20">
                  {journey.statusLabelAr}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white text-[#77798C] border border-[#E6E6F0]">
                  {journey.definition.difficultyLabel}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-[#25263A] mt-1">
                {journey.definition.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#77798C] hover:text-[#25263A] flex items-center justify-center transition-colors cursor-pointer shrink-0"
            aria-label="إغلاق"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-5 flex-1">
          {/* Description & Goal Card */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs space-y-3">
            <p className="text-xs sm:text-sm text-[#25263A] leading-relaxed">
              {journey.definition.description}
            </p>
            <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0] flex items-start gap-2.5">
              <Target className="w-4 h-4 text-[#5B5FEF] shrink-0 mt-0.5" />
              <div>
                <span className="text-[11px] font-black text-[#5B5FEF] block">
                  الهدف من الرحلة:
                </span>
                <p className="text-xs font-bold text-[#25263A] mt-0.5">
                  {journey.definition.goalText}
                </p>
              </div>
            </div>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
              <div className="bg-[#F7F7FC] rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                <span className="text-[11px] text-[#77798C] block">المدة الكلية</span>
                <span className="text-sm font-black text-[#25263A]">
                  {journey.definition.durationDays} يومًا
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                <span className="text-[11px] text-[#77798C] block">عدد المراحل</span>
                <span className="text-sm font-black text-[#5B5FEF]">
                  {journey.definition.stages.length} مراحل
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                <span className="text-[11px] text-[#77798C] block">الأيام المكتملة</span>
                <span className="text-sm font-black text-[#2E9E6B]">
                  {journey.completedDaysCount} من {journey.definition.durationDays}
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                <span className="text-[11px] text-[#77798C] block">الأيام المتبقية</span>
                <span className="text-sm font-black text-[#E8B84A]">
                  {journey.remainingDaysCount} يومًا
                </span>
              </div>
            </div>

            {/* Progress Bar & Current Stage */}
            <div className="pt-2 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#25263A]">
                  المرحلة الحالية ({journey.currentStage.stageNumber}/{journey.definition.stages.length}):{' '}
                  <span className="text-[#5B5FEF] font-black">{journey.currentStage.title}</span>
                </span>
                <span className="font-black text-[#5B5FEF]">{journey.progressPercent}%</span>
              </div>
              <div className="w-full h-3 bg-[#EFEFF9] rounded-full overflow-hidden border border-[#E6E6F0]">
                <div
                  className="h-full bg-gradient-to-l from-[#5B5FEF] to-[#72B7E8] rounded-full transition-all duration-500"
                  style={{ width: `${journey.progressPercent}%` }}
                />
              </div>
            </div>

            {/* Action Buttons: Start / Continue / Set Active */}
            <div className="pt-2 flex items-center gap-2.5 flex-wrap">
              {!journey.isEnrolled ? (
                <button
                  type="button"
                  onClick={handleStartOrResume}
                  className="flex-1 py-3 px-5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-sm shadow-md transition-all active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>ابدأ الرحلة الآن</span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      startOrSelectJourney(journey.definition.id);
                      setSelectedDayNum(journey.currentDayNumber);
                      onRefresh();
                      onShowToast(`أنت الآن في اليوم ${journey.currentDayNumber} من الرحلة 🌱`);
                    }}
                    className="flex-1 py-3 px-5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-sm shadow-md transition-all active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>
                      {journey.isActivePrimary
                        ? `متابعة الرحلة (اليوم ${journey.currentDayNumber})`
                        : 'متابعة الرحلة وجعلها الرئيسية'}
                    </span>
                  </button>

                  {!confirmReset ? (
                    <button
                      type="button"
                      onClick={() => setConfirmReset(true)}
                      className="py-3 px-3.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EFEFF9] text-[#77798C] hover:text-[#D95C6A] border border-[#E6E6F0] text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                      title="إعادة بدء الرحلة من اليوم الأول"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>إعادة البدء</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 bg-[#FFF5F6] border border-[#D95C6A]/30 rounded-xl p-1.5">
                      <span className="text-[11px] font-bold text-[#D95C6A] px-2">تأكيد الإعادة؟</span>
                      <button
                        type="button"
                        onClick={handleResetJourney}
                        className="px-2.5 py-1 rounded-lg bg-[#D95C6A] text-white text-[11px] font-black cursor-pointer"
                      >
                        نعم
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmReset(false)}
                        className="px-2.5 py-1 rounded-lg bg-white text-[#77798C] text-[11px] font-bold border border-[#E6E6F0] cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Stages Overview */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs space-y-3">
            <h3 className="text-sm font-black text-[#25263A] flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#5B5FEF]" />
              <span>مراحل الرحلة ({journey.definition.stages.length} مراحل)</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {journey.definition.stages.map((st) => {
                const isCurrentStage = journey.currentStage.stageNumber === st.stageNumber && journey.isEnrolled;
                const stageDays = journey.days.filter(
                  (d) => d.dayNumber >= st.startDay && d.dayNumber <= st.endDay
                );
                const stageCompletedDays = stageDays.filter((d) => d.state === 'completed').length;
                const isStageDone =
                  stageDays.length > 0 && stageCompletedDays === stageDays.length;

                return (
                  <div
                    key={st.stageNumber}
                    className={`rounded-xl p-3 border transition-all ${
                      isCurrentStage
                        ? 'bg-[#EEEEFF]/60 border-[#5B5FEF]'
                        : isStageDone
                        ? 'bg-[#EEFBF4] border-[#2E9E6B]/40'
                        : 'bg-[#F7F7FC] border-[#E6E6F0]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-black text-[#25263A] flex items-center gap-1.5">
                        <span>{st.badgeIcon}</span>
                        <span>
                          المرحلة {st.stageNumber}: {st.title}
                        </span>
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white border border-[#E6E6F0] text-[#77798C] shrink-0">
                        أيام {st.startDay}–{st.endDay}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#77798C] mt-1 leading-relaxed">
                      {st.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Days Map (خريطة الأيام) */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3 className="text-sm font-black text-[#25263A] flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#5B5FEF]" />
                <span>خريطة أيام الرحلة (اضغط على اليوم لعرض مهامه)</span>
              </h3>
              <div className="flex items-center gap-2 text-[10px] font-bold text-[#77798C]">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#2E9E6B] inline-block" /> مكتمل
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#5B5FEF] inline-block" /> اليوم الحالي
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#E6E6F0] inline-block" /> قادم مقفل
                </span>
              </div>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-10 gap-2">
              {journey.days.map((d) => {
                const isSelected = d.dayNumber === selectedDay.dayNumber;
                const isCurrent = d.dayNumber === journey.currentDayNumber && journey.isEnrolled;
                const isLocked = d.state === 'locked';
                const isCompleted = d.state === 'completed';
                const isPartial = d.state === 'partial';

                return (
                  <button
                    key={d.dayNumber}
                    type="button"
                    onClick={() => setSelectedDayNum(d.dayNumber)}
                    className={`relative py-2.5 px-1.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'ring-2 ring-[#5B5FEF] border-[#5B5FEF] bg-[#EEEEFF]'
                        : isCompleted
                        ? 'bg-[#EEFBF4] border-[#2E9E6B]/40 text-[#2E9E6B]'
                        : isCurrent
                        ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white shadow-xs'
                        : isPartial
                        ? 'bg-[#FFF9EB] border-[#E8B84A] text-[#25263A]'
                        : isLocked
                        ? 'bg-[#F7F7FC] border-[#E6E6F0] text-[#77798C]/70 opacity-80'
                        : 'bg-white border-[#E6E6F0] text-[#25263A]'
                    }`}
                  >
                    <span
                      className={`text-[10px] font-bold ${
                        isCurrent && !isSelected ? 'text-white/90' : 'text-[#77798C]'
                      }`}
                    >
                      اليوم
                    </span>
                    <span
                      className={`text-sm font-black leading-none ${
                        isCurrent && !isSelected ? 'text-white' : 'text-[#25263A]'
                      }`}
                    >
                      {d.dayNumber}
                    </span>
                    <div className="h-3.5 flex items-center justify-center">
                      {isCompleted ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#2E9E6B]" />
                      ) : isLocked ? (
                        <Lock className="w-3 h-3 text-[#77798C]/70" />
                      ) : isCurrent ? (
                        <span
                          className={`text-[9px] font-black px-1 rounded ${
                            isSelected ? 'bg-[#5B5FEF] text-white' : 'bg-white/20 text-white'
                          }`}
                        >
                          الحالي
                        </span>
                      ) : (
                        <span className="text-[9px] font-bold text-[#77798C]">
                          {d.completedTasksCount}/{d.totalTasksCount}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Day Tasks & Spiritual Reflection */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs space-y-4">
            <div className="flex items-center justify-between gap-2 flex-wrap border-b border-[#E6E6F0] pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg bg-[#EEEEFF] text-[#5B5FEF] text-xs font-black">
                    اليوم {selectedDay.dayNumber} من {journey.definition.durationDays}
                  </span>
                  {selectedDay.dayNumber === journey.currentDayNumber && journey.isEnrolled && (
                    <span className="px-2 py-0.5 rounded-lg bg-[#2E9E6B]/15 text-[#2E9E6B] text-[11px] font-black">
                      • اليوم الحالي
                    </span>
                  )}
                  {selectedDay.state === 'locked' && (
                    <span className="px-2 py-0.5 rounded-lg bg-[#F7F7FC] text-[#77798C] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1">
                      <Lock className="w-3 h-3" /> يوم قادم (مقفل)
                    </span>
                  )}
                </div>
                <h4 className="text-sm font-black text-[#25263A] mt-1.5">
                  {selectedDay.title}
                </h4>
              </div>

              <div className="text-left">
                <span className="text-xs font-black text-[#5B5FEF] block">
                  إنجاز مهام اليوم: {selectedDay.completedTasksCount} / {selectedDay.totalTasksCount}
                </span>
                {journey.isEnrolled && (
                  <span className="text-[11px] text-[#77798C]">التاريخ: {selectedDay.dateStr}</span>
                )}
              </div>
            </div>

            {/* Spiritual Reflection for the Day */}
            <div className="bg-gradient-to-l from-[#EEEEFF]/70 to-[#F7F7FC] rounded-xl p-3.5 border border-[#5B5FEF]/20">
              <p className="text-xs sm:text-sm font-bold text-[#25263A] leading-relaxed">
                {selectedDay.reflectionQuote}
              </p>
              <span className="text-[11px] font-bold text-[#5B5FEF] mt-1 block">
                — {selectedDay.reflectionSource}
              </span>
            </div>

            {/* Locked Day Notice */}
            {journey.isEnrolled && selectedDay.dayNumber > journey.maxUnlockedDayNumber && (
              <div className="bg-[#FFF9EB] border border-[#E8B84A]/50 rounded-xl p-3 flex items-center gap-2.5 text-xs text-[#25263A]">
                <Clock className="w-4 h-4 text-[#E8B84A] shrink-0" />
                <span>
                  هذا اليوم مستقبلي ({selectedDay.dateStr}). يمكنك الاطلاع على مهامه التحضيرية، وسيُفتح تلقائيًا لتسجيل الإنجاز عند حلول يومه بمشيئة الله.
                </span>
              </div>
            )}

            {/* Tasks Checklist */}
            <div className="space-y-2.5">
              <h5 className="text-xs font-black text-[#77798C]">
                المهام المطلوبة في اليوم {selectedDay.dayNumber}:
              </h5>

              {selectedDay.tasks.map((task) => {
                const isDayLocked =
                  !journey.isEnrolled || selectedDay.dayNumber > journey.maxUnlockedDayNumber;

                return (
                  <div
                    key={task.id}
                    className={`rounded-xl p-3 border transition-all flex items-center justify-between gap-3 ${
                      task.isCompleted
                        ? 'bg-[#EEFBF4]/80 border-[#2E9E6B]/40'
                        : 'bg-[#F7F7FC] border-[#E6E6F0] hover:border-[#5B5FEF]/40'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => handleToggleTask(task)}
                      className="flex items-center gap-3 text-right flex-1 cursor-pointer"
                    >
                      <span
                        className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all shrink-0 ${
                          task.isCompleted
                            ? 'bg-[#2E9E6B] border-[#2E9E6B] text-white'
                            : isDayLocked
                            ? 'bg-[#EFEFF9] border-[#E6E6F0] text-[#77798C]/50'
                            : 'bg-white border-[#5B5FEF] text-transparent hover:bg-[#EEEEFF]'
                        }`}
                      >
                        {task.isCompleted ? (
                          <Check className="w-4 h-4 stroke-[2.8]" />
                        ) : isDayLocked ? (
                          <Lock className="w-3 h-3 text-[#77798C]" />
                        ) : null}
                      </span>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`text-xs sm:text-sm font-black ${
                              task.isCompleted
                                ? 'text-[#2E9E6B] line-through decoration-[#2E9E6B]/50'
                                : 'text-[#25263A]'
                            }`}
                          >
                            {task.title}
                          </span>
                          {task.statusBadge && (
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                task.isCompleted
                                  ? 'bg-[#2E9E6B]/15 text-[#2E9E6B]'
                                  : 'bg-[#EEEEFF] text-[#5B5FEF]'
                              }`}
                            >
                              {task.statusBadge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-[#77798C] mt-0.5">{task.subtitle}</p>
                      </div>
                    </button>

                    {task.linkedScreen && (
                      <button
                        type="button"
                        onClick={() => handleOpenLinkedSection(task)}
                        className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                        title={`الانتقال إلى ${task.linkedActionLabel || 'القسم'}`}
                      >
                        <span>{task.linkedActionLabel || 'افتح'}</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
