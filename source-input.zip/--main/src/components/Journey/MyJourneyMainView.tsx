import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  ArrowRight,
  Sparkles,
  Check,
  Lock,
  Play,
  Trophy,
  Flame,
  Calendar,
  Layers,
  Award,
  ChevronLeft,
  ExternalLink,
  Compass,
  CheckCircle2,
  Target,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ScreenType, WardType } from '../../types';
import {
  JourneyCategory,
  ComputedJourneySummary,
  ComputedTaskItem,
  loadMyJourneyState,
  computeAllJourneys,
  computeAllChallenges,
  computeAllAchievements,
  startOrSelectJourney,
  toggleJourneyDayTask,
  joinOrToggleChallengeToday,
} from '../../utils/myJourneyService';
import { JourneySectionSvg } from '../Home/RifqSectionIcons';
import { JourneyDetailModal } from './JourneyDetailModal';

interface MyJourneyMainViewProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
  onSelectWard?: (ward: WardType) => void;
}

type JourneyViewTab = 'dashboard' | 'journeys' | 'challenges' | 'achievements';

const CATEGORY_FILTERS: { id: JourneyCategory | 'all'; label: string; emoji: string }[] = [
  { id: 'all', label: 'كل الرحلات', emoji: '🌱' },
  { id: 'prayer', label: 'الصلاة', emoji: '🌙' },
  { id: 'quran', label: 'القرآن', emoji: '📖' },
  { id: 'athkar', label: 'الأذكار', emoji: '🤲' },
  { id: 'good_deeds', label: 'الأعمال الصالحة', emoji: '🌿' },
  { id: 'fasting', label: 'الصيام', emoji: '🌙' },
  { id: 'qiyam', label: 'قيام الليل', emoji: '🌃' },
  { id: 'knowledge', label: 'طلب العلم', emoji: '📚' },
];

export const MyJourneyMainView: React.FC<MyJourneyMainViewProps> = ({
  onBack,
  onNavigate,
  onSelectWard,
}) => {
  const [activeTab, setActiveTab] = useState<JourneyViewTab>('dashboard');
  const [selectedCategory, setSelectedCategory] = useState<JourneyCategory | 'all'>('all');
  const [refreshTick, setRefreshTick] = useState(0);
  const [inspectingJourneyId, setInspectingJourneyId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3000);
  }, []);

  const triggerRefresh = useCallback(() => {
    setRefreshTick((t) => t + 1);
  }, []);

  useEffect(() => {
    const handleExternalUpdate = () => {
      setRefreshTick((t) => t + 1);
    };
    window.addEventListener('rifq-journey-updated', handleExternalUpdate);
    window.addEventListener('rifq-prayer-tracker-updated', handleExternalUpdate);
    window.addEventListener('rifq-user-data-synced', handleExternalUpdate);
    return () => {
      window.removeEventListener('rifq-journey-updated', handleExternalUpdate);
      window.removeEventListener('rifq-prayer-tracker-updated', handleExternalUpdate);
      window.removeEventListener('rifq-user-data-synced', handleExternalUpdate);
    };
  }, []);

  const persistedState = useMemo(() => {
    void refreshTick;
    return loadMyJourneyState();
  }, [refreshTick]);

  const allJourneys = useMemo(() => {
    return computeAllJourneys(persistedState);
  }, [persistedState]);

  const enrolledJourneys = useMemo(() => {
    return allJourneys.filter((j) => j.isEnrolled);
  }, [allJourneys]);

  const activeJourney: ComputedJourneySummary | null = useMemo(() => {
    if (persistedState.activeJourneyId) {
      const found = allJourneys.find(
        (j) => j.definition.id === persistedState.activeJourneyId && j.isEnrolled
      );
      if (found) return found;
    }
    return enrolledJourneys[0] || null;
  }, [allJourneys, enrolledJourneys, persistedState.activeJourneyId]);

  const allChallenges = useMemo(() => {
    return computeAllChallenges(persistedState);
  }, [persistedState]);

  const achievementsData = useMemo(() => {
    return computeAllAchievements(persistedState);
  }, [persistedState]);

  const filteredJourneys = useMemo(() => {
    if (selectedCategory === 'all') return allJourneys;
    return allJourneys.filter((j) => j.definition.category === selectedCategory);
  }, [allJourneys, selectedCategory]);

  const inspectingJourney = useMemo(() => {
    if (!inspectingJourneyId) return null;
    return allJourneys.find((j) => j.definition.id === inspectingJourneyId) || null;
  }, [allJourneys, inspectingJourneyId]);

  const handleToggleTodayTask = (journey: ComputedJourneySummary, task: ComputedTaskItem) => {
    const res = toggleJourneyDayTask(
      journey.definition.id,
      journey.currentDayNumber,
      task.id
    );
    if (!res.success && res.message) {
      showToast(res.message);
      return;
    }
    triggerRefresh();

    if (!task.isCompleted) {
      showToast(`تقبل الله طاعتك: تم إنجاز «${task.title}» ✓`);
      const remainingBeforeClick = journey.todayDayStatus.tasks.filter(
        (t) => !t.isCompleted
      ).length;
      if (remainingBeforeClick === 1) {
        try {
          confetti({
            particleCount: 60,
            spread: 75,
            origin: { y: 0.6 },
            colors: ['#5B5FEF', '#E8B84A', '#2E9E6B', '#72B7E8'],
          });
        } catch {
          // ignore
        }
        showToast(`ما شاء الله! أتممت جميع مهام اليوم ${journey.currentDayNumber} في رحلتك 🎉`);
      }
    }
  };

  const handleStartJourneyQuick = (journeyId: string) => {
    startOrSelectJourney(journeyId);
    triggerRefresh();
    const def = allJourneys.find((j) => j.definition.id === journeyId)?.definition;
    showToast(`بدأت «${def?.title || 'الرحلة'}» — أعانك الله وثبّت خطاك 🌱`);
  };

  return (
    <div className="space-y-5 pb-10 animate-fade-in" dir="rtl">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-24 left-4 right-4 max-w-md mx-auto z-50 bg-[#25263A] text-white px-4 py-3 rounded-2xl shadow-xl border border-[#5B5FEF]/40 flex items-center gap-2.5 text-xs sm:text-sm font-bold animate-fade-in">
          <Sparkles className="w-4 h-4 text-[#E8B84A] shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="bg-gradient-to-br from-[#FFFFFF] via-[#F7F7FC] to-[#EEEEFF] rounded-3xl p-5 border border-[#E6E6F0] shadow-xs">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="w-10 h-10 rounded-2xl bg-white border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] flex items-center justify-center transition-colors cursor-pointer shrink-0"
              aria-label="العودة للرئيسية"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-3">
              <JourneySectionSvg size={48} />
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg sm:text-xl font-black text-[#25263A]">
                    🌱 رحلتي الإيمانية
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#EEEEFF] text-[#5B5FEF] border border-[#5B5FEF]/20">
                    رحلات وتحديات
                  </span>
                </div>
                <p className="text-xs text-[#77798C] mt-0.5">
                  اختر رحلتك، واظب على مهام يومك، وارتقِ في منازل العبودية خطوة بخطوة
                </p>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('harvest')}
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-xs font-bold transition-colors cursor-pointer shrink-0"
          >
            <Trophy className="w-4 h-4 text-[#E8B84A]" />
            <span>حصاد الأعمال</span>
          </button>
        </div>

        {/* Navigation Tabs inside «رحلتي» */}
        <div className="grid grid-cols-4 gap-2 mt-4 pt-3 border-t border-[#E6E6F0]">
          {[
            { id: 'dashboard', label: 'رحلتي الحالية', badge: enrolledJourneys.length || undefined },
            { id: 'journeys', label: 'الرحلات', badge: allJourneys.length },
            {
              id: 'challenges',
              label: 'التحديات',
              badge: allChallenges.filter((c) => c.isJoined).length || undefined,
            },
            {
              id: 'achievements',
              label: 'الإنجازات',
              badge: `${achievementsData.unlockedCount}/${achievementsData.achievements.length}`,
            },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as JourneyViewTab)}
                className={`py-2.5 px-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : 'bg-white text-[#77798C] hover:text-[#25263A] border border-[#E6E6F0]'
                }`}
              >
                <span className="truncate">{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-[#F7F7FC] text-[#5B5FEF]'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB 1: الشاشة الرئيسية لـ «رحلتي» (Current Journey Dashboard)
         ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'dashboard' && (
        <div className="space-y-5">
          {activeJourney ? (
            <>
              {/* If user is enrolled in multiple journeys, allow switching between active ones */}
              {enrolledJourneys.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  <span className="text-xs font-bold text-[#77798C] shrink-0">رحلاتي الجارية:</span>
                  {enrolledJourneys.map((ej) => {
                    const isSelected = ej.definition.id === activeJourney.definition.id;
                    return (
                      <button
                        key={ej.definition.id}
                        type="button"
                        onClick={() => {
                          startOrSelectJourney(ej.definition.id);
                          triggerRefresh();
                        }}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#5B5FEF] text-white shadow-2xs'
                            : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF]'
                        }`}
                      >
                        <span>{ej.definition.iconEmoji}</span>
                        <span>{ej.definition.shortTitle}</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-[#EEEEFF] text-[#5B5FEF]'
                          }`}
                        >
                          {ej.progressPercent}%
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Main Current Journey Hero Card */}
              <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#EEEEFF] to-[#F7F7FC] border border-[#5B5FEF]/25 flex items-center justify-center text-3xl shadow-2xs shrink-0">
                      <span>{activeJourney.definition.iconEmoji}</span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#EEEEFF] text-[#5B5FEF]">
                          الرحلة الحالية • {activeJourney.statusLabelAr}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#F7F7FC] text-[#77798C] border border-[#E6E6F0]">
                          المرحلة {activeJourney.currentStage.stageNumber}: {activeJourney.currentStage.title}
                        </span>
                      </div>
                      <h2 className="text-base sm:text-lg font-black text-[#25263A] mt-1">
                        🌱 {activeJourney.definition.title}
                      </h2>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setInspectingJourneyId(activeJourney.definition.id)}
                    className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <span>متابعة الرحلة وخريطة الأيام</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress Bar & Day Counter */}
                <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm sm:text-base font-black text-[#25263A]">
                        اليوم {activeJourney.currentDayNumber} من {activeJourney.definition.durationDays}
                      </span>
                      {activeJourney.streakDays > 0 && (
                        <span className="px-2 py-0.5 rounded-full bg-[#FFF4E5] text-[#D9822B] text-[11px] font-black flex items-center gap-1">
                          <Flame className="w-3.5 h-3.5 fill-current" />
                          {activeJourney.streakDays} أيام متتالية
                        </span>
                      )}
                    </div>
                    <span className="text-base font-black text-[#5B5FEF]">
                      {activeJourney.progressPercent}%
                    </span>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full h-3.5 bg-[#EFEFF9] rounded-full overflow-hidden border border-[#E6E6F0]">
                    <div
                      className="h-full bg-gradient-to-l from-[#5B5FEF] via-[#6C70F5] to-[#2E9E6B] rounded-full transition-all duration-500"
                      style={{ width: `${activeJourney.progressPercent}%` }}
                    />
                  </div>

                  {/* Stats Row: Completed Days, Remaining Days, Today's Tasks */}
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="bg-white rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                      <span className="text-[11px] text-[#77798C] block">الأيام المكتملة</span>
                      <span className="text-sm font-black text-[#2E9E6B]">
                        {activeJourney.completedDaysCount} يومًا
                      </span>
                    </div>
                    <div className="bg-white rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                      <span className="text-[11px] text-[#77798C] block">الأيام المتبقية</span>
                      <span className="text-sm font-black text-[#5B5FEF]">
                        {activeJourney.remainingDaysCount} يومًا
                      </span>
                    </div>
                    <div className="bg-white rounded-xl p-2.5 border border-[#E6E6F0] text-center">
                      <span className="text-[11px] text-[#77798C] block">مهام اليوم</span>
                      <span className="text-sm font-black text-[#25263A]">
                        {activeJourney.todayDayStatus.completedTasksCount} /{' '}
                        {activeJourney.todayDayStatus.totalTasksCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Today's Tasks Interactive Section (مهام اليوم الحقيقية) */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-[#25263A] flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#5B5FEF]" />
                      <span>
                        مهام اليوم ({activeJourney.todayDayStatus.title})
                      </span>
                    </h3>
                    <span className="text-[11px] font-bold text-[#77798C]">
                      متزامنة مع نشاطك الحقيقي في رِفْق
                    </span>
                  </div>

                  <div className="space-y-2">
                    {activeJourney.todayDayStatus.tasks.map((task) => (
                      <div
                        key={task.id}
                        className={`rounded-2xl p-3.5 border transition-all flex items-center justify-between gap-3 ${
                          task.isCompleted
                            ? 'bg-[#EEFBF4]/90 border-[#2E9E6B]/40'
                            : 'bg-[#F7F7FC] border-[#E6E6F0] hover:border-[#5B5FEF]/40'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => handleToggleTodayTask(activeJourney, task)}
                          className="flex items-center gap-3 text-right flex-1 cursor-pointer"
                        >
                          <span
                            className={`w-6 h-6 rounded-lg flex items-center justify-center border transition-all shrink-0 ${
                              task.isCompleted
                                ? 'bg-[#2E9E6B] border-[#2E9E6B] text-white'
                                : 'bg-white border-[#5B5FEF] text-transparent hover:bg-[#EEEEFF]'
                            }`}
                          >
                            <Check className="w-4 h-4 stroke-[2.8]" />
                          </span>

                          <div className="flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`text-xs sm:text-sm font-black ${
                                  task.isCompleted ? 'text-[#2E9E6B]' : 'text-[#25263A]'
                                }`}
                              >
                                {task.isCompleted ? '✓ ' : '○ '}
                                {task.title}
                              </span>
                              {task.statusBadge && (
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    task.isCompleted
                                      ? 'bg-[#2E9E6B]/15 text-[#2E9E6B]'
                                      : 'bg-[#EEEEFF] text-[#5B5FEF]'
                                  }`}
                                >
                                  {task.statusBadge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-[#77798C] mt-0.5">{task.subtitle}</p>
                          </div>
                        </button>

                        {task.linkedScreen && (
                          <button
                            type="button"
                            onClick={() => {
                              if (task.linkedWard && onSelectWard) {
                                onSelectWard(task.linkedWard);
                              } else if (task.linkedScreen) {
                                onNavigate(task.linkedScreen);
                              }
                            }}
                            className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer"
                          >
                            <span>{task.linkedActionLabel || 'افتح'}</span>
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Last Achievement & Next Achievement Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#E6E6F0]">
                  {/* Last Achievement */}
                  <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-white border border-[#E6E6F0] flex items-center justify-center text-xl shrink-0">
                      <span>{achievementsData.lastUnlocked?.icon || '🌱'}</span>
                    </div>
                    <div className="min-w-0">
                      <span className="text-[10px] font-black text-[#2E9E6B] block">
                        آخر إنجاز حصلت عليه
                      </span>
                      <h4 className="text-xs font-black text-[#25263A] truncate">
                        {achievementsData.lastUnlocked
                          ? achievementsData.lastUnlocked.title
                          : 'ابدأ مهام اليوم لفتح أول وسام'}
                      </h4>
                      <p className="text-[11px] text-[#77798C] truncate">
                        {achievementsData.lastUnlocked
                          ? achievementsData.lastUnlocked.description
                          : 'وسام «بذرة الالتزام» بانتظارك اليوم'}
                      </p>
                    </div>
                  </div>

                  {/* Next Achievement */}
                  <div className="bg-[#EEEEFF]/50 rounded-2xl p-3.5 border border-[#5B5FEF]/20 flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-white border border-[#5B5FEF]/20 flex items-center justify-center text-xl shrink-0">
                      <span>{activeJourney.nextAchievement?.icon || '🏆'}</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-black text-[#5B5FEF] block">
                        الإنجاز التالي في الرحلة
                      </span>
                      <h4 className="text-xs font-black text-[#25263A] truncate">
                        {activeJourney.nextAchievement?.title}
                      </h4>
                      <p className="text-[11px] text-[#77798C] truncate">
                        {activeJourney.nextAchievement?.remainingCount === 0
                          ? 'مكتمل ما شاء الله! 🎉'
                          : `يتبقى ${activeJourney.nextAchievement?.remainingCount} أيام مكتملة للوصول إليه`}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Empty State when User hasn't enrolled in any journey yet (User chooses their own journey!) */
            <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] shadow-xs text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#EEEEFF] border border-[#5B5FEF]/20 mx-auto flex items-center justify-center">
                <JourneySectionSvg size={52} />
              </div>
              <div className="max-w-md mx-auto space-y-1.5">
                <h2 className="text-base sm:text-lg font-black text-[#25263A]">
                  اختر رحلتك الإيمانية الأولى وابدأ المسير 🌱
                </h2>
                <p className="text-xs text-[#77798C] leading-relaxed">
                  لم تشترك في أي رحلة بعد. اختر الرحلة التي تناسب هدفك الحالي في الصلاة أو القرآن أو الأذكار أو الصيام أو طلب العلم، وتابع تقدمك الحقيقي يومًا بيوم.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('journeys')}
                className="px-6 py-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs sm:text-sm font-black shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <Compass className="w-4 h-4" />
                <span>استعراض جميع الرحلات واختيار رحلتي</span>
              </button>
            </div>
          )}

          {/* Quick Preview of Available Journeys */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm sm:text-base font-black text-[#25263A] flex items-center gap-2">
                <span>رحلات العبادة في رِفْق</span>
              </h3>
              <button
                type="button"
                onClick={() => setActiveTab('journeys')}
                className="text-xs font-black text-[#5B5FEF] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>عرض كل الرحلات ({allJourneys.length})</span>
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {allJourneys.slice(0, 6).map((j) => (
                <div
                  key={j.definition.id}
                  onClick={() => setInspectingJourneyId(j.definition.id)}
                  className="bg-white rounded-2xl p-4 border border-[#E6E6F0] hover:border-[#5B5FEF] shadow-2xs transition-all cursor-pointer flex flex-col justify-between gap-3 group"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-[#F7F7FC] group-hover:bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-2xl transition-colors shrink-0">
                        <span>{j.definition.iconEmoji}</span>
                      </div>
                      <div>
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-black ${
                            j.status === 'in_progress'
                              ? 'bg-[#EEFBF4] text-[#2E9E6B]'
                              : j.status === 'completed'
                              ? 'bg-[#FFF9EB] text-[#D9822B]'
                              : 'bg-[#F7F7FC] text-[#77798C]'
                          }`}
                        >
                          {j.statusLabelAr}
                        </span>
                        <h4 className="text-sm font-black text-[#25263A] group-hover:text-[#5B5FEF] transition-colors mt-0.5">
                          {j.definition.title}
                        </h4>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#77798C] line-clamp-2 leading-relaxed">
                    {j.definition.description}
                  </p>

                  <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-[11px] font-bold text-[#77798C]">
                      <span>{j.definition.durationDays} يومًا</span>
                      <span>•</span>
                      <span>{j.definition.stages.length} مراحل</span>
                    </div>

                    {j.isEnrolled ? (
                      <span className="text-xs font-black text-[#5B5FEF] flex items-center gap-1">
                        <span>متابعة ({j.progressPercent}%)</span>
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStartJourneyQuick(j.definition.id);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#5B5FEF] hover:text-white text-xs font-black transition-colors cursor-pointer"
                      >
                        ابدأ الرحلة
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB 2: شاشة «الرحلات» الكاملة (All Journeys Catalog)
         ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'journeys' && (
        <div className="space-y-4">
          {/* Category Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {CATEGORY_FILTERS.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-black flex items-center gap-1.5 shrink-0 transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#5B5FEF] text-white shadow-xs'
                      : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF]'
                  }`}
                >
                  <span>{cat.emoji}</span>
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Journeys List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredJourneys.map((j) => (
              <div
                key={j.definition.id}
                onClick={() => setInspectingJourneyId(j.definition.id)}
                className={`bg-white rounded-2xl p-4 border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  j.isActivePrimary
                    ? 'border-[#5B5FEF] shadow-sm ring-1 ring-[#5B5FEF]/20'
                    : 'border-[#E6E6F0] hover:border-[#5B5FEF] shadow-2xs'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-13 h-13 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center text-2xl shrink-0">
                        <span>{j.definition.iconEmoji}</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              j.status === 'in_progress'
                                ? 'bg-[#EEFBF4] text-[#2E9E6B]'
                                : j.status === 'completed'
                                ? 'bg-[#FFF9EB] text-[#D9822B]'
                                : 'bg-[#F7F7FC] text-[#77798C] border border-[#E6E6F0]'
                            }`}
                          >
                            {j.statusLabelAr}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EEEEFF] text-[#5B5FEF]">
                            {j.definition.difficultyLabel}
                          </span>
                        </div>
                        <h3 className="text-sm sm:text-base font-black text-[#25263A] mt-1">
                          {j.definition.title}
                        </h3>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#77798C] leading-relaxed">
                    {j.definition.description}
                  </p>

                  {/* Metadata Badges */}
                  <div className="flex items-center gap-2 flex-wrap text-[11px] font-bold text-[#25263A]">
                    <span className="px-2.5 py-1 rounded-lg bg-[#F7F7FC] border border-[#E6E6F0]">
                      المدة: {j.definition.durationDays} يومًا
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-[#F7F7FC] border border-[#E6E6F0]">
                      عدد المراحل: {j.definition.stages.length} مراحل
                    </span>
                    {j.isEnrolled && (
                      <span className="px-2.5 py-1 rounded-lg bg-[#EEFBF4] text-[#2E9E6B] border border-[#2E9E6B]/20">
                        مكتمل: {j.completedDaysCount}/{j.definition.durationDays} يوم
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress Bar & Action */}
                <div className="pt-2.5 border-t border-[#E6E6F0] space-y-2.5">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-[#77798C]">
                        {j.isEnrolled
                          ? `اليوم الحالي: ${j.currentDayNumber} من ${j.definition.durationDays}`
                          : 'اضغط لعرض المراحل والأيام'}
                      </span>
                      <span className="text-[#5B5FEF] font-black">{j.progressPercent}%</span>
                    </div>
                    <div className="w-full h-2 bg-[#EFEFF9] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#5B5FEF] rounded-full transition-all duration-300"
                        style={{ width: `${j.progressPercent}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInspectingJourneyId(j.definition.id);
                      }}
                      className="text-xs font-bold text-[#77798C] hover:text-[#25263A] cursor-pointer"
                    >
                      تفاصيل الرحلة والمراحل
                    </button>

                    {!j.isEnrolled ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStartJourneyQuick(j.definition.id);
                          setInspectingJourneyId(j.definition.id);
                        }}
                        className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>ابدأ الرحلة</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          startOrSelectJourney(j.definition.id);
                          triggerRefresh();
                          setInspectingJourneyId(j.definition.id);
                        }}
                        className="px-4 py-2 rounded-xl bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#5B5FEF] hover:text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>متابعة الرحلة</span>
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB 3: شاشة «التحديات الإيمانية» (Challenges)
         ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'challenges' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] flex items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-black text-[#25263A]">
                🔥 التحديات الإيمانية المركزة
              </h3>
              <p className="text-xs text-[#77798C] mt-0.5">
                تحديات أسبوعية سريعة لرفع الهمة في عبادة محددة بالتوازي مع رحلتك اليومية
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {allChallenges.map((ch) => (
              <div
                key={ch.id}
                className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs flex flex-col justify-between gap-3"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center text-2xl shrink-0">
                        <span>{ch.icon}</span>
                      </div>
                      <div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            ch.isCompletedAll
                              ? 'bg-[#FFF9EB] text-[#D9822B]'
                              : ch.isJoined
                              ? 'bg-[#EEFBF4] text-[#2E9E6B]'
                              : 'bg-[#F7F7FC] text-[#77798C]'
                          }`}
                        >
                          {ch.isCompletedAll
                            ? '🏆 مكتمل'
                            : ch.isJoined
                            ? `🌱 اليوم ${ch.currentDayNumber} من ${ch.durationDays}`
                            : `▶️ متاح • ${ch.durationDays} أيام`}
                        </span>
                        <h4 className="text-sm font-black text-[#25263A] mt-1">{ch.title}</h4>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-[#77798C] leading-relaxed">{ch.description}</p>

                  <div className="bg-[#F7F7FC] rounded-xl p-2.5 border border-[#E6E6F0] text-[11px] font-bold text-[#5B5FEF]">
                    {ch.virtueText}
                  </div>
                </div>

                <div className="pt-2 border-t border-[#E6E6F0] space-y-2.5">
                  {ch.isJoined && (
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-bold">
                        <span className="text-[#77798C]">
                          تم إنجاز {ch.completedDaysCount} من {ch.durationDays} أيام
                        </span>
                        <span className="text-[#5B5FEF] font-black">{ch.progressPercent}%</span>
                      </div>
                      <div className="w-full h-2 bg-[#EFEFF9] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#2E9E6B] rounded-full transition-all"
                          style={{ width: `${ch.progressPercent}%` }}
                        />
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onNavigate(ch.linkedScreen)}
                      className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <span>{ch.linkedActionLabel}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const wasJoined = ch.isJoined;
                        joinOrToggleChallengeToday(ch.id);
                        triggerRefresh();
                        if (!wasJoined) {
                          showToast(`انضممت إلى «${ch.title}»! أعانك الله 🔥`);
                        } else if (!ch.isCompletedToday) {
                          showToast(`تقبل الله! تم تسجيل إنجاز اليوم في «${ch.title}» ✓`);
                        }
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                        !ch.isJoined
                          ? 'bg-[#5B5FEF] hover:bg-[#4145C7] text-white'
                          : ch.isCompletedToday
                          ? 'bg-[#EEFBF4] text-[#2E9E6B] border border-[#2E9E6B]/30'
                          : 'bg-[#5B5FEF] text-white'
                      }`}
                    >
                      {!ch.isJoined ? (
                        <>
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>ابدأ التحدي</span>
                        </>
                      ) : ch.isCompletedToday ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[2.8]" />
                          <span>مكتمل اليوم ✓</span>
                        </>
                      ) : (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>إتمام مهمة اليوم</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          TAB 4: شاشة «الإنجازات والأوسمة» (Achievements & Milestones)
         ═══════════════════════════════════════════════════════════════════════ */}
      {activeTab === 'achievements' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#FFF9EB] border border-[#E8B84A]/40 flex items-center justify-center text-2xl">
                🏆
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-black text-[#25263A]">
                  أوسمة وإنجازات «رحلتي»
                </h3>
                <p className="text-xs text-[#77798C]">
                  الأوسمة تُفتح تلقائيًا بناءً على التزامك الحقيقي في الرحلات والتحديات
                </p>
              </div>
            </div>
            <span className="px-3.5 py-1.5 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] text-xs font-black">
              مكتسب: {achievementsData.unlockedCount} من {achievementsData.achievements.length}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {achievementsData.achievements.map((ach) => (
              <div
                key={ach.id}
                className={`rounded-2xl p-4 border transition-all flex flex-col justify-between gap-3 ${
                  ach.isUnlocked
                    ? 'bg-white border-[#2E9E6B]/40 shadow-2xs'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] opacity-85'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border shrink-0 ${
                      ach.isUnlocked
                        ? 'bg-[#EEFBF4] border-[#2E9E6B]/30'
                        : 'bg-white border-[#E6E6F0] grayscale'
                    }`}
                  >
                    <span>{ach.icon}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-black text-[#25263A]">{ach.title}</h4>
                      {ach.isUnlocked ? (
                        <span className="px-2 py-0.2 rounded-full bg-[#EEFBF4] text-[#2E9E6B] text-[10px] font-black">
                          مكتسب ✓
                        </span>
                      ) : (
                        <Lock className="w-3.5 h-3.5 text-[#77798C]" />
                      )}
                    </div>
                    <p className="text-xs text-[#77798C] mt-1 leading-relaxed">
                      {ach.description}
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-[#E6E6F0]">
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span className="text-[#77798C]">{ach.requirementText}</span>
                    <span className="text-[#5B5FEF] font-black">
                      {Math.min(ach.currentProgress, ach.targetDays)} / {ach.targetDays}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#EFEFF9] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        ach.isUnlocked ? 'bg-[#2E9E6B]' : 'bg-[#5B5FEF]'
                      }`}
                      style={{ width: `${ach.progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Journey Detail Modal */}
      {inspectingJourney && (
        <JourneyDetailModal
          journey={inspectingJourney}
          onClose={() => setInspectingJourneyId(null)}
          onRefresh={triggerRefresh}
          onNavigate={onNavigate}
          onSelectWard={onSelectWard}
          onShowToast={showToast}
        />
      )}
    </div>
  );
};
