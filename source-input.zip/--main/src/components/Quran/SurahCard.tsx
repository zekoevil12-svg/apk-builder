import React from 'react';
import { Star, BookOpen, Bookmark } from 'lucide-react';
import { SurahMeta } from '../../data/quranData';

interface SurahCardProps {
  surah: SurahMeta;
  isFavorite: boolean;
  isBookmarked?: boolean;
  onSelect: (surahNumber: number) => void;
  onToggleFavorite: (surahNumber: number, e: React.MouseEvent) => void;
  onToggleBookmark?: (surahNumber: number, e: React.MouseEvent) => void;
}

export const SurahCard: React.FC<SurahCardProps> = ({
  surah,
  isFavorite,
  isBookmarked = false,
  onSelect,
  onToggleFavorite,
  onToggleBookmark,
}) => {
  return (
    <div
      onClick={() => onSelect(surah.number)}
      className="group relative bg-white dark:bg-[#1A1A1A] rounded-2xl p-4 shadow-sm hover:shadow-md transition-all duration-200 border border-[#E6E6F0] hover:border-[#5B5FEF] cursor-pointer flex flex-col justify-between overflow-hidden select-none"
    >
      {/* Top row: Favorite Star & Surah Number Badge */}
      <div className="flex items-center justify-between w-full mb-2">
        {/* Favorite Button */}
        <button
          onClick={(e) => onToggleFavorite(surah.number, e)}
          title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
          className={`w-8 h-8 rounded-full flex items-center justify-center transition-transform hover:scale-110 cursor-pointer ${
            isFavorite
              ? 'text-amber-500 bg-[#EEEEFF] dark:bg-amber-950/40'
              : 'text-gray-300 dark:text-[#77798C] hover:text-amber-500'
          }`}
        >
          <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-500' : ''}`} />
        </button>

        {/* Surah Number inside Golden Circle (40px) */}
        <div className="w-10 h-10 rounded-full border-2 border-[#5B5FEF] bg-[#F7F7FC] dark:bg-[#25263A] flex items-center justify-center shadow-xs">
          <span className="text-xs font-bold font-mono text-[#25263A] dark:text-[#5B5FEF]">
            {surah.number}
          </span>
        </div>
      </div>

      {/* Surah Name in Amiri font */}
      <div className="text-center my-2">
        <h3 className="text-xl font-bold font-amiri text-[#5B5FEF] group-hover:text-[#E8B84A] transition-colors">
          سورة {surah.name}
        </h3>
        <p className="text-[11px] text-gray-400 font-mono mt-0.5" dir="ltr">
          {surah.englishName}
        </p>
      </div>

      {/* Details Row: Cairo font, gray */}
      <div className="flex items-center justify-center gap-2 text-xs text-[#77798C] dark:text-gray-400 my-1 py-1.5 border-t border-b border-[#E6E6F0]">
        <span className="font-medium">{surah.numberOfAyahs} آيات</span>
        <span>•</span>
        <span className="font-medium">{surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}</span>
        <span>•</span>
        <span className="font-medium text-[#5B5FEF]">الجزء {surah.juz}</span>
      </div>

      {/* Card Action footer: Read button and Bookmark indicator */}
      <div className="mt-3 flex items-center justify-between pt-1">
        {onToggleBookmark && (
          <button
            onClick={(e) => onToggleBookmark(surah.number, e)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isBookmarked ? 'text-[#5B5FEF]' : 'text-gray-300 dark:text-[#77798C] hover:text-[#5B5FEF]'
            }`}
            title="إشارة مرجعية"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-[#E8B84A]' : ''}`} />
          </button>
        )}

        <div className="flex items-center gap-1 text-xs font-bold text-[#5B5FEF] group-hover:underline mr-auto">
          <span>قراءة المصحف</span>
          <BookOpen className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};

