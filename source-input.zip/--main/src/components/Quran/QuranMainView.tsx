import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowRight,
  BookOpen,
  Bookmark,
  Star,
  Clock,
  Settings,
  Eye,
  EyeOff,
  ChevronRight,
  ChevronLeft,
  Search,
  X,
  Share2,
  Copy,
  Check,
  RotateCcw,
  Trophy,
  Sliders,
  Sparkles,
  Layers,
  Compass,
  Play,
  Pause,
  Gauge,
} from 'lucide-react';
import {
  SURAH_LIST,
  SurahDetail,
  AyahItem,
  BookmarkItem,
  KhatmahTracker,
} from '../../data/quranData';
import {
  getSurahDetail,
  saveLastRead,
  loadLastRead,
  toggleBookmark,
  loadBookmarks,
  saveBookmarks,
  updateBookmarkNote,
  removeBookmarkById,
  toggleFavoriteSurah,
  loadFavoriteSurahs,
  loadKhatmah,
  saveKhatmah,
  TafseerType,
  TAFSEER_CONFIG,
  getAyahTafseer,
} from '../../utils/quranService';
import { TafseerModal } from './TafseerModal';
import { VerseCardModal } from './VerseCardModal';
import { BookmarksModal } from './BookmarksModal';
import { QuizView } from '../Tahfeez/QuizView';
import { InteractiveMushafSvg } from '../Tahfeez/InteractiveQuizIcons';

interface QuranMainViewProps {
  onNavigateHome: () => void;
}

// Quick frequently recited Surahs for instant jump
const QUICK_SURAHS = [
  { number: 1, name: 'الفاتحة' },
  { number: 2, name: 'البقرة' },
  { number: 18, name: 'الكهف' },
  { number: 36, name: 'يس' },
  { number: 55, name: 'الرحمن' },
  { number: 56, name: 'الواقعة' },
  { number: 67, name: 'الملك' },
  { number: 112, name: 'الإخلاص' },
  { number: 113, name: 'الفلق' },
  { number: 114, name: 'الناس' },
];

// Auto-Scroll Speed Presets (calibrated in pixels per second for comfortable Quran reading)
const AUTO_SCROLL_PRESETS = [
  { id: 'slow' as const, label: 'بطيء', speed: 15 },
  { id: 'medium' as const, label: 'متوسط', speed: 26 },
  { id: 'fast' as const, label: 'سريع', speed: 42 },
];

export const QuranMainView: React.FC<QuranMainViewProps> = ({ onNavigateHome }) => {
  // Saved last read position
  const initialLastRead = useMemo(() => loadLastRead(), []);

  // Main Tabs: 'index' (فهرس السور السريع) | 'mushaf' (قراءة متصلة) | 'tafseer' | 'translation' | 'quiz' (اختبر حفظك)
  const [activeTab, setActiveTab] = useState<'index' | 'mushaf' | 'tafseer' | 'translation' | 'quiz'>('index');

  // Current active Surah and Ayah
  const [currentSurahNumber, setCurrentSurahNumber] = useState<number>(initialLastRead.surahNumber || 1);
  const [currentAyahNumber, setCurrentAyahNumber] = useState<number>(initialLastRead.ayahNumber || 1);

  // Full Surah data
  const [surah, setSurah] = useState<SurahDetail | null>(null);
  const [loading, setLoading] = useState(true);

  // Reading customization
  const [fontSize, setFontSize] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_quran_font_size');
    return saved ? parseInt(saved, 10) : 26;
  });
  const [themeMode, setThemeMode] = useState<'beige' | 'white' | 'dark'>(() => {
    const saved = localStorage.getItem('rifq_quran_theme');
    return (saved as 'beige' | 'white' | 'dark') || 'beige';
  });

  // Memorization mode (وضع الإخفاء للتسميع)
  const [isHideMode, setIsHideMode] = useState(false);
  const [revealedAyahs, setRevealedAyahs] = useState<Record<number, boolean>>({});

  // Modals & Sheets
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBookmarksModalOpen, setIsBookmarksModalOpen] = useState(false);
  const [selectedAyahForSheet, setSelectedAyahForSheet] = useState<AyahItem | null>(null);
  const [tafseerAyah, setTafseerAyah] = useState<AyahItem | null>(null);
  const [shareCardAyah, setShareCardAyah] = useState<AyahItem | null>(null);
  const [highlightedAyahNumber, setHighlightedAyahNumber] = useState<number | null>(null);
  const pendingScrollAyahRef = useRef<number | null>(null);

  // Continuous Tafseer Tab State
  const [selectedTafseerType, setSelectedTafseerType] = useState<TafseerType>('muyassar');
  const [tafseerList, setTafseerList] = useState<Record<number, string>>({});
  const [loadingTafseerTab, setLoadingTafseerTab] = useState(false);

  // Translation Tab State
  const [transLang, setTransLang] = useState<'en' | 'fr' | 'ur'>('en');

  // Bookmarks, Favorites, Khatmah
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => loadBookmarks());
  const [favorites, setFavorites] = useState<number[]>(() => loadFavoriteSurahs());
  const [khatmah, setKhatmah] = useState<KhatmahTracker>(() => loadKhatmah());
  const [lastRead, setLastRead] = useState(() => loadLastRead());

  // Interactive Index Search and Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState<'all' | 'Meccan' | 'Medinan'>('all');
  const [selectedJuzFilter, setSelectedJuzFilter] = useState<number | 'all'>('all');
  const [indexSubTab, setIndexSubTab] = useState<'all' | 'favorites' | 'bookmarks'>('all');

  // Feedback notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedAyahNumber, setCopiedAyahNumber] = useState<number | null>(null);

  // Ayah references for auto-scroll and jump
  const ayahElementsRef = useRef<Record<number, HTMLElement | null>>({});
  const quickSurahsBarRef = useRef<HTMLDivElement | null>(null);
  const mushafScrollContainerRef = useRef<HTMLDivElement | null>(null);

  // ─────────────────────────────────────────────────────────────
  // 📖 حالة وإعدادات التمرير التلقائي (Auto-Scroll via requestAnimationFrame)
  // ─────────────────────────────────────────────────────────────
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const [isAutoScrollPausedByManual, setIsAutoScrollPausedByManual] = useState(false);
  const [showAutoScrollControls, setShowAutoScrollControls] = useState(false);
  const [autoScrollSpeed, setAutoScrollSpeed] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_quran_autoscroll_speed');
    const parsed = saved ? parseFloat(saved) : 26;
    return Number.isFinite(parsed) ? Math.min(60, Math.max(8, parsed)) : 26;
  });

  const autoScrollSpeedRef = useRef<number>(autoScrollSpeed);
  const rafIdRef = useRef<number | null>(null);
  const lastFrameTimeRef = useRef<number | null>(null);
  const virtualScrollTopRef = useRef<number | null>(null);
  const isUserTouchingRef = useRef<boolean>(false);
  const touchStartYRef = useRef<number | null>(null);
  const lastVisibleSyncTimeRef = useRef<number>(0);
  const lastSavedReadTimeRef = useRef<number>(0);
  const currentAyahNumberRef = useRef<number>(currentAyahNumber);

  useEffect(() => {
    currentAyahNumberRef.current = currentAyahNumber;
  }, [currentAyahNumber]);

  useEffect(() => {
    autoScrollSpeedRef.current = autoScrollSpeed;
  }, [autoScrollSpeed]);

  const updateAutoScrollSpeed = (newSpeed: number) => {
    const clamped = Math.min(60, Math.max(8, Math.round(newSpeed)));
    setAutoScrollSpeed(clamped);
    autoScrollSpeedRef.current = clamped;
    localStorage.setItem('rifq_quran_autoscroll_speed', clamped.toString());
  };

  const getActiveSpeedPreset = (speed: number): 'slow' | 'medium' | 'fast' => {
    if (speed <= 19) return 'slow';
    if (speed <= 34) return 'medium';
    return 'fast';
  };

  // Resolve the active scrollable container (inner Mushaf container or document scrollingElement)
  const getActiveScrollContainer = (): HTMLElement | null => {
    if (activeTab === 'mushaf' && mushafScrollContainerRef.current) {
      const el = mushafScrollContainerRef.current;
      if (el.scrollHeight > el.clientHeight + 2) {
        return el;
      }
    }
    return (document.scrollingElement as HTMLElement) || document.documentElement;
  };

  // Detect the currently visible Ayah at the reading focal line and persist reading position
  const syncVisibleAyahFromScroll = (forceSave = false) => {
    if (!surah || !surah.ayahs || surah.ayahs.length === 0) return;
    if (activeTab !== 'mushaf' && activeTab !== 'tafseer' && activeTab !== 'translation') return;

    const now = performance.now();
    if (!forceSave && now - lastVisibleSyncTimeRef.current < 180) return;
    lastVisibleSyncTimeRef.current = now;

    const container =
      activeTab === 'mushaf' &&
      mushafScrollContainerRef.current &&
      mushafScrollContainerRef.current.scrollHeight > mushafScrollContainerRef.current.clientHeight + 2
        ? mushafScrollContainerRef.current
        : null;

    const focalY = container
      ? container.getBoundingClientRect().top + Math.min(140, container.clientHeight * 0.32)
      : Math.min(220, window.innerHeight * 0.32);

    const ayahs = surah.ayahs;
    let low = 0;
    let high = ayahs.length - 1;
    let bestAyahNum = currentAyahNumberRef.current || 1;
    let foundAny = false;

    while (low <= high) {
      const mid = (low + high) >> 1;
      const ayahNum = ayahs[mid].numberInSurah;
      const el = ayahElementsRef.current[ayahNum];
      if (!el) break;
      const rect = el.getBoundingClientRect();
      foundAny = true;
      if (rect.top <= focalY + 32) {
        bestAyahNum = ayahNum;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }

    if (!foundAny) return;

    if (bestAyahNum !== currentAyahNumberRef.current) {
      currentAyahNumberRef.current = bestAyahNum;
      setCurrentAyahNumber(bestAyahNum);
    }

    if (forceSave || now - lastSavedReadTimeRef.current >= 2000) {
      lastSavedReadTimeRef.current = now;
      const ayahObj = ayahs.find((a) => a.numberInSurah === bestAyahNum) || ayahs[0];
      const nextRead = {
        surahNumber: surah.number,
        surahName: surah.name,
        ayahNumber: bestAyahNum,
        ayahText: ayahObj?.text || '',
        timestamp: Date.now(),
      };
      saveLastRead(nextRead);
      setLastRead(nextRead);
    }
  };

  // Stop Auto-Scroll cleanly
  const stopAutoScroll = (pausedByManual = false) => {
    if (rafIdRef.current !== null) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }
    lastFrameTimeRef.current = null;
    virtualScrollTopRef.current = null;
    setIsAutoScrolling(false);
    setIsAutoScrollPausedByManual(pausedByManual);
    syncVisibleAyahFromScroll(true);
  };

  // Toggle Auto-Scroll on/off from current position
  const toggleAutoScroll = () => {
    if (isAutoScrolling) {
      stopAutoScroll(false);
      return;
    }

    // If user is on index or quiz tab, switch to Mushaf tab first
    if (activeTab === 'index' || activeTab === 'quiz') {
      setActiveTab('mushaf');
    }

    setShowAutoScrollControls(true);
    setIsAutoScrollPausedByManual(false);

    setTimeout(() => {
      const target = getActiveScrollContainer();
      if (target) {
        const isAtVeryBottom =
          target.scrollHeight > target.clientHeight + 4 &&
          target.scrollTop + target.clientHeight >= target.scrollHeight - 4;
        if (isAtVeryBottom) {
          target.scrollTop = 0;
          virtualScrollTopRef.current = 0;
        } else {
          virtualScrollTopRef.current = target.scrollTop;
        }
      }
      lastFrameTimeRef.current = null;
      setIsAutoScrolling(true);
    }, 20);
  };

  // Continuous smooth requestAnimationFrame loop
  useEffect(() => {
    if (!isAutoScrolling || loading || !surah) {
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
      return;
    }

    let isCancelled = false;

    const step = (timestamp: number) => {
      if (isCancelled) return;

      const target = getActiveScrollContainer();
      if (!target) {
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      // Do not fight manual touch while user's finger is on screen
      if (isUserTouchingRef.current) {
        lastFrameTimeRef.current = timestamp;
        virtualScrollTopRef.current = target.scrollTop;
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      if (lastFrameTimeRef.current === null) {
        lastFrameTimeRef.current = timestamp;
        if (virtualScrollTopRef.current === null) {
          virtualScrollTopRef.current = target.scrollTop;
        }
      }

      const dtSeconds = Math.min((timestamp - lastFrameTimeRef.current) / 1000, 0.1);
      lastFrameTimeRef.current = timestamp;

      const maxScrollTop = Math.max(0, target.scrollHeight - target.clientHeight);
      if (maxScrollTop <= 1) {
        // Content fits on screen without scrolling
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      const currentVirtual =
        virtualScrollTopRef.current !== null ? virtualScrollTopRef.current : target.scrollTop;

      // Sync if external scroll changed target.scrollTop significantly
      const baseTop =
        Math.abs(currentVirtual - target.scrollTop) > 8 ? target.scrollTop : currentVirtual;

      const nextTop = baseTop + autoScrollSpeedRef.current * dtSeconds;

      if (nextTop >= maxScrollTop - 0.5) {
        target.scrollTop = maxScrollTop;
        virtualScrollTopRef.current = maxScrollTop;
        setIsAutoScrolling(false);
        setIsAutoScrollPausedByManual(false);
        syncVisibleAyahFromScroll(true);
        showToast(`وصلت إلى نهاية سورة ${surah.name} — توقف التمرير التلقائي`);
        return;
      }

      virtualScrollTopRef.current = nextTop;
      target.scrollTop = nextTop;
      syncVisibleAyahFromScroll(false);

      rafIdRef.current = requestAnimationFrame(step);
    };

    rafIdRef.current = requestAnimationFrame(step);

    return () => {
      isCancelled = true;
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, [isAutoScrolling, loading, surah, activeTab]);

  // Stop Auto-Scroll when switching to non-reading tabs or opening modals, and cleanup on unmount
  useEffect(() => {
    if (activeTab === 'index' || activeTab === 'quiz') {
      if (isAutoScrolling) {
        stopAutoScroll(false);
      }
    }
  }, [activeTab]);

  useEffect(() => {
    if (selectedAyahForSheet || tafseerAyah || shareCardAyah || isBookmarksModalOpen) {
      if (isAutoScrolling) {
        stopAutoScroll(true);
      }
    }
  }, [selectedAyahForSheet, tafseerAyah, shareCardAyah, isBookmarksModalOpen]);

  useEffect(() => {
    return () => {
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, []);

  // Handlers for manual touch / wheel interaction on the reading surface
  const handleReaderTouchStart = (e: React.TouchEvent) => {
    isUserTouchingRef.current = true;
    if (e.touches && e.touches.length > 0) {
      touchStartYRef.current = e.touches[0].clientY;
    }
  };

  const handleReaderTouchMove = (e: React.TouchEvent) => {
    if (touchStartYRef.current !== null && e.touches && e.touches.length > 0) {
      const deltaY = Math.abs(e.touches[0].clientY - touchStartYRef.current);
      if (deltaY > 7 && isAutoScrolling) {
        // User started dragging manually -> pause auto-scroll immediately with zero resistance
        stopAutoScroll(true);
      }
    }
  };

  const handleReaderTouchEnd = () => {
    isUserTouchingRef.current = false;
    touchStartYRef.current = null;
    if (!isAutoScrolling) {
      syncVisibleAyahFromScroll(true);
    }
  };

  const handleReaderWheel = (e: React.WheelEvent) => {
    if (Math.abs(e.deltaY) > 1 && isAutoScrolling) {
      stopAutoScroll(true);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2400);
  };

  // Save font size & theme preferences
  const updateFontSize = (size: number) => {
    setFontSize(size);
    localStorage.setItem('rifq_quran_font_size', size.toString());
  };

  const updateThemeMode = (mode: 'beige' | 'white' | 'dark') => {
    setThemeMode(mode);
    localStorage.setItem('rifq_quran_theme', mode);
  };

  // Fetch full Surah text and details
  useEffect(() => {
    let isCancelled = false;
    setLoading(true);

    getSurahDetail(currentSurahNumber)
      .then((data) => {
        if (!isCancelled) {
          setSurah(data);
          setLoading(false);
          setRevealedAyahs({});

          // Save last read position automatically
          const targetAyahIndex = Math.max(0, (currentAyahNumber || 1) - 1);
          const targetAyahObj = data.ayahs[targetAyahIndex] || data.ayahs[0];
          saveLastRead({
            surahNumber: data.number,
            surahName: data.name,
            ayahNumber: targetAyahObj?.numberInSurah || 1,
            ayahText: targetAyahObj?.text || '',
            timestamp: Date.now(),
          });
          setLastRead(loadLastRead());

          // Scroll to target ayah if not 1
          if (currentAyahNumber > 1) {
            setTimeout(() => {
              const el = ayahElementsRef.current[currentAyahNumber];
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }, 300);
          }
        }
      })
      .catch((err) => {
        console.error('Error loading surah:', err);
        if (!isCancelled) {
          setLoading(false);
          showToast('تعذر تحميل السورة من المصدر، يرجى المحاولة مرة أخرى');
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [currentSurahNumber]);

  // Load continuous tafseer when switching to 'tafseer' tab
  useEffect(() => {
    if (activeTab !== 'tafseer' || !surah) return;

    let isMounted = true;
    setLoadingTafseerTab(true);

    const promises = surah.ayahs.map(async (ayah) => {
      try {
        const res = await getAyahTafseer(surah.number, ayah.numberInSurah, selectedTafseerType);
        return {
          ayahNum: ayah.numberInSurah,
          text: typeof res === 'string' ? res : res?.text || ayah.tafseer || '',
        };
      } catch {
        return { ayahNum: ayah.numberInSurah, text: ayah.tafseer || '' };
      }
    });

    Promise.all(promises)
      .then((results) => {
        if (!isMounted) return;
        const map: Record<number, string> = {};
        results.forEach((r) => {
          map[r.ayahNum] = r.text;
        });
        setTafseerList(map);
        setLoadingTafseerTab(false);
      })
      .catch(() => {
        if (isMounted) setLoadingTafseerTab(false);
      });

    return () => {
      isMounted = false;
    };
  }, [activeTab, surah, selectedTafseerType]);

  // Scroll smoothly to target ayah whenever Surah loads or when navigating from a Bookmark
  useEffect(() => {
    if (
      loading ||
      !surah ||
      surah.number !== currentSurahNumber ||
      (activeTab !== 'mushaf' && activeTab !== 'tafseer' && activeTab !== 'translation')
    ) {
      return;
    }

    const hasPendingJump = pendingScrollAyahRef.current !== null;
    const targetAyah = hasPendingJump ? pendingScrollAyahRef.current! : currentAyahNumber;
    if (!targetAyah) return;

    pendingScrollAyahRef.current = null;

    if (targetAyah > 1 || hasPendingJump) {
      const timer = setTimeout(() => {
        const el = ayahElementsRef.current[targetAyah];
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setHighlightedAyahNumber(targetAyah);
          setTimeout(() => {
            setHighlightedAyahNumber((prev) => (prev === targetAyah ? null : prev));
          }, 2800);
        }
      }, 180);
      return () => clearTimeout(timer);
    }
  }, [loading, surah, currentSurahNumber, activeTab]);

  // Select Surah from Index or Bookmark and jump directly to target Ayah
  const handleSelectSurahFromIndex = (surahNum: number, ayahNum = 1, fromBookmark = false) => {
    if (surahNum < 1 || surahNum > 114) return;
    if (isAutoScrolling) {
      stopAutoScroll(false);
    }
    setIsAutoScrollPausedByManual(false);
    pendingScrollAyahRef.current = fromBookmark || ayahNum > 1 ? ayahNum : null;
    setCurrentSurahNumber(surahNum);
    setCurrentAyahNumber(ayahNum);
    currentAyahNumberRef.current = ayahNum;

    if (activeTab === 'index' || activeTab === 'quiz' || !fromBookmark) {
      setActiveTab('mushaf');
    }

    const targetMeta = SURAH_LIST.find((s) => s.number === surahNum);
    if (fromBookmark && targetMeta) {
      showToast(`تم الانتقال إلى سورة ${targetMeta.name} — الآية ${ayahNum} 🔖`);
    }

    if (surah && surah.number === surahNum) {
      const targetAyahObj = surah.ayahs[Math.max(0, ayahNum - 1)] || surah.ayahs[0];
      if (targetAyahObj) {
        saveLastRead({
          surahNumber: surah.number,
          surahName: surah.name,
          ayahNumber: targetAyahObj.numberInSurah,
          ayahText: targetAyahObj.text,
          timestamp: Date.now(),
        });
        setLastRead(loadLastRead());
      }

      if (ayahNum === 1 && !fromBookmark) {
        if (mushafScrollContainerRef.current) {
          mushafScrollContainerRef.current.scrollTop = 0;
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        // Same surah already loaded: scroll directly to the target ayah and highlight it
        setTimeout(() => {
          const el = ayahElementsRef.current[ayahNum];
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setHighlightedAyahNumber(ayahNum);
            setTimeout(() => {
              setHighlightedAyahNumber((prev) => (prev === ayahNum ? null : prev));
            }, 2800);
          }
        }, 120);
      }
    }
  };

  // Toggle Bookmark for an ayah
  const handleToggleBookmark = (ayah: AyahItem, note?: string) => {
    if (!surah) return;
    const updated = toggleBookmark({
      surahNumber: surah.number,
      surahName: surah.name,
      ayahNumber: ayah.numberInSurah,
      ayahText: ayah.text,
      note,
    });
    setBookmarks(updated);
    const isNowBookmarked = updated.some(
      (b) => b.surahNumber === surah.number && b.ayahNumber === ayah.numberInSurah
    );
    showToast(isNowBookmarked ? 'تمت إضافة الآية للعلامات المرجعية 🔖' : 'تمت إزالة العلامة المرجعية');
  };

  const handleDeleteBookmarkById = (id: string) => {
    const updated = removeBookmarkById(id);
    setBookmarks(updated);
    showToast('تمت إزالة العلامة المرجعية');
  };

  const handleUpdateBookmarkNote = (surahNum: number, ayahNum: number, note: string) => {
    const updated = updateBookmarkNote(surahNum, ayahNum, note);
    setBookmarks(updated);
    showToast(note.trim() ? 'تم حفظ ملاحظة العلامة المرجعية ✨' : 'تم تحديث العلامة المرجعية');
  };

  const getAyahBookmark = (ayahNum: number): BookmarkItem | undefined => {
    return bookmarks.find((b) => b.surahNumber === currentSurahNumber && b.ayahNumber === ayahNum);
  };

  const isAyahBookmarked = (ayahNum: number) => {
    return Boolean(getAyahBookmark(ayahNum));
  };

  // Toggle Favorite Surah
  const handleToggleFavorite = (surahNum: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = toggleFavoriteSurah(surahNum);
    setFavorites(updated);
    showToast(
      updated.includes(surahNum) ? 'تمت إضافة السورة للمفضلة ⭐' : 'تمت إزالة السورة من المفضلة'
    );
  };

  // Copy Ayah Text
  const handleCopyAyah = (ayah: AyahItem) => {
    if (!surah) return;
    const text = `﴿ ${ayah.text} ﴾ [سورة ${surah.name}: ${ayah.numberInSurah}]`;
    navigator.clipboard.writeText(text);
    setCopiedAyahNumber(ayah.numberInSurah);
    showToast('تم نسخ الآية الكريمة بنجاح 📋');
    setTimeout(() => setCopiedAyahNumber(null), 2000);
  };

  // Jump to Ayah from bottom slider
  const handleJumpToAyah = (ayahNum: number) => {
    setCurrentAyahNumber(ayahNum);
    currentAyahNumberRef.current = ayahNum;
    const el = ayahElementsRef.current[ayahNum];
    if (el) {
      el.scrollIntoView({ behavior: isAutoScrolling ? 'auto' : 'smooth', block: 'center' });
      setTimeout(() => {
        const target = getActiveScrollContainer();
        if (target) {
          virtualScrollTopRef.current = target.scrollTop;
        }
        syncVisibleAyahFromScroll(true);
      }, 60);
    }
  };

  // Filtered Surahs for Interactive Index
  const filteredSurahs = useMemo(() => {
    return SURAH_LIST.filter((s) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        s.name.includes(q) ||
        s.number.toString() === q ||
        s.englishName.toLowerCase().includes(q);

      const matchesJuz = selectedJuzFilter === 'all' || s.juz === selectedJuzFilter;
      const matchesType = selectedTypeFilter === 'all' || s.revelationType === selectedTypeFilter;

      if (indexSubTab === 'favorites') {
        return matchesSearch && matchesJuz && matchesType && favorites.includes(s.number);
      }

      return matchesSearch && matchesJuz && matchesType;
    });
  }, [searchQuery, selectedJuzFilter, selectedTypeFilter, indexSubTab, favorites]);

  const currentMeta = SURAH_LIST.find((s) => s.number === currentSurahNumber);
  const currentJuz = surah?.juz || currentMeta?.juz || 1;
  const currentHizb = Math.min(60, Math.max(1, (currentJuz - 1) * 2 + 1));
  const isSurahFavorite = favorites.includes(currentSurahNumber);

  // Theme styling definitions
  const themeClasses = {
    beige: 'bg-[#F7F7FC] text-[#25263A]',
    white: 'bg-[#FFFFFF] text-[#25263A]',
    dark: 'bg-[#121212] text-[#E6E6F0]',
  }[themeMode];

  const pageContainerBg = {
    beige: 'bg-[#F7F7FC]',
    white: 'bg-[#FFFFFF]',
    dark: 'bg-[#181818]',
  }[themeMode];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${themeClasses} flex flex-col pb-36 select-none`} dir="rtl">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-2xl shadow-xl text-xs font-bold border border-amber-300/40 animate-fade-in flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【1】الشريط العلوي (App Bar)
          • خلفية بيضاء مع حد ذهبي رفيع أسفل
          • يمين: زر العودة للرئيسية + شارة "الجزء X"
          • وسط: 4 تبويبات واضحة ("فهرس السور"، "المصحف"، "التفسير"، "الترجمة")
          • يسار: السورة الحالية + التنقل السريع بين السور
      ───────────────────────────────────────────────────────────── */}
      <header
        className={`sticky top-0 z-40 px-3 md:px-6 py-2.5 border-b border-[#E6E6F0] backdrop-blur-md transition-colors ${
          themeMode === 'dark' ? 'bg-[#1A1A1A]/95 text-white' : 'bg-[#FFFFFF]/95 text-[#25263A]'
        } shadow-xs`}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
          {/* Right Section: Home Button + Juz Badge */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onNavigateHome}
              className="p-2 rounded-xl text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="العودة للرئيسية"
            >
              <RotateCcw className="w-5 h-5" />
            </button>

            <span className="px-2.5 py-1 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] text-[#5B5FEF] text-xs font-bold whitespace-nowrap hidden sm:inline-block">
              الجزء {currentJuz}
            </span>
          </div>

          {/* Center Section: 4 Main Tabs */}
          <div className="flex items-center bg-[#F7F7FC] dark:bg-white/10 p-1 rounded-2xl border border-[#E6E6F0] text-xs font-bold">
            {/* 1. Fast Interactive Index Tab */}
            <button
              onClick={() => setActiveTab('index')}
              className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'index'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>فهرس السور</span>
            </button>

            {/* 2. Continuous Mushaf Reading Tab */}
            <button
              onClick={() => setActiveTab('mushaf')}
              className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'mushaf'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              <span>المصحف</span>
            </button>

            {/* 3. Tafseer Tab */}
            <button
              onClick={() => setActiveTab('tafseer')}
              className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'tafseer'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              التفسير
            </button>

            {/* 4. Translation Tab */}
            <button
              onClick={() => setActiveTab('translation')}
              className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'translation'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              الترجمة
            </button>

            {/* 5. Quiz Tab (اختبر حفظك • التصفح التفاعلي) */}
            <button
              onClick={() => setActiveTab('quiz')}
              className={`px-2.5 sm:px-3.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'quiz'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              <InteractiveMushafSvg size={14} color={activeTab === 'quiz' ? '#FFFFFF' : '#E8B84A'} />
              <span>اختبر حفظك</span>
            </button>
          </div>

          {/* Left Section: Bookmarks Trigger + Surah Selector Pill + Prev/Next Buttons */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Quick Open Bookmarks Modal / Side Drawer Button */}
            <button
              type="button"
              onClick={() => setIsBookmarksModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-[#E6E6F0] bg-[#F7F7FC] dark:bg-white/10 hover:bg-[#EEEEFF] text-[#5B5FEF] text-xs font-bold transition-all cursor-pointer"
              title="عرض العلامات المرجعية المحفوظة"
            >
              <Bookmark className="w-3.5 h-3.5 fill-[#E8B84A] text-[#5B5FEF]" />
              <span className="hidden md:inline">العلامات</span>
              <span className="px-1.5 py-0.2 rounded-full bg-[#5B5FEF] text-white text-[10px] font-mono">
                {bookmarks.length}
              </span>
            </button>

            {/* Previous Surah button */}
            <button
              disabled={currentSurahNumber <= 1}
              onClick={() => handleSelectSurahFromIndex(currentSurahNumber - 1)}
              className="p-1.5 rounded-xl border border-[#E6E6F0] text-[#77798C] dark:text-gray-300 disabled:opacity-25 hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="السورة السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Active Surah Name Pill (Clicks to open index if in reading view) */}
            <button
              onClick={() => setActiveTab('index')}
              className="flex items-center gap-1 px-2 sm:px-3 py-1.5 rounded-xl border border-[#E6E6F0] bg-[#EEEEFF] hover:bg-[#EEEEFF] transition-all cursor-pointer"
              title="تغيير السورة من الفهرس"
            >
              <span className="text-xs md:text-sm font-bold font-amiri text-[#5B5FEF] block truncate max-w-[75px] sm:max-w-[110px]">
                سورة {surah?.name || currentMeta?.name}
              </span>
            </button>

            {/* Next Surah button */}
            <button
              disabled={currentSurahNumber >= 114}
              onClick={() => handleSelectSurahFromIndex(currentSurahNumber + 1)}
              className="p-1.5 rounded-xl border border-[#E6E6F0] text-[#77798C] dark:text-gray-300 disabled:opacity-25 hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="السورة التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* ─────────────────────────────────────────────────────────────
          【2】المحتوى الرئيسي
          • التبويب 1: الفهرس التفاعلي السريع (الانتقال المباشر لأي سورة قبل القراءة)
          • التبويب 2: المصحف (صفحة واحدة متصلة بتمرير رأسي)
          • التبويب 3: التفسير
          • التبويب 4: الترجمة
      ───────────────────────────────────────────────────────────── */}
      <main className="max-w-4xl w-full mx-auto px-3 md:px-6 py-4 flex-1">
        {/* ═════════════════════════════════════════════════════════════════
            TAB 1: الفهرس التفاعلي السريع (قبل البدء بالقراءة)
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'index' && (
          <div className="space-y-4 animate-fade-in">
            {/* 1.1 بطاقة المتابعة السريعة لآخر موضع قراءة */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-white via-white to-[#F7F7FC] dark:from-[#1F1F1F] dark:to-[#181818] p-4 sm:p-5 border-2 border-[#E6E6F0] shadow-sm">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#EEEEFF] rounded-full blur-xl pointer-events-none" />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#5B5FEF]">
                    <Clock className="w-4 h-4" />
                    <span>آخر موضع قرأت</span>
                  </div>
                  <h2 className="text-lg md:text-xl font-bold font-amiri text-[#25263A] dark:text-white">
                    سورة {lastRead.surahName} — الآية {lastRead.ayahNumber}
                  </h2>
                  {lastRead.ayahText && (
                    <p className="text-xs text-[#77798C] dark:text-gray-400 font-amiri line-clamp-1 max-w-md">
                      ﴿ {lastRead.ayahText} ﴾
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleSelectSurahFromIndex(lastRead.surahNumber, lastRead.ayahNumber)}
                  className="px-5 py-2.5 bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold rounded-2xl transition-all shadow-sm hover:shadow-md cursor-pointer flex items-center justify-center gap-2 text-xs sm:text-sm self-start sm:self-auto shrink-0"
                >
                  <span>متابعة القراءة</span>
                  <span className="text-base">←</span>
                </button>
              </div>
            </div>

            {/* 1.1b بطاقة اختبر حفظك — التصفح التفاعلي */}
            <div className="rounded-3xl bg-gradient-to-l from-[#25263A] via-[#25263A] to-[#25263A] p-4 sm:p-5 border border-[#E6E6F0] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-white/10 border border-[#E6E6F0] flex items-center justify-center shrink-0">
                  <InteractiveMushafSvg size={24} color="#E8B84A" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-[#E8B84A]">
                    اختبر حفظك — التصفح التفاعلي
                  </h3>
                  <p className="text-xs text-[#F7F7FC]/85 mt-0.5">
                    إكمال الحروف والكلمات القرآنية الناقصة بالرسم العثماني مع التصحيح الفوري والعمل دون إنترنت
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('quiz')}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-[#25263A] font-bold text-xs sm:text-sm cursor-pointer shrink-0 shadow-xs hover:brightness-105 transition-all"
              >
                بدء الاختبار التفاعلي ←
              </button>
            </div>

            {/* 1.2 شريط السور الشائعة للانتقال الفوري (Quick Surah Chips) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-[#5B5FEF]">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>انتقال سريع لسور شائعة:</span>
                </span>
                <span className="text-[11px] text-gray-400">نقرة واحدة لفتح السورة</span>
              </div>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1.5 no-scrollbar">
                {QUICK_SURAHS.map((qs) => {
                  const isCurrent = qs.number === currentSurahNumber;
                  return (
                    <button
                      key={qs.number}
                      onClick={() => handleSelectSurahFromIndex(qs.number)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                        isCurrent
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-white dark:bg-[#1A1A1A] text-[#25263A] dark:text-gray-200 border border-[#E6E6F0] hover:border-[#5B5FEF] hover:bg-[#EEEEFF]'
                      }`}
                    >
                      <span className="text-[10px] opacity-75 font-mono">#{qs.number}</span>
                      <span>سورة {qs.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 1.3 شريط البحث والتصفية السريعة */}
            <div className="space-y-3 bg-white dark:bg-[#1A1A1A] p-4 rounded-3xl border border-[#E6E6F0] shadow-xs">
              <div className="flex flex-col sm:flex-row items-center gap-2.5">
                {/* Search Bar */}
                <div className="relative w-full flex-1">
                  <Search className="w-4 h-4 text-[#5B5FEF] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث باسم السورة (مثال: الكهف، يس) أو رقمها..."
                    className="w-full bg-[#F7F7FC] dark:bg-white/5 pr-10 pl-10 py-2.5 rounded-2xl border border-[#E6E6F0] text-xs text-[#25263A] dark:text-white placeholder:text-gray-400 focus:outline-none focus:border-[#5B5FEF]"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#77798C]"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Sub-tabs: كل السور | المفضلة | الإشارات */}
                <div className="flex items-center gap-1 bg-[#F7F7FC] dark:bg-white/5 p-1 rounded-2xl border border-[#E6E6F0] text-xs font-bold w-full sm:w-auto shrink-0 justify-center">
                  <button
                    onClick={() => setIndexSubTab('all')}
                    className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                      indexSubTab === 'all'
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'text-[#77798C] hover:text-[#5B5FEF]'
                    }`}
                  >
                    السور (114)
                  </button>
                  <button
                    onClick={() => setIndexSubTab('favorites')}
                    className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                      indexSubTab === 'favorites'
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'text-[#77798C] hover:text-[#5B5FEF]'
                    }`}
                  >
                    <Star className="w-3.5 h-3.5" />
                    <span>المفضلة ({favorites.length})</span>
                  </button>
                  <button
                    onClick={() => setIndexSubTab('bookmarks')}
                    className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
                      indexSubTab === 'bookmarks'
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'text-[#77798C] hover:text-[#5B5FEF]'
                    }`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>الإشارات ({bookmarks.length})</span>
                  </button>
                </div>
              </div>

              {/* Filters for 'all' tab: (مكية/مدنية + كل الأجزاء 1-30) */}
              {indexSubTab === 'all' && (
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#E6E6F0]">
                  {/* Type Filter */}
                  <div className="flex gap-1 text-xs">
                    <button
                      onClick={() => setSelectedTypeFilter('all')}
                      className={`px-2.5 py-1 rounded-xl font-bold transition-all cursor-pointer ${
                        selectedTypeFilter === 'all'
                          ? 'bg-[#5B5FEF] text-white'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C]'
                      }`}
                    >
                      الكل
                    </button>
                    <button
                      onClick={() => setSelectedTypeFilter('Meccan')}
                      className={`px-2.5 py-1 rounded-xl font-bold transition-all cursor-pointer ${
                        selectedTypeFilter === 'Meccan'
                          ? 'bg-[#5B5FEF] text-white'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C]'
                      }`}
                    >
                      مكية 🕋
                    </button>
                    <button
                      onClick={() => setSelectedTypeFilter('Medinan')}
                      className={`px-2.5 py-1 rounded-xl font-bold transition-all cursor-pointer ${
                        selectedTypeFilter === 'Medinan'
                          ? 'bg-[#5B5FEF] text-white'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C]'
                      }`}
                    >
                      مدنية 🕌
                    </button>
                  </div>

                  {/* Juz Dropdown */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-bold text-[#77798C]">الجزء:</span>
                    <select
                      value={selectedJuzFilter}
                      onChange={(e) =>
                        setSelectedJuzFilter(e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10))
                      }
                      className="bg-[#F7F7FC] dark:bg-white/5 border border-[#E6E6F0] text-xs font-bold text-[#25263A] dark:text-gray-200 py-1 px-2.5 rounded-xl focus:outline-none"
                    >
                      <option value="all">جميع الأجزاء (1 - 30)</option>
                      {Array.from({ length: 30 }, (_, i) => (
                        <option key={i + 1} value={i + 1}>
                          الجزء {i + 1}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* 1.4 قائمة السور التفاعلية (114 سورة) */}
            {indexSubTab !== 'bookmarks' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {filteredSurahs.map((s) => {
                  const isCurrent = s.number === currentSurahNumber;
                  const isFav = favorites.includes(s.number);
                  const isBookmarkedInSurah = bookmarks.some((b) => b.surahNumber === s.number);

                  return (
                    <div
                      key={s.number}
                      onClick={() => handleSelectSurahFromIndex(s.number)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                        isCurrent
                          ? 'bg-[#EEEEFF] border-[#5B5FEF] shadow-xs ring-1 ring-[#5B5FEF]'
                          : 'bg-white dark:bg-[#1A1A1A] border-[#E6E6F0] hover:border-[#5B5FEF] hover:shadow-xs'
                      }`}
                    >
                      {/* Right: Decorated Number & Names */}
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-9 h-9 rounded-full border flex items-center justify-center font-mono text-xs font-bold shrink-0 transition-colors ${
                            isCurrent
                              ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                              : 'border-[#5B5FEF] text-[#5B5FEF] group-hover:bg-[#4145C7] group-hover:text-white'
                          }`}
                        >
                          {s.number}
                        </span>

                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5">
                            <h3 className="font-bold text-base font-amiri text-[#25263A] dark:text-white group-hover:text-[#5B5FEF] transition-colors">
                              سورة {s.name}
                            </h3>
                            {isBookmarkedInSurah && (
                              <Bookmark className="w-3 h-3 text-[#5B5FEF] fill-[#E8B84A]" title="يوجد إشارة مرجعية" />
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-[#77798C] dark:text-gray-400">
                            <span>{s.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}</span>
                            <span>•</span>
                            <span>{s.numberOfAyahs} آية</span>
                            <span>•</span>
                            <span>جزء {s.juz}</span>
                          </div>
                        </div>
                      </div>

                      {/* Left: Star Favorite button & Arrow */}
                      <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleToggleFavorite(s.number, e)}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isFav ? 'text-amber-500' : 'text-gray-300 hover:text-amber-500'
                          }`}
                          title={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                        >
                          <Star className={`w-4 h-4 ${isFav ? 'fill-amber-500' : ''}`} />
                        </button>
                        <span className="text-[#5B5FEF] text-sm opacity-60 group-hover:opacity-100 group-hover:translate-x-1 transition-all">
                          ←
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* 1.5 قائمة الإشارات المرجعية (Bookmarks Tab in Index) */}
            {indexSubTab === 'bookmarks' && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between bg-white dark:bg-[#1A1A1A] px-4 py-3 rounded-2xl border border-[#E6E6F0]">
                  <div className="flex items-center gap-2">
                    <Bookmark className="w-4 h-4 text-[#5B5FEF] fill-[#E8B84A]" />
                    <span className="text-xs font-bold text-[#25263A] dark:text-white">
                      جميع الآيات المحفوظة ({bookmarks.length})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsBookmarksModalOpen(true)}
                    className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold hover:bg-[#4145C7] transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Bookmark className="w-3.5 h-3.5 fill-[#E8B84A] text-[#E8B84A]" />
                    <span>فتح واجهة العلامات والفرز</span>
                  </button>
                </div>

                {bookmarks.length > 0 ? (
                  bookmarks.map((b) => (
                    <div
                      key={b.id}
                      onClick={() => handleSelectSurahFromIndex(b.surahNumber, b.ayahNumber, true)}
                      className="p-4 bg-white dark:bg-[#1A1A1A] rounded-2xl border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center justify-between cursor-pointer shadow-2xs transition-all"
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <Bookmark className="w-4 h-4 text-[#5B5FEF] fill-[#E8B84A]" />
                          <h4 className="font-bold text-sm text-[#5B5FEF] font-amiri">
                            سورة {b.surahName} — الآية {b.ayahNumber}
                          </h4>
                          <span className="text-[10px] text-gray-400">
                            {new Date(b.timestamp).toLocaleDateString('ar-SA')}
                          </span>
                        </div>
                        <p className="font-amiri text-sm text-[#25263A] dark:text-[#E6E6F0] line-clamp-1">
                          ﴿ {b.ayahText} ﴾
                        </p>
                      </div>

                      <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            const updated = bookmarks.filter((x) => x.id !== b.id);
                            setBookmarks(updated);
                            saveBookmarks(updated);
                            showToast('تمت إزالة الإشارة المرجعية');
                          }}
                          className="p-1.5 text-gray-300 hover:text-rose-500 rounded-lg"
                          title="حذف"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-16 bg-white dark:bg-[#1A1A1A] rounded-3xl border border-[#E6E6F0] p-6">
                    <Bookmark className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                    <p className="text-sm font-bold text-[#77798C]">لا توجد إشارات مرجعية محفوظة حالياً</p>
                    <p className="text-xs text-gray-400 mt-1">انقر على أي آية أثناء القراءة لحفظها كإشارة مرجعية 🔖</p>
                  </div>
                )}
              </div>
            )}

            {filteredSurahs.length === 0 && indexSubTab !== 'bookmarks' && (
              <div className="text-center py-16 bg-white dark:bg-[#1A1A1A] rounded-3xl border border-[#E6E6F0] p-6">
                <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                <p className="text-sm font-bold text-[#77798C]">لا توجد سور مطابقة لبحثك</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedJuzFilter('all');
                    setSelectedTypeFilter('all');
                  }}
                  className="mt-3 px-4 py-1.5 bg-[#5B5FEF] text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  إعادة ضبط البحث
                </button>
              </div>
            )}
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            TAB 2: المصحف (عرض السورة كاملة في صفحة واحدة متصلة بتمرير رأسي)
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'mushaf' && (
          <div className="space-y-4 animate-fade-in">
            {/* 2.1 شريط السور التفاعلي السريع أعلى صفحة المصحف مباشرة + زر التمرير التلقائي */}
            <div className="flex items-center justify-between gap-2 bg-white dark:bg-[#1A1A1A] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
              <button
                onClick={() => setActiveTab('index')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 hover:bg-[#4145C7] transition-colors cursor-pointer"
                title="فتح الفهرس الكامل"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>فهرس السور</span>
              </button>

              {/* Horizontal quick surah carousel */}
              <div
                ref={quickSurahsBarRef}
                className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 flex-1"
              >
                {SURAH_LIST.map((s) => {
                  const isCurrent = s.number === currentSurahNumber;
                  return (
                    <button
                      key={s.number}
                      onClick={() => handleSelectSurahFromIndex(s.number)}
                      className={`px-2.5 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 shrink-0 ${
                        isCurrent
                          ? 'bg-[#5B5FEF] text-white shadow-xs font-amiri'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] dark:text-gray-300 hover:text-[#5B5FEF]'
                      }`}
                    >
                      <span className="text-[10px] font-mono opacity-80">{s.number}.</span>
                      <span>{s.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* زر قائمة العلامات المرجعية */}
              <button
                type="button"
                onClick={() => setIsBookmarksModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-xs font-bold shrink-0 transition-all cursor-pointer"
                title="عرض قائمة العلامات المرجعية المحفوظة"
              >
                <Bookmark className="w-3.5 h-3.5 fill-[#E8B84A] text-[#5B5FEF]" />
                <span className="hidden sm:inline">العلامات</span>
                {bookmarks.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-[#5B5FEF] text-white text-[10px] font-mono">
                    {bookmarks.length}
                  </span>
                )}
              </button>

              {/* زر التمرير التلقائي المباشر أعلى المصحف */}
              <button
                onClick={toggleAutoScroll}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer border ${
                  isAutoScrolling
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500 shadow-xs'
                    : 'bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#5B5FEF] hover:text-white border-[#5B5FEF]/30'
                }`}
                title={isAutoScrolling ? 'إيقاف التمرير التلقائي' : 'بدء التمرير التلقائي الناعم'}
              >
                {isAutoScrolling ? (
                  <>
                    <Pause className="w-3.5 h-3.5 fill-current" />
                    <span>إيقاف التمرير</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>التمرير التلقائي</span>
                  </>
                )}
              </button>
            </div>

            {/* 2.2 الحاوية المتصلة لصفحة المصحف */}
            {loading ? (
              <div className="py-32 flex flex-col items-center justify-center gap-3">
                <div className="w-10 h-10 border-4 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
                <span className="text-xs text-[#77798C] font-bold">جارِ تحميل نص السورة الكريمة...</span>
              </div>
            ) : surah ? (
              <div
                className={`relative rounded-3xl p-5 md:p-8 transition-colors shadow-sm ${pageContainerBg} border-2 border-[#5B5FEF]`}
              >
                {/* الإطار الذهبي المزدوج الناعم حول الصفحة */}
                <div className="absolute inset-2 border border-[#E6E6F0] rounded-2xl pointer-events-none" />

                {/* ترويسة السورة (Surah Header Banner) */}
                <div className="text-center mb-6 pt-2">
                  <div className="inline-block relative">
                    <div className="bg-white dark:bg-[#202020] px-8 py-3 rounded-2xl border-[3px] border-[#5B5FEF] shadow-sm flex items-center justify-center gap-3 min-w-[260px] md:min-w-[340px]">
                      {/* الزخارف النباتية الإسلامية */}
                      <span className="text-[#5B5FEF] text-lg select-none">❁ ❁</span>

                      <h1 className="text-2xl md:text-3xl font-black font-amiri tracking-wide text-[#5B5FEF]">
                        سُورَةُ {surah.name}
                      </h1>

                      <span className="text-[#5B5FEF] text-lg select-none">❁ ❁</span>
                    </div>

                    {/* معلومات السورة: مكان النزول • عدد الآيات • الجزء */}
                    <div className="mt-2 flex items-center justify-center gap-2 text-xs text-[#77798C] dark:text-gray-400 font-semibold">
                      <span>{surah.revelationType === 'Meccan' ? 'مكية 🕋' : 'مدنية 🕌'}</span>
                      <span>•</span>
                      <span>{surah.numberOfAyahs} آيات</span>
                      <span>•</span>
                      <span>الجزء {surah.juz}</span>
                    </div>
                  </div>

                  {/* البسملة الشريفة بخط Amiri كبير بني غامق في المنتصف بدون إطار */}
                  {surah.bismillahPre && (
                    <div
                      className={`mt-6 mb-4 font-amiri text-2xl md:text-3xl font-bold tracking-wider text-center select-none ${
                        themeMode === 'dark' ? 'text-[#E6E6F0]' : 'text-[#25263A]'
                      }`}
                    >
                      بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                    </div>
                  )}
                </div>

                {/* نص السورة الكامل متصل كصفحة مصحف واحدة بتمرير رأسي */}
                <div
                  ref={mushafScrollContainerRef}
                  onScroll={() => {
                    if (!isAutoScrolling) {
                      syncVisibleAyahFromScroll(false);
                    }
                  }}
                  onTouchStart={handleReaderTouchStart}
                  onTouchMove={handleReaderTouchMove}
                  onTouchEnd={handleReaderTouchEnd}
                  onTouchCancel={handleReaderTouchEnd}
                  onWheel={handleReaderWheel}
                  className={`overflow-y-auto max-h-[72vh] ${
                    isAutoScrolling ? '' : 'scroll-smooth'
                  } leading-[2.2] text-justify text-center sm:text-justify selection:bg-[#EEEEFF] selection:text-current px-2 md:px-4 py-2`}
                  style={{
                    fontSize: `${fontSize}px`,
                    lineHeight: '2.2',
                    fontFamily: 'Amiri, serif',
                  }}
                >
                  {surah.ayahs.map((ayah) => {
                    const isRevealed = revealedAyahs[ayah.numberInSurah];
                    const ayahBookmark = getAyahBookmark(ayah.numberInSurah);
                    const isBookmarked = Boolean(ayahBookmark);
                    const isHighlighted = highlightedAyahNumber === ayah.numberInSurah;

                    return (
                      <React.Fragment key={ayah.numberInSurah}>
                        {/* نص الآية (يتدفق متصلاً بالآية السابقة واللاحقة) */}
                        <span
                          ref={(el) => (ayahElementsRef.current[ayah.numberInSurah] = el)}
                          onClick={() => setSelectedAyahForSheet(ayah)}
                          className={`inline cursor-pointer transition-all duration-300 rounded px-1 -mx-0.5 hover:bg-[#EEEEFF] active:bg-[#EEEEFF] ${
                            isHighlighted
                              ? 'bg-amber-200/80 dark:bg-amber-500/30 ring-2 ring-[#E8B84A] shadow-xs'
                              : isBookmarked
                              ? 'bg-[#EEEEFF] dark:bg-[#5B5FEF]/25 border-b-2 border-[#E8B84A]'
                              : ''
                          }`}
                          title={
                            ayahBookmark?.note
                              ? `علامة مرجعية: ${ayahBookmark.note}`
                              : isBookmarked
                              ? 'آية محفوظة في العلامات المرجعية — انقر للخيارات'
                              : 'انقر لحفظ علامة مرجعية أو عرض التفسير'
                          }
                        >
                          {isHideMode && !isRevealed ? (
                            <span
                              onClick={(e) => {
                                e.stopPropagation();
                                setRevealedAyahs((prev) => ({
                                  ...prev,
                                  [ayah.numberInSurah]: true,
                                }));
                              }}
                              className="inline-block bg-[#EEEEFF] text-transparent select-none rounded px-2 py-0.5 my-0.5 border border-dashed border-[#E6E6F0] hover:bg-[#4145C7]/30 cursor-pointer"
                              title="انقر لإظهار الآية"
                            >
                              {ayah.text}
                            </span>
                          ) : (
                            <span>{ayah.text}</span>
                          )}
                        </span>

                        {/* رقم الآية مدمج داخل نفس السطر كرمز دائري مزخرف ﴿١﴾ مع شارة العلامة المرجعية */}
                        <span
                          onClick={() => setSelectedAyahForSheet(ayah)}
                          className="inline-flex items-center justify-center align-middle mx-1.5 cursor-pointer select-none group relative"
                          title={`الآية ${ayah.numberInSurah} - انقر للخيارات`}
                        >
                          <span
                            className={`inline-flex items-center justify-center rounded-full border font-sans font-bold shadow-2xs transition-colors ${
                              isBookmarked
                                ? 'bg-[#5B5FEF] text-white border-[#E8B84A] ring-2 ring-[#E8B84A]/50'
                                : 'border-[#5B5FEF] text-[#5B5FEF] group-hover:bg-[#4145C7] group-hover:text-white'
                            }`}
                            style={{
                              width: `${Math.max(22, fontSize * 0.95)}px`,
                              height: `${Math.max(22, fontSize * 0.95)}px`,
                              fontSize: `${Math.max(10, fontSize * 0.42)}px`,
                            }}
                          >
                            {ayah.numberInSurah}
                          </span>
                          {isBookmarked && (
                            <Bookmark className="w-3 h-3 text-[#E8B84A] fill-[#E8B84A] absolute -top-1.5 -left-1 drop-shadow-xs" />
                          )}
                        </span>
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            TAB 3: التفسير المتصل لكامل السورة
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'tafseer' && surah && (
          <div className="space-y-4 animate-fade-in">
            {/* Tafseer Selector */}
            <div className="flex items-center justify-between bg-white dark:bg-[#1A1A1A] p-2.5 rounded-2xl border border-[#E6E6F0]">
              <span className="text-xs font-bold text-[#5B5FEF]">اختر كتاب التفسير:</span>
              <div className="flex gap-1 overflow-x-auto no-scrollbar">
                {(Object.keys(TAFSEER_CONFIG) as TafseerType[]).map((type) => (
                  <button
                    key={type}
                    onClick={() => setSelectedTafseerType(type)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      selectedTafseerType === type
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'text-[#77798C] hover:text-[#5B5FEF]'
                    }`}
                  >
                    {TAFSEER_CONFIG[type].name}
                  </button>
                ))}
              </div>
            </div>

            {loadingTafseerTab && (
              <div className="py-20 flex flex-col items-center justify-center gap-2">
                <div className="w-8 h-8 border-3 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
                <span className="text-xs text-[#77798C]">جارِ جلب التفسير المعتمد...</span>
              </div>
            )}

            {!loadingTafseerTab && (
              <div
                className="space-y-3"
                onTouchStart={handleReaderTouchStart}
                onTouchMove={handleReaderTouchMove}
                onTouchEnd={handleReaderTouchEnd}
                onTouchCancel={handleReaderTouchEnd}
                onWheel={handleReaderWheel}
              >
                {surah.ayahs.map((ayah) => (
                  <div
                    key={ayah.numberInSurah}
                    ref={(el) => {
                      if (activeTab === 'tafseer') {
                        ayahElementsRef.current[ayah.numberInSurah] = el;
                      }
                    }}
                    className={`p-4 bg-white dark:bg-[#1A1A1A] rounded-2xl border shadow-2xs space-y-2 transition-all duration-300 ${
                      highlightedAyahNumber === ayah.numberInSurah
                        ? 'border-[#E8B84A] ring-2 ring-[#E8B84A] bg-amber-50/30 dark:bg-amber-500/10'
                        : 'border-[#E6E6F0]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-[#5B5FEF] font-bold border-b border-[#E6E6F0] pb-1.5">
                      <span>الآية {ayah.numberInSurah}</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleToggleBookmark(ayah)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                            isAyahBookmarked(ayah.numberInSurah)
                              ? 'bg-[#5B5FEF] text-white'
                              : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] hover:text-[#5B5FEF]'
                          }`}
                          title={
                            isAyahBookmarked(ayah.numberInSurah)
                              ? 'إزالة العلامة المرجعية'
                              : 'حفظ علامة مرجعية للآية'
                          }
                        >
                          <Bookmark
                            className={`w-3.5 h-3.5 ${
                              isAyahBookmarked(ayah.numberInSurah) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                            }`}
                          />
                          <span>{isAyahBookmarked(ayah.numberInSurah) ? 'محفوظة' : 'حفظ علامة'}</span>
                        </button>
                        <button
                          onClick={() => handleCopyAyah(ayah)}
                          className="p-1.5 text-gray-400 hover:text-[#5B5FEF] cursor-pointer"
                          title="نسخ"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] leading-relaxed">
                      ﴿ {ayah.text} ﴾
                    </p>
                    <p className="text-xs md:text-sm text-[#77798C] dark:text-gray-300 leading-relaxed pt-1">
                      {tafseerList[ayah.numberInSurah] || ayah.tafseer || 'جاري تحميل التفسير...'}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            TAB 4: الترجمة المتصلة لكامل السورة
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'translation' && surah && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center justify-between bg-white dark:bg-[#1A1A1A] p-2.5 rounded-2xl border border-[#E6E6F0]">
              <span className="text-xs font-bold text-[#5B5FEF]">اختر لغة الترجمة:</span>
              <div className="flex gap-1">
                {[
                  { id: 'en', label: '🇬🇧 English (Saheeh)' },
                  { id: 'fr', label: '🇫🇷 Français (Hamidullah)' },
                  { id: 'ur', label: '🇵🇰 اردو (جالندھری)' },
                ].map((lang) => (
                  <button
                    key={lang.id}
                    onClick={() => setTransLang(lang.id as 'en' | 'fr' | 'ur')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      transLang === lang.id
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'text-[#77798C] hover:text-[#5B5FEF]'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            <div
              className="space-y-3"
              onTouchStart={handleReaderTouchStart}
              onTouchMove={handleReaderTouchMove}
              onTouchEnd={handleReaderTouchEnd}
              onTouchCancel={handleReaderTouchEnd}
              onWheel={handleReaderWheel}
            >
              {surah.ayahs.map((ayah) => {
                const transText =
                  transLang === 'en'
                    ? ayah.translationEn
                    : transLang === 'fr'
                    ? ayah.translationFr
                    : ayah.translationUr;

                return (
                  <div
                    key={ayah.numberInSurah}
                    ref={(el) => {
                      if (activeTab === 'translation') {
                        ayahElementsRef.current[ayah.numberInSurah] = el;
                      }
                    }}
                    className={`p-4 bg-white dark:bg-[#1A1A1A] rounded-2xl border shadow-2xs space-y-2 transition-all duration-300 ${
                      highlightedAyahNumber === ayah.numberInSurah
                        ? 'border-[#E8B84A] ring-2 ring-[#E8B84A] bg-amber-50/30 dark:bg-amber-500/10'
                        : 'border-[#E6E6F0]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-[#5B5FEF] font-bold border-b border-[#E6E6F0] pb-1.5">
                      <span>الآية {ayah.numberInSurah}</span>
                      <button
                        type="button"
                        onClick={() => handleToggleBookmark(ayah)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                          isAyahBookmarked(ayah.numberInSurah)
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] hover:text-[#5B5FEF]'
                        }`}
                        title={
                          isAyahBookmarked(ayah.numberInSurah)
                            ? 'إزالة العلامة المرجعية'
                            : 'حفظ علامة مرجعية للآية'
                        }
                      >
                        <Bookmark
                          className={`w-3.5 h-3.5 ${
                            isAyahBookmarked(ayah.numberInSurah) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                          }`}
                        />
                        <span>{isAyahBookmarked(ayah.numberInSurah) ? 'محفوظة' : 'حفظ علامة'}</span>
                      </button>
                    </div>
                    <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] text-right leading-relaxed">
                      ﴿ {ayah.text} ﴾
                    </p>
                    <p
                      className={`text-xs md:text-sm text-[#77798C] dark:text-gray-300 leading-relaxed pt-1 ${
                        transLang === 'ur' ? 'text-right font-amiri text-base' : 'text-left font-sans'
                      }`}
                      dir={transLang === 'ur' ? 'rtl' : 'ltr'}
                    >
                      {transText || 'Translation requires internet connection on first load.'}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            TAB 5: اختبر حفظك (التصفح التفاعلي واختبارات الحفظ)
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'quiz' && (
          <QuizView
            onBack={() => setActiveTab('index')}
            onQuizComplete={() => {
              showToast('تم حفظ نتيجة الاختبار بنجاح');
            }}
          />
        )}
      </main>

      {/* ─────────────────────────────────────────────────────────────
          【3】الشريط السفلي (Bottom Bar)
          • ⚙️ الإعدادات (تغيير حجم الخط، الثيم)
          • 🔖 علامة الموضع الحالي
          • 👁️ وضع الإخفاء (تسميع)
          • 🏷️ شارة الحزب (حزب X)
          • 🎚️ شريط التمرير السريع بين آيات السورة
      ───────────────────────────────────────────────────────────── */}
      {surah && !loading && (
        <footer className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#1A1A1A]/95 backdrop-blur-md border-t border-[#E6E6F0] px-4 py-2.5 shadow-lg">
          <div className="max-w-3xl mx-auto space-y-2">
            {/* ─────────────────────────────────────────────────────────
                📖 لوحة التحكم في التمرير التلقائي والسرعة (تظهر عند التفعيل أو فتح إعدادات السرعة)
            ───────────────────────────────────────────────────────── */}
            {(isAutoScrolling || isAutoScrollPausedByManual || showAutoScrollControls) && (
              <div className="p-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 border border-[#5B5FEF]/30 space-y-2 animate-fade-in">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  {/* الحالة الحالية للتمرير */}
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                        isAutoScrolling
                          ? 'bg-emerald-500 animate-pulse shadow-xs shadow-emerald-500/50'
                          : isAutoScrollPausedByManual
                          ? 'bg-amber-500'
                          : 'bg-gray-400'
                      }`}
                    />
                    <span className="text-[11px] sm:text-xs font-bold text-[#25263A] dark:text-white">
                      {isAutoScrolling
                        ? 'التمرير التلقائي يعمل حاليًا'
                        : isAutoScrollPausedByManual
                        ? 'توقف مؤقتًا بسبب التفاعل اليدوي — يمكنك الاستئناف من نفس الموضع'
                        : 'إعدادات سرعة التمرير التلقائي'}
                    </span>
                  </div>

                  {/* أزرار السرعات الجاهزة (بطيء / متوسط / سريع) + إغلاق اللوحة */}
                  <div className="flex items-center gap-1">
                    {AUTO_SCROLL_PRESETS.map((preset) => {
                      const isPresetActive = getActiveSpeedPreset(autoScrollSpeed) === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => updateAutoScrollSpeed(preset.speed)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                            isPresetActive
                              ? 'bg-[#5B5FEF] text-white shadow-2xs'
                              : 'bg-white dark:bg-white/10 text-[#77798C] dark:text-gray-300 border border-[#E6E6F0] hover:border-[#5B5FEF]'
                          }`}
                        >
                          {preset.label}
                        </button>
                      );
                    })}

                    {!isAutoScrolling && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowAutoScrollControls(false);
                          setIsAutoScrollPausedByManual(false);
                        }}
                        className="p-1 rounded-lg text-gray-400 hover:text-[#77798C] mr-1 cursor-pointer"
                        title="إخفاء شريط السرعة"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Slider للتحكم الدقيق في السرعة */}
                <div className="flex items-center gap-2.5 pt-0.5">
                  <Gauge className="w-3.5 h-3.5 text-[#5B5FEF] shrink-0" />
                  <span className="text-[11px] text-[#77798C] dark:text-gray-400 font-bold shrink-0">
                    السرعة:
                  </span>
                  <button
                    type="button"
                    onClick={() => updateAutoScrollSpeed(autoScrollSpeed - 3)}
                    className="w-6 h-6 rounded-lg bg-white dark:bg-white/10 border border-[#E6E6F0] text-[#5B5FEF] font-bold text-xs flex items-center justify-center hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                    title="إبطاء السرعة"
                  >
                    -
                  </button>
                  <input
                    type="range"
                    min={8}
                    max={60}
                    step={1}
                    value={autoScrollSpeed}
                    onChange={(e) => updateAutoScrollSpeed(parseInt(e.target.value, 10))}
                    className="w-full accent-[#5B5FEF] h-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={() => updateAutoScrollSpeed(autoScrollSpeed + 3)}
                    className="w-6 h-6 rounded-lg bg-white dark:bg-white/10 border border-[#E6E6F0] text-[#5B5FEF] font-bold text-xs flex items-center justify-center hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                    title="زيادة السرعة"
                  >
                    +
                  </button>
                  <span className="text-[11px] font-bold text-[#5B5FEF] font-mono min-w-[34px] text-left shrink-0">
                    {Math.round((autoScrollSpeed / 26) * 10) / 10}x
                  </span>
                </div>
              </div>
            )}

            {/* Jump Slider */}
            <div className="flex items-center gap-3">
              <span className="text-[11px] font-bold text-[#5B5FEF] font-mono shrink-0">
                آية {currentAyahNumber} / {surah.numberOfAyahs}
              </span>
              <input
                type="range"
                min={1}
                max={surah.numberOfAyahs}
                value={currentAyahNumber}
                onChange={(e) => handleJumpToAyah(parseInt(e.target.value, 10))}
                className="w-full accent-[#E8B84A] h-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
              />
              <span className="text-[11px] font-bold text-gray-400 font-mono shrink-0">
                حزب {currentHizb}
              </span>
            </div>

            {/* Quick Action Tools */}
            <div className="flex items-center justify-between gap-1.5 pt-1 overflow-x-auto no-scrollbar">
              {/* Auto-Scroll Play / Stop Button */}
              <button
                type="button"
                onClick={toggleAutoScroll}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  isAutoScrolling
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500 shadow-xs'
                    : isAutoScrollPausedByManual
                    ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-500 shadow-xs'
                    : 'bg-[#EEEEFF] text-[#5B5FEF] border-[#5B5FEF]/30 hover:bg-[#5B5FEF] hover:text-white'
                }`}
                title={isAutoScrolling ? 'إيقاف التمرير التلقائي في نفس الموضع' : 'بدء التمرير التلقائي من الموضع الحالي'}
              >
                {isAutoScrolling ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>إيقاف التمرير</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>التمرير التلقائي</span>
                  </>
                )}
              </button>

              {/* Settings Toggle */}
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E6E6F0] text-xs font-bold text-[#5B5FEF] hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                title="إعدادات الخط والثيم"
              >
                <Settings className="w-4 h-4" />
                <span>الإعدادات</span>
              </button>

              {/* Memorization Mode Toggle */}
              <button
                onClick={() => {
                  setIsHideMode(!isHideMode);
                  showToast(!isHideMode ? 'تم تفعيل وضع التسميع 👁️' : 'تم إيقاف وضع التسميع');
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E6E6F0] text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  isHideMode
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : 'text-[#5B5FEF] hover:bg-[#EEEEFF]'
                }`}
                title="وضع الإخفاء لحفظ وتسميع الآيات"
              >
                {isHideMode ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                <span>وضع الإخفاء</span>
              </button>

              {/* Bookmark Current Ayah */}
              <button
                onClick={() => {
                  const currentAyah = surah.ayahs[Math.min(currentAyahNumber - 1, surah.ayahs.length - 1)];
                  if (currentAyah) handleToggleBookmark(currentAyah);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shrink-0 ${
                  isAyahBookmarked(currentAyahNumber)
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                    : 'border-[#E6E6F0] text-[#5B5FEF] hover:bg-[#EEEEFF]'
                }`}
                title="حفظ الآية الحالية في العلامات المرجعية"
              >
                <Bookmark
                  className={`w-4 h-4 ${
                    isAyahBookmarked(currentAyahNumber) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                  }`}
                />
                <span>{isAyahBookmarked(currentAyahNumber) ? 'محفوظة' : 'حفظ علامة'}</span>
              </button>

              {/* Open Saved Bookmarks List Modal */}
              <button
                type="button"
                onClick={() => setIsBookmarksModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E6E6F0] bg-[#F7F7FC] dark:bg-white/5 text-xs font-bold text-[#5B5FEF] hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                title="عرض قائمة العلامات المرجعية للعودة إليها"
              >
                <Bookmark className="w-4 h-4 fill-[#E8B84A] text-[#5B5FEF]" />
                <span>العلامات ({bookmarks.length})</span>
              </button>

              {/* Interactive Index Tab Trigger */}
              <button
                onClick={() => setActiveTab('index')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
                  activeTab === 'index'
                    ? 'bg-[#E8B84A] text-white shadow-xs'
                    : 'bg-[#5B5FEF] text-white shadow-xs hover:bg-[#4145C7]'
                }`}
                title="الانتقال لفهرس السور"
              >
                <BookOpen className="w-4 h-4" />
                <span>فهرس السور</span>
              </button>
            </div>
          </div>
        </footer>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【4】نافذة الخيارات التفاعلية للآية (Ayah Action Bottom Sheet)
      ───────────────────────────────────────────────────────────── */}
      {selectedAyahForSheet && surah && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end justify-center p-0 md:p-4 animate-fade-in">
          <div
            className="w-full max-w-lg bg-white dark:bg-[#1E1E1E] rounded-t-3xl md:rounded-3xl border-t-2 md:border-2 border-[#5B5FEF] p-5 space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Sheet Header */}
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-full bg-[#EEEEFF] border border-[#5B5FEF] text-[#5B5FEF] text-xs font-bold flex items-center justify-center">
                  {selectedAyahForSheet.numberInSurah}
                </span>
                <h3 className="font-bold text-sm text-[#5B5FEF] font-amiri">
                  سورة {surah.name} — الآية {selectedAyahForSheet.numberInSurah}
                </h3>
              </div>
              <button
                onClick={() => setSelectedAyahForSheet(null)}
                className="p-1.5 rounded-xl text-gray-400 hover:text-[#77798C] hover:bg-gray-100 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Verse Text Snippet */}
            <div className="p-3.5 bg-[#F7F7FC] dark:bg-white/5 rounded-2xl border border-[#E6E6F0] max-h-36 overflow-y-auto">
              <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] leading-relaxed text-center">
                ﴿ {selectedAyahForSheet.text} ﴾
              </p>
            </div>

            {/* Actions Grid */}
            <div className="grid grid-cols-3 gap-2.5 pt-1">
              {/* Copy */}
              <button
                onClick={() => {
                  handleCopyAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#25263A] dark:text-gray-200 border border-[#E6E6F0] transition-all cursor-pointer"
              >
                <Copy className="w-5 h-5 text-[#5B5FEF]" />
                <span className="text-xs font-bold">نسخ الآية</span>
              </button>

              {/* Bookmark */}
              <button
                onClick={() => {
                  handleToggleBookmark(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className={`flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl border border-[#E6E6F0] transition-all cursor-pointer ${
                  isAyahBookmarked(selectedAyahForSheet.numberInSurah)
                    ? 'bg-[#5B5FEF] text-white'
                    : 'bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#25263A] dark:text-gray-200'
                }`}
              >
                <Bookmark className="w-5 h-5" />
                <span className="text-xs font-bold">
                  {isAyahBookmarked(selectedAyahForSheet.numberInSurah) ? 'محفوظة' : 'حفظ موضع'}
                </span>
              </button>

              {/* Tafseer */}
              <button
                onClick={() => {
                  setTafseerAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#25263A] dark:text-gray-200 border border-[#E6E6F0] transition-all cursor-pointer"
              >
                <BookOpen className="w-5 h-5 text-[#5B5FEF]" />
                <span className="text-xs font-bold">التفسير</span>
              </button>

              {/* Share as Card */}
              <button
                onClick={() => {
                  setShareCardAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#25263A] dark:text-gray-200 border border-[#E6E6F0] transition-all cursor-pointer"
              >
                <Share2 className="w-5 h-5 text-[#5B5FEF]" />
                <span className="text-xs font-bold">بطاقة مشاركة</span>
              </button>

              {/* Favorite Surah */}
              <button
                onClick={() => {
                  handleToggleFavorite(surah.number);
                  setSelectedAyahForSheet(null);
                }}
                className={`flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl border border-[#E6E6F0] transition-all cursor-pointer ${
                  isSurahFavorite
                    ? 'bg-amber-500 text-white'
                    : 'bg-[#F7F7FC] dark:bg-white/5 hover:bg-[#EEEEFF] text-[#25263A] dark:text-gray-200'
                }`}
              >
                <Star className="w-5 h-5" />
                <span className="text-xs font-bold">
                  {isSurahFavorite ? 'مفضلة' : 'تفضيل السورة'}
                </span>
              </button>

              {/* Close */}
              <button
                onClick={() => setSelectedAyahForSheet(null)}
                className="flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 text-[#77798C] border border-[#E6E6F0] dark:border-gray-700 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
                <span className="text-xs font-bold">إغلاق</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【5】نافذة الإعدادات (Settings Modal)
      ───────────────────────────────────────────────────────────── */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-[#1E1E1E] rounded-3xl border-2 border-[#5B5FEF] p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#5B5FEF]" />
                <h3 className="font-bold text-base text-[#5B5FEF]">إعدادات المصحف</h3>
              </div>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-[#77798C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Font Size Slider */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#77798C] dark:text-gray-300">
                <span>حجم خط المصحف</span>
                <span className="font-mono text-[#5B5FEF]">{fontSize}px</span>
              </div>
              <input
                type="range"
                min={20}
                max={36}
                value={fontSize}
                onChange={(e) => updateFontSize(parseInt(e.target.value, 10))}
                className="w-full accent-[#E8B84A] h-2 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
              />
              <div className="p-3 bg-[#F7F7FC] dark:bg-white/5 rounded-xl text-center">
                <span style={{ fontSize: `${fontSize}px`, fontFamily: 'Amiri, serif' }}>
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </span>
              </div>
            </div>

            {/* Theme Mode Selector */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-[#77798C] dark:text-gray-300 block">
                مظهر صفحة المصحف
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => updateThemeMode('beige')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    themeMode === 'beige'
                      ? 'border-[#5B5FEF] bg-[#F7F7FC] text-[#25263A] ring-2 ring-[#5B5FEF]/30'
                      : 'border-[#E6E6F0] bg-[#F7F7FC]/50 text-[#77798C]'
                  }`}
                >
                  ورقي بيج
                </button>
                <button
                  onClick={() => updateThemeMode('white')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    themeMode === 'white'
                      ? 'border-[#5B5FEF] bg-white text-[#25263A] ring-2 ring-[#5B5FEF]/30'
                      : 'border-[#E6E6F0] bg-white/50 text-[#77798C]'
                  }`}
                >
                  أبيض ناصع
                </button>
                <button
                  onClick={() => updateThemeMode('dark')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    themeMode === 'dark'
                      ? 'border-[#5B5FEF] bg-[#121212] text-white ring-2 ring-[#5B5FEF]/30'
                      : 'border-gray-700 bg-[#121212]/50 text-gray-400'
                  }`}
                >
                  ليلي
                </button>
              </div>
            </div>

            {/* Auto-Scroll Speed Setting in Modal */}
            <div className="space-y-2 border-t border-[#E6E6F0] pt-4">
              <div className="flex items-center justify-between text-xs font-bold text-[#77798C] dark:text-gray-300">
                <span>سرعة التمرير التلقائي</span>
                <span className="font-mono text-[#5B5FEF]">
                  {AUTO_SCROLL_PRESETS.find((p) => p.id === getActiveSpeedPreset(autoScrollSpeed))?.label} (
                  {Math.round((autoScrollSpeed / 26) * 10) / 10}x)
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {AUTO_SCROLL_PRESETS.map((preset) => {
                  const isActive = getActiveSpeedPreset(autoScrollSpeed) === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => updateAutoScrollSpeed(preset.speed)}
                      className={`py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        isActive
                          ? 'border-[#5B5FEF] bg-[#5B5FEF] text-white shadow-xs'
                          : 'border-[#E6E6F0] bg-[#F7F7FC] dark:bg-white/5 text-[#77798C]'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>
              <input
                type="range"
                min={8}
                max={60}
                step={1}
                value={autoScrollSpeed}
                onChange={(e) => updateAutoScrollSpeed(parseInt(e.target.value, 10))}
                className="w-full accent-[#5B5FEF] h-2 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
              />
            </div>

            <button
              onClick={() => setIsSettingsOpen(false)}
              className="w-full py-2.5 bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              تم
            </button>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【6】نافذة التفسير الشامل المنبثقة (Tafseer Modal)
      ───────────────────────────────────────────────────────────── */}
      <TafseerModal
        isOpen={!!tafseerAyah}
        onClose={() => setTafseerAyah(null)}
        surahNumber={currentSurahNumber}
        surahName={surah?.name || ''}
        ayah={tafseerAyah}
      />

      {/* ─────────────────────────────────────────────────────────────
          【7】نافذة بطاقة المشاركة للآية (Verse Card Modal)
      ───────────────────────────────────────────────────────────── */}
      <VerseCardModal
        isOpen={!!shareCardAyah}
        onClose={() => setShareCardAyah(null)}
        surahName={surah?.name || ''}
        ayah={shareCardAyah}
      />

      {/* ─────────────────────────────────────────────────────────────
          【8】نافذة / واجهة قائمة العلامات المرجعية (Bookmarks Modal & Side Drawer)
      ───────────────────────────────────────────────────────────── */}
      <BookmarksModal
        isOpen={isBookmarksModalOpen}
        onClose={() => setIsBookmarksModalOpen(false)}
        bookmarks={bookmarks}
        onSelectBookmark={(surahNum, ayahNum) => {
          handleSelectSurahFromIndex(surahNum, ayahNum, true);
        }}
        onDeleteBookmark={handleDeleteBookmarkById}
        onUpdateBookmarkNote={handleUpdateBookmarkNote}
        readerThemeMode={themeMode}
        currentSurahNumber={currentSurahNumber}
        currentAyahNumber={currentAyahNumber}
        isCurrentAyahBookmarked={isAyahBookmarked(currentAyahNumber)}
        onBookmarkCurrentAyah={() => {
          if (!surah) return;
          const currentAyahObj =
            surah.ayahs[Math.min(currentAyahNumber - 1, surah.ayahs.length - 1)] || surah.ayahs[0];
          if (currentAyahObj) {
            handleToggleBookmark(currentAyahObj);
          }
        }}
      />
    </div>
  );
};
