import React, { useState } from 'react';
import { 
  Trophy, 
  Calendar, 
  CheckCircle2, 
  Plus, 
  RotateCcw, 
  BookOpen, 
  Award,
  Sparkles
} from 'lucide-react';
import { KhatmahTracker, SURAH_LIST } from '../../data/quranData';
import { saveKhatmah } from '../../utils/quranService';
import confetti from 'canvas-confetti';

interface KhatmahTrackerViewProps {
  tracker: KhatmahTracker;
  onUpdateTracker: (updated: KhatmahTracker) => void;
  onSelectSurah: (surahNumber: number) => void;
}

export const KhatmahTrackerView: React.FC<KhatmahTrackerViewProps> = ({
  tracker,
  onUpdateTracker,
  onSelectSurah,
}) => {
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [targetDays, setTargetDays] = useState(tracker.targetDays || 30);

  // Total ayahs in the Quran is 6,236
  const TOTAL_AYAHS = 6236;
  const percentage = Math.min(100, Math.round((tracker.completedAyahsCount / TOTAL_AYAHS) * 100));

  const handleMarkSurahRead = (surahNumber: number) => {
    const isAlreadyRead = tracker.readSurahs.includes(surahNumber);
    const surahMeta = SURAH_LIST.find((s) => s.number === surahNumber);
    const ayahsCount = surahMeta ? surahMeta.numberOfAyahs : 10;

    let updatedSurahs: number[];
    let updatedAyahsCount: number;

    if (isAlreadyRead) {
      updatedSurahs = tracker.readSurahs.filter((n) => n !== surahNumber);
      updatedAyahsCount = Math.max(0, tracker.completedAyahsCount - ayahsCount);
    } else {
      updatedSurahs = [...tracker.readSurahs, surahNumber];
      updatedAyahsCount = Math.min(TOTAL_AYAHS, tracker.completedAyahsCount + ayahsCount);

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#5B5FEF', '#E8B84A', '#FFD700'],
      });
    }

    // Calculate current Juz based on latest read surah
    const lastSurah = SURAH_LIST.find((s) => s.number === Math.max(1, ...updatedSurahs));
    const newJuz = lastSurah ? lastSurah.juz : 1;

    const updated: KhatmahTracker = {
      ...tracker,
      readSurahs: updatedSurahs,
      completedAyahsCount: updatedAyahsCount,
      currentJuz: newJuz,
      currentSurahNumber: lastSurah ? lastSurah.number : 1,
    };

    onUpdateTracker(updated);
    saveKhatmah(updated);
  };

  const handleQuickAdvanceJuz = () => {
    const nextJuz = Math.min(30, tracker.currentJuz + 1);
    const surahsInJuz = SURAH_LIST.filter((s) => s.juz <= nextJuz).map((s) => s.number);
    const totalAyahs = SURAH_LIST.filter((s) => s.juz <= nextJuz).reduce((acc, s) => acc + s.numberOfAyahs, 0);

    const updated: KhatmahTracker = {
      ...tracker,
      currentJuz: nextJuz,
      readSurahs: Array.from(new Set([...tracker.readSurahs, ...surahsInJuz])),
      completedAyahsCount: Math.min(TOTAL_AYAHS, totalAyahs),
    };

    onUpdateTracker(updated);
    saveKhatmah(updated);

    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#5B5FEF', '#E8B84A'],
    });
  };

  const handleResetKhatmah = () => {
    if (window.confirm('هل تريد بدء ختمة جديدة ومباركة وتصفير السجل الحالي؟')) {
      const reset: KhatmahTracker = {
        startDate: new Date().toISOString().split('T')[0],
        targetDays: 30,
        currentJuz: 1,
        currentSurahNumber: 1,
        completedAyahsCount: 0,
        readSurahs: [],
        notes: 'ختمة جديدة مباركة',
      };
      onUpdateTracker(reset);
      saveKhatmah(reset);
    }
  };

  // Calculate days since start
  const startDate = new Date(tracker.startDate || new Date().toISOString());
  const today = new Date();
  const diffDays = Math.max(1, Math.ceil((today.getTime() - startDate.getTime()) / (1000 * 3600 * 24)));
  const daysRemaining = Math.max(0, (tracker.targetDays || 30) - diffDays);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Khatmah Hero Card */}
      <div className="relative bg-gradient-to-br from-[#5B5FEF] via-[#4CAF82] to-[#4CAF82] rounded-3xl p-6 text-white shadow-xl overflow-hidden border border-[#E6E6F0]">
        {/* Background Islamic Pattern Decors */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-[#EEEEFF] rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-right">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 rounded-full text-xs text-amber-200 border border-white/15">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>متابعة ختمة القرآن الكريم</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-black font-amiri text-amber-300">
              «خيركم من تعلم القرآن وعلمه»
            </h2>
            <p className="text-xs md:text-sm text-emerald-100 max-w-md leading-relaxed">
              واصل قراءة وردك القرآني اليومي ودوّن تقدمك في ختمة كتاب الله المبارك.
            </p>
          </div>

          {/* Radial Progress Circle */}
          <div className="relative w-32 h-32 flex items-center justify-center shrink-0">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="rgba(255,255,255,0.15)"
                strokeWidth="10"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="#5B5FEF"
                strokeWidth="10"
                strokeDasharray="251.2"
                strokeDashoffset={251.2 - (251.2 * percentage) / 100}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-2xl font-black text-white font-mono">{percentage}%</span>
              <span className="text-[10px] text-amber-200">نسبة الختمة</span>
            </div>
          </div>
        </div>

        {/* Stats strip inside card */}
        <div className="mt-6 pt-5 border-t border-white/15 grid grid-cols-3 gap-2 text-center">
          <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-xs">
            <span className="text-[11px] text-emerald-200 block">الجزء الحالي</span>
            <strong className="text-base md:text-lg font-black text-white font-mono">
              {tracker.currentJuz} / 30
            </strong>
          </div>
          <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-xs">
            <span className="text-[11px] text-emerald-200 block">السور المنجزة</span>
            <strong className="text-base md:text-lg font-black text-white font-mono">
              {tracker.readSurahs.length} / 114
            </strong>
          </div>
          <div className="bg-white/10 rounded-2xl p-2.5 backdrop-blur-xs">
            <span className="text-[11px] text-emerald-200 block">الأيام المتبقية</span>
            <strong className="text-base md:text-lg font-black text-white font-mono">
              {daysRemaining} يوم
            </strong>
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={handleQuickAdvanceJuz}
          className="flex-1 py-3 px-4 bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white font-bold text-xs md:text-sm rounded-2xl shadow-xs flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4 text-amber-300" />
          <span>تم إتمام جزء كامل ({tracker.currentJuz})</span>
        </button>

        <button
          onClick={() => setShowGoalModal(true)}
          className="py-3 px-4 bg-white border border-[#E6E6F0] hover:bg-[#EEEEFF] text-[#4145C7] font-bold text-xs md:text-sm rounded-2xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Calendar className="w-4 h-4 text-[#5B5FEF]" />
          <span>تحديد مدة الختمة</span>
        </button>

        <button
          onClick={handleResetKhatmah}
          title="بدء ختمة جديدة"
          className="p-3 bg-white border border-[#E6E6F0] hover:bg-red-50 text-gray-400 hover:text-red-500 rounded-2xl transition-colors cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Surahs Checklist Grid */}
      <div className="bg-white rounded-3xl p-5 shadow-xs border border-[#E6E6F0]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#5B5FEF]" />
            <h3 className="font-bold text-[#4145C7] text-base">سجل السور المقروءة في هذه الختمة</h3>
          </div>
          <span className="text-xs text-[#77798C] font-medium">
            انقر على السورة لتسجيل إتمامها
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-[420px] overflow-y-auto pr-1">
          {SURAH_LIST.map((surah) => {
            const isRead = tracker.readSurahs.includes(surah.number);
            return (
              <div
                key={surah.number}
                className={`p-2.5 rounded-xl border transition-all flex items-center justify-between text-xs cursor-pointer select-none ${
                  isRead
                    ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-[#4145C7] font-bold'
                    : 'bg-gray-50/70 border-[#E6E6F0] text-gray-700 hover:bg-[#F7F7FC] hover:border-[#E6E6F0]'
                }`}
                onClick={() => handleMarkSurahRead(surah.number)}
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <span className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] shrink-0 font-mono ${
                    isRead ? 'bg-[#5B5FEF] text-white' : 'bg-white border text-[#77798C]'
                  }`}>
                    {surah.number}
                  </span>
                  <span className="truncate font-amiri text-sm">{surah.name}</span>
                </div>

                <div className="flex items-center gap-1">
                  {isRead ? (
                    <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
                  ) : (
                    <span className="w-3.5 h-3.5 rounded-full border border-gray-300 shrink-0" />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Goal Modal */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => setShowGoalModal(false)} />
          <div className="relative w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl z-10 space-y-4">
            <h3 className="font-bold text-lg text-[#4145C7] text-center">تحديد هدف الختمة</h3>
            <p className="text-xs text-[#77798C] text-center leading-relaxed">
              اختر عدد الأيام المستهدفة لإنهاء ختمة القرآن الكريم كاملة:
            </p>

            <div className="grid grid-cols-3 gap-2">
              {[15, 30, 60].map((d) => (
                <button
                  key={d}
                  onClick={() => setTargetDays(d)}
                  className={`py-3 rounded-2xl font-bold text-xs transition-all cursor-pointer ${
                    targetDays === d
                      ? 'bg-[#5B5FEF] text-white shadow-xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {d} يوماً
                </button>
              ))}
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => {
                  const updated = { ...tracker, targetDays };
                  onUpdateTracker(updated);
                  saveKhatmah(updated);
                  setShowGoalModal(false);
                }}
                className="flex-1 py-2.5 bg-[#5B5FEF] text-white font-bold rounded-xl text-xs"
              >
                حفظ الهدف
              </button>
              <button
                onClick={() => setShowGoalModal(false)}
                className="px-4 py-2.5 bg-gray-100 text-[#77798C] font-bold rounded-xl text-xs"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
