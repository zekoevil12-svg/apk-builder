import React, { useState, useMemo, useEffect } from 'react';
import {
  Bookmark,
  X,
  Search,
  Trash2,
  ArrowLeft,
  Clock,
  BookOpen,
  Edit3,
  Check,
  Tag,
  PanelRight,
  Maximize2,
  Sparkles,
  Plus,
} from 'lucide-react';
import { BookmarkItem, SURAH_LIST } from '../../data/quranData';
import { useTheme } from '../../context/ThemeContext';

interface BookmarksModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarks: BookmarkItem[];
  onSelectBookmark: (surahNumber: number, ayahNumber: number) => void;
  onDeleteBookmark: (id: string) => void;
  onUpdateBookmarkNote: (surahNumber: number, ayahNumber: number, note: string) => void;
  readerThemeMode?: 'beige' | 'white' | 'dark';
  currentSurahNumber?: number;
  currentAyahNumber?: number;
  onBookmarkCurrentAyah?: () => void;
  isCurrentAyahBookmarked?: boolean;
}

const QUICK_NOTE_TAGS = ['ورد القراءة اليومي', 'موضع الحفظ', 'مراجعة', 'آية للتدبر'];

export const BookmarksModal: React.FC<BookmarksModalProps> = ({
  isOpen,
  onClose,
  bookmarks,
  onSelectBookmark,
  onDeleteBookmark,
  onUpdateBookmarkNote,
  readerThemeMode = 'beige',
  currentSurahNumber,
  currentAyahNumber,
  onBookmarkCurrentAyah,
  isCurrentAyahBookmarked = false,
}) => {
  const { theme, isDark: globalIsDark } = useTheme();

  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'surah'>('recent');
  const [scopeFilter, setScopeFilter] = useState<'all' | 'currentSurah'>('all');
  const [layoutMode, setLayoutMode] = useState<'drawer' | 'modal'>(() => {
    const saved = localStorage.getItem('rifq_bookmarks_view_mode');
    return saved === 'modal' || saved === 'drawer' ? saved : 'drawer';
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState('');

  // Close on Escape key
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const toggleLayoutMode = () => {
    const next = layoutMode === 'drawer' ? 'modal' : 'drawer';
    setLayoutMode(next);
    localStorage.setItem('rifq_bookmarks_view_mode', next);
  };

  // Resolve active theme tokens combining global RIFQ theme + Quran reader themeMode
  const effectiveIsDark = globalIsDark || readerThemeMode === 'dark';
  const activeTokens = effectiveIsDark
    ? theme.definition.darkTokens
    : theme.definition.lightTokens;

  // Harmonize surface colors with readerThemeMode ('beige' | 'white' | 'dark') and global RIFQ theme
  const surfaceBg = effectiveIsDark
    ? activeTokens.surface
    : readerThemeMode === 'beige'
    ? `color-mix(in srgb, ${activeTokens.surface} 78%, #FAF5E8)`
    : activeTokens.surface;

  const secondaryBg = effectiveIsDark
    ? activeTokens.backgroundSecondary
    : readerThemeMode === 'beige'
    ? `color-mix(in srgb, ${activeTokens.background} 80%, #F4EFE0)`
    : activeTokens.background;

  const cardElevatedBg = effectiveIsDark
    ? activeTokens.surfaceElevated
    : readerThemeMode === 'beige'
    ? `color-mix(in srgb, ${activeTokens.surfaceElevated} 85%, #FDFBF5)`
    : activeTokens.surfaceElevated;

  const currentSurahMeta = useMemo(
    () => (currentSurahNumber ? SURAH_LIST.find((s) => s.number === currentSurahNumber) : undefined),
    [currentSurahNumber]
  );

  const currentSurahBookmarksCount = useMemo(() => {
    if (!currentSurahNumber) return 0;
    return bookmarks.filter((b) => b.surahNumber === currentSurahNumber).length;
  }, [bookmarks, currentSurahNumber]);

  const filteredAndSortedBookmarks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = bookmarks.filter((b) => {
      if (scopeFilter === 'currentSurah' && currentSurahNumber && b.surahNumber !== currentSurahNumber) {
        return false;
      }
      if (!q) return true;
      return (
        b.surahName.toLowerCase().includes(q) ||
        b.ayahText.toLowerCase().includes(q) ||
        b.ayahNumber.toString() === q ||
        b.surahNumber.toString() === q ||
        (b.note && b.note.toLowerCase().includes(q))
      );
    });

    if (sortBy === 'surah') {
      return [...list].sort((a, b) => {
        if (a.surahNumber !== b.surahNumber) return a.surahNumber - b.surahNumber;
        return a.ayahNumber - b.ayahNumber;
      });
    }

    return [...list].sort((a, b) => b.timestamp - a.timestamp);
  }, [bookmarks, searchQuery, sortBy, scopeFilter, currentSurahNumber]);

  if (!isOpen) return null;

  const startEditingNote = (b: BookmarkItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(b.id);
    setNoteDraft(b.note || '');
  };

  const saveEditingNote = (b: BookmarkItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    onUpdateBookmarkNote(b.surahNumber, b.ayahNumber, noteDraft);
    setEditingId(null);
    setNoteDraft('');
  };

  const handleJumpToBookmark = (surahNum: number, ayahNum: number) => {
    onSelectBookmark(surahNum, ayahNum);
    onClose();
  };

  // Scoped CSS custom properties ensure full compatibility with global RIFQ theme rules in index.css
  const scopedThemeStyle: React.CSSProperties = {
    '--theme-surface': surfaceBg,
    '--theme-surface-elevated': cardElevatedBg,
    '--theme-background': secondaryBg,
    '--theme-background-secondary': activeTokens.backgroundSecondary,
    '--theme-primary': activeTokens.primary,
    '--theme-primary-light': activeTokens.primaryLight,
    '--theme-primary-dark': activeTokens.primaryDark,
    '--theme-secondary': activeTokens.secondary,
    '--theme-accent': activeTokens.accent,
    '--theme-text': activeTokens.text,
    '--theme-text-secondary': activeTokens.textSecondary,
    '--theme-text-muted': activeTokens.textMuted,
    '--theme-border': activeTokens.border,
    '--theme-input-bg': activeTokens.inputBg,
    '--theme-input-border': activeTokens.inputBorder,
    backgroundColor: surfaceBg,
    color: activeTokens.text,
    borderColor: activeTokens.primary,
  } as React.CSSProperties;

  return (
    <div
      className={`fixed inset-0 z-50 backdrop-blur-xs flex animate-fade-in ${
        layoutMode === 'drawer'
          ? 'items-stretch justify-start'
          : 'items-end sm:items-center justify-center p-0 sm:p-4'
      }`}
      style={{ backgroundColor: activeTokens.overlay }}
      dir="rtl"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="قائمة العلامات المرجعية للقرآن الكريم"
    >
      <aside
        style={scopedThemeStyle}
        className={`flex flex-col overflow-hidden shadow-2xl transition-all duration-300 ${
          layoutMode === 'drawer'
            ? 'w-full sm:w-[430px] md:w-[470px] h-full border-l-2 animate-slide-in-right'
            : 'w-full max-w-xl max-h-[88vh] rounded-t-3xl sm:rounded-3xl border-t-2 sm:border-2'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ─────────────────────────────────────────────────────────────
            Header: Title, Count Badge, View Mode Switcher (Drawer / Modal), Close
        ───────────────────────────────────────────────────────────── */}
        <div
          className="px-4 sm:px-5 py-3.5 border-b flex items-center justify-between gap-2 shrink-0"
          style={{
            backgroundColor: secondaryBg,
            borderColor: activeTokens.border,
          }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0 shadow-2xs"
              style={{
                backgroundColor: activeTokens.primaryLight,
                borderColor: `color-mix(in srgb, ${activeTokens.primary} 35%, transparent)`,
              }}
            >
              <Bookmark
                className="w-5 h-5"
                style={{ color: activeTokens.primary, fill: activeTokens.accent }}
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3
                  className="font-bold text-sm sm:text-base truncate"
                  style={{ color: activeTokens.text }}
                >
                  العلامات المرجعية المحفوظة
                </h3>
                <span
                  className="px-2 py-0.5 rounded-full text-[11px] font-bold font-mono shadow-2xs"
                  style={{
                    backgroundColor: activeTokens.primary,
                    color: activeTokens.buttonText,
                  }}
                >
                  {bookmarks.length}
                </span>
              </div>
              <p
                className="text-[11px] truncate mt-0.5"
                style={{ color: activeTokens.textSecondary }}
              >
                اضغط على أي آية محفوظة للانتقال المباشر إلى موضعها في القارئ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {/* Toggle between Side Drawer (واجهة جانبية) and Centered Modal (نافذة منبثقة) */}
            <button
              type="button"
              onClick={toggleLayoutMode}
              className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-[11px] font-bold transition-all cursor-pointer"
              style={{
                backgroundColor: surfaceBg,
                borderColor: activeTokens.border,
                color: activeTokens.textSecondary,
              }}
              title={
                layoutMode === 'drawer'
                  ? 'التبديل إلى وضع النافذة المنبثقة (Modal)'
                  : 'التبديل إلى وضع الواجهة الجانبية (Side Drawer)'
              }
            >
              {layoutMode === 'drawer' ? (
                <>
                  <Maximize2 className="w-3.5 h-3.5" style={{ color: activeTokens.primary }} />
                  <span>نافذة منبثقة</span>
                </>
              ) : (
                <>
                  <PanelRight className="w-3.5 h-3.5" style={{ color: activeTokens.primary }} />
                  <span>واجهة جانبية</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl border transition-colors cursor-pointer"
              style={{
                backgroundColor: surfaceBg,
                borderColor: activeTokens.border,
                color: activeTokens.textSecondary,
              }}
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ─────────────────────────────────────────────────────────────
            Quick Current Reading Position Banner (Bookmark Current Ayah or Status)
        ───────────────────────────────────────────────────────────── */}
        {currentSurahNumber && currentAyahNumber && onBookmarkCurrentAyah && (
          <div
            className="px-4 py-2.5 border-b flex items-center justify-between gap-2 shrink-0"
            style={{
              backgroundColor: activeTokens.primaryLight,
              borderColor: activeTokens.border,
            }}
          >
            <div className="flex items-center gap-2 min-w-0">
              <Sparkles className="w-4 h-4 shrink-0" style={{ color: activeTokens.primary }} />
              <span className="text-xs font-bold truncate" style={{ color: activeTokens.text }}>
                موضعك الحالي: سورة {currentSurahMeta?.name || currentSurahNumber} — الآية{' '}
                {currentAyahNumber}
              </span>
            </div>

            <button
              type="button"
              onClick={onBookmarkCurrentAyah}
              className="px-3 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer shrink-0 shadow-2xs"
              style={
                isCurrentAyahBookmarked
                  ? {
                      backgroundColor: surfaceBg,
                      color: activeTokens.primary,
                      border: `1px solid ${activeTokens.primary}`,
                    }
                  : {
                      backgroundColor: activeTokens.primary,
                      color: activeTokens.buttonText,
                    }
              }
            >
              {isCurrentAyahBookmarked ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>محفوظة في العلامات</span>
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  <span>حفظ الموضع الحالي</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            Search, Scope Filter & Sort Controls
        ───────────────────────────────────────────────────────────── */}
        {bookmarks.length > 0 && (
          <div
            className="p-3.5 border-b space-y-2.5 shrink-0"
            style={{
              backgroundColor: surfaceBg,
              borderColor: activeTokens.border,
            }}
          >
            {/* Search Input */}
            <div className="relative w-full">
              <Search
                className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                style={{ color: activeTokens.primary }}
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث باسم السورة، نص الآية، رقمها، أو الملاحظة..."
                className="w-full pr-9 pl-8 py-2 rounded-xl border text-xs focus:outline-none transition-colors"
                style={{
                  backgroundColor: secondaryBg,
                  borderColor: activeTokens.border,
                  color: activeTokens.text,
                }}
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 cursor-pointer"
                  style={{ color: activeTokens.textMuted }}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Filter & Sort Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              {/* Scope Filter: All vs Current Surah */}
              <div
                className="flex items-center gap-1 p-1 rounded-xl border text-[11px] font-bold"
                style={{
                  backgroundColor: secondaryBg,
                  borderColor: activeTokens.border,
                }}
              >
                <button
                  type="button"
                  onClick={() => setScopeFilter('all')}
                  className="px-2.5 py-1 rounded-lg transition-all cursor-pointer"
                  style={
                    scopeFilter === 'all'
                      ? {
                          backgroundColor: activeTokens.primary,
                          color: activeTokens.buttonText,
                        }
                      : {
                          color: activeTokens.textSecondary,
                        }
                  }
                >
                  كل العلامات ({bookmarks.length})
                </button>
                {currentSurahNumber && (
                  <button
                    type="button"
                    onClick={() => setScopeFilter('currentSurah')}
                    className="px-2.5 py-1 rounded-lg transition-all cursor-pointer"
                    style={
                      scopeFilter === 'currentSurah'
                        ? {
                            backgroundColor: activeTokens.primary,
                            color: activeTokens.buttonText,
                          }
                        : {
                            color: activeTokens.textSecondary,
                          }
                    }
                  >
                    سورة {currentSurahMeta?.name} ({currentSurahBookmarksCount})
                  </button>
                )}
              </div>

              {/* Sort Controls: Recent vs Surah Order */}
              <div
                className="flex items-center gap-1 p-1 rounded-xl border text-[11px] font-bold"
                style={{
                  backgroundColor: secondaryBg,
                  borderColor: activeTokens.border,
                }}
              >
                <button
                  type="button"
                  onClick={() => setSortBy('recent')}
                  className="px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1"
                  style={
                    sortBy === 'recent'
                      ? {
                          backgroundColor: activeTokens.primary,
                          color: activeTokens.buttonText,
                        }
                      : {
                          color: activeTokens.textSecondary,
                        }
                  }
                >
                  <Clock className="w-3 h-3" />
                  <span>الأحدث</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSortBy('surah')}
                  className="px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-1"
                  style={
                    sortBy === 'surah'
                      ? {
                          backgroundColor: activeTokens.primary,
                          color: activeTokens.buttonText,
                        }
                      : {
                          color: activeTokens.textSecondary,
                        }
                  }
                >
                  <BookOpen className="w-3 h-3" />
                  <span>ترتيب المصحف</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            Bookmarks List Body (Scrollable)
        ───────────────────────────────────────────────────────────── */}
        <div
          className="flex-1 overflow-y-auto p-3.5 sm:p-4 space-y-3"
          style={{ backgroundColor: surfaceBg }}
        >
          {filteredAndSortedBookmarks.length > 0 ? (
            filteredAndSortedBookmarks.map((b) => {
              const surahMeta = SURAH_LIST.find((s) => s.number === b.surahNumber);
              const isEditingThis = editingId === b.id;
              const isCurrentPosition =
                currentSurahNumber === b.surahNumber && currentAyahNumber === b.ayahNumber;

              return (
                <div
                  key={b.id}
                  onClick={() => {
                    if (!isEditingThis) {
                      handleJumpToBookmark(b.surahNumber, b.ayahNumber);
                    }
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (!isEditingThis && (e.key === 'Enter' || e.key === ' ')) {
                      e.preventDefault();
                      handleJumpToBookmark(b.surahNumber, b.ayahNumber);
                    }
                  }}
                  className="group p-3.5 sm:p-4 rounded-2xl border transition-all duration-200 cursor-pointer space-y-2.5 shadow-2xs hover:shadow-md"
                  style={{
                    backgroundColor: isCurrentPosition ? activeTokens.primaryLight : secondaryBg,
                    borderColor: isCurrentPosition ? activeTokens.primary : activeTokens.border,
                  }}
                >
                  {/* Top Row: Surah & Ayah Badge + Metadata + Edit/Delete Actions */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold font-amiri shadow-2xs"
                        style={{
                          backgroundColor: activeTokens.primary,
                          color: activeTokens.buttonText,
                        }}
                      >
                        <Bookmark
                          className="w-3.5 h-3.5 shrink-0"
                          style={{ color: activeTokens.accent, fill: activeTokens.accent }}
                        />
                        <span>
                          سورة {b.surahName} — الآية {b.ayahNumber}
                        </span>
                      </span>

                      {surahMeta && (
                        <span
                          className="px-2 py-0.5 rounded-lg border text-[11px] font-bold"
                          style={{
                            backgroundColor: surfaceBg,
                            borderColor: activeTokens.border,
                            color: activeTokens.textSecondary,
                          }}
                        >
                          الجزء {surahMeta.juz} • {surahMeta.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}
                        </span>
                      )}

                      {isCurrentPosition && (
                        <span
                          className="px-2 py-0.5 rounded-lg text-[10px] font-bold"
                          style={{
                            backgroundColor: activeTokens.accent,
                            color: '#1E2035',
                          }}
                        >
                          موضع القراءة الحالي
                        </span>
                      )}
                    </div>

                    {/* Action Buttons (Edit Note, Delete) */}
                    <div
                      className="flex items-center gap-1 shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={(e) => startEditingNote(b, e)}
                        className="p-1.5 rounded-xl border transition-colors cursor-pointer"
                        style={{
                          backgroundColor: surfaceBg,
                          borderColor: activeTokens.border,
                          color: activeTokens.textSecondary,
                        }}
                        title="إضافة أو تعديل ملاحظة على العلامة"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteBookmark(b.id);
                        }}
                        className="p-1.5 rounded-xl border transition-colors cursor-pointer hover:bg-rose-500/10"
                        style={{
                          backgroundColor: surfaceBg,
                          borderColor: activeTokens.border,
                          color: activeTokens.error,
                        }}
                        title="حذف العلامة المرجعية"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Ayah Uthmani Text Preview */}
                  <div
                    className="p-3 rounded-xl border transition-colors"
                    style={{
                      backgroundColor: cardElevatedBg,
                      borderColor: activeTokens.border,
                    }}
                  >
                    <p
                      className="font-amiri text-base sm:text-lg leading-relaxed line-clamp-3 text-right"
                      style={{ color: activeTokens.text }}
                    >
                      ﴿ {b.ayahText} ﴾
                    </p>
                  </div>

                  {/* Note Display or Inline Note Editor + Direct Jump Call-To-Action */}
                  {isEditingThis ? (
                    <div
                      className="p-3 rounded-xl border space-y-2.5"
                      style={{
                        backgroundColor: surfaceBg,
                        borderColor: activeTokens.primary,
                      }}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span
                          className="text-[11px] font-bold flex items-center gap-1"
                          style={{ color: activeTokens.primary }}
                        >
                          <Tag className="w-3 h-3" />
                          <span>وسوم سريعة:</span>
                        </span>
                        {QUICK_NOTE_TAGS.map((tag) => {
                          const isSelectedTag = noteDraft === tag;
                          return (
                            <button
                              key={tag}
                              type="button"
                              onClick={() => setNoteDraft(tag)}
                              className="px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer"
                              style={
                                isSelectedTag
                                  ? {
                                      backgroundColor: activeTokens.primary,
                                      color: activeTokens.buttonText,
                                      borderColor: activeTokens.primary,
                                    }
                                  : {
                                      backgroundColor: secondaryBg,
                                      color: activeTokens.textSecondary,
                                      borderColor: activeTokens.border,
                                    }
                              }
                            >
                              {tag}
                            </button>
                          );
                        })}
                      </div>

                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={noteDraft}
                          onChange={(e) => setNoteDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              saveEditingNote(b);
                            }
                          }}
                          placeholder="اكتب ملاحظة للعلامة المرجعية (اختياري)..."
                          className="flex-1 px-3 py-1.5 rounded-xl border text-xs focus:outline-none"
                          style={{
                            backgroundColor: secondaryBg,
                            borderColor: activeTokens.border,
                            color: activeTokens.text,
                          }}
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={(e) => saveEditingNote(b, e)}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
                          style={{
                            backgroundColor: activeTokens.primary,
                            color: activeTokens.buttonText,
                          }}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>حفظ</span>
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingId(null);
                          }}
                          className="px-2.5 py-1.5 rounded-xl border text-xs font-bold cursor-pointer"
                          style={{
                            backgroundColor: secondaryBg,
                            borderColor: activeTokens.border,
                            color: activeTokens.textSecondary,
                          }}
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-2 pt-0.5">
                      <div className="flex items-center gap-2 min-w-0 flex-wrap">
                        {b.note ? (
                          <span
                            onClick={(e) => startEditingNote(b, e)}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold truncate max-w-[210px]"
                            style={{
                              backgroundColor: activeTokens.primaryLight,
                              color: activeTokens.primary,
                            }}
                            title="انقر لتعديل الملاحظة"
                          >
                            <Tag className="w-3 h-3 shrink-0" />
                            <span className="truncate">{b.note}</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={(e) => startEditingNote(b, e)}
                            className="text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-opacity hover:opacity-80"
                            style={{ color: activeTokens.textSecondary }}
                          >
                            <Tag className="w-3 h-3" />
                            <span>+ إضافة وسم أو ملاحظة</span>
                          </button>
                        )}

                        <span
                          className="text-[11px] flex items-center gap-1"
                          style={{ color: activeTokens.textMuted }}
                        >
                          <Clock className="w-3 h-3" />
                          {new Date(b.timestamp).toLocaleDateString('ar-SA', {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleJumpToBookmark(b.surahNumber, b.ayahNumber);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shrink-0 shadow-2xs group-hover:translate-x-[-2px]"
                        style={{
                          backgroundColor: activeTokens.primary,
                          color: activeTokens.buttonText,
                        }}
                      >
                        <span>الانتقال للآية</span>
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 px-4">
              <div
                className="w-16 h-16 rounded-3xl border flex items-center justify-center mx-auto mb-3 shadow-2xs"
                style={{
                  backgroundColor: secondaryBg,
                  borderColor: activeTokens.border,
                }}
              >
                <Bookmark className="w-8 h-8" style={{ color: activeTokens.textMuted }} />
              </div>
              <h4 className="text-sm font-bold" style={{ color: activeTokens.text }}>
                {searchQuery || scopeFilter === 'currentSurah'
                  ? 'لا توجد علامات مرجعية مطابقة'
                  : 'لا توجد علامات مرجعية محفوظة بعد'}
              </h4>
              <p
                className="text-xs mt-1.5 max-w-xs mx-auto leading-relaxed"
                style={{ color: activeTokens.textSecondary }}
              >
                {searchQuery || scopeFilter === 'currentSurah'
                  ? 'جرب عرض كل العلامات أو البحث بكلمة أخرى للوصول إلى آياتك المحفوظة.'
                  : 'انقر على أي آية أثناء القراءة في المصحف أو التفسير أو الترجمة، أو اضغط على زر «حفظ علامة» للعودة إليها في أي وقت.'}
              </p>
              {(searchQuery || scopeFilter === 'currentSurah') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setScopeFilter('all');
                  }}
                  className="mt-3 px-4 py-2 rounded-xl text-xs font-bold cursor-pointer"
                  style={{
                    backgroundColor: activeTokens.primary,
                    color: activeTokens.buttonText,
                  }}
                >
                  عرض جميع العلامات ({bookmarks.length})
                </button>
              )}
            </div>
          )}
        </div>

        {/* ─────────────────────────────────────────────────────────────
            Footer Summary
        ───────────────────────────────────────────────────────────── */}
        <div
          className="px-4 py-2.5 border-t flex items-center justify-between text-[11px] shrink-0"
          style={{
            backgroundColor: secondaryBg,
            borderColor: activeTokens.border,
            color: activeTokens.textSecondary,
          }}
        >
          <span>
            إجمالي الآيات المحفوظة: <strong style={{ color: activeTokens.primary }}>{bookmarks.length}</strong>
          </span>
          <span>انقر على أي بطاقة للانتقال المباشر</span>
        </div>
      </aside>
    </div>
  );
};
