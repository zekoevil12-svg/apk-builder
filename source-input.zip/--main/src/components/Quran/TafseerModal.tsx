import React, { useState, useEffect } from 'react';
import { X, BookOpen, Globe, Copy, Check, Loader2 } from 'lucide-react';
import { AyahItem } from '../../data/quranData';
import { getAyahTafseer, TafseerType, TAFSEER_CONFIG } from '../../utils/quranService';

interface TafseerModalProps {
  isOpen: boolean;
  onClose: () => void;
  surahNumber: number;
  surahName: string;
  ayah: AyahItem | null;
}

export const TafseerModal: React.FC<TafseerModalProps> = ({
  isOpen,
  onClose,
  surahNumber,
  surahName,
  ayah,
}) => {
  const [activeTab, setActiveTab] = useState<'tafseer' | 'translation'>('tafseer');
  const [selectedTafseer, setSelectedTafseer] = useState<TafseerType>('muyassar');
  const [lang, setLang] = useState<'en' | 'fr' | 'ur'>('en');
  const [copied, setCopied] = useState(false);
  const [tafseerText, setTafseerText] = useState<string>('');
  const [loadingTafseer, setLoadingTafseer] = useState<boolean>(false);

  // Load tafseer dynamically when ayah or tafseer author changes
  useEffect(() => {
    if (!ayah || !isOpen) return;

    if (selectedTafseer === 'muyassar' && ayah.tafseer) {
      setTafseerText(ayah.tafseer);
      return;
    }

    let isMounted = true;
    setLoadingTafseer(true);
    getAyahTafseer(surahNumber, ayah.numberInSurah, selectedTafseer)
      .then((res) => {
        if (isMounted) {
          setTafseerText(res.text);
          setLoadingTafseer(false);
        }
      })
      .catch((err) => {
        console.error(err);
        if (isMounted) {
          setTafseerText(ayah.tafseer || 'تعذر تحميل التفسير في الوقت الحالي.');
          setLoadingTafseer(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [ayah, selectedTafseer, surahNumber, isOpen]);

  if (!isOpen || !ayah) return null;

  const handleCopy = () => {
    let content = `﴿ ${ayah.text} ﴾ [سورة ${surahName}: ${ayah.numberInSurah}]\n\n`;
    if (activeTab === 'tafseer') {
      content += `${TAFSEER_CONFIG[selectedTafseer].name} (${TAFSEER_CONFIG[selectedTafseer].author}):\n${tafseerText}`;
    } else {
      const trans = lang === 'en' ? ayah.translationEn : lang === 'fr' ? ayah.translationFr : ayah.translationUr;
      content += `ترجمة المعاني:\n${trans || 'غير متوفر'}`;
    }
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4" dir="rtl">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={onClose} />

      {/* Modal Container */}
      <div className="relative w-full max-w-lg bg-white dark:bg-[#1A1A1A] rounded-3xl shadow-2xl border-2 border-[#E6E6F0] overflow-hidden z-10 flex flex-col max-h-[88vh] animate-scale-up">
        {/* Header */}
        <div className="bg-[#5B5FEF] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-amiri">
                سورة {surahName} — الآية {ayah.numberInSurah}
              </h3>
              <p className="text-[11px] text-amber-100 font-sans">تفسير القرآن الكريم وترجمة معانيه</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer text-xs flex items-center gap-1"
              title="نسخ"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Ayah Box */}
        <div className="p-4 bg-[#F7F7FC] dark:bg-[#25263A] border-b border-[#E6E6F0]">
          <div className="bg-white dark:bg-[#1F1F1F] p-4 rounded-2xl border border-[#E6E6F0] shadow-xs text-center">
            <p className="font-amiri text-xl md:text-2xl text-[#25263A] dark:text-[#E6E6F0] leading-loose">
              ﴿ {ayah.text} ﴾
            </p>
            <div className="mt-2 flex items-center justify-center gap-2 text-xs text-[#5B5FEF] font-bold">
              <span>الجزء {ayah.juz}</span>
              <span>•</span>
              <span>رقم الآية {ayah.numberInSurah}</span>
            </div>
          </div>
        </div>

        {/* Tab switcher: Tafseer / Translation */}
        <div className="flex border-b border-[#E6E6F0] dark:border-white/10 bg-gray-50/70 dark:bg-black/20 p-1.5 gap-2">
          <button
            onClick={() => setActiveTab('tafseer')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'tafseer'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A] dark:text-gray-400'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>التفسير</span>
          </button>
          <button
            onClick={() => setActiveTab('translation')}
            className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'translation'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A] dark:text-gray-400'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>ترجمة المعاني</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 md:p-5 overflow-y-auto space-y-4 flex-1 text-right">
          {activeTab === 'tafseer' ? (
            <div className="space-y-3">
              {/* Tafseer selector pills */}
              <div className="flex flex-wrap gap-1.5 pb-2 border-b border-[#E6E6F0]">
                {(Object.keys(TAFSEER_CONFIG) as TafseerType[]).map((key) => {
                  const conf = TAFSEER_CONFIG[key];
                  const isSelected = selectedTafseer === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setSelectedTafseer(key)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#25263A] dark:text-gray-300 hover:bg-[#EEEEFF]'
                      }`}
                    >
                      {conf.name}
                    </button>
                  );
                })}
              </div>

              {/* Author & Source Tag */}
              <div className="flex items-center justify-between text-xs text-[#77798C]">
                <span className="font-bold text-[#5B5FEF]">{TAFSEER_CONFIG[selectedTafseer].author}</span>
                <span className="text-[11px] text-gray-400">مجمع الملك فهد / Quran.com API</span>
              </div>

              {/* Tafseer text */}
              {loadingTafseer ? (
                <div className="py-12 flex flex-col items-center justify-center gap-2 text-[#5B5FEF]">
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span className="text-xs font-bold text-[#77798C]">جارِ جلب التفسير المعتمد...</span>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-[#F7F7FC]/50 dark:bg-white/5 border border-[#E6E6F0]">
                  <p className="text-[#25263A] dark:text-[#E6E6F0] text-sm md:text-base leading-relaxed whitespace-pre-wrap font-sans">
                    {tafseerText || 'التفسير متوفر عند الاتصال بالشبكة.'}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {/* Language selection */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#77798C]">اختر اللغة:</span>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setLang('en')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      lang === 'en' ? 'bg-[#5B5FEF] text-white' : 'bg-gray-100 dark:bg-white/10 text-[#77798C] dark:text-gray-300'
                    }`}
                  >
                    English (Sahih)
                  </button>
                  <button
                    onClick={() => setLang('fr')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      lang === 'fr' ? 'bg-[#5B5FEF] text-white' : 'bg-gray-100 dark:bg-white/10 text-[#77798C] dark:text-gray-300'
                    }`}
                  >
                    Français
                  </button>
                  <button
                    onClick={() => setLang('ur')}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      lang === 'ur' ? 'bg-[#5B5FEF] text-white' : 'bg-gray-100 dark:bg-white/10 text-[#77798C] dark:text-gray-300'
                    }`}
                  >
                    اردو
                  </button>
                </div>
              </div>

              <div
                className="p-4 rounded-2xl bg-gray-50 dark:bg-white/5 border border-[#E6E6F0] dark:border-white/10 text-left"
                dir={lang === 'ur' ? 'rtl' : 'ltr'}
              >
                <p className="text-[#25263A] dark:text-gray-200 text-sm md:text-base leading-relaxed font-sans">
                  {lang === 'en' && (ayah.translationEn || 'English translation loading...')}
                  {lang === 'fr' && (ayah.translationFr || 'Traduction française disponible en ligne...')}
                  {lang === 'ur' && (ayah.translationUr || 'اردو ترجمہ دستیاب ہے۔')}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 dark:bg-black/30 border-t border-[#E6E6F0] dark:border-white/10 flex items-center justify-between text-xs text-[#77798C]">
          <span>المصدر: مجمع الملك فهد لطباعة المصحف الشريف</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
