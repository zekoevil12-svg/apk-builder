import React, { useRef, useState } from 'react';
import { X, Download, Share2, Copy, Check, Sparkles } from 'lucide-react';
import { AyahItem } from '../../data/quranData';

interface VerseCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  surahName: string;
  ayah: AyahItem | null;
}

export const VerseCardModal: React.FC<VerseCardModalProps> = ({
  isOpen,
  onClose,
  surahName,
  ayah,
}) => {
  const [copied, setCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  if (!isOpen || !ayah) return null;

  const handleCopyText = () => {
    const text = `﴿ ${ayah.text} ﴾\n[سورة ${surahName} - الآية ${ayah.numberInSurah}]\n— عبر تطبيق مسبحة رفيق المسلم 📿`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const generateAndDownloadImage = () => {
    setIsGenerating(true);
    try {
      const canvas = document.createElement('canvas');
      const width = 1080;
      const height = 1080;
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Background gradient (Luxurious warm Islamic cream/beige)
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#F7F7FC');
      bgGrad.addColorStop(0.5, '#F7F7FC');
      bgGrad.addColorStop(1, '#F7F7FC');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Outer gold border
      ctx.strokeStyle = '#E8B84A';
      ctx.lineWidth = 8;
      ctx.strokeRect(40, 40, width - 80, height - 80);

      // Inner thin green border
      ctx.strokeStyle = '#5B5FEF';
      ctx.lineWidth = 2;
      ctx.strokeRect(55, 55, width - 110, height - 110);

      // Corner ornaments (geometric star marks)
      const drawCorner = (x: number, y: number) => {
        ctx.save();
        ctx.translate(x, y);
        ctx.strokeStyle = '#E8B84A';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#E8B84A';
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      };
      drawCorner(75, 75);
      drawCorner(width - 75, 75);
      drawCorner(75, height - 75);
      drawCorner(width - 75, height - 75);

      // Top title / Bismillah
      ctx.fillStyle = '#4145C7';
      ctx.font = 'bold 36px "Amiri", "Traditional Arabic", serif';
      ctx.textAlign = 'center';
      ctx.fillText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', width / 2, 140);

      // Decorative divider
      ctx.strokeStyle = '#E8B84A';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(width / 2 - 120, 180);
      ctx.lineTo(width / 2 + 120, 180);
      ctx.stroke();

      // Surah badge
      ctx.fillStyle = '#4145C7';
      ctx.beginPath();
      ctx.roundRect(width / 2 - 160, 220, 320, 60, 30);
      ctx.fill();
      ctx.strokeStyle = '#E8B84A';
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 28px "Tajawal", sans-serif';
      ctx.fillText(`سُورَةُ ${surahName} • الآية ${ayah.numberInSurah}`, width / 2, 260);

      // Verses Text (wrapped nicely)
      ctx.fillStyle = '#4145C7';
      ctx.font = 'bold 44px "Amiri", "Traditional Arabic", serif';
      const words = ayah.text.split(' ');
      let line = '';
      const lines: string[] = [];
      const maxWidth = width - 240;

      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
          lines.push(line);
          line = words[n] + ' ';
        } else {
          line = testLine;
        }
      }
      lines.push(line);

      // Center the lines vertically around the middle
      const lineHeight = 75;
      const totalTextHeight = lines.length * lineHeight;
      let startY = 400 + Math.max(0, (360 - totalTextHeight) / 2);

      for (let i = 0; i < lines.length; i++) {
        ctx.fillText(lines[i], width / 2, startY + (i * lineHeight));
      }

      // Bottom app branding
      ctx.strokeStyle = '#E8B84A';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(150, height - 160);
      ctx.lineTo(width - 150, height - 160);
      ctx.stroke();

      ctx.fillStyle = '#25263A';
      ctx.font = 'bold 24px "Tajawal", sans-serif';
      ctx.fillText('تطبيق «رِفْق | RIFQ» ✨ رفيقك لذكر الله وتلاوة القرآن', width / 2, height - 110);

      // Convert to downloadable PNG
      const link = document.createElement('a');
      link.download = `ayah-${surahName}-${ayah.numberInSurah}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleNativeShare = async () => {
    const text = `﴿ ${ayah.text} ﴾\n[سورة ${surahName} - الآية ${ayah.numberInSurah}]\n— تطبيق «رِفْق | RIFQ» ✨`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `آية من سورة ${surahName}`,
          text: text,
        });
      } catch {
        handleCopyText();
      }
    } else {
      handleCopyText();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#E6E6F0] overflow-hidden z-10 flex flex-col animate-scale-up">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-amber-300">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">بطاقة الآية الكريمة</h3>
              <p className="text-[11px] text-blue-100">تصميم ذهبي راقٍ للمشاركة والتدبر</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Preview */}
        <div className="p-5 bg-stone-100 flex items-center justify-center">
          <div className="relative w-full bg-gradient-to-b from-[#F7F7FC] to-[#F7F7FC] rounded-2xl p-6 border-2 border-[#5B5FEF] shadow-lg text-center overflow-hidden">
            {/* Inner blue border */}
            <div className="absolute inset-1.5 border border-[#4145C7]/20 rounded-xl pointer-events-none" />

            <div className="text-[#4145C7] font-amiri text-sm mb-2 font-bold">
              بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
            </div>

            <div className="inline-block px-3 py-1 bg-[#4145C7] text-amber-300 rounded-full text-xs font-bold border border-[#5B5FEF] mb-4 shadow-2xs">
              سورة {surahName} ﴿{ayah.numberInSurah}﴾
            </div>

            <p className="font-amiri text-xl md:text-2xl text-[#4145C7] font-bold leading-relaxed mb-6 px-2">
              ﴿ {ayah.text} ﴾
            </p>

            <div className="pt-3 border-t border-[#E6E6F0] flex items-center justify-between text-[11px] text-[#25263A]/80">
              <span>الجزء {ayah.juz}</span>
              <span className="font-bold text-[#4145C7]">تطبيق «رِفْق | RIFQ» ✨</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 bg-white border-t border-[#E6E6F0] grid grid-cols-3 gap-2">
          <button
            onClick={generateAndDownloadImage}
            disabled={isGenerating}
            className="py-2.5 px-3 bg-[#4145C7] hover:bg-[#4145C7] text-white font-bold text-xs rounded-xl flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 cursor-pointer shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>{isGenerating ? 'جارِ التحميل...' : 'حفظ كصورة'}</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="py-2.5 px-3 bg-[#5B5FEF] hover:bg-[#b8973d] text-white font-bold text-xs rounded-xl flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 cursor-pointer shadow-xs"
          >
            <Share2 className="w-4 h-4" />
            <span>مشاركة الآية</span>
          </button>

          <button
            onClick={handleCopyText}
            className="py-2.5 px-3 bg-gray-100 hover:bg-gray-200 text-[#25263A] font-bold text-xs rounded-xl flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-[#4CAF82]" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
