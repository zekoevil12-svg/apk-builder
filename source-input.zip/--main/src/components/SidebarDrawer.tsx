import React, { useState } from 'react';
import { ScreenType, WardType } from '../types';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { getSavedUserAvatar } from '../utils/firebase';
import { RifqLogo } from './RifqLogo';
import { shareRifqApp } from '../utils/shareRifq';
import { MORNING_ATHKAR, EVENING_ATHKAR, SLEEP_ATHKAR, PRAYER_ATHKAR } from '../data/athkarData';
import {
  RifqSectionIcon,
  WardTypeIcon,
  CreditsSectionSvg,
  ProfileSectionSvg,
} from './Home/RifqSectionIcons';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onSelectWard: (ward: WardType) => void;
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  currentScreen,
  onSelectScreen,
  onSelectWard,
}) => {
  const { currentUser, userProfile, isAdmin, openAuthModal } = useAuth();
  const { themeId } = useTheme();
  const isGirly = themeId === 'girly';
  const [shareCopied, setShareCopied] = useState(false);
  if (!isOpen) return null;

  const navItems: { label: string; screen: ScreenType; badge?: string }[] = [
    { label: 'الرئيسية', screen: 'home' },
    ...(isAdmin ? [{ label: 'لوحة الإدارة المركزية', screen: 'admin' as ScreenType, badge: 'Admin' }] : []),
    { label: 'غريب القرآن', screen: 'gharib_quran' },
    { label: 'أحكام التجويد التفاعلية', screen: 'tajweed' },
    { label: 'آية وفائدة (تدبرات)', screen: 'tadabbur' },
    { label: 'وِرد | WIRD', screen: 'wird' },
    { label: 'المسبحة', screen: 'tasbeeh' },
    { label: 'التذكيرات اليومية', screen: 'daily_reminders' },
    { label: 'المواقيت', screen: 'prayers' },
    { label: 'القرآن', screen: 'quran' },
    { label: 'القرآن — استماع', screen: 'quran_audio' },
    { label: 'الزكاة والمواريث', screen: 'zakat_mawarith' },
    { label: 'التقويم والصيام', screen: 'hijri_fasting' },
    { label: 'الحج والعمرة (المطوّف)', screen: 'hajj_umrah' },
    { label: 'الرقية والطب النبوي', screen: 'ruqyah_medicine' },
    { label: 'الأحاديث', screen: 'hadith' },
    { label: 'الأربعون النووية', screen: 'arbain_nawawiya' },
    { label: 'وصايا الرسول ﷺ', screen: 'wasaya' },
    { label: 'السيرة النبوية ﷺ', screen: 'prophetic_biography', badge: 'موسوعة' },
    { label: 'تاريخنا الإسلامي', screen: 'our_history', badge: 'جديد' },
    { label: 'قصص الصحابة', screen: 'companions_stories' },
    { label: 'قصص الأطفال', screen: 'kids_stories' },
    { label: 'الفقه الميسر', screen: 'fiqh_muyassar' },
    { label: 'الأذكار', screen: 'athkar' },
    { label: 'ركن الدعاء والمناجاة', screen: 'dua_corner', badge: 'جديد' },
    { label: '🕌 تعلّم الوضوء والصلاة', screen: 'wudu_prayer' },
    { label: 'أثر طيّب (للمتوفين)', screen: 'athar_tayyib' },
    { label: 'أمانة (الديون والأمانات)', screen: 'amana' },
    { label: 'رحلتي الإيمانية', screen: 'journey' },
    { label: 'حصاد الأعمال', screen: 'harvest' },
    { label: 'رِفْق للمرأة', screen: 'muslim_woman' },
    { label: 'الإحصائيات', screen: 'stats' },
    { label: 'الملف الشخصي', screen: 'profile' },
    { label: 'أسماء الله', screen: 'asmaa_allah' },
    { label: 'الإعدادات', screen: 'settings' },
    { label: 'تواصل المطور', screen: 'credits' },
  ];

  const wardItems: { label: string; type: WardType; count: string }[] = [
    { label: 'أذكار الصباح', type: 'morning', count: `${MORNING_ATHKAR.length} ذكرًا` },
    { label: 'أذكار المساء', type: 'evening', count: `${EVENING_ATHKAR.length} ذكرًا` },
    { label: 'أذكار النوم', type: 'sleep', count: `${SLEEP_ATHKAR.length} أذكار` },
    { label: 'أذكار بعد الصلاة', type: 'prayer', count: `${PRAYER_ATHKAR.length} أذكار` },
  ];

  const photoUrl = userProfile?.photoURL || getSavedUserAvatar(currentUser?.uid) || currentUser?.photoURL;
  const isEmojiAvatar = photoUrl?.startsWith('emoji:');
  const emojiChar = isEmojiAvatar ? photoUrl.replace('emoji:', '') : '';

  const handleShareApp = async () => {
    const res = await shareRifqApp();
    if (res === 'copied') {
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex" dir="rtl">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
        onClick={onClose}
      />

      {/* Drawer content */}
      <div className="relative w-[300px] max-w-[85vw] bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in-right overflow-y-auto">
        {/* Header with Rifq Modern Light Indigo/Lavender Theme */}
        <div className="bg-gradient-to-br from-[#F7F7FC] via-[#FFFFFF] to-[#EEEEFF] p-5 text-[#25263A] border-b border-[#E6E6F0] relative">
          <button
            onClick={onClose}
            aria-label="إغلاق القائمة"
            className="absolute top-4 left-4 w-8 h-8 rounded-full bg-white border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#5B5FEF] flex items-center justify-center transition-colors cursor-pointer"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>

          {/* User Account Card in Header */}
          {currentUser ? (
            <div 
              onClick={() => {
                onSelectScreen('profile');
                onClose();
              }}
              className="flex items-center gap-3 mb-2 cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-full bg-[#FFFFFF] border-2 border-[#5B5FEF] flex items-center justify-center text-xl shadow-xs overflow-hidden shrink-0">
                {photoUrl && !isEmojiAvatar ? (
                  <img src={photoUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : isEmojiAvatar ? (
                  <span className="text-2xl select-none">{emojiChar}</span>
                ) : (
                  <ProfileSectionSvg size={28} />
                )}
              </div>
              <div className="overflow-hidden">
                <h2 className="font-bold text-base text-[#25263A] truncate flex items-center gap-1">
                  <span>{userProfile?.displayName || currentUser.displayName || 'ذاكر لله'}</span>
                </h2>
                <p className="text-[11px] text-[#77798C] truncate" dir="ltr">
                  {currentUser.email || 'حساب سحابي موثق'}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 rounded-2xl bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shadow-xs overflow-hidden p-1 shrink-0">
                <RifqLogo size={38} variant="emblem" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="font-black text-lg text-[#5B5FEF]">رِفْـق | RIFQ</h2>
                </div>
                <button
                  onClick={() => {
                    openAuthModal('login');
                    onClose();
                  }}
                  className="text-xs font-bold text-[#4145C7] hover:underline flex items-center gap-1 cursor-pointer mt-0.5"
                >
                  <span>تسجيل الدخول للحفظ السحابي</span>
                </button>
              </div>
            </div>
          )}
          
          <div className="mt-3 bg-white rounded-xl p-2 text-xs text-[#4145C7] border border-[#E6E6F0] flex items-center gap-2">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill={isGirly ? '#D98FA8' : '#E99AC7'}
              stroke={isGirly ? '#CFA06A' : 'none'}
              strokeWidth={isGirly ? '1.2' : '0'}
              className="shrink-0"
            >
              <path d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z" />
            </svg>
            <span className="text-[11px] font-bold">«أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ»</span>
          </div>
        </div>

        {/* Navigation list */}
        <div className="p-4 space-y-6 flex-1">
          {/* Main screens */}
          <div>
            <span className="text-xs font-semibold text-[#5B5FEF] px-3 uppercase tracking-wider">
              القائمة الرئيسية
            </span>
            <div className="mt-2 space-y-1">
              {navItems.map((item) => {
                const isActive = currentScreen === item.screen;
                return (
                  <button
                    key={item.screen}
                    onClick={() => {
                      onSelectScreen(item.screen);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-[#EEEEFF] text-[#4145C7] font-bold border-r-4 border-[#5B5FEF]'
                        : 'text-[#25263A] hover:bg-[#F7F7FC]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-9 h-9 rounded-full flex items-center justify-center border shrink-0 transition-all ${
                          isActive
                            ? 'bg-white border-[#5B5FEF] shadow-2xs'
                            : 'bg-[#F7F7FC] border-[#E6E6F0]'
                        }`}
                        style={
                          isActive && isGirly
                            ? {
                                borderColor: '#CFA06A',
                                boxShadow: '0 2px 8px rgba(185, 140, 200, 0.25)',
                              }
                            : undefined
                        }
                      >
                        <RifqSectionIcon key={`drawer-${item.screen}-${themeId}`} screenId={item.screen} size={22} />
                      </span>
                      <span>{item.label}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Daily Wards Section */}
          <div>
            <span className="text-xs font-semibold text-[#5B5FEF] px-3 uppercase tracking-wider">
              الأوراد اليومية الموقوتة
            </span>
            <div className="mt-2 space-y-1">
              {wardItems.map((w) => (
                <button
                  key={w.type}
                  onClick={() => {
                    onSelectWard(w.type);
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm text-[#25263A] hover:bg-[#F7F7FC] transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                      <WardTypeIcon key={`drawer-ward-${w.type}-${themeId}`} type={w.type} size={22} />
                    </span>
                    <span className="font-medium">{w.label}</span>
                  </div>
                  <span className="text-xs text-[#77798C] font-bold">
                    {w.count}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Share app */}
          <div className="pt-2 border-t border-[#E6E6F0]">
            <button
              onClick={handleShareApp}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#4145C7] font-bold bg-[#EEEEFF] hover:bg-[#5B5FEF] hover:text-white border border-[#E6E6F0] transition-colors cursor-pointer"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2" />
                <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
                <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2" />
                <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="currentColor" strokeWidth="2" />
              </svg>
              <span>{shareCopied ? 'تم نسخ رسالة مشاركة رِفْق بنجاح ✓' : '📤 مشاركة رِفْق ولك الأجر'}</span>
            </button>
          </div>
        </div>

        {/* Footer info & Developer Credits Shortcut */}
        <div className="p-3 bg-[#F7F7FC] border-t border-[#E6E6F0]">
          <button
            onClick={() => {
              onSelectScreen('credits');
              onClose();
            }}
            className="w-full p-2.5 rounded-xl bg-white hover:bg-[#EEEEFF]/40 border border-[#E6E6F0] text-right transition-all shadow-2xs flex items-center justify-between cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                <CreditsSectionSvg size={20} />
              </div>
              <div>
                <p className="font-bold text-xs text-[#25263A] group-hover:text-[#5B5FEF] transition-colors">
                  المطور: محمد عبدالله
                </p>
                <p className="text-[10px] text-[#77798C]">
                  فتح صفحة الحقوق والتواصل
                </p>
              </div>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0]">
              قسم خاص
            </span>
          </button>
          <p className="text-[10px] text-[#77798C] text-center mt-2">
            تطبيق رِفْق | RIFQ © 2026 • صدقة جارية لوجه الله
          </p>
        </div>
      </div>
    </div>
  );
};


