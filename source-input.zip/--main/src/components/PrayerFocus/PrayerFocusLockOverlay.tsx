import React from 'react';
import { Check, Clock } from 'lucide-react';
import {
  PendingPrayerHarvestPrompt,
  savePrayerTrackerStatus,
  savePendingHarvestPrompt,
} from '../../utils/prayerFocusService';

interface PrayerFocusHarvestPromptModalProps {
  prompt: PendingPrayerHarvestPrompt | null;
  onPrayerLogged?: (prayerNameAr: string) => void;
}

/**
 * Post-Focus Worship Harvest Prompt («حصاد العبادة»):
 * Appears after a real Prayer Focus window ends to ask the user whether they prayed,
 * without ever auto-logging the prayer unless the user explicitly taps «نعم، صليت».
 */
export const PrayerFocusHarvestPromptModal: React.FC<
  PrayerFocusHarvestPromptModalProps
> = ({ prompt, onPrayerLogged }) => {
  if (!prompt) return null;

  const handleConfirmPrayed = () => {
    savePrayerTrackerStatus(prompt.dateStr, prompt.prayerKey, 'on_time');
    savePendingHarvestPrompt(null);
    if (onPrayerLogged) {
      onPrayerLogged(prompt.prayerNameAr);
    }
  };

  const handleLater = () => {
    savePendingHarvestPrompt(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in font-tajawal"
      dir="rtl"
    >
      <div className="bg-white dark:bg-[#1C1D2B] rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] dark:border-white/10 text-center space-y-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-[#4CAF82] via-[#5B5FEF] to-[#E8B84A]" />

        <div className="w-16 h-16 rounded-2xl bg-[#4CAF82]/15 text-[#4CAF82] flex items-center justify-center mx-auto text-3xl border border-[#4CAF82]/30">
          🕌
        </div>

        <div className="space-y-1.5">
          <span className="inline-block px-3 py-1 rounded-full bg-[#EEEEFF] dark:bg-[#5B5FEF]/20 text-[#5B5FEF] dark:text-[#8C90FF] text-[11px] font-black">
            انتهى وضع الصلاة والتركيز • حصاد العبادة
          </span>
          <h3 className="text-xl font-black text-[#25263A] dark:text-white">
            هل صليت {prompt.prayerNameAr}؟
          </h3>
          <p className="text-xs text-[#77798C] dark:text-gray-400 leading-relaxed">
            تقبّل الله طاعتك. عند التأكيد سيتم تسجيل صلاة {prompt.prayerNameAr} في حصاد الصلاة اليومي ورحلة المحافظة على الصلاة.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            onClick={handleConfirmPrayed}
            className="py-3 px-4 rounded-2xl bg-[#4CAF82] hover:brightness-95 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>نعم، صليت</span>
          </button>

          <button
            type="button"
            onClick={handleLater}
            className="py-3 px-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#222436] hover:bg-[#E6E6F0] text-[#77798C] dark:text-gray-300 font-black text-xs flex items-center justify-center gap-1.5 border border-[#E6E6F0] dark:border-white/10 transition-all cursor-pointer"
          >
            <Clock className="w-4 h-4" />
            <span>لاحقًا</span>
          </button>
        </div>
      </div>
    </div>
  );
};
