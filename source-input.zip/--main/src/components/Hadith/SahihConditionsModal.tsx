import React from 'react';
import { X, ShieldCheck, BookCheck, AlertTriangle, CheckCircle2, Star, Sparkles } from 'lucide-react';
import { SAHIH_CONDITIONS_INFO } from '../../data/hadithsData';

interface SahihConditionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SahihConditionsModal: React.FC<SahihConditionsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs font-tajawal animate-fade-in" dir="rtl">
      <div className="w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E6E6F0]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-5 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-200">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-amber-200">
                منهج التوثيق وشروط الحديث الصحيح
              </h3>
              <p className="text-xs text-blue-100/80">
                ضوابط الأحاديث الصحيحة والمعتمدة في تطبيق رِفْق | RIFQ
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Strict Rule Notice */}
          <div className="bg-[#4CAF82]/12 border border-[#4CAF82]/40 rounded-2xl p-4 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#4CAF82] shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed text-emerald-950">
              <span className="font-black text-[#4CAF82] block mb-1">
                قاعدة إلزامية: الأحاديث الصحيحة والحسنة فقط
              </span>
              يقتصر هذا القسم حصراً على الأحاديث الثابتة عن رسول الله ﷺ من أصح كتب السنة المعتمدة عند أهل السنة والجماعة، مع استبعاد تام للأحاديث الضعيفة أو المنكرة أو الموضوعة صيانةً لجناب السنة النبوية المطهرة.
            </div>
          </div>

          {/* 5 Conditions */}
          <div>
            <h4 className="text-sm font-black text-[#4145C7] mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
              <span>الشروط الخمسة لصحة الحديث عند علماء الأمة</span>
            </h4>

            <div className="space-y-2.5">
              {SAHIH_CONDITIONS_INFO.conditions.map((item, idx) => (
                <div 
                  key={idx}
                  className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]/70 text-xs"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-5 h-5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center font-bold text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="font-black text-[#25263A]">{item.title}</span>
                  </div>
                  <p className="text-[#77798C] pr-7 leading-relaxed">{item.detail}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Approved Books */}
          <div>
            <h4 className="text-sm font-black text-[#4145C7] mb-3 flex items-center gap-2">
              <BookCheck className="w-4 h-4 text-[#5B5FEF]" />
              <span>الكتب والمصادر المعتمدة</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAHIH_CONDITIONS_INFO.approvedBooks.map((book, idx) => (
                <div 
                  key={idx}
                  className="p-3 rounded-2xl bg-white border border-[#E6E6F0] shadow-2xs hover:border-[#E6E6F0] transition-colors"
                >
                  <div className="font-black text-xs text-[#4145C7] mb-0.5">{book.name}</div>
                  <div className="text-[11px] text-[#4145C7] font-medium mb-1">{book.author}</div>
                  <div className="text-[11px] text-[#77798C] leading-tight">{book.desc}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Grades explanation */}
          <div className="p-4 rounded-2xl bg-[#EEEEFF]/50 border border-[#E6E6F0] text-xs space-y-2">
            <span className="font-bold text-[#4145C7] block">معاني شارات الأحاديث في التطبيق:</span>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-[#4CAF82]/12 text-[#4CAF82] font-bold text-[11px]">صحيح ✅</span>
              <span className="text-[#77798C]">ما ورد في الصحيحين (البخاري ومسلم) أو حكم بصحته أئمة الحديث.</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] font-bold text-[11px]">حسن ⭐</span>
              <span className="text-[#77798C]">ما اتصل سنده برواة عدول خف ضبطهم قليلاً وحسنه الترمذي أو الأئمة.</span>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-[#E6E6F0] flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
          >
            فهمت، جزاكم الله خيراً
          </button>
        </div>

      </div>
    </div>
  );
};
