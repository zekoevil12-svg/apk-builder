import React, { useState, useEffect } from 'react';
import { 
  X, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  RotateCcw, 
  Copy, 
  Check, 
  Share2, 
  Star, 
  CheckCircle2, 
  Sparkles,
  BookMarked,
  ShieldCheck,
  Award,
  Scroll
} from 'lucide-react';
import { HadithItem } from '../../types/hadith';
import { hadithSpeech } from '../../utils/hadithSpeech';

interface HadithDetailModalProps {
  hadith: HadithItem | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  fontSize?: number;
  onShare?: (hadith: HadithItem) => void;
}

export const HadithDetailModal: React.FC<HadithDetailModalProps> = ({
  hadith,
  onClose,
  isFavorite,
  onToggleFavorite,
  fontSize = 20,
  onShare,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [activeTab, setActiveTab] = useState<'text' | 'explanation' | 'benefits' | 'rulings'>('text');

  useEffect(() => {
    const handleState = (speaking: boolean, paused: boolean) => {
      setIsSpeaking(speaking);
      setIsPaused(paused);
    };
    hadithSpeech.subscribe(handleState);

    return () => {
      hadithSpeech.stop();
    };
  }, []);

  if (!hadith) return null;

  const handleCopy = () => {
    const fullText = `${hadith.text}\n\nالراوي: ${hadith.narrator}\nالمصدر: ${hadith.source} (${hadith.hadithNumber})\nدرجة الحديث: ${hadith.grade} (${hadith.gradeDetail})\n\nالشرح الميسر:\n${hadith.explanation}\n\n[منقول من تطبيق «رِفْق | RIFQ»]`;
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (onShare) {
      onShare(hadith);
      return;
    }
    const shareText = `${hadith.text}\n\nالراوي: ${hadith.narrator}\nالمصدر: ${hadith.source} (${hadith.hadithNumber})\nالحكم: ${hadith.grade}`;
    if (navigator.share) {
      navigator.share({
        title: `حديث نبوي - ${hadith.source}`,
        text: shareText,
        url: window.location.href,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  const handlePlayAudio = () => {
    if (isPaused) {
      hadithSpeech.resume();
    } else if (isSpeaking) {
      hadithSpeech.pause();
    } else {
      const readText = `عن ${hadith.narrator}، قال رسول الله صلى الله عليه وسلم: ${hadith.text}`;
      hadithSpeech.speak(readText, speechRate);
    }
  };

  const handleRestartAudio = () => {
    hadithSpeech.stop();
    const readText = `عن ${hadith.narrator}، قال رسول الله صلى الله عليه وسلم: ${hadith.text}`;
    hadithSpeech.speak(readText, speechRate);
  };

  const handleChangeRate = (newRate: number) => {
    setSpeechRate(newRate);
    hadithSpeech.setRate(newRate);
    if (isSpeaking) {
      handleRestartAudio();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs font-tajawal animate-fade-in" dir="rtl">
      
      {/* Modal Container */}
      <div className="w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E6E6F0]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between relative shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center border border-[#E6E6F0] text-amber-200">
              <Scroll className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-amber-200">
                تفاصيل وتخريج الحديث
              </h3>
              <p className="text-xs text-emerald-100/80">
                {hadith.source} • {hadith.hadithNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onToggleFavorite(hadith.id)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="إضافة إلى المفضلة"
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-400 text-amber-400' : ''}`} />
            </button>
            <button
              onClick={handleShare}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="مشاركة الحديث"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleCopy}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="نسخ الحديث"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Audio TTS Player Toolbar */}
        <div className="bg-[#F7F7FC] px-4 py-2.5 border-b border-[#E6E6F0]/80 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePlayAudio}
              className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                isSpeaking && !isPaused
                  ? 'bg-amber-500 text-white'
                  : 'bg-[#5B5FEF] text-white hover:bg-[#4145C7]'
              }`}
            >
              {isSpeaking && !isPaused ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>إيقاف مؤقت</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" />
                  <span>{isPaused ? 'استئناف القراءة' : 'استماع صوتي'}</span>
                </>
              )}
            </button>

            {isSpeaking && (
              <button
                onClick={handleRestartAudio}
                className="p-1.5 rounded-lg bg-gray-200 hover:bg-gray-300 text-gray-700 transition-colors"
                title="إعادة البدء"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}

            {isSpeaking && !isPaused && (
              <span className="flex items-center gap-1 text-[#4CAF82] font-bold animate-pulse text-[11px]">
                <Volume2 className="w-3.5 h-3.5" />
                <span>جاري النطق...</span>
              </span>
            )}
          </div>

          {/* Speed Controls */}
          <div className="flex items-center gap-1 text-[11px]">
            <span className="text-gray-400">السرعة:</span>
            {[0.8, 1.0, 1.2].map(rate => (
              <button
                key={rate}
                onClick={() => handleChangeRate(rate)}
                className={`px-2 py-0.5 rounded-md font-mono font-bold transition-colors ${
                  speechRate === rate
                    ? 'bg-[#5B5FEF] text-[#25263A]'
                    : 'bg-white text-[#77798C] hover:bg-gray-100 border border-[#E6E6F0]'
                }`}
              >
                {rate}x
              </button>
            ))}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center border-b border-[#E6E6F0] px-4 bg-white">
          <button
            onClick={() => setActiveTab('text')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'text'
                ? 'border-[#5B5FEF] text-[#4145C7]'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            نص الحديث
          </button>
          <button
            onClick={() => setActiveTab('explanation')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'explanation'
                ? 'border-[#5B5FEF] text-[#4145C7]'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            الشرح الميسّر
          </button>
          <button
            onClick={() => setActiveTab('benefits')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'benefits'
                ? 'border-[#5B5FEF] text-[#4145C7]'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            الفوائد المستنبطة ({hadith.benefits.length})
          </button>
          <button
            onClick={() => setActiveTab('rulings')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'rulings'
                ? 'border-[#5B5FEF] text-[#4145C7]'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            الأحكام والدروس ({hadith.rulings.length})
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
          
          {/* Metadata Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]/80 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-gray-400 font-bold">درجة الحديث:</span>
              {hadith.grade === 'صحيح' ? (
                <span className="inline-flex items-center gap-1 font-black text-[#4145C7] bg-[#4CAF82]/12 px-2 py-0.5 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>صحيح ✅</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-black text-[#4145C7] bg-[#EEEEFF] px-2 py-0.5 rounded-md">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>حسن ⭐</span>
                </span>
              )}
              <span className="text-gray-400 text-[11px]">({hadith.gradeDetail})</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-gray-400">الراوي:</span>
              <span className="font-bold text-[#25263A]">{hadith.narrator}</span>
            </div>
          </div>

          {/* Tab 1: Text */}
          {activeTab === 'text' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-emerald-50/50 to-amber-50/40 p-5 rounded-2xl border border-[#E6E6F0]">
                <p 
                  className="text-[#4145C7] font-bold leading-loose text-justify tracking-wide"
                  style={{ 
                    fontSize: `${fontSize + 1}px`,
                    fontFamily: 'Amiri, Tajawal, serif',
                  }}
                >
                  {hadith.text}
                </p>
              </div>

              <div className="space-y-2 text-xs text-[#77798C] bg-gray-50 p-4 rounded-2xl border border-[#E6E6F0]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#77798C]">الكتاب والباب:</span>
                  <span className="font-medium text-[#25263A]">{hadith.bookName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#77798C]">المصدر الأصلي:</span>
                  <span className="font-medium text-[#4145C7]">{hadith.source}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#77798C]">رقم الحديث:</span>
                  <span className="font-mono text-gray-700">{hadith.hadithNumber}</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Explanation */}
          {activeTab === 'explanation' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-[#4145C7] font-black text-sm">
                <BookOpen className="w-4 h-4 text-[#5B5FEF]" />
                <span>الشرح الميسّر لمعاني الحديث</span>
              </div>
              <div className="bg-[#EEEEFF]/30 p-4 rounded-2xl border border-[#E6E6F0]/60 leading-relaxed text-sm text-[#25263A]">
                <p className="text-justify">{hadith.explanation}</p>
              </div>
            </div>
          )}

          {/* Tab 3: Benefits */}
          {activeTab === 'benefits' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-[#4145C7] font-black text-sm">
                <Award className="w-4 h-4 text-[#5B5FEF]" />
                <span>الفوائد الإيمانية والمستنبطة</span>
              </div>
              <div className="space-y-2.5">
                {hadith.benefits.map((benefit, idx) => (
                  <div 
                    key={idx}
                    className="flex items-start gap-3 bg-[#4CAF82]/12/40 p-3.5 rounded-xl border border-emerald-100 text-xs sm:text-sm text-[#25263A]"
                  >
                    <span className="w-5 h-5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center font-mono text-[10px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="leading-relaxed">{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: Rulings */}
          {activeTab === 'rulings' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-[#4145C7] font-black text-sm">
                <ShieldCheck className="w-4 h-4 text-[#4145C7]" />
                <span>الأحكام الفقهية والدروس التربوية</span>
              </div>
              <div className="space-y-2.5">
                {hadith.rulings.map((ruling, idx) => (
                  <div 
                    key={idx}
                    className="flex items-start gap-3 bg-white p-3.5 rounded-xl border border-[#E6E6F0]/80 shadow-2xs text-xs sm:text-sm text-[#25263A]"
                  >
                    <span className="w-5 h-5 rounded-full bg-[#5B5FEF] text-[#25263A] flex items-center justify-center font-bold text-[11px] shrink-0 mt-0.5">
                      ✓
                    </span>
                    <p className="leading-relaxed">{ruling}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-[#E6E6F0] text-xs font-bold text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-[#4CAF82]" /> : <Copy className="w-4 h-4 text-[#77798C]" />}
              <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
            </button>

            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#4CAF82]/12 border border-[#4CAF82]/40 text-xs font-black text-[#4145C7] hover:bg-[#4CAF82]/12 transition-colors cursor-pointer shadow-2xs"
            >
              <Share2 className="w-4 h-4 text-[#4145C7]" />
              <span>مشاركة (صورة / نص)</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
