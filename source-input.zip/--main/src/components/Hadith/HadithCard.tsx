import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Share2, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  Star, 
  CheckCircle2, 
  Sparkles,
  BookMarked
} from 'lucide-react';
import { HadithItem } from '../../types/hadith';

interface HadithCardProps {
  hadith: HadithItem;
  fontSize?: number;
  isFavorite: boolean;
  isPlayingAudio: boolean;
  onToggleFavorite: (id: string) => void;
  onOpenDetails: (hadith: HadithItem) => void;
  onPlayAudio: (hadith: HadithItem) => void;
  onStopAudio: () => void;
  onShare?: (hadith: HadithItem) => void;
}

export const HadithCard: React.FC<HadithCardProps> = ({
  hadith,
  fontSize = 19,
  isFavorite,
  isPlayingAudio,
  onToggleFavorite,
  onOpenDetails,
  onPlayAudio,
  onStopAudio,
  onShare,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `${hadith.text}\n\nالراوي: ${hadith.narrator}\nالمصدر: ${hadith.source} (${hadith.hadithNumber})\nدرجة الحديث: ${hadith.grade} (${hadith.gradeDetail})\n\n[منقول من تطبيق «رِفْق | RIFQ»]`;
    navigator.clipboard.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onShare) {
      onShare(hadith);
      return;
    }
    const shareText = `${hadith.text}\n\nالراوي: ${hadith.narrator}\nالمصدر: ${hadith.source} (${hadith.hadithNumber})\nالحكم: ${hadith.grade}`;
    if (navigator.share) {
      navigator.share({
        title: 'حديث نبوي شريف',
        text: shareText,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div 
      className={`w-full bg-white rounded-3xl p-5 sm:p-6 border transition-all duration-200 shadow-2xs hover:shadow-md relative overflow-hidden font-tajawal select-none ${
        isPlayingAudio 
          ? 'border-[#5B5FEF] ring-2 ring-[#5B5FEF]/20 bg-[#4CAF82]/12/20' 
          : 'border-[#E6E6F0] hover:border-[#E6E6F0]'
      }`}
      dir="rtl"
    >
      {/* Top Header Row: Source, Grade Badge, Favorite */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#E6E6F0]">
        <div className="flex flex-wrap items-center gap-2">
          {/* Grade Badge */}
          {hadith.grade === 'صحيح' ? (
            <span 
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#4CAF82]/12 text-[#4145C7] border border-[#4CAF82]/40 text-xs font-black shadow-2xs"
              title="حديث صحيح متصل السند ثابت عن النبي ﷺ"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-[#4145C7]" />
              <span>صحيح ✅</span>
            </span>
          ) : (
            <span 
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-xs font-black shadow-2xs"
              title="حديث حسن ثابت ورجاله ثقات"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
              <span>حسن ⭐</span>
            </span>
          )}

          {/* Book Source & Number */}
          <span className="text-xs text-[#77798C] font-bold bg-[#F7F7FC] px-2.5 py-1 rounded-lg border border-[#E6E6F0]/70 flex items-center gap-1">
            <BookMarked className="w-3 h-3 text-[#5B5FEF]" />
            <span className="text-[#25263A]">{hadith.source}</span>
            <span className="text-gray-300">•</span>
            <span className="text-[#77798C] font-mono text-[11px]">{hadith.hadithNumber}</span>
          </span>
        </div>

        {/* Favorite Star Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(hadith.id);
          }}
          aria-label="إضافة للمفضلة"
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            isFavorite 
              ? 'text-amber-500 bg-[#EEEEFF] shadow-2xs' 
              : 'text-gray-400 hover:text-amber-500 hover:bg-gray-50'
          }`}
        >
          <Star className={`w-4 h-4 ${isFavorite ? 'fill-amber-400 text-amber-500' : ''}`} />
        </button>
      </div>

      {/* Hadith Text */}
      <div 
        onClick={() => onOpenDetails(hadith)}
        className="cursor-pointer group"
      >
        <p 
          className="text-[#4145C7] leading-loose font-bold text-justify tracking-wide transition-colors group-hover:text-[#4145C7]"
          style={{ 
            fontSize: `${fontSize}px`,
            fontFamily: 'Amiri, Tajawal, serif',
          }}
        >
          {hadith.text}
        </p>

        {/* Narrator */}
        <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-[#77798C]">
          <span className="text-gray-400">الراوي:</span>
          <span className="text-[#25263A] font-bold bg-[#EEEEFF]/80 px-2 py-0.5 rounded-md border border-[#E6E6F0]">
            {hadith.narrator}
          </span>
        </div>
      </div>

      {/* Bottom Action Toolbar */}
      <div className="mt-4 pt-3 border-t border-[#E6E6F0] flex items-center justify-between gap-2">
        {/* Read Explanation button */}
        <button
          onClick={() => onOpenDetails(hadith)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#F7F7FC] to-amber-50 text-[#4145C7] hover:text-[#4145C7] border border-[#E6E6F0] text-xs font-bold hover:shadow-2xs transition-all cursor-pointer"
        >
          <BookOpen className="w-3.5 h-3.5 text-[#5B5FEF]" />
          <span>الشرح والفوائد 📖</span>
        </button>

        {/* Action icons: Audio, Copy, Share */}
        <div className="flex items-center gap-1.5">
          {/* Audio TTS Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (isPlayingAudio) {
                onStopAudio();
              } else {
                onPlayAudio(hadith);
              }
            }}
            title={isPlayingAudio ? "إيقاف القراءة الصوتية" : "استماع للحديث الشريف"}
            className={`p-2 rounded-xl transition-all cursor-pointer ${
              isPlayingAudio 
                ? 'bg-[#5B5FEF] text-white shadow-xs animate-pulse' 
                : 'text-[#77798C] hover:text-[#4145C7] hover:bg-[#4CAF82]/12'
            }`}
          >
            {isPlayingAudio ? (
              <VolumeX className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
          </button>

          {/* Copy Button */}
          <button
            onClick={handleCopy}
            title="نسخ الحديث"
            className="p-2 rounded-xl text-[#77798C] hover:text-[#4145C7] hover:bg-gray-100 transition-colors cursor-pointer"
          >
            {copied ? (
              <Check className="w-4 h-4 text-[#4CAF82]" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
          </button>

          {/* Share Button */}
          <button
            onClick={handleShare}
            title="مشاركة الحديث كصورة مصممة أو نص منسق مع بصمة التطبيق"
            className="px-2.5 py-1.5 rounded-xl text-[#4145C7] bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 border border-[#4CAF82]/40/80 transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs font-bold text-xs active:scale-95"
          >
            <Share2 className="w-3.5 h-3.5 text-[#4145C7]" />
            <span>مشاركة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
