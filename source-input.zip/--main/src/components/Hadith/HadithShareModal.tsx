import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  X, 
  Share2, 
  Download, 
  Copy, 
  Check, 
  Image as ImageIcon, 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  Send,
  MessageCircle,
  ExternalLink,
  BookMarked,
  Palette,
  Eye
} from 'lucide-react';
import { HadithItem } from '../../types/hadith';

interface HadithShareModalProps {
  hadith: HadithItem | null;
  isOpen: boolean;
  onClose: () => void;
}

type ShareTheme = 'emerald' | 'parchment' | 'midnight';

export const HadithShareModal: React.FC<HadithShareModalProps> = ({
  hadith,
  isOpen,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'image' | 'text'>('image');
  const [theme, setTheme] = useState<ShareTheme>('emerald');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [copiedImage, setCopiedImage] = useState(false);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Formatted Text for Social Media
  const formattedText = hadith ? `✨ حديث نبوي شريف ✨

عن ${hadith.narrator} رضي الله عنه، قال رسول الله ﷺ:
« ${hadith.text} »

📚 المصدر: ${hadith.source} (${hadith.hadithNumber})
⚖️ درجة الحديث: ${hadith.grade} (${hadith.gradeDetail})
📖 الشرح الميسّر: ${hadith.explanation}

📲 منقول من تطبيق «رِفْق | RIFQ»` : '';

  // Draw Card on Canvas
  const renderCardToCanvas = useCallback(() => {
    if (!hadith) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High-resolution canvas (1080 x 1080 standard square)
    const W = 1080;
    const H = 1080;
    canvas.width = W;
    canvas.height = H;

    // Theme definitions
    const themes = {
      emerald: {
        bgStart: '#0D3512',
        bgMid: '#16501E',
        bgEnd: '#09240D',
        borderGold: '#E0C068',
        borderInner: '#E8B84A',
        textTitle: '#FCE7A1',
        textHadith: '#FFFFFF',
        textSecondary: '#E8F5E9',
        badgeBg: 'rgba(9, 36, 13, 0.75)',
        badgeBorder: '#E8B84A',
        brandText: '#D1E7DD',
        patternColor: 'rgba(201, 168, 76, 0.08)'
      },
      parchment: {
        bgStart: '#F7F7FC',
        bgMid: '#F7F7FC',
        bgEnd: '#F7F7FC',
        borderGold: '#4145C7',
        borderInner: '#E8B84A',
        textTitle: '#4145C7',
        textHadith: '#25263A',
        textSecondary: '#25263A',
        badgeBg: 'rgba(255, 255, 255, 0.85)',
        badgeBorder: '#E8B84A',
        brandText: '#4145C7',
        patternColor: 'rgba(158, 116, 34, 0.06)'
      },
      midnight: {
        bgStart: '#0B1120',
        bgMid: '#111D36',
        bgEnd: '#060A14',
        borderGold: '#E8B84A',
        borderInner: '#E8B84A',
        textTitle: '#FDE68A',
        textHadith: '#F8FAFC',
        textSecondary: '#CBD5E1',
        badgeBg: 'rgba(15, 23, 42, 0.8)',
        badgeBorder: '#E8B84A',
        brandText: '#94A3B8',
        patternColor: 'rgba(245, 158, 11, 0.07)'
      }
    };

    const cfg = themes[theme];

    // 1. Draw Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, cfg.bgStart);
    bgGrad.addColorStop(0.5, cfg.bgMid);
    bgGrad.addColorStop(1, cfg.bgEnd);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // 2. Subtle Islamic Geometric Pattern (diagonals / crosses / stars)
    ctx.strokeStyle = cfg.patternColor;
    ctx.lineWidth = 1.5;
    const step = 60;
    for (let x = 0; x <= W; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + step * 4, H);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x - step * 4, H);
      ctx.stroke();
    }

    // 3. Elegant Multi-layer Frames
    const padOuter = 40;
    const padInner = 56;

    // Outer Border
    ctx.strokeStyle = cfg.borderGold;
    ctx.lineWidth = 4;
    ctx.strokeRect(padOuter, padOuter, W - padOuter * 2, H - padOuter * 2);

    // Inner Border
    ctx.strokeStyle = cfg.borderInner;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(padInner, padInner, W - padInner * 2, H - padInner * 2);

    // Corner Ornament Diamonds
    const drawCornerDiamond = (cx: number, cy: number, size: number) => {
      ctx.save();
      ctx.fillStyle = cfg.borderGold;
      ctx.beginPath();
      ctx.moveTo(cx, cy - size);
      ctx.lineTo(cx + size, cy);
      ctx.lineTo(cx, cy + size);
      ctx.lineTo(cx - size, cy);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const cOffset = padOuter + 8;
    drawCornerDiamond(cOffset, cOffset, 10);
    drawCornerDiamond(W - cOffset, cOffset, 10);
    drawCornerDiamond(cOffset, H - cOffset, 10);
    drawCornerDiamond(W - cOffset, H - cOffset, 10);

    // 4. Header Section
    ctx.direction = 'rtl';
    ctx.textAlign = 'center';

    // Bismillah / Header Title
    ctx.fillStyle = cfg.textTitle;
    ctx.font = 'bold 34px "Amiri", "Tajawal", serif';
    ctx.fillText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', W / 2, 120);

    // Decorative Separator
    ctx.font = 'bold 22px "Amiri", "Tajawal", serif';
    ctx.fillStyle = cfg.borderGold;
    ctx.fillText('— ❖  حَدِيثٌ نَبَوِيٌّ شَرِيفٌ  ❖ —', W / 2, 168);

    // 5. Narrator Intro Line
    ctx.fillStyle = cfg.textSecondary;
    ctx.font = 'bold 28px "Tajawal", sans-serif';
    const introText = `عن ${hadith.narrator} رضي الله عنه، قال رسول الله ﷺ:`;
    ctx.fillText(introText, W / 2, 230);

    // 6. Hadith Text (Word-wrapped with automatic font scaling)
    const maxTextWidth = W - 180;
    let hadithFontSize = 38;
    if (hadith.text.length > 250) {
      hadithFontSize = 30;
    } else if (hadith.text.length > 180) {
      hadithFontSize = 34;
    } else if (hadith.text.length < 90) {
      hadithFontSize = 44;
    }

    ctx.font = `bold ${hadithFontSize}px "Amiri", "Tajawal", serif`;
    const fullHadithText = `« ${hadith.text} »`;

    // Wrap text function
    const words = fullHadithText.split(' ');
    const lines: string[] = [];
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = currentLine + ' ' + word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width < maxTextWidth) {
        currentLine = testLine;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);

    // Render Hadith Text lines centered vertically in main canvas body
    const lineHeight = hadithFontSize * 1.7;
    const totalLinesHeight = lines.length * lineHeight;
    let startY = 320 + Math.max(0, (360 - totalLinesHeight) / 2);

    ctx.fillStyle = cfg.textHadith;
    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], W / 2, startY + i * lineHeight);
    }

    // 7. Source & Takhrij Badge (Lower Panel)
    const badgeW = W - 220;
    const badgeH = 150;
    const badgeX = (W - badgeW) / 2;
    const badgeY = 790;
    const cornerRadius = 24;

    // Rounded rectangle background
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(badgeX, badgeY, badgeW, badgeH, cornerRadius);
    ctx.fillStyle = cfg.badgeBg;
    ctx.fill();
    ctx.strokeStyle = cfg.badgeBorder;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    // Source Info inside Badge
    ctx.fillStyle = cfg.textTitle;
    ctx.font = 'bold 26px "Tajawal", sans-serif';
    ctx.fillText(`المصدر: ${hadith.source} (${hadith.hadithNumber})`, W / 2, badgeY + 50);

    // Grade & Verification
    ctx.fillStyle = cfg.textSecondary;
    ctx.font = 'bold 23px "Tajawal", sans-serif';
    const gradeMark = hadith.grade === 'صحيح' ? '✅' : '⭐';
    ctx.fillText(`الحكم: حديث ${hadith.grade} ${gradeMark} • ${hadith.gradeDetail}`, W / 2, badgeY + 95);

    // 8. Bottom Brand / Watermark
    ctx.fillStyle = cfg.brandText;
    ctx.font = '500 21px "Tajawal", sans-serif';
    ctx.fillText('تطبيق رِفْق | RIFQ • موسوعة السنن والأحاديث الصحيحة', W / 2, 1010);

    // Update Image Preview
    const dataUrl = canvas.toDataURL('image/png', 0.95);
    setImagePreviewUrl(dataUrl);
  }, [hadith, theme]);

  // Redraw when modal opens or theme/hadith changes
  useEffect(() => {
    if (isOpen && hadith) {
      if (document.fonts) {
        document.fonts.ready.then(() => {
          renderCardToCanvas();
        });
      }
      const t = setTimeout(() => {
        renderCardToCanvas();
      }, 60);
      return () => clearTimeout(t);
    }
  }, [isOpen, hadith, theme, renderCardToCanvas]);

  if (!isOpen || !hadith) return null;

  // Handle Download Image
  const handleDownloadImage = () => {
    if (!canvasRef.current) return;
    setIsGenerating(true);
    try {
      const dataUrl = canvasRef.current.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `hadith_${hadith.id}_${hadith.source.replace(/\s+/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handle Web Share with Image File
  const handleShareImage = async () => {
    if (!canvasRef.current) return;
    setIsGenerating(true);

    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) {
          handleDownloadImage();
          setIsGenerating(false);
          return;
        }

        const file = new File([blob], `hadith_${hadith.id}.png`, { type: 'image/png' });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          try {
            await navigator.share({
              files: [file],
              title: 'حديث نبوي شريف',
              text: `عن ${hadith.narrator}، قال رسول الله ﷺ: «${hadith.text}» - [${hadith.source}]`
            });
          } catch {
            // Cancelled or failed, fallback to download
          }
        } else {
          // Fallback: download the image
          handleDownloadImage();
        }
        setIsGenerating(false);
      }, 'image/png');
    } catch {
      handleDownloadImage();
      setIsGenerating(false);
    }
  };

  // Handle Copy Image to Clipboard
  const handleCopyImage = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        try {
          const item = new ClipboardItem({ 'image/png': blob });
          await navigator.clipboard.write([item]);
          setCopiedImage(true);
          setTimeout(() => setCopiedImage(false), 2500);
        } catch {
          // If copying image fails (e.g. permission or browser support), fallback to downloading
          handleDownloadImage();
        }
      }, 'image/png');
    } catch {
      handleDownloadImage();
    }
  };

  // Handle Copy Formatted Text
  const handleCopyFormattedText = () => {
    navigator.clipboard.writeText(formattedText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Handle Direct Social Media Share
  const handleShareWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank');
  };

  const handleShareTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank');
  };

  const handleShareTwitter = () => {
    const tweetText = `قال رسول الله ﷺ: «${hadith.text}»\n\n📚 ${hadith.source} (${hadith.hadithNumber}) • ${hadith.grade} ✅`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
    window.open(url, '_blank');
  };

  const handleNativeShareText = () => {
    if (navigator.share) {
      navigator.share({
        title: 'حديث نبوي شريف',
        text: formattedText,
        url: window.location.href
      }).catch(() => {});
    } else {
      handleCopyFormattedText();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs font-tajawal animate-fade-in" 
      dir="rtl"
    >
      {/* Hidden Canvas used for high-DPI rendering */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Modal Container */}
      <div className="w-full max-w-xl max-h-[92vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E6E6F0]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center border border-[#E6E6F0] text-amber-200">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-amber-200">
                مشاركة الحديث النبوي الشريف
              </h3>
              <p className="text-xs text-emerald-100/85">
                كصورة مصممة فاخرة أو نص منسق لوسائل التواصل
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection: Image Card vs Formatted Text */}
        <div className="grid grid-cols-2 bg-[#F7F7FC] p-1.5 border-b border-[#E6E6F0]">
          <button
            onClick={() => setActiveTab('image')}
            className={`py-2.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'image'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>صورة مصممة فاخرة 🎨</span>
          </button>

          <button
            onClick={() => setActiveTab('text')}
            className={`py-2.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'text'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>نص منسق للنشر ✍️</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">

          {/* ══════ TAB 1: DESIGNED IMAGE CARD ══════ */}
          {activeTab === 'image' && (
            <div className="space-y-4 animate-fade-in">
              
              {/* Theme Picker */}
              <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]/80 flex items-center justify-between gap-2">
                <span className="text-xs font-black text-gray-700 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-[#5B5FEF]" />
                  <span>طابع التصميم:</span>
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setTheme('emerald')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'emerald'
                        ? 'bg-[#5B5FEF] text-amber-200 shadow-2xs font-black ring-2 ring-[#5B5FEF]'
                        : 'bg-white text-gray-700 hover:bg-[#4CAF82]/12 border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span>زمردي نبوي</span>
                  </button>

                  <button
                    onClick={() => setTheme('parchment')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'parchment'
                        ? 'bg-[#4145C7] text-amber-100 shadow-2xs font-black ring-2 ring-[#5B5FEF]'
                        : 'bg-white text-gray-700 hover:bg-[#EEEEFF] border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-200 border border-amber-400" />
                    <span>مخطوطة عتيقة</span>
                  </button>

                  <button
                    onClick={() => setTheme('midnight')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'midnight'
                        ? 'bg-[#0B1120] text-amber-300 shadow-2xs font-black ring-2 ring-amber-400'
                        : 'bg-white text-gray-700 hover:bg-slate-100 border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                    <span>كحلي وسكينة</span>
                  </button>
                </div>
              </div>

              {/* Visual Card Preview */}
              <div className="relative group rounded-2xl overflow-hidden border-2 border-[#E6E6F0] shadow-md bg-gray-100 flex items-center justify-center">
                {imagePreviewUrl ? (
                  <img
                    src={imagePreviewUrl}
                    alt="بطاقة الحديث المصممة"
                    className="w-full max-h-[360px] object-contain rounded-2xl select-none"
                  />
                ) : (
                  <div className="py-24 text-center text-gray-400 text-xs flex flex-col items-center gap-2">
                    <Sparkles className="w-6 h-6 text-amber-400 animate-spin" />
                    <span>جاري إنشاء البطاقة المصممة...</span>
                  </div>
                )}

                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  <span>معاينة عالية الدقة 1080×1080</span>
                </div>
              </div>

              {/* Action Buttons for Image */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                {/* 1. Share Image Direct */}
                <button
                  onClick={handleShareImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4CAF82] text-white text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Share2 className="w-4 h-4 text-amber-300" />
                  <span>مشاركة الصورة</span>
                </button>

                {/* 2. Download Image */}
                <button
                  onClick={handleDownloadImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-[#25263A] text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل البطاقة (PNG)</span>
                </button>

                {/* 3. Copy Image to Clipboard */}
                <button
                  onClick={handleCopyImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-white hover:bg-gray-100 text-[#25263A] border border-[#E6E6F0] text-xs font-black shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {copiedImage ? (
                    <>
                      <Check className="w-4 h-4 text-[#4CAF82]" />
                      <span className="text-[#4CAF82]">تم نسخ الصورة!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#77798C]" />
                      <span>نسخ الصورة</span>
                    </>
                  )}
                </button>
              </div>

              <p className="text-[11px] text-[#77798C] text-center">
                💡 البطاقة مصممة بمقاس مربع مثالي لحالات واتساب، ستوري إنستغرام، إكس، وتيليجرام.
              </p>
            </div>
          )}

          {/* ══════ TAB 2: FORMATTED TEXT ══════ */}
          {activeTab === 'text' && (
            <div className="space-y-4 animate-fade-in">
              
              {/* Formatted Text Box */}
              <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0]/80 relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-[#77798C]">معاينة النص المنسق:</span>
                  <button
                    onClick={handleCopyFormattedText}
                    className="flex items-center gap-1 text-xs font-bold text-[#4145C7] hover:underline cursor-pointer"
                  >
                    {copiedText ? (
                      <span className="text-[#4CAF82] flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        تم النسخ
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <Copy className="w-3.5 h-3.5" />
                        نسخ النص
                      </span>
                    )}
                  </button>
                </div>

                <pre className="text-xs sm:text-sm text-[#25263A] whitespace-pre-wrap font-tajawal leading-relaxed bg-white p-3.5 rounded-xl border border-[#E6E6F0] max-h-56 overflow-y-auto select-all">
                  {formattedText}
                </pre>
              </div>

              {/* Social Media One-Click Sharing Buttons */}
              <div>
                <span className="text-xs font-bold text-[#77798C] block mb-2 px-1">
                  إرسال مباشر عبر المنصات:
                </span>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {/* WhatsApp */}
                  <button
                    onClick={handleShareWhatsApp}
                    className="py-2.5 px-3 rounded-2xl bg-[#25D366] hover:bg-[#20ba5a] text-white text-xs font-black shadow-2xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>واتساب</span>
                  </button>

                  {/* Telegram */}
                  <button
                    onClick={handleShareTelegram}
                    className="py-2.5 px-3 rounded-2xl bg-[#0088cc] hover:bg-[#0077b5] text-white text-xs font-black shadow-2xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>تيليجرام</span>
                  </button>

                  {/* X (Twitter) */}
                  <button
                    onClick={handleShareTwitter}
                    className="py-2.5 px-3 rounded-2xl bg-black hover:bg-gray-800 text-white text-xs font-black shadow-2xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span className="font-mono text-sm font-bold">𝕏</span>
                    <span>تويتر / إكس</span>
                  </button>

                  {/* System Share */}
                  <button
                    onClick={handleNativeShareText}
                    className="py-2.5 px-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4CAF82] text-white text-xs font-black shadow-2xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>مشاركة عامة</span>
                  </button>
                </div>
              </div>

              {/* Copy Full Text Button */}
              <button
                onClick={handleCopyFormattedText}
                className="w-full py-3 px-4 rounded-2xl bg-[#F7F7FC] hover:bg-gray-100 border border-[#E6E6F0] text-[#25263A] text-xs font-black shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                {copiedText ? (
                  <>
                    <Check className="w-4 h-4 text-[#4CAF82]" />
                    <span className="text-[#4CAF82]">تم نسخ النص المنسق إلى الحافظة بنجاح!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-[#5B5FEF]" />
                    <span>نسخ النص المنسق بالكامل مع التخريج والشرح</span>
                  </>
                )}
              </button>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 border-t border-[#E6E6F0] flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-[#77798C] font-bold">
            <BookMarked className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>{hadith.source} • {hadith.hadithNumber}</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-bold transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
