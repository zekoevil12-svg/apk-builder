import React, { useState, useMemo, useEffect } from 'react';
import { 
  BookMarked, 
  Search, 
  Star, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  Filter, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  Share2, 
  Copy, 
  BookOpen, 
  ArrowRight,
  SlidersHorizontal,
  Grid,
  ListFilter,
  Check,
  Award
} from 'lucide-react';
import { HadithItem, HadithCategoryKey } from '../../types/hadith';
import { AUTHENTIC_HADITHS, HADITH_CATEGORIES } from '../../data/hadithsData';
import { 
  loadHadithFavorites, 
  toggleHadithFavorite, 
  getSavedFontSize, 
  setSavedFontSize, 
  getHadithOfTheDay 
} from '../../utils/hadithStorage';
import { HadithCard } from './HadithCard';
import { HadithDetailModal } from './HadithDetailModal';
import { HadithShareModal } from './HadithShareModal';
import { SahihConditionsModal } from './SahihConditionsModal';
import { HadithSectionSvg } from '../Home/RifqSectionIcons';
import { hadithSpeech } from '../../utils/hadithSpeech';

interface HadithMainViewProps {
  onNavigateHome?: () => void;
}

export const HadithMainView: React.FC<HadithMainViewProps> = ({ onNavigateHome }) => {
  // Navigation tabs: 'today' | 'categories' | 'favorites' | 'search'
  const [activeTab, setActiveTab] = useState<'today' | 'categories' | 'favorites' | 'search'>('today');
  
  // Selected category in categories tab (null = view category grid)
  const [selectedCategory, setSelectedCategory] = useState<HadithCategoryKey | null>(null);

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [narratorFilter, setNarratorFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [sahihOnly, setSahihOnly] = useState(false);

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => loadHadithFavorites());

  // Font size setting (17, 19, 22)
  const [fontSize, setFontSize] = useState<number>(() => getSavedFontSize());

  // Modals
  const [selectedHadithForDetails, setSelectedHadithForDetails] = useState<HadithItem | null>(null);
  const [selectedHadithForShare, setSelectedHadithForShare] = useState<HadithItem | null>(null);
  const [showConditionsModal, setShowConditionsModal] = useState(false);

  // Audio playing
  const [playingHadithId, setPlayingHadithId] = useState<string | null>(null);

  // Hadith of the Day offset (for changing/refreshing)
  const [todayOffset, setTodayOffset] = useState(0);

  // Hadith of the day (guaranteed from Sahihayn: Bukhari or Muslim)
  const hadithOfTheDay = useMemo(() => {
    return getHadithOfTheDay(todayOffset);
  }, [todayOffset]);

  useEffect(() => {
    const handleState = (speaking: boolean) => {
      if (!speaking) {
        setPlayingHadithId(null);
      }
    };
    hadithSpeech.subscribe(handleState);

    return () => {
      hadithSpeech.stop();
    };
  }, []);

  const handleToggleFavorite = (id: string) => {
    toggleHadithFavorite(id);
    setFavorites(loadHadithFavorites());
  };

  const handleFontSizeChange = (size: number) => {
    setFontSize(size);
    setSavedFontSize(size);
  };

  const handlePlayAudio = (hadith: HadithItem) => {
    setPlayingHadithId(hadith.id);
    const speechText = `عن ${hadith.narrator}، قال رسول الله صلى الله عليه وسلم: ${hadith.text}`;
    hadithSpeech.speak(speechText, 1.0, undefined, () => {
      setPlayingHadithId(null);
    });
  };

  const handleStopAudio = () => {
    hadithSpeech.stop();
    setPlayingHadithId(null);
  };

  // Filtered Hadiths list
  const filteredHadiths = useMemo(() => {
    return AUTHENTIC_HADITHS.filter((hadith) => {
      // Strict rule: only Sahih or Hasan
      if (hadith.grade !== 'صحيح' && hadith.grade !== 'حسن') {
        return false;
      }

      // Sahih only filter
      if (sahihOnly && hadith.grade !== 'صحيح') {
        return false;
      }

      // Category filter
      if (selectedCategory && hadith.category !== selectedCategory) {
        return false;
      }

      // Search query in text, narrator, or explanation
      if (searchQuery.trim()) {
        const query = searchQuery.trim().toLowerCase();
        const textMatch = hadith.text.toLowerCase().includes(query);
        const narratorMatch = hadith.narrator.toLowerCase().includes(query);
        const explMatch = hadith.explanation.toLowerCase().includes(query);
        const sourceMatch = hadith.source.toLowerCase().includes(query);
        if (!textMatch && !narratorMatch && !explMatch && !sourceMatch) {
          return false;
        }
      }

      // Narrator filter
      if (narratorFilter.trim()) {
        const nQuery = narratorFilter.trim().toLowerCase();
        if (!hadith.narrator.toLowerCase().includes(nQuery)) {
          return false;
        }
      }

      // Source filter
      if (sourceFilter !== 'all') {
        if (!hadith.source.includes(sourceFilter)) {
          return false;
        }
      }

      return true;
    });
  }, [selectedCategory, searchQuery, narratorFilter, sourceFilter, sahihOnly]);

  // Favorite hadiths list
  const favoriteHadiths = useMemo(() => {
    return AUTHENTIC_HADITHS.filter(h => favorites.includes(h.id));
  }, [favorites]);

  return (
    <div className="w-full max-w-4xl mx-auto pb-24 font-tajawal animate-fade-in" dir="rtl">
      
      {/* ─── Top Banner & Header ─── */}
      <div className="bg-gradient-to-br from-[#5B5FEF] via-[#4CAF82] to-[#144718] rounded-3xl p-6 sm:p-7 text-white shadow-lg border border-[#E6E6F0] relative overflow-hidden mb-6">
        
        {/* Background Islamic Geometric Watermark */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-emerald-300/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          
          <div className="flex items-start sm:items-center gap-3.5">
            {onNavigateHome && (
              <button
                onClick={onNavigateHome}
                className="p-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer shrink-0 mt-1 sm:mt-0"
                title="الرجوع للرئيسية"
              >
                <ArrowRight className="w-5 h-5" />
              </button>
            )}

            <div className="w-12 h-12 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-xs">
              <HadithSectionSvg size={36} />
            </div>

            <div>
              <h1 className="text-xl sm:text-2xl font-black text-amber-200 flex items-center gap-2">
                <span>موسوعة الأحاديث النبوية الصحيحة</span>
              </h1>
              <p className="text-xs sm:text-sm text-emerald-100/90 mt-1">
                سنن النبي المصطفى ﷺ موثقة من أصح الكتب المعتمدة مع الشرح والفوائد
              </p>
            </div>
          </div>

          {/* Educational Conditions Button */}
          <button
            onClick={() => setShowConditionsModal(true)}
            className="self-start sm:self-center px-4 py-2.5 rounded-2xl bg-amber-400/20 hover:bg-amber-400/30 border border-amber-300/50 text-amber-200 text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer shrink-0"
          >
            <ShieldCheck className="w-4 h-4 text-amber-300" />
            <span>شروط الحديث الصحيح 🛡️</span>
          </button>
        </div>

        {/* Global Font Size & Fast Controls Bar */}
        <div className="mt-5 pt-4 border-t border-[#4CAF82]/40/50 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-emerald-200/80 text-xs">حجم خط الحديث:</span>
            <div className="inline-flex rounded-xl bg-black/20 p-1 border border-white/10">
              {[17, 19, 22].map(size => (
                <button
                  key={size}
                  onClick={() => handleFontSizeChange(size)}
                  className={`px-2.5 py-0.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    fontSize === size
                      ? 'bg-[#5B5FEF] text-[#4145C7] shadow-xs font-black'
                      : 'text-emerald-100/80 hover:text-white'
                  }`}
                >
                  {size === 17 ? 'أ' : size === 19 ? 'أ+' : 'أ++'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-amber-200/90">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
            <span>خالٍ تماماً من الأحاديث الضعيفة والموضوعة</span>
          </div>
        </div>
      </div>

      {/* ─── Navigation Tabs ─── */}
      <div className="bg-white rounded-2xl p-1.5 shadow-2xs border border-[#E6E6F0]/80 mb-6 flex items-center justify-between gap-1 overflow-x-auto">
        <button
          onClick={() => { setActiveTab('today'); setSelectedCategory(null); }}
          className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'today'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-50'
          }`}
        >
          <span>☀️</span>
          <span>حديث اليوم</span>
        </button>

        <button
          onClick={() => { setActiveTab('categories'); }}
          className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'categories'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-50'
          }`}
        >
          <span>📑</span>
          <span>التصنيفات</span>
        </button>

        <button
          onClick={() => { setActiveTab('favorites'); setSelectedCategory(null); }}
          className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'favorites'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-50'
          }`}
        >
          <Star className={`w-3.5 h-3.5 ${activeTab === 'favorites' ? 'fill-amber-300 text-amber-300' : 'text-amber-500'}`} />
          <span>المفضلة ({favorites.length})</span>
        </button>

        <button
          onClick={() => { setActiveTab('search'); setSelectedCategory(null); }}
          className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'search'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-50'
          }`}
        >
          <Search className="w-3.5 h-3.5" />
          <span>البحث المتقدم</span>
        </button>
      </div>

      {/* ─── TAB 1: حديث اليوم (Hadith of the Day) ─── */}
      {activeTab === 'today' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Featured Hadith of the Day Card */}
          <div className="bg-gradient-to-br from-[#F7F7FC] via-white to-amber-50/50 rounded-3xl p-6 sm:p-7 border-2 border-[#E6E6F0] shadow-md relative overflow-hidden">
            
            {/* Top Label */}
            <div className="flex items-center justify-between gap-2 pb-4 mb-4 border-b border-[#E6E6F0]">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500 animate-ping" />
                <span className="px-3 py-1 rounded-full bg-[#5B5FEF] text-white text-xs font-black">
                  حديث اليوم المختار
                </span>
                <span className="text-[11px] font-bold text-[#4145C7] bg-[#EEEEFF]/80 px-2 py-0.5 rounded-md border border-[#E6E6F0]">
                  من الصحيحين حصراً ✅
                </span>
              </div>

              {/* Refresh / Next Hadith */}
              <button
                onClick={() => setTodayOffset(prev => prev + 1)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white border border-[#E6E6F0] text-gray-700 hover:text-[#4145C7] text-xs font-bold hover:bg-gray-50 shadow-2xs transition-all cursor-pointer"
                title="عرض حديث آخر من الصحيحين"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">حديث آخر</span>
              </button>
            </div>

            {/* Hadith Text */}
            <div 
              onClick={() => setSelectedHadithForDetails(hadithOfTheDay)}
              className="cursor-pointer group"
            >
              <p 
                className="text-[#4145C7] leading-loose font-black text-justify tracking-wide group-hover:text-[#4145C7] transition-colors"
                style={{ 
                  fontSize: `${fontSize + 2}px`,
                  fontFamily: 'Amiri, Tajawal, serif'
                }}
              >
                {hadithOfTheDay.text}
              </p>

              <div className="mt-4 flex flex-wrap items-center gap-3 text-xs font-bold text-[#77798C]">
                <span className="bg-[#EEEEFF]/80 text-[#4145C7] px-2.5 py-1 rounded-lg">
                  الراوي: {hadithOfTheDay.narrator}
                </span>
                <span className="bg-[#4CAF82]/12/80 text-[#4CAF82] px-2.5 py-1 rounded-lg">
                  المصدر: {hadithOfTheDay.source} ({hadithOfTheDay.hadithNumber})
                </span>
                <span className="bg-white px-2.5 py-1 rounded-lg border border-[#E6E6F0] text-[#4145C7]">
                  الحكم: {hadithOfTheDay.grade} ({hadithOfTheDay.gradeDetail})
                </span>
              </div>
            </div>

            {/* Brief Explanation Preview */}
            <div className="mt-5 p-4 rounded-2xl bg-white/90 border border-[#E6E6F0]/80 text-xs text-gray-700 leading-relaxed">
              <span className="font-bold text-[#4145C7] block mb-1">الشرح الميسّر:</span>
              <p className="line-clamp-3">{hadithOfTheDay.explanation}</p>
            </div>

            {/* Bottom Actions */}
            <div className="mt-5 pt-4 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => setSelectedHadithForDetails(hadithOfTheDay)}
                className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4CAF82] text-white text-xs font-bold shadow-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-amber-300" />
                <span>قراءة الشرح الكامل والفوائد 📖</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedHadithForShare(hadithOfTheDay)}
                  className="p-2.5 rounded-xl border border-[#4CAF82]/40/80 bg-[#4CAF82]/12/80 hover:bg-[#4CAF82]/12 text-[#4145C7] text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                  title="مشاركة الحديث كصورة مصممة أو نص منسق"
                >
                  <Share2 className="w-4 h-4 text-[#4145C7]" />
                  <span>مشاركة</span>
                </button>

                <button
                  onClick={() => {
                    if (playingHadithId === hadithOfTheDay.id) {
                      handleStopAudio();
                    } else {
                      handlePlayAudio(hadithOfTheDay);
                    }
                  }}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    playingHadithId === hadithOfTheDay.id
                      ? 'bg-amber-500 text-white border-amber-500'
                      : 'bg-white border-[#E6E6F0] text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {playingHadithId === hadithOfTheDay.id ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#4145C7]" />}
                  <span>{playingHadithId === hadithOfTheDay.id ? 'إيقاف' : 'استماع'}</span>
                </button>

                <button
                  onClick={() => handleToggleFavorite(hadithOfTheDay.id)}
                  className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                    favorites.includes(hadithOfTheDay.id)
                      ? 'bg-[#EEEEFF] text-amber-500 border-[#E6E6F0]'
                      : 'bg-white text-[#77798C] border-[#E6E6F0] hover:text-amber-500'
                  }`}
                  title="المفضلة"
                >
                  <Star className={`w-4 h-4 ${favorites.includes(hadithOfTheDay.id) ? 'fill-amber-400' : ''}`} />
                </button>
              </div>
            </div>

          </div>

          {/* Quick Category Shortcuts */}
          <div>
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className="text-sm font-black text-[#25263A] flex items-center gap-2">
                <span>تصفح التصنيفات النبوية</span>
              </h3>
              <button
                onClick={() => setActiveTab('categories')}
                className="text-xs text-[#4145C7] hover:underline font-bold"
              >
                عرض كافة التصنيفات ({HADITH_CATEGORIES.length}) ←
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {HADITH_CATEGORIES.slice(0, 5).map(cat => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setActiveTab('categories');
                  }}
                  className="p-3 bg-white rounded-2xl border border-[#E6E6F0]/80 hover:border-[#5B5FEF] hover:shadow-2xs transition-all text-center flex flex-col items-center gap-1 cursor-pointer"
                >
                  <span className="text-xl">{cat.icon}</span>
                  <span className="text-xs font-bold text-[#25263A]">{cat.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Selected highlights from Sunnah */}
          <div className="space-y-3">
            <h3 className="text-sm font-black text-[#25263A] px-1">
              مختارات من أصح الأحاديث النبوية
            </h3>
            <div className="space-y-3">
              {AUTHENTIC_HADITHS.slice(0, 3).map(hadith => (
                <HadithCard
                  key={hadith.id}
                  hadith={hadith}
                  fontSize={fontSize}
                  isFavorite={favorites.includes(hadith.id)}
                  isPlayingAudio={playingHadithId === hadith.id}
                  onToggleFavorite={handleToggleFavorite}
                  onOpenDetails={setSelectedHadithForDetails}
                  onPlayAudio={handlePlayAudio}
                  onStopAudio={handleStopAudio}
                  onShare={setSelectedHadithForShare}
                />
              ))}
            </div>
          </div>

        </div>
      )}

      {/* ─── TAB 2: التصنيفات (Categories) ─── */}
      {activeTab === 'categories' && (
        <div className="space-y-6 animate-fade-in">
          
          {/* Category Selector Pills */}
          <div className="bg-white p-3 rounded-2xl border border-[#E6E6F0]/80 shadow-2xs">
            <div className="flex items-center justify-between gap-2 mb-2 px-1">
              <span className="text-xs font-black text-gray-700">اختر التصنيف النبوي:</span>
              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="text-xs text-[#4145C7] font-bold hover:underline"
                >
                  عرض جميع الأحاديث (إلغاء التصفية)
                </button>
              )}
            </div>

            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === null
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'bg-[#F7F7FC] text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]/60'
                }`}
              >
                الكل ({AUTHENTIC_HADITHS.length})
              </button>

              {HADITH_CATEGORIES.map(cat => {
                const count = AUTHENTIC_HADITHS.filter(h => h.category === cat.id).length;
                const isSelected = selectedCategory === cat.id;

                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#5B5FEF] text-white shadow-2xs'
                        : 'bg-[#F7F7FC] text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]/60'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span>{cat.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-gray-200/70 text-[#77798C]'
                    }`}>
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* If no category is selected, show prominent 10-category cards grid */}
          {!selectedCategory && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {HADITH_CATEGORIES.map(cat => {
                const count = AUTHENTIC_HADITHS.filter(h => h.category === cat.id).length;
                return (
                  <div
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className="bg-white p-4 rounded-3xl border border-[#E6E6F0]/80 hover:border-[#5B5FEF] hover:shadow-sm transition-all cursor-pointer group flex items-start gap-3.5"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0]/60 flex items-center justify-center text-2xl group-hover:scale-105 transition-transform shrink-0">
                      {cat.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-black text-sm text-[#4145C7] group-hover:text-[#4145C7]">
                          {cat.name}
                        </h4>
                        <span className="text-[11px] font-mono font-bold text-[#77798C] bg-[#F7F7FC] px-2 py-0.5 rounded-md border border-[#E6E6F0]">
                          {count} أحاديث
                        </span>
                      </div>
                      <p className="text-xs text-[#77798C] mt-1 leading-relaxed line-clamp-2">
                        {cat.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* List of Hadiths in current selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-[#77798C]">
                الأحاديث المعروضة: ({filteredHadiths.length}) حديثاً موثقاً
              </span>
            </div>

            {filteredHadiths.map(hadith => (
              <HadithCard
                key={hadith.id}
                hadith={hadith}
                fontSize={fontSize}
                isFavorite={favorites.includes(hadith.id)}
                isPlayingAudio={playingHadithId === hadith.id}
                onToggleFavorite={handleToggleFavorite}
                onOpenDetails={setSelectedHadithForDetails}
                onPlayAudio={handlePlayAudio}
                onStopAudio={handleStopAudio}
                onShare={setSelectedHadithForShare}
              />
            ))}
          </div>

        </div>
      )}

      {/* ─── TAB 3: المفضلة (Favorites) ─── */}
      {activeTab === 'favorites' && (
        <div className="space-y-4 animate-fade-in">
          
          <div className="bg-[#EEEEFF]/60 border border-[#E6E6F0]/80 rounded-2xl p-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Star className="w-5 h-5 text-amber-500 fill-amber-400" />
              <div>
                <h3 className="text-sm font-black text-amber-950">الأحاديث المحفوظة في المفضلة</h3>
                <p className="text-xs text-[#4145C7]/80">
                  يمكنك الوصول السريع لأحاديثك المفضلة ومراجعة شروحها في أي وقت
                </p>
              </div>
            </div>
            <span className="text-xs font-bold text-[#4145C7] bg-white px-3 py-1 rounded-xl border border-[#E6E6F0] font-mono">
              {favoriteHadiths.length} حديث
            </span>
          </div>

          {favoriteHadiths.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-[#E6E6F0]">
              <div className="w-16 h-16 rounded-full bg-[#EEEEFF] mx-auto flex items-center justify-center text-amber-400 mb-3">
                <Star className="w-8 h-8" />
              </div>
              <h4 className="font-black text-base text-[#25263A] mb-1">لا توجد أحاديث في المفضلة حالياً</h4>
              <p className="text-xs text-[#77798C] max-w-sm mx-auto mb-4 leading-relaxed">
                اضغط على أيقونة النجمة ⭐ بجانب أي حديث لإضافته إلى قائمة الأحاديث المفضلة للرجوع إليه لاحقاً.
              </p>
              <button
                onClick={() => setActiveTab('categories')}
                className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] text-white text-xs font-bold hover:bg-[#4CAF82] transition-colors cursor-pointer"
              >
                تصفح الأحاديث الآن
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {favoriteHadiths.map(hadith => (
                <HadithCard
                  key={hadith.id}
                  hadith={hadith}
                  fontSize={fontSize}
                  isFavorite={true}
                  isPlayingAudio={playingHadithId === hadith.id}
                  onToggleFavorite={handleToggleFavorite}
                  onOpenDetails={setSelectedHadithForDetails}
                  onPlayAudio={handlePlayAudio}
                  onStopAudio={handleStopAudio}
                  onShare={setSelectedHadithForShare}
                />
              ))}
            </div>
          )}

        </div>
      )}

      {/* ─── TAB 4: البحث المتقدم والفلترة (Search & Filters) ─── */}
      {activeTab === 'search' && (
        <div className="space-y-5 animate-fade-in">
          
          {/* Search Controls Panel */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-2xs space-y-4">
            
            {/* Main Word Search Input */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بكلمة من الحديث (مثال: الأخلاق، الصلاة، الجنة، البركة...)"
                className="w-full pl-10 pr-11 py-3 bg-[#F7F7FC] border border-[#E6E6F0] rounded-2xl text-xs sm:text-sm text-[#25263A] placeholder:text-gray-400 focus:outline-none focus:border-[#5B5FEF] focus:ring-1 focus:ring-[#5B5FEF]"
              />
              <Search className="w-5 h-5 text-gray-400 absolute right-3.5 top-3.5" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3.5 top-3.5 text-xs text-gray-400 hover:text-[#77798C]"
                >
                  مسح
                </button>
              )}
            </div>

            {/* Filter Bar: Narrator, Source, Sahih Only */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-[#E6E6F0]">
              
              {/* Narrator Filter */}
              <div>
                <label className="block text-[11px] font-bold text-[#77798C] mb-1">الصحابي الراوي:</label>
                <input
                  type="text"
                  value={narratorFilter}
                  onChange={(e) => setNarratorFilter(e.target.value)}
                  placeholder="مثال: أبو هريرة، عمر، عائشة..."
                  className="w-full px-3 py-2 bg-white border border-[#E6E6F0] rounded-xl text-xs text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                />
              </div>

              {/* Source Book Filter */}
              <div>
                <label className="block text-[11px] font-bold text-[#77798C] mb-1">الكتاب والمصدر:</label>
                <select
                  value={sourceFilter}
                  onChange={(e) => setSourceFilter(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#E6E6F0] rounded-xl text-xs text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                >
                  <option value="all">كافة المصادر المعتمدة</option>
                  <option value="البخاري">صحيح البخاري</option>
                  <option value="مسلم">صحيح مسلم</option>
                  <option value="الترمذي">جامع الترمذي</option>
                  <option value="أبو داود">سنن أبي داود</option>
                  <option value="ابن ماجه">سنن ابن ماجه</option>
                  <option value="الحاكم">المستدرك للحاكم</option>
                </select>
              </div>

              {/* Sahih Only Toggle */}
              <div className="flex items-center justify-between sm:justify-start gap-2 sm:pt-6">
                <button
                  onClick={() => setSahihOnly(!sahihOnly)}
                  className={`w-full py-2 px-3 rounded-xl border text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    sahihOnly
                      ? 'bg-[#5B5FEF] text-white border-[#4CAF82]/40 shadow-2xs'
                      : 'bg-[#F7F7FC] text-gray-700 border-[#E6E6F0] hover:bg-gray-100'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{sahihOnly ? 'صحيح فقط ✅ (مفعل)' : 'تصفية: صحيح فقط'}</span>
                </button>
              </div>

            </div>

          </div>

          {/* Search Results Count */}
          <div className="flex items-center justify-between px-1 text-xs text-[#77798C] font-bold">
            <span>نتائج البحث: ({filteredHadiths.length}) حديثاً</span>
            {(searchQuery || narratorFilter || sourceFilter !== 'all' || sahihOnly) && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setNarratorFilter('');
                  setSourceFilter('all');
                  setSahihOnly(false);
                }}
                className="text-[#4145C7] hover:underline"
              >
                إعادة تعيين الفلاتر
              </button>
            )}
          </div>

          {/* Results List */}
          {filteredHadiths.length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-[#E6E6F0]">
              <Search className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <h4 className="font-bold text-sm text-gray-700 mb-1">لم يتم العثور على نتائج</h4>
              <p className="text-xs text-[#77798C]">
                جرب البحث بكلمة أخرى أو التخفيف من شروط الفلترة للوصول للحديث المطلوب.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredHadiths.map(hadith => (
                <HadithCard
                  key={hadith.id}
                  hadith={hadith}
                  fontSize={fontSize}
                  isFavorite={favorites.includes(hadith.id)}
                  isPlayingAudio={playingHadithId === hadith.id}
                  onToggleFavorite={handleToggleFavorite}
                  onOpenDetails={setSelectedHadithForDetails}
                  onPlayAudio={handlePlayAudio}
                  onStopAudio={handleStopAudio}
                  onShare={setSelectedHadithForShare}
                />
              ))}
            </div>
          )}

        </div>
      )}

      {/* ─── Modals ─── */}
      {selectedHadithForDetails && (
        <HadithDetailModal
          hadith={selectedHadithForDetails}
          onClose={() => setSelectedHadithForDetails(null)}
          isFavorite={favorites.includes(selectedHadithForDetails.id)}
          onToggleFavorite={handleToggleFavorite}
          fontSize={fontSize}
          onShare={setSelectedHadithForShare}
        />
      )}

      {/* Share Modal (Designed Image & Formatted Text) */}
      <HadithShareModal
        hadith={selectedHadithForShare}
        isOpen={!!selectedHadithForShare}
        onClose={() => setSelectedHadithForShare(null)}
      />

      <SahihConditionsModal
        isOpen={showConditionsModal}
        onClose={() => setShowConditionsModal(false)}
      />

    </div>
  );
};
