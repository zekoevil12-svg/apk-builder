import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  ArrowRight,
  BookOpen,
  Volume2,
  VolumeX,
  CheckCircle2,
  XCircle,
  Sparkles,
  Search,
  Bookmark,
  Copy,
  Share2,
  Check,
  RotateCcw,
  Award,
  PenTool,
  Plus,
  Trash2,
} from 'lucide-react';
import { TajweedSectionSvg, TadabburSectionSvg } from '../Home/RifqSectionIcons';

interface TajweedTadabburViewProps {
  initialTab?: 'tajweed' | 'tadabbur';
  onBack: () => void;
}

// ═══════════════════════════════════════════════════════════════════════════
// 1. بيانات مخارج الحروف المصوّرة (5 مخارج عامة و17 مخرجاً فرعياً)
// ═══════════════════════════════════════════════════════════════════════════
interface MakhrajArea {
  id: 'jawf' | 'halq' | 'lisan' | 'shafatan' | 'khayshoom';
  name: string;
  subtitle: string;
  letters: string[];
  description: string;
  subPoints: {
    title: string;
    letters: string;
    howToPronounce: string;
    commonMistake: string;
    exampleAyah: string;
    surahName: string;
    surahNum: number;
    ayahNum: number;
  }[];
  svgCoords: { cx: number; cy: number; labelX: number; labelY: number; color: string };
}

const MAKHARIJ_DATA: MakhrajArea[] = [
  {
    id: 'jawf',
    name: 'الجَوْف (خلاء الفم والحلق)',
    subtitle: 'مخرج حروف المد الثلاثة',
    letters: ['ا', 'و', 'ي'],
    description:
      'الجوف هو الخلاء الواقع داخل الحلق والفم، وتخرج منه حروف المد الثلاثة: الألف الساكنة المفتوح ما قبلها، والواو الساكنة المضموم ما قبلها، والياء الساكنة المكسور ما قبلها.',
    svgCoords: { cx: 145, cy: 135, labelX: 60, labelY: 135, color: '#E8B84A' },
    subPoints: [
      {
        title: 'حروف المد الثلاثة (نُوحِيهَا)',
        letters: 'الألف (ـَا) • الواو (ـُو) • الياء (ـِي)',
        howToPronounce: 'يخرج الصوت بامتداد الهواء في الجوف دون انحباس في مخرج محقق، وينتهي بانتهاء هواء الفم.',
        commonMistake: 'خلط صوت المدّ بغنة من الخيشوم أو تقصير المد الطبيعي عن حركتين.',
        exampleAyah: 'تِلْكَ مِنْ أَنبَاءِ الْغَيْبِ نُوحِيهَا إِلَيْكَ',
        surahName: 'هود',
        surahNum: 11,
        ayahNum: 49,
      },
    ],
  },
  {
    id: 'halq',
    name: 'الحَلْق (ثلاثة مخارج لستة حروف)',
    subtitle: 'حروف الإظهار الحلقي الستة',
    letters: ['ء', 'هـ', 'ع', 'ح', 'غ', 'خ'],
    description:
      'ينقسم الحلق إلى ثلاث مناطق: أقصى الحلق (مما يلي الصدر)، وسط الحلق، وأدنى الحلق (مما يلي الفم).',
    svgCoords: { cx: 172, cy: 178, labelX: 70, labelY: 185, color: '#4CAF82' },
    subPoints: [
      {
        title: 'أقصى الحلق (الأوتار الصوتية)',
        letters: 'الهمزة (ء) • الهاء (هـ)',
        howToPronounce: 'تخرج الهمزة الساكنة بانطباق الوترين الصوتيين، وتخرج الهاء بانفتاحهما الجزئي مع جريان النفس.',
        commonMistake: 'إضعاف صوت الهاء في أواخر الكلمات مثل (مَالِيَهْ) أو القلقلة في الهمزة.',
        exampleAyah: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
        surahName: 'الفاتحة',
        surahNum: 1,
        ayahNum: 6,
      },
      {
        title: 'وسط الحلق (منطقة لسان المزمار)',
        letters: 'العين (ع) • الحاء (ح)',
        howToPronounce: 'رجوع لسان المزمار إلى جدار الحلق الخلفي مع تضييق المجرى الصوتي.',
        commonMistake: 'تفخيم العين أو الحاء عند مجاورتهما لحرف مفخم مثل (حَصْحَصَ) أو تمييع صوت العين.',
        exampleAyah: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
        surahName: 'الفاتحة',
        surahNum: 1,
        ayahNum: 5,
      },
      {
        title: 'أدنى الحلق (جذر اللسان مع الحنك اللحمي)',
        letters: 'الغين (غ) • الخاء (خ)',
        howToPronounce: 'اقتراب أصل اللسان من الحنك اللحمي؛ وكلاهما من حروف الاستعلاء المفخمة.',
        commonMistake: 'خلط الغين بالقاف أو المبالغة في شخير الخاء.',
        exampleAyah: 'غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
        surahName: 'الفاتحة',
        surahNum: 1,
        ayahNum: 7,
      },
    ],
  },
  {
    id: 'lisan',
    name: 'اللِّسَان (عشرة مخارج لثمانية عشر حرفاً)',
    subtitle: 'أوسع مخارج الحروف العربية',
    letters: ['ق', 'ك', 'ج', 'ش', 'ي', 'ض', 'ل', 'ن', 'ر', 'ط', 'د', 'ت', 'ص', 'ز', 'س', 'ظ', 'ذ', 'ث'],
    description:
      'فيه عشرة مخارج تفصيلية موزعة على: أقصى اللسان، وسط اللسان، حافتي اللسان، وطرف اللسان.',
    svgCoords: { cx: 128, cy: 112, labelX: 52, labelY: 110, color: '#4145C7' },
    subPoints: [
      {
        title: 'أقصى اللسان (القاف والكاف)',
        letters: 'القاف (ق) • الكاف (ك)',
        howToPronounce: 'القاف من أقصى اللسان مع الحنك اللحمي (مفخمة مقلقلة)، والكاف أسفل منها قليلاً مع الحنك اللحمي والعظمي (مهموسة).',
        commonMistake: 'نطق القاف كالكاف أو ترك همس الكاف الساكنة.',
        exampleAyah: 'قُلْ هُوَ اللَّهُ أَحَدٌ',
        surahName: 'الإخلاص',
        surahNum: 112,
        ayahNum: 1,
      },
      {
        title: 'وسط اللسان وحافته (ج ش ي • ض • ل)',
        letters: 'الجيم (ج) • الشين (ش) • الياء غير المدية (ي) • الضاد (ض) • اللام (ل)',
        howToPronounce: 'وسط اللسان مع وسط الحنك الأعلى لـ(ج ش ي)، وحافة اللسان مع الأضراس العليا للضاد، وأدنى الحافة للام.',
        commonMistake: 'إبدال الضاد ظاءً أو دالاً مفخمة، أو رخاوة الجيم.',
        exampleAyah: 'فَمَنْ يَعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ',
        surahName: 'الزلزلة',
        surahNum: 99,
        ayahNum: 7,
      },
      {
        title: 'طرف اللسان (ن ر • ط د ت • ص ز س • ظ ذ ث)',
        letters: 'النون • الراء • النطعية (ط د ت) • الصفير (ص ز س) • اللثوية (ظ ذ ث)',
        howToPronounce: 'طرف اللسان مع لثة الثنايا العليا لـ(ن، ر، ط د ت)، ومع الصفير لـ(ص ز س)، ومع أطراف الثنايا العليا لـ(ظ ذ ث).',
        commonMistake: 'عدم إخراج طرف اللسان في الحروف اللثوية (ظ ذ ث) أو تكرير الراء المبالغ فيه.',
        exampleAyah: 'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ',
        surahName: 'الكوثر',
        surahNum: 108,
        ayahNum: 1,
      },
    ],
  },
  {
    id: 'shafatan',
    name: 'الشَّفَتَان (مخرجان لأربعة حروف)',
    subtitle: 'الفاء • الباء • الميم • الواو غير المدية',
    letters: ['ف', 'ب', 'م', 'و'],
    description:
      'تخرج الفاء من باطن الشفة السفلى مع أطراف الثنايا العليا، وتخرج الباء والميم بانطباق الشفتين، والواو غير المدية بانضمام الشفتين.',
    svgCoords: { cx: 88, cy: 112, labelX: 40, labelY: 85, color: '#4145C7' },
    subPoints: [
      {
        title: 'الشفتان (ف • ب م و)',
        letters: 'الفاء (ف) • الباء (ب) • الميم (م) • الواو (و)',
        howToPronounce: 'انطباق الشفتين في الباء والميم (مع غنة في الميم)، وانضمامهما في الواو، وباطن الشفة السفلى مع الثنايا العليا للفاء.',
        commonMistake: 'المبالغة في كزّ الشفتين عند الإخفاء الشفوي أو الإقلاب، والصواب تلامس خفيف دون كزّ.',
        exampleAyah: 'تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ',
        surahName: 'المسد',
        surahNum: 111,
        ayahNum: 1,
      },
    ],
  },
  {
    id: 'khayshoom',
    name: 'الخَيْشُوم (التجويف الأنفي)',
    subtitle: 'مخرج صِفَة الغُنَّة المركبة في النون والميم',
    letters: ['غنة ن', 'غنة م'],
    description:
      'الخيشوم هو الفتحة المتصلة من أعلى الأنف إلى داخل الحلق، ويخرج منه صوت الغُنَّة الملازم لحرفي النون والميم في جميع أحوالهما وخاصة عند التشديد والإدغام والإخفاء.',
    svgCoords: { cx: 112, cy: 76, labelX: 55, labelY: 55, color: '#D95C6A' },
    subPoints: [
      {
        title: 'الغنة الأكمل (حركتان كاملتان)',
        letters: 'النون المشددة (نّ) • الميم المشددة (مّ) • الإدغام بغنة • الإخفاء • الإقلاب',
        howToPronounce: 'جريان الصوت الرخيم في الخيشوم بمقدار حركتين، ويتبع ما بعده تفخيماً وترقيقاً في الإخفاء الحقيقي.',
        commonMistake: 'إنقاص زمن الغنة عن حركتين عند النون والميم المشددتين مثل (إِنَّ) و(ثُمَّ).',
        exampleAyah: 'عَمَّ يَتَسَاءَلُونَ * عَنِ النَّبَإِ الْعَظِيمِ',
        surahName: 'النبأ',
        surahNum: 78,
        ayahNum: 1,
      },
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 2. بيانات أحكام التجويد المصورة والتطبيقية (مع تلوين الحرف وتلاوة صوتية)
// ═══════════════════════════════════════════════════════════════════════════
interface TajweedRuleLesson {
  id: string;
  category: 'noon' | 'meem' | 'mudood' | 'qalqalah';
  title: string;
  badge: string;
  ruleColor: string;
  letters: string;
  definition: string;
  mushafSign: string;
  howToApply: string;
  examples: {
    prefix: string;
    highlighted: string;
    suffix: string;
    surahName: string;
    surahNum: number;
    ayahNum: number;
    explanation: string;
  }[];
}

const TAJWEED_LESSONS: TajweedRuleLesson[] = [
  {
    id: 'izhar_halqi',
    category: 'noon',
    title: '١. الإظهار الحلقي',
    badge: 'أحكام النون الساكنة والتنوين',
    ruleColor: '#5B5FEF',
    letters: 'ء • هـ • ع • ح • غ • خ (أَخِي هَاكَ عِلْمًا حَازَهُ غَيْرُ خَاسِرٍ)',
    definition:
      'إخراج النون الساكنة أو التنوين من مخرجهما بغير غنة ظاهرة ولا سكت إذا جاء بعدهما أحد حروف الحلق الستة.',
    mushafSign: 'وضع رأس الحاء الصغيرة (ۡ) فوق النون الساكنة، وتراكب الحركتين في التنوين (ـٌ / ـٍ).',
    howToApply: 'قرع طرف اللسان مخرج النون بوضوح ثم الانتقال فوراً لحرف الحلق دون إطالة زمن الغنة.',
    examples: [
      {
        prefix: 'كُلٌّ آمَنَ بِاللَّهِ — ',
        highlighted: 'مَنْ آ',
        suffix: 'مَنَ بِاللَّهِ وَمَلَائِكَتِهِ',
        surahName: 'البقرة',
        surahNum: 2,
        ayahNum: 285,
        explanation: 'نون ساكنة جاء بعدها حرف الهمزة (ء) من حروف الحلق فوجب الإظهار الحلقي.',
      },
      {
        prefix: 'وَإِنَّهُ لَكِتَابٌ — ',
        highlighted: 'عَلِيمٌ حَ',
        suffix: 'كِيمٌ',
        surahName: 'فصلت',
        surahNum: 41,
        ayahNum: 42,
        explanation: 'تنوين بالضم جاء بعده حرف الحاء (ح) من حروف وسط الحلق فوجب الإظهار.',
      },
      {
        prefix: 'وَمَا لَهُم مِّنَ اللَّهِ ',
        highlighted: 'مِنْ هَ',
        suffix: 'ادٍ',
        surahName: 'الرعد',
        surahNum: 13,
        ayahNum: 33,
        explanation: 'نون ساكنة جاء بعدها حرف الهاء (هـ) من أقصى الحلق.',
      },
    ],
  },
  {
    id: 'idgham',
    category: 'noon',
    title: '٢. الإدغام (بغنة وبغير غنة)',
    badge: 'أحكام النون الساكنة والتنوين',
    ruleColor: '#4CAF82',
    letters: 'يَرْمَلُون — بغنة: (ي ن م و - ينمو) | بغير غنة: (ل ر)',
    definition:
      'إدخال النون الساكنة أو التنوين في الحرف المتحرك الذي بعدها بحيث يصيران حرفاً واحداً مشدداً من جنس الثاني (بشرط أن يكون في كلمتين).',
    mushafSign: 'تعرية النون الساكنة من السكون، وتتابع الحركتين في التنوين مع تشديد الحرف التالي.',
    howToApply: 'إذا تلاها (ينمو) ندغم مع غنة بمقدار حركتين، وإذا تلاها (ل، ر) ندغم إدغاماً كاملاً بلا غنة.',
    examples: [
      {
        prefix: 'فَـ',
        highlighted: 'مَن يَ',
        suffix: 'عْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ',
        surahName: 'الزلزلة',
        surahNum: 99,
        ayahNum: 7,
        explanation: 'إدغام ناقص بغنة حركتين؛ لمجيء الياء بعد النون الساكنة في كلمتين.',
      },
      {
        prefix: 'وَلَمْ يَكُـ',
        highlighted: 'ن لَّ',
        suffix: 'هُ كُفُوًا أَحَدٌ',
        surahName: 'الإخلاص',
        surahNum: 112,
        ayahNum: 4,
        explanation: 'إدغام كامل بغير غنة؛ لمجيء اللام بعد النون الساكنة.',
      },
      {
        prefix: 'وَاعْلَمُوا أَنَّ اللَّهَ ',
        highlighted: 'غَفُورٌ رَّ',
        suffix: 'حِيمٌ',
        surahName: 'البقرة',
        surahNum: 2,
        ayahNum: 235,
        explanation: 'إدغام كامل بغير غنة؛ لمجيء الراء بعد التنوين.',
      },
    ],
  },
  {
    id: 'iqlab',
    category: 'noon',
    title: '٣. الإقلاب (القلب)',
    badge: 'أحكام النون الساكنة والتنوين',
    ruleColor: '#72B7E8',
    letters: 'حرف واحد فقط: الباء (ب)',
    definition:
      'قلب النون الساكنة أو التنوين ميماً مخفاة مع الغنة بمقدار حركتين إذا جاء بعدهما حرف الباء، سواء في كلمة أو كلمتين.',
    mushafSign: 'وضع ميم صغيرة قائمة (مـ) فوق النون الساكنة أو مكان الحركة الثانية في التنوين.',
    howToApply: 'تلامس الشفتين برفق لإخفاء الميم المقلوبة مع إجراء الغنة من الخيشوم حركتين ثم النطق بالباء.',
    examples: [
      {
        prefix: 'كَلَّا لَـ',
        highlighted: 'يُنبَ',
        suffix: 'ذَنَّ فِي الْحُطَمَةِ',
        surahName: 'الهمزة',
        surahNum: 104,
        ayahNum: 4,
        explanation: 'إقلاب في كلمة واحدة؛ جاءت الباء بعد النون الساكنة في (لَيُنبَذَنَّ).',
      },
      {
        prefix: 'إِنَّ اللَّهَ ',
        highlighted: 'سَمِيعٌ بَ',
        suffix: 'صِيرٌ',
        surahName: 'الحج',
        surahNum: 22,
        ayahNum: 75,
        explanation: 'إقلاب التنوين ميماً مخفاة بغنة لمجيء الباء بعده.',
      },
    ],
  },
  {
    id: 'ikhfaa_haqiqi',
    category: 'noon',
    title: '٤. الإخفاء الحقيقي',
    badge: 'أحكام النون الساكنة والتنوين',
    ruleColor: '#D95C6A',
    letters: '١٥ حرفاً (ص ذ ث ك ج ش ق س د ط ز ف ت ض ظ)',
    definition:
      'النطق بالنون الساكنة أو التنوين بحالة متوسطة بين الإظهار والإدغام عارياً عن التشديد مع بقاء الغنة بمقدار حركتين.',
    mushafSign: 'تعرية النون من السكون مع عدم تشديد الحرف الذي يليها.',
    howToApply: 'تهيئة الفم على مخرج الحرف التالي للنون مع إخراج الغنة (مفخمة إن تلاها حرف استعلاء، ومرققة إن تلاها حرف استفال).',
    examples: [
      {
        prefix: '',
        highlighted: 'مِن شَ',
        suffix: 'رِّ مَا خَلَقَ',
        surahName: 'الفلق',
        surahNum: 113,
        ayahNum: 2,
        explanation: 'إخفاء حقيقي بغنة مرققة؛ لمجيء الشين بعد النون الساكنة.',
      },
      {
        prefix: 'الَّذِينَ هُمْ ',
        highlighted: 'عَن صَ',
        suffix: 'لَاتِهِمْ سَاهُونَ',
        surahName: 'الماعون',
        surahNum: 107,
        ayahNum: 5,
        explanation: 'إخفاء حقيقي بغنة مفخمة؛ لمجيء حرف الصاد (المفخم) بعد النون الساكنة.',
      },
    ],
  },
  {
    id: 'meem_sakina',
    category: 'meem',
    title: '٥. أحكام الميم الساكنة الثلاثة',
    badge: 'أحكام الميم الساكنة',
    ruleColor: '#6A1B9A',
    letters: 'الإخفاء الشفوي (ب) • الإدغام الشفوي (م) • الإظهار الشفوي (باقي الحروف ٢٦)',
    definition:
      'للميم الساكنة ثلاثة أحكام: تخفى عند الباء بغنة، وتدغم في مثلها (الميم) بغنة، وتظهر عند باقي الحروف (وأشد ما تكون إظهاراً عند الواو والفاء).',
    mushafSign: 'تعرية الميم عند الباء والميم، ووضع رأس الحاء (مْ) عند حروف الإظهار الشفوي.',
    howToApply: 'احذر أن تخفي الميم الساكنة عند الواو أو الفاء لاتحاد أو تقارب المخرج.',
    examples: [
      {
        prefix: 'تَرْمِيهِـ',
        highlighted: 'م بِ',
        suffix: 'حِجَارَةٍ مِّن سِجِّيلٍ',
        surahName: 'الفيل',
        surahNum: 105,
        ayahNum: 4,
        explanation: 'إخفاء شفوي بغنة حركتين؛ لمجيء الباء بعد الميم الساكنة.',
      },
      {
        prefix: 'الَّذِي أَطْعَمَهُم مِّن جُوعٍ وَآمَنَـ',
        highlighted: 'هُم مِّ',
        suffix: 'نْ خَوْفٍ',
        surahName: 'قريش',
        surahNum: 106,
        ayahNum: 4,
        explanation: 'إدغام متماثلين صغير (شفوي) بغنة أكمل ما تكون.',
      },
      {
        prefix: 'أَلَمْ يَجْعَلْ كَيْدَ',
        highlighted: 'هُمْ فِ',
        suffix: 'ي تَضْلِيلٍ',
        surahName: 'الفيل',
        surahNum: 105,
        ayahNum: 2,
        explanation: 'إظهار شفوي؛ مع الحذر الشديد من إخفاء الميم عند الفاء.',
      },
    ],
  },
  {
    id: 'mudood',
    category: 'mudood',
    title: '٦. أحكام المدود (الطبيعي والفرعي)',
    badge: 'أحكام المدود',
    ruleColor: '#D95C6A',
    letters: 'حروف المد (ا، و، ي) — سببه الهمز أو السكون',
    definition:
      'المد الطبيعي يمد حركتين بلا زيادة، والمد الفرعي يتوقف على سبب كالهمز (المد المتصل الواجب ٤-٥ حركات، والمنفصل الجائز ٤-٥ حركات) أو السكون (اللازم ٦ حركات لزوماً، والعارض للسكون ٢ أو ٤ أو ٦).',
    mushafSign: 'وضع علامة المد (ٓ) فوق حرف المد إذا تلاه همز أو سكون.',
    howToApply: 'ضبط مقادير المدود بالميزان الصوتي المتساوي دون تفاوت بين النظائر في القراءة الواحدة.',
    examples: [
      {
        prefix: 'إِذَا ',
        highlighted: 'جَاءَ',
        suffix: ' نَصْرُ اللَّهِ وَالْفَتْحُ',
        surahName: 'النصر',
        surahNum: 110,
        ayahNum: 1,
        explanation: 'مد واجب متصل (٤ أو ٥ حركات)؛ لأن حرف المد والهمزة اجتمعا في كلمة واحدة.',
      },
      {
        prefix: '',
        highlighted: 'إِنَّا أَ',
        suffix: 'عْطَيْنَاكَ الْكَوْثَرَ',
        surahName: 'الكوثر',
        surahNum: 108,
        ayahNum: 1,
        explanation: 'مد جائز منفصل؛ لأن حرف المد في آخر الكلمة الأولى والهمزة في أول الكلمة الثانية.',
      },
      {
        prefix: 'غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا ',
        highlighted: 'الضَّالِّ',
        suffix: 'ينَ',
        surahName: 'الفاتحة',
        surahNum: 1,
        ayahNum: 7,
        explanation: 'مد لازم كلمي مثقل يمد ٦ حركات لزوماً؛ لمجيء الحرف المشدد بعد حرف المد.',
      },
    ],
  },
  {
    id: 'qalqalah',
    category: 'qalqalah',
    title: '٧. القلقلة (قُطْبُ جَدٍ)',
    badge: 'صفات الحروف اللازمة',
    ruleColor: '#00695C',
    letters: 'خمسة حروف مجموعة في: (قُطْبُ جَدٍ) بشرط سكونها',
    definition:
      'اضطراب الحرف الساكن في مخرجه عند النطق به بالتباعد بين طرفي عضو النطق دون أن يصاحبه شائبة حركة، وهي صغرى وسط الكلام وكبرى عند الوقف.',
    mushafSign: 'وجود علامة السكون (ۡ) على أحد حروف (قطب جد) أو سكونه عارضاً لأجل الوقف.',
    howToApply: 'تجنب إمالة صوت القلقلة إلى الفتح أو الكسر أو الضم، بل يخرج الصوت صافياً بالتصادم والتباعد.',
    examples: [
      {
        prefix: 'قُلْ أَعُوذُ بِرَبِّ ',
        highlighted: 'الْفَلَقْ',
        suffix: '',
        surahName: 'الفلق',
        surahNum: 113,
        ayahNum: 1,
        explanation: 'قلقلة كبرى في حرف القاف عند الوقف على رأس الآية.',
      },
      {
        prefix: 'لَمْ ',
        highlighted: 'يَلِدْ',
        suffix: ' وَلَمْ ',
        surahName: 'الإخلاص',
        surahNum: 112,
        ayahNum: 3,
        explanation: 'قلقلة صغرى في الدال الساكنة في (يَلِدْ) وسط الآية.',
      },
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 3. أسئلة الاختبار التفاعلي لتحديد الحكم التجويدي في الكلمة
// ═══════════════════════════════════════════════════════════════════════════
interface TajweedQuizQuestion {
  id: number;
  ayahSnippet: string;
  targetWord: string;
  surahInfo: string;
  surahNum: number;
  ayahNum: number;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const TAJWEED_QUIZ_QUESTIONS: TajweedQuizQuestion[] = [
  {
    id: 1,
    ayahSnippet: '﴿ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ ﴾',
    targetWord: 'حَاسِدٍ إِذَا',
    surahInfo: 'سورة الفلق: ٥',
    surahNum: 113,
    ayahNum: 5,
    options: ['إظهار حلقي', 'إدغام بغنة', 'إخفاء حقيقي', 'إقلاب'],
    correctIndex: 0,
    explanation: 'الحكم إظهار حلقي؛ لأن التنوين في (حَاسِدٍ) جاء بعده حرف الهمزة (إِذَا) وهو من حروف أقصى الحلق.',
  },
  {
    id: 2,
    ayahSnippet: '﴿ فَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ ﴾',
    targetWord: 'فَمَن يَعْمَلْ',
    surahInfo: 'سورة الزلزلة: ٧',
    surahNum: 99,
    ayahNum: 7,
    options: ['إدغام بغير غنة', 'إدغام ناقص بغنة', 'إظهار حلقي', 'إخفاء حقيقي'],
    correctIndex: 1,
    explanation: 'الحكم إدغام ناقص بغنة بمقدار حركتين؛ لمجيء حرف الياء (من حروف ينمو) بعد النون الساكنة في كلمتين.',
  },
  {
    id: 3,
    ayahSnippet: '﴿ كَلَّا لَيُنبَذَنَّ فِي الْحُطَمَةِ ﴾',
    targetWord: 'لَيُنبَذَنَّ',
    surahInfo: 'سورة الهمزة: ٤',
    surahNum: 104,
    ayahNum: 4,
    options: ['إخفاء شفوي', 'إقلاب', 'إدغام بغنة', 'إظهار شفوي'],
    correctIndex: 1,
    explanation: 'الحكم إقلاب؛ لأن النون الساكنة جاء بعدها حرف الباء في كلمة واحدة فتُقلب ميماً مخفاة بغنة.',
  },
  {
    id: 4,
    ayahSnippet: '﴿ تَرْمِيهِم بِحِجَارَةٍ مِّن سِجِّيلٍ ﴾',
    targetWord: 'تَرْمِيهِم بِحِجَارَةٍ',
    surahInfo: 'سورة الفيل: ٤',
    surahNum: 105,
    ayahNum: 4,
    options: ['إقلاب', 'إظهار شفوي', 'إخفاء شفوي', 'إدغام متماثلين'],
    correctIndex: 2,
    explanation: 'الحكم إخفاء شفوي؛ لأنها ميم ساكنة أصلية جاء بعدها حرف الباء، فتُخفى مع الغنة حركتين.',
  },
  {
    id: 5,
    ayahSnippet: '﴿ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ ﴾',
    targetWord: 'يَكُن لَّهُ',
    surahInfo: 'سورة الإخلاص: ٤',
    surahNum: 112,
    ayahNum: 4,
    options: ['إدغام كامل بغير غنة', 'إدغام بغنة', 'إخفاء حقيقي', 'إظهار حلقي'],
    correctIndex: 0,
    explanation: 'الحكم إدغام كامل بغير غنة؛ لمجيء حرف اللام بعد النون الساكنة.',
  },
  {
    id: 6,
    ayahSnippet: '﴿ إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ ﴾',
    targetWord: 'جَاءَ',
    surahInfo: 'سورة النصر: ١',
    surahNum: 110,
    ayahNum: 1,
    options: ['مد جائز منفصل', 'مد واجب متصل', 'مد لازم كلمي', 'مد بدل'],
    correctIndex: 1,
    explanation: 'الحكم مد واجب متصل (٤-٥ حركات)؛ لأن حرف المد (الألف) والهمزة اجتمعا في كلمة واحدة.',
  },
  {
    id: 7,
    ayahSnippet: '﴿ الْحَاقَّةُ * مَا الْحَاقَّةُ ﴾',
    targetWord: 'الْحَاقَّةُ',
    surahInfo: 'سورة الحاقة: ١',
    surahNum: 69,
    ayahNum: 1,
    options: ['مد عارض للسكون', 'مد واجب متصل', 'مد لازم كلمي مثقل (٦ حركات)', 'مد طبيعي'],
    correctIndex: 2,
    explanation: 'الحكم مد لازم كلمي مثقل يُمد ٦ حركات لزوماً؛ لمجيء الحرف المشدد (القاف) بعد حرف المد.',
  },
  {
    id: 8,
    ayahSnippet: '﴿ الَّذِينَ هُمْ عَن صَلَاتِهِمْ سَاهُونَ ﴾',
    targetWord: 'عَن صَلَاتِهِمْ',
    surahInfo: 'سورة الماعون: ٥',
    surahNum: 107,
    ayahNum: 5,
    options: ['إظهار حلقي', 'إخفاء حقيقي بغنة مفخمة', 'إخفاء حقيقي بغنة مرققة', 'إدغام بغنة'],
    correctIndex: 1,
    explanation: 'الحكم إخفاء حقيقي بغنة مفخمة؛ لأن الصاد من حروف الإخفاء وهي من حروف الاستعلاء المفخمة (خص ضغط قظ).',
  },
  {
    id: 9,
    ayahSnippet: '﴿ وَالسَّمَاءِ ذَاتِ الْبُرُوجِ ﴾',
    targetWord: 'الْبُرُوجْ (عند الوقف)',
    surahInfo: 'سورة البروج: ١',
    surahNum: 85,
    ayahNum: 1,
    options: ['همس', 'قلقلة كبرى في الجيم', 'إظهار حلقي', 'غنة حركتين'],
    correctIndex: 1,
    explanation: 'الحكم قلقلة كبرى؛ لأن الجيم من حروف (قطب جد) وسكنت سكوناً عارضاً لأجل الوقف.',
  },
  {
    id: 10,
    ayahSnippet: '﴿ أَلَمْ يَجْعَلْ كَيْدَهُمْ فِي تَضْلِيلٍ ﴾',
    targetWord: 'كَيْدَهُمْ فِي',
    surahInfo: 'سورة الفيل: ٢',
    surahNum: 105,
    ayahNum: 2,
    options: ['إخفاء شفوي', 'إظهار شفوي أشد إظهاراً', 'إدغام شفوي', 'إقلاب'],
    correctIndex: 1,
    explanation: 'الحكم إظهار شفوي؛ لمجيء الفاء بعد الميم الساكنة، ويجب الحذر من إخفاء الميم عند الفاء لقرب المخرج.',
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 4. بيانات تدبرات وفوائد قرآنية (آية وفائدة) من أمهات كتب التفسير
// ═══════════════════════════════════════════════════════════════════════════
export interface TadabburItem {
  id: string;
  surahName: string;
  surahNum: number;
  ayahNum: number;
  ayahText: string;
  topic: 'tawakkul' | 'duaa' | 'quloob' | 'sabr' | 'akhlaq' | 'akhirah';
  topicLabel: string;
  title: string;
  reflection: string;
  actionStep: string;
  sourceBook: string;
  scholar: string;
}

const TADABBUR_ITEMS: TadabburItem[] = [
  {
    id: 'tad_1',
    surahName: 'الطلاق',
    surahNum: 65,
    ayahNum: 2,
    ayahText: 'وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا * وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ ۚ وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ',
    topic: 'tawakkul',
    topicLabel: 'التوكل واليقين',
    title: 'الجمع بين تقوى الله والتوكل عليه مفتاح كل فرج',
    reflection:
      'رتّب الله سبحانه المخرج من كل ضيق والرزق من وجوه لا تخطر ببال العبد على تحقيق التقوى، ثم ختم بقوله (وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ) أي كافيه كل ما أهمّه من أمر دينه ودنياه؛ فمن كان الله كافيه فلا مطمع لأحد في خذلانه.',
    actionStep: 'عند كل أمر يضيق عليك اليوم، راقب تقوى الله في خطوتك وقل بيقين: حسبي الله وكفى.',
    sourceBook: 'تيسير الكريم الرحمن في تفسير كلام المنان',
    scholar: 'الشيخ عبد الرحمن بن ناصر السعدي',
  },
  {
    id: 'tad_2',
    surahName: 'البقرة',
    surahNum: 2,
    ayahNum: 186,
    ayahText: 'وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ',
    topic: 'duaa',
    topicLabel: 'الدعاء والفرج',
    title: 'سرّ حذف الواسطة في آية الدعاء',
    reflection:
      'في كل الأسئلة في القرآن يأتي الجواب بـ(قُلْ) إلا في هذه الآية؛ فلم يقل سبحانه (فقل إني قريب) بل قال مباشرة: (فَإِنِّي قَرِيبٌ)، إشعاراً بغاية القرب ورفع الحجاب بين العبد الداعي وربه متى أخلص القلب وانطرح بين يديه.',
    actionStep: 'اجعل لك اليوم خلوة صادقة تناجي فيها ربك بأسمائه الحسنى دون عجلة موقناً بالإجابة.',
    sourceBook: 'بدائع الفوائد ومدارج السالكين',
    scholar: 'الإمام ابن قيم الجوزية',
  },
  {
    id: 'tad_3',
    surahName: 'الشعراء',
    surahNum: 26,
    ayahNum: 88,
    ayahText: 'يَوْمَ لَا يَنفَعُ مَالٌ وَلَا بَنُونَ * إِلَّا مَنْ أَتَى اللَّهَ بِقَلْبٍ سَلِيمٍ',
    topic: 'quloob',
    topicLabel: 'صلاح القلوب',
    title: 'حقيقة القلب السليم الذي ينجو صاحبه يوم القيامة',
    reflection:
      'القلب السليم هو الذي سَلِمَ من الشرك والغلّ والحقد والحسد والشحّ والكبر وحب الدنيا؛ فسلِم من كل شهوة تخالف أمر الله، ومن كل شبهة تعارض خبره، فصار خالصاً لله محبةً وإنابةً وتوكلاً.',
    actionStep: 'طهّر قلبك قبل نومك الليلة بالعفو عن كل مسلم وتنقية الصدر من الشحناء.',
    sourceBook: 'إغاثة اللهفان وتفسير ابن كثير',
    scholar: 'الإمام ابن القيم والحافظ ابن كثير',
  },
  {
    id: 'tad_4',
    surahName: 'الأنبياء',
    surahNum: 21,
    ayahNum: 87,
    ayahText: 'فَنَادَىٰ فِي الظُّلُمَاتِ أَن لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ * فَاسْتَجَبْنَا لَهُ وَنَجَّيْنَاهُ مِنَ الْغَمِّ ۚ وَكَذَٰلِكَ نُنجِي الْمُؤْمِنِينَ',
    topic: 'duaa',
    topicLabel: 'الدعاء والفرج',
    title: 'وعدٌ إلهي عام لكل مكروب إلى يوم القيامة',
    reflection:
      'جمعت دعوة ذي النون عليه السلام ثلاثة أركان للفرج: كمال التوحيد (لَا إِلَٰهَ إِلَّا أَنتَ)، وتنزيه الله عن الظلم (سُبْحَانَكَ)، والاعتراف بالتقصير (إِنِّي كُنتُ مِنَ الظَّالِمِينَ)، ثم أتبعه الله بوعد عام غير خاص بيونس: (وَكَذَٰلِكَ نُنجِي الْمُؤْمِنِينَ).',
    actionStep: 'أكثر من دعاء ذي النون في سجودك وعند كل همّ أو كرب يلمّ بك.',
    sourceBook: 'الفوائد',
    scholar: 'الإمام ابن قيم الجوزية',
  },
  {
    id: 'tad_5',
    surahName: 'الشرح',
    surahNum: 94,
    ayahNum: 5,
    ayahText: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا * إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    topic: 'sabr',
    topicLabel: 'الصبر والابتلاء',
    title: 'لن يغلبَ عسرٌ واحدٌ يُسرَين',
    reflection:
      'جاء لفظ (الْعُسْرِ) معرّفاً بأل في الموضعين فهو عسر واحد، وجاء لفظ (يُسْرًا) منكّراً في الموضعين فهما يسران اثنان، وعبّر بحرف المصاحبة (مَعَ) لا (بعد) ليدل على أن اليسر مقارن للعسر كامنٌ في طياته.',
    actionStep: 'استبشر بالفرج في قلب الشدة، فاليسر يولد من رحم الصبر والرضا.',
    sourceBook: 'التحرير والتنوير وتفسير السعدي',
    scholar: 'الشيخ الطاهر بن عاشور والشيخ السعدي',
  },
  {
    id: 'tad_6',
    surahName: 'فصلت',
    surahNum: 41,
    ayahNum: 34,
    ayahText: 'وَلَا تَسْتَوِي الْحَسَنَةُ وَلَا السَّيِّئَةُ ۚ ادْفَعْ بِالَّتِي هِيَ أَحْسَنُ فَإِذَا الَّذِي بَيْنَكَ وَبَيْنَهُ عَدَاوَةٌ كَأَنَّهُ وَلِيٌّ حَمِيمٌ',
    topic: 'akhlaq',
    topicLabel: 'الأخلاق والمعاملات',
    title: 'كيمياء الخلق الحسن في تحويل العداوة إلى مودة',
    reflection:
      'لم يأمر الله بالدفع بالحسنة فحسب، بل بـ(الَّتِي هِيَ أَحْسَنُ)؛ فإذا قابلت الجهل بالحلم، والإساءة بالإحسان، والقطيعة بالصلة، انقلب المعادي بقدرة مقلب القلوب إلى صديق قريب شفيق، ولا يلقاها إلا الذين صبروا.',
    actionStep: 'قابل موقفاً واحداً مزعجاً اليوم بالرفق والكلمة الطيبة ابتغاء وجه الله.',
    sourceBook: 'تفسير القرآن العظيم',
    scholar: 'الحافظ ابن كثير الدمشقي',
  },
  {
    id: 'tad_7',
    surahName: 'الكهف',
    surahNum: 18,
    ayahNum: 46,
    ayahText: 'الْمَالُ وَالْبَنُونَ زِينَةُ الْحَيَاةِ الدُّنْيَا ۖ وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِندَ رَبِّكَ ثَوَابًا وَخَيْرٌ أَمَلًا',
    topic: 'akhirah',
    topicLabel: 'الآخرة والجزاء',
    title: 'بين زينةٍ فانية وباقياتٍ خالدة',
    reflection:
      'سمّى الله المال والبنين (زِينَة) لأنها تجمّل ظاهر العيش لكنها تنقضي، وسمّى الطاعات والأذكار (الْبَاقِيَاتُ الصَّالِحَاتُ) لأن أثرها وثوابها باقٍ لا يفنى، وهي خير ثواباً عند الله وخير ما يأمله العبد يوم يلقاه.',
    actionStep: 'اجعل لسانك رطباً بـ: سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر، ولا حول ولا قوة إلا بالله.',
    sourceBook: 'تيسير الكريم الرحمن',
    scholar: 'الشيخ عبد الرحمن السعدي',
  },
  {
    id: 'tad_8',
    surahName: 'الذاريات',
    surahNum: 51,
    ayahNum: 50,
    ayahText: 'فَفِرُّوا إِلَى اللَّهِ ۖ إِنِّي لَكُم مِّنْهُ نَذِيرٌ مُّبِينٌ',
    topic: 'quloob',
    topicLabel: 'صلاح القلوب',
    title: 'الفرار منه إليه سبحانه',
    reflection:
      'كل شيء تخافه تفرّ منه إلا الله سبحانه، فإنك إذا خفته فررت إليه؛ فراراً من الجهل إلى العلم، ومن المعصية إلى التوبة، ومن الغفلة إلى الذكر، ومن وحشة الخلق إلى أنس الخالق جل جلاله.',
    actionStep: 'كلما شعرت بفتور أو وحشة، بادر بركعتين خاشعتين تفرّ بهما إلى الله.',
    sourceBook: 'مدارج السالكين بين منازل إياك نعبد وإياك نستعين',
    scholar: 'الإمام ابن قيم الجوزية',
  },
];

export const TajweedTadabburView: React.FC<TajweedTadabburViewProps> = ({
  initialTab = 'tajweed',
  onBack,
}) => {
  const [mainSection, setMainSection] = useState<'tajweed' | 'tadabbur'>(initialTab);

  // Sub-tabs inside Tajweed
  const [tajweedSubTab, setTajweedSubTab] = useState<'makharij' | 'rules' | 'quiz'>('rules');
  const [selectedMakhrajId, setSelectedMakhrajId] = useState<MakhrajArea['id']>('halq');
  const [selectedRuleCategory, setSelectedRuleCategory] = useState<'all' | 'noon' | 'meem' | 'mudood' | 'qalqalah'>('all');

  // Audio player state
  const [playingAudioKey, setPlayingAudioKey] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Quiz state
  const [quizIdx, setQuizIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [bestScore, setBestScore] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_tajweed_best_score');
    return saved ? parseInt(saved, 10) : 0;
  });

  // Tadabbur state
  const [tadabburTopic, setTadabburTopic] = useState<string>('all');
  const [tadabburSearch, setTadabburSearch] = useState<string>('');
  const [favoriteTadabburIds, setFavoriteTadabburIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('rifq_tadabbur_favorites');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [personalNotes, setPersonalNotes] = useState<Record<string, string>>(() => {
    try {
      const raw = localStorage.getItem('rifq_tadabbur_notes');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteDraft, setNoteDraft] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    setMainSection(initialTab);
  }, [initialTab]);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  // Play real Quranic ayah audio from EveryAyah (Husary Muallim / Alafasy)
  const playAyahAudio = (surahNum: number, ayahNum: number, key: string) => {
    if (playingAudioKey === key && audioRef.current) {
      audioRef.current.pause();
      setPlayingAudioKey(null);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
    }

    const sStr = String(surahNum).padStart(3, '0');
    const aStr = String(ayahNum).padStart(3, '0');
    const primaryUrl = `https://everyayah.com/data/Husary_128kbps/${sStr}${aStr}.mp3`;
    const fallbackUrl = `https://everyayah.com/data/Alafasy_128kbps/${sStr}${aStr}.mp3`;

    const audio = new Audio(primaryUrl);
    audioRef.current = audio;
    setPlayingAudioKey(key);

    audio.onended = () => setPlayingAudioKey(null);
    audio.onerror = () => {
      const fallback = new Audio(fallbackUrl);
      audioRef.current = fallback;
      fallback.onended = () => setPlayingAudioKey(null);
      fallback.onerror = () => {
        setPlayingAudioKey(null);
        showToast('تعذر تشغيل التلاوة الصوتية، تأكد من الاتصال بالإنترنت');
      };
      fallback.play().catch(() => setPlayingAudioKey(null));
    };

    audio.play().catch(() => {
      setPlayingAudioKey(null);
    });
  };

  const activeMakhraj = useMemo(
    () => MAKHARIJ_DATA.find((m) => m.id === selectedMakhrajId) || MAKHARIJ_DATA[0],
    [selectedMakhrajId]
  );

  const filteredRules = useMemo(() => {
    if (selectedRuleCategory === 'all') return TAJWEED_LESSONS;
    return TAJWEED_LESSONS.filter((r) => r.category === selectedRuleCategory);
  }, [selectedRuleCategory]);

  const filteredTadabbur = useMemo(() => {
    return TADABBUR_ITEMS.filter((item) => {
      if (tadabburTopic === 'favorites' && !favoriteTadabburIds.includes(item.id)) return false;
      if (tadabburTopic !== 'all' && tadabburTopic !== 'favorites' && item.topic !== tadabburTopic) {
        return false;
      }
      if (tadabburSearch.trim()) {
        const q = tadabburSearch.trim();
        return (
          item.title.includes(q) ||
          item.ayahText.includes(q) ||
          item.surahName.includes(q) ||
          item.reflection.includes(q)
        );
      }
      return true;
    });
  }, [tadabburTopic, tadabburSearch, favoriteTadabburIds]);

  const toggleTadabburFavorite = (id: string) => {
    setFavoriteTadabburIds((prev) => {
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      localStorage.setItem('rifq_tadabbur_favorites', JSON.stringify(next));
      showToast(next.includes(id) ? 'تم حفظ الفائدة في المفضلة' : 'تمت إزالة الفائدة من المفضلة');
      return next;
    });
  };

  const savePersonalNote = (id: string) => {
    const trimmed = noteDraft.trim();
    const updated = { ...personalNotes };
    if (trimmed) {
      updated[id] = trimmed;
      showToast('تم حفظ خاطرتك التدبرية بنجاح');
    } else {
      delete updated[id];
    }
    setPersonalNotes(updated);
    localStorage.setItem('rifq_tadabbur_notes', JSON.stringify(updated));
    setEditingNoteId(null);
    setNoteDraft('');
  };

  const handleAnswerQuiz = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    const currentQ = TAJWEED_QUIZ_QUESTIONS[quizIdx];
    if (idx === currentQ.correctIndex) {
      setQuizScore((s) => s + 1);
    }
  };

  const handleNextQuestion = () => {
    if (quizIdx + 1 < TAJWEED_QUIZ_QUESTIONS.length) {
      setQuizIdx((i) => i + 1);
      setSelectedAnswer(null);
    } else {
      setQuizFinished(true);
      if (quizScore > bestScore) {
        setBestScore(quizScore);
        localStorage.setItem('rifq_tajweed_best_score', String(quizScore));
      }
    }
  };

  const resetQuiz = () => {
    setQuizIdx(0);
    setSelectedAnswer(null);
    setQuizScore(0);
    setQuizFinished(false);
  };

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 select-none" dir="rtl">
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-[#F7F7FC] px-5 py-2.5 rounded-2xl shadow-xl text-xs font-cairo font-bold border border-[#5B5FEF] animate-fade-in">
          {toast}
        </div>
      )}

      {/* الشريط العلوي */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-3.5 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onBack}
                className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
                aria-label="رجوع"
              >
                <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
              </button>
              <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
                {mainSection === 'tajweed' ? (
                  <TajweedSectionSvg size={28} />
                ) : (
                  <TadabburSectionSvg size={28} />
                )}
              </div>
              <div>
                <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                  {mainSection === 'tajweed'
                    ? 'أحكام التجويد التفاعلية'
                    : 'تدبرات وفوائد قرآنية (آية وفائدة)'}
                </h1>
                <p className="text-xs text-[#77798C]">
                  {mainSection === 'tajweed'
                    ? 'شرح مصوّر لمخارج الحروف والأحكام مع التلاوة الصوتية والاختبارات'
                    : 'لطائف وتدبرات موثقة من أمهات كتب التفسير المعتمدة'}
                </p>
              </div>
            </div>
          </div>

          {/* مبدّل القسمين: أحكام التجويد | آية وفائدة */}
          <div className="flex items-center bg-[#F7F7FC] p-1 rounded-2xl border border-[#E6E6F0] self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setMainSection('tajweed')}
              className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer ${
                mainSection === 'tajweed'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:text-[#4145C7]'
              }`}
            >
              أحكام التجويد التفاعلية
            </button>
            <button
              type="button"
              onClick={() => setMainSection('tadabbur')}
              className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer ${
                mainSection === 'tadabbur'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:text-[#4145C7]'
              }`}
            >
              آية وفائدة (تدبرات)
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* ═════════════════════════════════════════════════════════════════
            القسم الأول: أحكام التجويد التفاعلية
        ═════════════════════════════════════════════════════════════════ */}
        {mainSection === 'tajweed' && (
          <>
            {/* التبويبات الفرعية للتجويد */}
            <div className="grid grid-cols-3 gap-2.5 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
              <button
                type="button"
                onClick={() => setTajweedSubTab('rules')}
                className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                  tajweedSubTab === 'rules'
                    ? 'bg-[#25263A] text-[#E8B84A] shadow-xs'
                    : 'text-[#25263A] hover:bg-[#F7F7FC]'
                }`}
              >
                الأحكام والأمثلة الصوتية
              </button>
              <button
                type="button"
                onClick={() => setTajweedSubTab('makharij')}
                className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                  tajweedSubTab === 'makharij'
                    ? 'bg-[#25263A] text-[#E8B84A] shadow-xs'
                    : 'text-[#25263A] hover:bg-[#F7F7FC]'
                }`}
              >
                مخارج الحروف المصوّرة
              </button>
              <button
                type="button"
                onClick={() => setTajweedSubTab('quiz')}
                className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                  tajweedSubTab === 'quiz'
                    ? 'bg-[#25263A] text-[#E8B84A] shadow-xs'
                    : 'text-[#25263A] hover:bg-[#F7F7FC]'
                }`}
              >
                اختبر إتقانك للتجويد
              </button>
            </div>

            {/* ── ١. الأحكام والأمثلة الصوتية ── */}
            {tajweedSubTab === 'rules' && (
              <div className="space-y-5">
                {/* شريط تصنيف الأحكام */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                  {[
                    { id: 'all', label: 'جميع الأحكام (٧)' },
                    { id: 'noon', label: 'النون الساكنة والتنوين' },
                    { id: 'meem', label: 'الميم الساكنة' },
                    { id: 'mudood', label: 'أحكام المدود' },
                    { id: 'qalqalah', label: 'القلقلة' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedRuleCategory(cat.id as typeof selectedRuleCategory)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold whitespace-nowrap transition-all cursor-pointer border ${
                        selectedRuleCategory === cat.id
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#FFFFFF] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* بطاقات الأحكام التفصيلية */}
                <div className="space-y-5">
                  {filteredRules.map((rule) => (
                    <div
                      key={rule.id}
                      className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#F7F7FC] pb-3">
                        <div>
                          <span className="text-xs font-cairo font-bold text-[#4145C7]">
                            {rule.badge}
                          </span>
                          <h2 className="font-cairo font-bold text-lg text-[#25263A] mt-0.5">
                            {rule.title}
                          </h2>
                        </div>
                        <div
                          className="px-3 py-1.5 rounded-xl text-xs font-cairo font-bold text-white self-start sm:self-auto"
                          style={{ backgroundColor: rule.ruleColor }}
                        >
                          حروفه: {rule.letters}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs leading-relaxed">
                        <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]">
                          <span className="font-cairo font-bold text-[#4145C7] block mb-1">
                            التعريف المبسط:
                          </span>
                          <p className="text-[#25263A]">{rule.definition}</p>
                        </div>
                        <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]">
                          <span className="font-cairo font-bold text-[#4145C7] block mb-1">
                            علامته في مصحف المدينة:
                          </span>
                          <p className="text-[#25263A]">{rule.mushafSign}</p>
                        </div>
                        <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]">
                          <span className="font-cairo font-bold text-[#4145C7] block mb-1">
                            كيفية الأداء الصحيح:
                          </span>
                          <p className="text-[#25263A]">{rule.howToApply}</p>
                        </div>
                      </div>

                      {/* الأمثلة التطبيقية الصوتية */}
                      <div className="space-y-2.5 pt-1">
                        <h3 className="text-xs font-cairo font-bold text-[#77798C]">
                          أمثلة قرآنية تطبيقية (اضغط على زر الاستماع لسماع الأداء الصحيح):
                        </h3>
                        <div className="grid grid-cols-1 gap-2.5">
                          {rule.examples.map((ex, idx) => {
                            const audioKey = `${rule.id}_${idx}`;
                            const isPlaying = playingAudioKey === audioKey;
                            return (
                              <div
                                key={audioKey}
                                className="bg-[#F7F7FC]/70 rounded-2xl p-3.5 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                              >
                                <div className="space-y-1">
                                  <p className="font-amiri text-xl sm:text-2xl text-[#25263A] leading-loose">
                                    ﴿ {ex.prefix}
                                    <span
                                      className="px-1.5 py-0.5 rounded-lg font-bold underline decoration-2"
                                      style={{
                                        color: rule.ruleColor,
                                        backgroundColor: `${rule.ruleColor}18`,
                                      }}
                                    >
                                      {ex.highlighted}
                                    </span>
                                    {ex.suffix} ﴾
                                  </p>
                                  <p className="text-xs text-[#77798C]">
                                    <span className="font-bold text-[#4145C7]">
                                      [سورة {ex.surahName}: {ex.ayahNum}]
                                    </span>{' '}
                                    · {ex.explanation}
                                  </p>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => playAyahAudio(ex.surahNum, ex.ayahNum, audioKey)}
                                  className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold flex items-center gap-2 shrink-0 self-start sm:self-center cursor-pointer transition-all ${
                                    isPlaying
                                      ? 'bg-[#5B5FEF] text-white shadow-sm'
                                      : 'bg-[#FFFFFF] text-[#25263A] border border-[#E6E6F0] hover:bg-[#4145C7] hover:text-white'
                                  }`}
                                >
                                  {isPlaying ? (
                                    <>
                                      <VolumeX className="w-4 h-4 animate-pulse" />
                                      <span>إيقاف التلاوة</span>
                                    </>
                                  ) : (
                                    <>
                                      <Volume2 className="w-4 h-4 text-[#5B5FEF]" />
                                      <span>استماع للآية</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ── ٢. مخارج الحروف المصوّرة التفاعلية ── */}
            {tajweedSubTab === 'makharij' && (
              <div className="space-y-5">
                <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  {/* الرسم التشريحي التفاعلي SVG لمخارج الحروف الخمسة */}
                  <div className="md:col-span-5 flex flex-col items-center">
                    <div className="w-full max-w-[290px] bg-[#F7F7FC] rounded-3xl border-2 border-[#E6E6F0] p-3 relative">
                      <svg
                        viewBox="0 0 260 250"
                        className="w-full h-auto"
                        aria-label="مخطط مخارج الحروف العربية التفاعلي"
                      >
                        {/* خلفية المقطع الجانبي للرأس والجهاز النطقي */}
                        <path
                          d="M95,25 C155,20 205,55 205,115 C205,155 190,185 190,230 L135,230 L135,195 C110,195 85,185 80,165 C75,150 85,140 75,130 C65,120 65,105 78,98 C65,90 68,75 82,68 C78,45 85,30 95,25 Z"
                          fill="#F7F7FC"
                          stroke="#5B5FEF"
                          strokeWidth="2"
                        />
                        {/* مسار التجويف الأنفي (الخيشوم) */}
                        <path
                          d="M82,82 Q115,65 150,88 Q130,98 85,95 Z"
                          fill={selectedMakhrajId === 'khayshoom' ? '#D95C6A33' : '#E8DEC8'}
                          stroke="#D95C6A"
                          strokeWidth="1.5"
                        />
                        {/* مسار الجوف والفم */}
                        <path
                          d="M85,112 Q135,98 168,125 Q178,155 172,205"
                          fill="none"
                          stroke="#5B5FEF"
                          strokeWidth="8"
                          strokeLinecap="round"
                          opacity="0.35"
                        />
                        {/* اللسان */}
                        <path
                          d="M92,122 Q125,102 156,126 Q152,145 112,142 Z"
                          fill={selectedMakhrajId === 'lisan' ? '#4145C744' : '#D7C49E'}
                          stroke="#4145C7"
                          strokeWidth="1.8"
                        />

                        {/* النقاط التفاعلية للمخارج الخمسة */}
                        {MAKHARIJ_DATA.map((m) => {
                          const isSelected = m.id === selectedMakhrajId;
                          return (
                            <g
                              key={m.id}
                              onClick={() => setSelectedMakhrajId(m.id)}
                              className="cursor-pointer"
                            >
                              <line
                                x1={m.svgCoords.cx}
                                y1={m.svgCoords.cy}
                                x2={m.svgCoords.labelX}
                                y2={m.svgCoords.labelY}
                                stroke={m.svgCoords.color}
                                strokeWidth={isSelected ? '2' : '1'}
                                strokeDasharray={isSelected ? 'none' : '3,3'}
                              />
                              <circle
                                cx={m.svgCoords.cx}
                                cy={m.svgCoords.cy}
                                r={isSelected ? 11 : 8}
                                fill={m.svgCoords.color}
                                stroke="#FFFFFF"
                                strokeWidth="2"
                              />
                              <rect
                                x={m.svgCoords.labelX - 34}
                                y={m.svgCoords.labelY - 11}
                                width="68"
                                height="22"
                                rx="6"
                                fill={isSelected ? m.svgCoords.color : '#FFFFFF'}
                                stroke={m.svgCoords.color}
                                strokeWidth="1.2"
                              />
                              <text
                                x={m.svgCoords.labelX}
                                y={m.svgCoords.labelY + 4}
                                textAnchor="middle"
                                fontSize="10"
                                fontWeight="bold"
                                fill={isSelected ? '#FFFFFF' : '#25263A'}
                              >
                                {m.name.split(' ')[0]}
                              </text>
                            </g>
                          );
                        })}
                      </svg>
                      <p className="text-[11px] text-center text-[#77798C] mt-2">
                        اضغط على أي مخرج في الرسم التوضيحي لعرض حروفه وآلية نطقه
                      </p>
                    </div>
                  </div>

                  {/* أزرار اختيار المخرج العام وتفاصيله */}
                  <div className="md:col-span-7 space-y-4">
                    <div className="flex flex-wrap gap-2">
                      {MAKHARIJ_DATA.map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => setSelectedMakhrajId(m.id)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer border ${
                            selectedMakhrajId === m.id
                              ? 'bg-[#25263A] text-[#E8B84A] border-[#5B5FEF] shadow-xs'
                              : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                          }`}
                        >
                          {m.name.split(' (')[0]}
                        </button>
                      ))}
                    </div>

                    <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <h3 className="font-cairo font-bold text-base text-[#25263A]">
                          {activeMakhraj.name}
                        </h3>
                        <span className="text-xs font-bold text-[#4145C7]">
                          {activeMakhraj.subtitle}
                        </span>
                      </div>
                      <p className="text-xs text-[#25263A] leading-relaxed">
                        {activeMakhraj.description}
                      </p>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {activeMakhraj.letters.map((letter) => (
                          <span
                            key={letter}
                            className="w-8 h-8 rounded-xl bg-[#FFFFFF] border border-[#E6E6F0] font-amiri font-bold text-base text-[#25263A] flex items-center justify-center shadow-2xs"
                          >
                            {letter}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* المخارج التفصيلية والأخطاء الشائعة للمخرج المختار */}
                <div className="space-y-3">
                  {activeMakhraj.subPoints.map((sp, i) => {
                    const key = `makhraj_${activeMakhraj.id}_${i}`;
                    const isPlaying = playingAudioKey === key;
                    return (
                      <div
                        key={key}
                        className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-4 space-y-3"
                      >
                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <h4 className="font-cairo font-bold text-sm text-[#25263A]">
                            {sp.title}
                          </h4>
                          <span className="text-xs font-bold text-[#4145C7]">
                            الحروف: {sp.letters}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div className="bg-[#F7F7FC]/60 p-3 rounded-xl">
                            <span className="font-bold text-[#4CAF82] block mb-1">
                              آلية النطق الصحيحة:
                            </span>
                            <p className="text-[#25263A] leading-relaxed">{sp.howToPronounce}</p>
                          </div>
                          <div className="bg-[#F7F7FC]/60 p-3 rounded-xl">
                            <span className="font-bold text-[#D95C6A] block mb-1">
                              تنبيه من خطأ شائع:
                            </span>
                            <p className="text-[#25263A] leading-relaxed">{sp.commonMistake}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between flex-wrap gap-3 bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                          <div>
                            <p className="font-amiri text-xl text-[#25263A]">
                              ﴿ {sp.exampleAyah} ﴾
                            </p>
                            <span className="text-[11px] text-[#77798C]">
                              سورة {sp.surahName} — الآية {sp.ayahNum}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => playAyahAudio(sp.surahNum, sp.ayahNum, key)}
                            className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Volume2 className="w-4 h-4" />
                            <span>{isPlaying ? 'إيقاف' : 'سماع النطق'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── ٣. اختبار تحديد الحكم التجويدي في الكلمة ── */}
            {tajweedSubTab === 'quiz' && (
              <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
                  <div>
                    <h2 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                      اختبار تحديد الحكم التجويدي في الآيات
                    </h2>
                    <p className="text-xs text-[#77798C]">
                      حدد الحكم التجويدي الصحيح للموضع المميز في الآية الكريمة
                    </p>
                  </div>
                  <div className="text-xs font-cairo font-bold text-[#4145C7]">
                    أعلى نتيجة: {bestScore} / {TAJWEED_QUIZ_QUESTIONS.length}
                  </div>
                </div>

                {!quizFinished ? (
                  <div className="space-y-5">
                    <div className="flex items-center justify-between text-xs font-bold text-[#77798C]">
                      <span>
                        السؤال {quizIdx + 1} من {TAJWEED_QUIZ_QUESTIONS.length}
                      </span>
                      <span className="text-[#4CAF82]">النقاط الحالية: {quizScore}</span>
                    </div>

                    <div className="bg-[#F7F7FC] rounded-2xl p-5 border-2 border-[#E6E6F0] text-center space-y-3">
                      <span className="text-xs font-bold text-[#4145C7]">
                        {TAJWEED_QUIZ_QUESTIONS[quizIdx].surahInfo}
                      </span>
                      <p className="font-amiri text-2xl sm:text-3xl text-[#25263A] leading-loose">
                        {TAJWEED_QUIZ_QUESTIONS[quizIdx].ayahSnippet}
                      </p>
                      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl bg-[#EEEEFF] border border-[#5B5FEF] text-sm font-cairo font-bold text-[#25263A]">
                        <span>ما الحكم التجويدي في:</span>
                        <span className="font-amiri text-lg text-[#D95C6A]">
                          « {TAJWEED_QUIZ_QUESTIONS[quizIdx].targetWord} »
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {TAJWEED_QUIZ_QUESTIONS[quizIdx].options.map((opt, idx) => {
                        const isCorrect = idx === TAJWEED_QUIZ_QUESTIONS[quizIdx].correctIndex;
                        const isSelected = selectedAnswer === idx;
                        let btnStyle =
                          'bg-[#F7F7FC]/70 border-[#E6E6F0] text-[#25263A] hover:border-[#5B5FEF]';
                        if (selectedAnswer !== null) {
                          if (isCorrect) {
                            btnStyle = 'bg-[#5B5FEF] text-white border-[#4CAF82]';
                          } else if (isSelected) {
                            btnStyle = 'bg-[#D95C6A] text-white border-[#D95C6A]';
                          }
                        }
                        return (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => handleAnswerQuiz(idx)}
                            disabled={selectedAnswer !== null}
                            className={`p-3.5 rounded-2xl border font-cairo font-bold text-sm flex items-center justify-between transition-all cursor-pointer ${btnStyle}`}
                          >
                            <span>{opt}</span>
                            {selectedAnswer !== null && isCorrect && (
                              <CheckCircle2 className="w-5 h-5 shrink-0" />
                            )}
                            {selectedAnswer !== null && isSelected && !isCorrect && (
                              <XCircle className="w-5 h-5 shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {selectedAnswer !== null && (
                      <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#5B5FEF] space-y-3 animate-fade-in">
                        <p className="text-xs sm:text-sm font-cairo font-bold text-[#25263A] leading-relaxed">
                          التعليل التجويدي: {TAJWEED_QUIZ_QUESTIONS[quizIdx].explanation}
                        </p>
                        <button
                          type="button"
                          onClick={handleNextQuestion}
                          className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer"
                        >
                          {quizIdx + 1 < TAJWEED_QUIZ_QUESTIONS.length
                            ? 'السؤال التالي ←'
                            : 'عرض النتيجة النهائية'}
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6 space-y-4">
                    <Award className="w-14 h-14 text-[#5B5FEF] mx-auto" />
                    <h3 className="font-cairo font-bold text-xl text-[#25263A]">
                      أتممت اختبار أحكام التجويد!
                    </h3>
                    <p className="text-base font-bold text-[#4CAF82]">
                      نتيجتك: {quizScore} من {TAJWEED_QUIZ_QUESTIONS.length} (
                      {Math.round((quizScore / TAJWEED_QUIZ_QUESTIONS.length) * 100)}%)
                    </p>
                    <button
                      type="button"
                      onClick={resetQuiz}
                      className="px-6 py-2.5 rounded-xl bg-[#25263A] text-[#E8B84A] font-cairo font-bold text-xs inline-flex items-center gap-2 cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>إعادة الاختبار</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            القسم الثاني: تدبرات وفوائد قرآنية (آية وفائدة)
        ═════════════════════════════════════════════════════════════════ */}
        {mainSection === 'tadabbur' && (
          <div className="space-y-5">
            {/* شريط البحث والتصنيف الموضوعي */}
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-4 space-y-3 shadow-2xs">
              <div className="relative">
                <Search className="w-4 h-4 text-[#5B5FEF] absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={tadabburSearch}
                  onChange={(e) => setTadabburSearch(e.target.value)}
                  placeholder="ابحث في الآيات أو الفوائد التدبرية أو اسم السورة..."
                  className="w-full bg-[#F7F7FC] pr-10 pl-4 py-2.5 rounded-2xl border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                />
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                {[
                  { id: 'all', label: 'كل التدبرات' },
                  { id: 'tawakkul', label: 'التوكل واليقين' },
                  { id: 'duaa', label: 'الدعاء والفرج' },
                  { id: 'quloob', label: 'صلاح القلوب' },
                  { id: 'sabr', label: 'الصبر والابتلاء' },
                  { id: 'akhlaq', label: 'الأخلاق والمعاملات' },
                  { id: 'akhirah', label: 'الآخرة والجزاء' },
                  { id: 'favorites', label: `المفضلة (${favoriteTadabburIds.length})` },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setTadabburTopic(tab.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold whitespace-nowrap transition-all cursor-pointer border ${
                      tadabburTopic === tab.id
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* بطاقات آية وفائدة */}
            <div className="space-y-4">
              {filteredTadabbur.map((item) => {
                const isFav = favoriteTadabburIds.includes(item.id);
                const audioKey = `tadabbur_${item.id}`;
                const isPlaying = playingAudioKey === audioKey;
                const userNote = personalNotes[item.id];

                return (
                  <div
                    key={item.id}
                    className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs text-[#4145C7] font-cairo font-bold">
                      <span>
                        سورة {item.surahName} · الآية {item.ayahNum} · {item.topicLabel}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => playAyahAudio(item.surahNum, item.ayahNum, audioKey)}
                          className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] cursor-pointer"
                          title="استماع للآية"
                        >
                          <Volume2
                            className={`w-4 h-4 ${isPlaying ? 'text-[#4CAF82] animate-pulse' : 'text-[#5B5FEF]'}`}
                          />
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleTadabburFavorite(item.id)}
                          className={`p-2 rounded-xl border cursor-pointer ${
                            isFav
                              ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                              : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                          }`}
                          title="حفظ في المفضلة"
                        >
                          <Bookmark className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* نص الآية الكريمة */}
                    <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] text-center">
                      <p className="font-amiri text-xl sm:text-2xl text-[#25263A] leading-loose">
                        ﴿ {item.ayahText} ﴾
                      </p>
                    </div>

                    {/* عنوان الفائدة والتدبر */}
                    <div className="space-y-2">
                      <h3 className="font-cairo font-bold text-base text-[#25263A]">
                        {item.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-[#25263A]/90 leading-relaxed">
                        {item.reflection}
                      </p>
                    </div>

                    {/* العمل بالآية */}
                    <div className="bg-[#5B5FEF]/8 rounded-2xl p-3.5 border border-[#5B5FEF]/25">
                      <span className="text-xs font-cairo font-bold text-[#4145C7] block mb-1">
                        العمل التطبيقي بالآية:
                      </span>
                      <p className="text-xs text-[#25263A] leading-relaxed">{item.actionStep}</p>
                    </div>

                    {/* خاطرة المستخدم التدبرية */}
                    {userNote && editingNoteId !== item.id && (
                      <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] flex items-start justify-between gap-2">
                        <div className="text-xs">
                          <span className="font-bold text-[#4145C7] block mb-1">
                            خاطرتي التدبرية:
                          </span>
                          <p className="text-[#25263A]">{userNote}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingNoteId(item.id);
                            setNoteDraft(userNote);
                          }}
                          className="text-xs text-[#4145C7] underline cursor-pointer shrink-0"
                        >
                          تعديل
                        </button>
                      </div>
                    )}

                    {editingNoteId === item.id && (
                      <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#5B5FEF] space-y-2">
                        <textarea
                          value={noteDraft}
                          onChange={(e) => setNoteDraft(e.target.value)}
                          placeholder="اكتب تأملك أو الفائدة التي لامست قلبك من هذه الآية..."
                          rows={2}
                          className="w-full bg-white p-2.5 rounded-xl border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-none"
                        />
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => savePersonalNote(item.id)}
                            className="px-3.5 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                          >
                            حفظ الخاطرة
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingNoteId(null)}
                            className="px-3 py-1.5 rounded-xl bg-white text-[#77798C] text-xs font-bold cursor-pointer"
                          >
                            إلغاء
                          </button>
                        </div>
                      </div>
                    )}

                    {/* المصدر وأزرار النسخ وإضافة خاطرة */}
                    <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-[#F7F7FC] text-xs">
                      <span className="text-[#77798C]">
                        المصدر: <strong className="text-[#25263A]">{item.sourceBook}</strong> —{' '}
                        {item.scholar}
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingNoteId(item.id);
                            setNoteDraft(userNote || '');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] font-bold flex items-center gap-1.5 border border-[#E6E6F0] cursor-pointer"
                        >
                          <PenTool className="w-3.5 h-3.5 text-[#5B5FEF]" />
                          <span>{userNote ? 'تعديل خاطرتي' : 'أضف خاطرتك'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const fullText = `﴿ ${item.ayahText} ﴾ [سورة ${item.surahName}: ${item.ayahNum}]\n\n• ${item.title}:\n${item.reflection}\n\n• العمل بالآية: ${item.actionStep}\n• المصدر: ${item.sourceBook} (${item.scholar})\n— تطبيق رِفْق | RIFQ`;
                            navigator.clipboard.writeText(fullText);
                            setCopiedId(item.id);
                            showToast('تم نسخ الآية والفائدة التدبرية');
                            setTimeout(() => setCopiedId(null), 2000);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] font-bold flex items-center gap-1.5 border border-[#E6E6F0] cursor-pointer"
                        >
                          {copiedId === item.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                              <span>تم النسخ</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-[#5B5FEF]" />
                              <span>نسخ الفائدة</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
