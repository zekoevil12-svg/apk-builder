import React, { useState, useRef, useEffect, useCallback } from 'react';
import { soundManager } from '../../utils/audio';
import { RosaryThemeId } from '../../types';
import { getRosaryTheme } from '../../utils/rosaryThemes';

interface InteractiveBeadsProps {
  currentCount: number;
  target: number;
  onCount: () => void;
  vibrationEnabled: boolean;
  soundEnabled: boolean;
  soundType: 'wooden_bead' | 'crystal_click' | 'soft_chime';
  themeId?: RosaryThemeId;
}

interface BeadPosition {
  index: number;
  x: number;
  y: number;
  scale: number;
  zIndex: number;
  isSeparator: boolean;
}

export const InteractiveBeads: React.FC<InteractiveBeadsProps> = ({
  currentCount,
  target,
  onCount,
  vibrationEnabled,
  soundEnabled,
  soundType,
  themeId,
}) => {
  const activeTheme = getRosaryTheme(themeId);
  const [smoothRotation, setSmoothRotation] = useState<number>(0);
  const [activeBeadGlow, setActiveBeadGlow] = useState<boolean>(false);
  const [tasselSway, setTasselSway] = useState<number>(0);
  const [isPulsing, setIsPulsing] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // Animation & Physics refs
  const targetRotationRef = useRef<number>(0);
  const currentRotationRef = useRef<number>(0);
  const dragOffsetRef = useRef<number>(0);
  const startYRef = useRef<number>(0);
  const hasTriggeredInDragRef = useRef<boolean>(false);
  const lastCountTimeRef = useRef<number>(0);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  // Total beads on the visible rosary string (33 traditional beads)
  const TOTAL_BEADS = 33;
  const STEP_ANGLE = 360 / TOTAL_BEADS;

  // Silky-Smooth 60/120 FPS Physics Animation Loop (Lerp Damping)
  useEffect(() => {
    let isRunning = true;
    const updatePhysics = () => {
      if (!isRunning) return;

      const target = targetRotationRef.current + dragOffsetRef.current;
      const diff = target - currentRotationRef.current;

      if (Math.abs(diff) > 0.015) {
        // High-fidelity responsive lerp (0.24 factor gives quick yet silky-smooth glide)
        currentRotationRef.current += diff * 0.24;
        setSmoothRotation(currentRotationRef.current);
      } else if (currentRotationRef.current !== target) {
        currentRotationRef.current = target;
        setSmoothRotation(target);
      }

      animFrameRef.current = requestAnimationFrame(updatePhysics);
    };

    animFrameRef.current = requestAnimationFrame(updatePhysics);

    return () => {
      isRunning = false;
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  // Execute a single verified count with sound, haptic and smooth rotation
  const triggerSingleCount = useCallback(() => {
    const now = Date.now();
    // Prevent accidental double clicks / ghost touches (minimum 80ms debounce)
    if (now - lastCountTimeRef.current < 80) {
      return;
    }
    lastCountTimeRef.current = now;

    // Visual feedback with easeOutCubic spring
    setIsPulsing(true);
    setActiveBeadGlow(true);
    setTimeout(() => setActiveBeadGlow(false), 200);
    setTimeout(() => setIsPulsing(false), 200);

    // Dynamic rotation advance with smooth physics glide
    targetRotationRef.current -= STEP_ANGLE;

    // Tassel sway animation with easeOutCubic damping
    setTasselSway(8);
    setTimeout(() => setTasselSway(-5), 140);
    setTimeout(() => setTasselSway(2), 260);
    setTimeout(() => setTasselSway(0), 380);

    // Haptic vibration
    if (vibrationEnabled && typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(15);
      } catch {
        // ignore
      }
    }

    // Audio click sound
    if (soundEnabled) {
      soundManager.playBeadClick(0.7, soundType);
    }

    // Inform parent
    onCount();
  }, [onCount, vibrationEnabled, soundEnabled, soundType, STEP_ANGLE]);

  // Pointer Down (Mouse or Touch)
  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    startYRef.current = e.clientY;
    dragOffsetRef.current = 0;
    hasTriggeredInDragRef.current = false;
    try {
      (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    } catch {
      // ignore browser error if pointer capture is unavailable
    }
  };

  // Pointer Move (Swipe/Drag Detection with physical tracking)
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;

    const deltaY = e.clientY - startYRef.current;
    
    // Smooth physical drag resistance
    const clampedDrag = Math.max(-18, Math.min(28, deltaY));
    dragOffsetRef.current = clampedDrag * 0.35;

    // Threshold for drag count: 20px downward drag
    if (deltaY > 20 && !hasTriggeredInDragRef.current) {
      hasTriggeredInDragRef.current = true;
      triggerSingleCount();
    }
  };

  // Pointer Up / Cancel
  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;

    // If it was a clean quick tap without dragging past threshold
    const deltaY = Math.abs(e.clientY - startYRef.current);
    if (!hasTriggeredInDragRef.current && deltaY < 10) {
      triggerSingleCount();
    }

    setIsDragging(false);
    dragOffsetRef.current = 0;
    hasTriggeredInDragRef.current = false;
    try {
      (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
    } catch {
      // ignore
    }
  };

  // Calculate 3D Elliptical Layout coordinates for all 33 beads
  // The rosary hangs in an ellipse with perspective (top beads are further & smaller, bottom beads are closer & larger)
  const cx = 180;
  const cy = 160;
  const rx = 135; // horizontal radius
  const ry = 110; // vertical radius

  const beads: BeadPosition[] = [];
  for (let i = 0; i < TOTAL_BEADS; i++) {
    const angleDeg = (i * STEP_ANGLE + smoothRotation) % 360;
    const angleRad = (angleDeg * Math.PI) / 180;

    // x and y coordinates on ellipse
    const x = cx + rx * Math.cos(angleRad);
    const y = cy + ry * Math.sin(angleRad);

    // Scale with perspective: beads closer to the bottom (sin > 0) appear larger
    const depthFactor = (Math.sin(angleRad) + 1) / 2; // 0 (top) to 1 (bottom)
    const scale = 0.72 + depthFactor * 0.42; // range 0.72 to 1.14
    const zIndex = Math.round(depthFactor * 100);

    // Separators (فواصل) at positions 0, 11, 22
    const isSeparator = i % 11 === 0;

    beads.push({ index: i, x, y, scale, zIndex, isSeparator });
  }

  // Sort beads by zIndex so background beads render behind foreground beads
  const sortedBeads = [...beads].sort((a, b) => a.zIndex - b.zIndex);

  return (
    <div
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      className="relative w-full max-w-[380px] h-[370px] mx-auto flex items-center justify-center select-none cursor-pointer touch-none"
      title="اضغط أو اسحب على المسبحة للتسبيح"
    >
      <svg
        viewBox="0 0 360 360"
        className="w-full h-full overflow-visible drop-shadow-md"
        style={{
          transform: isPulsing ? 'scale(1.03)' : 'scale(1)',
          transition: 'transform 180ms cubic-bezier(0.22, 1, 0.36, 1)',
          willChange: 'transform',
        }}
      >
        <defs>
          {/* Radial Gradient for 3D Lustrous Main Beads */}
          <radialGradient id="greenBeadGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor={activeTheme.beadGradient.stop0} />
            <stop offset="25%" stopColor={activeTheme.beadGradient.stop25} />
            <stop offset="60%" stopColor={activeTheme.beadGradient.stop60} />
            <stop offset="85%" stopColor={activeTheme.beadGradient.stop85} />
            <stop offset="100%" stopColor={activeTheme.beadGradient.stop100} />
          </radialGradient>

          {/* Radial Gradient for Active Foreground Bead Glow */}
          <radialGradient id="activeBeadGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor={activeTheme.activeBeadGradient.stop0} />
            <stop offset="25%" stopColor={activeTheme.activeBeadGradient.stop25} />
            <stop offset="60%" stopColor={activeTheme.activeBeadGradient.stop60} />
            <stop offset="88%" stopColor={activeTheme.activeBeadGradient.stop88} />
            <stop offset="100%" stopColor={activeTheme.activeBeadGradient.stop100} />
          </radialGradient>

          {/* Radial Gradient for Ornate Golden Separator Beads */}
          <radialGradient id="goldBeadGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#FFF9C4" />
            <stop offset="30%" stopColor="#E8B84A" />
            <stop offset="65%" stopColor="#E99AC7" />
            <stop offset="90%" stopColor="#4145C7" />
            <stop offset="100%" stopColor="#25263A" />
          </radialGradient>

          {/* Linear Gradient for Golden Thread */}
          <linearGradient id="goldThreadGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E99AC7" />
            <stop offset="50%" stopColor="#F9E29D" />
            <stop offset="100%" stopColor="#4145C7" />
          </linearGradient>

          {/* Drop shadow filter for 3D depth */}
          <filter id="beadShadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="1" dy="3" stdDeviation="3" floodOpacity="0.28" floodColor="#061A08" />
          </filter>

          {/* Soft blur for ambient bead bounce */}
          <filter id="ambientGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Golden Silk Connecting Cord Loop */}
        <ellipse
          cx={cx}
          cy={cy}
          rx={rx}
          ry={ry}
          fill="none"
          stroke="url(#goldThreadGrad)"
          strokeWidth="3.5"
          strokeDasharray="4 2"
          className="opacity-80"
        />

        {/* 33 Lustrous 3D Beads sorted by Z-Depth */}
        {sortedBeads.map((bead) => {
          const radius = 13.5 * bead.scale;
          const isFocal = bead.zIndex > 88; // Close to front center

          return (
            <g
              key={bead.index}
              transform={`translate(${bead.x}, ${bead.y})`}
            >
              {/* Bead Base Shadow */}
              <ellipse
                cx={0}
                cy={radius * 0.4}
                rx={radius * 0.9}
                ry={radius * 0.5}
                fill="#051707"
                opacity="0.3"
              />

              {/* Main Spherical Bead Body */}
              <circle
                cx={0}
                cy={0}
                r={radius}
                fill={
                  bead.isSeparator
                    ? 'url(#goldBeadGrad)'
                    : isFocal && activeBeadGlow
                    ? 'url(#activeBeadGrad)'
                    : 'url(#greenBeadGrad)'
                }
              />

              {/* Gold Filigree Ring on Separator Beads */}
              {bead.isSeparator && (
                <ellipse
                  cx={0}
                  cy={0}
                  rx={radius}
                  ry={radius * 0.35}
                  fill="none"
                  stroke="#FFF176"
                  strokeWidth="1.2"
                  opacity="0.8"
                />
              )}

              {/* Specular White Glass Gloss Highlight */}
              <ellipse
                cx={-radius * 0.28}
                cy={-radius * 0.32}
                rx={radius * 0.42}
                ry={radius * 0.22}
                transform={`rotate(-25, ${-radius * 0.28}, ${-radius * 0.32})`}
                fill="#FFFFFF"
                opacity={bead.isSeparator ? 0.85 : 0.65}
              />

              {/* Secondary delicate point reflection */}
              <circle
                cx={-radius * 0.12}
                cy={-radius * 0.45}
                r={radius * 0.12}
                fill="#FFFFFF"
                opacity="0.75"
              />

              {/* Bottom ambient reflection bounce rim */}
              <path
                d={`M ${-radius * 0.65} ${radius * 0.4} A ${radius} ${radius} 0 0 0 ${radius * 0.65} ${radius * 0.4}`}
                fill="none"
                stroke={bead.isSeparator ? '#FFE082' : activeTheme.bottomAmbientStroke}
                strokeWidth="1"
                opacity="0.4"
              />
            </g>
          );
        })}

        {/* The Golden Minaret / Imam (الشاهد الذهبي) at the bottom junction */}
        <g
          transform={`translate(${cx}, ${cy + ry}) rotate(${tasselSway})`}
          style={{
            transition: 'transform 350ms cubic-bezier(0.22, 1, 0.36, 1)',
            transformOrigin: '0 0'
          }}
          filter="url(#beadShadow)"
        >
          {/* Main Ornate Spire / Minaret */}
          {/* Top Collar Bead */}
          <circle cx="0" cy="8" r="8" fill="url(#goldBeadGrad)" />
          {/* Spire Stem */}
          <path
            d="M -5 14 L 5 14 L 3 32 L -3 32 Z"
            fill="url(#goldBeadGrad)"
            stroke="#25263A"
            strokeWidth="0.4"
          />
          {/* Middle Decorative Ring */}
          <ellipse cx="0" cy="22" rx="6" ry="2.5" fill="#FFE082" stroke="#4145C7" strokeWidth="0.6" />
          {/* Bottom Finial Cap */}
          <path
            d="M -7 32 Q 0 40 7 32 L 6 36 L -6 36 Z"
            fill="url(#goldBeadGrad)"
          />

          {/* Golden Tassel Head (عقدة الشرابة الذهبية) */}
          <ellipse cx="0" cy="40" rx="6.5" ry="4.5" fill="url(#goldBeadGrad)" />

          {/* Golden Silk Strands (خيوط الشرابة الحريرية) */}
          <g opacity="0.9" stroke="url(#goldThreadGrad)" strokeWidth="1.2">
            <path d="M -5 44 Q -8 60 -10 75" fill="none" />
            <path d="M -3 44 Q -4 62 -5 77" fill="none" />
            <path d="M -1 44 Q -1 62 -2 78" fill="none" />
            <path d="M 0 44 Q 0 63 0 79" fill="none" />
            <path d="M 1 44 Q 2 62 2 78" fill="none" />
            <path d="M 3 44 Q 4 62 5 77" fill="none" />
            <path d="M 5 44 Q 8 60 10 75" fill="none" />
          </g>

          {/* Tassel Bottom Golden Beads */}
          <circle cx="-10" cy="76" r="1.5" fill="#E8B84A" />
          <circle cx="-5" cy="78" r="1.5" fill="#E8B84A" />
          <circle cx="0" cy="80" r="1.8" fill="#E8B84A" />
          <circle cx="5" cy="78" r="1.5" fill="#E8B84A" />
          <circle cx="10" cy="76" r="1.5" fill="#E8B84A" />
        </g>
      </svg>

      {/* Floating Center Touch Hint when idle at 0 */}
      {currentCount === 0 && (
        <div className="absolute top-[44%] left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none bg-[#5B5FEF]/90 text-amber-200 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-md border border-[#E6E6F0] animate-bounce">
          انقر أو اسحب للبدء
        </div>
      )}
    </div>
  );
};
