import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  RotateCcw, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight,
  Share2,
  Volume2,
  VolumeX,
  Smartphone,
  BookOpen,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../../utils/audio';
import { UserSettings } from '../../types';
import { DhikrShareModal } from '../DhikrShareModal';
import { TasbeehSectionSvg, AthkarSectionSvg } from '../Home/RifqSectionIcons';

export interface SpecializedRosary {
  id: string;
  name: string;
  category: 'prayer' | 'istighfar' | 'salawat' | 'baqiyat' | 'distress' | 'sleep' | 'free';
  icon: string;
  description: string;
  hadithSource: string;
  isSequential?: boolean;
  steps: {
    id: string;
    text: string;
    target: number;
    subText?: string;
  }[];
}

export const SPECIALIZED_ROSARIES: SpecializedRosary[] = [
  {
    id: 'after_prayer_sequence',
    name: 'مسبحة دبر الصلاة النبوية',
    category: 'prayer',
    icon: '🕌',
    description: 'التسبيح النبوي المسنون بعد كل صلاة مكتوبة (33 تسبيح، 33 تحميد، 33 تكبير، ثم تمام المائة لا إله إلا الله)',
    hadithSource: 'صحيح مسلم: «مَنْ سَبَّحَ اللَّهَ فِي دُبُرِ كُلِّ صَلَاةٍ ثَلَاثًا وَثَلَاثِينَ، وَحَمِدَ اللَّهَ ثَلَاثًا وَثَلَاثِينَ، وَكَبَّرَ اللَّهَ ثَلَاثًا وَثَلَاثِينَ، فَتِلْكَ تِسْعَةٌ وَتِسْعُونَ، وَقَالَ تَمَامَ الْمِائَةِ: لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، غُفِرَتْ خَطَايَاهُ وَإِنْ كَانَتْ مِثْلَ زَبَدِ الْبَحْرِ»',
    isSequential: true,
    steps: [
      { id: 'subhanallah', text: 'سُبْحَانَ اللَّهِ', target: 33, subText: 'التسبيح (33 مرة)' },
      { id: 'alhamdulillah', text: 'الْحَمْدُ لِلَّهِ', target: 33, subText: 'التحميد (33 مرة)' },
      { id: 'allahuakbar', text: 'اللَّهُ أَكْبَرُ', target: 33, subText: 'التكبير (33 مرة)' },
      { 
        id: 'tamam_miya', 
        text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ', 
        target: 1, 
        subText: 'تمام المائة المباركة (مرة واحدة)' 
      },
    ],
  },
  {
    id: 'istighfar_rosary',
    name: 'مسبحة الاستغفار والتوبة',
    category: 'istighfar',
    icon: '🤲',
    description: 'استغفار مأثور عن النبي ﷺ كان يستغفر في المجلس الواحد مائة مرة',
    hadithSource: 'سنن أبي داود وجامع الترمذي: «إِنْ كُنَّا لَنَعُدُّ لِرَسُولِ اللَّهِ ﷺ فِي المَجْلِسِ الوَاحِدِ مِائَةَ مَرَّةٍ: رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ»',
    steps: [
      { id: 'astaghfirullah', text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', target: 100, subText: 'ورد الاستغفار اليومي (100 مرة)' },
      { id: 'rabbi_ighfirli', text: 'رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ', target: 100, subText: 'استغفار المجلس النبوي (100 مرة)' },
      { 
        id: 'sayyid_istighfar', 
        text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ', 
        target: 7, 
        subText: 'سيد الاستغفار الموجب للجنة (7 مرات)' 
      },
    ],
  },
  {
    id: 'salawat_rosary',
    name: 'مسبحة الصلاة على النبي ﷺ',
    category: 'salawat',
    icon: '💚',
    description: 'الصلاة على حبيب القلوب ﷺ كفاية الهموم ومغفرة الذنوب ورفعة الدرجات',
    hadithSource: 'صحيح مسلم: «مَنْ صَلَّى عَلَيَّ وَاحِدَةً صَلَّى اللَّهُ عَلَيْهِ بِهَا عَشْرًا» ، وجامع الترمذي: «إِذًا تُكْفَى هَمَّكَ، وَيُغْفَرُ لَكَ ذَنْبُكَ»',
    steps: [
      { id: 'salawat_short', text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ', target: 100, subText: 'الصيغة الموجزة (100 مرة)' },
      { 
        id: 'salawat_ibrahimiya', 
        text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ ، اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ', 
        target: 10, 
        subText: 'الصلاة الإبراهيمية التامة (10 مرات)' 
      },
    ],
  },
  {
    id: 'baqiyat_rosary',
    name: 'مسبحة الباقيات الصالحات',
    category: 'baqiyat',
    icon: '🌟',
    description: 'أحب الكلام إلى الله، وغراس الجنة، وأثقل شيء في ميزان العبد يوم القيامة',
    hadithSource: 'صحيح مسلم: «أَحَبُّ الْكَلَامِ إِلَى اللَّهِ أَرْبَعٌ: سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ، لَا يَضُرُّكَ بِأَيِّهِنَّ بَدَأْتَ»',
    steps: [
      { id: 'baqiyat_all', text: 'سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ', target: 100, subText: 'الكلمات الأربع المباركات (100 مرة)' },
      { id: 'subhan_wa_bihamdihi', text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ', target: 100, subText: 'حبيبتان إلى الرحمن ثقيلتان في الميزان (100 مرة)' },
    ],
  },
  {
    id: 'distress_rosary',
    name: 'مسبحة تفريج الكرب (دعاء ذي النون)',
    category: 'distress',
    icon: '🛡️',
    description: 'دعوة يونس عليه السلام في بطن الحوت التي ما دعا بها مسلم قط إلا فرج الله عنه',
    hadithSource: 'جامع الترمذي وصحيح الحاكم: «دَعْوَةُ ذِي النُّونِ إِذْ دَعَا وَهُوَ فِي بَطْنِ الحُوتِ: لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ، فَإِنَّهُ لَمْ يَدْعُ بِهَا رَجُلٌ مُسْلِمٌ فِي شَيْءٍ قَطُّ إِلَّا اسْتَجَابَ اللَّهُ لَهُ»',
    steps: [
      { id: 'dhun_noon', text: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ', target: 40, subText: 'دعوة تفريج الكربات (40 أو 100 مرة)' },
      { id: 'hasbuna', text: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', target: 100, subText: 'كلمة إبراهيم ومحمد عليهما السلام (100 مرة)' },
      { id: 'hawqala', text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ', target: 100, subText: 'كنز الجنة وباب دفع الهموم (100 مرة)' },
    ],
  },
  {
    id: 'sleep_rosary',
    name: 'مسبحة أذكار النوم والتسبيح',
    category: 'sleep',
    icon: '🌙',
    description: 'وصية رسول الله ﷺ لفاطمة وعلي رضي الله عنهما عند النوم خير من خادم',
    hadithSource: 'صحيح البخاري: «أَلَا أَدُلُّكُمَا عَلَى مَا هُوَ خَيْرٌ لَكُمَا مِنْ خَادِمٍ؟ إِذَا أَوَيْتُمَا إِلَى فِرَاشِكُمَا فَسَبِّحَا ثَلَاثًا وَثَلَاثِينَ، وَاحْمَدَا ثَلَاثًا وَثَلَاثِينَ، وَكَبِّرَا أَرْبَعًا وَثَلَاثِينَ، فَهُوَ خَيْرٌ لَكُمَا مِنْ خَادِمٍ»',
    isSequential: true,
    steps: [
      { id: 'sl_subhan', text: 'سُبْحَانَ اللَّهِ', target: 33, subText: 'تسبيح النوم (33 مرة)' },
      { id: 'sl_hamd', text: 'الْحَمْدُ لِلَّهِ', target: 33, subText: 'تحميد النوم (33 مرة)' },
      { id: 'sl_akbar', text: 'اللَّهُ أَكْبَرُ', target: 34, subText: 'تكبير النوم (34 مرة)' },
    ],
  },
  {
    id: 'custom_free_rosary',
    name: 'المسبحة الحرة والمفتوحة',
    category: 'free',
    icon: '📿',
    description: 'سبّح بأي ذكر ترغب به مع إمكانية تعديل الهدف أو تركه مفتوحاً بلا نهاية',
    hadithSource: '«فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ»',
    steps: [
      { id: 'free_dhikr', text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', target: 100, subText: 'ذكرك الخاص المفتوح' },
    ],
  },
];

interface OtherRosariesViewProps {
  settings: UserSettings;
  onIncrement: (dhikrText: string, amount?: number) => void;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  activeThemeColor?: string;
}

export const OtherRosariesView: React.FC<OtherRosariesViewProps> = ({
  settings,
  onIncrement,
  onUpdateSettings,
  activeThemeColor = '#E99AC7',
}) => {
  const [selectedRosaryId, setSelectedRosaryId] = useState<string>(SPECIALIZED_ROSARIES[0].id);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [countsByStep, setCountsByStep] = useState<Record<string, number>>({});
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState<boolean>(false);
  const [customTextInput, setCustomTextInput] = useState<string>('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ');
  const [isEditingCustom, setIsEditingCustom] = useState<boolean>(false);
  const [isOpenTarget, setIsOpenTarget] = useState<boolean>(false);

  const activeRosary = SPECIALIZED_ROSARIES.find((r) => r.id === selectedRosaryId) || SPECIALIZED_ROSARIES[0];
  const activeStep = activeRosary.steps[currentStepIndex] || activeRosary.steps[0];
  const stepKey = `${activeRosary.id}_${activeStep.id}`;
  const currentStepCount = countsByStep[stepKey] || 0;
  const target = isOpenTarget ? 0 : activeStep.target;
  const progress = target > 0 ? Math.min(100, Math.round((currentStepCount / target) * 100)) : 100;

  // Change rosary
  const handleSelectRosary = (rosaryId: string) => {
    setSelectedRosaryId(rosaryId);
    setCurrentStepIndex(0);
    setIsCompleted(false);
  };

  // Main Count Click
  const handleCount = () => {
    if (settings.soundEnabled) {
      soundManager.playBeadClick(settings.soundVolume, settings.soundType);
    }
    if (settings.vibrationEnabled) {
      soundManager.triggerHaptic(20);
    }

    const nextVal = currentStepCount + 1;
    setCountsByStep((prev) => ({
      ...prev,
      [stepKey]: nextVal,
    }));

    const textToCount = activeRosary.id === 'custom_free_rosary' ? customTextInput : activeStep.text;
    onIncrement(textToCount, 1);

    // If target reached
    if (target > 0 && nextVal >= target) {
      // If sequential rosary (e.g. after prayer)
      if (activeRosary.isSequential && currentStepIndex < activeRosary.steps.length - 1) {
        if (settings.soundEnabled) {
          soundManager.playCompletionChime(0.7);
        }
        if (settings.vibrationEnabled) {
          soundManager.triggerHaptic([30, 40, 80]);
        }
        setTimeout(() => {
          setCurrentStepIndex((prev) => prev + 1);
        }, 250);
      } else {
        // Complete whole rosary
        if (settings.soundEnabled) {
          soundManager.playCompletionChime(0.9);
        }
        if (settings.vibrationEnabled) {
          soundManager.triggerHaptic([40, 60, 40, 60, 120]);
        }
        try {
          confetti({
            particleCount: 60,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#E99AC7', '#4CAF82', '#5B5FEF', '#E8B84A'],
          });
        } catch {
          // ignore
        }
        setIsCompleted(true);
      }
    }
  };

  // Reset current step or all steps
  const handleResetCurrent = () => {
    setCountsByStep((prev) => ({
      ...prev,
      [stepKey]: 0,
    }));
    setIsCompleted(false);
  };

  const handleResetAllSteps = () => {
    setCountsByStep((prev) => {
      const next = { ...prev };
      activeRosary.steps.forEach((s) => {
        next[`${activeRosary.id}_${s.id}`] = 0;
      });
      return next;
    });
    setCurrentStepIndex(0);
    setIsCompleted(false);
  };

  return (
    <div className="w-full flex flex-col items-center space-y-4 text-right animate-fade-in" dir="rtl">
      
      {/* 1. Category Switcher (Horizontal scroll of cards) */}
      <div className="w-full overflow-x-auto pb-2 flex gap-2 scrollbar-none">
        {SPECIALIZED_ROSARIES.map((rosary) => {
          const isSelected = selectedRosaryId === rosary.id;
          return (
            <button
              key={rosary.id}
              onClick={() => handleSelectRosary(rosary.id)}
              className={`shrink-0 px-3.5 py-2.5 rounded-2xl flex items-center gap-2 border transition-all cursor-pointer text-xs font-bold ${
                isSelected
                  ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white border-[#5B5FEF] shadow-md scale-[1.02]'
                  : 'bg-white hover:bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] shadow-2xs'
              }`}
            >
              <span className="text-base flex items-center justify-center">
                {rosary.icon === '📿' ? (
                  <TasbeehSectionSvg size={20} />
                ) : rosary.icon === '🤲' ? (
                  <AthkarSectionSvg size={20} />
                ) : (
                  rosary.icon
                )}
              </span>
              <span>{rosary.name}</span>
            </button>
          );
        })}
      </div>

      {/* 2. Active Rosary Hero Card */}
      <div className="w-full bg-white rounded-3xl p-4 sm:p-5 border border-[#E6E6F0] shadow-sm space-y-4">
        {/* Header Title + Hadith Quote Badge */}
        <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <span className="w-10 h-10 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0] text-xl flex items-center justify-center shrink-0">
              {activeRosary.icon === '📿' ? (
                <TasbeehSectionSvg size={28} />
              ) : activeRosary.icon === '🤲' ? (
                <AthkarSectionSvg size={28} />
              ) : (
                activeRosary.icon
              )}
            </span>
            <div>
              <h3 className="text-base font-black text-[#4145C7] font-tajawal">
                {activeRosary.name}
              </h3>
              <p className="text-[11px] text-[#77798C] font-medium leading-relaxed">
                {activeRosary.description}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsShareModalOpen(true)}
            title="مشاركة فضل هذا الذكر"
            className="p-2 rounded-xl bg-[#EEEEFF] hover:bg-[#eadecc] text-[#4145C7] transition-colors cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        {/* Hadith Citation Card */}
        <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] text-xs text-[#25263A] leading-relaxed">
          <span className="font-bold text-[#4145C7] block mb-0.5">📖 الفضل والمصدر النبوي:</span>
          <p className="text-[11px] font-amiri text-stone-700 leading-normal">
            {activeRosary.hadithSource}
          </p>
        </div>

        {/* Sequential Step Selector Tabs (if multiple steps) */}
        {activeRosary.steps.length > 1 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {activeRosary.steps.map((st, idx) => {
              const count = countsByStep[`${activeRosary.id}_${st.id}`] || 0;
              const isDone = count >= st.target;
              const isCurrent = idx === currentStepIndex;

              return (
                <button
                  key={st.id}
                  onClick={() => setCurrentStepIndex(idx)}
                  className={`flex-1 min-w-[120px] p-2 rounded-xl text-center border transition-all cursor-pointer ${
                    isCurrent
                      ? 'bg-[#EEEEFF] border-[#5B5FEF] shadow-2xs'
                      : isDone
                      ? 'bg-[#4CAF82]/12/80 border-[#4CAF82]/40 text-[#4CAF82]'
                      : 'bg-white border-[#E6E6F0] text-[#77798C]'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1 text-[11px] font-black">
                    {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-[#4CAF82] shrink-0" />}
                    <span className="truncate">{st.text.split(' ')[0]}...</span>
                  </div>
                  <span className="text-[10px] text-[#77798C] font-mono block mt-0.5">
                    {count} / {st.target}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* Active Step Dhikr Display */}
        <div className="p-4 rounded-2xl bg-gradient-to-b from-[#F7F7FC] to-white border border-[#E6E6F0] text-center relative overflow-hidden">
          {activeRosary.id === 'custom_free_rosary' && isEditingCustom ? (
            <div className="space-y-2 py-2">
              <input
                type="text"
                value={customTextInput}
                onChange={(e) => setCustomTextInput(e.target.value)}
                placeholder="اكتب ذكرك المفضل هنا..."
                className="w-full text-center font-bold text-base bg-white border border-[#E6E6F0] rounded-xl p-2.5 focus:outline-hidden"
              />
              <button
                onClick={() => setIsEditingCustom(false)}
                className="px-4 py-1.5 bg-[#5B5FEF] text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                حفظ الذكر
              </button>
            </div>
          ) : (
            <div className="py-2">
              <h4 className="text-xl sm:text-2xl font-black text-[#4145C7] font-amiri leading-relaxed">
                {activeRosary.id === 'custom_free_rosary' ? customTextInput : activeStep.text}
              </h4>
              <span className="text-xs text-[#4145C7] font-bold block mt-1">
                {activeStep.subText}
              </span>
              {activeRosary.id === 'custom_free_rosary' && (
                <button
                  onClick={() => setIsEditingCustom(true)}
                  className="mt-2 text-[11px] text-[#77798C] hover:text-[#5B5FEF] underline cursor-pointer"
                >
                  تعديل نص الذكر ✏️
                </button>
              )}
            </div>
          )}

          {/* Progress Bar */}
          {target > 0 && (
            <div className="w-full max-w-md mx-auto mt-3">
              <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden border border-[#E6E6F0] p-0.5">
                <div
                  className="h-full bg-gradient-to-l from-[#5B5FEF] via-[#4CAF82] to-[#E99AC7] rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-bold text-[#77798C] mt-1 px-1">
                <span>المنجز: {currentStepCount}</span>
                <span>الهدف: {target}</span>
              </div>
            </div>
          )}
        </div>

        {/* Completion Celebration Card */}
        {isCompleted && (
          <div className="bg-gradient-to-r from-emerald-600 to-[#5B5FEF] text-white p-3.5 rounded-2xl shadow-md flex items-center justify-between animate-fade-in border border-[#4CAF82]/40">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🎉</span>
              <div>
                <span className="font-black text-sm block">هنيئاً لك! أتممت الورد كاملاً بنجاح</span>
                <span className="text-[11px] text-emerald-100">تقبل الله منك ورزقك أجر هذا الذكر العظيم</span>
              </div>
            </div>
            <button
              onClick={handleResetAllSteps}
              className="px-3 py-1.5 bg-white text-[#4145C7] text-xs font-black rounded-xl cursor-pointer hover:bg-[#4CAF82]/12 transition-colors"
            >
              إعادة الورد ↺
            </button>
          </div>
        )}

        {/* Big Tactile Count Button */}
        <div className="flex flex-col items-center justify-center py-2">
          <button
            onClick={handleCount}
            aria-label="تسبيح"
            className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-gradient-to-tr from-[#5B5FEF] via-[#4CAF82] to-[#E99AC7] text-white shadow-[0_8px_26px_rgba(27,94,32,0.45)] hover:scale-102 active:scale-95 transition-all duration-150 flex flex-col items-center justify-center cursor-pointer border-4 border-white select-none group"
          >
            <span className="text-3xl font-black font-mono tracking-tight drop-shadow-xs">
              {currentStepCount}
            </span>
            <span className="text-[11px] font-bold text-amber-200 mt-1 group-active:scale-110 transition-transform">
              {target > 0 ? `من ${target}` : 'مفتوح ∞'}
            </span>
          </button>
          <span className="text-[11px] text-gray-400 font-bold mt-2">
            اضغط للزيادة (+1)
          </span>
        </div>

        {/* Helper Action Buttons Row */}
        <div className="flex items-center justify-between pt-3 border-t border-[#E6E6F0] text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                settings.soundEnabled ? 'bg-[#4CAF82]/12 text-[#4145C7]' : 'bg-gray-100 text-gray-400'
              }`}
              title="كتم / تفعيل الصوت"
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => onUpdateSettings({ vibrationEnabled: !settings.vibrationEnabled })}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                settings.vibrationEnabled ? 'bg-[#EEEEFF] text-[#4145C7]' : 'bg-gray-100 text-gray-400'
              }`}
              title="تفعيل / إيقاف الاهتزاز"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetCurrent}
              className="px-3 py-1.5 rounded-xl bg-gray-50 hover:bg-gray-100 text-[#77798C] font-bold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>تصفير المرحلة</span>
            </button>
            {activeRosary.steps.length > 1 && (
              <button
                onClick={handleResetAllSteps}
                className="px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#EEEEFF] text-[#4145C7] font-bold transition-colors cursor-pointer"
              >
                تصفير الكل
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Share Modal */}
      <DhikrShareModal
        dhikr={{
          text: activeRosary.id === 'custom_free_rosary' ? customTextInput : activeStep.text,
          source: activeRosary.hadithSource,
          virtue: activeRosary.description,
          countTarget: target > 0 ? target : undefined,
          title: activeRosary.name,
        }}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </div>
  );
};
