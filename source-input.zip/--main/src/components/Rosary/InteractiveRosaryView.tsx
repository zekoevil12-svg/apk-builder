import React, { useState, useEffect } from 'react';
import { 
  RotateCcw, 
  Settings, 
  History, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Award,
  BookOpen,
  Bell,
  Share2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  RosaryState, 
  RosarySessionLog, 
  loadRosaryState, 
  saveRosaryState, 
  loadRosaryHistory, 
  recordRosaryIncrement, 
  resetCurrentSessionCount, 
  clearAllRosaryData,
  getRealRosaryStats
} from '../../utils/rosaryStorage';
import { soundManager } from '../../utils/audio';
import { InteractiveBeads } from './InteractiveBeads';
import { DhikrCard } from './DhikrCard';
import { DhikrSelectorModal } from './DhikrSelectorModal';
import { RosaryHistoryModal } from './RosaryHistoryModal';
import { RosarySettingsModal } from './RosarySettingsModal';
import { ScreenType, UserSettings } from '../../types';
import { QuranSectionSvg, AthkarSectionSvg } from '../Home/RifqSectionIcons';

interface InteractiveRosaryViewProps {
  onNavigate: (screen: ScreenType) => void;
  onSyncGlobalCount?: (dhikrText: string, amount?: number) => void;
  userSettings?: UserSettings;
  overrideDhikrText?: string;
  overrideTarget?: number;
  overrideTheme?: string;
  hideInternalDhikrCard?: boolean;
  onDhikrChange?: (dhikr: string, target?: number) => void;
}

export const InteractiveRosaryView: React.FC<InteractiveRosaryViewProps> = ({
  onNavigate,
  onSyncGlobalCount,
  userSettings,
  overrideDhikrText,
  overrideTarget,
  overrideTheme,
  hideInternalDhikrCard = false,
  onDhikrChange,
}) => {
  const [rosaryState, setRosaryState] = useState<RosaryState>(loadRosaryState);
  const [historyLogs, setHistoryLogs] = useState<RosarySessionLog[]>(loadRosaryHistory);
  const [realStats, setRealStats] = useState(getRealRosaryStats);

  // Modals
  const [isDhikrModalOpen, setIsDhikrModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [showGoalBanner, setShowGoalBanner] = useState(false);

  // Synchronize stats on mount and whenever state updates
  useEffect(() => {
    setRealStats(getRealRosaryStats());
  }, [rosaryState]);

  // Synchronize override props if provided
  useEffect(() => {
    if (overrideDhikrText || overrideTarget || overrideTheme) {
      setRosaryState((prev) => ({
        ...prev,
        selectedDhikr: overrideDhikrText || prev.selectedDhikr,
        target: overrideTarget || prev.target,
        theme: (overrideTheme as any) || prev.theme,
      }));
    }
  }, [overrideDhikrText, overrideTarget, overrideTheme]);

  // Synchronize with external UserSettings when updated via SettingsView
  useEffect(() => {
    if (userSettings) {
      setRosaryState((prev) => {
        const fresh = loadRosaryState();
        return {
          ...prev,
          selectedDhikr: overrideDhikrText || userSettings.rosaryDhikr || prev.selectedDhikr,
          target: overrideTarget || userSettings.rosaryTarget || prev.target,
          soundEnabled: userSettings.rosarySoundEnabled !== undefined ? userSettings.rosarySoundEnabled : (userSettings.soundEnabled ?? prev.soundEnabled),
          vibrationEnabled: userSettings.rosaryVibrationEnabled !== undefined ? userSettings.rosaryVibrationEnabled : (userSettings.vibrationEnabled ?? prev.vibrationEnabled),
          theme: (overrideTheme as any) || userSettings.rosaryTheme || prev.theme,
          ...fresh,
        };
      });
    }
  }, [
    userSettings?.rosaryDhikr,
    userSettings?.rosaryTarget,
    userSettings?.rosarySoundEnabled,
    userSettings?.rosaryVibrationEnabled,
    userSettings?.soundEnabled,
    userSettings?.vibrationEnabled,
    userSettings?.rosaryTheme,
    overrideDhikrText,
    overrideTarget,
    overrideTheme,
  ]);

  // Calculate Real Progress Bar Percentage
  const progressPercent = Math.min(
    100,
    Math.round((rosaryState.currentCount / Math.max(1, rosaryState.target)) * 100)
  );

  // Handle single bead count (via tap or swipe on the 3D beads)
  const handleBeadCount = () => {
    const result = recordRosaryIncrement(1);
    setRosaryState(result.newState);
    setHistoryLogs(result.historyLog);
    setRealStats(getRealRosaryStats());

    // Inform global sync handler if available
    if (onSyncGlobalCount) {
      onSyncGlobalCount(result.newState.selectedDhikr, 1);
    }

    // Goal / Cycle reached celebration
    if (result.completedCycle) {
      if (rosaryState.soundEnabled) {
        soundManager.playCompletionChime(0.8);
      }
      if (rosaryState.vibrationEnabled) {
        soundManager.triggerHaptic([40, 60, 40, 60, 120]);
      }
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#E99AC7', '#4CAF82', '#5B5FEF', '#F7F7FC'],
        });
      } catch {
        // ignore
      }

      setShowGoalBanner(true);
      setTimeout(() => setShowGoalBanner(false), 4000);
    }
  };

  // Reset current session counter to 0
  const handleResetSession = () => {
    const newState = resetCurrentSessionCount();
    setRosaryState({ ...newState });
    setRealStats(getRealRosaryStats());
  };

  // Clear all data completely
  const handleClearAllData = () => {
    const res = clearAllRosaryData();
    setRosaryState(res.state);
    setHistoryLogs(res.history);
    setRealStats(getRealRosaryStats());
  };

  // Select new Dhikr
  const handleSelectDhikr = (text: string, newTarget?: number) => {
    const updated: RosaryState = {
      ...rosaryState,
      selectedDhikr: text,
      target: newTarget || rosaryState.target,
    };
    saveRosaryState(updated);
    setRosaryState(updated);
    if (onDhikrChange) {
      onDhikrChange(text, newTarget || rosaryState.target);
    }
  };

  // Update Settings
  const handleUpdateSettings = (updates: Partial<RosaryState>) => {
    const updated = { ...rosaryState, ...updates };
    saveRosaryState(updated);
    setRosaryState(updated);
  };

  return (
    <div className="w-full flex flex-col items-center max-w-xl mx-auto space-y-4 select-none pb-8" dir="rtl">
      
      {/* 1. Header Card: Current Dhikr & Real Statistics (hidden when parent provides unified header) */}
      {!hideInternalDhikrCard && (
        <DhikrCard
          currentDhikr={rosaryState.selectedDhikr}
          todayCount={realStats.todayTasbeeh}
          totalCycles={realStats.totalCycles}
          totalSessions={realStats.totalSessions}
          onOpenDhikrSelector={() => setIsDhikrModalOpen(true)}
        />
      )}

      {/* Goal Reached Celebration Banner */}
      {showGoalBanner && (
        <div className="w-full bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-[#25263A] p-3 rounded-2xl shadow-md flex items-center justify-between animate-fade-in border border-amber-300">
          <div className="flex items-center gap-2">
            <span className="text-xl">🎉</span>
            <div>
              <span className="font-black text-xs block">مبارك! أتممت الدورة بنجاح ({rosaryState.target} تسبيحة)</span>
              <span className="text-[10px] opacity-80">تم تدوين الجلسة في سجلك وبدء الدورة التالية مباركة إن شاء الله</span>
            </div>
          </div>
          <span className="px-2 py-1 bg-white/40 rounded-lg text-xs font-bold font-mono">
            +{rosaryState.target}
          </span>
        </div>
      )}

      {/* 2. Main 3D Interactive Beads Rosary Section */}
      <div className="w-full bg-white rounded-3xl p-5 shadow-sm border border-[#E6E6F0] flex flex-col items-center relative overflow-hidden">
        
        {/* Subtle Islamic Geometrical Background Pattern */}
        <div className="absolute inset-0 bg-[radial-gradient(#5B5FEF_1px,transparent_1px)] [background-size:20px_20px] opacity-4 pointer-events-none" />

        {/* Counter Display: 0 / 100 */}
        <div className="w-full flex items-center justify-between px-2 mb-1">
          {/* Quick Audio & Haptic Status */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleUpdateSettings({ soundEnabled: !rosaryState.soundEnabled })}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                rosaryState.soundEnabled ? 'bg-[#4CAF82]/12 text-[#4145C7]' : 'bg-gray-100 text-gray-400'
              }`}
              title={rosaryState.soundEnabled ? 'صوت النقرات مفعّل' : 'صوت النقرات معطل'}
            >
              {rosaryState.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={() => handleUpdateSettings({ vibrationEnabled: !rosaryState.vibrationEnabled })}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                rosaryState.vibrationEnabled ? 'bg-[#EEEEFF] text-[#4145C7]' : 'bg-gray-100 text-gray-400'
              }`}
              title={rosaryState.vibrationEnabled ? 'الاهتزاز مفعّل' : 'الاهتزاز معطل'}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          {/* Prominent High-Contrast Counter */}
          <div className="text-center">
            <div className="flex items-baseline justify-center gap-1.5 font-mono">
              <span className="text-4xl md:text-5xl font-black text-[#4145C7] tracking-tight">
                {rosaryState.currentCount}
              </span>
              <span className="text-xl md:text-2xl font-bold text-gray-300">/</span>
              <span className="text-xl md:text-2xl font-bold text-[#5B5FEF]">
                {rosaryState.target}
              </span>
            </div>
            <span className="text-[11px] text-gray-400 font-bold block mt-0.5">
              {progressPercent}% من هدف الدورة
            </span>
          </div>

          {/* History Log Trigger Button */}
          <button
            onClick={() => setIsHistoryModalOpen(true)}
            className="p-2 rounded-xl bg-[#EEEEFF] hover:bg-[#EEEEFF] text-[#4145C7] transition-colors relative cursor-pointer"
            title="فتح سجل التسبيح"
          >
            <History className="w-4 h-4" />
            {historyLogs.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#5B5FEF] text-white text-[9px] font-mono font-bold flex items-center justify-center">
                {historyLogs.length > 9 ? '+9' : historyLogs.length}
              </span>
            )}
          </button>
        </div>

        {/* 3. Real Progress Bar bound to currentCount / target */}
        <div className="w-full max-w-sm mx-auto my-2">
          <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-[#E6E6F0]">
            <div
              className="h-full bg-gradient-to-l from-[#5B5FEF] via-[#4CAF82] to-[#E99AC7] rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* 4. 3D Realistic Lustrous Beads String (Click or Swipe to count) */}
        <div className="w-full flex items-center justify-center py-2">
          <InteractiveBeads
            currentCount={rosaryState.currentCount}
            target={rosaryState.target}
            onCount={handleBeadCount}
            vibrationEnabled={rosaryState.vibrationEnabled}
            soundEnabled={rosaryState.soundEnabled}
            soundType={rosaryState.soundType}
            themeId={userSettings?.rosaryTheme || rosaryState.theme}
          />
        </div>

        {/* Interaction Hint */}
        <p className="text-[12px] text-[#77798C] font-medium text-center mt-1">
          اضغط على الخرز أو اسحب للأسفل لاحتساب التسبيح
        </p>

        {/* Bottom Quick Action Bar */}
        <div className="w-full flex items-center justify-between pt-4 mt-2 border-t border-[#E6E6F0]">
          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsModalOpen(true)}
            className="px-3.5 py-2 bg-[#EEEEFF] hover:bg-[#e7dfd3] text-[#4145C7] text-xs font-bold rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Settings className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>إعدادات المسبحة</span>
          </button>

          {/* Daily Reminders Button */}
          <button
            onClick={() => onNavigate('daily_reminders')}
            className="px-3.5 py-2 bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4145C7] text-xs font-bold rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer border border-[#4CAF82]/40"
          >
            <Bell className="w-3.5 h-3.5 text-[#4CAF82]" />
            <span>التذكيرات اليومية</span>
          </button>

          {/* Reset Current Count Button */}
          <button
            onClick={() => handleUpdateSettings({ currentCount: 0 })}
            className="px-3.5 py-2 bg-gray-50 hover:bg-gray-100 text-[#77798C] text-xs font-bold rounded-2xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="تصفير عداد الجلسة الحالية"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير</span>
          </button>
        </div>
      </div>

      {/* Quick Access to Quran and Athkar sections */}
      <div className="w-full grid grid-cols-2 gap-3">
        <button
          onClick={() => onNavigate('quran')}
          className="p-3.5 bg-white hover:bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] shadow-2xs flex items-center gap-3 transition-colors text-right cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center text-lg shrink-0 border border-[#E6E6F0]">
            <QuranSectionSvg size={28} />
          </div>
          <div>
            <span className="text-xs font-bold text-[#4145C7] block">المصحف الشريف</span>
            <span className="text-[10px] text-[#77798C]">قراءة وتلاوات وتفسير</span>
          </div>
        </button>

        <button
          onClick={() => onNavigate('athkar')}
          className="p-3.5 bg-white hover:bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] shadow-2xs flex items-center gap-3 transition-colors text-right cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-[#4CAF82]/12 text-[#4145C7] flex items-center justify-center text-lg shrink-0 border border-[#4CAF82]/40">
            <AthkarSectionSvg size={28} />
          </div>
          <div>
            <span className="text-xs font-bold text-[#4145C7] block">موسوعة الأذكار</span>
            <span className="text-[10px] text-[#77798C]">أذكار الصباح والمساء</span>
          </div>
        </button>
      </div>

      {/* Modals */}
      <DhikrSelectorModal
        isOpen={isDhikrModalOpen}
        onClose={() => setIsDhikrModalOpen(false)}
        selectedDhikr={rosaryState.selectedDhikr}
        onSelectDhikr={handleSelectDhikr}
      />

      <RosaryHistoryModal
        isOpen={isHistoryModalOpen}
        onClose={() => setIsHistoryModalOpen(false)}
        historyLogs={historyLogs}
        onDataCleared={handleClearAllData}
      />

      <RosarySettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        state={rosaryState}
        onUpdateState={handleUpdateSettings}
        onResetSession={handleResetSession}
        onClearAllData={handleClearAllData}
        onOpenDhikrSelector={() => {
          setIsSettingsModalOpen(false);
          setIsDhikrModalOpen(true);
        }}
      />
    </div>
  );
};
