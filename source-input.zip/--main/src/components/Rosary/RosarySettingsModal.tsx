import React, { useState } from 'react';
import { X, Settings, RotateCcw, Trash2, Volume2, VolumeX, Smartphone, Check, AlertCircle, Palette } from 'lucide-react';
import { RosaryState } from '../../utils/rosaryStorage';
import { ROSARY_THEMES } from '../../utils/rosaryThemes';

interface RosarySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: RosaryState;
  onUpdateState: (updates: Partial<RosaryState>) => void;
  onResetSession: () => void;
  onClearAllData: () => void;
  onOpenDhikrSelector: () => void;
}

export const RosarySettingsModal: React.FC<RosarySettingsModalProps> = ({
  isOpen,
  onClose,
  state,
  onUpdateState,
  onResetSession,
  onClearAllData,
  onOpenDhikrSelector,
}) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [customTargetInput, setCustomTargetInput] = useState<string>('');
  const [isCustomTargetActive, setIsCustomTargetActive] = useState<boolean>(
    ![33, 100, 500, 1000].includes(state.target)
  );

  if (!isOpen) return null;

  const targetOptions = [33, 100, 500, 1000];

  const handleSelectTarget = (targetVal: number) => {
    setIsCustomTargetActive(false);
    onUpdateState({ target: targetVal });
  };

  const handleApplyCustomTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customTargetInput, 10);
    if (!isNaN(val) && val > 0) {
      onUpdateState({ target: val });
      setIsCustomTargetActive(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" dir="rtl">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={onClose} />

      {/* Modal Card */}
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#E6E6F0] overflow-hidden z-10 flex flex-col max-h-[88vh] animate-scale-up">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-amber-300">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">إعدادات المسبحة</h3>
              <p className="text-[11px] text-emerald-100">تخصيص الهدف والأصوات والتنبيهات</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* Target Selection */}
          <div className="bg-[#F7F7FC]/70 p-3.5 rounded-2xl border border-[#E6E6F0] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#4145C7]">هدف الدورة الحالية:</span>
              <span className="text-xs font-mono font-black text-[#5B5FEF] bg-white px-2.5 py-0.5 rounded-full border border-[#E6E6F0]">
                {state.target} تسبيحة
              </span>
            </div>

            {/* Quick target buttons */}
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {targetOptions.map((t) => {
                const isActive = state.target === t && !isCustomTargetActive;
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => handleSelectTarget(t)}
                    className={`py-2 rounded-xl text-xs font-bold font-mono transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'bg-white hover:bg-gray-100 text-gray-700 border border-[#E6E6F0]'
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>

            {/* Custom Target Input */}
            <form onSubmit={handleApplyCustomTarget} className="flex gap-2 pt-1">
              <input
                type="number"
                min="1"
                max="100000"
                value={customTargetInput}
                onChange={(e) => setCustomTargetInput(e.target.value)}
                placeholder="هدف مخصص (مثال: 50)"
                className="flex-1 bg-white border border-gray-300 focus:border-[#5B5FEF] rounded-xl px-3 py-1.5 text-xs font-mono text-center focus:outline-hidden"
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#5B5FEF] hover:bg-[#b0923e] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                تطبيق
              </button>
            </form>
          </div>

          {/* Sound and Haptic Toggles */}
          <div className="space-y-2">
            {/* Sound Toggle */}
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-[#E6E6F0]">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${state.soundEnabled ? 'bg-[#4CAF82]/12 text-[#4145C7]' : 'bg-gray-200 text-gray-400'}`}>
                  {state.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div>
                  <span className="text-xs font-bold text-[#25263A] block">صوت نقرات الخرز</span>
                  <span className="text-[11px] text-gray-400">تأثير صوتي عند كل تسبيحة</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onUpdateState({ soundEnabled: !state.soundEnabled })}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  state.soundEnabled ? 'bg-[#5B5FEF]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    state.soundEnabled ? 'left-1' : 'right-1'
                  }`}
                />
              </button>
            </div>

            {/* Sound Type Selection */}
            {state.soundEnabled && (
              <div className="p-3 bg-[#4CAF82]/12/60 rounded-2xl border border-emerald-100 flex items-center justify-between">
                <span className="text-xs font-bold text-[#4145C7]">نوع الصوت:</span>
                <div className="flex gap-1">
                  {[
                    { id: 'wooden_bead', label: 'خشبي' },
                    { id: 'crystal_click', label: 'بلوري' },
                    { id: 'soft_chime', label: 'رنين' },
                  ].map((st) => (
                    <button
                      key={st.id}
                      onClick={() => onUpdateState({ soundType: st.id as 'wooden_bead' | 'crystal_click' | 'soft_chime' })}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        state.soundType === st.id
                          ? 'bg-[#5B5FEF] text-white'
                          : 'bg-white text-[#77798C] border border-[#E6E6F0]'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Vibration Toggle */}
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl border border-[#E6E6F0]">
              <div className="flex items-center gap-2.5">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${state.vibrationEnabled ? 'bg-[#EEEEFF] text-[#4145C7]' : 'bg-gray-200 text-gray-400'}`}>
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#25263A] block">الاهتزاز اللمسي (Haptic)</span>
                  <span className="text-[11px] text-gray-400">نبضة اهتزاز خفيفة مع كل خرزة</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onUpdateState({ vibrationEnabled: !state.vibrationEnabled })}
                className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                  state.vibrationEnabled ? 'bg-[#5B5FEF]' : 'bg-gray-300'
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    state.vibrationEnabled ? 'left-1' : 'right-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Rosary Theme Selection */}
          <div className="space-y-2 pt-1 border-t border-[#E6E6F0]">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-[#5B5FEF]" />
              <span className="text-xs font-bold text-[#25263A]">ثيم ولون المسبحة:</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {ROSARY_THEMES.map((t) => {
                const isSelected = (state.theme || 'emerald') === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => onUpdateState({ theme: t.id })}
                    className={`p-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 relative ${
                      isSelected
                        ? 'bg-[#EEEEFF]/70 border-[#5B5FEF] ring-2 ring-[#5B5FEF]/40 shadow-xs'
                        : 'bg-gray-50 border-[#E6E6F0] hover:bg-gray-100'
                    }`}
                  >
                    <div
                      className="w-5 h-5 rounded-full shadow-inner border border-white"
                      style={{
                        background: `radial-gradient(circle at 35% 30%, ${t.beadGradient.stop0}, ${t.beadGradient.stop25} 35%, ${t.beadGradient.stop60} 70%, ${t.beadGradient.stop100} 100%)`,
                      }}
                    />
                    <span className="text-[10px] font-bold text-[#25263A] leading-none line-clamp-1">
                      {t.nameAr}
                    </span>
                    {isSelected && (
                      <div className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center text-[8px]">
                        ✓
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Buttons: Reset Session & Clear History */}
          <div className="space-y-2 pt-2 border-t border-[#E6E6F0]">
            {/* Reset Session */}
            <button
              onClick={() => setShowResetConfirm(true)}
              className="w-full py-2.5 px-3 bg-[#EEEEFF] hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-[#4145C7]" />
              <span>تصفير عداد الجلسة الحالية (العودة للصفر)</span>
            </button>

            {/* Delete All Data */}
            <button
              onClick={() => setShowClearConfirm(true)}
              className="w-full py-2.5 px-3 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4 text-red-500" />
              <span>حذف السجل والإحصائيات بالكامل</span>
            </button>
          </div>
        </div>

        {/* Confirmation Modal for Reset Session */}
        {showResetConfirm && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-30 animate-fade-in">
            <div className="bg-white rounded-3xl p-5 max-w-xs w-full text-center space-y-4 shadow-xl border border-[#E6E6F0]">
              <div className="w-12 h-12 rounded-full bg-[#EEEEFF] text-[#4145C7] mx-auto flex items-center justify-center">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-[#25263A] text-base mb-1">تصفير العداد الحالي؟</h4>
                <p className="text-xs text-[#77798C] leading-relaxed">
                  سيتم إعادة العداد الحالي إلى 0 للبدء من جديد مع الحفاظ على سجل الدورات السابقة.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    onResetSession();
                    setShowResetConfirm(false);
                    onClose();
                  }}
                  className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  نعم، صفّر
                </button>
                <button
                  onClick={() => setShowResetConfirm(false)}
                  className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Confirmation Modal for Clear All Data */}
        {showClearConfirm && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-30 animate-fade-in">
            <div className="bg-white rounded-3xl p-5 max-w-xs w-full text-center space-y-4 shadow-xl border border-red-200">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 mx-auto flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-[#25263A] text-base mb-1">حذف كافة البيانات؟</h4>
                <p className="text-xs text-[#77798C] leading-relaxed">
                  سيتم تصفير جميع التسبيحات والدورات وحذف سجل الجلسات بالكامل والبدء من الصفر.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    onClearAllData();
                    setShowClearConfirm(false);
                    onClose();
                  }}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  نعم، احذف الكل
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
