import React, { useState } from 'react';
import {
  Sparkles,
  UserCheck,
  ArrowLeft,
  Shield,
  Mail,
  UserPlus,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  signInWithGoogleAccount,
  ensureUserCloudDoc,
  getAuthErrorMessage,
} from '../../utils/firebase';

interface FirstRunAuthModalProps {
  onComplete: () => void;
  onOpenFullAuth: (mode: 'login' | 'signup') => void;
}

export const FirstRunAuthModal: React.FC<FirstRunAuthModalProps> = ({
  onComplete,
  onOpenFullAuth,
}) => {
  const { currentUser, refreshUserProfile } = useAuth();
  const [googleLoading, setGoogleLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // If user is already authenticated, advance immediately
  React.useEffect(() => {
    if (currentUser) {
      onComplete();
    }
  }, [currentUser, onComplete]);

  const handleDirectGoogleSignIn = async () => {
    if (googleLoading) return;
    setErrorMsg(null);
    setGoogleLoading(true);
    try {
      const res = await signInWithGoogleAccount();
      await ensureUserCloudDoc(res.user, {
        name: res.user.displayName || undefined,
        displayName: res.user.displayName || undefined,
        email: res.user.email || undefined,
        photoURL: res.user.photoURL || undefined,
        provider: 'google.com',
        providerId: 'google.com',
      });
      await refreshUserProfile();
      onComplete();
    } catch (err: unknown) {
      setErrorMsg(getAuthErrorMessage(err));
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md font-tajawal"
      dir="rtl"
    >
      <div className="relative w-full max-w-md bg-[#F7F7FC] rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-[#E6E6F0] animate-fade-in text-[#25263A]">
        {/* Header */}
        <div className="p-6 bg-gradient-to-b from-white to-[#F7F7FC] text-center border-b border-[#E6E6F0]">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#EEEEFF]/80 border border-[#E6E6F0] flex items-center justify-center shadow-md">
            <UserCheck className="w-8 h-8 text-[#4145C7]" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/70 text-blue-950 text-xs font-bold mb-1">
            <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>الخطوة 3 من 4</span>
          </div>
          <h2 className="text-2xl font-black text-[#4145C7] font-tajawal">
            تسجيل الدخول إلى رِفْق
          </h2>
          <p className="text-xs text-[#77798C] mt-1 max-w-xs mx-auto leading-relaxed">
            سجّل دخولك لمزامنة أذكارك وتسبيحاتك وغراس جنتك تلقائيًا عبر جميع أجهزتك
          </p>
        </div>

        {/* Options */}
        <div className="p-6 space-y-3">
          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Direct Google Sign-In */}
          <button
            type="button"
            onClick={handleDirectGoogleSignIn}
            disabled={googleLoading}
            className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-[#EEEEFF]/60 border-2 border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] font-black text-sm shadow-xs transition-all flex items-center justify-center gap-3 cursor-pointer active:scale-98 disabled:opacity-50"
          >
            {googleLoading ? (
              <Loader2 className="w-5 h-5 animate-spin text-[#5B5FEF]" />
            ) : (
              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.3 8.9 5 12 5z"
                />
                <path
                  fill="#4285F4"
                  d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.9z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.7 0-1.1.2-2 .4-2.7L1.6 6.4C.6 8.3 0 10.1 0 12c0 1.9.6 3.7 1.6 5.6l3.7-2.9z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.3-6.7-5.3L1.6 15.9C3.5 19.7 7.4 23 12 23z"
                />
              </svg>
            )}
            <span>
              {googleLoading ? 'جاري تسجيل الدخول بحساب Google...' : 'تسجيل الدخول بحساب Google'}
            </span>
          </button>

          <div className="flex items-center gap-3 text-xs text-[#77798C] py-0.5">
            <div className="h-px bg-[#E6E6F0] flex-1" />
            <span className="font-bold">أو</span>
            <div className="h-px bg-[#E6E6F0] flex-1" />
          </div>

          <button
            type="button"
            onClick={() => onOpenFullAuth('login')}
            disabled={googleLoading}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-white font-black text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer active:scale-98 disabled:opacity-50"
          >
            <Mail className="w-4 h-4" />
            <span>تسجيل الدخول بالبريد الإلكتروني</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenFullAuth('signup')}
            disabled={googleLoading}
            className="w-full py-3 px-4 rounded-2xl bg-white hover:bg-[#EEEEFF]/70 border border-[#E6E6F0] text-[#4145C7] font-black text-xs shadow-2xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
          >
            <UserPlus className="w-4 h-4 text-[#5B5FEF]" />
            <span>إنشاء حساب جديد</span>
          </button>

          <div className="pt-1">
            <button
              type="button"
              onClick={onComplete}
              disabled={googleLoading}
              className="w-full py-2.5 px-4 rounded-2xl bg-transparent hover:bg-stone-200/60 text-[#77798C] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>المتابعة بدون حساب الآن</span>
              <ArrowLeft className="w-3.5 h-3.5 text-stone-400" />
            </button>
          </div>
        </div>

        {/* Footer Note */}
        <div className="px-6 py-3.5 bg-white/50 border-t border-[#E6E6F0]/80 text-center text-[11px] text-[#77798C] flex items-center justify-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-[#4145C7]" />
          <span>يمكنك تسجيل الدخول في أي وقت لاحقًا من حسابي</span>
        </div>
      </div>
    </div>
  );
};
