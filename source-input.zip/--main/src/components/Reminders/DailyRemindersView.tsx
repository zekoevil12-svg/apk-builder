import React, { useState, useEffect } from 'react';
import {
  DailyReminderItem,
  DailyReminderPreferences,
  ReminderCategory,
  PRESET_DUAS_AND_TASBIHS,
  loadDailyReminders,
  saveDailyReminders,
  loadReminderPreferences,
  saveReminderPreferences,
  fireDailyReminderItem,
  formatTime12HourArabic,
  isWithinQuietHours,
} from '../../utils/dailyRemindersService';
import {
  getNotificationPermission,
  requestNotificationPermission,
  subscribeToNotificationSettings,
  saveUnifiedNotificationSettings,
  openSystemNotificationSettings,
  NotificationManager,
  PermissionState,
} from '../../utils/notifications';
import { ScreenType, WardType } from '../../types';

interface DailyRemindersViewProps {
  onBack?: () => void;
  onNavigate?: (screen: ScreenType) => void;
  onOpenWard?: (ward: WardType) => void;
  onSelectTasbeehDhikr?: (dhikrText: string, targetCount: number) => void;
}

const ARABIC_DAYS = [
  { day: 0, short: 'الأحد' },
  { day: 1, short: 'الإثنين' },
  { day: 2, short: 'الثلاثاء' },
  { day: 3, short: 'الأربعاء' },
  { day: 4, short: 'الخميس' },
  { day: 5, short: 'الجمعة' },
  { day: 6, short: 'السبت' },
];

const CATEGORY_LABELS: Record<ReminderCategory, string> = {
  morning_evening: 'أذكار الصباح والمساء',
  tasbeeh: 'ورد تسبيح يومي',
  dua: 'دعاء مأثور',
  istighfar: 'استغفار وتوبة',
  salawat: 'الصلاة على النبي ﷺ',
  sleep: 'أذكار النوم',
};

export const DailyRemindersView: React.FC<DailyRemindersViewProps> = ({
  onBack,
  onNavigate,
  onOpenWard,
  onSelectTasbeehDhikr,
}) => {
  const [reminders, setReminders] = useState<DailyReminderItem[]>(() => loadDailyReminders());
  const [prefs, setPrefs] = useState<DailyReminderPreferences>(() => loadReminderPreferences());
  const [permissionState, setPermissionState] = useState<PermissionState>(() =>
    getNotificationPermission()
  );
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  // New Custom Reminder Form State
  const [newTitle, setNewTitle] = useState('');
  const [newText, setNewText] = useState('');
  const [newTime, setNewTime] = useState('08:00');
  const [newCategory, setNewCategory] = useState<ReminderCategory>('tasbeeh');
  const [newTarget, setNewTarget] = useState<number>(100);
  const [newDays, setNewDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);

  useEffect(() => {
    const syncPerm = async () => {
      const detailed = await NotificationManager.getDetailedStatus();
      if (detailed.granted && detailed.areNotificationsEnabled) {
        setPermissionState('granted');
      } else if (detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied') {
        setPermissionState('denied');
      } else {
        setPermissionState(getNotificationPermission());
      }
    };
    syncPerm();
    const unsubscribe = subscribeToNotificationSettings(() => {
      setReminders(loadDailyReminders());
      setPrefs(loadReminderPreferences());
      syncPerm();
    });
    window.addEventListener('focus', syncPerm);
    return () => {
      unsubscribe();
      window.removeEventListener('focus', syncPerm);
    };
  }, []);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3000);
  };

  const handleUpdatePrefs = (partial: Partial<DailyReminderPreferences>) => {
    const updated = { ...prefs, ...partial };
    setPrefs(updated);
    saveReminderPreferences(updated);
    if (partial.masterEnabled !== undefined) {
      saveUnifiedNotificationSettings({ remindersChannelEnabled: partial.masterEnabled });
    }
    showToast('تم حفظ تفضيلات الإشعارات بنجاح');
  };

  const handleToggleReminder = (id: string) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setReminders(updated);
    saveDailyReminders(updated);
    const target = updated.find((r) => r.id === id);
    if (target) {
      if (id === 'rem_morning_athkar') {
        saveUnifiedNotificationSettings({ morningAthkarEnabled: target.enabled });
      } else if (id === 'rem_evening_athkar') {
        saveUnifiedNotificationSettings({ eveningAthkarEnabled: target.enabled });
      } else if (id === 'rem_sleep_athkar') {
        saveUnifiedNotificationSettings({ sleepAthkarEnabled: target.enabled });
      }
      showToast(
        target.enabled
          ? `تم تفعيل تذكير «${target.title}» الساعة ${formatTime12HourArabic(target.time)}`
          : `تم إيقاف تذكير «${target.title}»`
      );
    }
  };

  const handleTimeChange = (id: string, newTimeVal: string) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, time: newTimeVal } : r));
    setReminders(updated);
    saveDailyReminders(updated);
    if (id === 'rem_morning_athkar') {
      saveUnifiedNotificationSettings({ morningAthkarTime: newTimeVal });
    } else if (id === 'rem_evening_athkar') {
      saveUnifiedNotificationSettings({ eveningAthkarTime: newTimeVal });
    } else if (id === 'rem_sleep_athkar') {
      saveUnifiedNotificationSettings({ sleepAthkarTime: newTimeVal });
    }
    showToast(`تم تحديث وقت التذكير إلى ${formatTime12HourArabic(newTimeVal)}`);
  };

  const handleToggleDay = (id: string, dayNum: number) => {
    const updated = reminders.map((r) => {
      if (r.id !== id) return r;
      const exists = r.daysOfWeek.includes(dayNum);
      const nextDays = exists
        ? r.daysOfWeek.filter((d) => d !== dayNum)
        : [...r.daysOfWeek, dayNum].sort();
      return { ...r, daysOfWeek: nextDays.length > 0 ? nextDays : [dayNum] };
    });
    setReminders(updated);
    saveDailyReminders(updated);
  };

  const handleDeleteReminder = (id: string) => {
    const updated = reminders.filter((r) => r.id !== id);
    setReminders(updated);
    saveDailyReminders(updated);
    showToast('تم حذف التذكير');
  };

  const handleAddCustomReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newText.trim()) {
      showToast('يرجى إدخال عنوان التذكير ونص الدعاء أو التسبيح');
      return;
    }

    const created: DailyReminderItem = {
      id: `custom_rem_${Date.now()}`,
      title: newTitle.trim(),
      dhikrOrDuaText: newText.trim(),
      category: newCategory,
      time: newTime || '08:00',
      enabled: true,
      daysOfWeek: newDays.length > 0 ? newDays : [0, 1, 2, 3, 4, 5, 6],
      targetCount: Math.max(1, newTarget),
      isCustom: true,
    };

    const updated = [created, ...reminders];
    setReminders(updated);
    saveDailyReminders(updated);
    setNewTitle('');
    setNewText('');
    setShowAddForm(false);
    showToast(`تمت إضافة تذكير «${created.title}» الساعة ${formatTime12HourArabic(created.time)}`);
  };

  const handleRequestPermission = async () => {
    if (permissionState === 'denied') {
      await openSystemNotificationSettings();
    }
    const res = await requestNotificationPermission();
    setPermissionState(res);
    if (res === 'granted') {
      handleUpdatePrefs({ systemPushEnabled: true, masterEnabled: true });
      showToast('تم تفعيل إشعارات الجهاز بنجاح');
    } else {
      showToast('إشعارات الجهاز متوقفة — اضغط على «السماح بالإشعارات» لتفعيلها من إعدادات التطبيق');
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 font-cairo" dir="rtl">
      {/* الشريط العلوي */}
      <header className="sticky top-0 z-30 bg-[#FFFFFF] border-b border-[#E6E6F0] shadow-xs">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                aria-label="رجوع"
                className="w-10 h-10 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center hover:bg-[#F7F7FC] cursor-pointer"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M9 18L15 12L9 6"
                    stroke="#5B5FEF"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            )}
            <div className="w-10 h-10 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path
                  d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"
                  stroke="#5B5FEF"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M13.73 21a2 2 0 0 1-3.46 0"
                  stroke="#4CAF82"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <div>
              <h1 className="font-bold text-lg md:text-xl text-[#25263A]">
                التذكيرات اليومية للأدعية والتسبيح
              </h1>
              <p className="text-xs text-[#77798C]">
                مسبحة رفيق المسلم · جدولة مواعيد الأذكار والتسبيح حسب تفضيلاتك
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowAddForm((prev) => !prev)}
            className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-xs md:text-sm flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path
                d="M12 5V19M5 12H19"
                stroke="#FFFFFF"
                strokeWidth="2.4"
                strokeLinecap="round"
              />
            </svg>
            <span>{showAddForm ? 'إغلاق النموذج' : 'تذكير جديد'}</span>
          </button>
        </div>
      </header>

      {/* رسالة التأكيد السريعة */}
      {toastMsg && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#FFFFFF] border-2 border-[#5B5FEF] text-[#25263A] px-5 py-2.5 rounded-2xl shadow-xl flex items-center gap-2">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="9" stroke="#4CAF82" strokeWidth="2" />
            <path
              d="M8.5 12.5L10.8 14.8L15.5 9.5"
              stroke="#4CAF82"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-xs md:text-sm font-bold">{toastMsg}</span>
        </div>
      )}

      <main className="max-w-4xl mx-auto px-4 pt-5 space-y-5">
        {/* بطاقة تفضيلات المستخدم ووقت الهدوء */}
        <section className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F7F7FC] pb-3">
            <div>
              <h2 className="font-bold text-base text-[#25263A]">
                تفضيلات التنبيه واحترام أوقات الهدوء
              </h2>
              <p className="text-xs text-[#77798C]">
                تحكم كامل في طريقة التنبيه، الصوت، الاهتزاز، وساعات عدم الإزعاج.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {permissionState !== 'granted' && (
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                >
                  السماح بالإشعارات
                </button>
              )}
              <button
                type="button"
                onClick={() => handleUpdatePrefs({ masterEnabled: !prefs.masterEnabled })}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                  prefs.masterEnabled
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                }`}
              >
                {prefs.masterEnabled ? 'التذكيرات مفعّلة ✓' : 'التذكيرات متوقفة'}
              </button>
            </div>
          </div>

          {/* أزرار التفضيلات (صوت / اهتزاز / إشعار خارجي / وقت الهدوء) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              type="button"
              onClick={() => handleUpdatePrefs({ soundEnabled: !prefs.soundEnabled })}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                prefs.soundEnabled
                  ? 'bg-[#F7F7FC] border-[#5B5FEF]'
                  : 'bg-white border-[#E6E6F0] opacity-70'
              }`}
            >
              <div className="text-xs font-bold text-[#25263A]">التنبيه الصوتي</div>
              <div className="text-[11px] text-[#4CAF82] font-bold mt-0.5">
                {prefs.soundEnabled ? 'مفعّل (رنين هادئ)' : 'صامت'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleUpdatePrefs({ vibrationEnabled: !prefs.vibrationEnabled })}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                prefs.vibrationEnabled
                  ? 'bg-[#F7F7FC] border-[#5B5FEF]'
                  : 'bg-white border-[#E6E6F0] opacity-70'
              }`}
            >
              <div className="text-xs font-bold text-[#25263A]">الاهتزاز</div>
              <div className="text-[11px] text-[#4CAF82] font-bold mt-0.5">
                {prefs.vibrationEnabled ? 'مفعّل' : 'متوقف'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleUpdatePrefs({ systemPushEnabled: !prefs.systemPushEnabled })}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                prefs.systemPushEnabled
                  ? 'bg-[#F7F7FC] border-[#5B5FEF]'
                  : 'bg-white border-[#E6E6F0] opacity-70'
              }`}
            >
              <div className="text-xs font-bold text-[#25263A]">إشعارات الشاشة</div>
              <div className="text-[11px] text-[#4CAF82] font-bold mt-0.5">
                {prefs.systemPushEnabled ? 'مفعّلة' : 'داخل التطبيق فقط'}
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleUpdatePrefs({ quietHoursEnabled: !prefs.quietHoursEnabled })}
              className={`p-3 rounded-xl border text-right transition-all cursor-pointer ${
                prefs.quietHoursEnabled
                  ? 'bg-[#F7F7FC] border-[#5B5FEF]'
                  : 'bg-white border-[#E6E6F0] opacity-70'
              }`}
            >
              <div className="text-xs font-bold text-[#25263A]">ساعات الهدوء</div>
              <div className="text-[11px] text-[#4CAF82] font-bold mt-0.5">
                {prefs.quietHoursEnabled
                  ? `${prefs.quietHoursStart} - ${prefs.quietHoursEnd}`
                  : 'غير مفعّلة'}
              </div>
            </button>
          </div>

          {/* ضبط وقت الهدوء عند تفعيله */}
          {prefs.quietHoursEnabled && (
            <div className="bg-[#F7F7FC] rounded-xl p-3.5 border border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-[#25263A] font-bold">
                فترة عدم الإزعاج (تُكتم الأصوات والاهتزاز تلقائياً):
                {isWithinQuietHours(prefs) && (
                  <span className="mr-2 text-[#4CAF82]">• نشط الآن</span>
                )}
              </div>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 text-xs font-bold">
                  <span>من:</span>
                  <input
                    type="time"
                    value={prefs.quietHoursStart}
                    onChange={(e) => handleUpdatePrefs({ quietHoursStart: e.target.value })}
                    className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 text-xs font-bold"
                  />
                </label>
                <label className="flex items-center gap-1.5 text-xs font-bold">
                  <span>إلى:</span>
                  <input
                    type="time"
                    value={prefs.quietHoursEnd}
                    onChange={(e) => handleUpdatePrefs({ quietHoursEnd: e.target.value })}
                    className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 text-xs font-bold"
                  />
                </label>
              </div>
            </div>
          )}
        </section>

        {/* نموذج إضافة تذكير مخصص جديد */}
        {showAddForm && (
          <form
            onSubmit={handleAddCustomReminder}
            className="bg-[#FFFFFF] rounded-2xl border-2 border-[#5B5FEF] p-5 shadow-md space-y-4 animate-fade-in"
          >
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-2.5">
              <h3 className="font-bold text-base text-[#25263A]">
                إضافة موعد تذكير جديد للدعاء أو التسبيح
              </h3>
              <span className="text-xs text-[#77798C]">اختر من الأدعية المأثورة أو اكتب وردك</span>
            </div>

            {/* قوالب سريعة جاهزة */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-[#77798C] block">
                اختيار سريع من الأذكار والأدعية المأثورة:
              </label>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                {PRESET_DUAS_AND_TASBIHS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setNewTitle(preset.title);
                      setNewText(preset.text);
                      setNewCategory(preset.category);
                      setNewTarget(preset.target);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#4145C7] hover:text-white text-xs font-bold text-[#25263A] border border-[#E6E6F0] shrink-0 transition-colors cursor-pointer"
                  >
                    {preset.title}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold mb-1">عنوان التذكير</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: ورد الحوقلة، دعاء الضحى..."
                  className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">وقت التذكير المحدد</label>
                <input
                  type="time"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1">عدد التكرار المستهدف</label>
                <input
                  type="number"
                  min={1}
                  max={10000}
                  value={newTarget}
                  onChange={(e) => setNewTarget(Number(e.target.value) || 33)}
                  className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">نص الدعاء أو التسبيح</label>
              <textarea
                rows={2}
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder="اكتب نص الذكر أو الدعاء الذي سيظهر في الإشعار..."
                className="w-full p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-base focus:outline-none"
                style={{ fontFamily: "'Amiri', serif" }}
              />
            </div>

            {/* أيام الأسبوع */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold">أيام التذكير:</label>
              <div className="flex flex-wrap items-center gap-1.5">
                {ARABIC_DAYS.map((d) => {
                  const selected = newDays.includes(d.day);
                  return (
                    <button
                      key={d.day}
                      type="button"
                      onClick={() =>
                        setNewDays((prev) =>
                          prev.includes(d.day)
                            ? prev.length > 1
                              ? prev.filter((x) => x !== d.day)
                              : prev
                            : [...prev, d.day].sort()
                        )
                      }
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border cursor-pointer ${
                        selected
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      {d.short}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2.5 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#25263A] cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
              >
                حفظ موعد التذكير
              </button>
            </div>
          </form>
        )}

        {/* قائمة التذكيرات اليومية المجدولة */}
        <section className="space-y-3.5">
          {reminders.map((item) => (
            <div
              key={item.id}
              className={`bg-[#FFFFFF] rounded-2xl p-4 sm:p-5 border transition-all space-y-3.5 ${
                item.enabled
                  ? 'border-[#5B5FEF] shadow-[0_4px_14px_rgba(201,168,76,0.12)]'
                  : 'border-[#E6E6F0] opacity-75'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-[#25263A]">{item.title}</h3>
                    <span className="text-xs text-[#77798C]">
                      · {CATEGORY_LABELS[item.category]} · الهدف: {item.targetCount}
                    </span>
                  </div>
                  <p
                    className="text-lg text-[#25263A] leading-relaxed"
                    style={{ fontFamily: "'Amiri', serif" }}
                  >
                    {item.dhikrOrDuaText}
                  </p>
                </div>

                {/* محدد الوقت المخصص + مفتاح التفعيل */}
                <div className="flex items-center gap-2.5 shrink-0">
                  <div className="flex items-center gap-1.5 bg-[#F7F7FC] border border-[#5B5FEF] rounded-xl px-3 py-1.5">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="9" stroke="#5B5FEF" strokeWidth="2" />
                      <path
                        d="M12 7V12L15 14"
                        stroke="#5B5FEF"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <input
                      type="time"
                      value={item.time}
                      onChange={(e) => handleTimeChange(item.id, e.target.value)}
                      aria-label={`وقت ${item.title}`}
                      className="bg-transparent text-sm font-bold text-[#25263A] focus:outline-none cursor-pointer"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleReminder(item.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      item.enabled
                        ? 'bg-[#5B5FEF] text-white'
                        : 'bg-[#F7F7FC] text-[#77798C] border border-[#E6E6F0]'
                    }`}
                  >
                    {item.enabled ? 'مفعّل' : 'متوقف'}
                  </button>
                </div>
              </div>

              {/* أيام الأسبوع وأزرار الإجراء السريع */}
              <div className="pt-3 border-t border-[#F7F7FC] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-1 flex-wrap">
                  {ARABIC_DAYS.map((d) => {
                    const activeDay = item.daysOfWeek.includes(d.day);
                    return (
                      <button
                        key={d.day}
                        type="button"
                        onClick={() => handleToggleDay(item.id, d.day)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                          activeDay
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#F7F7FC] text-[#77798C]'
                        }`}
                      >
                        {d.short}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
                  <button
                    type="button"
                    onClick={() => {
                      fireDailyReminderItem(item, prefs);
                      showToast(`تم إرسال إشعار تجريبي لـ «${item.title}»`);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer"
                  >
                    تجربة التنبيه
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (item.linkedWard && onOpenWard) {
                        onOpenWard(item.linkedWard);
                      } else if (onSelectTasbeehDhikr) {
                        onSelectTasbeehDhikr(item.dhikrOrDuaText, item.targetCount);
                      } else if (onNavigate) {
                        onNavigate('tasbeeh');
                      }
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-bold cursor-pointer"
                  >
                    ابدأ الذكر الآن
                  </button>

                  {item.isCustom && (
                    <button
                      type="button"
                      onClick={() => handleDeleteReminder(item.id)}
                      className="px-2.5 py-1.5 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#77798C] hover:text-[#25263A] cursor-pointer"
                    >
                      حذف
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
};
