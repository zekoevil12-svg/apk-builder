import React, { useState, useEffect } from 'react';
import {
  X,
  Mail,
  Lock,
  User as UserIcon,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Loader2,
  KeyRound,
  ArrowRight,
  Send,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import {
  auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  fetchSignInMethodsForEmail,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithGoogleAccount,
  extractAuthErrorCode,
  getAuthErrorMessage,
  updateProfile,
  ensureUserCloudDoc,
  setSavedUserDisplayName,
} from '../../utils/firebase';
import { useAuth, AuthModalMode } from '../../context/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: AuthModalMode;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
}) => {
  const { currentUser, refreshUserProfile, authError, clearAuthError, logout } = useAuth();
  const [mode, setMode] = useState<AuthModalMode>(initialMode);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // States
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string>('');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Sync mode with initialMode when modal opens
  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setErrorMessage(null);
      setErrorCode('');
      setSuccessMessage(null);
      clearAuthError();
    }
  }, [isOpen, initialMode, clearAuthError]);

  // Automatically close modal when user signs in (unless explicitly checking verification)
  useEffect(() => {
    if (isOpen && currentUser && mode !== 'verification' && !loading && !googleLoading) {
      const timer = setTimeout(() => {
        onClose();
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [isOpen, currentUser, mode, loading, googleLoading, onClose]);

  const handleSwitchMode = (newMode: AuthModalMode) => {
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    clearAuthError();
    setMode(newMode);
  };

  const activeErrorMessage = errorMessage || authError;
  const hasMinLen = password.length >= 6;
  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  // 1. Real Google Sign-In (Native on Android APK, Popup/Token on Web)
  const handleGoogleSignIn = async () => {
    if (loading || googleLoading) return;
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    clearAuthError();
    setGoogleLoading(true);
    setLoading(true);

    try {
      const res = await signInWithGoogleAccount();
      await ensureUserCloudDoc(res.user, {
        name: res.user.displayName || undefined,
        displayName: res.user.displayName || undefined,
        email: res.user.email || undefined,
        photoURL: res.user.photoURL || undefined,
        provider: 'google.com',
        providerId: 'google.com',
      });
      await refreshUserProfile();
      setSuccessMessage('تم تسجيل الدخول بنجاح! مرحبًا بك في رِفْق.');
      setTimeout(() => {
        onClose();
      }, 400);
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      // If user simply closed the account picker, show a gentle message or clear
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setGoogleLoading(false);
      setLoading(false);
    }
  };

  // 2. Real Email + Password Login
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || googleLoading) return;
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    clearAuthError();

    const normalizedEmail = email.trim().toLowerCase();
    if (!isEmailValid) {
      setErrorMessage('يرجى إدخال بريد إلكتروني صحيح.');
      return;
    }
    if (!password) {
      setErrorMessage('يرجى إدخال كلمة المرور.');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, normalizedEmail, password);

      try {
        await userCredential.user.reload();
      } catch {
        // Ignore reload network issue
      }

      const freshUser = auth.currentUser || userCredential.user;
      await ensureUserCloudDoc(freshUser, {
        provider: 'password',
        providerId: 'password',
      });
      await refreshUserProfile();

      setSuccessMessage('تم تسجيل الدخول بنجاح! مرحبًا بك في رِفْق.');
      setTimeout(() => {
        onClose();
      }, 450);
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  // 3. Real Email + Password Sign Up
  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || googleLoading) return;
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    clearAuthError();

    const trimmedName = name.trim();
    const normalizedEmail = email.trim().toLowerCase();

    if (!trimmedName) {
      setErrorMessage('يرجى إدخال الاسم.');
      return;
    }
    if (!isEmailValid) {
      setErrorMessage('يرجى إدخال بريد إلكتروني صحيح.');
      return;
    }
    if (!hasMinLen) {
      setErrorMessage('كلمة المرور يجب أن تتكون من 6 أحرف أو أرقام على الأقل.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('كلمتا المرور غير متطابقتين.');
      return;
    }

    setLoading(true);
    try {
      try {
        const existingMethods = await fetchSignInMethodsForEmail(auth, normalizedEmail);
        if (existingMethods && existingMethods.length > 0) {
          setErrorCode('auth/email-already-in-use');
          if (existingMethods.includes('google.com') && !existingMethods.includes('password')) {
            setErrorMessage(
              'هذا البريد الإلكتروني مرتبط بحساب Google، يرجى تسجيل الدخول باستخدام زر Google.'
            );
          } else {
            setErrorMessage(
              'هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول أو استعادة كلمة المرور.'
            );
          }
          setLoading(false);
          return;
        }
      } catch {
        // Continue to createUserWithEmailAndPassword
      }

      const userCred = await createUserWithEmailAndPassword(auth, normalizedEmail, password);

      setSavedUserDisplayName(userCred.user.uid, trimmedName);
      try {
        await updateProfile(userCred.user, { displayName: trimmedName });
      } catch {
        // Non-blocking
      }

      await ensureUserCloudDoc(userCred.user, {
        uid: userCred.user.uid,
        name: trimmedName,
        displayName: trimmedName,
        email: normalizedEmail,
        photoURL: userCred.user.photoURL || null,
        provider: 'password',
        providerId: 'password',
      });

      // Send verification email in background without blocking access to the app
      sendEmailVerification(userCred.user).catch(() => {});

      await refreshUserProfile();
      setSuccessMessage('تم إنشاء حسابك بنجاح! مرحبًا بك في رِفْق.');
      setTimeout(() => {
        onClose();
      }, 500);
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  // 4. Real Forgot Password (sendPasswordResetEmail)
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    clearAuthError();

    const normalizedEmail = email.trim().toLowerCase();
    if (!isEmailValid) {
      setErrorMessage('يرجى إدخال البريد الإلكتروني المسجل به الحساب بشكل صحيح.');
      return;
    }

    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, normalizedEmail);
      setSuccessMessage(
        `تم إرسال رابط إعادة تعيين كلمة المرور إلى (${normalizedEmail}). يرجى تفقد صندوق الوارد أو الرسائل غير المرغوب فيها.`
      );
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  // 5. Resend Verification Email (if opened from profile)
  const handleResendVerification = async () => {
    const activeUser = auth.currentUser || currentUser;
    if (!activeUser || loading) return;
    setLoading(true);
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    try {
      await sendEmailVerification(activeUser);
      setSuccessMessage(
        `تم إرسال رابط تأكيد البريد الإلكتروني إلى (${activeUser.email || email}) بنجاح.`
      );
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  const handleCheckEmailVerified = async () => {
    const activeUser = auth.currentUser || currentUser;
    if (!activeUser || loading) return;
    setLoading(true);
    setErrorMessage(null);
    setErrorCode('');
    setSuccessMessage(null);
    try {
      await activeUser.reload();
      const reloadedUser = auth.currentUser || activeUser;
      if (reloadedUser.emailVerified) {
        await ensureUserCloudDoc(reloadedUser);
        await refreshUserProfile();
        setSuccessMessage('تم تأكيد بريدك الإلكتروني بنجاح!');
        setTimeout(() => {
          onClose();
        }, 600);
      } else {
        setErrorMessage(
          'لم يتم تأكيد البريد بعد. يرجى فتح الرسالة المرسلة إلى بريدك الإلكتروني والضغط على رابط التأكيد.'
        );
      }
    } catch (error: unknown) {
      const code = extractAuthErrorCode(error);
      setErrorCode(code);
      setErrorMessage(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs font-tajawal animate-fade-in"
      dir="rtl"
    >
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-[#E6E6F0] flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center text-[#E8B84A] shadow-inner">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">
                {mode === 'login' && 'تسجيل الدخول إلى رِفْق'}
                {mode === 'signup' && 'إنشاء حساب جديد'}
                {mode === 'forgot' && 'استعادة كلمة المرور'}
                {mode === 'verification' && 'تأكيد البريد الإلكتروني'}
              </h3>
              <p className="text-xs text-white/85">
                احفظ تقدمك وأذكارك وتسبيحاتك عبر جميع أجهزتك
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Friendly Error Alert */}
        {activeErrorMessage && (
          <div className="mx-4 mt-4 p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold flex flex-col gap-2 shadow-2xs">
            <div className="flex items-start justify-between gap-2.5">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                <div className="leading-relaxed">
                  <div>{activeErrorMessage}</div>

                  {mode === 'login' &&
                    (activeErrorMessage.includes('كلمة المرور') ||
                      activeErrorMessage.includes('غير صحيحة') ||
                      errorCode === 'auth/invalid-credential' ||
                      errorCode === 'auth/wrong-password') && (
                      <button
                        type="button"
                        onClick={() => handleSwitchMode('forgot')}
                        className="mt-1.5 text-[11px] text-[#4145C7] hover:underline font-black block cursor-pointer"
                      >
                        نسيت كلمة المرور؟ استعدها الآن
                      </button>
                    )}

                  {mode === 'login' && errorCode === 'auth/user-not-found' && (
                    <button
                      type="button"
                      onClick={() => handleSwitchMode('signup')}
                      className="mt-1.5 text-[11px] text-[#4145C7] hover:underline font-black block cursor-pointer"
                    >
                      إنشاء حساب جديد بهذا البريد
                    </button>
                  )}

                  {mode === 'signup' &&
                    (activeErrorMessage.includes('مسجل بالفعل') ||
                      errorCode === 'auth/email-already-in-use') && (
                      <div className="flex flex-wrap items-center gap-3 mt-1.5">
                        <button
                          type="button"
                          onClick={() => handleSwitchMode('login')}
                          className="text-[11px] text-[#4145C7] hover:underline font-black cursor-pointer"
                        >
                          تسجيل الدخول
                        </button>
                        <span className="text-rose-300">•</span>
                        <button
                          type="button"
                          onClick={() => handleSwitchMode('forgot')}
                          className="text-[11px] text-[#4145C7] hover:underline font-black cursor-pointer"
                        >
                          نسيت كلمة المرور؟
                        </button>
                      </div>
                    )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setErrorCode('');
                  clearAuthError();
                }}
                className="p-1 text-rose-400 hover:text-rose-700 rounded-lg transition-colors cursor-pointer shrink-0"
                title="إغلاق التنبيه"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Friendly Success Alert */}
        {successMessage && (
          <div className="mx-4 mt-4 p-3.5 rounded-2xl bg-[#4CAF82]/12 border border-[#4CAF82]/40 text-[#2E7D5B] text-xs font-bold flex items-start justify-between gap-2.5 animate-fade-in shadow-2xs">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#4CAF82] mt-0.5" />
              <div className="leading-relaxed">{successMessage}</div>
            </div>
            <button
              type="button"
              onClick={() => setSuccessMessage(null)}
              className="p-1 text-[#4CAF82] hover:text-[#2E7D5B] rounded-lg transition-colors cursor-pointer shrink-0"
              title="إغلاق التنبيه"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* ══════════════ TAB 1: LOGIN ══════════════ */}
          {mode === 'login' && (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              {/* Primary Option: Google Sign-In */}
              <button
                id="btn-google-signin"
                type="button"
                onClick={handleGoogleSignIn}
                disabled={loading || googleLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-[#F7F7FC] border-2 border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] text-sm font-black flex items-center justify-center gap-3 transition-all cursor-pointer shadow-xs active:scale-98 disabled:opacity-50"
              >
                {googleLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-[#5B5FEF]" />
                ) : (
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.3 8.9 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.9z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.7 0-1.1.2-2 .4-2.7L1.6 6.4C.6 8.3 0 10.1 0 12c0 1.9.6 3.7 1.6 5.6l3.7-2.9z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.3-6.7-5.3L1.6 15.9C3.5 19.7 7.4 23 12 23z"
                    />
                  </svg>
                )}
                <span>
                  {googleLoading ? 'جاري تسجيل الدخول بحساب Google...' : 'تسجيل الدخول بحساب Google'}
                </span>
              </button>

              {/* Divider */}
              <div className="flex items-center gap-3 text-xs text-[#77798C] my-1">
                <div className="h-px bg-[#E6E6F0] flex-1" />
                <span className="font-bold">أو</span>
                <div className="h-px bg-[#E6E6F0] flex-1" />
              </div>

              {/* Email Field */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>البريد الإلكتروني</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@mail.com"
                  dir="ltr"
                  autoComplete="email"
                  required
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A]"
                />
              </div>

              {/* Password Field */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-[#5B5FEF]" />
                    <span>كلمة المرور</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleSwitchMode('forgot')}
                    className="text-[11px] font-bold text-[#4145C7] hover:underline cursor-pointer"
                  >
                    نسيت كلمة المرور؟
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    autoComplete="current-password"
                    required
                    className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A] pl-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#77798C] cursor-pointer"
                    aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading || googleLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-white text-sm font-black shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
              >
                {loading && !googleLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <Mail className="w-4 h-4" />
                )}
                <span>
                  {loading && !googleLoading
                    ? 'جاري تسجيل الدخول...'
                    : 'تسجيل الدخول بالبريد الإلكتروني'}
                </span>
              </button>

              {/* Switch to Sign Up */}
              <div className="pt-2 text-center text-xs text-[#77798C]">
                <span>ليس لديك حساب بعد؟ </span>
                <button
                  type="button"
                  onClick={() => handleSwitchMode('signup')}
                  className="font-black text-[#4145C7] hover:underline cursor-pointer"
                >
                  إنشاء حساب جديد
                </button>
              </div>
            </form>
          )}

          {/* ══════════════ TAB 2: SIGN UP ══════════════ */}
          {mode === 'signup' && (
            <form onSubmit={handleEmailSignUp} className="space-y-3.5">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={loading || googleLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-[#F7F7FC] border-2 border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] text-sm font-black flex items-center justify-center gap-3 transition-all cursor-pointer shadow-xs active:scale-98 disabled:opacity-50"
              >
                {googleLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-[#5B5FEF]" />
                ) : (
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.3 8.9 5 12 5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.9z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.7 0-1.1.2-2 .4-2.7L1.6 6.4C.6 8.3 0 10.1 0 12c0 1.9.6 3.7 1.6 5.6l3.7-2.9z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.3-6.7-5.3L1.6 15.9C3.5 19.7 7.4 23 12 23z"
                    />
                  </svg>
                )}
                <span>
                  {googleLoading ? 'جاري التسجيل بحساب Google...' : 'تسجيل الدخول بحساب Google'}
                </span>
              </button>

              <div className="flex items-center gap-3 text-xs text-[#77798C] my-1">
                <div className="h-px bg-[#E6E6F0] flex-1" />
                <span className="font-bold">أو بالبريد الإلكتروني</span>
                <div className="h-px bg-[#E6E6F0] flex-1" />
              </div>

              {/* Name */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <UserIcon className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>الاسم</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="أدخل اسمك الكريم"
                  autoComplete="name"
                  required
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A]"
                />
              </div>

              {/* Email */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>البريد الإلكتروني</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@mail.com"
                  dir="ltr"
                  autoComplete="email"
                  required
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A]"
                />
              </div>

              {/* Password */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>كلمة المرور</span>
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="6 أحرف أو أرقام على الأقل"
                    dir="ltr"
                    autoComplete="new-password"
                    required
                    className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A] pl-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#77798C] cursor-pointer"
                    aria-label={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>تأكيد كلمة المرور</span>
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="أعد كتابة كلمة المرور"
                  dir="ltr"
                  autoComplete="new-password"
                  required
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A]"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading || googleLoading}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-white text-sm font-black shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
              >
                {loading && !googleLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>{loading && !googleLoading ? 'جاري إنشاء الحساب...' : 'إنشاء حساب جديد'}</span>
              </button>

              {/* Switch to Login */}
              <div className="pt-1 text-center text-xs text-[#77798C]">
                <span>لديك حساب بالفعل؟ </span>
                <button
                  type="button"
                  onClick={() => handleSwitchMode('login')}
                  className="font-black text-[#4145C7] hover:underline cursor-pointer"
                >
                  تسجيل الدخول
                </button>
              </div>
            </form>
          )}

          {/* ══════════════ TAB 3: FORGOT PASSWORD ══════════════ */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-[#EEEEFF]/80 border border-[#E6E6F0] text-xs text-[#4145C7] leading-relaxed">
                أدخل بريدك الإلكتروني المسجل في رِفْق، وسنرسل إليك رابطًا لإعادة تعيين كلمة المرور.
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>البريد الإلكتروني</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@mail.com"
                  dir="ltr"
                  autoComplete="email"
                  required
                  className="w-full px-3.5 py-2.5 rounded-2xl border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/25 text-sm outline-hidden transition-all bg-[#F7F7FC] text-[#25263A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-white text-sm font-black shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin text-white" /> : <Send className="w-4 h-4" />}
                <span>إرسال رابط استعادة كلمة المرور</span>
              </button>

              <button
                type="button"
                onClick={() => handleSwitchMode('login')}
                className="w-full py-2.5 text-center text-xs font-bold text-[#77798C] hover:text-[#25263A] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>العودة لتسجيل الدخول</span>
              </button>
            </form>
          )}

          {/* ══════════════ TAB 4: EMAIL VERIFICATION ══════════════ */}
          {mode === 'verification' && (
            <div className="space-y-4 text-center">
              <div className="w-16 h-16 rounded-3xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto border-2 border-[#E6E6F0] shadow-xs">
                <Mail className="w-8 h-8" />
              </div>

              <div className="space-y-1.5">
                <h4 className="text-base font-black text-[#25263A]">تأكيد بريدك الإلكتروني</h4>
                <p className="text-xs text-[#77798C] leading-relaxed px-2">
                  أرسلنا رسالة تأكيد إلى البريد الإلكتروني{' '}
                  <strong className="text-[#4145C7]" dir="ltr">
                    {currentUser?.email || email}
                  </strong>
                  . يرجى فتح الرسالة والضغط على الرابط لتأكيد الحساب.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={handleCheckEmailVerified}
                  disabled={loading}
                  className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-white text-xs font-black shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loading ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  )}
                  <span>تم التأكيد، تحديث الحالة</span>
                </button>

                <button
                  type="button"
                  onClick={handleResendVerification}
                  disabled={loading}
                  className="py-3 px-3 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] text-[#25263A] text-xs font-bold shadow-2xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4 text-[#5B5FEF]" />
                  <span>إعادة إرسال الرابط</span>
                </button>
              </div>

              <div className="pt-2 flex flex-col items-center gap-2 border-t border-[#E6E6F0]">
                <button
                  type="button"
                  onClick={onClose}
                  className="text-xs font-black text-[#4145C7] hover:underline cursor-pointer"
                >
                  المتابعة إلى التطبيق الآن
                </button>

                {currentUser && (
                  <button
                    type="button"
                    onClick={async () => {
                      await logout();
                      handleSwitchMode('login');
                    }}
                    className="text-[11px] font-bold text-[#77798C] hover:text-rose-600 cursor-pointer"
                  >
                    تسجيل الخروج واستخدام حساب آخر
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3.5 bg-[#F7F7FC] border-t border-[#E6E6F0] text-center text-[11px] text-[#77798C] font-medium">
          🔒 بياناتك وأذكارك محفوظة ومشفرة بأمان عبر جميع أجهزتك
        </div>
      </div>
    </div>
  );
};
