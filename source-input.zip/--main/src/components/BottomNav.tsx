import React, { useState } from 'react';
import { ScreenType } from '../types';
import { soundManager } from '../utils/audio';
import { useTheme } from '../context/ThemeContext';
import {
  HomeSectionSvg,
  QuranSectionSvg,
  PrayersSectionSvg,
  ProfileSectionSvg,
} from './Home/RifqSectionIcons';

interface BottomNavProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentScreen, onNavigate }) => {
  const [isPressed, setIsPressed] = useState(false);
  const { themeId, isDark } = useTheme();
  const isGirly = themeId === 'girly';
  const beadRoseGoldColor = isGirly ? '#F3D4B0' : '#E99AC7';
  const beadLavenderColor = isGirly ? '#E5CBF0' : '#FFFFFF';
  const activeIndicatorBg = isGirly
    ? 'linear-gradient(90deg, var(--theme-primary) 0%, var(--theme-secondary) 50%, var(--theme-accent) 100%)'
    : 'var(--theme-primary)';
  const activeIconDropShadow = isGirly
    ? 'drop-shadow(0 3px 7px color-mix(in srgb, var(--theme-primary) 34%, transparent))'
    : 'drop-shadow(0 3px 7px rgba(91, 95, 239, 0.22))';

  const handleTasbeehClick = () => {
    // Haptic feedback
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([35]);
      } catch {
        // ignore
      }
    }
    soundManager.triggerHaptic(35);

    setIsPressed(true);
    setTimeout(() => setIsPressed(false), 250);

    onNavigate('tasbeeh');
  };

  return (
    <nav 
      data-rifq-nav-theme={themeId}
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#FFFFFF] border-t border-[#E6E6F0] shadow-[0_-4px_20px_rgba(37,38,58,0.05)] h-[74px] flex items-center justify-around px-2 max-w-4xl mx-auto md:rounded-t-[22px] transition-colors duration-250" 
      dir="rtl"
    >
      {/* 1. الرئيسية */}
      <button
        id="tab-home"
        type="button"
        onClick={() => onNavigate('home')}
        className={`flex-1 h-full flex flex-col items-center justify-center relative transition-all duration-200 cursor-pointer ${
          currentScreen === 'home'
            ? 'text-[#5B5FEF] girly-nav-tab-active'
            : 'text-[#77798C] hover:text-[#25263A]'
        }`}
      >
        {currentScreen === 'home' && (
          <div
            className="absolute top-0 left-3 right-3 h-[3.5px] bg-[#5B5FEF] rounded-full girly-nav-indicator"
            style={{
              background: activeIndicatorBg,
              boxShadow: '0 2px 8px color-mix(in srgb, var(--theme-primary) 45%, transparent)',
            }}
          />
        )}
        <div
          className={`transition-transform duration-200 ${
            currentScreen === 'home'
              ? 'scale-110 -translate-y-0.5 girly-nav-icon-active'
              : 'opacity-80 hover:opacity-100'
          }`}
          style={{ filter: currentScreen === 'home' ? activeIconDropShadow : undefined }}
        >
          <HomeSectionSvg key={`nav-home-${themeId}-${isDark}`} size={25} />
        </div>
        <span className={`text-[11px] mt-1 font-tajawal transition-colors ${currentScreen === 'home' ? 'font-black text-[#5B5FEF]' : 'font-bold text-[#77798C]'}`}>
          الرئيسية
        </span>
      </button>

      {/* 2. القرآن الكريم */}
      <button
        id="tab-quran"
        type="button"
        onClick={() => onNavigate('quran')}
        className={`flex-1 h-full flex flex-col items-center justify-center relative transition-all duration-200 cursor-pointer ${
          currentScreen === 'quran'
            ? 'text-[#5B5FEF] girly-nav-tab-active'
            : 'text-[#77798C] hover:text-[#25263A]'
        }`}
      >
        {currentScreen === 'quran' && (
          <div
            className="absolute top-0 left-3 right-3 h-[3.5px] bg-[#5B5FEF] rounded-full girly-nav-indicator"
            style={{
              background: activeIndicatorBg,
              boxShadow: '0 2px 8px color-mix(in srgb, var(--theme-primary) 45%, transparent)',
            }}
          />
        )}
        <div
          className={`transition-transform duration-200 ${
            currentScreen === 'quran'
              ? 'scale-110 -translate-y-0.5 girly-nav-icon-active'
              : 'opacity-80 hover:opacity-100'
          }`}
          style={{ filter: currentScreen === 'quran' ? activeIconDropShadow : undefined }}
        >
          <QuranSectionSvg key={`nav-quran-${themeId}-${isDark}`} size={25} />
        </div>
        <span className={`text-[11px] mt-1 font-tajawal transition-colors ${currentScreen === 'quran' ? 'font-black text-[#5B5FEF]' : 'font-bold text-[#77798C]'}`}>
          القرآن الكريم
        </span>
      </button>

      {/* 3. المسبحة المركزية (زر دائري بارز في المنتصف يتكيف مع الثيم النشط) */}
      <div className="flex-1 h-full flex items-center justify-center relative">
        <div 
          className="absolute -top-4 w-[72px] h-[72px] rounded-full bg-[#5B5FEF]/25 blur-md pointer-events-none transition-all duration-500"
          style={{
            transform: isPressed ? 'scale(1.3)' : 'scale(1.1)',
            backgroundColor: isGirly
              ? 'color-mix(in srgb, var(--theme-secondary) 28%, transparent)'
              : 'color-mix(in srgb, var(--theme-primary) 26%, transparent)',
          }}
        />

        <button
          id="tab-tasbeeh-prominent"
          type="button"
          onClick={handleTasbeehClick}
          aria-label="المسبحة المركزية"
          className={`relative -top-4 w-[64px] h-[64px] rounded-full flex flex-col items-center justify-center text-white cursor-pointer border-[3.5px] border-white transition-all duration-300 group select-none ${
            isPressed ? 'scale-90' : 'hover:scale-105'
          } ${
            currentScreen === 'tasbeeh' 
              ? 'ring-2 ring-[#5B5FEF] ring-offset-2 ring-offset-white' 
              : ''
          }`}
          style={{
            background: isGirly
              ? 'linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-secondary) 52%, var(--theme-accent) 100%)'
              : 'var(--theme-hero-gradient)',
            boxShadow: isPressed
              ? '0 4px 18px color-mix(in srgb, var(--theme-primary) 55%, transparent)'
              : '0 6px 20px color-mix(in srgb, var(--theme-primary) 38%, transparent)',
          }}
        >
          <div className="group-hover:rotate-12 group-active:scale-110 transition-transform">
            <svg
              key={`nav-misbaha-svg-${themeId}-${isDark}`}
              width={26}
              height={26}
              viewBox="0 0 32 32"
              fill="none"
              aria-hidden="true"
            >
              <circle cx="16" cy="14" r="8" stroke="#FFFFFF" strokeWidth="1.8" strokeDasharray="2.5 2.5" />
              <circle cx="16" cy="6" r="2.2" fill={beadRoseGoldColor} />
              <circle cx="23.5" cy="11.5" r="2" fill={beadLavenderColor} />
              <circle cx="21" cy="20" r="2" fill={beadRoseGoldColor} />
              <circle cx="11" cy="20" r="2" fill={beadLavenderColor} />
              <circle cx="8.5" cy="11.5" r="2" fill={beadRoseGoldColor} />
              <path d="M16 22V27M14 27H18" stroke={beadRoseGoldColor} strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <span className="text-[10px] font-black font-tajawal tracking-tight mt-0.5 text-white">
            المسبحة
          </span>
        </button>
      </div>

      {/* 4. المواقيت */}
      <button
        id="tab-prayers"
        type="button"
        onClick={() => onNavigate('prayers')}
        className={`flex-1 h-full flex flex-col items-center justify-center relative transition-all duration-200 cursor-pointer ${
          currentScreen === 'prayers'
            ? 'text-[#5B5FEF] girly-nav-tab-active'
            : 'text-[#77798C] hover:text-[#25263A]'
        }`}
      >
        {currentScreen === 'prayers' && (
          <div
            className="absolute top-0 left-3 right-3 h-[3.5px] bg-[#5B5FEF] rounded-full girly-nav-indicator"
            style={{
              background: activeIndicatorBg,
              boxShadow: '0 2px 8px color-mix(in srgb, var(--theme-primary) 45%, transparent)',
            }}
          />
        )}
        <div
          className={`transition-transform duration-200 ${
            currentScreen === 'prayers'
              ? 'scale-110 -translate-y-0.5 girly-nav-icon-active'
              : 'opacity-80 hover:opacity-100'
          }`}
          style={{ filter: currentScreen === 'prayers' ? activeIconDropShadow : undefined }}
        >
          <PrayersSectionSvg key={`nav-prayers-${themeId}-${isDark}`} size={25} />
        </div>
        <span className={`text-[11px] mt-1 font-tajawal transition-colors ${currentScreen === 'prayers' ? 'font-black text-[#5B5FEF]' : 'font-bold text-[#77798C]'}`}>
          المواقيت
        </span>
      </button>

      {/* 5. حسابي */}
      <button
        id="tab-profile"
        type="button"
        onClick={() => onNavigate('profile')}
        className={`flex-1 h-full flex flex-col items-center justify-center relative transition-all duration-200 cursor-pointer ${
          currentScreen === 'profile'
            ? 'text-[#5B5FEF] girly-nav-tab-active'
            : 'text-[#77798C] hover:text-[#25263A]'
        }`}
      >
        {currentScreen === 'profile' && (
          <div
            className="absolute top-0 left-3 right-3 h-[3.5px] bg-[#5B5FEF] rounded-full girly-nav-indicator"
            style={{
              background: activeIndicatorBg,
              boxShadow: '0 2px 8px color-mix(in srgb, var(--theme-primary) 45%, transparent)',
            }}
          />
        )}
        <div
          className={`transition-transform duration-200 ${
            currentScreen === 'profile'
              ? 'scale-110 -translate-y-0.5 girly-nav-icon-active'
              : 'opacity-80 hover:opacity-100'
          }`}
          style={{ filter: currentScreen === 'profile' ? activeIconDropShadow : undefined }}
        >
          <ProfileSectionSvg key={`nav-profile-${themeId}-${isDark}`} size={25} />
        </div>
        <span className={`text-[11px] mt-1 font-tajawal transition-colors ${currentScreen === 'profile' ? 'font-black text-[#5B5FEF]' : 'font-bold text-[#77798C]'}`}>
          حسابي
        </span>
      </button>
    </nav>
  );
};


