import React from 'react';
import { WirdSectionSvg } from '../Home/RifqSectionIcons';

export type WirdGroupIconId =
  | 'mushaf_pen'
  | 'mushaf'
  | 'mosque'
  | 'crescent'
  | 'lantern'
  | 'kaaba'
  | 'palm'
  | 'tasbeeh';

export const WIRD_GROUP_ICONS: { id: WirdGroupIconId; label: string }[] = [
  { id: 'mushaf_pen', label: 'مصحف وقلم' },
  { id: 'mushaf', label: 'المصحف الشريف' },
  { id: 'mosque', label: 'المسجد' },
  { id: 'crescent', label: 'الهلال والنجمة' },
  { id: 'lantern', label: 'فانوس النور' },
  { id: 'kaaba', label: 'الكعبة المشرفة' },
  { id: 'palm', label: 'النخلة المباركة' },
  { id: 'tasbeeh', label: 'المسبحة' },
];

/**
 * Main WIRD section icon: Uses the updated ic_wird.png asset
 */
export const WirdMushafPenSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 32,
  className = '',
}) => <WirdSectionSvg size={size} className={className} />;

export const WirdGroupSvgIcon: React.FC<{
  icon: string;
  size?: number;
  className?: string;
}> = ({ icon, size = 24, className = '' }) => {
  switch (icon) {
    case 'mosque':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <path
            d="M18 6C13 10 10 13.5 10 17.5H26C26 13.5 23 10 18 6Z"
            fill="#72B7E8"
            stroke="#25263A"
            strokeWidth="1.6"
          />
          <rect x="8" y="17.5" width="20" height="12.5" rx="2" fill="#F7F7FC" stroke="#5B5FEF" strokeWidth="1.8" />
          <path d="M15 30V23C15 21.3431 16.3431 20 18 20C19.6569 20 21 21.3431 21 23V30" fill="#72B7E8" />
          <path d="M5 12V30M31 12V30" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'crescent':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <path
            d="M23.5 24.5C17.701 24.5 13 19.799 13 14C13 10.9 14.34 8.11 16.47 6.19C11.18 6.89 7 11.41 7 16.95C7 22.94 11.86 27.8 17.85 27.8C22.35 27.8 26.21 25.06 27.85 21.15C26.53 23.19 24.58 24.5 23.5 24.5Z"
            fill="#72B7E8"
            stroke="#E8B84A"
            strokeWidth="1.5"
          />
          <polygon
            points="25,9 26.2,11.6 29,12 27,14 27.5,16.8 25,15.4 22.5,16.8 23,14 21,12 23.8,11.6"
            fill="#E8B84A"
          />
        </svg>
      );
    case 'lantern':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <path d="M18 4V8" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 12L18 8L24 12H12Z" fill="#72B7E8" stroke="#25263A" strokeWidth="1.5" />
          <rect x="11" y="12" width="14" height="14" rx="3" fill="#F7F7FC" stroke="#5B5FEF" strokeWidth="2" />
          <circle cx="18" cy="19" r="3.5" fill="#E8B84A" />
          <path d="M13 26L11 30H25L23 26H13Z" fill="#72B7E8" stroke="#25263A" strokeWidth="1.5" />
        </svg>
      );
    case 'kaaba':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <rect x="7" y="8" width="22" height="21" rx="2.5" fill="#25263A" stroke="#5B5FEF" strokeWidth="1.8" />
          <rect x="7" y="13" width="22" height="3.5" fill="#72B7E8" />
          <rect x="19" y="19" width="5" height="8" rx="1" fill="#E8B84A" />
        </svg>
      );
    case 'palm':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <path d="M18 15V30" stroke="#25263A" strokeWidth="2.6" strokeLinecap="round" />
          <path
            d="M18 15C14 10 8 11 7 15C11 14 15 15 18 15Z"
            fill="#4CAF82"
            stroke="#4CAF82"
            strokeWidth="1.2"
          />
          <path
            d="M18 15C22 10 28 11 29 15C25 14 21 15 18 15Z"
            fill="#4CAF82"
            stroke="#4CAF82"
            strokeWidth="1.2"
          />
          <path
            d="M18 14C15 8 11 6 9 8C13 9 16 12 18 14Z"
            fill="#72B7E8"
          />
          <path
            d="M18 14C21 8 25 6 27 8C23 9 20 12 18 14Z"
            fill="#72B7E8"
          />
        </svg>
      );
    case 'tasbeeh':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <circle cx="18" cy="16" r="9" stroke="#5B5FEF" strokeWidth="2.5" strokeDasharray="3 3" />
          <circle cx="18" cy="7" r="2.2" fill="#25263A" />
          <circle cx="27" cy="16" r="2.2" fill="#72B7E8" />
          <circle cx="9" cy="16" r="2.2" fill="#72B7E8" />
          <circle cx="18" cy="25" r="2.5" fill="#25263A" />
          <path d="M18 27.5V32" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      );
    case 'mushaf':
      return (
        <svg width={size} height={size} viewBox="0 0 36 36" fill="none" className={className}>
          <path
            d="M6 10C6 8.89543 6.89543 8 8 8H15C16.6569 8 18 9.34315 18 11V27C18 25.8954 17.1046 25 16 25H8C6.89543 25 6 24.1046 6 23V10Z"
            fill="#F7F7FC"
            stroke="#5B5FEF"
            strokeWidth="2"
          />
          <path
            d="M30 10C30 8.89543 29.1046 8 28 8H21C19.3431 8 18 9.34315 18 11V27C18 25.8954 18.8954 25 20 25H28C29.1046 25 30 24.1046 30 23V10Z"
            fill="#F7F7FC"
            stroke="#5B5FEF"
            strokeWidth="2"
          />
          <path d="M10 29L18 26L26 29" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    default:
      return <WirdMushafPenSvg size={size} className={className} />;
  }
};

/**
 * Empty state SVG (64px) replacing 📭 emoji
 */
export const EmptyGroupsSvg: React.FC<{ size?: number }> = ({ size = 64 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="32" cy="32" r="30" fill="#F7F7FC" stroke="#5B5FEF" strokeWidth="2" />
    <rect x="16" y="24" width="32" height="22" rx="4" fill="#FFFFFF" stroke="#5B5FEF" strokeWidth="2.2" />
    <path
      d="M16 28L32 37L48 28"
      stroke="#E8B84A"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path d="M26 18H38" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" />
  </svg>
);

/**
 * Medal SVG icons for member rankings (1st, 2nd, 3rd) replacing 🥇🥈🥉
 */
export const RankMedalSvg: React.FC<{ rank: number }> = ({ rank }) => {
  const colors =
    rank === 1
      ? { fill: '#E8B84A', stroke: '#4145C7', text: '#FFFFFF' }
      : rank === 2
      ? { fill: '#77798C', stroke: '#77798C', text: '#FFFFFF' }
      : rank === 3
      ? { fill: '#CD7F32', stroke: '#8B4513', text: '#FFFFFF' }
      : { fill: '#F7F7FC', stroke: '#72B7E8', text: '#25263A' };

  return (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <circle
        cx="16"
        cy="16"
        r="13"
        fill={colors.fill}
        stroke={colors.stroke}
        strokeWidth="2"
      />
      <text
        x="16"
        y="20"
        textAnchor="middle"
        fill={colors.text}
        fontSize="12"
        fontWeight="bold"
        fontFamily="Cairo, sans-serif"
      >
        {rank}
      </text>
    </svg>
  );
};

/**
 * 64px Golden Crescent Moon SVG for the "غدًا إن شاء الله" Wird completion/lock dialog
 */
export const CrescentMoonWirdSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 64,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <circle
      cx="32"
      cy="32"
      r="30"
      fill="#F7F7FC"
      stroke="#5B5FEF"
      strokeWidth="2"
    />
    <path
      d="M41.5 43.2C31.2 43.2 22.8 34.8 22.8 24.5C22.8 19.1 25.1 14.2 28.8 10.8C19.5 12.1 12.2 20.1 12.2 29.8C12.2 40.4 20.8 49 31.4 49C39.4 49 46.2 44.1 49.1 37.2C46.8 40.8 43.4 43.2 41.5 43.2Z"
      fill="#72B7E8"
      stroke="#E8B84A"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <polygon
      points="43,15 44.8,19.2 49.4,19.8 46,23 46.9,27.5 43,25.2 39.1,27.5 40,23 36.6,19.8 41.2,19.2"
      fill="#72B7E8"
    />
    <circle cx="34" cy="14" r="1.8" fill="#E8B84A" />
    <circle cx="49" cy="30" r="1.5" fill="#E8B84A" />
  </svg>
);

