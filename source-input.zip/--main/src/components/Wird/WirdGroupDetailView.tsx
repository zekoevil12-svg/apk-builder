import React, { useState, useMemo } from 'react';
import {
  ArrowRight,
  Share2,
  Settings,
  Check,
  Copy,
  BookOpen,
  RefreshCw,
  BarChart3,
  PieChart as PieChartIcon,
  UserPlus,
  Send,
  Shield,
  Trash2,
  UserX,
  Lock,
  Globe,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  WirdGroupDoc,
  WirdMemberDoc,
  WirdPlanType,
  QURAN_SURAH_OPTIONS,
  getPlanLabel,
  resolveEffectiveMemberUserId,
  ensureGroupSyncedInFirestore,
  evaluateMemberReadingCompletionEligibility,
} from '../../utils/wirdService';
import {
  buildWirdGroupInviteUrl,
  buildWirdGroupInviteMessage,
  buildWirdWhatsAppShareUrl,
  buildWirdTelegramShareUrl,
  openWirdExternalShareUrl,
  shareWirdGroupInviteNatively,
  sanitizeWirdInviteCode,
} from '../../utils/wirdInviteService';
import { Capacitor } from '@capacitor/core';
import {
  WirdGroupSvgIcon,
  WIRD_GROUP_ICONS,
  WirdGroupIconId,
  RankMedalSvg,
} from './WirdIcons';
import { TomorrowWirdDialog } from './WirdMushafReader';

interface WirdGroupDetailViewProps {
  group: WirdGroupDoc;
  currentUserId: string;
  currentUserName: string;
  onBack: () => void;
  onOpenMushaf: (startPage: number, endPage: number, title: string) => void;
  onCompleteMyWird: () => Promise<void>;
  onRedistribute: () => Promise<void>;
  onAdvanceDay: () => Promise<void>;
  onSendMessage: (
    message: string,
    category: 'dua' | 'encouragement' | 'general'
  ) => Promise<void>;
  onPromoteMember: (targetUserId: string) => Promise<void>;
  onRemoveMember: (targetUserId: string) => Promise<void>;
  onHandleJoinRequest: (requestId: string, approve: boolean) => Promise<void>;
  onUpdateSettings: (updates: {
    groupName: string;
    description: string;
    planType: WirdPlanType;
    customSurahName?: string;
    targetDays: number;
    icon: WirdGroupIconId;
    isPublic: boolean;
  }) => Promise<void>;
  onDeleteGroup: () => Promise<void>;
  onOpenJoinModal?: (prefillCode?: string) => void;
}

export const WirdGroupDetailView: React.FC<WirdGroupDetailViewProps> = ({
  group,
  currentUserId,
  onBack,
  onOpenMushaf,
  onCompleteMyWird,
  onRedistribute,
  onAdvanceDay,
  onSendMessage,
  onPromoteMember,
  onRemoveMember,
  onHandleJoinRequest,
  onUpdateSettings,
  onDeleteGroup,
  onOpenJoinModal,
}) => {
  const [viewMode, setViewMode] = useState<'main' | 'settings' | 'stats'>('main');
  const [chartDisplayMode, setChartDisplayMode] = useState<'both' | 'pie' | 'bar'>('both');
  const [memberBarMetric, setMemberBarMetric] = useState<'pages' | 'days'>('pages');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedInviteLink, setCopiedInviteLink] = useState(false);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);

  // Wall message states
  const [msgText, setMsgText] = useState('');
  const [msgCategory, setMsgCategory] = useState<'dua' | 'encouragement' | 'general'>('dua');

  // Admin settings form states
  const [editName, setEditName] = useState(group.groupName);
  const [editDesc, setEditDesc] = useState(group.description);
  const [editPlanType, setEditPlanType] = useState<WirdPlanType>(group.planType);
  const [editSurahName, setEditSurahName] = useState(
    group.customSurahName || QURAN_SURAH_OPTIONS[0].name
  );
  const [editTargetDays, setEditTargetDays] = useState(group.targetDays);
  const [editIcon, setEditIcon] = useState<WirdGroupIconId>(group.icon);
  const [editIsPublic, setEditIsPublic] = useState<boolean>(group.isPublic);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [memberToRemove, setMemberToRemove] = useState<WirdMemberDoc | null>(null);
  const [isRemovingMember, setIsRemovingMember] = useState(false);
  const [adminToast, setAdminToast] = useState<string | null>(null);
  const [showTomorrowModal, setShowTomorrowModal] = useState(false);
  const [isAdvancingDay, setIsAdvancingDay] = useState(false);

  const showLocalToast = (msg: string) => {
    setAdminToast(msg);
    setTimeout(() => setAdminToast(null), 3500);
  };

  const effectiveUserId = useMemo(
    () => resolveEffectiveMemberUserId(group, currentUserId),
    [group, currentUserId]
  );

  const myMember = useMemo(
    () =>
      group.members.find((m) => m.userId === effectiveUserId) ||
      group.members.find((m) => m.userId === currentUserId) ||
      null,
    [group.members, effectiveUserId, currentUserId]
  );

  const isAdmin =
    group.adminId === effectiveUserId ||
    group.adminId === currentUserId ||
    (Array.isArray(group.adminIds) &&
      (group.adminIds.includes(effectiveUserId) ||
        group.adminIds.includes(currentUserId))) ||
    myMember?.role === 'admin';

  // Current day distributions
  const todayDistributions = useMemo(
    () => group.distribution.filter((d) => d.dayNumber === group.currentDay),
    [group.distribution, group.currentDay]
  );

  const myTodayDist = useMemo(
    () =>
      todayDistributions.find((d) => d.userId === effectiveUserId) ||
      todayDistributions.find((d) => d.userId === currentUserId) ||
      null,
    [todayDistributions, effectiveUserId, currentUserId]
  );

  const myCompletionEligibility = useMemo(
    () => evaluateMemberReadingCompletionEligibility(group, currentUserId),
    [group, currentUserId]
  );

  // Sort members by completion status & total completed days
  const sortedMemberRows = useMemo(() => {
    return group.members
      .filter((m) => m.isActive !== false)
      .map((member) => {
        const dist = todayDistributions.find((d) => d.userId === member.userId);
        return {
          member,
          dist,
          isCompletedToday: Boolean(dist?.isCompleted),
        };
      })
      .sort((a, b) => {
        if (a.isCompletedToday !== b.isCompletedToday) {
          return a.isCompletedToday ? -1 : 1;
        }
        return (b.member.completedDaysCount || 0) - (a.member.completedDaysCount || 0);
      });
  }, [group.members, todayDistributions]);

  const totalMembersCount = sortedMemberRows.length;
  const completedMembersCount = sortedMemberRows.filter((r) => r.isCompletedToday).length;
  const progressPercent =
    totalMembersCount > 0
      ? Math.round((completedMembersCount / totalMembersCount) * 100)
      : 0;

  const formattedTodayAr = useMemo(() => {
    return new Date().toLocaleDateString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  }, []);

  const cleanJoinCode = useMemo(
    () => sanitizeWirdInviteCode(group.joinCode || group.groupCode),
    [group.joinCode, group.groupCode]
  );

  const inviteLink = useMemo(
    () => buildWirdGroupInviteUrl(cleanJoinCode),
    [cleanJoinCode]
  );

  const inviteShareMessage = useMemo(
    () =>
      buildWirdGroupInviteMessage({
        groupName: group.groupName,
        joinCode: cleanJoinCode,
      }),
    [group.groupName, cleanJoinCode]
  );

  const whatsAppShareUrl = useMemo(
    () =>
      buildWirdWhatsAppShareUrl({
        groupName: group.groupName,
        joinCode: cleanJoinCode,
      }),
    [group.groupName, cleanJoinCode]
  );

  const telegramShareUrl = useMemo(
    () =>
      buildWirdTelegramShareUrl({
        groupName: group.groupName,
        joinCode: cleanJoinCode,
      }),
    [group.groupName, cleanJoinCode]
  );

  const handleCopyCodeOnly = async () => {
    try {
      await navigator.clipboard.writeText(cleanJoinCode);
      setCopiedCode(true);
      showLocalToast(`تم نسخ كود الدعوة: ${cleanJoinCode}`);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleCopyInviteLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteShareMessage);
      setCopiedInviteLink(true);
      showLocalToast('تم نسخ رسالة ورابط الدعوة بنجاح');
      setTimeout(() => setCopiedInviteLink(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleShareInvite = async () => {
    setIsInviteModalOpen(true);
    void ensureGroupSyncedInFirestore(group);
  };

  const handleNativeSystemShare = async () => {
    await shareWirdGroupInviteNatively({
      groupName: group.groupName,
      joinCode: cleanJoinCode,
    });
  };

  const handleSaveAdminSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    await onUpdateSettings({
      groupName: editName,
      description: editDesc,
      planType: editPlanType,
      customSurahName: editPlanType === 'surah_custom' ? editSurahName : undefined,
      targetDays: Number(editTargetDays) || 30,
      icon: editIcon,
      isPublic: editIsPublic,
    });
    showLocalToast('تم حفظ إعدادات المجموعة وإعادة توزيع الأجزاء بنجاح');
    setViewMode('main');
  };

  // ── 【الشاشة 6】صفحة الإعدادات (للمشرف) ──
  if (viewMode === 'settings' && isAdmin) {
    return (
      <div className="space-y-5 pb-10 animate-fade-in" dir="rtl">
        {/* شريط علوي */}
        <div className="bg-[#FFFFFF] rounded-[20px] p-4 border border-[#E6E6F0] flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setViewMode('main')}
              className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
              <span>رجوع للمجموعة</span>
            </button>
            <h2 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
              إعدادات وإدارة المجموعة
            </h2>
          </div>
        </div>

        {/* تعديل المجموعة */}
        <form
          onSubmit={handleSaveAdminSettings}
          className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] space-y-4 shadow-xs"
        >
          <h3 className="font-cairo font-bold text-base text-[#25263A] border-b border-[#F7F7FC] pb-2.5">
            تعديل بيانات وخطة المجموعة
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                اسم المجموعة
              </label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
              />
            </div>

            <div>
              <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                نوع الخطة
              </label>
              <select
                value={editPlanType}
                onChange={(e) => setEditPlanType(e.target.value as WirdPlanType)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
              >
                <option value="khatma">ختمة كاملة (30 جزء)</option>
                <option value="juz_amma">جزء عم (الجزء 30)</option>
                <option value="surah_custom">سور محددة</option>
                <option value="custom">خطة مخصصة</option>
              </select>
            </div>

            {editPlanType === 'surah_custom' && (
              <div>
                <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                  اختر السورة
                </label>
                <select
                  value={editSurahName}
                  onChange={(e) => setEditSurahName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                >
                  {QURAN_SURAH_OPTIONS.map((s) => (
                    <option key={s.number} value={s.name}>
                      {s.name} (ص {s.startPage} - {s.endPage})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                عدد الأيام
              </label>
              <input
                type="number"
                min={1}
                max={365}
                value={editTargetDays}
                onChange={(e) => setEditTargetDays(Number(e.target.value) || 30)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
              />
            </div>

            <div>
              <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                خصوصية المجموعة
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setEditIsPublic(true)}
                  className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                    editIsPublic
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  <Globe className="w-4 h-4" />
                  <span>عامة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setEditIsPublic(false)}
                  className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                    !editIsPublic
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  <Lock className="w-4 h-4" />
                  <span>خاصة</span>
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
              أيقونة المجموعة (SVG)
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
              {WIRD_GROUP_ICONS.map((ic) => (
                <button
                  key={ic.id}
                  type="button"
                  onClick={() => setEditIcon(ic.id)}
                  className={`p-2 rounded-xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                    editIcon === ic.id
                      ? 'bg-[#F7F7FC] border-[#5B5FEF] ring-2 ring-[#5B5FEF]/40'
                      : 'bg-white border-[#E6E6F0] hover:border-[#5B5FEF]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center">
                    <WirdGroupSvgIcon icon={ic.id} size={20} />
                  </div>
                  <span className="font-cairo text-[10px] font-bold text-[#25263A] truncate w-full text-center">
                    {ic.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
              الوصف
            </label>
            <textarea
              rows={2}
              value={editDesc}
              onChange={(e) => setEditDesc(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
            />
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs cursor-pointer"
            >
              حفظ التعديلات
            </button>

            <button
              type="button"
              onClick={async () => {
                await onRedistribute();
                showLocalToast('تمت إعادة توزيع الأجزاء بالتساوي بنجاح');
              }}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>إعادة توزيع الأجزاء</span>
            </button>
          </div>
        </form>

        {/* طلبات الانضمام (للمجموعات الخاصة) */}
        {group.joinRequests.length > 0 && (
          <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] space-y-3 shadow-xs">
            <h3 className="font-cairo font-bold text-base text-[#25263A]">
              طلبات الانضمام المعلقة ({group.joinRequests.length})
            </h3>
            <div className="space-y-2.5">
              {group.joinRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-3"
                >
                  <div>
                    <p className="font-cairo font-bold text-sm text-[#25263A]">
                      {req.userName}
                    </p>
                    <p className="font-cairo text-xs text-[#77798C]">
                      {new Date(req.requestedAt).toLocaleString('ar-EG')}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onHandleJoinRequest(req.id, true)}
                      className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer"
                    >
                      قبول وتوزيع
                    </button>
                    <button
                      type="button"
                      onClick={() => onHandleJoinRequest(req.id, false)}
                      className="px-3 py-1.5 rounded-xl bg-[#D95C6A] text-white font-cairo font-bold text-xs cursor-pointer"
                    >
                      رفض
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* إدارة الأعضاء: قائمة + ترقية مشرف + حذف مع إعادة التوزيع */}
        <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] space-y-3 shadow-xs">
          <h3 className="font-cairo font-bold text-base text-[#25263A]">
            إدارة الأعضاء ({group.members.length})
          </h3>
          <div className="space-y-2.5">
            {group.members.map((m) => (
              <div
                key={m.userId}
                className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-3 flex-wrap"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center font-cairo font-bold text-xs text-[#25263A]">
                    {m.displayName.charAt(0)}
                  </div>
                  <div>
                    <p className="font-cairo font-bold text-sm text-[#25263A]">
                      {m.displayName}{' '}
                      <span className="text-[11px] text-[#E8B84A]">
                        ({m.role === 'admin' ? 'مشرف' : 'عضو'})
                      </span>
                    </p>
                    <p className="font-cairo text-xs text-[#77798C]">
                      أيام الإنجاز: {m.completedDaysCount || 0} يوم
                    </p>
                  </div>
                </div>

                {m.userId !== currentUserId &&
                  m.userId !== effectiveUserId &&
                  m.userId !== group.adminId && (
                  <div className="flex items-center gap-2">
                    {m.role !== 'admin' && (
                      <button
                        type="button"
                        onClick={async () => {
                          await onPromoteMember(m.userId);
                          showLocalToast(`تم تعيين ${m.displayName} مشرفاً`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-[#72B7E8] text-white font-cairo font-bold text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>تعيين مشرف</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setMemberToRemove(m)}
                      className="px-3 py-1.5 rounded-xl bg-[#D95C6A] text-white font-cairo font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>إزالة العضو</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* حذف المجموعة: زر أحمر + تأكيد */}
        <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#D95C6A]/40 space-y-3">
          <h3 className="font-cairo font-bold text-base text-[#D95C6A]">
            منطقة الخطر • حذف المجموعة
          </h3>
          <p className="font-cairo text-xs text-[#77798C]">
            حذف المجموعة سيؤدي إلى إنهاء الختمة الجماعية وإزالتها لجميع الأعضاء نهائياً.
          </p>
          {!confirmDeleteOpen ? (
            <button
              type="button"
              onClick={() => setConfirmDeleteOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-[#D95C6A] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>حذف المجموعة نهائياً</span>
            </button>
          ) : (
            <div className="p-3.5 rounded-xl bg-[#D95C6A]/5 border border-[#D95C6A] flex items-center justify-between gap-3 flex-wrap">
              <span className="font-cairo font-bold text-xs text-[#D95C6A]">
                هل أنت متأكد من حذف مجموعة «{group.groupName}» نهائياً؟
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onDeleteGroup}
                  className="px-3.5 py-1.5 rounded-xl bg-[#D95C6A] text-white font-cairo font-bold text-xs cursor-pointer"
                >
                  تأكيد الحذف
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="px-3.5 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-xs cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── شاشة الإحصائيات البصرية للمجموعة والتقرير الأسبوعي (Recharts) ──
  if (viewMode === 'stats') {
    const totalCompletedDaysAll = group.dailyProgressHistory.filter(
      (d) => d.isFullCompleted
    ).length;
    const overallPlanPercent = Math.min(
      100,
      Math.round(
        ((group.currentDay - 1 + progressPercent / 100) /
          Math.max(1, group.targetDays)) *
          100
      )
    );

    const RIFQ_CHART_COLORS = [
      '#4CAF82',
      '#72B7E8',
      '#72B7E8',
      '#E8B84A',
      '#E8B84A',
      '#25263A',
      '#E8B84A',
    ];

    // 1. بيانات توزيع الإنجاز بين الأعضاء (للرسم البياني الشريطي والدائري)
    const memberChartData = sortedMemberRows.map(
      ({ member, dist, isCompletedToday }, idx) => {
        const assignedPagesToday = dist
          ? Math.max(1, dist.pageTo - dist.pageFrom + 1)
          : 0;
        const completedPagesToday = isCompletedToday
          ? assignedPagesToday
          : Math.min(assignedPagesToday, Math.max(0, member.dailyProgress || 0));
        const remainingPagesToday = Math.max(
          0,
          assignedPagesToday - completedPagesToday
        );
        const completedDays =
          (member.completedDaysCount || 0) +
          (isCompletedToday && !(member.completedDaysCount || 0) ? 1 : 0);
        const completionRate =
          assignedPagesToday > 0
            ? Math.round((completedPagesToday / assignedPagesToday) * 100)
            : isCompletedToday
            ? 100
            : 0;
        const adherenceRate = Math.min(
          100,
          Math.round((completedDays / Math.max(1, group.currentDay)) * 100)
        );

        return {
          userId: member.userId,
          name: member.displayName,
          shortName:
            member.displayName.length > 12
              ? `${member.displayName.slice(0, 12)}…`
              : member.displayName,
          assignedPages: assignedPagesToday,
          completedPages: completedPagesToday,
          remainingPages: remainingPagesToday,
          completedDays,
          completionRate,
          adherenceRate,
          partNumber: dist?.partNumber || 1,
          surahName: dist?.surahName || 'سورة الفاتحة',
          isCompletedToday,
          fill: RIFQ_CHART_COLORS[idx % RIFQ_CHART_COLORS.length],
          shareValue: Math.max(1, completedPagesToday || assignedPagesToday),
        };
      }
    );

    const totalAssignedPagesToday = memberChartData.reduce(
      (sum, m) => sum + m.assignedPages,
      0
    );
    const totalCompletedPagesToday = memberChartData.reduce(
      (sum, m) => sum + m.completedPages,
      0
    );

    // 2. بيانات نسبة تقدم الختمة الجماعية (PieChart)
    const pagesPerDayTarget = Math.max(
      1,
      Math.round(group.totalPages / Math.max(1, group.targetDays))
    );
    const previousCompletedPages = Math.min(
      group.totalPages,
      Math.max(0, group.currentDay - 1) * pagesPerDayTarget
    );
    const completedKhatmaPages = Math.min(
      group.totalPages,
      previousCompletedPages + totalCompletedPagesToday
    );
    const activeTodayRemainingPages = Math.max(
      0,
      totalAssignedPagesToday - totalCompletedPagesToday
    );
    const remainingKhatmaPages = Math.max(
      0,
      group.totalPages - completedKhatmaPages - activeTodayRemainingPages
    );

    const khatmaPieData = [
      {
        name: 'مكتمل من الختمة',
        value: completedKhatmaPages,
        color: '#4CAF82',
      },
      {
        name: 'قيد القراءة اليوم',
        value: activeTodayRemainingPages,
        color: '#72B7E8',
      },
      {
        name: 'متبقي من الخطة',
        value:
          completedKhatmaPages === 0 &&
          activeTodayRemainingPages === 0 &&
          remainingKhatmaPages === 0
            ? group.totalPages || 1
            : remainingKhatmaPages,
        color: '#E6E6F0',
      },
    ].filter((segment) => segment.value > 0);

    // 3. بيانات إنجاز الأعضاء لليوم الحالي (PieChart)
    const pendingMembersCount = Math.max(
      0,
      totalMembersCount - completedMembersCount
    );
    const todayMembersPieData =
      totalMembersCount > 0
        ? [
            {
              name: 'أتموا قراءة الورد',
              value: completedMembersCount,
              color: '#4CAF82',
            },
            {
              name: 'قيد القراءة اليوم',
              value: pendingMembersCount,
              color: '#72B7E8',
            },
          ].filter((s) => s.value > 0)
        : [
            {
              name: 'بانتظار الأعضاء',
              value: 1,
              color: '#E6E6F0',
            },
          ];

    // 4. بيانات السجل اليومي للتقدم الجماعي (BarChart)
    const rawHistory =
      group.dailyProgressHistory.length > 0
        ? group.dailyProgressHistory.slice(-7)
        : [
            {
              dayNumber: group.currentDay,
              date: formattedTodayAr,
              completedMembers: completedMembersCount,
              totalMembers: totalMembersCount,
              isFullCompleted:
                totalMembersCount > 0 &&
                completedMembersCount === totalMembersCount,
            },
          ];

    const dailyHistoryChartData = rawHistory.map((dp) => {
      const pct =
        dp.totalMembers > 0
          ? Math.round((dp.completedMembers / dp.totalMembers) * 100)
          : 0;
      return {
        dayNumber: dp.dayNumber,
        dayLabel: `اليوم ${dp.dayNumber}`,
        date: dp.date,
        completedMembers: dp.completedMembers,
        remainingMembers: Math.max(0, dp.totalMembers - dp.completedMembers),
        totalMembers: dp.totalMembers,
        percentage: pct,
      };
    });

    return (
      <div className="space-y-5 pb-10 animate-fade-in" dir="rtl">
        {/* شريط علوي + أزرار تبديل نوع الرسم البياني */}
        <div className="bg-[#FFFFFF] rounded-[20px] p-4 border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setViewMode('main')}
              className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
              <span>رجوع للمجموعة</span>
            </button>
            <div>
              <h2 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                الإحصائيات البصرية وتوزيع الإنجاز
              </h2>
              <p className="font-cairo text-xs text-[#77798C]">
                {group.groupName} • {getPlanLabel(group.planType, group.customSurahName)}
              </p>
            </div>
          </div>

          {/* مفتاح اختيار نوع الرسم البياني */}
          <div className="flex items-center gap-1.5 bg-[#F7F7FC] p-1 rounded-xl border border-[#E6E6F0] self-start sm:self-auto">
            {(
              [
                { id: 'both', label: 'الكل (دائري + شريطي)' },
                { id: 'pie', label: 'رسم دائري' },
                { id: 'bar', label: 'رسم شريطي' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setChartDisplayMode(tab.id)}
                className={`px-3 py-1.5 rounded-lg font-cairo font-bold text-xs transition-all cursor-pointer ${
                  chartDisplayMode === tab.id
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'text-[#25263A] hover:bg-[#F7F7FC]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 4 بطاقات ملخص رقمية */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-[#FFFFFF] p-4 rounded-[20px] border border-[#E6E6F0] text-center">
            <p className="font-cairo font-bold text-2xl text-[#5B5FEF]">
              {overallPlanPercent}%
            </p>
            <p className="font-cairo text-xs text-[#25263A] mt-1">
              نسبة تقدم الختمة الجماعية
            </p>
          </div>
          <div className="bg-[#FFFFFF] p-4 rounded-[20px] border border-[#E6E6F0] text-center">
            <p className="font-cairo font-bold text-2xl text-[#4CAF82]">
              {completedMembersCount}/{totalMembersCount}
            </p>
            <p className="font-cairo text-xs text-[#25263A] mt-1">
              إنجاز الأعضاء اليوم ({progressPercent}%)
            </p>
          </div>
          <div className="bg-[#FFFFFF] p-4 rounded-[20px] border border-[#E6E6F0] text-center">
            <p className="font-cairo font-bold text-2xl text-[#72B7E8]">
              {totalCompletedPagesToday}/{totalAssignedPagesToday || group.totalPages}
            </p>
            <p className="font-cairo text-xs text-[#25263A] mt-1">
              الصفحات المنجزة اليوم
            </p>
          </div>
          <div className="bg-[#FFFFFF] p-4 rounded-[20px] border border-[#E6E6F0] text-center">
            <p className="font-cairo font-bold text-2xl text-[#E8B84A]">
              {totalCompletedDaysAll}
            </p>
            <p className="font-cairo text-xs text-[#25263A] mt-1">
              أيام مكتملة 100%
            </p>
          </div>
        </div>

        {/* ── 1. الرسم البياني الدائري (PieChart): نسبة تقدم الختمة الجماعية وتوزيع الحصص ── */}
        {(chartDisplayMode === 'both' || chartDisplayMode === 'pie') && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* البطاقة الأولى: نسبة تقدم الختمة الجماعية (PieChart) */}
            <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                    <PieChartIcon className="w-4 h-4 text-[#5B5FEF]" />
                  </div>
                  <div>
                    <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                      نسبة تقدم الختمة الجماعية
                    </h3>
                    <p className="font-cairo text-[11px] text-[#77798C]">
                      توزيع الصفحات المنجزة والمتبقية من إجمالي {group.totalPages} صفحة
                    </p>
                  </div>
                </div>
                <span className="font-cairo font-bold text-sm text-[#4CAF82]">
                  {overallPlanPercent}% مكتمل
                </span>
              </div>

              <div className="w-full h-64 relative" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={khatmaPieData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="48%"
                      innerRadius={55}
                      outerRadius={82}
                      paddingAngle={3}
                      stroke="#FFFFFF"
                      strokeWidth={2}
                    >
                      {khatmaPieData.map((entry, index) => (
                        <Cell key={`khatma-cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const item = payload[0].payload as (typeof khatmaPieData)[0];
                          const pct =
                            group.totalPages > 0
                              ? Math.round((item.value / group.totalPages) * 100)
                              : 0;
                          return (
                            <div
                              className="bg-[#FFFFFF] p-3 rounded-xl shadow-md border border-[#E6E6F0] text-right font-cairo text-xs"
                              dir="rtl"
                            >
                              <p className="font-bold text-[#25263A] mb-1">
                                {item.name}
                              </p>
                              <p className="text-[#4CAF82] font-bold">
                                {item.value} صفحة ({pct}%)
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={32}
                      formatter={(value) => (
                        <span className="font-cairo text-xs text-[#25263A] font-bold mx-1">
                          {value}
                        </span>
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
                {/* النسبة في منتصف الحلقة الدائرية */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-7">
                  <span className="font-cairo font-bold text-xl text-[#25263A]">
                    {overallPlanPercent}%
                  </span>
                  <span className="font-cairo text-[10px] text-[#77798C]">
                    إنجاز الخطة
                  </span>
                </div>
              </div>
            </div>

            {/* البطاقة الثانية: رسم دائري لتوزيع الإنجاز والحصص بين الأعضاء */}
            <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                    <PieChartIcon className="w-4 h-4 text-[#4CAF82]" />
                  </div>
                  <div>
                    <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                      توزيع حصص وإنجاز الأعضاء اليوم
                    </h3>
                    <p className="font-cairo text-[11px] text-[#77798C]">
                      نسبة إتمام الورد اليومي وحصة كل عضو من صفحات المجموعة
                    </p>
                  </div>
                </div>
                <span className="font-cairo font-bold text-sm text-[#5B5FEF]">
                  {progressPercent}% اليوم
                </span>
              </div>

              <div className="w-full h-64 relative" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    {/* الحلقة الداخلية: حالة الإنجاز اليوم (مكتمل / قيد القراءة) */}
                    <Pie
                      data={todayMembersPieData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="48%"
                      innerRadius={32}
                      outerRadius={52}
                      paddingAngle={2}
                      stroke="#FFFFFF"
                      strokeWidth={2}
                    >
                      {todayMembersPieData.map((entry, idx) => (
                        <Cell key={`today-status-${idx}`} fill={entry.color} />
                      ))}
                    </Pie>
                    {/* الحلقة الخارجية: توزيع الصفحات بين الأعضاء */}
                    <Pie
                      data={
                        memberChartData.length > 0
                          ? memberChartData
                          : [{ name: 'لا يوجد أعضاء', shareValue: 1, fill: '#E6E6F0' }]
                      }
                      dataKey="shareValue"
                      nameKey="name"
                      cx="50%"
                      cy="48%"
                      innerRadius={60}
                      outerRadius={82}
                      paddingAngle={3}
                      stroke="#FFFFFF"
                      strokeWidth={2}
                    >
                      {(memberChartData.length > 0
                        ? memberChartData
                        : [{ fill: '#E6E6F0' }]
                      ).map((entry, idx) => (
                        <Cell key={`member-slice-${idx}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const dataObj = payload[0].payload;
                          if ('assignedPages' in dataObj) {
                            return (
                              <div
                                className="bg-[#FFFFFF] p-3 rounded-xl shadow-md border border-[#E6E6F0] text-right font-cairo text-xs"
                                dir="rtl"
                              >
                                <p className="font-bold text-[#25263A] mb-1">
                                  {dataObj.name}
                                </p>
                                <p className="text-[#4CAF82] font-bold">
                                  المنجز اليوم: {dataObj.completedPages} من{' '}
                                  {dataObj.assignedPages} صفحات ({dataObj.completionRate}%)
                                </p>
                                <p className="text-[#77798C] text-[11px] mt-0.5">
                                  أيام الإنجاز الكلية: {dataObj.completedDays} يوم
                                </p>
                              </div>
                            );
                          }
                          return (
                            <div
                              className="bg-[#FFFFFF] p-2.5 rounded-xl shadow-md border border-[#E6E6F0] text-right font-cairo text-xs"
                              dir="rtl"
                            >
                              <p className="font-bold text-[#25263A]">
                                {dataObj.name}: {dataObj.value} عضو
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={32}
                      formatter={(value) => (
                        <span className="font-cairo text-xs text-[#25263A] font-bold mx-1">
                          {value}
                        </span>
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* ── 2. الرسم البياني الشريطي (BarChart): توزيع الإنجاز بين الأعضاء ── */}
        {(chartDisplayMode === 'both' || chartDisplayMode === 'bar') && (
          <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F7F7FC] pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                  <BarChart3 className="w-4 h-4 text-[#72B7E8]" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                    توزيع الإنجاز بين أعضاء المجموعة (رسم بياني شريطي)
                  </h3>
                  <p className="font-cairo text-[11px] text-[#77798C]">
                    مقارنة الصفحات المنجزة والمخصصة لكل عضو وأيام الالتزام في الختمة
                  </p>
                </div>
              </div>

              {/* تبديل مقياس الرسم الشريطي للأعضاء */}
              <div className="flex items-center gap-1.5 bg-[#F7F7FC] p-1 rounded-xl border border-[#E6E6F0] self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setMemberBarMetric('pages')}
                  className={`px-3 py-1 rounded-lg font-cairo font-bold text-xs transition-all cursor-pointer ${
                    memberBarMetric === 'pages'
                      ? 'bg-[#5B5FEF] text-white'
                      : 'text-[#25263A] hover:bg-[#F7F7FC]'
                  }`}
                >
                  صفحات ورد اليوم
                </button>
                <button
                  type="button"
                  onClick={() => setMemberBarMetric('days')}
                  className={`px-3 py-1 rounded-lg font-cairo font-bold text-xs transition-all cursor-pointer ${
                    memberBarMetric === 'days'
                      ? 'bg-[#5B5FEF] text-white'
                      : 'text-[#25263A] hover:bg-[#F7F7FC]'
                  }`}
                >
                  أيام الإنجاز والنسبة
                </button>
              </div>
            </div>

            {memberChartData.length === 0 ? (
              <p className="font-cairo text-xs text-[#77798C] text-center py-8">
                لا يوجد أعضاء نشطون لعرض توزيع الإنجاز بعد.
              </p>
            ) : (
              <div className="w-full h-72 pt-2" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={memberChartData}
                    margin={{ top: 10, right: 20, left: 0, bottom: 10 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#F7F7FC"
                    />
                    <XAxis
                      dataKey="shortName"
                      tick={{ fontSize: 11, fill: '#25263A', fontFamily: 'Cairo' }}
                      tickLine={false}
                      axisLine={{ stroke: '#72B7E8' }}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#77798C', fontFamily: 'Cairo' }}
                      tickLine={false}
                      axisLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const item =
                            payload[0].payload as (typeof memberChartData)[0];
                          return (
                            <div
                              className="bg-[#FFFFFF] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs space-y-1 min-w-[165px]"
                              dir="rtl"
                            >
                              <p className="font-bold text-[#25263A] border-b border-[#F7F7FC] pb-1">
                                {item.name} • الجزء {item.partNumber}
                              </p>
                              <div className="flex items-center justify-between gap-3">
                                <span className="text-[#77798C]">الصفحات المنجزة:</span>
                                <span className="font-bold text-[#4CAF82]">
                                  {item.completedPages} صفحة
                                </span>
                              </div>
                              <div className="flex items-center justify-between gap-3">
                                <span className="text-[#77798C]">الصفحات المخصصة:</span>
                                <span className="font-bold text-[#5B5FEF]">
                                  {item.assignedPages} صفحة
                                </span>
                              </div>
                              <div className="flex items-center justify-between gap-3">
                                <span className="text-[#77798C]">إجمالي أيام الإنجاز:</span>
                                <span className="font-bold text-[#72B7E8]">
                                  {item.completedDays} يوم ({item.completionRate}%)
                                </span>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Legend
                      verticalAlign="top"
                      height={32}
                      formatter={(value) => (
                        <span className="font-cairo text-xs text-[#25263A] font-bold mx-1">
                          {value}
                        </span>
                      )}
                    />
                    {memberBarMetric === 'pages' ? (
                      <>
                        <Bar
                          dataKey="completedPages"
                          name="الصفحات المنجزة اليوم"
                          fill="#4CAF82"
                          radius={[8, 8, 0, 0]}
                          maxBarSize={42}
                        />
                        <Bar
                          dataKey="assignedPages"
                          name="الصفحات المخصصة اليوم"
                          fill="#72B7E8"
                          radius={[8, 8, 0, 0]}
                          maxBarSize={42}
                        />
                      </>
                    ) : (
                      <>
                        <Bar
                          dataKey="completedDays"
                          name="أيام الإنجاز المكتملة"
                          fill="#72B7E8"
                          radius={[8, 8, 0, 0]}
                          maxBarSize={42}
                        />
                        <Bar
                          dataKey="completionRate"
                          name="نسبة إنجاز اليوم (%)"
                          fill="#4CAF82"
                          radius={[8, 8, 0, 0]}
                          maxBarSize={42}
                        />
                      </>
                    )}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {/* ── 3. الرسم البياني الشريطي لتطور الختمة الجماعية عبر الأيام ── */}
        {(chartDisplayMode === 'both' || chartDisplayMode === 'bar') && (
          <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
              <div>
                <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                  مسار تقدم الختمة الجماعية عبر الأيام
                </h3>
                <p className="font-cairo text-[11px] text-[#77798C]">
                  عدد الأعضاء المنجزين ونسبة إتمام الورد الجماعي لكل يوم
                </p>
              </div>
              <span className="font-cairo font-bold text-xs text-[#E8B84A]">
                آخر {dailyHistoryChartData.length} أيام
              </span>
            </div>

            <div className="w-full h-60 pt-2" dir="ltr">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={dailyHistoryChartData}
                  margin={{ top: 10, right: 20, left: 0, bottom: 5 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    vertical={false}
                    stroke="#F7F7FC"
                  />
                  <XAxis
                    dataKey="dayLabel"
                    tick={{ fontSize: 11, fill: '#25263A', fontFamily: 'Cairo' }}
                    tickLine={false}
                    axisLine={{ stroke: '#72B7E8' }}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#77798C', fontFamily: 'Cairo' }}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const dp =
                          payload[0].payload as (typeof dailyHistoryChartData)[0];
                        return (
                          <div
                            className="bg-[#FFFFFF] p-3 rounded-xl shadow-md border border-[#E6E6F0] text-right font-cairo text-xs space-y-1"
                            dir="rtl"
                          >
                            <p className="font-bold text-[#25263A]">
                              {dp.dayLabel} ({dp.date})
                            </p>
                            <p className="text-[#4CAF82] font-bold">
                              أكمل {dp.completedMembers} من {dp.totalMembers} أعضاء (
                              {dp.percentage}%)
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={30}
                    formatter={(value) => (
                      <span className="font-cairo text-xs text-[#25263A] font-bold mx-1">
                        {value}
                      </span>
                    )}
                  />
                  <Bar
                    dataKey="completedMembers"
                    name="الأعضاء المنجزون"
                    fill="#4CAF82"
                    radius={[8, 8, 0, 0]}
                    maxBarSize={40}
                  />
                  <Bar
                    dataKey="remainingMembers"
                    name="قيد القراءة"
                    fill="#72B7E8"
                    radius={[8, 8, 0, 0]}
                    maxBarSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* ── 4. جدول تفصيل إنجاز الأعضاء والتقرير الأسبوعي ── */}
        <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] space-y-3">
          <h3 className="font-cairo font-bold text-base text-[#25263A]">
            تفصيل نسب الإنجاز بين الأعضاء
          </h3>
          <div className="space-y-2.5">
            {memberChartData.map((m, idx) => (
              <div
                key={m.userId}
                className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-3 flex-wrap"
              >
                <div className="flex items-center gap-2.5">
                  <RankMedalSvg rank={idx + 1} />
                  <div>
                    <p className="font-cairo font-bold text-xs sm:text-sm text-[#25263A]">
                      {m.name} •{' '}
                      <span className="text-[#E8B84A]">الجزء {m.partNumber}</span>
                    </p>
                    <p className="font-cairo text-[11px] text-[#77798C]">
                      الصفحات: {m.completedPages}/{m.assignedPages} صفحة • أيام الإنجاز:{' '}
                      {m.completedDays} يوم
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 w-40">
                  <div className="flex-1 h-2.5 rounded-full bg-[#F7F7FC] overflow-hidden border border-[#E6E6F0]">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${m.completionRate}%`,
                        backgroundColor: m.isCompletedToday ? '#4CAF82' : '#72B7E8',
                      }}
                    />
                  </div>
                  <span className="font-cairo font-bold text-xs text-[#4CAF82] w-9 text-left">
                    {m.completionRate}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── 【الشاشة 4】صفحة المجموعة الرئيسية ──
  return (
    <div className="space-y-5 pb-10 animate-fade-in" dir="rtl">
      {adminToast && (
        <div className="p-3 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs flex items-center justify-between shadow-md">
          <span>{adminToast}</span>
          <button type="button" onClick={() => setAdminToast(null)} className="cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ■ شريط علوي: رجوع + أيقونة المجموعة + الاسم + إحصائيات بصرية + مشاركة + إعدادات (للمشرف) */}
      <div className="bg-[#FFFFFF] rounded-[20px] p-4 border border-[#E6E6F0] shadow-xs flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
            title="رجوع"
          >
            <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          </button>

          <div className="w-11 h-11 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
            <WirdGroupSvgIcon icon={group.icon} size={26} />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                {group.groupName}
              </h2>
              <span className="font-cairo text-[11px] font-bold text-[#E8B84A]">
                • كود: {group.joinCode}
              </span>
            </div>
            <p className="font-cairo text-xs text-[#77798C]">{group.description}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setViewMode('stats')}
            className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#5B5FEF] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            title="شاشة الإحصائيات البصرية"
          >
            <PieChartIcon className="w-4 h-4 text-[#5B5FEF]" />
            <span>الإحصائيات البصرية</span>
          </button>

          <button
            type="button"
            onClick={handleShareInvite}
            className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            title="مشاركة كود الدعوة"
          >
            {copiedCode ? (
              <Check className="w-4 h-4 text-[#4CAF82]" />
            ) : (
              <Share2 className="w-4 h-4 text-[#5B5FEF]" />
            )}
            <span>مشاركة</span>
          </button>

          {isAdmin && (
            <button
              type="button"
              onClick={() => setViewMode('settings')}
              className="px-3 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              title="إعدادات المشرف"
            >
              <Settings className="w-4 h-4" />
              <span>الإعدادات</span>
            </button>
          )}
        </div>
      </div>

      {/* ■ بطاقة ملخص الورد */}
      <div className="bg-[#FFFFFF] rounded-[20px] p-5 border-2 border-[#5B5FEF] shadow-sm space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <p className="font-cairo font-bold text-xs text-[#77798C]">
              اليوم {group.currentDay} من {group.targetDays} - {formattedTodayAr}
            </p>
            <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A] mt-0.5">
              {getPlanLabel(group.planType, group.customSurahName)}
            </h3>
          </div>

          <div className="text-left">
            <span className="font-cairo font-bold text-xl sm:text-2xl text-[#5B5FEF]">
              إنجاز {progressPercent}%
            </span>
          </div>
        </div>

        {/* شريط تقدم كبير (14px) */}
        <div className="w-full h-[14px] rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-l from-[#72B7E8] via-[#E8B84A] to-[#4CAF82] transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-xs font-cairo font-bold pt-1">
          <div className="flex items-center gap-1.5 text-[#4CAF82]">
            <CheckCircle2 className="w-4 h-4 text-[#4CAF82]" />
            <span>
              {completedMembersCount} من {totalMembersCount} أعضاء أكملوا ورد اليوم
            </span>
          </div>
          <span className="text-[#77798C]">
            إجمالي صفحات الخطة: {group.totalPages} صفحة
          </span>
        </div>
      </div>

      {/* ■ أزرار التحكم */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          type="button"
          onClick={() => setViewMode('stats')}
          className="py-2.5 px-3 rounded-xl bg-[#FFFFFF] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
        >
          <BarChart3 className="w-4 h-4 text-[#72B7E8]" />
          <span>الإحصائيات والتقدم</span>
        </button>

        <button
          type="button"
          onClick={handleShareInvite}
          className="py-2.5 px-3 rounded-xl bg-[#FFFFFF] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
        >
          <UserPlus className="w-4 h-4 text-[#4CAF82]" />
          <span>دعوة أصدقاء</span>
        </button>

        <button
          type="button"
          onClick={async () => {
            await onRedistribute();
            showLocalToast('تمت إعادة توزيع الأجزاء بالتساوي على جميع الأعضاء');
          }}
          className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#5B5FEF] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
        >
          <RefreshCw className="w-4 h-4 text-[#5B5FEF]" />
          <span>إعادة توزيع</span>
        </button>

        <button
          type="button"
          disabled={isAdvancingDay}
          onClick={async () => {
            if (isAdvancingDay) return;
            setIsAdvancingDay(true);
            try {
              const prevDay = group.currentDay;
              const targetDays = group.targetDays;
              await onAdvanceDay();
              const nextDayNum = prevDay >= targetDays ? 1 : prevDay + 1;
              showLocalToast(
                prevDay >= targetDays && completedMembersCount < totalMembersCount
                  ? `تم إتمام اليوم الأخير (${prevDay} من ${targetDays}) واكتمال الختمة بنجاح!`
                  : prevDay >= targetDays
                  ? 'تم بدء دورة ختمة جديدة من اليوم 1 وتوزيع الأوراد بنجاح'
                  : `تم إنهاء اليوم ${prevDay} والانتقال لأوراد اليوم ${nextDayNum} بنجاح`
              );
            } finally {
              setIsAdvancingDay(false);
            }
          }}
          className="py-2.5 px-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] disabled:opacity-60 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs transition-all active:scale-95"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isAdvancingDay ? 'جاري إنهاء اليوم...' : 'إنهاء اليوم'}</span>
        </button>
      </div>

      {/* ■ بطاقة «وردك اليوم» المخصصة للعضو الحالي مع قفل النطاق وشريط التقدم الذهبي */}
      {myMember && myTodayDist && (() => {
        const myPageFrom = myTodayDist.pageFrom;
        const myPageTo = myTodayDist.pageTo;
        const myTotalPages = Math.max(1, myPageTo - myPageFrom + 1);
        const hasStartedMyReading = myCompletionEligibility.hasStarted;
        const myCurrentPage = myTodayDist.isCompleted
          ? myPageTo
          : hasStartedMyReading
          ? Math.max(
              myPageFrom,
              Math.min(
                myPageTo,
                myTodayDist.currentPage ||
                  myCompletionEligibility.currentPageReached ||
                  myPageFrom
              )
            )
          : myPageFrom;
        const myPct = myTodayDist.isCompleted
          ? 100
          : hasStartedMyReading
          ? Math.min(
              100,
              Math.max(
                myTodayDist.progress || 0,
                myCompletionEligibility.progressPercent || 0
              )
            )
          : 0;

        return (
          <div className="bg-[#F7F7FC] rounded-[20px] p-5 border-2 border-[#5B5FEF] shadow-sm space-y-3.5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#5B5FEF]" />
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                  وردك اليوم
                </h3>
              </div>

              <span
                className={`px-3 py-1 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 border ${
                  myTodayDist.isCompleted
                    ? 'bg-[#4CAF82]/12 text-[#4CAF82] border-[#4CAF82]'
                    : hasStartedMyReading
                    ? 'bg-[#E8B84A]/15 text-[#B47D12] border-[#E8B84A]'
                    : 'bg-[#77798C]/12 text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                {myTodayDist.isCompleted ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4CAF82]" />
                ) : hasStartedMyReading ? (
                  <Clock className="w-3.5 h-3.5 text-[#B47D12]" />
                ) : (
                  <Lock className="w-3.5 h-3.5 text-[#5B5FEF]" />
                )}
                <span>
                  {myTodayDist.isCompleted
                    ? 'تم الإنهاء • أتممت قراءة وردك اليوم'
                    : hasStartedMyReading
                    ? `قيد القراءة • وصلت إلى ص ${myCurrentPage}`
                    : 'لم يبدأ • قفل النطاق المخصص مفعّل'}
                </span>
              </span>
            </div>

            <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#E6E6F0] space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <p className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                    {myTodayDist.surahName}
                  </p>
                  <p className="font-cairo font-bold text-xs text-[#77798C] mt-0.5">
                    الجزء {myTodayDist.partNumber} • الصفحات: {myPageFrom} → {myPageTo} ({myTotalPages} صفحة)
                  </p>
                </div>

                <span className="font-cairo font-bold text-xs sm:text-sm text-[#25263A] bg-[#F7F7FC] px-3 py-1 rounded-xl border border-[#E6E6F0]">
                  {myTodayDist.isCompleted
                    ? `مكتمل (${myPageFrom} → ${myPageTo})`
                    : hasStartedMyReading
                    ? `الصفحة ${myCurrentPage} من ${myPageTo}`
                    : `يبدأ من صفحة ${myPageFrom}`}
                </span>
              </div>

              {/* شريط تقدم ذهبي */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-3 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-[#72B7E8] via-[#E8B84A] to-[#4CAF82] transition-all duration-500"
                    style={{ width: `${myPct}%` }}
                  />
                </div>
                <span className="font-cairo font-bold text-xs sm:text-sm text-[#5B5FEF] min-w-[40px] text-left">
                  {myPct}%
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 flex-wrap">
              <button
                type="button"
                onClick={() =>
                  onOpenMushaf(
                    myPageFrom,
                    myPageTo,
                    `ورد ${myMember.displayName} • الجزء ${myTodayDist.partNumber}`
                  )
                }
                className="flex-1 min-w-[140px] py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] hover:brightness-105 text-white font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <BookOpen className="w-4 h-4" />
                <span>
                  {myTodayDist.isCompleted
                    ? 'إعادة قراءة وردك / الاستماع'
                    : hasStartedMyReading
                    ? 'متابعة قراءة وردك من المصحف'
                    : 'فتح المصحف وبدء قراءة وردك'}
                </span>
              </button>

              {!myTodayDist.isCompleted ? (
                <button
                  type="button"
                  aria-disabled={!myCompletionEligibility.allowed}
                  onClick={async () => {
                    if (!myCompletionEligibility.allowed) {
                      showLocalToast(myCompletionEligibility.reason);
                      return;
                    }
                    try {
                      await onCompleteMyWird();
                      setShowTomorrowModal(true);
                    } catch (err: any) {
                      showLocalToast(
                        err?.message ||
                          'أكمل قراءة الجزء المخصص أولًا قبل الضغط على انتهاء القراءة'
                      );
                    }
                  }}
                  className={`py-2.5 px-4 rounded-xl font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                    myCompletionEligibility.allowed
                      ? 'bg-[#4CAF82] hover:brightness-95 text-white shadow-xs'
                      : 'bg-[#77798C]/20 text-[#77798C] border border-[#77798C]'
                  }`}
                  title={
                    myCompletionEligibility.allowed
                      ? 'اضغط لتسجيل إتمام قراءة الورد'
                      : myCompletionEligibility.reason
                  }
                >
                  {myCompletionEligibility.allowed ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-[#77798C]" />
                  )}
                  <span>انتهاء القراءة</span>
                </button>
              ) : null}

              {/* زر "الورد التالي" معطل بالرمادي #77798C وعند الضغط يظهر نافذة "غدًا إن شاء الله" */}
              <button
                type="button"
                onClick={() => setShowTomorrowModal(true)}
                aria-disabled="true"
                className="py-2.5 px-4 rounded-xl bg-[#77798C]/25 text-[#77798C] border border-[#77798C] font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-4 h-4 text-[#77798C]" />
                <span>الورد التالي (غدًا إن شاء الله)</span>
              </button>
            </div>
          </div>
        );
      })()}

      {/* ■ قائمة الأعضاء مرتبة حسب الإنجاز + التوزيع التلقائي + قفل الورد + متابعة الأدمن وإزالة عضو */}
      <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3 flex-wrap gap-2">
          <div>
            <h3 className="font-cairo font-bold text-base text-[#25263A]">
              قائمة الأعضاء وتوزيع الأجزاء ({totalMembersCount})
            </h3>
            <p className="font-cairo text-[11px] text-[#77798C]">
              متابعة حية من Firestore لحالة القراءة، نسبة التقدم، والصفحة الحالية لكل عضو
            </p>
          </div>
          <span className="font-cairo text-xs font-bold text-[#E8B84A]">
            توزيع تلقائي متساوٍ
          </span>
        </div>

        <div className="space-y-3">
          {sortedMemberRows.map(({ member, dist, isCompletedToday }, idx) => {
            const isCurrentUser =
              member.userId === effectiveUserId || member.userId === currentUserId;
            const isOwnerMember = member.userId === group.adminId;
            const pageFrom = dist?.pageFrom || 1;
            const pageTo = dist?.pageTo || 1;
            const assignedPagesCount = Math.max(1, pageTo - pageFrom + 1);
            const partNumber = dist?.partNumber || 1;
            const surahName = dist?.surahName || 'سورة الفاتحة';

            const hasStartedReading = Boolean(
              !isCompletedToday &&
                (dist?.status === 'reading' ||
                  member.readingStatus === 'reading' ||
                  dist?.startTime ||
                  member.startTime ||
                  (member.dailyProgress || 0) > 0)
            );

            const memberStatusLabel = isCompletedToday
              ? 'تم الإنهاء'
              : hasStartedReading
              ? 'قيد القراءة'
              : 'لم يبدأ';

            const currentPageReached = isCompletedToday
              ? pageTo
              : hasStartedReading
              ? Math.max(
                  pageFrom,
                  Math.min(
                    pageTo,
                    dist?.currentPage ||
                      member.currentPage ||
                      dist?.highestPageReached ||
                      pageFrom
                  )
                )
              : 0;

            const memberProgressPct = isCompletedToday
              ? 100
              : hasStartedReading
              ? Math.min(
                  100,
                  Math.max(
                    1,
                    dist?.progress ||
                      member.progressPercent ||
                      Math.round(
                        ((Math.max(pageFrom, currentPageReached) - pageFrom + 1) /
                          assignedPagesCount) *
                          100
                      )
                  )
                )
              : 0;

            const startTimeIso = dist?.startTime || member.startTime || null;
            const completedAtIso = dist?.completedAt || null;

            return (
              <div
                key={member.userId}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isCompletedToday
                    ? 'bg-[#F7F7FC] border-[#4CAF82]/50'
                    : isCurrentUser
                    ? 'bg-[#FFFFFF] border-[#5B5FEF] ring-1 ring-[#5B5FEF]/40'
                    : 'bg-[#F7F7FC]/60 border-[#E6E6F0]'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  {/* شارة الترتيب بـ SVG */}
                  <div className="shrink-0 pt-0.5">
                    <RankMedalSvg rank={idx + 1} />
                  </div>

                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-cairo font-bold text-sm text-[#25263A]">
                        {member.displayName}
                      </span>
                      {isCurrentUser && (
                        <span className="font-cairo text-[11px] font-bold text-[#5B5FEF]">
                          (أنت)
                        </span>
                      )}
                      {isOwnerMember ? (
                        <span className="font-cairo text-[11px] font-bold text-[#5B5FEF]">
                          • صاحب المجموعة
                        </span>
                      ) : member.role === 'admin' ? (
                        <span className="font-cairo text-[11px] font-bold text-[#E8B84A]">
                          • مشرف
                        </span>
                      ) : null}
                    </div>

                    <div className="flex items-center gap-2 text-xs font-cairo text-[#25263A] flex-wrap">
                      <span className="font-bold text-[#E8B84A]">
                        الجزء {partNumber}
                      </span>
                      <span>•</span>
                      <span>{surahName}</span>
                      <span>•</span>
                      <span className="font-bold">
                        صفحة {pageFrom} إلى {pageTo} ({assignedPagesCount} صفحات)
                      </span>
                    </div>

                    {/* شريط نسبة التقدم + وقت البدء / وقت الإنجاز */}
                    <div className="flex items-center gap-3 flex-wrap pt-0.5">
                      <div className="flex items-center gap-2 min-w-[140px]">
                        <div className="w-24 h-2 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-300"
                            style={{
                              width: `${memberProgressPct}%`,
                              backgroundColor: isCompletedToday
                                ? '#4CAF82'
                                : hasStartedReading
                                ? '#E8B84A'
                                : '#CBD5E1',
                            }}
                          />
                        </div>
                        <span className="font-cairo font-bold text-[11px] text-[#25263A]">
                          {memberProgressPct}%
                        </span>
                      </div>

                      {hasStartedReading && !isCompletedToday && currentPageReached > 0 && (
                        <span className="font-cairo text-[11px] font-bold text-[#5B5FEF]">
                          • وصل إلى ص {currentPageReached} من {pageTo}
                        </span>
                      )}

                      {isCompletedToday && completedAtIso && (
                        <span className="font-cairo text-[11px] text-[#4CAF82] font-bold">
                          • وقت الإنجاز:{' '}
                          {new Date(completedAtIso).toLocaleTimeString('ar-EG', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      )}

                      {!isCompletedToday && startTimeIso && (
                        <span className="font-cairo text-[11px] text-[#77798C]">
                          • وقت البدء:{' '}
                          {new Date(startTimeIso).toLocaleTimeString('ar-EG', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* أزرار القراءة والإنجاز (قفل الورد: العضو يقرأ ورده فقط) + زر إزالة العضو للأدمن */}
                <div className="flex items-center gap-2 shrink-0 flex-wrap">
                  {isCompletedToday ? (
                    <span className="px-3 py-1.5 rounded-xl bg-[#4CAF82]/12 border border-[#4CAF82] text-[#4CAF82] font-cairo font-bold text-xs flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>تم الإنهاء • أتم قراءة الجزء المخصص له</span>
                    </span>
                  ) : hasStartedReading ? (
                    <span className="px-2.5 py-1.5 rounded-xl bg-[#E8B84A]/15 border border-[#E8B84A] text-[#B47D12] font-cairo font-bold text-xs flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{memberStatusLabel}</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-1.5 rounded-xl bg-[#77798C]/12 border border-[#E6E6F0] text-[#77798C] font-cairo font-bold text-xs flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{memberStatusLabel}</span>
                    </span>
                  )}

                  {isCurrentUser ? (
                    <>
                      {/* زر "اقرأ الآن" أو "إعادة قراءة وردك" */}
                      <button
                        type="button"
                        onClick={() =>
                          onOpenMushaf(
                            pageFrom,
                            pageTo,
                            `ورد ${member.displayName} • الجزء ${partNumber}`
                          )
                        }
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white font-cairo font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>
                          {isCompletedToday
                            ? 'إعادة قراءة وردك'
                            : hasStartedReading
                            ? 'متابعة القراءة'
                            : 'اقرأ الآن'}
                        </span>
                      </button>

                      {/* زر "انتهاء القراءة" (يتفعّل فقط بعد القراءة الفعلية) أو زر "الورد التالي" المعطل (#77798C) بعد الإتمام */}
                      {!isCompletedToday ? (
                        <button
                          type="button"
                          aria-disabled={!myCompletionEligibility.allowed}
                          onClick={async () => {
                            if (!myCompletionEligibility.allowed) {
                              showLocalToast(myCompletionEligibility.reason);
                              return;
                            }
                            try {
                              await onCompleteMyWird();
                              setShowTomorrowModal(true);
                            } catch (err: any) {
                              showLocalToast(
                                err?.message ||
                                  'أكمل قراءة الجزء المخصص أولًا قبل الضغط على انتهاء القراءة'
                              );
                            }
                          }}
                          className={`px-3.5 py-2 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all ${
                            myCompletionEligibility.allowed
                              ? 'bg-[#4CAF82] hover:brightness-95 text-white shadow-xs'
                              : 'bg-[#77798C]/20 text-[#77798C] border border-[#77798C]'
                          }`}
                          title={
                            myCompletionEligibility.allowed
                              ? 'اضغط لتسجيل انتهاء القراءة'
                              : myCompletionEligibility.reason
                          }
                        >
                          {myCompletionEligibility.allowed ? (
                            <Check className="w-3.5 h-3.5" />
                          ) : (
                            <Lock className="w-3.5 h-3.5 text-[#77798C]" />
                          )}
                          <span>انتهاء القراءة</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setShowTomorrowModal(true)}
                          aria-disabled="true"
                          className="px-3 py-2 rounded-xl bg-[#77798C]/25 text-[#77798C] border border-[#77798C] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <Lock className="w-3.5 h-3.5 text-[#77798C]" />
                          <span>الورد التالي</span>
                        </button>
                      )}
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        const myRangeText = myTodayDist
                          ? `الصفحات ${myTodayDist.pageFrom} → ${myTodayDist.pageTo}`
                          : 'الورد المخصص لحسابك';
                        showLocalToast(
                          `قفل الورد مفعّل: لا يمكن قراءة ورد العضو «${member.displayName}» — وردك المخصص اليوم هو ${myRangeText}`
                        );
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-[#D95C6A]/10 hover:bg-[#D95C6A]/15 border border-[#D95C6A]/40 text-[#D95C6A] font-cairo text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      title="قفل الورد: كل عضو يقرأ ورده المخصص فقط"
                    >
                      <Lock className="w-3 h-3 text-[#D95C6A]" />
                      <span>مقفل • ورد خاص بالعضو</span>
                    </button>
                  )}

                  {/* زر إزالة عضو (لأدمن المجموعة وصاحبها فقط، ولا يظهر لصاحب المجموعة الأساسي) */}
                  {isAdmin && !isCurrentUser && !isOwnerMember && (
                    <button
                      type="button"
                      onClick={() => setMemberToRemove(member)}
                      className="px-2.5 py-1.5 rounded-xl bg-[#D95C6A]/12 hover:bg-[#D95C6A] text-[#D95C6A] hover:text-white border border-[#D95C6A]/40 font-cairo text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      title="إزالة هذا العضو من المجموعة وإعادة توزيع الأجزاء"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>إزالة عضو</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ■ حائط الرسائل (أدعية وتشجيع) */}
      <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-4">
        <h3 className="font-cairo font-bold text-base text-[#25263A] border-b border-[#F7F7FC] pb-2.5">
          حائط الرسائل (أدعية وتشجيع)
        </h3>

        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!msgText.trim()) return;
            await onSendMessage(msgText, msgCategory);
            setMsgText('');
          }}
          className="space-y-2.5"
        >
          <div className="flex items-center gap-2">
            {(
              [
                { id: 'dua', label: 'دعاء' },
                { id: 'encouragement', label: 'تشجيع' },
                { id: 'general', label: 'رسالة عامة' },
              ] as const
            ).map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setMsgCategory(cat.id)}
                className={`px-3 py-1 rounded-lg font-cairo font-bold text-xs border cursor-pointer ${
                  msgCategory === cat.id
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={msgText}
              onChange={(e) => setMsgText(e.target.value)}
              placeholder="اكتب دعاءً أو رسالة تشجيع لأعضاء المجموعة..."
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-xs sm:text-sm text-[#25263A]"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>إرسال</span>
            </button>
          </div>
        </form>

        {group.messages.length === 0 ? (
          <p className="font-cairo text-xs text-[#77798C] text-center py-4">
            لا توجد رسائل بعد. كن أول من يشارك دعاءً أو تشجيعاً لأهل القرآن.
          </p>
        ) : (
          <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
            {group.messages.map((m) => (
              <div
                key={m.id}
                className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-1"
              >
                <div className="flex items-center justify-between text-[11px] font-cairo">
                  <span className="font-bold text-[#25263A]">
                    {m.userName} •{' '}
                    <span className="text-[#5B5FEF]">
                      {m.category === 'dua'
                        ? 'دعاء'
                        : m.category === 'encouragement'
                        ? 'تشجيع'
                        : 'عام'}
                    </span>
                  </span>
                  <span className="text-[#77798C]">
                    {new Date(m.createdAt).toLocaleTimeString('ar-EG', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="font-cairo text-xs text-[#25263A] leading-relaxed">
                  {m.message}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ■ آخر النشاطات (سجل النشاطات بالوقت) */}
      <div className="bg-[#FFFFFF] rounded-[20px] p-5 border border-[#E6E6F0] shadow-xs space-y-3">
        <h3 className="font-cairo font-bold text-base text-[#25263A] border-b border-[#F7F7FC] pb-2.5">
          آخر النشاطات وسجل المجموعة
        </h3>
        {group.activityLog.length === 0 ? (
          <p className="font-cairo text-xs text-[#77798C] text-center py-3">
            لا توجد نشاطات مسجلة بعد.
          </p>
        ) : (
          <div className="space-y-2 max-h-56 overflow-y-auto">
            { group.activityLog.map((log) => (
              <div
                key={log.id}
                className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-2 text-xs font-cairo"
              >
                <span className="text-[#25263A] font-medium">{log.details}</span>
                <span className="text-[11px] text-[#77798C] shrink-0">
                  {new Date(log.createdAt).toLocaleTimeString('ar-EG', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ■ نافذة دعوة صديق للدخول للمجموعة */}
      {isInviteModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4 animate-fade-in"
          dir="rtl"
        >
          <div className="bg-[#FFFFFF] w-full max-w-md rounded-[20px] border-2 border-[#5B5FEF] p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                  <UserPlus className="w-4 h-4 text-[#4CAF82]" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                    دعوة صديق للدخول للمجموعة
                  </h3>
                  <p className="font-cairo text-xs text-[#77798C]">
                    {group.groupName} • {group.isPublic ? 'مجموعة عامة (انضمام فوري)' : 'مجموعة خاصة (بطلب موافقة)'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsInviteModalOpen(false)}
                className="p-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* كود الدعوة الفريد */}
            <div className="bg-[#F7F7FC] rounded-2xl p-4 border-2 border-[#5B5FEF] text-center space-y-2.5">
              <span className="font-cairo font-bold text-xs text-[#77798C] block">
                كود الدعوة الخاص بالمجموعة
              </span>
              <div
                className="font-cairo font-bold text-2xl sm:text-3xl tracking-[0.25em] text-[#25263A] bg-[#FFFFFF] py-2.5 px-4 rounded-xl border border-[#E6E6F0] select-all"
                dir="ltr"
              >
                {cleanJoinCode}
              </div>
              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopyCodeOnly}
                  className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedCode ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedCode ? 'تم نسخ الكود' : 'نسخ كود الدعوة'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyInviteLink}
                  className="px-4 py-2 rounded-xl bg-[#FFFFFF] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedInviteLink ? (
                    <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                  ) : (
                    <Share2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  )}
                  <span>{copiedInviteLink ? 'تم نسخ الدعوة' : 'نسخ الدعوة والرابط'}</span>
                </button>
              </div>
            </div>

            {/* خيارات المشاركة السريعة مع الأصدقاء */}
            <div className="grid grid-cols-2 gap-2.5">
              <a
                href={whatsAppShareUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  if (Capacitor.isNativePlatform()) {
                    e.preventDefault();
                    void openWirdExternalShareUrl(whatsAppShareUrl);
                  }
                }}
                className="py-2.5 px-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>دعوة عبر واتساب</span>
              </a>

              <a
                href={telegramShareUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  if (Capacitor.isNativePlatform()) {
                    e.preventDefault();
                    void openWirdExternalShareUrl(telegramShareUrl);
                  }
                }}
                className="py-2.5 px-3 rounded-xl bg-[#72B7E8] hover:bg-[#72B7E8] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>دعوة عبر تليجرام</span>
              </a>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleNativeSystemShare}
                className="flex-1 py-2.5 px-3 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-[#5B5FEF]" />
                <span>مشاركة عبر التطبيقات</span>
              </button>

              {onOpenJoinModal && (
                <button
                  type="button"
                  onClick={() => {
                    setIsInviteModalOpen(false);
                    onOpenJoinModal(cleanJoinCode);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>نافذة الانضمام بالكود</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      {/* ■ نافذة تأكيد إزالة عضو من المجموعة (للأدمن فقط) */}
      {memberToRemove && isAdmin && (
        <div
          className="fixed inset-0 z-[75] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          dir="rtl"
        >
          <div className="bg-[#FFFFFF] w-full max-w-md rounded-[20px] border-2 border-[#D95C6A] p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-full bg-[#D95C6A]/12 border border-[#D95C6A] flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5 text-[#D95C6A]" />
                </div>
                <div>
                  <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                    هل تريد إزالة هذا العضو من المجموعة؟
                  </h3>
                  <p className="font-cairo text-xs text-[#77798C]">
                    العضو: {memberToRemove.displayName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={isRemovingMember}
                onClick={() => setMemberToRemove(null)}
                className="p-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] font-cairo text-xs text-[#25263A] space-y-1.5 leading-relaxed">
              <p className="font-bold text-[#D95C6A]">
                عند التأكيد سيتم تنفيذ الإجراءات التالية في Firestore فورًا:
              </p>
              <p>• إزالة العضو «{memberToRemove.displayName}» من عضوية المجموعة نهائيًا.</p>
              <p>• تحديث العدد الفعلي لأعضاء المجموعة وإعادة توزيع الأجزاء بالتساوي على الأعضاء المتبقين.</p>
              <p>• اختفاء المجموعة من قائمة «مجموعاتي» لدى هذا العضو.</p>
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                disabled={isRemovingMember}
                onClick={async () => {
                  if (!memberToRemove || isRemovingMember) return;
                  setIsRemovingMember(true);
                  try {
                    await onRemoveMember(memberToRemove.userId);
                    showLocalToast(
                      `تمت إزالة العضو «${memberToRemove.displayName}» وإعادة توزيع الأجزاء تلقائياً`
                    );
                    setMemberToRemove(null);
                  } catch (err: any) {
                    showLocalToast(
                      err?.message || 'تعذر إزالة العضو، يرجى المحاولة مرة أخرى'
                    );
                  } finally {
                    setIsRemovingMember(false);
                  }
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#D95C6A] hover:brightness-95 disabled:opacity-60 text-white font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <UserX className="w-4 h-4" />
                <span>
                  {isRemovingMember ? 'جاري إزالة العضو...' : 'تأكيد إزالة العضو'}
                </span>
              </button>

              <button
                type="button"
                disabled={isRemovingMember}
                onClick={() => setMemberToRemove(null)}
                className="py-2.5 px-4 rounded-xl bg-[#F7F7FC] hover:bg-[#E6E6F0] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs sm:text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ■ نافذة رسالة "غدًا إن شاء الله" عند الضغط على زر الورد التالي المعطل */}
      <TomorrowWirdDialog
        isOpen={showTomorrowModal}
        surahName={myTodayDist?.surahName || 'القرآن الكريم'}
        partNumber={myTodayDist?.partNumber || 1}
        pageFrom={myTodayDist?.pageFrom || 1}
        pageTo={myTodayDist?.pageTo || 20}
        onCloseDialog={() => setShowTomorrowModal(false)}
        onReturnToGroup={() => setShowTomorrowModal(false)}
        onRestartCurrentWird={() => {
          setShowTomorrowModal(false);
          if (myTodayDist) {
            onOpenMushaf(
              myTodayDist.pageFrom,
              myTodayDist.pageTo,
              `ورد ${myMember?.displayName || ''} • الجزء ${myTodayDist.partNumber}`
            );
          }
        }}
        onListenRecitation={() => {
          setShowTomorrowModal(false);
          if (myTodayDist) {
            onOpenMushaf(
              myTodayDist.pageFrom,
              myTodayDist.pageTo,
              `ورد ${myMember?.displayName || ''} • الجزء ${myTodayDist.partNumber}`
            );
          }
        }}
      />
    </div>
  );
};
