import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowRight,
  ChevronRight,
  ChevronLeft,
  Check,
  ZoomIn,
  ZoomOut,
  Lock,
  Loader2,
  AlertTriangle,
  EyeOff,
  Eye,
  Volume2,
  Pause,
  RotateCcw,
  Home,
  BookOpen,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import {
  fetchAndSyncMushafPage,
  CachedMushafPageData,
  getJuzForPage,
  getSurahNameForPage,
  getUserWird,
  startMemberWirdReadingSession,
  updateMemberReadingPage,
} from '../../utils/wirdService';
import { WirdMushafPenSvg, CrescentMoonWirdSvg } from './WirdIcons';

export interface WirdMushafReaderProps {
  groupId?: string;
  userId?: string;
  currentDay?: number;
  initialPage: number;
  targetEndPage: number;
  partNumber?: number;
  surahName?: string;
  isCompleted?: boolean;
  title?: string;
  onClose: () => void;
  onCompleteWird: () => void | Promise<void>;
}

/**
 * Reusable "غدًا إن شاء الله" Dialog matching the exact RIFQ design specification
 */
export const TomorrowWirdDialog: React.FC<{
  isOpen: boolean;
  surahName: string;
  partNumber: number;
  pageFrom: number;
  pageTo: number;
  onCloseDialog: () => void;
  onReturnToGroup: () => void;
  onRestartCurrentWird?: () => void;
  onListenRecitation?: () => void;
}> = ({
  isOpen,
  surahName,
  partNumber,
  pageFrom,
  pageTo,
  onCloseDialog,
  onReturnToGroup,
  onRestartCurrentWird,
  onListenRecitation,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[70] bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
      dir="rtl"
    >
      <div
        className="w-full max-w-md bg-[#F7F7FC] rounded-[20px] border-2 border-[#5B5FEF] p-6 shadow-2xl text-center space-y-4"
        role="dialog"
        aria-modal="true"
        aria-labelledby="tomorrow-wird-title"
      >
        {/* أيقونة قمر (SVG) 64px */}
        <div className="flex justify-center">
          <CrescentMoonWirdSvg size={64} />
        </div>

        {/* العنوان: Cairo Bold 24px ذهبي #72B7E8 */}
        <h2
          id="tomorrow-wird-title"
          className="font-cairo font-bold text-[24px] text-[#5B5FEF] leading-tight"
        >
          غدًا إن شاء الله
        </h2>

        {/* النص الفرعي: Cairo 16px بني #25263A */}
        <p className="font-cairo font-semibold text-[16px] text-[#25263A]">
          لقد أتممت وردك اليوم
        </p>

        {/* تفاصيل "وردك الحالي": Cairo Bold 14px بني #25263A */}
        <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] space-y-1">
          <p className="font-cairo font-bold text-[14px] text-[#25263A] leading-[1.8]">
            وردك الحالي:
          </p>
          <p className="font-cairo font-bold text-[15px] text-[#5B5FEF] leading-[1.8]">
            {surahName}
          </p>
          <p className="font-cairo font-bold text-[14px] text-[#25263A] leading-[1.8]">
            الجزء {partNumber} • الصفحات {pageFrom} → {pageTo}
          </p>
        </div>

        {/* قائمة ما يمكن للعضو فعله */}
        <div className="bg-[#FFFFFF] rounded-2xl p-3.5 border border-[#E6E6F0] text-right space-y-2">
          <p className="font-cairo font-bold text-xs text-[#25263A] mb-1">
            يمكنك:
          </p>

          <button
            type="button"
            onClick={() => {
              if (onRestartCurrentWird) {
                onRestartCurrentWird();
              } else {
                onCloseDialog();
              }
            }}
            className="w-full flex items-center justify-between p-2 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 border border-[#4CAF82]/30 text-[#4CAF82] font-cairo font-bold text-xs transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
              <span>إعادة قراءة وردك</span>
            </span>
            <span className="text-[11px] underline">ابدأ من ص {pageFrom}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onListenRecitation) {
                onListenRecitation();
              } else {
                onCloseDialog();
              }
            }}
            className="w-full flex items-center justify-between p-2 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 border border-[#4CAF82]/30 text-[#4CAF82] font-cairo font-bold text-xs transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
              <span>الاستماع للتلاوة</span>
            </span>
            <span className="text-[11px] underline">تشغيل التلاوة</span>
          </button>

          <div className="flex items-center gap-2 p-2 rounded-xl bg-[#D95C6A]/10 border border-[#D95C6A]/30 text-[#D95C6A] font-cairo font-bold text-xs">
            <XCircle className="w-4 h-4 text-[#D95C6A] shrink-0" />
            <span>تجاوز النطاق المخصص (الصفحات {pageFrom} → {pageTo})</span>
          </div>
        </div>

        {/* زر "العودة للمجموعة": ذهبي متدرج */}
        <div className="pt-1 space-y-2">
          <button
            type="button"
            onClick={onReturnToGroup}
            className="w-full py-3 px-6 rounded-[20px] bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] hover:brightness-105 text-[#FFFFFF] font-cairo font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>العودة للمجموعة</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export const WirdMushafReader: React.FC<WirdMushafReaderProps> = ({
  groupId,
  userId,
  currentDay,
  initialPage,
  targetEndPage,
  partNumber: propPartNumber,
  surahName: propSurahName,
  isCompleted: propIsCompleted = false,
  title,
  onClose,
  onCompleteWird,
}) => {
  const fallbackStart = Math.max(1, Math.min(604, initialPage));
  const fallbackEnd = Math.max(fallbackStart, Math.min(604, targetEndPage));

  // 【1】نطاق الورد المخصص من Firestore مباشرة
  const [wirdPageFrom, setWirdPageFrom] = useState<number>(fallbackStart);
  const [wirdPageTo, setWirdPageTo] = useState<number>(fallbackEnd);
  const [wirdPartNumber, setWirdPartNumber] = useState<number>(
    propPartNumber || getJuzForPage(fallbackStart)
  );
  const [wirdSurahName, setWirdSurahName] = useState<string>(
    propSurahName || getSurahNameForPage(fallbackStart)
  );
  const [isWirdCompleted, setIsWirdCompleted] = useState<boolean>(propIsCompleted);
  const [verifyingFirestoreWird, setVerifyingFirestoreWird] = useState<boolean>(
    Boolean(groupId && userId)
  );

  // الصفحة الحالية محصورة إجبارياً داخل [wirdPageFrom, wirdPageTo]
  const [currentPage, setCurrentPage] = useState<number>(fallbackStart);
  const [highestPageReached, setHighestPageReached] = useState<number>(fallbackStart);
  const [sessionStarted, setSessionStarted] = useState<boolean>(false);
  const [pageData, setPageData] = useState<CachedMushafPageData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState<number>(28);

  // حالات قفل الورد والرسائل التفاعلية
  const [lockWarning, setLockWarning] = useState<string | null>(null);
  const [startBoundaryModalPage, setStartBoundaryModalPage] = useState<number | null>(null);
  const [showTomorrowDialog, setShowTomorrowDialog] = useState<boolean>(false);

  // حالات التلاوة الصوتية لصفحة الورد الحالية
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [playingAyahIndex, setPlayingAyahIndex] = useState<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // حالات «وضع التسميع» التدريجي
  const [recitationHideLevel, setRecitationHideLevel] = useState<0 | 25 | 50 | 75 | 100>(0);
  const [recitationMaskStyle, setRecitationMaskStyle] = useState<'blur' | 'hidden'>('blur');
  const [revealedAyahKeys, setRevealedAyahKeys] = useState<Set<string>>(new Set());

  // دعم السحب باللمس (Swipe) مع تطبيق القفل الحقيقي
  const touchStartXRef = useRef<number | null>(null);

  // 【1】عند فتح صفحة المصحف: التحقق من Firestore مباشرة عبر getUserWird وتسجيل بدء جلسة قراءة حقيقية
  useEffect(() => {
    let isMounted = true;
    if (!groupId || !userId) {
      setVerifyingFirestoreWird(false);
      setSessionStarted(true);
      return;
    }

    setVerifyingFirestoreWird(true);
    void startMemberWirdReadingSession(groupId, userId).then(() => {
      if (isMounted) {
        setSessionStarted(true);
      }
    });

    getUserWird(groupId, userId, currentDay)
      .then((firestoreWird) => {
        if (!isMounted) return;
        if (firestoreWird) {
          const verifiedFrom = Math.max(1, Math.min(604, firestoreWird.pageFrom));
          const verifiedTo = Math.max(verifiedFrom, Math.min(604, firestoreWird.pageTo));
          setWirdPageFrom(verifiedFrom);
          setWirdPageTo(verifiedTo);
          setWirdPartNumber(firestoreWird.partNumber || getJuzForPage(verifiedFrom));
          setWirdSurahName(firestoreWird.surahName || getSurahNameForPage(verifiedFrom));
          setIsWirdCompleted(Boolean(firestoreWird.isCompleted));
          const initialHighest = Math.max(
            verifiedFrom,
            Number(firestoreWird.highestPageReached) || 0,
            Number(firestoreWird.currentPage) || 0
          );
          setHighestPageReached(Math.min(verifiedTo, initialHighest));
          // إجبار الصفحة الحالية على البقاء داخل النطاق المخصص للعضو في Firestore
          const resumePage = firestoreWird.currentPage
            ? Math.max(verifiedFrom, Math.min(verifiedTo, firestoreWird.currentPage))
            : verifiedFrom;
          setCurrentPage(resumePage);
        }
      })
      .finally(() => {
        if (isMounted) {
          setVerifyingFirestoreWird(false);
          setSessionStarted(true);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [groupId, userId, currentDay]);

  // إيقاف الصوت عند إغلاق المصحف أو تغيير الصفحة
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [currentPage]);

  // تحميل بيانات الصفحة الحالية (فقط إذا كانت داخل النطاق المخصص [wirdPageFrom, wirdPageTo])
  useEffect(() => {
    let isMounted = true;
    const clampedPage = Math.max(wirdPageFrom, Math.min(wirdPageTo, currentPage));
    if (clampedPage !== currentPage) {
      setCurrentPage(clampedPage);
      return;
    }

    setLoading(true);
    setError(null);

    fetchAndSyncMushafPage(clampedPage)
      .then((data) => {
        if (isMounted) {
          setPageData(data);
          setLoading(false);
          setHighestPageReached((prev) => Math.max(prev, clampedPage));
          if (groupId && userId) {
            updateMemberReadingPage(groupId, userId, clampedPage);
          }
        }
      })
      .catch(() => {
        if (isMounted) {
          setError('تعذّر تحميل صفحة المصحف الشريف، يرجى التحقق من الاتصال بالإنترنت');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [currentPage, wirdPageFrom, wirdPageTo, groupId, userId]);

  const triggerLockWarning = (msg: string) => {
    setLockWarning(msg);
    setTimeout(() => setLockWarning(null), 3500);
  };

  /**
   * 【2】&【3】التحقق الصارم عند أي محاولة لتغيير الصفحة (أزرار / تمرير / لوحة مفاتيح)
   */
  const handleAttemptPageChange = (targetPage: number) => {
    // 【2】عند محاولة التمرير للخلف قبل بداية الورد
    if (targetPage < wirdPageFrom) {
      setCurrentPage(wirdPageFrom);
      triggerLockWarning(`وردك يبدأ من الصفحة ${wirdPageFrom}`);
      setStartBoundaryModalPage(wirdPageFrom);
      return;
    }

    // 【3】عند محاولة التمرير للأمام بعد نهاية الورد
    if (targetPage > wirdPageTo) {
      setCurrentPage(wirdPageTo);
      setShowTomorrowDialog(true);
      return;
    }

    // داخل النطاق المخصص -> مسموح
    setCurrentPage(targetPage);
  };

  const handlePrevPage = () => {
    handleAttemptPageChange(currentPage - 1);
  };

  const handleNextPage = () => {
    handleAttemptPageChange(currentPage + 1);
  };

  // تشغيل التلاوة الصوتية لآيات الصفحة الحالية
  const playAyahAtIndex = (idx: number) => {
    const ayahs = pageData?.ayahs || [];
    if (ayahs.length === 0) return;

    const safeIdx = idx >= 0 && idx < ayahs.length ? idx : 0;
    const targetAyah = ayahs[safeIdx];
    const globalNumber = targetAyah?.number || 1;
    const url = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalNumber}.mp3`;

    if (!audioRef.current) {
      audioRef.current = new Audio(url);
    } else {
      audioRef.current.pause();
      audioRef.current.src = url;
    }

    setPlayingAyahIndex(safeIdx);

    audioRef.current.onended = () => {
      if (safeIdx + 1 < ayahs.length) {
        playAyahAtIndex(safeIdx + 1);
      } else {
        setIsPlayingAudio(false);
        setPlayingAyahIndex(0);
      }
    };

    audioRef.current.onerror = () => {
      setIsPlayingAudio(false);
      triggerLockWarning('تعذّر تشغيل التلاوة الصوتية، يرجى التحقق من الاتصال بالإنترنت');
    };

    audioRef.current
      .play()
      .then(() => {
        setIsPlayingAudio(true);
      })
      .catch(() => {
        setIsPlayingAudio(false);
      });
  };

  const handleToggleAudioRecitation = () => {
    if (isPlayingAudio && audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
      return;
    }
    playAyahAtIndex(playingAyahIndex);
  };

  const toggleRevealKey = (key: string) => {
    setRevealedAyahKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  // معالجة السحب باللمس (Swipe) لمنع التجاوز وإظهار الرسالة المناسبة
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0]?.clientX ?? null;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const endX = e.changedTouches[0]?.clientX ?? touchStartXRef.current;
    const deltaX = endX - touchStartXRef.current;
    touchStartXRef.current = null;

    if (Math.abs(deltaX) < 45) return;
    // في المصحف العربي (RTL): السحب لليمين (deltaX > 0) ينقل للصفحة التالية، والسحب لليسار ينقل للسابقة
    if (deltaX > 45) {
      handleNextPage();
    } else if (deltaX < -45) {
      handlePrevPage();
    }
  };

  // حسابات النطاق وشريط التقدم الذهبي
  const totalWirdPages = Math.max(1, wirdPageTo - wirdPageFrom + 1);
  const effectiveReachedPage = Math.max(currentPage, highestPageReached);
  const currentWirdPageIndex = Math.max(1, effectiveReachedPage - wirdPageFrom + 1);
  const progressPercentage = Math.min(
    100,
    Math.max(0, Math.round((currentWirdPageIndex / totalWirdPages) * 100))
  );

  const isAtFirstPage = currentPage <= wirdPageFrom;
  const isAtLastPage = currentPage >= wirdPageTo;
  const canFinishWird =
    sessionStarted && !loading && effectiveReachedPage >= wirdPageTo;

  const currentJuz = pageData?.juzNumber || wirdPartNumber || getJuzForPage(currentPage);
  const surahHeaderName = pageData?.surahName || wirdSurahName || 'القرآن الكريم';

  // قائمة أرقام الصفحات المسموحة فقط داخل نطاق الورد
  const allowedPagesList = useMemo(() => {
    const pages: number[] = [];
    for (let p = wirdPageFrom; p <= wirdPageTo; p++) {
      pages.push(p);
    }
    return pages;
  }, [wirdPageFrom, wirdPageTo]);

  const handleFinishWirdReading = async () => {
    if (!canFinishWird) {
      triggerLockWarning(
        `أكمل قراءة الجزء المخصص أولًا (الوصول إلى صفحة ${wirdPageTo} من ${wirdPageTo}) قبل الضغط على انتهاء القراءة`
      );
      return;
    }
    try {
      await onCompleteWird();
      setIsWirdCompleted(true);
      setShowTomorrowDialog(true);
    } catch (err: any) {
      triggerLockWarning(
        err?.message || 'أكمل قراءة الجزء المخصص أولًا قبل الضغط على انتهاء القراءة'
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-fade-in"
      dir="rtl"
    >
      <div className="bg-[#F7F7FC] w-full max-w-2xl rounded-[20px] border-2 border-[#5B5FEF] shadow-2xl overflow-hidden flex flex-col max-h-[95vh]">
        {/* ── 【الشريط العلوي】اسم السورة + "وردك: الصفحات X → Y" + رقم الصفحة الحالية: "12 من 20" ── */}
        <div className="bg-[#FFFFFF] px-4 py-3 flex items-center justify-between border-b border-[#E6E6F0] gap-2 flex-wrap">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
              <span>رجوع</span>
            </button>

            <div className="w-9 h-9 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
              <WirdMushafPenSvg size={22} />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
                  {surahHeaderName}
                </h3>
                <span className="px-2 py-0.5 rounded-lg bg-[#F7F7FC] border border-[#E6E6F0] font-cairo font-bold text-[11px] text-[#5B5FEF]">
                  {currentPage} من {wirdPageTo}
                </span>
              </div>
              <p className="font-cairo font-bold text-xs text-[#77798C]">
                وردك: الصفحات {wirdPageFrom} → {wirdPageTo}
                {title ? ` • ${title}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* زر الاستماع للتلاوة الصوتية */}
            <button
              type="button"
              onClick={handleToggleAudioRecitation}
              disabled={loading || Boolean(error)}
              className={`px-2.5 py-1.5 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 border transition-colors cursor-pointer ${
                isPlayingAudio
                  ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                  : 'bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border-[#E6E6F0]'
              }`}
              title="الاستماع لتلاوة الصفحة الحالية"
            >
              {isPlayingAudio ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">إيقاف التلاوة</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span className="hidden sm:inline">الاستماع للتلاوة</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setFontSize((f) => Math.min(38, f + 2))}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              title="تكبير الخط"
              aria-label="تكبير الخط"
            >
              <ZoomIn className="w-4 h-4 text-[#5B5FEF]" />
            </button>
            <button
              type="button"
              onClick={() => setFontSize((f) => Math.max(20, f - 2))}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              title="تصغير الخط"
              aria-label="تصغير الخط"
            >
              <ZoomOut className="w-4 h-4 text-[#5B5FEF]" />
            </button>
          </div>
        </div>

        {/* ── 【عرض النطاق】بطاقة "📖 وردك اليوم" + شريط التقدم الذهبي + أرقام الصفحات ── */}
        <div className="bg-[#F7F7FC] px-4 py-3 border-b border-[#E6E6F0] space-y-2.5">
          <div className="bg-[#FFFFFF] rounded-2xl p-3.5 border border-[#E6E6F0] shadow-2xs space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#5B5FEF]" />
                <span className="font-cairo font-bold text-xs sm:text-sm text-[#25263A]">
                  وردك اليوم
                </span>
                {verifyingFirestoreWird && (
                  <span className="text-[10px] font-cairo text-[#5B5FEF] flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" />
                    متحقق من Firestore
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-0.5 rounded-lg font-cairo font-bold text-[11px] flex items-center gap-1 border ${
                    isWirdCompleted
                      ? 'bg-[#4CAF82]/12 text-[#4CAF82] border-[#4CAF82]/40'
                      : 'bg-[#D95C6A]/10 text-[#D95C6A] border-[#D95C6A]/30'
                  }`}
                >
                  <Lock className="w-3 h-3" />
                  <span>
                    {isWirdCompleted ? 'تم إتمام الورد اليومي' : 'قفل النطاق مفعّل'}
                  </span>
                </span>

                <button
                  type="button"
                  onClick={() => {
                    const next = recitationHideLevel === 0 ? 50 : 0;
                    setRecitationHideLevel(next);
                    setRevealedAyahKeys(new Set());
                  }}
                  className={`px-2.5 py-0.5 rounded-lg font-cairo font-bold text-[11px] flex items-center gap-1 border transition-all cursor-pointer ${
                    recitationHideLevel > 0
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:bg-[#F7F7FC]'
                  }`}
                >
                  {recitationHideLevel > 0 ? (
                    <Eye className="w-3 h-3" />
                  ) : (
                    <EyeOff className="w-3 h-3 text-[#5B5FEF]" />
                  )}
                  <span>
                    {recitationHideLevel > 0
                      ? `تسميع (${recitationHideLevel}%)`
                      : 'وضع التسميع'}
                  </span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between flex-wrap gap-2 text-xs font-cairo">
              <div className="font-bold text-[#25263A]">
                <span>{surahHeaderName}</span>
                <span className="mx-1.5 text-[#5B5FEF]">•</span>
                <span>
                  الصفحات: {wirdPageFrom} → {wirdPageTo} ({totalWirdPages} صفحة)
                </span>
              </div>
              <span className="font-bold text-[#25263A]">
                الصفحة {currentPage} من {wirdPageTo}
              </span>
            </div>

            {/* شريط تقدم ذهبي */}
            <div className="flex items-center gap-2.5">
              <div className="flex-1 h-2.5 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-l from-[#72B7E8] via-[#E8B84A] to-[#4CAF82] transition-all duration-300"
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
              <span className="font-cairo font-bold text-xs text-[#5B5FEF] min-w-[36px] text-left">
                {progressPercentage}%
              </span>
            </div>

            {/* أرقام الصفحات داخل النطاق المخصص فقط */}
            {allowedPagesList.length > 1 && allowedPagesList.length <= 30 && (
              <div className="flex items-center gap-1 overflow-x-auto pt-1 pb-0.5">
                {allowedPagesList.map((pageNum) => {
                  const isCurrent = pageNum === currentPage;
                  const isRead = pageNum < currentPage || isWirdCompleted;
                  return (
                    <button
                      key={pageNum}
                      type="button"
                      onClick={() => handleAttemptPageChange(pageNum)}
                      className={`min-w-[28px] h-7 px-1.5 rounded-lg font-cairo font-bold text-[11px] border transition-all cursor-pointer shrink-0 ${
                        isCurrent
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-2xs scale-105'
                          : isRead
                          ? 'bg-[#4CAF82]/12 text-[#4CAF82] border-[#4CAF82]/40'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                      }`}
                      title={`الانتقال إلى صفحة ${pageNum}`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {recitationHideLevel > 0 && (
            <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-[11px] font-cairo font-bold">
              <div className="flex items-center gap-1">
                {([25, 50, 75, 100] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => {
                      setRecitationHideLevel(lvl);
                      setRevealedAyahKeys(new Set());
                    }}
                    className={`px-2.5 py-1 rounded-lg border cursor-pointer transition-all ${
                      recitationHideLevel === lvl
                        ? 'bg-[#25263A] text-white border-[#25263A]'
                        : 'bg-white text-[#25263A] border-[#E6E6F0]'
                    }`}
                  >
                    إخفاء {lvl}%
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    setRecitationMaskStyle((s) => (s === 'blur' ? 'hidden' : 'blur'))
                  }
                  className="px-2.5 py-1 rounded-lg bg-white border border-[#E6E6F0] text-[#25263A] cursor-pointer"
                >
                  النمط: {recitationMaskStyle === 'blur' ? 'نص مموه' : 'نص مخفي'}
                </button>
                {revealedAyahKeys.size > 0 && (
                  <button
                    type="button"
                    onClick={() => setRevealedAyahKeys(new Set())}
                    className="px-2.5 py-1 rounded-lg bg-[#5B5FEF] text-white cursor-pointer"
                  >
                    إعادة الإخفاء
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* رسالة تحذير قفل الورد عند محاولة التجاوز للخلف */}
        {lockWarning && (
          <div className="mx-4 mt-2.5 p-3 rounded-xl bg-[#D95C6A]/10 border border-[#D95C6A] text-[#D95C6A] font-cairo font-bold text-xs flex items-center justify-between gap-2 animate-fade-in">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-[#D95C6A] shrink-0" />
              <span>{lockWarning}</span>
            </div>
            <button
              type="button"
              onClick={() => setLockWarning(null)}
              className="text-[11px] underline cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}

        {/* ── 【منطقة المصحف】عرض الصفحات داخل النطاق فقط + منع التمرير خارج النطاق ── */}
        <div
          className="flex-1 overflow-y-auto p-3 sm:p-5 bg-[#F7F7FC]"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          <div className="bg-[#F7F7FC] border-2 border-[#5B5FEF] rounded-2xl p-1.5 shadow-inner min-h-[340px] flex flex-col">
            <div className="border border-[#5B5FEF]/70 rounded-xl p-4 sm:p-6 flex-1 flex flex-col justify-between">
              {/* اسم السورة والجزء */}
              <div className="py-2 px-4 mb-4 rounded-xl bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-between">
                <span className="font-cairo font-bold text-xs text-[#25263A]">
                  الجزء {currentJuz}
                </span>
                <h4
                  className="font-amiri font-bold text-[24px] text-[#5B5FEF] leading-normal"
                  style={{ fontFamily: 'Amiri, serif' }}
                >
                  {surahHeaderName}
                </h4>
                <span className="font-cairo font-bold text-xs text-[#5B5FEF]">
                  ص {currentPage}
                </span>
              </div>

              {loading ? (
                <div className="flex-1 flex flex-col items-center justify-center py-16 text-[#25263A] gap-3">
                  <Loader2 className="w-8 h-8 animate-spin text-[#5B5FEF]" />
                  <p className="font-cairo font-bold text-sm">
                    جاري تحميل صفحة المصحف ({currentPage}) ضمن وردك المخصص...
                  </p>
                </div>
              ) : error ? (
                <div className="flex-1 flex flex-col items-center justify-center py-12 text-center gap-3">
                  <p className="font-cairo font-bold text-sm text-[#D95C6A]">{error}</p>
                  <button
                    type="button"
                    onClick={() => setCurrentPage((p) => p)}
                    className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer"
                  >
                    إعادة المحاولة
                  </button>
                </div>
              ) : (
                <div
                  className="text-justify leading-[2.3] text-[#25263A] font-amiri select-text"
                  style={{ fontSize: `${fontSize}px`, fontFamily: 'Amiri, serif' }}
                >
                  {(pageData?.ayahs || []).map((ayah, idx) => {
                    const prevSurahNumber =
                      idx > 0 ? pageData?.ayahs?.[idx - 1]?.surah?.number : undefined;
                    const currentSurahNumber = ayah?.surah?.number;
                    const showSurahBanner =
                      idx > 0 &&
                      prevSurahNumber !== undefined &&
                      currentSurahNumber !== undefined &&
                      prevSurahNumber !== currentSurahNumber;
                    const safeAyahNumber = ayah?.number ?? ayah?.numberInSurah ?? idx + 1;
                    const safeNumberInSurah = ayah?.numberInSurah ?? ayah?.number ?? idx + 1;
                    const isAyahCurrentlyPlaying =
                      isPlayingAudio && playingAyahIndex === idx;

                    return (
                      <React.Fragment key={`${safeAyahNumber}-${idx}`}>
                        {showSurahBanner && (
                          <div className="my-4 py-2 px-4 rounded-xl bg-[#F7F7FC] border border-[#5B5FEF] text-center">
                            <span
                              className="text-[24px] font-bold text-[#5B5FEF] font-amiri"
                              style={{ fontFamily: 'Amiri, serif' }}
                            >
                              {ayah?.surah?.name || surahHeaderName}
                            </span>
                          </div>
                        )}
                        {(() => {
                          const ayahKey = `ayah-${safeAyahNumber}-${idx}`;
                          const words = (ayah?.text || '').trim().split(/\s+/).filter(Boolean);
                          const isAyahRevealed = revealedAyahKeys.has(ayahKey);

                          if (recitationHideLevel === 0) {
                            return (
                              <span
                                className={`rounded-lg transition-colors ${
                                  isAyahCurrentlyPlaying
                                    ? 'bg-[#EEEEFF] px-1 py-0.5'
                                    : ''
                                }`}
                              >
                                {ayah?.text || ''}{' '}
                                <button
                                  type="button"
                                  onClick={() => playAyahAtIndex(idx)}
                                  title="استمع لهذه الآية"
                                  className="inline-flex items-center justify-center mx-1 w-7 h-7 rounded-full bg-[#F7F7FC] hover:bg-[#4145C7] hover:text-white border border-[#5B5FEF] text-[#5B5FEF] font-cairo text-xs font-bold align-middle transition-colors cursor-pointer"
                                >
                                  {safeNumberInSurah}
                                </button>{' '}
                              </span>
                            );
                          }

                          return (
                            <span className="inline">
                              {words.map((word, wIdx) => {
                                const wordKey = `${ayahKey}-${wIdx}`;
                                const shouldHide =
                                  recitationHideLevel === 100
                                    ? true
                                    : recitationHideLevel === 25
                                    ? (wIdx + idx) % 4 === 1
                                    : recitationHideLevel === 50
                                    ? wIdx >= Math.ceil(words.length * 0.4)
                                    : wIdx >= 1;
                                const isRevealed =
                                  isAyahRevealed || revealedAyahKeys.has(wordKey);

                                if (!shouldHide) {
                                  return (
                                    <span key={wordKey} className="inline-block mx-1">
                                      {word}
                                    </span>
                                  );
                                }

                                if (isRevealed) {
                                  return (
                                    <button
                                      key={wordKey}
                                      type="button"
                                      onClick={() => toggleRevealKey(wordKey)}
                                      className="inline-block mx-1 px-1.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/35 cursor-pointer"
                                    >
                                      {word}
                                    </button>
                                  );
                                }

                                if (recitationMaskStyle === 'blur') {
                                  return (
                                    <button
                                      key={wordKey}
                                      type="button"
                                      onClick={() => toggleRevealKey(wordKey)}
                                      className="inline-block mx-1 px-1.5 rounded-lg bg-[#F7F7FC] border border-dashed border-[#E6E6F0] cursor-pointer align-middle"
                                      title="اضغط لإظهار الكلمة"
                                    >
                                      <span
                                        className="inline-block select-none pointer-events-none"
                                        style={{
                                          filter: 'blur(6px)',
                                          WebkitFilter: 'blur(6px)',
                                          opacity: 0.75,
                                        }}
                                      >
                                        {word}
                                      </span>
                                    </button>
                                  );
                                }

                                return (
                                  <button
                                    key={wordKey}
                                    type="button"
                                    onClick={() => toggleRevealKey(wordKey)}
                                    className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#EEEEFF] border border-dashed border-[#5B5FEF] text-[#4145C7] font-cairo text-xs font-bold cursor-pointer align-middle"
                                    title="اضغط لإظهار الكلمة"
                                  >
                                    ••••
                                  </button>
                                );
                              })}{' '}
                              <button
                                type="button"
                                onClick={() => toggleRevealKey(ayahKey)}
                                className={`inline-flex items-center justify-center mx-1 w-7 h-7 rounded-full border font-cairo text-xs font-bold align-middle cursor-pointer ${
                                  isAyahRevealed
                                    ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                                    : 'bg-[#F7F7FC] border-[#5B5FEF] text-[#5B5FEF]'
                                }`}
                                title="اضغط لإظهار/إخفاء الآية كاملة"
                              >
                                {safeNumberInSurah}
                              </button>{' '}
                            </span>
                          );
                        })()}
                      </React.Fragment>
                    );
                  })}
                </div>
              )}

              {/* رقم الصفحة داخل نطاق الورد */}
              <div className="mt-6 pt-3 border-t border-[#E6E6F0] flex items-center justify-between text-xs font-cairo font-bold text-[#77798C]">
                <span>بداية وردك: ص {wirdPageFrom}</span>
                <span className="text-[14px] text-[#25263A]">
                  الصفحة {currentPage} من {wirdPageTo}
                </span>
                <span>نهاية وردك: ص {wirdPageTo}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── 【الشريط السفلي】زر "الصفحة السابقة" + رقم الصفحة + زر "الصفحة التالية" + حالة إتمام الورد ── */}
        <div className="p-3.5 sm:p-4 bg-[#FFFFFF] border-t border-[#E6E6F0] space-y-3">
          <div className="flex items-center justify-between gap-2">
            {/* ■ زر "الصفحة السابقة": نشط إذا الصفحة > pageFrom، معطل (#77798C) إذا الصفحة = pageFrom، وعند الضغط على المعطل تظهر رسالة */}
            <button
              type="button"
              onClick={handlePrevPage}
              aria-disabled={isAtFirstPage}
              className={`px-3.5 sm:px-4 py-2.5 rounded-xl border font-cairo font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                isAtFirstPage
                  ? 'bg-[#77798C]/20 text-[#77798C] border-[#77798C]'
                  : 'bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border-[#5B5FEF]'
              }`}
            >
              <ChevronRight
                className={`w-4 h-4 ${
                  isAtFirstPage ? 'text-[#77798C]' : 'text-[#5B5FEF]'
                }`}
              />
              <span>الصفحة السابقة</span>
              {isAtFirstPage && <Lock className="w-3.5 h-3.5 text-[#77798C]" />}
            </button>

            <div className="text-center">
              <span className="font-cairo text-xs sm:text-sm font-bold text-[#25263A] block">
                الصفحة {currentPage} من {wirdPageTo}
              </span>
              <span className="font-cairo text-[11px] text-[#77798C]">
                (الصفحات {wirdPageFrom} → {wirdPageTo})
              </span>
            </div>

            {/* ■ زر "الصفحة التالية": نشط إذا الصفحة < pageTo، معطل (#77798C) إذا الصفحة = pageTo، وعند الضغط على المعطل تظهر رسالة "غدًا إن شاء الله" */}
            <button
              type="button"
              onClick={handleNextPage}
              aria-disabled={isAtLastPage}
              className={`px-3.5 sm:px-4 py-2.5 rounded-xl border font-cairo font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                isAtLastPage
                  ? 'bg-[#77798C]/20 text-[#77798C] border-[#77798C]'
                  : 'bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] border-[#5B5FEF]'
              }`}
            >
              {isAtLastPage && <Lock className="w-3.5 h-3.5 text-[#77798C]" />}
              <span>الصفحة التالية</span>
              <ChevronLeft
                className={`w-4 h-4 ${
                  isAtLastPage ? 'text-[#77798C]' : 'text-[#5B5FEF]'
                }`}
              />
            </button>
          </div>

          {/* 【4】بعد إتمام الورد كاملًا: زر "الورد التالي" معطل (رمادي #77798C) وعند الضغط → رسالة "غدًا إن شاء الله" */}
          {isWirdCompleted ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setCurrentPage(wirdPageFrom);
                  triggerLockWarning(`بدأت إعادة قراءة وردك الحالي من الصفحة ${wirdPageFrom}`);
                }}
                className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#5B5FEF] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-[#5B5FEF]" />
                <span>إعادة قراءة وردك</span>
              </button>

              <button
                type="button"
                onClick={handleToggleAudioRecitation}
                className="py-2.5 px-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isPlayingAudio ? (
                  <>
                    <Pause className="w-4 h-4" />
                    <span>إيقاف التلاوة</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    <span>الاستماع للتلاوة</span>
                  </>
                )}
              </button>

              {/* زر "الورد التالي" معطل باللون الرمادي #77798C وعند الضغط يظهر رسالة "غدًا إن شاء الله" */}
              <button
                type="button"
                onClick={() => setShowTomorrowDialog(true)}
                aria-disabled="true"
                className="py-2.5 px-3 rounded-xl bg-[#77798C]/25 text-[#77798C] border border-[#77798C] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-4 h-4 text-[#77798C]" />
                <span>الورد التالي (غدًا إن شاء الله)</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleFinishWirdReading}
                aria-disabled={!canFinishWird}
                className={`flex-1 h-[46px] rounded-xl font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  canFinishWird
                    ? 'bg-[#4CAF82] hover:brightness-95 text-white shadow-md active:scale-[0.99]'
                    : 'bg-[#77798C]/20 text-[#77798C] border border-[#77798C]'
                }`}
              >
                {canFinishWird ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>إنهاء القراءة وتسجيل إتمام الورد</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-[#77798C]" />
                    <span>
                      إنهاء القراءة (يتفعّل عند الوصول لصفحة {wirdPageTo})
                    </span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setShowTomorrowDialog(true)}
                aria-disabled="true"
                className="h-[46px] px-3.5 rounded-xl bg-[#77798C]/25 text-[#77798C] border border-[#77798C] font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                title="الورد التالي مقفل حتى الغد"
              >
                <Lock className="w-4 h-4 text-[#77798C]" />
                <span>الورد التالي</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ── 【2】نافذة تنبيه بداية الورد عند محاولة الرجوع قبل pageFrom ── */}
      {startBoundaryModalPage !== null && (
        <div
          className="fixed inset-0 z-[65] bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          dir="rtl"
        >
          <div className="w-full max-w-sm bg-[#F7F7FC] rounded-[20px] border-2 border-[#5B5FEF] p-6 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#D95C6A]/10 border-2 border-[#D95C6A] flex items-center justify-center">
              <Lock className="w-7 h-7 text-[#D95C6A]" />
            </div>

            <h3 className="font-cairo font-bold text-xl text-[#25263A]">
              بداية الورد المخصص
            </h3>

            <p className="font-cairo font-bold text-base text-[#D95C6A]">
              وردك يبدأ من الصفحة {startBoundaryModalPage}
            </p>

            <p className="font-cairo text-xs text-[#25263A] leading-relaxed">
              لا يمكنك الرجوع لصفحات خارج نطاق وردك المخصص لهذا اليوم ({surahHeaderName} • الصفحات{' '}
              {wirdPageFrom} → {wirdPageTo}).
            </p>

            <button
              type="button"
              onClick={() => setStartBoundaryModalPage(null)}
              className="w-full py-2.5 px-6 rounded-[20px] bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-sm shadow-md cursor-pointer"
            >
              حسنًا، متابعة القراءة
            </button>
          </div>
        </div>
      )}

      {/* ── 【3】&【4】نافذة رسالة "غدًا إن شاء الله" عند محاولة تجاوز نهاية الورد ── */}
      <TomorrowWirdDialog
        isOpen={showTomorrowDialog}
        surahName={surahHeaderName}
        partNumber={currentJuz}
        pageFrom={wirdPageFrom}
        pageTo={wirdPageTo}
        onCloseDialog={() => setShowTomorrowDialog(false)}
        onReturnToGroup={() => {
          setShowTomorrowDialog(false);
          onClose();
        }}
        onRestartCurrentWird={() => {
          setShowTomorrowDialog(false);
          setCurrentPage(wirdPageFrom);
          triggerLockWarning(`تمت العودة لبداية وردك الحالي (صفحة ${wirdPageFrom})`);
        }}
        onListenRecitation={() => {
          setShowTomorrowDialog(false);
          if (!isPlayingAudio) {
            playAyahAtIndex(0);
          }
        }}
      />
    </div>
  );
};
