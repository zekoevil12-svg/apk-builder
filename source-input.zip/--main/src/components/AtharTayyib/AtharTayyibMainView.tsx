import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowRight,
  Plus,
  Search,
  Sparkles,
  Heart,
  BookOpen,
  Bell,
  Shield,
  UserPlus,
} from 'lucide-react';
import {
  DeceasedRecord,
  loadAtharTayyibRecords,
  saveDeceasedRecord,
  deleteDeceasedRecord,
  recordPrayerForDeceased,
  syncAtharTayyibRemindersWithSystem,
} from '../../utils/atharTayyibStorage';
import { DeceasedCard } from './DeceasedCard';
import { DeceasedDetailsView } from './DeceasedDetailsView';
import { AddEditDeceasedModal } from './AddEditDeceasedModal';

export interface AtharTayyibMainViewProps {
  onBackToHome: () => void;
  initialDeceasedId?: string | null;
}

export const AtharTayyibMainView: React.FC<AtharTayyibMainViewProps> = ({
  onBackToHome,
  initialDeceasedId,
}) => {
  const [records, setRecords] = useState<DeceasedRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<DeceasedRecord | null>(null);
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<DeceasedRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load records from local storage on mount
  useEffect(() => {
    const list = loadAtharTayyibRecords();
    setRecords(list);

    if (initialDeceasedId) {
      const found = list.find((r) => r.id === initialDeceasedId);
      if (found) {
        setSelectedRecord(found);
      }
    }
  }, [initialDeceasedId]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSaveRecord = (record: DeceasedRecord) => {
    saveDeceasedRecord(record);
    const updated = loadAtharTayyibRecords();
    setRecords(updated);

    // If currently viewing this record, update it
    if (selectedRecord && selectedRecord.id === record.id) {
      setSelectedRecord(record);
    }

    showToast(editingRecord ? 'تم حفظ التعديلات بنجاح 🤍' : 'تمت إضافة السجل بنجاح 🕊️');
    setEditingRecord(null);
  };

  const handleDeleteRecord = (id: string) => {
    deleteDeceasedRecord(id);
    const updated = loadAtharTayyibRecords();
    setRecords(updated);
    if (selectedRecord && selectedRecord.id === id) {
      setSelectedRecord(null);
    }
    showToast('تم حذف السجل بنجاح.');
  };

  const handleQuickPray = (recordId: string) => {
    const updated = recordPrayerForDeceased(recordId);
    if (updated) {
      setRecords((prev) => prev.map((r) => (r.id === recordId ? updated : r)));
      if (selectedRecord && selectedRecord.id === recordId) {
        setSelectedRecord(updated);
      }
    }
  };

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setIsAddEditModalOpen(true);
  };

  const handleOpenEdit = (rec: DeceasedRecord) => {
    setEditingRecord(rec);
    setIsAddEditModalOpen(true);
  };

  // Filter records based on user search
  const filteredRecords = useMemo(() => {
    if (!searchQuery.trim()) return records;
    const q = searchQuery.toLowerCase();
    return records.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        (r.relationship && r.relationship.toLowerCase().includes(q)) ||
        (r.shortBio && r.shortBio.toLowerCase().includes(q))
    );
  }, [records, searchQuery]);

  // Total prayers recorded across all deceased
  const totalPrayersCount = useMemo(() => {
    return records.reduce((sum, r) => sum + (r.prayerCount || 0), 0);
  }, [records]);

  // If a deceased person is selected, display their full details page
  if (selectedRecord) {
    return (
      <div className="min-h-screen bg-[#F7F7FC] dark:bg-[#121324] text-[#25263A] dark:text-[#F3F4F6] transition-colors duration-250">
        <DeceasedDetailsView
          record={selectedRecord}
          onBack={() => setSelectedRecord(null)}
          onPray={handleQuickPray}
          onEdit={handleOpenEdit}
          onDelete={handleDeleteRecord}
        />

        {/* Modal for Editing while in details */}
        <AddEditDeceasedModal
          isOpen={isAddEditModalOpen}
          onClose={() => {
            setIsAddEditModalOpen(false);
            setEditingRecord(null);
          }}
          onSave={handleSaveRecord}
          initialRecord={editingRecord}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F7FC] dark:bg-[#121324] text-[#25263A] dark:text-[#F3F4F6] pb-24 transition-colors duration-250" dir="rtl">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] dark:bg-[#1E1F35] text-white px-4 py-2 rounded-full text-xs font-bold shadow-xl border border-[#E8B84A]/40 flex items-center gap-2 animate-fade-in">
          <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="w-full max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-6">
        {/* Top Header Navigation */}
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onBackToHome}
            className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#25263A] dark:text-[#F3F4F6] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-[#F7F7FC] transition-colors cursor-pointer text-xs font-bold shadow-xs"
          >
            <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
            <span>الرئيسية</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة متوفى 🕊️</span>
          </button>
        </div>

        {/* Hero Section */}
        <div className="relative bg-gradient-to-b from-[#FFFEFC] via-[#FFFFFF] to-[#FAF8FF] dark:from-[#1E1F35] dark:via-[#202138] dark:to-[#171829] rounded-[32px] p-6 sm:p-8 border border-[#E8B84A]/30 dark:border-[#2D2E4A] shadow-[0_8px_30px_rgba(37,38,58,0.03)] overflow-hidden">
          {/* Subtle Ambient Glowing Gradients */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-radial from-[#E8B84A]/12 via-[#B98CC8]/5 to-transparent pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-radial from-[#9FA4FF]/10 to-transparent pointer-events-none" />

          <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center sm:text-right flex-1">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-[#FFF9E6] dark:bg-[#332A15] text-[#8C6D1F] dark:text-[#FDD835] border border-[#E8B84A]/30">
                <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
                <span>قسم «أثر طيّب» للمتوفين</span>
              </div>

              <h1 className="font-cairo font-black text-2xl sm:text-3xl text-[#25263A] dark:text-[#F3F4F6]">
                أثر طيّب
              </h1>

              <p className="text-xs sm:text-sm text-[#56586E] dark:text-[#C2C3D6] max-w-lg leading-relaxed">
                "نذكرهم بالدعاء، ونحفظ أثرهم في قلوبنا."
              </p>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-2 text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
                <span className="flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-[#E8B84A]" />
                  <span>{records.length} {records.length === 1 ? 'شخص محفوظ' : 'أشخاص محفوظين'}</span>
                </span>
                {totalPrayersCount > 0 && (
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
                    <span>{totalPrayersCount} دعاء مسجل</span>
                  </span>
                )}
                <span className="flex items-center gap-1 text-[11px] text-[#4CAF82]">
                  <Shield className="w-3 h-3" />
                  <span>خصوصية تامة ومحفوظة على جهازك فقط</span>
                </span>
              </div>
            </div>

            {/* Quick Add Button on Desktop */}
            <div className="shrink-0 hidden sm:block">
              <button
                type="button"
                onClick={handleOpenAdd}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] via-[#6B6FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer flex items-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>إضافة من تحب للدعاء له</span>
              </button>
            </div>
          </div>
        </div>

        {/* Search Bar (When records exist) */}
        {records.length > 0 && (
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="البحث بالاسم أو صلة القرابة..."
              className="w-full px-4 py-3 pr-11 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors shadow-xs"
            />
            <Search className="w-4 h-4 text-[#77798C] absolute right-4 top-3.5 pointer-events-none" />
          </div>
        )}

        {/* Deceased Grid or Empty State */}
        {filteredRecords.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredRecords.map((record) => (
              <DeceasedCard
                key={record.id}
                record={record}
                onOpenDetails={setSelectedRecord}
                onQuickPray={handleQuickPray}
              />
            ))}
          </div>
        ) : records.length > 0 ? (
          /* Search returned no results */
          <div className="text-center py-12 bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl border border-[#E6E6F0] dark:border-[#2D2E4A] p-6 space-y-3">
            <Search className="w-8 h-8 text-[#77798C] mx-auto" />
            <p className="text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
              لا توجد نتائج مطابقة لـ "{searchQuery}"
            </p>
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-xs text-[#5B5FEF] font-black underline cursor-pointer"
            >
              عرض جميع السجلات
            </button>
          </div>
        ) : (
          /* Empty State (Zero records, completely authentic - no fake data!) */
          <div className="text-center py-12 sm:py-16 bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl border border-[#E6E6F0] dark:border-[#2D2E4A] p-6 sm:p-10 space-y-5 shadow-xs">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-[#FFF9E6] to-[#FFEBB3] dark:from-[#352D16] dark:to-[#453616] border border-[#E8B84A]/40 flex items-center justify-center text-[#E8B84A] mx-auto shadow-sm">
              <Heart className="w-8 h-8 text-[#D4A836]" />
            </div>

            <div className="max-w-md mx-auto space-y-2">
              <h2 className="font-cairo font-black text-lg sm:text-xl text-[#25263A] dark:text-[#F3F4F6]">
                لم تقم بإضافة أي متوفى بعد
              </h2>
              <p className="text-xs sm:text-sm text-[#77798C] dark:text-[#9E9FB5] leading-relaxed">
                أضف من تحب من الوالدين أو الأقارب أو الأصدقاء الذين انتقلوا إلى رحمة الله، لتتذكرهم بالدعاء المأثور، وتحفظ أثرهم الطيب في قلبك، وتضبط تذكيراً دورياً بالدعاء لهم.
              </p>
            </div>

            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer inline-flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة متوفى جديد 🕊️</span>
            </button>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      <AddEditDeceasedModal
        isOpen={isAddEditModalOpen}
        onClose={() => {
          setIsAddEditModalOpen(false);
          setEditingRecord(null);
        }}
        onSave={handleSaveRecord}
        initialRecord={editingRecord}
      />
    </div>
  );
};
