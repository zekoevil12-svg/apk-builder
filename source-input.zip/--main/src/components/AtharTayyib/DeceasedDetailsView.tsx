import React, { useState } from 'react';
import {
  ArrowRight,
  Heart,
  Sparkles,
  Share2,
  Copy,
  Check,
  Clock,
  BookOpen,
  Bell,
  Edit3,
  Trash2,
  AlertTriangle,
  User,
  Quote,
} from 'lucide-react';
import {
  DeceasedRecord,
  AUTHENTIC_DECEASED_SUPPLICATIONS,
  getAtharTayyibDuaText,
  AuthenticSupplication,
} from '../../utils/atharTayyibStorage';
import { MemorialPhotoFrame } from './MemorialPhotoFrame';

export interface DeceasedDetailsViewProps {
  record: DeceasedRecord;
  onBack: () => void;
  onPray: (recordId: string) => void;
  onEdit: (record: DeceasedRecord) => void;
  onDelete: (recordId: string) => void;
}

export const DeceasedDetailsView: React.FC<DeceasedDetailsViewProps> = ({
  record,
  onBack,
  onPray,
  onEdit,
  onDelete,
}) => {
  const isFemale = record.gender === 'female';
  const pron = isFemale ? 'لها' : 'له';
  const pronCap = isFemale ? 'ارحمها واغفر لها' : 'ارحمه واغفر له';

  const [copiedDuaId, setCopiedDuaId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [justPrayed, setJustPrayed] = useState(false);

  // Copy supplication text
  const handleCopyDua = async (dua: AuthenticSupplication) => {
    const text = getAtharTayyibDuaText(dua, record.gender);
    const fullText = `${text}\n\n[${dua.source}${dua.referenceAyah ? ` — الآية ${dua.referenceAyah}` : ''}]`;
    try {
      await navigator.clipboard.writeText(fullText);
      setCopiedDuaId(dua.id);
      setTimeout(() => setCopiedDuaId(null), 2000);
    } catch {
      // Fallback
    }
  };

  // Share supplication text
  const handleShareDua = async (dua: AuthenticSupplication) => {
    const text = getAtharTayyibDuaText(dua, record.gender);
    const fullText = `دعاء للمتوفى: ${record.name}\n\n${text}\n\nالمصدر: ${dua.source}\n\nمن تطبيق رِفْق | RIFQ`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `دعاء لـ ${record.name}`,
          text: fullText,
        });
      } catch {
        // User cancelled share
      }
    } else {
      handleCopyDua(dua);
    }
  };

  const handlePrayClick = () => {
    onPray(record.id);
    setJustPrayed(true);
    setTimeout(() => setJustPrayed(false), 2500);
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-6 pb-24" dir="rtl">
      {/* Top Navigation & Actions Bar */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#25263A] dark:text-[#F3F4F6] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-[#F7F7FC] transition-colors cursor-pointer text-xs font-bold shadow-xs"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span>العودة لقائمة أثر طيّب</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onEdit(record)}
            className="p-2 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#5B5FEF] dark:text-[#9FA4FF] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-[#EEEEFF] transition-colors cursor-pointer shadow-xs"
            title="تعديل البيانات"
            aria-label="تعديل البيانات"
          >
            <Edit3 className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => setShowDeleteModal(true)}
            className="p-2 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] text-red-500 hover:text-red-700 border border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors cursor-pointer shadow-xs"
            title="حذف السجل"
            aria-label="حذف السجل"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hero Memorial Card */}
      <div className="relative bg-gradient-to-b from-[#FFFFFF] via-[#FFFEFA] to-[#F9F7FC] dark:from-[#1E1F35] dark:via-[#202138] dark:to-[#171829] rounded-[36px] p-6 sm:p-8 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-[0_8px_30px_rgba(37,38,58,0.04)] text-center overflow-hidden">
        {/* Soft Background Rays */}
        <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-[#E8B84A]/10 via-[#B98CC8]/5 to-transparent pointer-events-none" />

        {/* Big Glowing Memorial Photo Frame */}
        <div className="relative flex justify-center mb-5">
          <MemorialPhotoFrame
            photoUrl={record.photoDataUrl}
            name={record.name}
            size="xl"
            shape="circle"
            showGlow={true}
          />
        </div>

        {/* Deceased Name */}
        <h1 className="font-cairo font-black text-2xl sm:text-3xl text-[#25263A] dark:text-[#F3F4F6] mb-2 leading-tight">
          {record.name}
        </h1>

        {/* Metadata Pills (Only what user entered!) */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-4">
          {record.relationship && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-[#EEEEFF] dark:bg-[#282946] text-[#5B5FEF] dark:text-[#9FA4FF] border border-[#5B5FEF]/20">
              <User className="w-3.5 h-3.5 ml-1 text-[#5B5FEF]" />
              {record.relationship}
            </span>
          )}

          {record.deathDate && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-[#FFF9E6] dark:bg-[#352D16] text-[#8C6D1F] dark:text-[#FDD835] border border-[#E8B84A]/30">
              <Clock className="w-3.5 h-3.5 ml-1 text-[#E8B84A]" />
              تاريخ الوفاة: {record.deathDate}
            </span>
          )}

          {record.reminder?.enabled && record.reminder?.time && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] border border-[#A5D6A7]/40">
              <Bell className="w-3.5 h-3.5 ml-1 text-[#4CAF82]" />
              تذكير بالدعاء: {record.reminder.time}
            </span>
          )}
        </div>

        {/* Short Bio (Only if entered!) */}
        {record.shortBio && (
          <p className="max-w-xl mx-auto text-sm text-[#56586E] dark:text-[#C2C3D6] leading-relaxed mb-6 bg-[#F7F7FC]/80 dark:bg-[#25263A]/40 p-4 rounded-2xl border border-[#E6E6F0]/60 dark:border-[#2D2E4A]/60">
            {record.shortBio}
          </p>
        )}

        {/* Primary Interaction: "دعوت له 🤍" */}
        <div className="max-w-md mx-auto pt-2">
          <button
            type="button"
            onClick={handlePrayClick}
            className={`w-full py-3.5 px-6 rounded-3xl text-sm font-black transition-all active:scale-98 cursor-pointer flex items-center justify-center gap-2 shadow-md ${
              justPrayed
                ? 'bg-[#2E7D32] text-white shadow-[#2E7D32]/30 scale-102'
                : 'bg-gradient-to-r from-[#5B5FEF] via-[#6B6FEF] to-[#4145C7] hover:brightness-105 text-white shadow-[#5B5FEF]/25'
            }`}
          >
            <Heart className={`w-5 h-5 ${justPrayed ? 'fill-current animate-ping' : 'fill-white'}`} />
            <span>
              {justPrayed
                ? `تقبل الله دعاءك ${pron} 🤍`
                : `دعوت ${pron} 🤍`}
            </span>
          </button>

          {/* Genuine Prayer Count */}
          <div className="mt-3 flex items-center justify-center gap-2 text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
            <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
            <span>
              {record.prayerCount > 0
                ? `سجلت الدعاء ${pron} ${record.prayerCount} ${
                    record.prayerCount === 1
                      ? 'مرة'
                      : record.prayerCount === 2
                      ? 'مرتين'
                      : 'مرات'
                  }`
                : `اضغط لتسجيل دعائك في ميزان حسناته`}
            </span>
          </div>
        </div>
      </div>

      {/* Section: "أثر طيّب" (User-entered Memories & Good Deeds only) */}
      {(record.memories || record.notes) && (
        <div className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-6 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-4">
          <div className="flex items-center gap-2.5 pb-2 border-b border-[#E6E6F0] dark:border-[#2D2E4A]">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#FFF9E6] to-[#FFEBB3] dark:from-[#352D16] dark:to-[#453616] flex items-center justify-center text-[#E8B84A]">
              <Quote className="w-4 h-4 text-[#D4A836]" />
            </div>
            <h2 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
              أثر طيّب • مواقف وذكريات
            </h2>
          </div>

          {record.memories && (
            <div className="space-y-1">
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] font-bold">
                من الأثر الجميل الذي تركه:
              </p>
              <p className="text-xs sm:text-sm text-[#25263A] dark:text-[#E2E3F0] leading-relaxed whitespace-pre-wrap bg-[#FFFDF5] dark:bg-[#25263A]/40 p-4 rounded-2xl border border-[#E8B84A]/25">
                {record.memories}
              </p>
            </div>
          )}

          {record.notes && (
            <div className="space-y-1 pt-1">
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] font-bold">
                ملاحظات خاصة:
              </p>
              <p className="text-xs text-[#56586E] dark:text-[#C2C3D6] leading-relaxed bg-[#F7F7FC] dark:bg-[#25263A]/30 p-3 rounded-2xl border border-[#E6E6F0]/60">
                {record.notes}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Section: "اللهم ارحمه واغفر له" (Authentic Supplications from Quran & Sunnah) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#EEEEFF] to-[#E2E2FF] dark:from-[#2B2D54] dark:to-[#383A6B] flex items-center justify-center text-[#5B5FEF]">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-base sm:text-lg text-[#25263A] dark:text-[#F3F4F6]">
                اللهم {pronCap}
              </h2>
              <p className="text-[11px] text-[#77798C] dark:text-[#9E9FB5]">
                أدعية صحيحة مأثورة من القرآن الكريم والسنة النبوية المطهرة
              </p>
            </div>
          </div>
        </div>

        {/* Supplication Cards Grid */}
        <div className="grid grid-cols-1 gap-3.5">
          {AUTHENTIC_DECEASED_SUPPLICATIONS.map((dua) => {
            const duaText = getAtharTayyibDuaText(dua, record.gender);
            const isCopied = copiedDuaId === dua.id;

            return (
              <div
                key={dua.id}
                className="bg-gradient-to-br from-[#FFFEFC] to-[#FAF8FF] dark:from-[#1E1F35] dark:to-[#22233D] rounded-3xl p-4 sm:p-5 border border-[#E8B84A]/30 dark:border-[#2D2E4A] shadow-xs hover:border-[#E8B84A]/60 transition-all space-y-3"
              >
                {/* Category & Source Header */}
                <div className="flex items-center justify-between text-xs">
                  <span className="inline-flex items-center gap-1 font-bold text-[#8C6D1F] dark:text-[#FDD835]">
                    <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
                    <span>{dua.category === 'quran' ? 'دعاء قرآني مبارك' : 'من السنة النبوية الصحيحة'}</span>
                  </span>
                  <span className="text-[11px] text-[#77798C] dark:text-[#9E9FB5] font-medium">
                    {dua.source}
                  </span>
                </div>

                {/* Du'a Text with clean Arabic styling */}
                <p className="font-cairo font-black text-sm sm:text-base text-[#25263A] dark:text-[#F3F4F6] leading-loose text-center sm:text-right py-1">
                  {duaText}
                </p>

                {/* Hadith / Verse Citation & Explanation */}
                {dua.explanation && (
                  <p className="text-[11px] text-[#77798C] dark:text-[#9E9FB5] leading-relaxed bg-[#F7F7FC]/80 dark:bg-[#25263A]/40 p-2.5 rounded-xl border border-[#E6E6F0]/60">
                    {dua.explanation}
                  </p>
                )}

                {/* Action Buttons: Copy & Share */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E6E6F0]/70 dark:border-[#2D2E4A]/70">
                  <button
                    type="button"
                    onClick={() => handleCopyDua(dua)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] dark:hover:bg-[#2F304B] text-[#5B5FEF] dark:text-[#9FA4FF] text-xs font-bold transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                    title="نسخ نص الدعاء"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                        <span className="text-[#4CAF82]">تم النسخ</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleShareDua(dua)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#FFF9E6] to-[#FFEBB3] dark:from-[#352D16] dark:to-[#453616] text-[#8C6D1F] dark:text-[#FDD835] text-xs font-bold transition-all cursor-pointer border border-[#E8B84A]/30 hover:brightness-95"
                    title="مشاركة نص الدعاء"
                  >
                    <Share2 className="w-3.5 h-3.5 text-[#E8B84A]" />
                    <span>مشاركة الدعاء</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-6 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-2xl space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                هل تريد حذف هذا السجل؟
              </h3>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] mt-1 leading-relaxed">
                سيتم حذف سجل {record.name} وجميع الذكريات والدعوات المرتبطة به من هذا الجهاز.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] text-xs font-bold cursor-pointer"
              >
                تراجع
              </button>
              <button
                type="button"
                onClick={() => {
                  onDelete(record.id);
                  setShowDeleteModal(false);
                }}
                className="flex-1 py-2.5 rounded-2xl bg-red-600 text-white text-xs font-black hover:bg-red-700 transition-colors cursor-pointer"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
