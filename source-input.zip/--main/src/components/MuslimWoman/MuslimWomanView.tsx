import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  ShieldCheck, 
  Trash2, 
  Plus, 
  Calendar, 
  Heart, 
  Bell, 
  Sparkles, 
  Baby, 
  Droplet, 
  Moon, 
  BookOpen, 
  Lock
} from 'lucide-react';
import { 
  WomanProfileState, 
  INITIAL_WOMAN_STATE, 
  loadWomanState, 
  saveWomanState, 
  wipeAllWomanData,
  CycleRecord,
  PregnancyData,
  FeedingRecord,
  ChildRecord,
  WomanReminder,
  DiaryEntry,
  DailyHabitRecord
} from './womanTypes';
import { CycleTrackerView } from './CycleTrackerView';
import { PregnancyView } from './PregnancyView';
import { BreastfeedingView } from './BreastfeedingView';
import { ChildrenView } from './ChildrenView';
import { ChildPlantView } from './ChildPlantView';
import { SproutHeaderSvg } from './ChildPlantSvg';
import { PregnancyJourneyHeaderSvg } from './PregnancySvg';
import { RemindersView } from './RemindersView';
import { DiaryView } from './DiaryView';
import { SelfCareView } from './SelfCareView';
import { WomanCalendarView } from './WomanCalendarView';
import { FiqhView } from './FiqhView';
import { MuslimWomanSectionSvg } from '../Home/RifqSectionIcons';

interface MuslimWomanViewProps {
  onBack: () => void;
}

type ActiveTab = 
  | 'dashboard'
  | 'child_plant'
  | 'cycle'
  | 'pregnancy'
  | 'fiqh'
  | 'calendar'
  | 'breastfeeding'
  | 'children'
  | 'reminders'
  | 'diary'
  | 'selfcare'
  | 'privacy';

export const MuslimWomanView: React.FC<MuslimWomanViewProps> = ({ onBack }) => {
  const [state, setState] = useState<WomanProfileState>(() => loadWomanState());
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);

  // حفظ تلقائي محلي دائم عند أي تغيير
  useEffect(() => {
    saveWomanState(state);
  }, [state]);

  // فحص هل سُجلت أي بيانات سابقة
  const isCompletelyEmpty = 
    state.cycles.length === 0 &&
    !state.pregnancy.hasActivePregnancy &&
    state.feedings.length === 0 &&
    state.children.length === 0 &&
    state.reminders.length === 0 &&
    state.diary.length === 0 &&
    Object.keys(state.selfCare).length === 0;

  // الإجراءات البرمجية الحقيقية
  const handleAddCycle = (cycleData: Omit<CycleRecord, 'id'>) => {
    const newCycle: CycleRecord = {
      ...cycleData,
      id: Date.now().toString()
    };
    setState(prev => ({
      ...prev,
      cycles: [newCycle, ...prev.cycles]
    }));
  };

  const handleDeleteCycle = (id: string) => {
    setState(prev => ({
      ...prev,
      cycles: prev.cycles.filter(c => c.id !== id)
    }));
  };

  const handleUpdatePregnancy = (pregData: PregnancyData) => {
    setState(prev => ({
      ...prev,
      pregnancy: pregData
    }));
  };

  const handleAddFeeding = (feedingData: Omit<FeedingRecord, 'id'>) => {
    const newFeeding: FeedingRecord = {
      ...feedingData,
      id: Date.now().toString()
    };
    setState(prev => ({
      ...prev,
      feedings: [newFeeding, ...prev.feedings]
    }));
  };

  const handleDeleteFeeding = (id: string) => {
    setState(prev => ({
      ...prev,
      feedings: prev.feedings.filter(f => f.id !== id)
    }));
  };

  const handleAddChild = (childData: Omit<ChildRecord, 'id'>) => {
    const newChild: ChildRecord = {
      ...childData,
      id: Date.now().toString()
    };
    setState(prev => ({
      ...prev,
      children: [...prev.children, newChild]
    }));
  };

  const handleDeleteChild = (id: string) => {
    setState(prev => ({
      ...prev,
      children: prev.children.filter(c => c.id !== id)
    }));
  };

  const handleAddReminder = (reminderData: Omit<WomanReminder, 'id'>) => {
    const newReminder: WomanReminder = {
      ...reminderData,
      id: Date.now().toString()
    };
    setState(prev => ({
      ...prev,
      reminders: [...prev.reminders, newReminder]
    }));
  };

  const handleToggleReminder = (id: string) => {
    setState(prev => ({
      ...prev,
      reminders: prev.reminders.map(r => r.id === id ? { ...r, isActive: !r.isActive } : r)
    }));
  };

  const handleDeleteReminder = (id: string) => {
    setState(prev => ({
      ...prev,
      reminders: prev.reminders.filter(r => r.id !== id)
    }));
  };

  const handleAddDiaryEntry = (entryData: Omit<DiaryEntry, 'id' | 'createdAt'>) => {
    const newEntry: DiaryEntry = {
      ...entryData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setState(prev => ({
      ...prev,
      diary: [newEntry, ...prev.diary]
    }));
  };

  const handleDeleteDiaryEntry = (id: string) => {
    setState(prev => ({
      ...prev,
      diary: prev.diary.filter(d => d.id !== id)
    }));
  };

  const handleUpdateSecurity = (pin: string | null, enabled: boolean) => {
    setState(prev => ({
      ...prev,
      pinCode: pin,
      isPinEnabled: enabled
    }));
  };

  const handleUpdateTodayCare = (record: DailyHabitRecord) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    setState(prev => ({
      ...prev,
      selfCare: {
        ...prev.selfCare,
        [todayStr]: record
      }
    }));
  };

  const handleAddCustomHabit = (name: string) => {
    if (state.customHabits.includes(name)) return;
    setState(prev => ({
      ...prev,
      customHabits: [...prev.customHabits, name]
    }));
  };

  const handleDeleteCustomHabit = (name: string) => {
    setState(prev => ({
      ...prev,
      customHabits: prev.customHabits.filter(h => h !== name)
    }));
  };

  const handleWipeAll = () => {
    wipeAllWomanData();
    setState(INITIAL_WOMAN_STATE);
    setShowWipeConfirm(false);
    setActiveTab('dashboard');
  };

  // عناصر شريط التنقل
  const NAV_ITEMS: { id: ActiveTab; label: string; icon: string; badge?: string }[] = [
    { id: 'dashboard', label: 'حالتي اليوم', icon: '🌸' },
    { id: 'child_plant', label: 'نبتة طفلي', icon: 'svg_sprout' },
    { id: 'cycle', label: 'الدورة', icon: '🩸', badge: state.cycles.length > 0 ? `${state.cycles.length}` : undefined },
    { id: 'pregnancy', label: 'الحمل — رحلتك', icon: 'svg_pregnancy' },
    { id: 'fiqh', label: 'فقه المرأة', icon: '🌙' },
    { id: 'calendar', label: 'التقويم', icon: '📅' },
    { id: 'breastfeeding', label: 'الرضاعة', icon: '🍼', badge: state.feedings.length > 0 ? `${state.feedings.length}` : undefined },
    { id: 'children', label: 'الأطفال', icon: '👶', badge: state.children.length > 0 ? `${state.children.length}` : undefined },
    { id: 'reminders', label: 'التذكيرات', icon: '🔔', badge: state.reminders.filter(r => r.isActive).length > 0 ? `${state.reminders.filter(r => r.isActive).length}` : undefined },
    { id: 'diary', label: 'مذكراتي', icon: '💗', badge: state.diary.length > 0 ? `${state.diary.length}` : undefined },
    { id: 'selfcare', label: 'العناية', icon: '🌿' },
    { id: 'privacy', label: 'الخصوصية', icon: '🔐' },
  ];

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-16 font-cairo">
      {/* ── الترويسة الرئيسية ── */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#E6E6F0] shadow-2xs">
        <div className="max-w-4xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="w-10 h-10 rounded-xl bg-[#F7F7FC] hover:bg-stone-200 flex items-center justify-center text-[#25263A] transition-colors cursor-pointer"
              title="العودة للرئيسية"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <MuslimWomanSectionSvg size={30} />
                <h1 className="text-lg font-black text-[#25263A] font-tajawal">رِفْق للمرأة</h1>
              </div>
              <p className="text-[11px] text-[#77798C]">تنظيم يومكِ، عبادتكِ، وصحتكِ بخصوصية تامة على جهازكِ</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('privacy')}
            className="flex items-center gap-1.5 text-xs text-[#77798C] hover:text-[#4145C7] bg-[#EEEEFF] px-3 py-1.5 rounded-xl border border-[#E6E6F0] transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-[#4CAF82]" />
            <span className="hidden sm:inline">حفظ محلي 100%</span>
          </button>
        </div>

        {/* شريط الأدوات والتنقل الأفقي */}
        <div className="max-w-4xl mx-auto px-2 overflow-x-auto no-scrollbar border-t border-[#E6E6F0] bg-white">
          <div className="flex items-center gap-1.5 py-2 px-2 min-w-max">
            {NAV_ITEMS.map(item => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer select-none ${
                    isActive
                      ? 'bg-[#5B5FEF] text-white shadow-xs'
                      : 'bg-stone-50 hover:bg-[#F7F7FC] text-stone-700 border border-[#E6E6F0]/70'
                  }`}
                >
                  {item.icon === 'svg_sprout' ? (
                    <SproutHeaderSvg size={16} />
                  ) : item.icon === 'svg_pregnancy' ? (
                    <PregnancyJourneyHeaderSvg size={16} />
                  ) : (
                    <span className="text-sm">{item.icon}</span>
                  )}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-white text-[#5B5FEF]' : 'bg-[#5B5FEF] text-white'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* ── المحتوى الفعلي حسب التبويب النشط ── */}
      <main className="max-w-4xl mx-auto px-4 pt-6">
        {/* 1. لوحة حالتي اليوم (Dashboard) */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fade-in">
            {/* الحالة الفارغة الابتدائية الترحيبية إذا لم تسجل المستخدمة أي بيانات */}
            {isCompletelyEmpty ? (
              <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-5 shadow-xs">
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-pink-100 to-amber-100 border-2 border-[#E6E6F0] flex items-center justify-center text-4xl shadow-xs">
                  🌸
                </div>
                <div className="space-y-2 max-w-md mx-auto">
                  <h3 className="text-xl font-black text-[#25263A] font-tajawal">
                    أهلاً بكِ في مساحتكِ الخاصة 🤍
                  </h3>
                  <p className="text-xs text-[#77798C] leading-relaxed">
                    هذا القسم مصمم خصيصاً لكِ ليكون رفيقكِ في العبادة والصحة وتنظيم الأسرة. لا يحتوي على أي بيانات وهمية أو افتراضية؛ سيمتلئ تدريجياً بما تسجلينه أنتِ فقط ويُحفظ بأمان على هاتفكِ.
                  </p>
                </div>

                <div className="pt-2 flex flex-wrap gap-2.5 justify-center max-w-lg mx-auto">
                  <button
                    type="button"
                    onClick={() => setActiveTab('cycle')}
                    className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <span>🩸 تسجيل الدورة الشهرية</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('pregnancy')}
                    className="flex items-center gap-1.5 bg-[#EEEEFF] hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <span>🤰 حاسبة ومتابعة الحمل</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('fiqh')}
                    className="flex items-center gap-1.5 bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <span>🌙 تصفح فقه المرأة</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('diary')}
                    className="flex items-center gap-1.5 bg-pink-50 hover:bg-pink-100 text-pink-800 border border-pink-200 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    <span>💗 كتابة أول خاطرة</span>
                  </button>
                </div>
              </div>
            ) : (
              /* بطاقة كبيرة «حالتي اليوم» تعرض بيانات حقيقية مسجلة فقط */
              <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0]">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-100 to-amber-100 border border-[#E6E6F0] flex items-center justify-center text-2xl shadow-2xs">
                      🌸
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-[#25263A] font-tajawal">
                        حالتي اليوم
                      </h3>
                      <span className="text-[11px] text-[#77798C]">
                        ملخص ما قمتِ بتسجيله فعلياً في مساحتكِ
                      </span>
                    </div>
                  </div>

                  <span className="text-xs bg-[#F7F7FC] text-[#25263A] font-bold px-3 py-1 rounded-xl border border-[#E6E6F0]">
                    {new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'short' })}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  {/* حالة الدورة إن سُجلت */}
                  {state.cycles.length > 0 && (
                    <div
                      onClick={() => setActiveTab('cycle')}
                      className="p-3.5 rounded-2xl bg-rose-50/50 border border-rose-200 flex items-center justify-between cursor-pointer hover:border-rose-400 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">🩸</span>
                        <div>
                          <h4 className="font-bold text-rose-900">متابعة الدورة</h4>
                          <p className="text-[11px] text-[#77798C]">آخر تسجيل: {state.cycles[0].startDate}</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-rose-700 bg-white px-2 py-1 rounded-lg border border-rose-200">
                        {state.cycles.length} دورات مسجلة
                      </span>
                    </div>
                  )}

                  {/* حالة الحمل إن كان نشطاً */}
                  {state.pregnancy.hasActivePregnancy && state.pregnancy.lmpDate && (
                    <div
                      onClick={() => setActiveTab('pregnancy')}
                      className="p-3.5 rounded-2xl bg-[#EEEEFF]/60 border border-[#E6E6F0] flex items-center justify-between cursor-pointer hover:border-amber-400 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">🤰</span>
                        <div>
                          <h4 className="font-bold text-[#4145C7]">متابعة الحمل المبارك</h4>
                          <p className="text-[11px] text-[#77798C]">
                            الأسبوع {Math.floor((new Date().getTime() - new Date(state.pregnancy.lmpDate).getTime()) / (1000 * 60 * 60 * 24 * 7))}
                          </p>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-[#5B5FEF] bg-white px-2 py-1 rounded-lg border border-[#E6E6F0]">
                        متابعة نشطة
                      </span>
                    </div>
                  )}

                  {/* تذكيرات اليوم */}
                  {state.reminders.filter(r => r.isActive).length > 0 && (
                    <div
                      onClick={() => setActiveTab('reminders')}
                      className="p-3.5 rounded-2xl bg-blue-50/50 border border-blue-200 flex items-center justify-between cursor-pointer hover:border-blue-400 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">🔔</span>
                        <div>
                          <h4 className="font-bold text-blue-900">تذكيراتكِ النشطة</h4>
                          <p className="text-[11px] text-[#77798C]">
                            {state.reminders.filter(r => r.isActive)[0].title}
                          </p>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-blue-700 bg-white px-2 py-1 rounded-lg border border-blue-200">
                        {state.reminders.filter(r => r.isActive).length} تذكيرات
                      </span>
                    </div>
                  )}

                  {/* آخر خاطرة مكتوبة */}
                  {state.diary.length > 0 && (
                    <div
                      onClick={() => setActiveTab('diary')}
                      className="p-3.5 rounded-2xl bg-pink-50/50 border border-pink-200 flex items-center justify-between cursor-pointer hover:border-pink-400 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">💗</span>
                        <div className="min-w-0">
                          <h4 className="font-bold text-pink-900">آخر خاطرة</h4>
                          <p className="text-[11px] text-[#77798C] truncate">{state.diary[0].title}</p>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-pink-700 bg-white px-2 py-1 rounded-lg border border-pink-200 shrink-0">
                        {state.diary.length} خواطر
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* شبكة الأدوات الـ 9 الكاملة */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-[#25263A] px-1">أدوات مساحتكِ الخاصة:</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  {
                    id: 'child_plant',
                    title: 'نبتة طفلي',
                    desc: 'نمو الطفل والقياسات والمواعيد والرسوم البيانية',
                    icon: 'svg_sprout',
                    color: 'hover:border-[#5B5FEF]'
                  },
                  {
                    id: 'cycle',
                    title: 'الدورة الشهرية',
                    desc: state.cycles.length > 0 ? `${state.cycles.length} دورات مسجلة` : 'لم تسجلي بعد',
                    icon: '🩸',
                    color: 'hover:border-rose-300'
                  },
                  {
                    id: 'pregnancy',
                    title: 'الحمل — رحلتك',
                    desc: '40 أسبوعاً، حجم الجنين، عداد الحركات، والمواعيد',
                    icon: 'svg_pregnancy',
                    color: 'hover:border-[#5B5FEF]'
                  },
                  {
                    id: 'fiqh',
                    title: 'فقه المرأة',
                    desc: 'أحكام الطهارة والصلاة والأسرة',
                    icon: '🌙',
                    color: 'hover:border-[#4CAF82]/40'
                  },
                  {
                    id: 'calendar',
                    title: 'تقويم المرأة',
                    desc: 'عرض موحد لما سجلتِه',
                    icon: '📅',
                    color: 'hover:border-blue-300'
                  },
                  {
                    id: 'breastfeeding',
                    title: 'متابعة الرضاعة',
                    desc: state.feedings.length > 0 ? `${state.feedings.length} رضعات مسجلة` : 'لم تسجلي بعد',
                    icon: '🍼',
                    color: 'hover:border-orange-300'
                  },
                  {
                    id: 'children',
                    title: 'متابعة الأطفال',
                    desc: state.children.length > 0 ? `${state.children.length} أطفال مسجلين` : 'لم تضيفي طفلاً',
                    icon: '👶',
                    color: 'hover:border-sky-300'
                  },
                  {
                    id: 'diary',
                    title: 'مذكراتي الخاصة',
                    desc: state.diary.length > 0 ? `${state.diary.length} خواطر مسجلة` : 'فارغة تماماً',
                    icon: '💗',
                    color: 'hover:border-pink-300'
                  },
                  {
                    id: 'reminders',
                    title: 'التذكيرات',
                    desc: state.reminders.length > 0 ? `${state.reminders.length} تذكيرات مسجلة` : 'لا توجد تذكيرات',
                    icon: '🔔',
                    color: 'hover:border-purple-300'
                  },
                  {
                    id: 'selfcare',
                    title: 'العناية والروتين',
                    desc: 'ماء، نوم، حركة، وأوراد',
                    icon: '🌿',
                    color: 'hover:border-teal-300'
                  },
                ].map(tool => (
                  <div
                    key={tool.id}
                    onClick={() => setActiveTab(tool.id as ActiveTab)}
                    className={`bg-white rounded-2xl p-4 border border-[#E6E6F0] ${tool.color} shadow-2xs hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between space-y-2`}
                  >
                    <div className="w-10 h-10 rounded-xl bg-[#F7F7FC] flex items-center justify-center text-xl">
                      {tool.icon === 'svg_sprout' ? (
                        <SproutHeaderSvg size={22} />
                      ) : tool.icon === 'svg_pregnancy' ? (
                        <PregnancyJourneyHeaderSvg size={22} />
                      ) : (
                        tool.icon
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#25263A] font-tajawal">{tool.title}</h4>
                      <p className="text-[11px] text-[#77798C] line-clamp-1 mt-0.5">{tool.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* قسم نبتة طفلي المستقل والمتكامل */}
        {activeTab === 'child_plant' && (
          <ChildPlantView onBackToWomanHub={() => setActiveTab('dashboard')} />
        )}

        {/* 2. متابعة الدورة الشهرية */}
        {activeTab === 'cycle' && (
          <CycleTrackerView
            cycles={state.cycles}
            onAddCycle={handleAddCycle}
            onDeleteCycle={handleDeleteCycle}
          />
        )}

        {/* 3. قسم الحمل المتكامل — رحلتك */}
        {activeTab === 'pregnancy' && (
          <PregnancyView
            pregnancy={state.pregnancy}
            onUpdatePregnancy={handleUpdatePregnancy}
            onBackToWomanHub={() => setActiveTab('dashboard')}
          />
        )}

        {/* 4. فقه المرأة الموثق */}
        {activeTab === 'fiqh' && <FiqhView />}

        {/* 5. التقويم الموحد */}
        {activeTab === 'calendar' && <WomanCalendarView state={state} />}

        {/* 6. متابعة الرضاعة */}
        {activeTab === 'breastfeeding' && (
          <BreastfeedingView
            feedings={state.feedings}
            onAddFeeding={handleAddFeeding}
            onDeleteFeeding={handleDeleteFeeding}
          />
        )}

        {/* 7. متابعة الأطفال */}
        {activeTab === 'children' && (
          <ChildrenView
            childrenList={state.children}
            onAddChild={handleAddChild}
            onDeleteChild={handleDeleteChild}
          />
        )}

        {/* 8. التذكيرات الشخصية */}
        {activeTab === 'reminders' && (
          <RemindersView
            reminders={state.reminders}
            onAddReminder={handleAddReminder}
            onToggleReminder={handleToggleReminder}
            onDeleteReminder={handleDeleteReminder}
          />
        )}

        {/* 9. مذكراتي الخاصة */}
        {activeTab === 'diary' && (
          <DiaryView
            entries={state.diary}
            pinCode={state.pinCode}
            isPinEnabled={state.isPinEnabled}
            onAddEntry={handleAddDiaryEntry}
            onDeleteEntry={handleDeleteDiaryEntry}
            onUpdateSecurity={handleUpdateSecurity}
          />
        )}

        {/* 10. العناية الشخصية والروتين */}
        {activeTab === 'selfcare' && (
          <SelfCareView
            selfCare={state.selfCare}
            customHabits={state.customHabits}
            onUpdateTodayRecord={handleUpdateTodayCare}
            onAddCustomHabit={handleAddCustomHabit}
            onDeleteCustomHabit={handleDeleteCustomHabit}
          />
        )}

        {/* 11. الخصوصية وإدارة البيانات */}
        {activeTab === 'privacy' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#4CAF82]/12 border border-[#4CAF82]/40 flex items-center justify-center text-2xl shadow-xs">
                  🛡️
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#25263A] font-tajawal">سياسة الخصوصية والأمان</h3>
                  <p className="text-xs text-[#77798C]">تطبيق «رِفْق» يلتزم بأعلى معايير الخصوصية والأمان</p>
                </div>
              </div>

              <div className="p-4 bg-[#4CAF82]/12/50 rounded-2xl border border-[#4CAF82]/40/60 text-xs text-[#4CAF82] space-y-2">
                <div className="font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#4CAF82]" />
                  <span>تخزين محلي 100% (Local Storage Only):</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-stone-700">
                  <li>جميع بياناتكِ المسجلة (الدورة، الحمل، الرضاعة، الأطفال، المذكرات، التذكيرات) تُحفظ على ذاكرة هاتفكِ فقط.</li>
                  <li>لا يتم رفع أي بيانات إلى أي خادم خارجي أو سيرفر إطلاقاً.</li>
                  <li>لا تتم مشاركة بياناتكِ مع أي طرف ثالث أو استخدامها في الإعلانات أو الإحصاءات العامة.</li>
                  <li>يمكنكِ في أي وقت حذف كافة بياناتكِ نهائياً بنقرة واحدة.</li>
                </ul>
              </div>

              {/* زر حذف كافة البيانات */}
              <div className="pt-4 border-t border-[#E6E6F0] flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-rose-700">حذف كافة بياناتي نهائياً</h4>
                  <p className="text-[11px] text-[#77798C]">مسح جميع السجلات والعودة للحالة الفارغة الأولية</p>
                </div>

                <button
                  type="button"
                  onClick={() => setShowWipeConfirm(true)}
                  className="flex items-center gap-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>حذف كافة البيانات</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ── التذييل الثابت ── */}
      <footer className="mt-12 text-center text-xs text-[#77798C] space-y-1">
        <p className="font-bold text-[#25263A]">رِفْق | مساحة خاصة لكِ 🤍</p>
        <p className="text-[10px]">خصوصية تامة • بدون بيانات وهمية • حفظ محلي آمن</p>
      </footer>

      {/* نافذة تأكيد حذف البيانات */}
      {showWipeConfirm && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-rose-300 shadow-xl space-y-4 text-center">
            <div className="w-14 h-14 mx-auto rounded-full bg-rose-50 flex items-center justify-center text-2xl text-rose-600">
              ⚠️
            </div>
            <div>
              <h4 className="text-base font-bold text-[#25263A]">هل أنتِ متأكدة؟</h4>
              <p className="text-xs text-[#77798C] mt-1 leading-relaxed">
                سيتم مسح جميع سجلات الدورة والحمل والمذكرات والتذكيرات نهائياً من هاتفكِ والعودة للقسم الفارغ تماماً. لا يمكن التراجع عن هذا الإجراء.
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleWipeAll}
                className="flex-1 bg-rose-600 text-white py-2.5 rounded-xl font-bold text-xs hover:bg-rose-700 transition-colors cursor-pointer"
              >
                نعم، احذف كل بياناتي
              </button>
              <button
                type="button"
                onClick={() => setShowWipeConfirm(false)}
                className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold text-xs hover:bg-stone-50 cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
