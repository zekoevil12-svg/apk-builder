import React, { useState } from 'react';
import { Plus, Trash2, Bell, Check, Clock, Calendar } from 'lucide-react';
import { WomanReminder } from './womanTypes';

interface RemindersViewProps {
  reminders: WomanReminder[];
  onAddReminder: (reminder: Omit<WomanReminder, 'id'>) => void;
  onToggleReminder: (id: string) => void;
  onDeleteReminder: (id: string) => void;
}

export const RemindersView: React.FC<RemindersViewProps> = ({
  reminders,
  onAddReminder,
  onToggleReminder,
  onDeleteReminder,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState('08:00');
  const [frequency, setFrequency] = useState<'once' | 'daily' | 'weekly' | 'monthly'>('daily');
  const [category, setCategory] = useState<'health' | 'worship' | 'baby' | 'personal'>('health');
  const [notes, setNotes] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAddReminder({
      title: title.trim(),
      date,
      time,
      frequency,
      category,
      isActive: true,
      notes: notes.trim() || undefined
    });

    setTitle('');
    setNotes('');
    setShowAddModal(false);
  };

  const getFreqLabel = (f: WomanReminder['frequency']) => {
    switch (f) {
      case 'once': return 'مرة واحدة';
      case 'daily': return 'يومياً 🔄';
      case 'weekly': return 'أسبوعياً 📅';
      case 'monthly': return 'شهرياً 🌙';
    }
  };

  const getCatBadge = (c: WomanReminder['category']) => {
    switch (c) {
      case 'health': return { label: 'صحة وعافية 💊', bg: 'bg-rose-50 text-rose-800' };
      case 'worship': return { label: 'عبادة وذكر 🕌', bg: 'bg-[#4CAF82]/12 text-[#4CAF82]' };
      case 'baby': return { label: 'طفلي 🍼', bg: 'bg-blue-50 text-blue-800' };
      case 'personal': return { label: 'شخصي 🌸', bg: 'bg-purple-50 text-purple-800' };
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-2xl shadow-xs">
            🔔
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">التذكيرات الشخصية</h3>
            <p className="text-xs text-[#77798C]">تنبيهات للمواعيد، الفيتامينات، وأوقات الأوراد والأعمال</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة تذكير</span>
        </button>
      </div>

      {reminders.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#EEEEFF] flex items-center justify-center text-3xl">
            🔔
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h4 className="text-base font-bold text-[#25263A]">لا توجد تذكيرات مسجلة بعد</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              أضيفي تذكيراتك اليومية كشرب الماء، موعد فيتامينات، قيام الليل، أذكار الصباح والمساء، أو موعد مراجعة الطبيب.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة أول تذكير</span>
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
          {reminders.map(r => {
            const badge = getCatBadge(r.category);
            return (
              <div
                key={r.id}
                className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                  r.isActive ? 'border-[#E6E6F0] bg-white' : 'border-[#E6E6F0] bg-stone-50/60 opacity-60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onToggleReminder(r.id)}
                    className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                      r.isActive ? 'bg-[#5B5FEF] text-white shadow-xs' : 'border border-stone-300 text-transparent'
                    }`}
                  >
                    ✓
                  </button>
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-bold ${r.isActive ? 'text-[#25263A]' : 'text-stone-400 line-through'}`}>
                        {r.title}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${badge.bg}`}>
                        {badge.label}
                      </span>
                      <span className="text-[10px] text-[#77798C] bg-stone-100 px-1.5 py-0.5 rounded">
                        {getFreqLabel(r.frequency)}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#77798C] flex items-center gap-2">
                      <span>⏰ {r.time}</span>
                      <span>📅 {r.date}</span>
                      {r.notes && <span>• {r.notes}</span>}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onDeleteReminder(r.id)}
                  className="p-1.5 text-stone-400 hover:text-rose-500 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* نافذة إضافة تذكير */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#E6E6F0] shadow-xl space-y-4">
            <h4 className="text-base font-bold text-[#25263A]">إضافة تذكير جديد</h4>
            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1">عنوان التذكير</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: شرب الماء، فيتامين د، ورد المساء..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-stone-700 font-bold mb-1">التوقيت</label>
                  <input
                    type="time"
                    required
                    value={time}
                    onChange={e => setTime(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-bold mb-1">التاريخ</label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">التكرار</label>
                <select
                  value={frequency}
                  onChange={e => setFrequency(e.target.value as any)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden bg-white"
                >
                  <option value="daily">يومياً</option>
                  <option value="weekly">أسبوعياً</option>
                  <option value="monthly">شهرياً</option>
                  <option value="once">مرة واحدة فقط</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">التصنيف</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'health', label: 'صحة وعافية 💊' },
                    { id: 'worship', label: 'عبادة وأوراد 🕌' },
                    { id: 'baby', label: 'الطفل 🍼' },
                    { id: 'personal', label: 'شخصي 🌸' },
                  ].map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCategory(c.id as any)}
                      className={`p-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                        category === c.id
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-stone-50 border-[#E6E6F0] text-stone-700'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">ملاحظة (اختياري)</label>
                <input
                  type="text"
                  placeholder="ملاحظة سريعة..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  حفظ التذكير
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
