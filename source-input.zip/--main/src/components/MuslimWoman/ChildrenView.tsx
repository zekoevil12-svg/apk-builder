import React, { useState } from 'react';
import { Plus, Trash2, Baby, Calendar, Heart } from 'lucide-react';
import { ChildRecord } from './womanTypes';

interface ChildrenViewProps {
  childrenList: ChildRecord[];
  onAddChild: (child: Omit<ChildRecord, 'id'>) => void;
  onDeleteChild: (id: string) => void;
}

export const ChildrenView: React.FC<ChildrenViewProps> = ({
  childrenList,
  onAddChild,
  onDeleteChild,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [notes, setNotes] = useState('');

  // دالة حساب العمر الحقيقي بدقة من تاريخ الميلاد
  const calculateExactAge = (bDateStr: string) => {
    const birth = new Date(bDateStr);
    const now = new Date();
    if (birth > now) return 'تاريخ الميلاد في المستقبل';

    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      const prevMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      days += prevMonthLastDay;
    }

    if (months < 0) {
      years -= 1;
      months += 12;
    }

    if (years === 0 && months === 0) {
      return `${days} يوماً`;
    }
    if (years === 0) {
      return `${months} أشهر و ${days} أيام`;
    }
    return `${years} سنوات و ${months} أشهر`;
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !birthDate) return;
    if (new Date(birthDate) > new Date()) {
      alert('تاريخ الميلاد لا يمكن أن يكون في المستقبل');
      return;
    }

    onAddChild({
      name: name.trim(),
      birthDate,
      gender,
      notes: notes.trim() || undefined
    });

    setName('');
    setBirthDate('');
    setNotes('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-2xl shadow-xs">
            👶
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">متابعة الأطفال</h3>
            <p className="text-xs text-[#77798C]">تسجيل الأبناء، حساب الأعمار الحقيقية، ومتابعة الملاحظات</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة طفل جديد</span>
        </button>
      </div>

      {childrenList.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 mx-auto rounded-full bg-blue-50 flex items-center justify-center text-3xl">
            👶
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h4 className="text-base font-bold text-[#25263A]">لم تضيفي أي طفل بعد</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              أضيفي أطفالك المباركين لحساب أعمارهم بدقة يومية، ومتابعة مواعيد التطعيمات والملاحظات الصحية الخاصة بكل طفل.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة أول طفل</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {childrenList.map(child => (
            <div
              key={child.id}
              className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3 relative group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl ${
                    child.gender === 'female' ? 'bg-pink-100 text-pink-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {child.gender === 'female' ? '👧' : '👦'}
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-[#25263A]">{child.name}</h4>
                    <span className="text-[11px] text-[#77798C]">
                      {child.gender === 'female' ? 'بنت 🌸' : 'ولد 💙'} • وُلد في {child.birthDate}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onDeleteChild(child.id)}
                  className="p-2 text-stone-400 hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="p-3 bg-[#F7F7FC]/70 rounded-xl flex items-center justify-between text-xs">
                <span className="text-[#77798C] font-bold">العمر الحالي الحقيقي:</span>
                <span className="text-[#25263A] font-black font-tajawal text-sm">
                  {calculateExactAge(child.birthDate)}
                </span>
              </div>

              {child.notes && (
                <p className="text-xs text-[#77798C] italic bg-stone-50 p-2.5 rounded-lg border border-[#E6E6F0]">
                  {child.notes}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {/* نافذة إضافة طفل */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#E6E6F0] shadow-xl space-y-4">
            <h4 className="text-base font-bold text-[#25263A]">إضافة طفل جديد</h4>
            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1">اسم الطفل / الطفلة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: يوسف، مريم..."
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">الجنس</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setGender('male')}
                    className={`p-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                      gender === 'male'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-stone-50 border-[#E6E6F0] text-stone-700'
                    }`}
                  >
                    👦 ولد
                  </button>
                  <button
                    type="button"
                    onClick={() => setGender('female')}
                    className={`p-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                      gender === 'female'
                        ? 'bg-pink-600 text-white border-pink-600'
                        : 'bg-stone-50 border-[#E6E6F0] text-stone-700'
                    }`}
                  >
                    👧 بنت
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">تاريخ الميلاد</label>
                <input
                  type="date"
                  required
                  value={birthDate}
                  onChange={e => setBirthDate(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">ملاحظات خاصة (فصيلة الدم، حساسية، تطعيمات...)</label>
                <input
                  type="text"
                  placeholder="اختياري..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  حفظ الطفل
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
