import React, { useState, useEffect, useRef } from 'react';
import {
  ChildRow,
  MeasurementRow,
  AppointmentRow,
  NoteRow,
  ActivityRow,
  ChildPlantDatabaseState,
  loadChildPlantDb,
  saveChildPlantDb,
  calculateChildAge,
  formatDateDMY,
  deleteAllChildDataFromSqlite,
  scheduleRealChildAppointmentNotification,
  checkAndFireChildAppointmentNotifications,
} from '../../utils/childPlantSqlite';
import {
  SproutHeaderSvg,
  RulerSvg,
  WeightScaleSvg,
  HeadCircumferenceSvg,
  CalendarApptSvg,
  NoteBookSvg,
  ActivityLogSvg,
  InteractiveChildPlantSvg,
} from './ChildPlantSvg';
import {
  ChildMeasurementsAndChartsScreen,
  ChildStagesTimelineScreen,
  ChildAppointmentsScreen,
  ChildActivitiesNotesAndChildrenScreen,
} from './ChildPlantSubScreens';

export type ChildPlantScreenKey =
  | 'main'
  | 'add_child'
  | 'measurements'
  | 'charts'
  | 'stages'
  | 'appointments'
  | 'activities'
  | 'notes'
  | 'children_list';

interface ChildPlantViewProps {
  onBackToWomanHub?: () => void;
}

export const ChildPlantView: React.FC<ChildPlantViewProps> = ({ onBackToWomanHub }) => {
  const [db, setDb] = useState<ChildPlantDatabaseState>(() => loadChildPlantDb());
  const [screen, setScreen] = useState<ChildPlantScreenKey>('main');
  const [bannerMessage, setBannerMessage] = useState<string | null>(null);

  // حماية الخصوصية (PIN اختياري)
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => !loadChildPlantDb().pinEnabled);
  const [pinInput, setPinInput] = useState('');
  const [pinSetupOpen, setPinSetupOpen] = useState(false);
  const [newPinValue, setNewPinValue] = useState('');

  // حقول الشاشة 1: إضافة طفل
  const [childName, setChildName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const [initHeight, setInitHeight] = useState('');
  const [initWeight, setInitWeight] = useState('');
  const [initHead, setInitHead] = useState('');
  const [addFormError, setAddFormError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const updateDb = (updater: (prev: ChildPlantDatabaseState) => ChildPlantDatabaseState) => {
    setDb((prev) => {
      const next = updater(prev);
      saveChildPlantDb(next);
      return next;
    });
  };

  // فحص إشعارات المواعيد الحقيقية دورياً
  useEffect(() => {
    checkAndFireChildAppointmentNotifications();
    const timer = setInterval(() => {
      checkAndFireChildAppointmentNotifications();
    }, 25000);
    return () => clearInterval(timer);
  }, []);

  const showSuccessBanner = (msg: string) => {
    setBannerMessage(msg);
    setTimeout(() => {
      setBannerMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  const selectedChild: ChildRow | null =
    db.children.find((c) => c.id === db.selectedChildId) || db.children[0] || null;

  // تسجيل حدث عيد الميلاد تلقائياً في سجل الطفل إذا وافق اليوم
  useEffect(() => {
    if (!selectedChild) return;
    const age = calculateChildAge(selectedChild.birth_date);
    if (!age.isBirthdayToday) return;

    const todayStr = new Date().toISOString().slice(0, 10);
    const bdayRef = `bday_${selectedChild.id}_${todayStr}`;
    const exists = db.activities.some((a) => a.ref_id === bdayRef);
    if (!exists) {
      updateDb((prev) => ({
        ...prev,
        activities: [
          {
            id: `act_${Date.now()}`,
            child_id: selectedChild.id,
            type: 'birthday',
            ref_id: bdayRef,
            title: 'إتمام سنة جديدة من العمر',
            subtitle: `أتم ${selectedChild.name || 'طفلي'} ${age.years} سنة بحمد الله`,
            date: todayStr,
            created_at: new Date().toISOString(),
          },
          ...prev.activities,
        ],
      }));
    }
  }, [selectedChild?.id, selectedChild?.birth_date]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoBase64(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const resetAddChildForm = () => {
    setChildName('');
    setBirthDate('');
    setGender('male');
    setPhotoBase64(null);
    setInitHeight('');
    setInitWeight('');
    setInitHead('');
    setAddFormError(null);
  };

  // حفظ الطفل في SQLite والتحقق الصارم من الحقول
  const handleSaveNewChild = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setAddFormError(null);

    const trimmedName = childName.trim();
    // التحقق: الاسم لا يحتوي رموز غريبة
    const validNameRegex = /^[\u0600-\u06FFa-zA-Z0-9\s\-_.]*$/;
    if (trimmedName && !validNameRegex.test(trimmedName)) {
      setAddFormError('الاسم يجب ألا يحتوي على رموز غريبة.');
      return;
    }

    // التحقق: تاريخ الميلاد إلزامي ولا يكون في المستقبل
    if (!birthDate) {
      setAddFormError('تاريخ الميلاد حقل إلزامي.');
      return;
    }
    const todayStr = new Date().toISOString().slice(0, 10);
    if (birthDate > todayStr) {
      setAddFormError('تاريخ الميلاد لا يمكن أن يكون في المستقبل.');
      return;
    }

    // التحقق: الأرقام موجبة
    const h = initHeight.trim() ? Number(initHeight) : null;
    const w = initWeight.trim() ? Number(initWeight) : null;
    const hc = initHead.trim() ? Number(initHead) : null;

    if (
      (h !== null && (isNaN(h) || h <= 0)) ||
      (w !== null && (isNaN(w) || w <= 0)) ||
      (hc !== null && (isNaN(hc) || hc <= 0))
    ) {
      setAddFormError('الطول والوزن ومحيط الرأس يجب أن تكون أرقاماً موجبة.');
      return;
    }

    const nowIso = new Date().toISOString();
    const newChildId = `child_${Date.now()}`;
    const newChild: ChildRow = {
      id: newChildId,
      name: trimmedName || 'طفلي',
      birth_date: birthDate,
      gender,
      photo_path: photoBase64,
      created_at: nowIso,
    };

    const newMeasurements: MeasurementRow[] = [];
    const newActivities: ActivityRow[] = [];

    if (h !== null || w !== null || hc !== null) {
      const mId = `meas_${Date.now()}`;
      newMeasurements.push({
        id: mId,
        child_id: newChildId,
        date: todayStr,
        height: h,
        weight: w,
        head_circumference: hc,
        notes: 'القياس الأول عند إضافة الطفل',
        created_at: nowIso,
      });

      const summaryParts: string[] = [];
      if (h !== null) summaryParts.push(`الطول: ${h} سم`);
      if (w !== null) summaryParts.push(`الوزن: ${w} كغ`);
      if (hc !== null) summaryParts.push(`محيط الرأس: ${hc} سم`);

      newActivities.push({
        id: `act_${Date.now()}`,
        child_id: newChildId,
        type: 'measurement',
        ref_id: mId,
        title: 'قياس نمو أولي',
        subtitle: summaryParts.join(' • '),
        date: todayStr,
        created_at: nowIso,
      });
    }

    updateDb((prev) => ({
      ...prev,
      children: [...prev.children, newChild],
      measurements: [...newMeasurements, ...prev.measurements],
      activities: [...newActivities, ...prev.activities],
      selectedChildId: newChildId,
    }));

    resetAddChildForm();
    setScreen('main');
    showSuccessBanner('تم حفظ بيانات الطفل بنجاح وحساب عمره تلقائياً');
  };

  // حفظ أو تعديل قياس نمو
  const handleSaveMeasurement = (data: {
    id?: string;
    date: string;
    height: number | null;
    weight: number | null;
    head_circumference: number | null;
    notes: string;
  }) => {
    if (!selectedChild) return;
    const nowIso = new Date().toISOString();

    if (data.id) {
      updateDb((prev) => ({
        ...prev,
        measurements: prev.measurements.map((m) =>
          m.id === data.id
            ? {
                ...m,
                date: data.date,
                height: data.height,
                weight: data.weight,
                head_circumference: data.head_circumference,
                notes: data.notes,
              }
            : m
        ),
      }));
      showSuccessBanner('تم تحديث قياس النمو بنجاح');
    } else {
      const mId = `meas_${Date.now()}`;
      const newRow: MeasurementRow = {
        id: mId,
        child_id: selectedChild.id,
        date: data.date,
        height: data.height,
        weight: data.weight,
        head_circumference: data.head_circumference,
        notes: data.notes,
        created_at: nowIso,
      };
      const parts: string[] = [];
      if (data.height !== null) parts.push(`الطول: ${data.height} سم`);
      if (data.weight !== null) parts.push(`الوزن: ${data.weight} كغ`);
      if (data.head_circumference !== null) parts.push(`محيط الرأس: ${data.head_circumference} سم`);

      const newAct: ActivityRow = {
        id: `act_${Date.now()}`,
        child_id: selectedChild.id,
        type: 'measurement',
        ref_id: mId,
        title: 'إضافة قياس نمو',
        subtitle: parts.join(' • '),
        date: data.date,
        created_at: nowIso,
      };

      updateDb((prev) => ({
        ...prev,
        measurements: [newRow, ...prev.measurements],
        activities: [newAct, ...prev.activities],
      }));
      showSuccessBanner('تمت إضافة قياس النمو إلى قاعدة البيانات');
    }
  };

  const handleDeleteMeasurement = (id: string) => {
    updateDb((prev) => ({
      ...prev,
      measurements: prev.measurements.filter((m) => m.id !== id),
      activities: prev.activities.filter((a) => a.ref_id !== id),
    }));
    showSuccessBanner('تم حذف القياس');
  };

  // حفظ أو تعديل موعد + جدولة إشعار حقيقي
  const handleSaveAppointment = async (data: {
    id?: string;
    title: string;
    date: string;
    time: string;
    doctor_name: string;
    notes: string;
    reminder_enabled: boolean;
  }) => {
    if (!selectedChild) return;
    const nowIso = new Date().toISOString();
    const apptId = data.id || `appt_${Date.now()}`;

    const row: AppointmentRow = {
      id: apptId,
      child_id: selectedChild.id,
      title: data.title,
      date: data.date,
      time: data.time,
      doctor_name: data.doctor_name,
      notes: data.notes,
      reminder_enabled: data.reminder_enabled ? 1 : 0,
      created_at: nowIso,
    };

    if (data.id) {
      updateDb((prev) => ({
        ...prev,
        appointments: prev.appointments.map((a) => (a.id === data.id ? row : a)),
      }));
    } else {
      const act: ActivityRow = {
        id: `act_${Date.now()}`,
        child_id: selectedChild.id,
        type: 'appointment',
        ref_id: apptId,
        title: `موعد: ${data.title}`,
        subtitle: `${formatDateDMY(data.date)} الساعة ${data.time}`,
        date: data.date,
        created_at: nowIso,
      };
      updateDb((prev) => ({
        ...prev,
        appointments: [row, ...prev.appointments],
        activities: [act, ...prev.activities],
      }));
    }

    if (row.reminder_enabled) {
      await scheduleRealChildAppointmentNotification(row);
      checkAndFireChildAppointmentNotifications();
    }
    showSuccessBanner('تم حفظ الموعد وجدولة التنبيه المحلي بنجاح');
  };

  const handleDeleteAppointment = (id: string) => {
    updateDb((prev) => ({
      ...prev,
      appointments: prev.appointments.filter((a) => a.id !== id),
      activities: prev.activities.filter((act) => act.ref_id !== id),
    }));
    showSuccessBanner('تم إلغاء الموعد وإزالة تنبيهه');
  };

  const handleToggleAppointmentReminder = (id: string) => {
    updateDb((prev) => ({
      ...prev,
      appointments: prev.appointments.map((a) =>
        a.id === id ? { ...a, reminder_enabled: a.reminder_enabled ? 0 : 1 } : a
      ),
    }));
  };

  // حفظ أو تعديل ملاحظة
  const handleSaveNote = (data: { id?: string; title: string; content: string; date: string }) => {
    if (!selectedChild) return;
    const nowIso = new Date().toISOString();

    if (data.id) {
      updateDb((prev) => ({
        ...prev,
        notes: prev.notes.map((n) =>
          n.id === data.id
            ? { ...n, title: data.title, content: data.content, created_at: data.date }
            : n
        ),
      }));
      showSuccessBanner('تم تحديث الملاحظة');
    } else {
      const nId = `note_${Date.now()}`;
      const newNote: NoteRow = {
        id: nId,
        child_id: selectedChild.id,
        title: data.title,
        content: data.content,
        created_at: data.date || nowIso,
      };
      const newAct: ActivityRow = {
        id: `act_${Date.now()}`,
        child_id: selectedChild.id,
        type: 'note',
        ref_id: nId,
        title: `ملاحظة: ${data.title}`,
        subtitle: data.content.slice(0, 60),
        date: data.date || nowIso.slice(0, 10),
        created_at: nowIso,
      };
      updateDb((prev) => ({
        ...prev,
        notes: [newNote, ...prev.notes],
        activities: [newAct, ...prev.activities],
      }));
      showSuccessBanner('تم حفظ الملاحظة');
    }
  };

  const handleDeleteNote = (id: string) => {
    updateDb((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== id),
      activities: prev.activities.filter((a) => a.ref_id !== id),
    }));
    showSuccessBanner('تم حذف الملاحظة');
  };

  const isDark = db.darkMode;
  const pageBg = isDark ? 'bg-[#121212] text-white' : 'bg-[#F7F7FC] text-[#25263A]';
  const cardBg = isDark
    ? 'bg-[#1E1E1E] border border-[#E99AC7]/40 text-white rounded-[20px] shadow-sm'
    : 'bg-[#FFFFFF] border border-[#E99AC7] text-[#25263A] rounded-[20px] shadow-xs';

  // شاشة القفل بكلمة مرور اختياري (الخصوصية)
  if (db.pinEnabled && !isUnlocked) {
    return (
      <div className={`${pageBg} p-6 rounded-3xl border border-[#E6E6F0] max-w-md mx-auto text-center space-y-4`}>
        <div className="w-14 h-14 mx-auto rounded-full bg-[#FDF2F8] border border-[#5B5FEF] flex items-center justify-center">
          <SproutHeaderSvg size={28} />
        </div>
        <h3 className="font-bold text-base">قسم «نبتة طفلي» محمي برمز الخصوصية</h3>
        <p className="text-xs text-[#77798C]">أدخلي رمز الحماية المحلي لفتح بيانات طفلك</p>
        <input
          type="password"
          value={pinInput}
          onChange={(e) => setPinInput(e.target.value)}
          placeholder="رمز المرور"
          className="w-full px-4 py-2.5 rounded-xl bg-white text-[#25263A] border border-[#E6E6F0] text-center font-bold text-sm"
        />
        <div className="flex justify-center gap-2">
          <button
            type="button"
            onClick={() => {
              if (pinInput === db.pinCode) {
                setIsUnlocked(true);
                setPinInput('');
              } else {
                showSuccessBanner('رمز المرور غير صحيح');
              }
            }}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
          >
            فتح القسم
          </button>
          {onBackToWomanHub && (
            <button
              type="button"
              onClick={onBackToWomanHub}
              className="px-4 py-2.5 rounded-xl bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
            >
              رجوع
            </button>
          )}
        </div>
      </div>
    );
  }

  // تحديد عنوان الشريط العلوي حسب الشاشة الحالية
  const getHeaderTitle = () => {
    if (screen === 'add_child' || db.children.length === 0) return 'إضافة طفل';
    if (screen === 'measurements') return 'قياسات النمو';
    if (screen === 'charts') return 'الرسوم البيانية';
    if (screen === 'stages') return 'مراحل النمو';
    if (screen === 'appointments') return 'المواعيد';
    if (screen === 'activities') return 'سجل الطفل';
    if (screen === 'notes') return 'ملاحظاتي';
    if (screen === 'children_list') return 'أطفالي';
    return 'نبتة طفلي';
  };

  const childMeasurements = selectedChild
    ? db.measurements.filter((m) => m.child_id === selectedChild.id)
    : [];
  const childAppointments = selectedChild
    ? db.appointments.filter((a) => a.child_id === selectedChild.id)
    : [];
  const childNotes = selectedChild
    ? db.notes.filter((n) => n.child_id === selectedChild.id)
    : [];
  const childActivities = selectedChild
    ? db.activities.filter((act) => act.child_id === selectedChild.id)
    : [];
  const ageInfo = selectedChild ? calculateChildAge(selectedChild.birth_date) : null;

  return (
    <div className={`${pageBg} rounded-3xl p-4 sm:p-5 space-y-4 transition-colors duration-300`}>
      {/* الشريط العلوي الموحد */}
      <div className={`${cardBg} px-4 py-3.5 flex items-center justify-between gap-2`}>
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              if (screen !== 'main' && db.children.length > 0) {
                setScreen('main');
              } else if (onBackToWomanHub) {
                onBackToWomanHub();
              }
            }}
            className="px-3 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
          >
            رجوع
          </button>
          <div className="flex items-center gap-2">
            <SproutHeaderSvg size={22} />
            <h2 className="font-bold text-base sm:text-lg">{getHeaderTitle()}</h2>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* تبديل الوضع الليلي الدافئ */}
          <button
            type="button"
            onClick={() => updateDb((prev) => ({ ...prev, darkMode: !prev.darkMode }))}
            className="px-2.5 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] text-[11px] font-bold cursor-pointer"
          >
            {isDark ? 'نهاري' : 'ليلي'}
          </button>

          {/* زر إعداد قفل الخصوصية */}
          <button
            type="button"
            onClick={() => setPinSetupOpen((v) => !v)}
            className="px-2.5 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] text-[11px] font-bold cursor-pointer"
          >
            {db.pinEnabled ? 'القفل مفعّل' : 'قفل سري'}
          </button>

          {/* قائمة التبديل إذا وجد أكثر من طفل أو زر الحفظ في شاشة الإضافة */}
          {(screen === 'add_child' || db.children.length === 0) ? (
            <button
              type="button"
              onClick={() => handleSaveNewChild()}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
            >
              حفظ
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setScreen('children_list')}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
            >
              أطفالي ({db.children.length})
            </button>
          )}
        </div>
      </div>

      {/* نافذة إعداد رمز القفل الاختياري */}
      {pinSetupOpen && (
        <div className={`${cardBg} p-4 space-y-3`}>
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-xs">حماية الخصوصية (قفل بكلمة مرور اختياري)</h4>
            <button
              type="button"
              onClick={() => setPinSetupOpen(false)}
              className="text-xs text-[#77798C] font-bold cursor-pointer"
            >
              إغلاق
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="password"
              value={newPinValue}
              onChange={(e) => setNewPinValue(e.target.value)}
              placeholder="أدخلي رمز مرور جديد"
              className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#5B5FEF] text-xs font-bold"
            />
            <button
              type="button"
              onClick={() => {
                if (!newPinValue.trim()) return;
                updateDb((prev) => ({
                  ...prev,
                  pinCode: newPinValue.trim(),
                  pinEnabled: true,
                }));
                setNewPinValue('');
                setPinSetupOpen(false);
                showSuccessBanner('تم تفعيل قفل الخصوصية المحلي');
              }}
              className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
            >
              تفعيل القفل
            </button>
            {db.pinEnabled && (
              <button
                type="button"
                onClick={() => {
                  updateDb((prev) => ({ ...prev, pinCode: null, pinEnabled: false }));
                  setPinSetupOpen(false);
                  showSuccessBanner('تم إلغاء قفل الخصوصية');
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-100 text-rose-700 text-xs font-bold cursor-pointer"
              >
                إلغاء القفل
              </button>
            )}
          </div>
        </div>
      )}

      {/* رسالة التأكيد والنجاح */}
      {bannerMessage && (
        <div className="p-3 rounded-2xl bg-[#5B5FEF] text-white text-xs font-bold text-center shadow-xs">
          {bannerMessage}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════
          الشاشة 1: إضافة طفل (تظهر عند عدم وجود طفل أو عند طلب إضافة طفل جديد)
         ════════════════════════════════════════════════════════════════════ */}
      {(db.children.length === 0 || screen === 'add_child') && (
        <form onSubmit={handleSaveNewChild} className={`${cardBg} p-5 space-y-4`}>
          <div className="flex items-center justify-between border-b border-[#E99AC7]/50 pb-3">
            <div>
              <h3 className="font-bold text-base">بيانات الطفل الأساسية</h3>
              <p className="text-xs text-[#77798C]">
                تُحفظ البيانات محلياً بالكامل على جهازك لحساب العمر ومراحل النمو
              </p>
            </div>
            {db.children.length > 0 && (
              <button
                type="button"
                onClick={() => setScreen('main')}
                className="px-3 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            )}
          </div>

          {addFormError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold">
              {addFormError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 1. اسم الطفل (اختياري) */}
            <div>
              <label className="block text-xs font-bold mb-1.5">1. اسم الطفل (اختياري)</label>
              <input
                type="text"
                value={childName}
                onChange={(e) => setChildName(e.target.value)}
                placeholder="اتركيه فارغاً أو اكتبي اسم طفلك"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>

            {/* 2. تاريخ الميلاد (إلزامي) */}
            <div>
              <label className="block text-xs font-bold mb-1.5">
                2. تاريخ الميلاد (إلزامي) *
              </label>
              <input
                type="date"
                required
                max={new Date().toISOString().slice(0, 10)}
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>
          </div>

          {/* 3. الجنس: ذكر / أنثى */}
          <div>
            <label className="block text-xs font-bold mb-1.5">3. الجنس</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setGender('male')}
                className={`py-2.5 rounded-xl font-bold text-xs border transition-all cursor-pointer ${
                  gender === 'male'
                    ? 'bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white border-[#5B5FEF]'
                    : 'bg-[#FDF2F8]/50 text-[#25263A] border-[#E99AC7]'
                }`}
              >
                ذكر
              </button>
              <button
                type="button"
                onClick={() => setGender('female')}
                className={`py-2.5 rounded-xl font-bold text-xs border transition-all cursor-pointer ${
                  gender === 'female'
                    ? 'bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white border-[#5B5FEF]'
                    : 'bg-[#FDF2F8]/50 text-[#25263A] border-[#E99AC7]'
                }`}
              >
                أنثى
              </button>
            </div>
          </div>

          {/* 4. صورة الطفل (اختياري) */}
          <div>
            <label className="block text-xs font-bold mb-1.5">4. صورة الطفل (اختياري)</label>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-[#FDF2F8] border border-[#5B5FEF] overflow-hidden flex items-center justify-center shrink-0">
                {photoBase64 ? (
                  <img src={photoBase64} alt="صورة الطفل" className="w-full h-full object-cover" />
                ) : (
                  <SproutHeaderSvg size={26} />
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 rounded-xl bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
              >
                اختيار صورة من الجهاز
              </button>
              {photoBase64 && (
                <button
                  type="button"
                  onClick={() => setPhotoBase64(null)}
                  className="px-3 py-2 rounded-xl bg-rose-50 text-rose-700 text-xs font-bold cursor-pointer"
                >
                  إزالة
                </button>
              )}
            </div>
          </div>

          {/* 5، 6، 7: الطول والوزن ومحيط الرأس الحالي (اختياري) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold mb-1">5. الطول الحالي (سم - اختياري)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={initHeight}
                onChange={(e) => setInitHeight(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">6. الوزن الحالي (كغ - اختياري)</label>
              <input
                type="number"
                step="0.05"
                min="0.1"
                value={initWeight}
                onChange={(e) => setInitWeight(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">7. محيط الرأس (سم - اختياري)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                value={initHead}
                onChange={(e) => setInitHead(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>
          </div>

          {/* زر الحفظ الذهبي المتدرج */}
          <button
            type="submit"
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#E99AC7] via-[#E8B84A] to-[#E8B84A] text-white font-bold text-sm shadow-sm cursor-pointer"
          >
            حفظ وبدء نبتة طفلي
          </button>
        </form>
      )}

      {/* ════════════════════════════════════════════════════════════════════
          الشاشة 2: نبتة طفلي — الرئيسية (عند وجود طفل مسجل)
         ════════════════════════════════════════════════════════════════════ */}
      {selectedChild && ageInfo && screen === 'main' && (
        <div className="space-y-4">
          {/* بطاقة الطفل */}
          <div className={`${cardBg} p-5 flex items-center justify-between gap-4`}>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#FDF2F8] border-2 border-[#5B5FEF] overflow-hidden flex items-center justify-center shrink-0">
                {selectedChild.photo_path ? (
                  <img
                    src={selectedChild.photo_path}
                    alt={selectedChild.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <SproutHeaderSvg size={30} />
                )}
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-lg">{selectedChild.name || 'طفلي'}</h3>
                <p className="text-xs font-bold text-[#4CAF82]">
                  العمر: {ageInfo.formattedArabic}
                </p>
                <p className="text-xs text-[#77798C]">
                  تاريخ الميلاد: {formatDateDMY(selectedChild.birth_date)}
                </p>
              </div>
            </div>

            {db.children.length > 1 && (
              <select
                value={selectedChild.id}
                onChange={(e) =>
                  updateDb((prev) => ({ ...prev, selectedChildId: e.target.value }))
                }
                className="px-3 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] border border-[#5B5FEF] text-xs font-bold"
              >
                {db.children.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name || 'طفلي'}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* النبتة التفاعلية SVG */}
          <div className={`${cardBg} p-6 flex flex-col items-center justify-center text-center space-y-3 overflow-hidden`}>
            <div className="py-4">
              <InteractiveChildPlantSvg
                stageIndex={ageInfo.stageIndex}
                visualScale={ageInfo.visualScale}
                animateOnMount={true}
              />
            </div>
            <span className="px-3.5 py-1 rounded-full bg-[#FDF2F8] text-[#4CAF82] text-xs font-bold border border-[#E99AC7]">
              {ageInfo.stageTitle}
            </span>
          </div>

          {/* العمر الحقيقي والتنبيه غير الطبي */}
          <div className={`${cardBg} p-5 text-center space-y-2.5`}>
            <div className="flex items-center justify-center gap-2">
              <SproutHeaderSvg size={20} />
              <h4 className="font-bold text-base">صغيرك يكبر يومًا بعد يوم</h4>
            </div>
            <p className="text-sm font-bold text-[#4CAF82]">
              عمره الآن: {ageInfo.formattedArabic}
            </p>
            <p className="text-xs text-[#77798C] leading-relaxed">{ageInfo.stageDescription}</p>
            <div className="inline-block px-4 py-2 rounded-xl bg-[#FDF2F8]/60 border border-[#E99AC7] text-[11px] font-bold text-[#25263A]">
              [النبتة تمثيل بصري لعمر طفلك وليست مقياسًا طبيًا]
            </div>
          </div>

          {/* الأزرار السريعة للانتقال للشاشات الفرعية */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setScreen('measurements')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <RulerSvg size={24} />
              <span className="font-bold text-xs">قياسات النمو</span>
              <span className="text-[11px] text-[#77798C]">{childMeasurements.length} قياس</span>
            </button>

            <button
              type="button"
              onClick={() => setScreen('charts')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <WeightScaleSvg size={24} />
              <span className="font-bold text-xs">الرسوم البيانية</span>
              <span className="text-[11px] text-[#77798C]">الطول • الوزن • الرأس</span>
            </button>

            <button
              type="button"
              onClick={() => setScreen('stages')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <HeadCircumferenceSvg size={24} />
              <span className="font-bold text-xs">مراحل النمو</span>
              <span className="text-[11px] text-[#77798C]">Timeline تعليمي</span>
            </button>

            <button
              type="button"
              onClick={() => setScreen('appointments')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <CalendarApptSvg size={24} />
              <span className="font-bold text-xs">المواعيد</span>
              <span className="text-[11px] text-[#77798C]">{childAppointments.length} موعد</span>
            </button>

            <button
              type="button"
              onClick={() => setScreen('notes')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <NoteBookSvg size={24} />
              <span className="font-bold text-xs">ملاحظاتي</span>
              <span className="text-[11px] text-[#77798C]">{childNotes.length} ملاحظة</span>
            </button>

            <button
              type="button"
              onClick={() => setScreen('activities')}
              className={`${cardBg} p-4 flex flex-col items-center justify-center gap-2 hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <ActivityLogSvg size={24} />
              <span className="font-bold text-xs">سجل الطفل</span>
              <span className="text-[11px] text-[#77798C]">{childActivities.length} حدث</span>
            </button>
          </div>
        </div>
      )}

      {/* الشاشات 3 و 4: قياسات النمو والرسوم البيانية */}
      {selectedChild && (screen === 'measurements' || screen === 'charts') && (
        <ChildMeasurementsAndChartsScreen
          mode={screen}
          onSwitchMode={(m) => setScreen(m)}
          measurements={childMeasurements}
          isDark={isDark}
          onSaveMeasurement={handleSaveMeasurement}
          onDeleteMeasurement={handleDeleteMeasurement}
        />
      )}

      {/* الشاشة 5: مراحل النمو (Timeline) */}
      {selectedChild && ageInfo && screen === 'stages' && (
        <ChildStagesTimelineScreen ageInfo={ageInfo} isDark={isDark} />
      )}

      {/* الشاشة 6: المواعيد */}
      {selectedChild && screen === 'appointments' && (
        <ChildAppointmentsScreen
          appointments={childAppointments}
          isDark={isDark}
          onSaveAppointment={handleSaveAppointment}
          onDeleteAppointment={handleDeleteAppointment}
          onToggleReminder={handleToggleAppointmentReminder}
        />
      )}

      {/* الشاشات 7 و 8 و 9: سجل الطفل، ملاحظاتي، أطفالي */}
      {selectedChild &&
        (screen === 'activities' || screen === 'notes' || screen === 'children_list') && (
          <ChildActivitiesNotesAndChildrenScreen
            subView={
              screen === 'activities'
                ? 'activities'
                : screen === 'notes'
                ? 'notes'
                : 'children'
            }
            activities={childActivities}
            notes={childNotes}
            childrenList={db.children}
            selectedChildId={selectedChild.id}
            isDark={isDark}
            onSaveNote={handleSaveNote}
            onDeleteNote={handleDeleteNote}
            onSelectChild={(id) => {
              updateDb((prev) => ({ ...prev, selectedChildId: id }));
              setScreen('main');
            }}
            onOpenAddChild={() => {
              resetAddChildForm();
              setScreen('add_child');
            }}
            onDeleteAllChildData={(id) => {
              const updated = deleteAllChildDataFromSqlite(db, id);
              setDb(updated);
              if (updated.children.length === 0) {
                setScreen('add_child');
              } else {
                setScreen('main');
              }
              showSuccessBanner('تم حذف كل بيانات الطفل من قاعدة البيانات');
            }}
          />
        )}
    </div>
  );
};
