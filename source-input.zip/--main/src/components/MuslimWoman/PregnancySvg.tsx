import React from 'react';

/**
 * أيقونات ورسوميات SVG حقيقية 100% لقسم الحمل «رحلتك» في رِفْق للمرأة
 * بدون أي إيموجي كأيقونات رئيسية - الهوية اللونية: ذهبي + وردي هادئ + بيج + بني
 */

const GOLD = '#E8B84A';
const SOFT_PINK = '#E99AC7';
const LIGHT_PINK = '#EEEEFF';
const BROWN = '#5B5FEF';
const GREEN = '#4CAF82';
const BLUE = '#72B7E8';

export const PregnancyJourneyHeaderSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="32" cy="32" r="29" fill={LIGHT_PINK} stroke={GOLD} strokeWidth="2.2" />
    <path
      d="M32 14C24.5 14 19 20 19 28.5C19 39.5 32 50 32 50C32 50 45 39.5 45 28.5C45 20 39.5 14 32 14Z"
      fill={SOFT_PINK}
      fillOpacity="0.45"
      stroke={BROWN}
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <circle cx="32" cy="26" r="5" fill={GOLD} />
    <path
      d="M26 35C26 31.8 28.7 29.5 32 29.5C35.3 29.5 38 31.8 38 35"
      stroke={BROWN}
      strokeWidth="2.2"
      strokeLinecap="round"
    />
  </svg>
);

export const FetusGrowthSvg: React.FC<{ size?: number; trimester?: number }> = ({
  size = 44,
  trimester = 2,
}) => {
  const accent = trimester === 1 ? SOFT_PINK : trimester === 2 ? GOLD : GREEN;
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="40" cy="40" r="36" fill={LIGHT_PINK} stroke={accent} strokeWidth="2.5" />
      <circle
        cx="40"
        cy="40"
        r="28"
        fill="#FFFFFF"
        stroke={SOFT_PINK}
        strokeWidth="1.5"
        strokeDasharray="4 3"
      />
      <circle cx="43" cy="28" r="8" fill={SOFT_PINK} stroke={BROWN} strokeWidth="2" />
      <path
        d="M36 35C30 37 27 44 30 50C33 55 41 56 46 52C50 49 49 42 44 38"
        fill={SOFT_PINK}
        fillOpacity="0.5"
        stroke={BROWN}
        strokeWidth="2.2"
        strokeLinecap="round"
      />
      <path d="M34 45C36 43 39 43 41 45" stroke={accent} strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
};

export const DoctorConsultSvg: React.FC<{ size?: number }> = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="24" cy="24" r="21" fill="#E3F2FD" stroke={BLUE} strokeWidth="2" />
    <path d="M24 14V34M14 24H34" stroke={BLUE} strokeWidth="3.2" strokeLinecap="round" />
  </svg>
);

export const WeightHealthSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="8" width="32" height="32" rx="8" fill={LIGHT_PINK} stroke={GOLD} strokeWidth="2.2" />
    <path d="M16 18C19 13 29 13 32 18L29 24H19L16 18Z" fill="#FFFFFF" stroke={BROWN} strokeWidth="1.8" />
    <path d="M24 23L27 17" stroke={GOLD} strokeWidth="2.2" strokeLinecap="round" />
    <path d="M16 32H32" stroke={BROWN} strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const KicksCounterSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="24" cy="24" r="20" fill={LIGHT_PINK} stroke={SOFT_PINK} strokeWidth="2.2" />
    <path
      d="M21 31C18 28 18 22 21 19C23.5 16.5 27 18 27 22C27 25 25 28 25 31C25 33.5 22.8 33 21 31Z"
      fill={GOLD}
      stroke={BROWN}
      strokeWidth="1.8"
    />
    <circle cx="19" cy="14" r="2" fill={BROWN} />
    <circle cx="23.5" cy="13" r="1.8" fill={BROWN} />
    <circle cx="27.5" cy="14" r="1.6" fill={BROWN} />
    <circle cx="30.5" cy="16.5" r="1.4" fill={BROWN} />
  </svg>
);

export const ContractionTimerSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="24" cy="26" r="16" fill="#FFFFFF" stroke={GOLD} strokeWidth="2.4" />
    <path d="M20 6H28M24 6V10" stroke={BROWN} strokeWidth="2.4" strokeLinecap="round" />
    <path
      d="M15 26H19L22 20L26 32L29 26H33"
      stroke={SOFT_PINK}
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const PregnancyAppointmentsSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="11" width="32" height="29" rx="6" fill="#FFFFFF" stroke={GOLD} strokeWidth="2.2" />
    <path d="M8 19H40" stroke={GOLD} strokeWidth="2" />
    <path d="M16 7V13M32 7V13" stroke={BROWN} strokeWidth="2.4" strokeLinecap="round" />
    <path d="M24 24V34M19 29H29" stroke={GREEN} strokeWidth="2.5" strokeLinecap="round" />
  </svg>
);

export const PregnancyNutritionSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M24 14C17 14 12 19 12 27C12 35 17.5 41 24 41C30.5 41 36 35 36 27C36 19 31 14 24 14Z"
      fill={LIGHT_PINK}
      stroke={GREEN}
      strokeWidth="2.2"
    />
    <path d="M24 14C24 10 27 7 31 7C31 11 28 14 24 14Z" fill={GREEN} />
    <path
      d="M20 26L23 29L29 23"
      stroke={GREEN}
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const PregnancyDuasFiqhSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M10 14C15 12 21 12 24 15C27 12 33 12 38 14V36C33 34 27 34 24 37C21 34 15 34 10 36V14Z"
      fill="#FFFFFF"
      stroke={GOLD}
      strokeWidth="2.2"
      strokeLinejoin="round"
    />
    <path d="M24 15V37" stroke={GOLD} strokeWidth="2" />
    <circle cx="24" cy="9" r="2.5" fill={SOFT_PINK} />
  </svg>
);

export const HospitalBagSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="8" y="16" width="32" height="24" rx="6" fill={LIGHT_PINK} stroke={BROWN} strokeWidth="2.2" />
    <path d="M18 16V12C18 9.8 19.8 8 22 8H26C28.2 8 30 9.8 30 12V16" stroke={BROWN} strokeWidth="2.2" />
    <path d="M24 23V33M19 28H29" stroke={GOLD} strokeWidth="2.6" strokeLinecap="round" />
  </svg>
);

export const PregnancyJournalSvg: React.FC<{ size?: number }> = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="11" y="8" width="26" height="32" rx="4" fill="#FFFFFF" stroke={SOFT_PINK} strokeWidth="2.2" />
    <path d="M17 16H31M17 22H31M17 28H25" stroke={BROWN} strokeWidth="2" strokeLinecap="round" />
    <circle cx="31" cy="31" r="4" fill={GOLD} />
  </svg>
);

export const WaterDropSvg: React.FC<{ size?: number }> = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M24 8C24 8 12 22 12 30C12 36.6 17.4 42 24 42C30.6 42 36 36.6 36 30C36 22 24 8 24 8Z"
      fill="#E3F2FD"
      stroke={BLUE}
      strokeWidth="2.2"
    />
  </svg>
);
