import React, { useState, useEffect } from 'react';
import {
  PregnancyData,
} from './womanTypes';
import {
  PregnancyDatabaseState,
  PregnancyProfileRow,
  loadPregnancyDb,
  savePregnancyDb,
  wipePregnancyDb,
  calculatePregnancyStats,
  formatArabicDateIso,
  scheduleRealPregnancyNotification,
  checkAndFirePregnancyNotifications,
  MANDATORY_MEDICAL_DISCLAIMER,
  PREGNANCY_40_WEEKS,
  RECOMMENDED_CHECKUPS,
  ESSENTIAL_NUTRIENTS,
  FOODS_TO_AVOID,
  URGENT_WARNING_SIGNS,
  PREGNANCY_DUAS_AND_FIQH,
  DEFAULT_HOSPITAL_BAG,
} from '../../utils/pregnancySqlite';
import {
  PregnancyJourneyHeaderSvg,
  FetusGrowthSvg,
  DoctorConsultSvg,
  WeightHealthSvg,
  KicksCounterSvg,
  ContractionTimerSvg,
  PregnancyAppointmentsSvg,
  PregnancyNutritionSvg,
  PregnancyDuasFiqhSvg,
  HospitalBagSvg,
  PregnancyJournalSvg,
  WaterDropSvg,
} from './PregnancySvg';

export type PregnancySubScreen =
  | 'main'
  | 'setup'
  | 'weeks'
  | 'health'
  | 'kicks'
  | 'contractions'
  | 'appointments'
  | 'nutrition'
  | 'duas_fiqh'
  | 'bag'
  | 'journal'
  | 'settings';

interface PregnancyViewProps {
  pregnancy: PregnancyData;
  onUpdatePregnancy: (data: PregnancyData) => void;
  onBackToWomanHub?: () => void;
}

const AVAILABLE_SYMPTOMS = [
  'غثيان صباحي',
  'إرهاق ورغبة في النوم',
  'حرقة المعدة',
  'ألم أسفل الظهر',
  'تقلصات خفيفة',
  'تورم خفيف في القدمين',
  'تقلب المزاج',
  'صداع خفيف',
  'ضيق تنفس خفيف عند المجهود',
  'كثرة التبول',
];

const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const PregnancyView: React.FC<PregnancyViewProps> = ({
  pregnancy,
  onUpdatePregnancy,
  onBackToWomanHub,
}) => {
  const [db, setDb] = useState<PregnancyDatabaseState>(() => {
    const loaded = loadPregnancyDb();
    // إذا كان هناك حمل قديم محفوظ في state الأب ولم يُنقل بعد، نزامنه تلقائياً
    if (!loaded.profile && pregnancy.hasActivePregnancy && pregnancy.lmpDate) {
      const lmp = new Date(pregnancy.lmpDate + 'T00:00:00');
      const due = new Date(lmp.getTime() + 280 * 24 * 60 * 60 * 1000);
      const dueIso = due.toISOString().slice(0, 10);
      const pid = Date.now();
      const bagItems = Object.entries(DEFAULT_HOSPITAL_BAG).flatMap(([cat, list], idx) =>
        list.map((name, i) => ({
          id: pid + idx * 100 + i,
          pregnancyId: pid,
          category: cat as 'mother' | 'baby' | 'documents',
          itemName: name,
          isPacked: false,
          createdAt: new Date().toISOString(),
        }))
      );
      const synced: PregnancyDatabaseState = {
        ...loaded,
        profile: {
          id: pid,
          calculationMethod: 'lmp',
          lmpDate: pregnancy.lmpDate,
          dueDate: dueIso,
          bloodType: '',
          doctorName: '',
          hospitalName: '',
          createdAt: new Date().toISOString(),
        },
        bagItems,
      };
      savePregnancyDb(synced);
      return synced;
    }
    return loaded;
  });

  const [subScreen, setSubScreen] = useState<PregnancySubScreen>(() =>
    db.profile ? 'main' : 'setup'
  );
  const [statusBanner, setStatusBanner] = useState<{ text: string; isError?: boolean } | null>(
    null
  );

  // قفل الخصوصية PIN
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => !loadPregnancyDb().pinEnabled);
  const [pinInput, setPinInput] = useState('');
  const [newPinCode, setNewPinCode] = useState('');

  const calc = db.profile ? calculatePregnancyStats(db.profile) : null;
  const [previewWeek, setPreviewWeek] = useState<number>(calc?.currentWeek ?? 20);

  useEffect(() => {
    if (calc) {
      setPreviewWeek(calc.currentWeek);
    }
  }, [db.profile?.lmpDate, db.profile?.dueDate]);

  // فحص الإشعارات الحقيقية دورياً
  useEffect(() => {
    checkAndFirePregnancyNotifications();
    const timer = setInterval(() => {
      checkAndFirePregnancyNotifications();
    }, 25000);
    return () => clearInterval(timer);
  }, []);

  const updateDb = (updater: (prev: PregnancyDatabaseState) => PregnancyDatabaseState) => {
    setDb((prev) => {
      const next = updater(prev);
      savePregnancyDb(next);
      return next;
    });
  };

  const showBanner = (text: string, isError = false) => {
    setStatusBanner({ text, isError });
    setTimeout(() => {
      setStatusBanner((cur) => (cur?.text === text ? null : cur));
    }, 3500);
  };

  // ── حقول شاشة إعداد الحمل ──
  const [calcMethod, setCalcMethod] = useState<'lmp' | 'due_date'>('lmp');
  const [dateInput, setDateInput] = useState('');
  const [preWeightInput, setPreWeightInput] = useState('');
  const [heightInput, setHeightInput] = useState('');
  const [bloodTypeInput, setBloodTypeInput] = useState('');
  const [doctorInput, setDoctorInput] = useState('');
  const [hospitalInput, setHospitalInput] = useState('');

  // ── حقول شاشة الصحة والوزن والأعراض ──
  const [weightKgInput, setWeightKgInput] = useState('');
  const [bpInput, setBpInput] = useState('');
  const [weightNotesInput, setWeightNotesInput] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [symptomSeverity, setSymptomSeverity] = useState<'mild' | 'moderate' | 'severe'>('mild');
  const [waterCups, setWaterCups] = useState(0);
  const [folicTaken, setFolicTaken] = useState(false);
  const [ironTaken, setIronTaken] = useState(false);
  const [calciumTaken, setCalciumTaken] = useState(false);

  // ── عداد حركات الجنين ──
  const [kickActive, setKickActive] = useState(false);
  const [kickStartMs, setKickStartMs] = useState<number | null>(null);
  const [kickStartTimeStr, setKickStartTimeStr] = useState('');
  const [kickCount, setKickCount] = useState(0);
  const [kickElapsedSec, setKickElapsedSec] = useState(0);

  useEffect(() => {
    if (!kickActive) return;
    const t = setInterval(() => {
      setKickElapsedSec((s) => s + 1);
    }, 1000);
    return () => clearInterval(t);
  }, [kickActive]);

  // ── مؤقت الانقباضات ──
  const [contractionActive, setContractionActive] = useState(false);
  const [contractionStartMs, setContractionStartMs] = useState<number | null>(null);
  const [lastContractionStartMs, setLastContractionStartMs] = useState<number | null>(null);
  const [contractionElapsedSec, setContractionElapsedSec] = useState(0);
  const [contractionIntensity, setContractionIntensity] = useState<'mild' | 'moderate' | 'strong'>(
    'moderate'
  );

  useEffect(() => {
    if (!contractionActive) return;
    const t = setInterval(() => {
      setContractionElapsedSec((s) => s + 1);
    }, 1000);
    return () => clearInterval(t);
  }, [contractionActive]);

  // ── حقول مواعيد الطبيبة ──
  const [apptTitle, setApptTitle] = useState('');
  const [apptDoctor, setApptDoctor] = useState('');
  const [apptType, setApptType] = useState<'checkup' | 'ultrasound' | 'lab' | 'vaccine'>('checkup');
  const [apptDate, setApptDate] = useState('');
  const [apptTime, setApptTime] = useState('10:00');
  const [apptReminder, setApptReminder] = useState(true);
  const [apptNotes, setApptNotes] = useState('');

  // ── حقول حقيبة الولادة ──
  const [bagTab, setBagTab] = useState<'mother' | 'baby' | 'documents'>('mother');
  const [customBagItem, setCustomBagItem] = useState('');

  // ── حقول مذكرات رحلتي ──
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');

  // ── فلاتر الأسابيع والأدعية ──
  const [weeksFilter, setWeeksFilter] = useState<0 | 1 | 2 | 3>(0);
  const [duasFilter, setDuasFilter] = useState<'all' | 'dua' | 'fiqh'>('all');
  const [showWipeConfirm, setShowWipeConfirm] = useState(false);

  const todayIso = () => new Date().toISOString().slice(0, 10);
  const formatMmSs = (sec: number) => {
    const m = String(Math.floor(sec / 60)).padStart(2, '0');
    const s = String(sec % 60).padStart(2, '0');
    return `${m}:${s}`;
  };

  // شريط التنبيه الطبي الإلزامي
  const renderMedicalDisclaimer = () => (
    <div className="bg-[#E3F2FD] border border-[#72B7E8]/35 rounded-2xl p-3.5 flex items-start gap-3 text-right">
      <div className="shrink-0 mt-0.5">
        <DoctorConsultSvg size={22} />
      </div>
      <div className="space-y-0.5">
        <div className="text-xs font-bold text-[#72B7E8]">استشيري الطبيب المختص دائماً</div>
        <p className="text-[11px] text-[#25263A] leading-relaxed">{MANDATORY_MEDICAL_DISCLAIMER}</p>
      </div>
    </div>
  );

  // شاشة القفل برمز PIN
  if (!isUnlocked && db.pinEnabled) {
    return (
      <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] max-w-md mx-auto text-center space-y-4">
        <div className="flex justify-center">
          <PregnancyJourneyHeaderSvg size={54} />
        </div>
        <h3 className="text-base font-bold text-[#25263A]">رحلتكِ — حماية الخصوصية</h3>
        <p className="text-xs text-[#77798C]">أدخلي رمز الحماية الخاص بكِ لفتح سجلات الحمل</p>
        <input
          type="password"
          maxLength={6}
          value={pinInput}
          onChange={(e) => setPinInput(e.target.value)}
          placeholder="••••"
          className="w-full p-3 text-center text-lg tracking-widest border border-[#E6E6F0] rounded-xl outline-hidden"
        />
        <button
          type="button"
          onClick={() => {
            if (pinInput.trim() === db.pinCode) {
              setIsUnlocked(true);
              setPinInput('');
            } else {
              showBanner('رمز الحماية غير صحيح', true);
            }
          }}
          className="w-full bg-[#5B5FEF] text-white py-3 rounded-xl font-bold text-xs cursor-pointer"
        >
          فتح رحلتكِ
        </button>
      </div>
    );
  }

  // حفظ إعداد الحمل الجديد
  const handleSaveSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dateInput) {
      showBanner('يرجى اختيار التاريخ أولاً لحساب الحمل تلقائياً', true);
      return;
    }

    const chosenMs = new Date(dateInput + 'T00:00:00').getTime();
    const nowMs = Date.now();
    if (calcMethod === 'lmp' && chosenMs > nowMs) {
      showBanner('تاريخ أول يوم لآخر دورة لا يمكن أن يكون في المستقبل', true);
      return;
    }

    const preW = preWeightInput.trim() ? Number(preWeightInput) : undefined;
    const hCm = heightInput.trim() ? Number(heightInput) : undefined;
    if ((preW !== undefined && (preW <= 25 || preW > 250)) || (hCm !== undefined && (hCm <= 100 || hCm > 220))) {
      showBanner('يرجى إدخال قيم صحيحة وموجبة للوزن والطول', true);
      return;
    }

    let lmpIso = dateInput;
    let dueIso = dateInput;
    if (calcMethod === 'lmp') {
      const d = new Date(chosenMs + 280 * 24 * 60 * 60 * 1000);
      dueIso = d.toISOString().slice(0, 10);
    } else {
      const l = new Date(chosenMs - 280 * 24 * 60 * 60 * 1000);
      lmpIso = l.toISOString().slice(0, 10);
    }

    const pid = Date.now();
    const profile: PregnancyProfileRow = {
      id: pid,
      calculationMethod: calcMethod,
      lmpDate: lmpIso,
      dueDate: dueIso,
      prePregnancyWeight: preW,
      heightCm: hCm,
      bloodType: bloodTypeInput,
      doctorName: doctorInput.trim(),
      hospitalName: hospitalInput.trim(),
      createdAt: new Date().toISOString(),
    };

    updateDb((prev) => {
      const existingBag =
        prev.bagItems.length > 0
          ? prev.bagItems
          : Object.entries(DEFAULT_HOSPITAL_BAG).flatMap(([cat, list], idx) =>
              list.map((itemName, i) => ({
                id: pid + idx * 100 + i,
                pregnancyId: pid,
                category: cat as 'mother' | 'baby' | 'documents',
                itemName,
                isPacked: false,
                createdAt: new Date().toISOString(),
              }))
            );

      const initialWeights =
        preW !== undefined
          ? [
              {
                id: pid + 1,
                pregnancyId: pid,
                date: lmpIso,
                week: 1,
                weightKg: preW,
                bloodPressure: '',
                notes: 'الوزن الابتدائي قبل الحمل',
                createdAt: new Date().toISOString(),
              },
            ]
          : prev.weights;

      return {
        ...prev,
        profile,
        bagItems: existingBag,
        weights: initialWeights,
      };
    });

    onUpdatePregnancy({
      hasActivePregnancy: true,
      lmpDate: lmpIso,
      notes: '',
      appointments: [],
    });

    setSubScreen('main');
    showBanner('تم حساب عمر الحمل وبدء رحلتكِ بنجاح');
  };

  const getHeaderTitle = () => {
    switch (subScreen) {
      case 'setup':
        return 'بدء رحلتكِ';
      case 'weeks':
        return 'تطور الجنين (40 أسبوعاً)';
      case 'health':
        return 'صحتكِ والوزن والأعراض';
      case 'kicks':
        return 'عدّاد حركات الجنين';
      case 'contractions':
        return 'مؤقّت الانقباضات';
      case 'appointments':
        return 'مواعيد الطبيبة والفحوصات';
      case 'nutrition':
        return 'التغذية والفيتامينات';
      case 'duas_fiqh':
        return 'أدعية وفقه الحامل';
      case 'bag':
        return 'حقيبة الولادة';
      case 'journal':
        return 'مذكرات رحلتي';
      case 'settings':
        return 'إعدادات رحلتكِ';
      default:
        return 'رحلتك';
    }
  };

  return (
    <div className="space-y-5 animate-fade-in text-[#25263A]">
      {/* 【الشريط العلوي: رجوع + "رحلتك" + إعدادات】 */}
      <div className="bg-white rounded-2xl px-4 py-3.5 border border-[#E6E6F0] flex items-center justify-between">
        <button
          type="button"
          onClick={() => {
            if (subScreen !== 'main' && db.profile) {
              setSubScreen('main');
            } else if (onBackToWomanHub) {
              onBackToWomanHub();
            }
          }}
          className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#FDF2F8] text-xs font-bold text-[#25263A] transition-colors cursor-pointer"
        >
          رجوع
        </button>

        <div className="flex items-center gap-2">
          <PregnancyJourneyHeaderSvg size={26} />
          <h2 className="text-base sm:text-lg font-bold text-[#25263A]">{getHeaderTitle()}</h2>
        </div>

        {db.profile ? (
          <button
            type="button"
            onClick={() => setSubScreen('settings')}
            className="px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#FDF2F8] text-xs font-bold text-[#4145C7] border border-[#E6E6F0] transition-colors cursor-pointer"
          >
            إعدادات
          </button>
        ) : (
          <div className="w-14" />
        )}
      </div>

      {/* شريط رسائل التأكيد */}
      {statusBanner && (
        <div
          className={`p-3 rounded-xl text-xs font-bold text-white ${
            statusBanner.isError ? 'bg-rose-700' : 'bg-[#4CAF82]'
          }`}
        >
          {statusBanner.text}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          شاشة البداية (Empty State) — إعداد وحساب الحمل التلقائي
         ══════════════════════════════════════════════════════════════════════ */}
      {(!db.profile || subScreen === 'setup') && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] space-y-5">
            <div className="text-center space-y-2">
              <div className="flex justify-center">
                <FetusGrowthSvg size={64} />
              </div>
              <h3 className="text-lg font-bold text-[#25263A]">ابدئي متابعة رحلة حملكِ المباركة</h3>
              <p className="text-xs text-[#77798C] max-w-md mx-auto leading-relaxed">
                لا توجد بيانات حمل مسجلة حالياً. أدخلي تاريخ أول يوم لآخر دورة شهرية أو تاريخ الولادة المتوقع ليحسب التطبيق عمر الحمل ومراحل نمو الجنين تلقائياً وبخصوصية تامة 100% على جهازكِ.
              </p>
            </div>

            <form onSubmit={handleSaveSetup} className="space-y-4 max-w-lg mx-auto text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setCalcMethod('lmp');
                    setDateInput('');
                  }}
                  className={`py-2.5 px-3 rounded-xl font-bold border transition-colors cursor-pointer ${
                    calcMethod === 'lmp'
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-white text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  تاريخ أول يوم لآخر دورة (LMP)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCalcMethod('due_date');
                    setDateInput('');
                  }}
                  className={`py-2.5 px-3 rounded-xl font-bold border transition-colors cursor-pointer ${
                    calcMethod === 'due_date'
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-white text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  تاريخ الولادة المتوقع (EDD)
                </button>
              </div>

              <div>
                <label className="block font-bold text-[#25263A] mb-1">
                  {calcMethod === 'lmp'
                    ? 'تاريخ أول يوم من آخر دورة شهرية (إلزامي):'
                    : 'تاريخ الولادة المتوقع الذي حددته الطبيبة (إلزامي):'}
                </label>
                <input
                  type="date"
                  required
                  value={dateInput}
                  onChange={(e) => setDateInput(e.target.value)}
                  className="w-full p-3 rounded-xl border border-[#E6E6F0] bg-[#F7F7FC]/40 text-sm outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#25263A] mb-1">
                    الوزن قبل الحمل (كجم - اختياري):
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={preWeightInput}
                    onChange={(e) => setPreWeightInput(e.target.value)}
                    placeholder="مثال: 62"
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#25263A] mb-1">
                    الطول (سم - اختياري):
                  </label>
                  <input
                    type="number"
                    value={heightInput}
                    onChange={(e) => setHeightInput(e.target.value)}
                    placeholder="مثال: 162"
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#25263A] mb-1">فصيلة الدم (اختياري):</label>
                  <select
                    value={bloodTypeInput}
                    onChange={(e) => setBloodTypeInput(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-stone-300 bg-white"
                  >
                    <option value="">غير محدد</option>
                    {BLOOD_TYPES.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#25263A] mb-1">
                    اسم الطبيبة (اختياري):
                  </label>
                  <input
                    type="text"
                    value={doctorInput}
                    onChange={(e) => setDoctorInput(e.target.value)}
                    placeholder="د. ..."
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#25263A] mb-1">
                    المستشفى / العيادة (اختياري):
                  </label>
                  <input
                    type="text"
                    value={hospitalInput}
                    onChange={(e) => setHospitalInput(e.target.value)}
                    placeholder="اسم المستشفى"
                    className="w-full p-2.5 rounded-xl border border-stone-300"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#5B5FEF] hover:bg-[#4145C7] text-white py-3.5 rounded-xl font-bold text-sm transition-colors cursor-pointer"
              >
                حساب الحمل وبدء رحلتكِ
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة الرئيسية — «رحلتك» (بطاقة الأسبوع + بطاقة الجنين + الأقسام)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'main' && (
        <div className="space-y-5">
          {renderMedicalDisclaimer()}

          {/* 【بطاقة الأسبوع】 */}
          <div className="bg-gradient-to-br from-white to-[#FDF2F8]/60 rounded-3xl p-6 border border-[#5B5FEF] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl sm:text-3xl font-black text-[#25263A]">
                  الأسبوع {calc.currentWeek}
                </div>
                <div className="text-sm font-bold text-[#5B5FEF] mt-0.5">
                  {calc.trimesterTitle}
                  {calc.extraDays > 0 ? ` · و ${calc.extraDays} أيام` : ''}
                </div>
              </div>
              <FetusGrowthSvg size={60} trimester={calc.trimester} />
            </div>

            {/* شريط التقدم المئوي */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-[#25263A]">تقدم رحلة الحمل</span>
                <span className="text-[#5B5FEF]">{calc.progressPercent}%</span>
              </div>
              <div className="w-full h-3.5 bg-[#F7F7FC] rounded-full overflow-hidden border border-[#E6E6F0]">
                <div
                  className="h-full bg-[#5B5FEF] rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(2, calc.progressPercent)}%` }}
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs font-bold">
              <span className="text-[#4CAF82]">باقي {calc.remainingDays} يوم</span>
              <span className="text-[#25263A]">
                تاريخ الولادة المتوقع: {formatArabicDateIso(calc.dueDate)}
              </span>
            </div>
          </div>

          {/* 【بطاقة الجنين】 */}
          {(() => {
            const weekInfo =
              PREGNANCY_40_WEEKS[Math.max(0, Math.min(39, previewWeek - 1))];
            return (
              <div className="bg-white rounded-3xl p-5 border border-[#E99AC7] space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FetusGrowthSvg size={44} trimester={weekInfo.trimester} />
                    <div>
                      <h3 className="text-sm sm:text-base font-bold text-[#25263A]">
                        حجم الجنين — الأسبوع {weekInfo.week}
                      </h3>
                      <p className="text-xs font-bold text-[#5B5FEF]">
                        يقارب حجم: {weekInfo.sizeComparison}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={previewWeek <= 1}
                      onClick={() => setPreviewWeek((w) => Math.max(1, w - 1))}
                      className="px-2.5 py-1 rounded-lg bg-[#F7F7FC] disabled:opacity-40 text-xs font-bold cursor-pointer"
                    >
                      السابق
                    </button>
                    <button
                      type="button"
                      disabled={previewWeek >= 40}
                      onClick={() => setPreviewWeek((w) => Math.min(40, w + 1))}
                      className="px-2.5 py-1 rounded-lg bg-[#F7F7FC] disabled:opacity-40 text-xs font-bold cursor-pointer"
                    >
                      التالي
                    </button>
                  </div>
                </div>

                {previewWeek !== calc.currentWeek && (
                  <button
                    type="button"
                    onClick={() => setPreviewWeek(calc.currentWeek)}
                    className="text-xs font-bold text-[#5B5FEF] underline cursor-pointer"
                  >
                    العودة لأسبوعي الحالي (الأسبوع {calc.currentWeek})
                  </button>
                )}

                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="bg-[#F7F7FC]/70 rounded-xl p-3">
                    <div className="text-[11px] text-[#77798C]">الطول التقريبي</div>
                    <div className="text-xs font-bold text-[#25263A] mt-0.5">
                      {weekInfo.lengthEstimate}
                    </div>
                  </div>
                  <div className="bg-[#F7F7FC]/70 rounded-xl p-3">
                    <div className="text-[11px] text-[#77798C]">الوزن التقريبي</div>
                    <div className="text-xs font-bold text-[#25263A] mt-0.5">
                      {weekInfo.weightEstimate}
                    </div>
                  </div>
                </div>

                <div className="space-y-2.5 text-xs leading-relaxed">
                  <div>
                    <span className="font-bold text-[#25263A]">تطور الجنين هذا الأسبوع: </span>
                    <span className="text-[#25263A]">{weekInfo.fetalDevelopment}</span>
                  </div>
                  <div>
                    <span className="font-bold text-[#25263A]">تغيرات جسم الأم: </span>
                    <span className="text-[#25263A]">{weekInfo.motherChanges}</span>
                  </div>
                  <div>
                    <span className="font-bold text-[#4CAF82]">إرشاد الأسبوع الطبي: </span>
                    <span className="text-[#25263A]">{weekInfo.medicalTip}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between text-[11px] text-[#77798C]">
                  <span>المصدر: {weekInfo.medicalSource}</span>
                  <button
                    type="button"
                    onClick={() => setSubScreen('weeks')}
                    className="font-bold text-[#5B5FEF] hover:underline cursor-pointer"
                  >
                    استعراض الـ 40 أسبوعاً كاملة
                  </button>
                </div>
              </div>
            );
          })()}

          {/* شبكة أقسام وأدوات متابعة الحمل الكاملة */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-bold text-[#25263A]">أقسام وأدوات رحلتكِ</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                {
                  id: 'weeks' as PregnancySubScreen,
                  title: 'مراحل الـ 40 أسبوعاً',
                  desc: 'تطور الجنين والأم أسبوعاً بأسبوع',
                  icon: <FetusGrowthSvg size={28} />,
                },
                {
                  id: 'health' as PregnancySubScreen,
                  title: 'صحتكِ والوزن والأعراض',
                  desc:
                    db.weights.length === 0
                      ? 'سجلي وزنكِ وأعراضكِ اليومية'
                      : `آخر وزن: ${db.weights[db.weights.length - 1].weightKg} كجم`,
                  icon: <WeightHealthSvg size={28} />,
                },
                {
                  id: 'kicks' as PregnancySubScreen,
                  title: 'عدّاد حركات الجنين',
                  desc:
                    db.kicks.length === 0
                      ? 'حساب وقت 10 حركات للجنين'
                      : `${db.kicks.length} جلسات مسجلة`,
                  icon: <KicksCounterSvg size={28} />,
                },
                {
                  id: 'contractions' as PregnancySubScreen,
                  title: 'مؤقّت الانقباضات',
                  desc:
                    db.contractions.length === 0
                      ? 'حساب مدة وتكرار الطلق'
                      : `${db.contractions.length} انقباضات مسجلة`,
                  icon: <ContractionTimerSvg size={28} />,
                },
                {
                  id: 'appointments' as PregnancySubScreen,
                  title: 'مواعيد الطبيبة والفحوصات',
                  desc:
                    db.appointments.filter((a) => !a.isCompleted).length === 0
                      ? 'جدولة المواعيد بتذكير حقيقي'
                      : `${db.appointments.filter((a) => !a.isCompleted).length} مواعيد قادمة`,
                  icon: <PregnancyAppointmentsSvg size={28} />,
                },
                {
                  id: 'nutrition' as PregnancySubScreen,
                  title: 'التغذية والفيتامينات',
                  desc: 'العناصر الأساسية والأطعمة الممنوعة',
                  icon: <PregnancyNutritionSvg size={28} />,
                },
                {
                  id: 'duas_fiqh' as PregnancySubScreen,
                  title: 'أدعية وفقه الحامل',
                  desc: 'أدعية مأثورة وأحكام الحمل والولادة',
                  icon: <PregnancyDuasFiqhSvg size={28} />,
                },
                {
                  id: 'bag' as PregnancySubScreen,
                  title: 'حقيبة الولادة',
                  desc: `${db.bagItems.filter((i) => i.isPacked).length} من ${db.bagItems.length} جاهز`,
                  icon: <HospitalBagSvg size={28} />,
                },
                {
                  id: 'journal' as PregnancySubScreen,
                  title: 'مذكرات رحلتي',
                  desc:
                    db.notes.length === 0
                      ? 'دوني مشاعركِ ورسائلكِ لجنينكِ'
                      : `${db.notes.length} مذكرات محفوظة`,
                  icon: <PregnancyJournalSvg size={28} />,
                },
              ].map((card) => (
                <button
                  key={card.id}
                  type="button"
                  onClick={() => setSubScreen(card.id)}
                  className="bg-white rounded-2xl p-4 border border-[#E6E6F0] hover:border-[#5B5FEF] text-right flex flex-col justify-between gap-2.5 transition-all cursor-pointer"
                >
                  <div>{card.icon}</div>
                  <div>
                    <div className="text-xs font-bold text-[#25263A]">{card.title}</div>
                    <div className="text-[11px] text-[#77798C] mt-0.5 line-clamp-1">
                      {card.desc}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 2: تطور الجنين أسبوعاً بأسبوع (40 أسبوعاً كاملة)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'weeks' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 0 as const, label: 'الكل (40 أسبوعاً)' },
              { id: 1 as const, label: 'الثلث الأول (1-13)' },
              { id: 2 as const, label: 'الثلث الثاني (14-27)' },
              { id: 3 as const, label: 'الثلث الثالث (28-40)' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setWeeksFilter(tab.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                  weeksFilter === tab.id
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-white text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {PREGNANCY_40_WEEKS.filter(
              (w) => weeksFilter === 0 || w.trimester === weeksFilter
            ).map((w) => {
              const isCurrent = w.week === calc.currentWeek;
              return (
                <div
                  key={w.week}
                  className={`bg-white rounded-2xl p-4 border space-y-2 ${
                    isCurrent ? 'border-2 border-[#5B5FEF]' : 'border-[#E99AC7]/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-[#25263A]">
                      الأسبوع {w.week} — {w.sizeComparison}
                    </h4>
                    {isCurrent && (
                      <span className="text-xs font-bold text-[#4CAF82]">أسبوعكِ الحالي</span>
                    )}
                  </div>
                  <div className="text-xs font-bold text-[#5B5FEF]">
                    الطول التقريبي: {w.lengthEstimate} · الوزن التقريبي: {w.weightEstimate}
                  </div>
                  <p className="text-xs text-[#25263A] leading-relaxed">
                    <strong>الجنين:</strong> {w.fetalDevelopment}
                  </p>
                  <p className="text-xs text-[#25263A] leading-relaxed">
                    <strong>الأم:</strong> {w.motherChanges}
                  </p>
                  <p className="text-xs text-[#4CAF82] leading-relaxed">
                    <strong>نصيحة طبية:</strong> {w.medicalTip}
                  </p>
                  <div className="text-[11px] text-[#77798C]">المصدر: {w.medicalSource}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 3: صحتكِ، منحنى الوزن، الأعراض اليومية، وعلامات التحذير
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'health' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}

          {/* تسجيل وزن جديد */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3">
            <div className="flex items-center gap-2">
              <WeightHealthSvg size={24} />
              <h3 className="text-sm font-bold text-[#25263A]">تسجيل الوزن وضغط الدم</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <input
                type="number"
                step="0.1"
                value={weightKgInput}
                onChange={(e) => setWeightKgInput(e.target.value)}
                placeholder="الوزن الحالي (كجم)*"
                className="p-2.5 rounded-xl border border-stone-300"
              />
              <input
                type="text"
                value={bpInput}
                onChange={(e) => setBpInput(e.target.value)}
                placeholder="ضغط الدم (مثال 120/80)"
                className="p-2.5 rounded-xl border border-stone-300"
              />
              <input
                type="text"
                value={weightNotesInput}
                onChange={(e) => setWeightNotesInput(e.target.value)}
                placeholder="ملاحظات (اختياري)"
                className="p-2.5 rounded-xl border border-stone-300"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                const w = Number(weightKgInput);
                if (!weightKgInput.trim() || isNaN(w) || w <= 25 || w > 250) {
                  showBanner('يرجى إدخال وزن صحيح بالكيلوجرام', true);
                  return;
                }
                updateDb((prev) => ({
                  ...prev,
                  weights: [
                    ...prev.weights,
                    {
                      id: Date.now(),
                      pregnancyId: prev.profile!.id,
                      date: todayIso(),
                      week: calc.currentWeek,
                      weightKg: w,
                      bloodPressure: bpInput.trim(),
                      notes: weightNotesInput.trim(),
                      createdAt: new Date().toISOString(),
                    },
                  ],
                }));
                setWeightKgInput('');
                setBpInput('');
                setWeightNotesInput('');
                showBanner('تم حفظ القياس في سجل الوزن');
              }}
              className="w-full bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold text-xs cursor-pointer"
            >
              حفظ القياس في السجل
            </button>
          </div>

          {/* منحنى الوزن التفاعلي (SVG Chart) */}
          <div className="bg-white rounded-2xl p-5 border border-[#E99AC7] space-y-3">
            <h4 className="text-sm font-bold text-[#25263A]">منحنى تغير الوزن خلال الحمل</h4>
            {db.weights.length === 0 ? (
              <p className="text-xs text-[#77798C] text-center py-6">
                لا توجد قراءات وزن مسجلة بعد. أضيفي وزنكِ أعلاه ليظهر المنحنى البياني.
              </p>
            ) : (
              <div className="space-y-3">
                {(() => {
                  const vals = db.weights.map((w) => w.weightKg);
                  const minW = Math.min(...vals) - 2;
                  const maxW = Math.max(...vals) + 2;
                  const range = Math.max(4, maxW - minW);
                  const pts = db.weights.map((w, idx) => {
                    const x =
                      db.weights.length === 1
                        ? 160
                        : 25 + (idx / (db.weights.length - 1)) * 270;
                    const y = 110 - ((w.weightKg - minW) / range) * 85;
                    return { x, y, w };
                  });
                  const poly = pts.map((p) => `${p.x},${p.y}`).join(' ');
                  return (
                    <svg viewBox="0 0 320 130" className="w-full h-36 bg-[#F7F7FC]/40 rounded-xl">
                      <polyline
                        fill="none"
                        stroke="#5B5FEF"
                        strokeWidth="3"
                        points={poly}
                      />
                      {pts.map((p) => (
                        <g key={p.w.id}>
                          <circle cx={p.x} cy={p.y} r="4.5" fill="#25263A" />
                          <text
                            x={p.x}
                            y={p.y - 8}
                            textAnchor="middle"
                            fontSize="9"
                            fill="#25263A"
                          >
                            {p.w.weightKg}كجم
                          </text>
                        </g>
                      ))}
                    </svg>
                  );
                })()}
                <div className="divide-y divide-[#E6E6F0] text-xs">
                  {[...db.weights].reverse().map((w) => (
                    <div key={w.id} className="py-2 flex items-center justify-between">
                      <div>
                        <span className="font-bold">{w.weightKg} كجم</span> · الأسبوع {w.week} ·{' '}
                        <span className="text-[#77798C]">{formatArabicDateIso(w.date)}</span>
                        {w.bloodPressure ? ` · الضغط: ${w.bloodPressure}` : ''}
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          updateDb((prev) => ({
                            ...prev,
                            weights: prev.weights.filter((item) => item.id !== w.id),
                          }))
                        }
                        className="text-rose-600 text-[11px] font-bold cursor-pointer"
                      >
                        حذف
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* تسجيل الأعراض اليومية والماء والفيتامينات */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-4 text-xs">
            <h4 className="text-sm font-bold text-[#25263A]">
              تسجيل الأعراض اليومية والفيتامينات والماء
            </h4>
            <div className="flex flex-wrap gap-2">
              {AVAILABLE_SYMPTOMS.map((sym) => {
                const active = selectedSymptoms.includes(sym);
                return (
                  <button
                    key={sym}
                    type="button"
                    onClick={() =>
                      setSelectedSymptoms((prev) =>
                        prev.includes(sym) ? prev.filter((s) => s !== sym) : [...prev, sym]
                      )
                    }
                    className={`px-3 py-1.5 rounded-xl font-bold border cursor-pointer ${
                      active
                        ? 'bg-[#FDF2F8] text-[#25263A] border-[#5B5FEF]'
                        : 'bg-[#F7F7FC]/60 text-[#77798C] border-[#E6E6F0]'
                    }`}
                  >
                    {sym}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between bg-[#F7F7FC]/60 p-3 rounded-xl">
              <div className="flex items-center gap-2 font-bold">
                <WaterDropSvg size={20} />
                <span>أكواب الماء اليوم: {waterCups} كوب</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setWaterCups((c) => Math.max(0, c - 1))}
                  className="w-7 h-7 rounded-lg bg-white border border-stone-300 font-bold cursor-pointer"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setWaterCups((c) => c + 1)}
                  className="w-7 h-7 rounded-lg bg-[#72B7E8] text-white font-bold cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#F7F7FC]/40 cursor-pointer">
                <input
                  type="checkbox"
                  checked={folicTaken}
                  onChange={(e) => setFolicTaken(e.target.checked)}
                />
                <span className="font-bold">حمض الفوليك</span>
              </label>
              <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#F7F7FC]/40 cursor-pointer">
                <input
                  type="checkbox"
                  checked={ironTaken}
                  onChange={(e) => setIronTaken(e.target.checked)}
                />
                <span className="font-bold">مكمل الحديد</span>
              </label>
              <label className="flex items-center gap-2 p-2.5 rounded-xl bg-[#F7F7FC]/40 cursor-pointer">
                <input
                  type="checkbox"
                  checked={calciumTaken}
                  onChange={(e) => setCalciumTaken(e.target.checked)}
                />
                <span className="font-bold">الكالسيوم وفيتامين د</span>
              </label>
            </div>

            <button
              type="button"
              onClick={() => {
                updateDb((prev) => ({
                  ...prev,
                  symptoms: [
                    {
                      id: Date.now(),
                      pregnancyId: prev.profile!.id,
                      date: todayIso(),
                      week: calc.currentWeek,
                      symptoms: selectedSymptoms,
                      severity: symptomSeverity,
                      waterCups,
                      folicAcidTaken: folicTaken,
                      ironTaken,
                      calciumTaken,
                      notes: '',
                      createdAt: new Date().toISOString(),
                    },
                    ...prev.symptoms,
                  ],
                }));
                setSelectedSymptoms([]);
                showBanner('تم حفظ سجل اليوم الصحي بنجاح');
              }}
              className="w-full bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold cursor-pointer"
            >
              حفظ سجل اليوم الصحي
            </button>
          </div>

          {/* علامات التحذير الطارئة */}
          <div className="bg-rose-50 rounded-2xl p-5 border border-rose-300 space-y-2">
            <h4 className="text-sm font-bold text-rose-900">
              علامات تحذيرية تستدعي مراجعة الطبيب فوراً (WHO / ACOG)
            </h4>
            <ul className="space-y-1.5 text-xs text-[#25263A]">
              {URGENT_WARNING_SIGNS.map((w, i) => (
                <li key={i}>
                  <strong>• {w.sign}:</strong> {w.detail}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 4: عدّاد حركات الجنين (Kick Counter — Count to 10)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'kicks' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] text-center space-y-4">
            <div className="flex justify-center">
              <KicksCounterSvg size={48} />
            </div>
            <h3 className="text-base font-bold text-[#25263A]">
              عدّاد حركات الجنين (قاعدة Count to 10 الطبية)
            </h3>
            <p className="text-xs text-[#77798C] max-w-md mx-auto leading-relaxed">
              توصي الكلية الأمريكية لأطباء النساء والتوليد (ACOG) بداية من الأسبوع 28 بحساب الوقت اللازم للشعور بـ 10 حركات للجنين.
            </p>
            <div className="text-3xl font-black text-[#25263A]">{kickCount} / 10 حركات</div>
            <div className="text-xs font-bold text-[#5B5FEF]">
              المدة المنقضية: {formatMmSs(kickElapsedSec)}
            </div>

            {!kickActive ? (
              <button
                type="button"
                onClick={() => {
                  const now = new Date();
                  setKickActive(true);
                  setKickStartMs(now.getTime());
                  setKickStartTimeStr(
                    `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(
                      2,
                      '0'
                    )}`
                  );
                  setKickCount(1);
                  setKickElapsedSec(0);
                }}
                className="w-full max-w-sm mx-auto bg-[#5B5FEF] text-white py-3.5 rounded-xl font-bold text-sm cursor-pointer"
              >
                بدء جلسة عدّ الحركات الآن
              </button>
            ) : (
              <div className="space-y-2.5 max-w-sm mx-auto">
                <button
                  type="button"
                  onClick={() => {
                    const next = kickCount + 1;
                    setKickCount(next);
                    if (next >= 10) {
                      const now = new Date();
                      const endHm = `${String(now.getHours()).padStart(2, '0')}:${String(
                        now.getMinutes()
                      ).padStart(2, '0')}`;
                      updateDb((prev) => ({
                        ...prev,
                        kicks: [
                          {
                            id: Date.now(),
                            pregnancyId: prev.profile!.id,
                            date: todayIso(),
                            startTime: kickStartTimeStr,
                            endTime: endHm,
                            durationSeconds: kickElapsedSec,
                            kicksCount: next,
                            notes: '',
                            createdAt: now.toISOString(),
                          },
                          ...prev.kicks,
                        ],
                      }));
                      setKickActive(false);
                      setKickCount(0);
                      setKickElapsedSec(0);
                      showBanner('اكتملت 10 حركات وتم حفظ الجلسة بنجاح');
                    }
                  }}
                  className="w-full bg-[#5B5FEF] text-white py-4 rounded-2xl font-bold text-sm cursor-pointer"
                >
                  تسجيل حركة جديدة (+1)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (kickCount > 0 && kickStartMs) {
                      const now = new Date();
                      const endHm = `${String(now.getHours()).padStart(2, '0')}:${String(
                        now.getMinutes()
                      ).padStart(2, '0')}`;
                      updateDb((prev) => ({
                        ...prev,
                        kicks: [
                          {
                            id: Date.now(),
                            pregnancyId: prev.profile!.id,
                            date: todayIso(),
                            startTime: kickStartTimeStr,
                            endTime: endHm,
                            durationSeconds: kickElapsedSec,
                            kicksCount: kickCount,
                            notes: '',
                            createdAt: now.toISOString(),
                          },
                          ...prev.kicks,
                        ],
                      }));
                      showBanner('تم حفظ جلسة حركات الجنين');
                    }
                    setKickActive(false);
                    setKickCount(0);
                    setKickElapsedSec(0);
                  }}
                  className="w-full py-2.5 rounded-xl border border-stone-300 text-xs font-bold cursor-pointer"
                >
                  حفظ وإنهاء الجلسة
                </button>
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#E99AC7] space-y-2">
            <h4 className="text-sm font-bold text-[#25263A]">سجل جلسات حركات الجنين</h4>
            {db.kicks.length === 0 ? (
              <p className="text-xs text-[#77798C] text-center py-4">
                لم يتم تسجيل أي جلسة لحركات الجنين بعد.
              </p>
            ) : (
              <div className="divide-y divide-[#E6E6F0] text-xs">
                {db.kicks.map((k) => (
                  <div key={k.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold">
                        {k.kicksCount} حركات في {formatMmSs(k.durationSeconds)} دقيقة
                      </div>
                      <div className="text-[11px] text-[#77798C]">
                        {formatArabicDateIso(k.date)} · من {k.startTime} إلى {k.endTime}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        updateDb((prev) => ({
                          ...prev,
                          kicks: prev.kicks.filter((item) => item.id !== k.id),
                        }))
                      }
                      className="text-rose-600 text-[11px] font-bold cursor-pointer"
                    >
                      حذف
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 5: مؤقّت الانقباضات / الطلق (Contraction Timer — 5-1-1)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'contractions' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="bg-white rounded-3xl p-6 border border-[#E6E6F0] text-center space-y-4">
            <div className="flex justify-center">
              <ContractionTimerSvg size={48} />
            </div>
            <h3 className="text-base font-bold text-[#25263A]">
              مؤقّت الانقباضات (قاعدة 5-1-1 الطبية)
            </h3>
            <p className="text-xs text-[#77798C] max-w-md mx-auto leading-relaxed">
              إذا انتظمت الانقباضات كل 5 دقائق، واستمرت كل انقباضة نحو دقيقة كاملة (60 ثانية) لمدة ساعة، توجهي إلى المستشفى فوراً.
            </p>
            <div className="text-3xl font-black text-[#25263A]">{contractionElapsedSec} ثانية</div>
            <div className="flex justify-center gap-2 text-xs">
              {(['mild', 'moderate', 'strong'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setContractionIntensity(lvl)}
                  className={`px-3 py-1.5 rounded-xl font-bold border cursor-pointer ${
                    contractionIntensity === lvl
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                  }`}
                >
                  {lvl === 'mild' ? 'خفيفة' : lvl === 'moderate' ? 'متوسطة' : 'قوية'}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                if (!contractionActive) {
                  setContractionActive(true);
                  setContractionStartMs(Date.now());
                  setContractionElapsedSec(0);
                } else {
                  const now = new Date();
                  const startMs = contractionStartMs ?? now.getTime();
                  const startObj = new Date(startMs);
                  const intervalSeconds =
                    lastContractionStartMs !== null
                      ? Math.round((startMs - lastContractionStartMs) / 1000)
                      : undefined;
                  setLastContractionStartMs(startMs);

                  const fmt = (d: Date) =>
                    `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(
                      2,
                      '0'
                    )}:${String(d.getSeconds()).padStart(2, '0')}`;

                  updateDb((prev) => ({
                    ...prev,
                    contractions: [
                      {
                        id: Date.now(),
                        pregnancyId: prev.profile!.id,
                        date: todayIso(),
                        startTime: fmt(startObj),
                        endTime: fmt(now),
                        durationSeconds: Math.max(1, contractionElapsedSec),
                        intervalSeconds,
                        intensity: contractionIntensity,
                        createdAt: now.toISOString(),
                      },
                      ...prev.contractions,
                    ],
                  }));
                  setContractionActive(false);
                  setContractionElapsedSec(0);
                  showBanner('تم حفظ الانقباضة والفاصل الزمني');
                }
              }}
              className={`w-full max-w-sm mx-auto py-3.5 rounded-xl font-bold text-sm text-white cursor-pointer ${
                contractionActive ? 'bg-rose-700' : 'bg-[#5B5FEF]'
              }`}
            >
              {contractionActive ? 'انتهت الانقباضة — حفظ المدة' : 'بدأت الانقباضة الآن'}
            </button>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#E99AC7] space-y-2">
            <h4 className="text-sm font-bold text-[#25263A]">سجل الانقباضات</h4>
            {db.contractions.length === 0 ? (
              <p className="text-xs text-[#77798C] text-center py-4">
                لا توجد انقباضات مسجلة حالياً.
              </p>
            ) : (
              <div className="divide-y divide-[#E6E6F0] text-xs">
                {db.contractions.map((c) => (
                  <div key={c.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <div className="font-bold">
                        المدة: {c.durationSeconds} ثانية · الشدة:{' '}
                        {c.intensity === 'strong'
                          ? 'قوية'
                          : c.intensity === 'moderate'
                          ? 'متوسطة'
                          : 'خفيفة'}
                      </div>
                      <div className="text-[11px] text-[#77798C]">
                        الوقت: {c.startTime}
                        {c.intervalSeconds !== undefined
                          ? ` · الفاصل عن السابقة: ${formatMmSs(c.intervalSeconds)} د`
                          : ''}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        updateDb((prev) => ({
                          ...prev,
                          contractions: prev.contractions.filter((item) => item.id !== c.id),
                        }))
                      }
                      className="text-rose-600 text-[11px] font-bold cursor-pointer"
                    >
                      حذف
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 6: مواعيد الطبيبة والفحوصات (مع إشعارات حقيقية + فحوصات الأثلاث)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'appointments' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <PregnancyAppointmentsSvg size={24} />
              <h3 className="text-sm font-bold text-[#25263A]">إضافة موعد طبي أو فحص جديد</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <input
                type="text"
                value={apptTitle}
                onChange={(e) => setApptTitle(e.target.value)}
                placeholder="عنوان الموعد (مثال: سونار الشهر الخامس)*"
                className="p-2.5 rounded-xl border border-stone-300"
              />
              <input
                type="text"
                value={apptDoctor}
                onChange={(e) => setApptDoctor(e.target.value)}
                placeholder="اسم الطبيبة أو المركز الطبي (اختياري)"
                className="p-2.5 rounded-xl border border-stone-300"
              />
              <input
                type="date"
                value={apptDate}
                onChange={(e) => setApptDate(e.target.value)}
                className="p-2.5 rounded-xl border border-stone-300"
              />
              <input
                type="time"
                value={apptTime}
                onChange={(e) => setApptTime(e.target.value)}
                className="p-2.5 rounded-xl border border-stone-300"
              />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={apptReminder}
                onChange={(e) => setApptReminder(e.target.checked)}
              />
              <span className="font-bold">تفعيل إشعار تنبيه حقيقي في وقت الموعد</span>
            </label>
            <button
              type="button"
              onClick={async () => {
                if (!apptTitle.trim() || !apptDate) {
                  showBanner('يرجى إدخال عنوان الموعد وتاريخه', true);
                  return;
                }
                if (apptReminder) {
                  await scheduleRealPregnancyNotification(
                    'تم جدولة موعد متابعة الحمل — رحلتكِ',
                    `${apptTitle.trim()} بتاريخ ${formatArabicDateIso(apptDate)} الساعة ${apptTime}`
                  );
                }
                updateDb((prev) => ({
                  ...prev,
                  appointments: [
                    ...prev.appointments,
                    {
                      id: Date.now(),
                      pregnancyId: prev.profile!.id,
                      title: apptTitle.trim(),
                      doctorOrLab: apptDoctor.trim(),
                      appointmentType: apptType,
                      date: apptDate,
                      time: apptTime,
                      notes: apptNotes.trim(),
                      reminderEnabled: apptReminder,
                      isCompleted: false,
                      createdAt: new Date().toISOString(),
                    },
                  ],
                }));
                setApptTitle('');
                setApptDoctor('');
                setApptDate('');
                showBanner('تم حفظ الموعد وجدولة الإشعار الحقيقي');
              }}
              className="w-full bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold cursor-pointer"
            >
              حفظ الموعد وجدولة الإشعار
            </button>
          </div>

          <div className="bg-white rounded-2xl p-5 border border-[#E99AC7] space-y-2 text-xs">
            <h4 className="text-sm font-bold text-[#25263A]">مواعيدكِ المسجلة</h4>
            {db.appointments.length === 0 ? (
              <p className="text-[#77798C] text-center py-4">
                لا توجد مواعيد مسجلة بعد. أضيفي موعدكِ القادم مع الطبيبة أعلاه.
              </p>
            ) : (
              <div className="divide-y divide-[#E6E6F0]">
                {db.appointments.map((a) => (
                  <div key={a.id} className="py-2.5 flex items-center justify-between">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={a.isCompleted}
                        onChange={() =>
                          updateDb((prev) => ({
                            ...prev,
                            appointments: prev.appointments.map((item) =>
                              item.id === a.id
                                ? { ...item, isCompleted: !item.isCompleted }
                                : item
                            ),
                          }))
                        }
                      />
                      <div>
                        <div className={`font-bold ${a.isCompleted ? 'line-through text-[#77798C]' : ''}`}>
                          {a.title}
                        </div>
                        <div className="text-[11px] text-[#77798C]">
                          {formatArabicDateIso(a.date)} · الساعة {a.time}
                          {a.doctorOrLab ? ` · ${a.doctorOrLab}` : ''}
                        </div>
                      </div>
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        updateDb((prev) => ({
                          ...prev,
                          appointments: prev.appointments.filter((item) => item.id !== a.id),
                        }))
                      }
                      className="text-rose-600 text-[11px] font-bold cursor-pointer"
                    >
                      حذف
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* جدول الفحوصات الموصى بها */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3">
            <h4 className="text-sm font-bold text-[#25263A]">
              جدول الفحوصات الطبية الموصى بها لكل ثلث (WHO / ACOG)
            </h4>
            <div className="space-y-2.5 text-xs">
              {RECOMMENDED_CHECKUPS.map((c, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-[#F7F7FC]/50 space-y-1">
                  <div className="font-bold text-[#25263A]">
                    الثلث {c.trimester === 1 ? 'الأول' : c.trimester === 2 ? 'الثاني' : 'الثالث'} (
                    {c.timingWeeks}): {c.title}
                  </div>
                  <p className="text-[#25263A] leading-relaxed">{c.description}</p>
                  <div className="text-[11px] text-[#77798C]">المصدر: {c.source}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 7: التغذية والفيتامينات والأطعمة الممنوعة
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'nutrition' && (
        <div className="space-y-4">
          {renderMedicalDisclaimer()}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-[#25263A]">العناصر الغذائية الأساسية للحامل</h3>
            {ESSENTIAL_NUTRIENTS.map((n, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 border border-[#E6E6F0] space-y-1.5 text-xs"
              >
                <div className="font-bold text-sm text-[#25263A]">
                  {n.name} ({n.dailyNeed})
                </div>
                <p className="text-[#25263A]">
                  <strong>الأهمية الطبية:</strong> {n.importance}
                </p>
                <p className="text-[#4CAF82] font-bold">
                  المصادر الطبيعية: {n.naturalSources}
                </p>
                <div className="text-[11px] text-[#77798C]">المصدر: {n.source}</div>
              </div>
            ))}
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-rose-800">
              أطعمة وممارسات يجب تجنبها أثناء الحمل
            </h3>
            {FOODS_TO_AVOID.map((f, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 border border-rose-200 space-y-1 text-xs"
              >
                <div className="font-bold text-rose-800">{f.title}</div>
                <p className="text-[#25263A]">{f.reason}</p>
                <div className="text-[11px] text-[#77798C]">المصدر: {f.source}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 8: أدعية الحامل وفقه الحمل والولادة (خط Amiri ومصادر موثقة)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'duas_fiqh' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            {[
              { id: 'all' as const, label: 'الكل' },
              { id: 'dua' as const, label: 'أدعية القرآن والسنة' },
              { id: 'fiqh' as const, label: 'فقه الحمل والولادة' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setDuasFilter(t.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                  duasFilter === t.id
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-white text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {PREGNANCY_DUAS_AND_FIQH.filter(
              (item) => duasFilter === 'all' || item.category === duasFilter
            ).map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3"
              >
                <h4 className="text-sm font-bold text-[#25263A]">{item.title}</h4>
                <div
                  className="bg-[#F7F7FC]/65 rounded-xl p-4 text-center text-base sm:text-lg font-bold text-[#25263A] leading-loose"
                  style={{ fontFamily: 'Amiri, serif' }}
                >
                  {item.arabicText}
                </div>
                <p className="text-xs text-[#25263A] leading-relaxed">{item.explanation}</p>
                <div className="flex items-center justify-between text-[11px] font-bold text-[#5B5FEF]">
                  <span>المصدر: {item.source}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(
                        `${item.title}\n${item.arabicText}\n(${item.source})`
                      );
                      showBanner('تم نسخ النص مع مصدره');
                    }}
                    className="text-[#25263A] hover:text-[#5B5FEF] cursor-pointer"
                  >
                    نسخ
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 9: حقيبة الولادة التفاعلية (الأم + المولود + المستندات)
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'bag' && (
        <div className="space-y-4">
          {(() => {
            const total = db.bagItems.length;
            const packed = db.bagItems.filter((i) => i.isPacked).length;
            const pct = total === 0 ? 0 : Math.round((packed / total) * 100);
            return (
              <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span>نسبة تجهيز حقيبة الولادة</span>
                  <span className="text-[#4CAF82]">
                    {packed} من {total} ({pct}%)
                  </span>
                </div>
                <div className="w-full h-3 bg-[#F7F7FC] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#4CAF82] transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })()}

          <div className="flex gap-2">
            {[
              { id: 'mother' as const, label: 'حقيبة الأم' },
              { id: 'baby' as const, label: 'حقيبة المولود' },
              { id: 'documents' as const, label: 'المستندات' },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setBagTab(t.id)}
                className={`flex-1 py-2 rounded-xl text-xs font-bold border cursor-pointer ${
                  bagTab === t.id
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-white text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={customBagItem}
              onChange={(e) => setCustomBagItem(e.target.value)}
              placeholder="أضيفي غرضاً جديداً لهذه القائمة..."
              className="flex-1 p-2.5 rounded-xl border border-stone-300 bg-white text-xs"
            />
            <button
              type="button"
              onClick={() => {
                if (!customBagItem.trim()) return;
                updateDb((prev) => ({
                  ...prev,
                  bagItems: [
                    ...prev.bagItems,
                    {
                      id: Date.now(),
                      pregnancyId: prev.profile!.id,
                      category: bagTab,
                      itemName: customBagItem.trim(),
                      isPacked: false,
                      createdAt: new Date().toISOString(),
                    },
                  ],
                }));
                setCustomBagItem('');
              }}
              className="bg-[#5B5FEF] text-white px-4 rounded-xl text-xs font-bold cursor-pointer"
            >
              إضافة
            </button>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-[#E99AC7] divide-y divide-[#E6E6F0] text-xs">
            {db.bagItems
              .filter((i) => i.category === bagTab)
              .map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={item.isPacked}
                      onChange={() =>
                        updateDb((prev) => ({
                          ...prev,
                          bagItems: prev.bagItems.map((b) =>
                            b.id === item.id ? { ...b, isPacked: !b.isPacked } : b
                          ),
                        }))
                      }
                    />
                    <span className={item.isPacked ? 'line-through text-[#77798C]' : 'font-bold'}>
                      {item.itemName}
                    </span>
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      updateDb((prev) => ({
                        ...prev,
                        bagItems: prev.bagItems.filter((b) => b.id !== item.id),
                      }))
                    }
                    className="text-rose-600 text-[11px] font-bold cursor-pointer"
                  >
                    حذف
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 10: مذكرات رحلتي ورسائل لجنيني
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'journal' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <PregnancyJournalSvg size={24} />
              <h3 className="text-sm font-bold text-[#25263A]">
                خاطرة أو رسالة لجنينكِ (الأسبوع {calc.currentWeek})
              </h3>
            </div>
            <input
              type="text"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              placeholder="عنوان الخاطرة (اختياري)"
              className="w-full p-2.5 rounded-xl border border-stone-300"
            />
            <textarea
              rows={3}
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="اكتبي مشاعركِ أو دعاءكِ لجنينكِ في هذا الأسبوع..."
              className="w-full p-2.5 rounded-xl border border-stone-300"
            />
            <button
              type="button"
              onClick={() => {
                if (!noteContent.trim()) {
                  showBanner('يرجى كتابة نص الخاطرة أولاً', true);
                  return;
                }
                updateDb((prev) => ({
                  ...prev,
                  notes: [
                    {
                      id: Date.now(),
                      pregnancyId: prev.profile!.id,
                      week: calc.currentWeek,
                      date: todayIso(),
                      title: noteTitle.trim() || `ذكرى الأسبوع ${calc.currentWeek}`,
                      content: noteContent.trim(),
                      createdAt: new Date().toISOString(),
                    },
                    ...prev.notes,
                  ],
                }));
                setNoteTitle('');
                setNoteContent('');
                showBanner('تم حفظ الخاطرة في مذكرات رحلتكِ');
              }}
              className="w-full bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold cursor-pointer"
            >
              حفظ في مذكرات رحلتي
            </button>
          </div>

          {db.notes.length === 0 ? (
            <div className="bg-white rounded-2xl p-6 border border-[#E99AC7] text-center text-xs text-[#77798C]">
              لم تكتبي أي مذكرات بعد. كل ما تكتبينه هنا يُحفظ بخصوصية تامة على جهازكِ.
            </div>
          ) : (
            <div className="space-y-3">
              {db.notes.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl p-4 border border-[#E99AC7] space-y-1.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-[#25263A]">
                      {n.title} · الأسبوع {n.week}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        updateDb((prev) => ({
                          ...prev,
                          notes: prev.notes.filter((item) => item.id !== n.id),
                        }))
                      }
                      className="text-rose-600 text-[11px] font-bold cursor-pointer"
                    >
                      حذف
                    </button>
                  </div>
                  <div className="text-[11px] text-[#5B5FEF]">{formatArabicDateIso(n.date)}</div>
                  <p className="text-[#25263A] leading-relaxed whitespace-pre-wrap">{n.content}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          الشاشة 11: التذكيرات الحقيقية والإعدادات والخصوصية
         ══════════════════════════════════════════════════════════════════════ */}
      {db.profile && calc && subScreen === 'settings' && (
        <div className="space-y-4 text-xs">
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] space-y-3">
            <h3 className="text-sm font-bold text-[#25263A]">
              التذكيرات اليومية الحقيقية (Real Notifications)
            </h3>
            <p className="text-[11px] text-[#77798C]">
              عند تفعيل أي تذكير، يطلب التطبيق صلاحية الإشعارات الحقيقية من النظام ويرسل إشعاراً فعلياً.
            </p>
            <div className="space-y-2.5">
              {db.reminders.map((r) => (
                <div
                  key={r.reminderKey}
                  className="p-3 rounded-xl bg-[#F7F7FC]/60 flex flex-wrap items-center justify-between gap-2"
                >
                  <div>
                    <div className="font-bold text-[#25263A]">{r.title}</div>
                    <div className="text-[11px] text-[#77798C]">{r.subtitle}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={r.time}
                      onChange={(e) => {
                        const newTime = e.target.value;
                        updateDb((prev) => ({
                          ...prev,
                          reminders: prev.reminders.map((rem) =>
                            rem.reminderKey === r.reminderKey ? { ...rem, time: newTime } : rem
                          ),
                        }));
                      }}
                      className="p-1.5 rounded-lg border border-stone-300 bg-white text-xs"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const nextEnabled = !r.enabled;
                        if (nextEnabled) {
                          const ok = await scheduleRealPregnancyNotification(
                            r.title,
                            `تم تفعيل التذكير اليومي في الساعة ${r.time}`
                          );
                          if (!ok) {
                            showBanner(
                              'يرجى السماح بصلاحية الإشعارات من المتصفح/النظام أولاً',
                              true
                            );
                            return;
                          }
                        }
                        updateDb((prev) => ({
                          ...prev,
                          reminders: prev.reminders.map((rem) =>
                            rem.reminderKey === r.reminderKey
                              ? { ...rem, enabled: nextEnabled }
                              : rem
                          ),
                        }));
                        showBanner(
                          nextEnabled ? 'تم تفعيل التذكير الحقيقي' : 'تم إيقاف التذكير'
                        );
                      }}
                      className={`px-3 py-1.5 rounded-xl font-bold cursor-pointer ${
                        r.enabled ? 'bg-[#5B5FEF] text-white' : 'bg-stone-200 text-[#25263A]'
                      }`}
                    >
                      {r.enabled ? 'مفعّل' : 'غير مفعّل'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* حماية الخصوصية برمز PIN */}
          <div className="bg-white rounded-2xl p-5 border border-[#E99AC7] space-y-3">
            <h4 className="text-sm font-bold text-[#25263A]">قفل الخصوصية (PIN اختياري)</h4>
            <div className="flex gap-2">
              <input
                type="password"
                maxLength={6}
                value={newPinCode}
                onChange={(e) => setNewPinCode(e.target.value)}
                placeholder="أدخلي رمز PIN من 4 أرقام"
                className="flex-1 p-2.5 rounded-xl border border-stone-300"
              />
              <button
                type="button"
                onClick={() => {
                  if (newPinCode.trim().length < 4) {
                    showBanner('الرمز يجب أن يتكون من 4 أرقام على الأقل', true);
                    return;
                  }
                  updateDb((prev) => ({
                    ...prev,
                    pinEnabled: true,
                    pinCode: newPinCode.trim(),
                  }));
                  setNewPinCode('');
                  showBanner('تم تفعيل رمز حماية الخصوصية');
                }}
                className="bg-[#5B5FEF] text-white px-4 rounded-xl font-bold cursor-pointer"
              >
                تفعيل القفل
              </button>
              {db.pinEnabled && (
                <button
                  type="button"
                  onClick={() => {
                    updateDb((prev) => ({
                      ...prev,
                      pinEnabled: false,
                      pinCode: null,
                    }));
                    showBanner('تم إلغاء قفل الخصوصية');
                  }}
                  className="bg-stone-200 text-[#25263A] px-3 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء القفل
                </button>
              )}
            </div>
          </div>

          {/* تعديل الحساب أو حذف البيانات */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setSubScreen('setup')}
              className="px-4 py-2.5 rounded-xl bg-[#F7F7FC] font-bold text-[#25263A] border border-[#E6E6F0] cursor-pointer"
            >
              تعديل تاريخ آخر دورة / موعد الولادة
            </button>

            {!showWipeConfirm ? (
              <button
                type="button"
                onClick={() => setShowWipeConfirm(true)}
                className="px-4 py-2.5 rounded-xl bg-rose-50 text-rose-700 font-bold border border-rose-200 cursor-pointer"
              >
                حذف جميع بيانات رحلة الحمل
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const empty = wipePregnancyDb();
                    setDb(empty);
                    onUpdatePregnancy({
                      hasActivePregnancy: false,
                      lmpDate: '',
                      notes: '',
                      appointments: [],
                    });
                    setShowWipeConfirm(false);
                    setSubScreen('setup');
                    showBanner('تم حذف جميع بيانات الحمل بنجاح');
                  }}
                  className="px-3 py-2 rounded-xl bg-rose-700 text-white font-bold cursor-pointer"
                >
                  تأكيد الحذف النهائي
                </button>
                <button
                  type="button"
                  onClick={() => setShowWipeConfirm(false)}
                  className="px-3 py-2 rounded-xl border border-stone-300 font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
