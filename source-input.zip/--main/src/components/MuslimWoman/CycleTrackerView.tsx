import React, { useState } from 'react';
import { Plus, Trash2, Calendar, AlertCircle, Info, Check, Sparkles } from 'lucide-react';
import { CycleRecord } from './womanTypes';

interface CycleTrackerViewProps {
  cycles: CycleRecord[];
  onAddCycle: (cycle: Omit<CycleRecord, 'id'>) => void;
  onDeleteCycle: (id: string) => void;
}

const COMMON_SYMPTOMS = [
  'تقلصات وألم أسفل البطن',
  'ألم أسفل الظهر',
  'تقلب المزاج أو قلق',
  'صداع أو دوار',
  'إرهاق وخمول',
  'انتفاخ البطن',
  'حساسية في الصدر'
];

export const CycleTrackerView: React.FC<CycleTrackerViewProps> = ({
  cycles,
  onAddCycle,
  onDeleteCycle,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [flowIntensity, setFlowIntensity] = useState<'light' | 'medium' | 'heavy'>('medium');

  // حساب الإحصائيات من البيانات الحقيقية فقط
  const sortedCycles = [...cycles].sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  const lastCycle = sortedCycles[0] || null;

  // حساب متوسط مدة الحيض (عدد أيام النزف)
  const averageBleedingDays = cycles.length > 0
    ? Math.round(
        cycles.reduce((acc, c) => {
          const diff = (new Date(c.endDate).getTime() - new Date(c.startDate).getTime()) / (1000 * 60 * 60 * 24) + 1;
          return acc + (diff > 0 ? diff : 5);
        }, 0) / cycles.length
      )
    : 0;

  // حساب متوسط مدة الدورة الكاملة (بين بدايتي دورتين متتاليتين)
  let averageCycleDays = 0;
  if (sortedCycles.length >= 2) {
    let totalCycleGaps = 0;
    for (let i = 0; i < sortedCycles.length - 1; i++) {
      const currentStart = new Date(sortedCycles[i].startDate).getTime();
      const prevStart = new Date(sortedCycles[i + 1].startDate).getTime();
      const gapDays = Math.round((currentStart - prevStart) / (1000 * 60 * 60 * 24));
      totalCycleGaps += gapDays;
    }
    averageCycleDays = Math.round(totalCycleGaps / (sortedCycles.length - 1));
  } else if (sortedCycles.length === 1) {
    averageCycleDays = 28; // قيمة تقريبية مبدئية مع توضيح للمستخدمة
  }

  // حساب التاريخ القادم المتوقع
  let nextExpectedDate: Date | null = null;
  let daysUntilNext: number | null = null;
  if (lastCycle && averageCycleDays > 0) {
    const lastStart = new Date(lastCycle.startDate);
    nextExpectedDate = new Date(lastStart.getTime() + averageCycleDays * 24 * 60 * 60 * 1000);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    daysUntilNext = Math.round((nextExpectedDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  }

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(symptom) ? prev.filter(s => s !== symptom) : [...prev, symptom]
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!startDate || !endDate) return;
    if (new Date(endDate) < new Date(startDate)) {
      alert('تاريخ انتهاء الدورة يجب أن يكون بعد أو نفس تاريخ البداية');
      return;
    }

    onAddCycle({
      startDate,
      endDate,
      symptoms: selectedSymptoms,
      notes: notes.trim() || undefined,
      flowIntensity
    });

    setStartDate('');
    setEndDate('');
    setSelectedSymptoms([]);
    setNotes('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* الترويسة وأزرار الإجراء */}
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center text-2xl shadow-xs">
            🩸
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">متابعة الدورة الشهرية</h3>
            <p className="text-xs text-[#77798C]">تسجيل ومتابعة أوقات الحيض والطهارة وحساب المواعيد القادمة</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>سجلي دورة جديدة</span>
        </button>
      </div>

      {/* الحالة الفارغة إن لم تسجل أي دورة */}
      {cycles.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 mx-auto rounded-full bg-rose-50 flex items-center justify-center text-3xl">
            🩸
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h4 className="text-base font-bold text-[#25263A]">لم تسجلي أي دورة بعد</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              ابدئي بتسجيل أول يوم وآخر يوم من دورتك لحساب متوسط أيام الحيض والأيام المتوقعة ومواعيد الطهارة بدقة متناهية وبخصوصية تامة على هاتفك.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>🩸 سجلي أول دورة الآن</span>
          </button>
        </div>
      ) : (
        <>
          {/* ملخص الحسابات الحقيقية */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {/* بطاقة الدورة القادمة المتوقعة */}
            <div className="bg-gradient-to-br from-white to-amber-50/40 rounded-2xl p-4 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#77798C] mb-2">
                <span>الموعد القادم المتوقع</span>
                <span className="text-lg">🟡</span>
              </div>
              <div className="text-xl font-black text-[#25263A] font-tajawal">
                {nextExpectedDate ? nextExpectedDate.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'}
              </div>
              <div className="mt-1.5 text-[11px] text-[#5B5FEF] font-bold">
                {daysUntilNext !== null
                  ? daysUntilNext > 0
                    ? `متبقٍ حوالي ${daysUntilNext} يوماً`
                    : daysUntilNext === 0
                    ? 'الموعد متوقع اليوم'
                    : `تأخرت بنحو ${Math.abs(daysUntilNext)} يوماً`
                  : '—'}
              </div>
            </div>

            {/* بطاقة متوسط مدة الدورة الكاملة */}
            <div className="bg-gradient-to-br from-white to-rose-50/30 rounded-2xl p-4 border border-rose-200/50 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#77798C] mb-2">
                <span>متوسط طول الدورة</span>
                <span className="text-lg">🔄</span>
              </div>
              <div className="text-xl font-black text-[#25263A] font-tajawal">
                {averageCycleDays} <span className="text-xs font-normal text-[#77798C]">يوماً</span>
              </div>
              <div className="mt-1.5 text-[11px] text-[#77798C]">
                {sortedCycles.length >= 2
                  ? `محسوب من ${sortedCycles.length} دورات مسجلة`
                  : 'مبدئي (سجّلي دورتين لحساب دقيق)'}
              </div>
            </div>

            {/* بطاقة متوسط أيام الحيض */}
            <div className="bg-gradient-to-br from-white to-emerald-50/30 rounded-2xl p-4 border border-[#4CAF82]/40/50 shadow-xs">
              <div className="flex items-center justify-between text-xs text-[#77798C] mb-2">
                <span>متوسط أيام الحيض</span>
                <span className="text-lg">🔴</span>
              </div>
              <div className="text-xl font-black text-[#25263A] font-tajawal">
                {averageBleedingDays} <span className="text-xs font-normal text-[#77798C]">أيام</span>
              </div>
              <div className="mt-1.5 text-[11px] text-[#4CAF82] font-bold">
                أيام الطهارة التقديرية: {Math.max(0, averageCycleDays - averageBleedingDays)} يوماً
              </div>
            </div>
          </div>

          {/* دليل ألوان التقويم (Legend) */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-xs">
            <div className="text-xs font-bold text-[#25263A] mb-3 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-[#5B5FEF]" />
              <span>دليل ألوان التقويم الشرعي والصحي:</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="flex items-center gap-2 p-2 rounded-xl bg-rose-50 border border-rose-200">
                <span className="w-3.5 h-3.5 rounded-full bg-[#D95C6A]" />
                <span className="font-bold text-[#D95C6A]">🔴 أيام الحيض (المسجلة)</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0]">
                <span className="w-3.5 h-3.5 rounded-full bg-[#E8B84A]" />
                <span className="font-bold text-[#4145C7]">🟡 الأيام المتوقعة القادمة</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-[#4CAF82]/12 border border-[#4CAF82]/40">
                <span className="w-3.5 h-3.5 rounded-full bg-[#4CAF82]" />
                <span className="font-bold text-[#4CAF82]">🟢 أيام الطهارة والعبادة</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-50 border border-[#E6E6F0]">
                <span className="w-3.5 h-3.5 rounded-full bg-[#E6E6F0]" />
                <span className="text-[#77798C]">⚪ غير مسجل</span>
              </div>
            </div>
          </div>

          {/* سجل الدورات السابقة */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-[#25263A] flex items-center gap-2">
                <span>سجل الدورات السابقة</span>
                <span className="text-xs bg-[#EEEEFF] text-[#5B5FEF] font-bold px-2 py-0.5 rounded-full">
                  {cycles.length}
                </span>
              </h4>
            </div>

            <div className="space-y-3">
              {sortedCycles.map((c) => {
                const daysDiff = Math.round((new Date(c.endDate).getTime() - new Date(c.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1;
                return (
                  <div
                    key={c.id}
                    className="p-3.5 rounded-xl border border-[#E6E6F0] hover:border-[#E6E6F0] bg-stone-50/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-[#25263A]">
                          من {c.startDate} إلى {c.endDate}
                        </span>
                        <span className="text-xs font-black px-2 py-0.5 rounded-md bg-rose-100 text-rose-800">
                          {daysDiff} أيام نزف
                        </span>
                        {c.flowIntensity && (
                          <span className="text-[11px] text-[#77798C] bg-white px-2 py-0.5 rounded border border-[#E6E6F0]">
                            تدفق {c.flowIntensity === 'light' ? 'خفيف' : c.flowIntensity === 'medium' ? 'متوسط' : 'غزير'}
                          </span>
                        )}
                      </div>

                      {c.symptoms && c.symptoms.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {c.symptoms.map((s, idx) => (
                            <span key={idx} className="text-[10px] bg-[#EEEEFF] text-[#4145C7] px-2 py-0.5 rounded-md border border-[#E6E6F0]/60">
                              {s}
                            </span>
                          ))}
                        </div>
                      )}

                      {c.notes && (
                        <p className="text-xs text-[#77798C] italic">ملاحظة: {c.notes}</p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteCycle(c.id)}
                      className="self-end sm:self-center p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="حذف السجل"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* نموذج تسجيل دورة جديدة */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#E6E6F0] shadow-xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0]">
              <h4 className="text-base font-bold text-[#25263A] flex items-center gap-2">
                <span>🩸 تسجيل دورة جديدة</span>
              </h4>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-stone-400 hover:text-[#77798C] p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-bold mb-1">تاريخ البداية (أول يوم نزف)</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-bold mb-1">تاريخ النهاية (يوم الطهر)</label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={e => setEndDate(e.target.value)}
                    className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1.5">كثافة التدفق</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['light', 'medium', 'heavy'] as const).map(intensity => (
                    <button
                      key={intensity}
                      type="button"
                      onClick={() => setFlowIntensity(intensity)}
                      className={`p-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                        flowIntensity === intensity
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-stone-50 border-[#E6E6F0] text-stone-700'
                      }`}
                    >
                      {intensity === 'light' ? 'خفيف' : intensity === 'medium' ? 'متوسط' : 'غزير'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1.5">الأعراض المصاحبة</label>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_SYMPTOMS.map(s => {
                    const isSelected = selectedSymptoms.includes(s);
                    return (
                      <button
                        key={s}
                        type="button"
                        onClick={() => toggleSymptom(s)}
                        className={`text-[11px] px-2.5 py-1.5 rounded-lg border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-rose-100 text-rose-800 border-rose-300 font-bold'
                            : 'bg-stone-50 text-[#77798C] border-[#E6E6F0]'
                        }`}
                      >
                        {isSelected ? '✓ ' : ''}{s}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">ملاحظات إضافية</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="أي ملاحظات تخص الأدوية أو الحالة النفسية..."
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  حفظ السجل
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
