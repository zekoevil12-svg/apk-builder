import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  AlertTriangle,
  Send,
  CheckCircle2,
  Clock,
  MessageSquare,
  RefreshCw,
  ImagePlus,
  Trash2,
  Smartphone,
  FileText,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import {
  submitUserReportToFirestore,
  fetchUserOwnReports,
  subscribeToUserOwnReports,
  collectSafeDeviceDiagnosticInfo,
  compressScreenshotFileToDataUrl,
  formatAdminOperationError,
  getReportStatusLabel,
  ReportCategory,
  UserReportRecord,
} from '../../utils/adminService';

interface UserReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultCategory?: ReportCategory;
  defaultTargetId?: string;
}

const REPORT_CATEGORIES: { id: ReportCategory; label: string }[] = [
  { id: 'bug', label: 'مشكلة تقنية أو خلل في التطبيق' },
  { id: 'content', label: 'ملاحظة على محتوى شرعي أو نص' },
  { id: 'group', label: 'بلاغ عن مجموعة ختمة أو رسالة مخالفة' },
  { id: 'account', label: 'مشكلة في الحساب أو المزامنة' },
  { id: 'suggestion', label: 'اقتراح ميزة لتطوير رِفْق' },
  { id: 'other', label: 'أخرى' },
];

export const UserReportModal: React.FC<UserReportModalProps> = ({
  isOpen,
  onClose,
  defaultCategory = 'bug',
  defaultTargetId = '',
}) => {
  const { currentUser } = useAuth();
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState<'new' | 'history'>('new');
  const [category, setCategory] = useState<ReportCategory>(defaultCategory);
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [targetId, setTargetId] = useState(defaultTargetId);
  const [screenshotDataUrl, setScreenshotDataUrl] = useState<string | null>(null);
  const [compressingScreenshot, setCompressingScreenshot] = useState(false);
  const [includeDeviceInfo, setIncludeDeviceInfo] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const [myReports, setMyReports] = useState<UserReportRecord[]>([]);
  const [loadingReports, setLoadingReports] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setCategory(defaultCategory);
      setTargetId(defaultTargetId);
      setErrorMsg(null);
      setSuccessMsg(null);
      setLoadingReports(true);
      const unsub = subscribeToUserOwnReports(currentUser?.uid || null, (list) => {
        setMyReports(list);
        setLoadingReports(false);
      });
      return () => unsub();
    }
  }, [isOpen, defaultCategory, defaultTargetId, currentUser?.uid]);

  const loadUserReports = async () => {
    setLoadingReports(true);
    setErrorMsg(null);
    try {
      const list = await fetchUserOwnReports(currentUser?.uid || null);
      setMyReports(list);
    } catch (err) {
      setErrorMsg(formatAdminOperationError(err));
    } finally {
      setLoadingReports(false);
    }
  };

  if (!isOpen) return null;

  const handleScreenshotSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCompressingScreenshot(true);
    setErrorMsg(null);
    try {
      const dataUrl = await compressScreenshotFileToDataUrl(file);
      setScreenshotDataUrl(dataUrl);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'تعذر إرفاق الصورة.');
    } finally {
      setCompressingScreenshot(false);
      e.target.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    const categoryObj = REPORT_CATEGORIES.find((c) => c.id === category);

    try {
      const created = await submitUserReportToFirestore({
        category,
        issueType: categoryObj?.label,
        subject,
        description,
        targetId: targetId.trim() || undefined,
        screenshotDataUrl,
        deviceInfo: includeDeviceInfo ? collectSafeDeviceDiagnosticInfo(theme?.definition?.nameAr) : null,
      });
      setSubject('');
      setDescription('');
      setTargetId('');
      setScreenshotDataUrl(null);
      setSuccessMsg(`تم تسجيل بلاغك فعلياً في قاعدة البيانات برقم مرجعي (#${created.id}).`);
      await loadUserReports();
    } catch (err) {
      setErrorMsg(formatAdminOperationError(err));
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = (status: UserReportRecord['status']) => {
    const label = getReportStatusLabel(status);
    switch (status) {
      case 'open':
      case 'new':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
            {label}
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
            {label}
          </span>
        );
      case 'resolved':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            {label}
          </span>
        );
      case 'closed':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-gray-100 text-gray-600 border border-gray-200">
            {label}
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-[#E6E6F0] flex items-center justify-between bg-[#F7F7FC]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center border border-[#E6E6F0]">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-[#25263A]">مركز البلاغات والدعم الفني</h3>
              <p className="text-xs text-[#77798C]">إرسال بلاغ مباشر أو متابعة حالة بلاغاتك السابقة</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center text-[#77798C] hover:text-[#25263A] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#E6E6F0] bg-white px-5 pt-3 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('new')}
            className={`px-4 py-2 text-xs font-black rounded-t-xl border-b-2 transition-all cursor-pointer ${
              activeTab === 'new'
                ? 'border-[#5B5FEF] text-[#5B5FEF] bg-[#EEEEFF]/50'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            إرسال بلاغ جديد
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 text-xs font-black rounded-t-xl border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-[#5B5FEF] text-[#5B5FEF] bg-[#EEEEFF]/50'
                : 'border-transparent text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>بلاغاتي السابقة ({myReports.length})</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'new' ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold">
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">نوع المشكلة / التصنيف</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ReportCategory)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                >
                  {REPORT_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">عنوان المشكلة أو الاقتراح</label>
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={200}
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="مثال: مشكلة في مزامنة الأذكار أو الإبلاغ عن مجموعة..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              {category === 'group' && (
                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    كود المجموعة أو المعرف (اختياري)
                  </label>
                  <input
                    type="text"
                    maxLength={100}
                    value={targetId}
                    onChange={(e) => setTargetId(e.target.value)}
                    placeholder="أدخل كود الانضمام أو معرف المجموعة"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">وصف المشكلة بالتفصيل</label>
                <textarea
                  required
                  minLength={5}
                  maxLength={3500}
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="اشرح المشكلة أو الملاحظة بالتفصيل..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              {/* Screenshot attachment */}
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleScreenshotSelect}
                  className="hidden"
                />
                {!screenshotDataUrl ? (
                  <button
                    type="button"
                    disabled={compressingScreenshot}
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl border border-dashed border-[#E6E6F0] bg-[#F7F7FC] text-xs font-bold text-[#77798C] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <ImagePlus className="w-4 h-4 text-[#5B5FEF]" />
                    <span>
                      {compressingScreenshot
                        ? 'جاري تجهيز الصورة...'
                        : 'إرفاق لقطة شاشة (Screenshot) — اختياري'}
                    </span>
                  </button>
                ) : (
                  <div className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={screenshotDataUrl}
                        alt="Screenshot"
                        className="w-12 h-12 object-cover rounded-lg border border-[#E6E6F0]"
                      />
                      <span className="text-xs font-bold text-[#25263A]">تم إرفاق لقطة الشاشة</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setScreenshotDataUrl(null)}
                      className="p-1.5 rounded-lg bg-white text-[#D95C6A] border border-[#E6E6F0] cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <label className="flex items-center justify-between p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] cursor-pointer">
                <div className="flex items-center gap-2 text-xs font-bold text-[#25263A]">
                  <Smartphone className="w-4 h-4 text-[#5B5FEF]" />
                  <span>إرفاق معلومات الجهاز والتطبيق الأساسية بشكل آمن</span>
                </div>
                <input
                  type="checkbox"
                  checked={includeDeviceInfo}
                  onChange={(e) => setIncludeDeviceInfo(e.target.checked)}
                  className="w-4 h-4 accent-[#5B5FEF] cursor-pointer"
                />
              </label>

              <button
                type="submit"
                disabled={submitting || compressingScreenshot}
                className="w-full py-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{submitting ? 'جاري إرسال البلاغ...' : 'إرسال البلاغ'}</span>
              </button>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#77798C]">
                  إجمالي بلاغاتك المسجلة: {myReports.length}
                </span>
                <button
                  type="button"
                  onClick={loadUserReports}
                  disabled={loadingReports}
                  className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#5B5FEF] flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingReports ? 'animate-spin' : ''}`} />
                  <span>تحديث</span>
                </button>
              </div>

              {loadingReports ? (
                <div className="p-8 text-center text-xs text-[#77798C]">جاري تحميل بلاغاتك...</div>
              ) : myReports.length === 0 ? (
                <div className="p-8 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center space-y-2">
                  <FileText className="w-8 h-8 text-[#5B5FEF] mx-auto" />
                  <div className="text-xs font-black text-[#25263A]">
                    لا توجد بلاغات مسجلة حتى الآن
                  </div>
                  <p className="text-[11px] text-[#77798C]">
                    لم تقم بإرسال أي بلاغات أو اقتراحات سابقة.
                  </p>
                </div>
              ) : (
                myReports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-bold text-xs text-[#25263A]">{rep.subject}</h4>
                        <span className="text-[10px] font-mono text-[#77798C]" dir="ltr">
                          #{rep.id}
                        </span>
                      </div>
                      {getStatusBadge(rep.status)}
                    </div>
                    <p className="text-xs text-[#77798C] leading-relaxed whitespace-pre-wrap">
                      {rep.description}
                    </p>
                    <div className="text-[10px] text-[#77798C]">
                      تاريخ الإرسال:{' '}
                      {rep.createdAt
                        ? new Date(rep.createdAt).toLocaleString('ar-SA')
                        : 'غير متاح'}
                    </div>
                    {rep.adminResponse && (
                      <div className="mt-2 p-3 rounded-xl bg-white border border-[#5B5FEF]/30 space-y-1">
                        <div className="text-[11px] font-black text-[#5B5FEF] flex items-center gap-1.5">
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>رد إدارة رِفْق:</span>
                        </div>
                        <p className="text-xs text-[#25263A] leading-relaxed whitespace-pre-wrap">
                          {rep.adminResponse}
                        </p>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
