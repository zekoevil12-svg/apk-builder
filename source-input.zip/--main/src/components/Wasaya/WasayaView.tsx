import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  WasayaCategoryId,
  WasiyaItem,
} from '../../data/wasayaData';
import {
  initWasayaSqliteTables,
  loadWasayaCategoriesFromStorage,
  loadWasayaByCategoryFromStorage,
  loadWasayaFromStorage,
  loadWasayaFavorites,
  toggleWasayaFavorite,
  searchWasayaInStorage,
  getDailyWasiyaFromStorage,
} from '../../utils/wasayaSqlite';

interface WasayaViewProps {
  onBack: () => void;
  initialWasiyaId?: string | null;
  initialCategoryId?: WasayaCategoryId | null;
}

type WasayaSubScreen = 'home' | 'category' | 'detail' | 'search' | 'favorites';

/**
 * أيقونة قسم «وصايا الرسول ﷺ»: مصحف + قلب (SVG ذهبي فخم)
 */
export const WasayaMushafHeartSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 36,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <defs>
      <linearGradient id="wasayaGoldGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#E8B84A" />
        <stop offset="50%" stopColor="#E8B84A" />
        <stop offset="100%" stopColor="#4145C7" />
      </linearGradient>
    </defs>
    {/* إطار دائري زخرفي */}
    <circle cx="24" cy="24" r="22" fill="#F7F7FC" stroke="url(#wasayaGoldGrad)" strokeWidth="2" />
    {/* المصحف المفتوح */}
    <path
      d="M10 18C10 16.3431 11.3431 15 13 15H21C22.6569 15 24 16.3431 24 18V34C24 32.8954 23.1046 32 22 32H12C10.8954 32 10 31.1046 10 30V18Z"
      fill="#FFFFFF"
      stroke="url(#wasayaGoldGrad)"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <path
      d="M38 18C38 16.3431 36.6569 15 35 15H27C25.3431 15 24 16.3431 24 18V34C24 32.8954 24.8954 32 26 32H36C37.1046 32 38 31.1046 38 30V18Z"
      fill="#FFFFFF"
      stroke="url(#wasayaGoldGrad)"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    {/* سطور المصحف */}
    <path d="M13.5 21H20.5M13.5 25H20.5M27.5 21H34.5M27.5 25H34.5" stroke="#5B5FEF" strokeWidth="1.6" strokeLinecap="round" />
    {/* القلب الذهبي أعلى المصحف */}
    <path
      d="M24 17.5C24 17.5 18.5 13.8 18.5 10.3C18.5 8.5 19.9 7.2 21.6 7.2C22.7 7.2 23.5 7.8 24 8.6C24.5 7.8 25.3 7.2 26.4 7.2C28.1 7.2 29.5 8.5 29.5 10.3C29.5 13.8 24 17.5 24 17.5Z"
      fill="url(#wasayaGoldGrad)"
    />
    {/* حامل المصحف السفلي */}
    <path d="M16 36L24 33L32 36" stroke="#4CAF82" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/**
 * أيقونات SVG مخصصة بمقاس (48×48) للتصنيفات العشرة بدون أي إيموجي
 */
export const WasayaCategorySvg48: React.FC<{
  categoryId: WasayaCategoryId;
  size?: number;
}> = ({ categoryId, size = 48 }) => {
  const gold = '#E8B84A';
  const lightGold = '#E8B84A';
  const green = '#4CAF82';
  const beige = '#F7F7FC';

  switch (categoryId) {
    case 'worship':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* محراب وقبة مسجد مع كفي الدعاء */}
          <path d="M14 35H34M17 35V24C17 19.5 20.1 16 24 16C27.9 16 31 19.5 31 24V35" stroke={gold} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M24 11V16" stroke={green} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M21 26C21 24.3 22.3 23 24 23C25.7 23 27 24.3 27 26V35H21V26Z" fill={lightGold} fillOpacity="0.28" stroke={green} strokeWidth="1.8" />
        </svg>
      );
    case 'morals':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* ميزان الخلق الحسن والرحمة */}
          <path d="M24 12V35M16 35H32M14 18H34" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M14 18L11 25H17L14 18Z" fill={lightGold} fillOpacity="0.3" stroke={green} strokeWidth="1.8" strokeLinejoin="round" />
          <path d="M34 18L31 25H37L34 18Z" fill={lightGold} fillOpacity="0.3" stroke={green} strokeWidth="1.8" strokeLinejoin="round" />
        </svg>
      );
    case 'speech':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* الكلمة الطيبة وحفظ اللسان */}
          <path
            d="M12 17C12 14.8 13.8 13 16 13H32C34.2 13 36 14.8 36 17V27C36 29.2 34.2 31 32 31H21L15 36V31H16C13.8 31 12 29.2 12 27V17Z"
            fill="#FFFFFF"
            stroke={gold}
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <path d="M18 20H30M18 24.5H26" stroke={green} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'food':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* إناء الطعام المبارك والسنبلة */}
          <path d="M12 25H36C36 31.1 30.6 35 24 35C17.4 35 12 31.1 12 25Z" fill="#FFFFFF" stroke={gold} strokeWidth="2.2" strokeLinejoin="round" />
          <path d="M16 35H32" stroke={green} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M20 19C20 17 21.5 15.5 21.5 13.5M24 19C24 17 25.5 15.5 25.5 13.5M28 19C28 17 29.5 15.5 29.5 13.5" stroke={green} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'wealth':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* الصدقة والمال الحلال */}
          <circle cx="24" cy="21" r="8" fill="#FFFFFF" stroke={gold} strokeWidth="2.2" />
          <path d="M24 17V25M21.5 19.5H25.5C26.3 19.5 27 20.2 27 21C27 21.8 26.3 22.5 25.5 22.5H22.5" stroke={green} strokeWidth="1.8" strokeLinecap="round" />
          <path d="M13 33C16 31 19.5 31 23 32.5L31 32.5C33 32.5 35 31 36 30" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
        </svg>
      );
    case 'dealings':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* الوالدين والأرحام والتعامل */}
          <circle cx="19" cy="18" r="4" fill="#FFFFFF" stroke={gold} strokeWidth="2" />
          <circle cx="29" cy="19" r="3.5" fill="#FFFFFF" stroke={green} strokeWidth="2" />
          <path d="M12 33C12 28.5 15.1 25.5 19 25.5C22.9 25.5 26 28.5 26 33" stroke={gold} strokeWidth="2.2" strokeLinecap="round" />
          <path d="M24 33C24.5 29.2 26.8 26.8 29.8 26.8C32.8 26.8 35.2 29.2 35.8 33" stroke={green} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'heart':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* القلب السليم والإخلاص */}
          <path
            d="M24 35.5C24 35.5 13 28.2 13 19.8C13 15.8 16.1 13 19.8 13C21.9 13 23.3 14.1 24 15.4C24.7 14.1 26.1 13 28.2 13C31.9 13 35 15.8 35 19.8C35 28.2 24 35.5 24 35.5Z"
            fill="#FFFFFF"
            stroke={gold}
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <path d="M18.5 22.5L22.5 26.5L29.5 19.5" stroke={green} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'occasions':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* هلال المواسم المباركة (رمضان والحج والجمعة والليل) */}
          <path
            d="M29.5 29.8C24.2 29.8 19.9 25.5 19.9 20.2C19.9 17.3 21.1 14.7 23.1 13C17.6 13.7 13.5 18.4 13.5 24C13.5 30.1 18.4 35 24.5 35C29.3 35 33.4 31.9 34.9 27.6C33.3 29 31.5 29.8 29.5 29.8Z"
            fill="#FFFFFF"
            stroke={gold}
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <circle cx="30" cy="17" r="2.5" fill={green} />
        </svg>
      );
    case 'tribulations':
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* درع الحصن والثبات في الفتن */}
          <path
            d="M24 11L35 15.5V23.5C35 30.2 30.3 35.4 24 37.5C17.7 35.4 13 30.2 13 23.5V15.5L24 11Z"
            fill="#FFFFFF"
            stroke={gold}
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
          <path d="M20 24L23 27L28.5 20.5" stroke={green} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'comprehensive':
    default:
      return (
        <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
          <rect x="2" y="2" width="44" height="44" rx="14" fill={beige} stroke={gold} strokeWidth="1.5" />
          {/* المخطوطة النبوية الجامعة */}
          <rect x="14" y="12" width="20" height="24" rx="3" fill="#FFFFFF" stroke={gold} strokeWidth="2.2" />
          <path d="M18 18H30M18 23H30M18 28H25" stroke={green} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
  }
};

/* ── أيقونات العمليات بصيغة SVG نقية (بدون إيموجي) ── */
const BackArrowSvg: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const EnterArrowSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M19 12H5M5 12L11 6M5 12L11 18" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const SearchIconSvg: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2.2" />
    <path d="M20 20L16.2 16.2" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" />
  </svg>
);

const BookmarkHeartSvg: React.FC<{ filled?: boolean; className?: string }> = ({
  filled = false,
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} className={className}>
    <path
      d="M12 20.5C12 20.5 4 14.8 4 8.8C4 5.8 6.4 3.5 9.3 3.5C10.9 3.5 12 4.4 12 5.3C12 4.4 13.1 3.5 14.7 3.5C17.6 3.5 20 5.8 20 8.8C20 14.8 12 20.5 12 20.5Z"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinejoin="round"
    />
  </svg>
);

const CopyIconSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <rect x="9" y="9" width="11" height="11" rx="2.5" stroke="currentColor" strokeWidth="2" />
    <path d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const ShareIconSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <circle cx="18" cy="5" r="3" stroke="currentColor" strokeWidth="2" />
    <circle cx="6" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
    <circle cx="18" cy="19" r="3" stroke="currentColor" strokeWidth="2" />
    <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const BookSourceSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M4 19.5C4 18.1 5.1 17 6.5 17H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    <path d="M6.5 2H20V22H6.5C5.1 22 4 20.9 4 19.5V4.5C4 3.1 5.1 2 6.5 2Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
  </svg>
);

const NarratorSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M12 2C10.3 2 9 3.3 9 5V11C9 12.7 10.3 14 12 14C13.7 14 15 12.7 15 11V5C15 3.3 13.7 2 12 2Z" stroke="currentColor" strokeWidth="2" />
    <path d="M19 10V11C19 14.9 15.9 18 12 18C8.1 18 5 14.9 5 11V10M12 18V22M8 22H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const FontZoomSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path d="M4 19L10 5L16 19M6.2 14H13.8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M19 8V14M16 11H22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const NightModeSvg: React.FC<{ isDark: boolean; className?: string }> = ({
  isDark,
  className = 'w-5 h-5',
}) =>
  isDark ? (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="2" />
      <path d="M12 2V4M12 20V22M4.9 4.9L6.3 6.3M17.7 17.7L19.1 19.1M2 12H4M20 12H22M4.9 19.1L6.3 17.7M17.7 6.3L19.1 4.9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );

export const WasayaView: React.FC<WasayaViewProps> = ({
  onBack,
  initialWasiyaId = null,
  initialCategoryId = null,
}) => {
  const [subScreen, setSubScreen] = useState<WasayaSubScreen>(() => {
    if (initialWasiyaId) return 'detail';
    if (initialCategoryId) return 'category';
    return 'home';
  });
  const [previousScreen, setPreviousScreen] = useState<WasayaSubScreen>('home');
  const [selectedCategoryId, setSelectedCategoryId] = useState<WasayaCategoryId>(
    initialCategoryId || 'worship'
  );
  const [selectedWasiyaId, setSelectedWasiyaId] = useState<string | null>(initialWasiyaId);
  const [categorySearchQuery, setCategorySearchQuery] = useState('');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [searchCategoryFilter, setSearchCategoryFilter] = useState<WasayaCategoryId | 'all'>('all');
  const [searchBookFilter, setSearchBookFilter] = useState<string>('all');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadWasayaFavorites());
  const [fontScale, setFontScale] = useState<number>(1);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    initWasayaSqliteTables();
    setFavoriteIds(loadWasayaFavorites());
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2200);
  }, []);

  const categories = useMemo(() => loadWasayaCategoriesFromStorage(), [favoriteIds]);
  const allWasaya = useMemo(() => loadWasayaFromStorage(), [favoriteIds]);
  const dailyWasiya = useMemo(() => getDailyWasiyaFromStorage(), [favoriteIds]);

  const currentCategory = useMemo(
    () => categories.find((c) => c.id === selectedCategoryId) || categories[0],
    [categories, selectedCategoryId]
  );

  const categoryWasaya = useMemo(() => {
    const items = loadWasayaByCategoryFromStorage(selectedCategoryId);
    if (!categorySearchQuery.trim()) return items;
    return searchWasayaInStorage(categorySearchQuery, selectedCategoryId, 'all');
  }, [selectedCategoryId, categorySearchQuery, favoriteIds]);

  const selectedWasiya: (WasiyaItem & { isFavorite: boolean }) | null = useMemo(() => {
    if (!selectedWasiyaId) return dailyWasiya;
    return allWasaya.find((w) => w.id === selectedWasiyaId) || dailyWasiya;
  }, [allWasaya, selectedWasiyaId, dailyWasiya]);

  const searchResults = useMemo(
    () => searchWasayaInStorage(globalSearchQuery, searchCategoryFilter, searchBookFilter),
    [globalSearchQuery, searchCategoryFilter, searchBookFilter, favoriteIds]
  );

  const favoriteWasaya = useMemo(
    () => allWasaya.filter((w) => favoriteIds.includes(w.id)),
    [allWasaya, favoriteIds]
  );

  const handleToggleFavorite = (wasiyaId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const { favoriteIds: updated, isFavorite } = toggleWasayaFavorite(wasiyaId);
    setFavoriteIds(updated);
    showToast(isFavorite ? 'تم حفظ الوصية في المفضلة' : 'تمت إزالة الوصية من المفضلة');
  };

  const formatWasiyaForShare = (w: WasiyaItem): string => {
    return [
      `وصايا الرسول ﷺ — ${w.title}`,
      `«${w.text}»`,
      `الراوي: ${w.narrator}`,
      `المصدر: ${w.source} (${w.grade})`,
      `الشرح: ${w.explanation}`,
      '— تطبيق رِفْق | RIFQ',
    ].join('\n\n');
  };

  const handleCopyWasiya = async (w: WasiyaItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = formatWasiyaForShare(w);
    try {
      await navigator.clipboard.writeText(text);
      showToast('تم نسخ الوصية النبوية مع المصدر');
    } catch {
      showToast('تم نسخ الوصية النبوية');
    }
  };

  const handleShareWasiya = async (w: WasiyaItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = formatWasiyaForShare(w);
    if (navigator.share) {
      try {
        await navigator.share({
          title: `وصايا الرسول ﷺ — ${w.title}`,
          text,
        });
        return;
      } catch {
        // fallback to copy
      }
    }
    await handleCopyWasiya(w);
  };

  const handleCycleFontScale = () => {
    setFontScale((prev) => {
      const next = prev >= 1.35 ? 1 : Number((prev + 0.12).toFixed(2));
      showToast(next === 1 ? 'حجم الخط الافتراضي' : `تم تكبير الخط (${Math.round(next * 100)}%)`);
      return next;
    });
  };

  const openCategoryScreen = (catId: WasayaCategoryId) => {
    setSelectedCategoryId(catId);
    setCategorySearchQuery('');
    setPreviousScreen('home');
    setSubScreen('category');
  };

  const openDetailScreen = (wasiyaId: string, fromScreen: WasayaSubScreen) => {
    setSelectedWasiyaId(wasiyaId);
    setPreviousScreen(fromScreen);
    setSubScreen('detail');
  };

  // ألوان الوضع النهاري والليلي حسب المواصفات الإلزامية
  const pageBgClass = isDarkMode ? 'bg-[#121212] text-white' : 'bg-[#F7F7FC] text-[#25263A]';
  const cardBgClass = isDarkMode
    ? 'bg-[#1E1E1E] border-[#E6E6F0] text-white'
    : 'bg-[#FFFFFF] border-[#E6E6F0] text-[#25263A]';
  const innerBeigeBoxClass = isDarkMode
    ? 'bg-[#161616] border-[#E6E6F0] text-white'
    : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A]';
  const mutedTextClass = isDarkMode ? 'text-[#B0B0B0]' : 'text-[#77798C]';

  return (
    <div
      className={`min-h-[calc(100vh-120px)] rounded-[20px] p-4 sm:p-5 transition-colors duration-200 space-y-5 select-none ${pageBgClass}`}
      dir="rtl"
    >
      {/* إشعار Toast أنيق */}
      {toastMessage && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-white px-4 py-2.5 rounded-xl shadow-lg border border-[#5B5FEF] text-xs font-cairo font-bold flex items-center gap-2 animate-fade-in">
          <span className="w-2 h-2 rounded-full bg-[#5B5FEF]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =====================================================================
          الشاشة 1: الرئيسية لقسم وصايا الرسول ﷺ
      ===================================================================== */}
      {subScreen === 'home' && (
        <div className="space-y-5 animate-fade-in">
          {/* الشريط العلوي: رجوع + وصايا الرسول ﷺ + بحث + مفضلة + الوضع الليلي */}
          <div className={`rounded-[16px] p-4 border shadow-xs flex items-center justify-between gap-2 ${cardBgClass}`}>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onBack}
                aria-label="رجوع"
                className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <BackArrowSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
              <WasayaMushafHeartSvg size={38} />
              <div>
                <h1 className="font-cairo font-bold text-lg sm:text-xl leading-tight">
                  وصايا الرسول ﷺ
                </h1>
                <p className={`text-xs font-cairo ${mutedTextClass}`}>
                  جوامع الوصايا النبوية الصحيحة من أمهات كتب السنة
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setPreviousScreen('home');
                  setSubScreen('search');
                }}
                aria-label="بحث في الوصايا"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer"
              >
                <SearchIconSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setPreviousScreen('home');
                  setSubScreen('favorites');
                }}
                aria-label="المفضلة"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer"
              >
                <BookmarkHeartSvg
                  filled={favoriteIds.length > 0}
                  className="w-5 h-5 text-[#5B5FEF]"
                />
              </button>
              <button
                type="button"
                onClick={() => setIsDarkMode((d) => !d)}
                aria-label="الوضع الليلي"
                className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer"
              >
                <NightModeSvg isDark={isDarkMode} className="w-5 h-5 text-[#5B5FEF]" />
              </button>
            </div>
          </div>

          {/* البطاقة الترحيبية: الآية والحديث النبوي */}
          <div className={`rounded-[16px] p-5 border shadow-xs space-y-3 ${cardBgClass}`}>
            <div className={`rounded-xl p-4 border text-center space-y-2 ${innerBeigeBoxClass}`}>
              <p className="font-amiri font-bold text-lg sm:text-xl text-[#4CAF82] leading-relaxed">
                ﴿لَقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ﴾
              </p>
              <p className={`font-cairo text-xs ${mutedTextClass}`}>سورة الأحزاب: الآية 21</p>
            </div>

            <div className="pt-1 text-center space-y-1">
              <p className="font-amiri text-[18px] leading-relaxed">
                «تَرَكْتُ فِيكُمْ مَا إِنْ تَمَسَّكْتُمْ بِهِ لَنْ تَضِلُّوا بَعْدِي أَبَدًا»
              </p>
              <p className={`font-cairo text-xs ${mutedTextClass}`}>رواه مسلم</p>
            </div>
          </div>

          {/* شريط البحث السريع */}
          <div className={`rounded-[16px] p-3.5 border shadow-xs ${cardBgClass}`}>
            <div className="flex items-center gap-3">
              <span className="w-10 h-10 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                <SearchIconSvg className="w-5 h-5 text-[#5B5FEF]" />
              </span>
              <input
                type="text"
                value={globalSearchQuery}
                onChange={(e) => {
                  setGlobalSearchQuery(e.target.value);
                  if (e.target.value.trim().length > 0) {
                    setPreviousScreen('home');
                    setSubScreen('search');
                  }
                }}
                onFocus={() => {
                  setPreviousScreen('home');
                  setSubScreen('search');
                }}
                placeholder="ابحث في الوصايا النبوية، الموضوع، الراوي، أو المصدر..."
                className="w-full bg-transparent font-cairo text-sm focus:outline-none placeholder:text-[#77798C]"
              />
            </div>
          </div>

          {/* قسم "وصية اليوم" */}
          {dailyWasiya && (
            <div className={`rounded-[16px] p-5 border shadow-xs space-y-4 ${cardBgClass}`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
                <div className="flex items-center gap-2.5">
                  <WasayaMushafHeartSvg size={30} />
                  <div>
                    <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
                      وصية اليوم
                    </h2>
                    <p className={`font-cairo text-xs ${mutedTextClass}`}>
                      {dailyWasiya.title}
                    </p>
                  </div>
                </div>

                <span className={`font-cairo text-xs ${mutedTextClass}`}>
                  {dailyWasiya.subtopic}
                </span>
              </div>

              {/* نص الوصية في بطاقة بيج بخط Amiri 18px */}
              <div className={`rounded-xl p-4 border ${innerBeigeBoxClass}`}>
                <p
                  className="font-amiri text-[18px] leading-[1.95] text-center"
                  style={{ color: isDarkMode ? '#FFFFFF' : '#25263A' }}
                >
                  «{dailyWasiya.text}»
                </p>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <div className={`font-cairo text-xs ${mutedTextClass} space-y-0.5`}>
                  <p>{dailyWasiya.source}</p>
                  <p>{dailyWasiya.narrator}</p>
                </div>

                <button
                  type="button"
                  onClick={() => openDetailScreen(dailyWasiya.id, 'home')}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 shadow-xs hover:opacity-95 active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <span>اقرأ المزيد</span>
                  <EnterArrowSvg className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* شبكة التصنيفات (2×N) — 10 تصنيفات بدون أي شارة أو نجمة */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h2 className="font-cairo font-bold text-base sm:text-lg">
                تصنيفات وصايا الرسول ﷺ
              </h2>
              <span className={`font-cairo text-xs ${mutedTextClass}`}>
                10 تصنيفات · {allWasaya.length} وصية موثقة
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => openCategoryScreen(cat.id)}
                  className={`rounded-[16px] p-4 border text-right shadow-xs hover:border-[#5B5FEF] active:scale-[0.98] transition-all duration-200 cursor-pointer flex items-center justify-between gap-3 ${cardBgClass}`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* أيقونة SVG بمقاس 48×48 */}
                    <div className="shrink-0">
                      <WasayaCategorySvg48 categoryId={cat.id} size={48} />
                    </div>
                    <div className="min-w-0 space-y-1">
                      <h3 className="font-cairo font-bold text-[16px] leading-snug truncate">
                        {cat.name}
                      </h3>
                      <p className={`font-cairo text-xs ${mutedTextClass} truncate`}>
                        {cat.topics.join(' · ')}
                      </p>
                      <p className="font-cairo font-semibold text-xs text-[#5B5FEF]">
                        عدد الوصايا: {cat.count}
                      </p>
                    </div>
                  </div>

                  {/* سهم للدخول */}
                  <span className="w-9 h-9 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center text-[#25263A] shrink-0">
                    <EnterArrowSvg className="w-4 h-4 text-[#5B5FEF]" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          الشاشة 2: صفحة التصنيف (قائمة الوصايا داخل التصنيف)
      ===================================================================== */}
      {subScreen === 'category' && currentCategory && (
        <div className="space-y-4 animate-fade-in">
          {/* الشريط العلوي: رجوع + اسم التصنيف + بحث */}
          <div className={`rounded-[16px] p-4 border shadow-xs space-y-3 ${cardBgClass}`}>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setSubScreen('home')}
                  aria-label="رجوع"
                  className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <BackArrowSvg className="w-5 h-5 text-[#5B5FEF]" />
                </button>
                <WasayaCategorySvg48 categoryId={currentCategory.id} size={42} />
                <div>
                  <h1 className="font-cairo font-bold text-base sm:text-lg">
                    {currentCategory.name}
                  </h1>
                  <p className={`font-cairo text-xs ${mutedTextClass}`}>
                    {currentCategory.topics.join(' · ')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setSearchCategoryFilter(currentCategory.id);
                  setPreviousScreen('category');
                  setSubScreen('search');
                }}
                aria-label="بحث في التصنيف"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <SearchIconSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
            </div>

            {/* حقل البحث السريع داخل التصنيف */}
            <div className={`rounded-xl px-3.5 py-2.5 border flex items-center gap-2.5 ${innerBeigeBoxClass}`}>
              <SearchIconSvg className="w-4 h-4 text-[#5B5FEF] shrink-0" />
              <input
                type="text"
                value={categorySearchQuery}
                onChange={(e) => setCategorySearchQuery(e.target.value)}
                placeholder={`ابحث في ${currentCategory.name}...`}
                className="w-full bg-transparent font-cairo text-xs sm:text-sm focus:outline-none placeholder:text-[#77798C]"
              />
            </div>
          </div>

          {/* قائمة الوصايا في التصنيف */}
          <div className="space-y-3.5">
            {categoryWasaya.map((item) => (
              <div
                key={item.id}
                onClick={() => openDetailScreen(item.id, 'category')}
                className={`rounded-[16px] p-4 border shadow-xs hover:border-[#5B5FEF] transition-all cursor-pointer space-y-3.5 ${cardBgClass}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-cairo font-bold text-sm sm:text-base">
                    {item.title}
                  </h2>
                  <span className={`font-cairo text-xs ${mutedTextClass}`}>
                    {item.subtopic}
                  </span>
                </div>

                {/* نص الوصية بخط Amiri 18px في بطاقة بيج */}
                <div className={`rounded-xl p-4 border ${innerBeigeBoxClass}`}>
                  <p
                    className="font-amiri text-[18px] leading-[1.95]"
                    style={{ color: isDarkMode ? '#FFFFFF' : '#25263A' }}
                  >
                    «{item.text}»
                  </p>
                </div>

                {/* المصدر أسفل الوصية Cairo 12px رمادي + أزرار نسخ | مشاركة | مفضلة */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <p className={`font-cairo text-[12px] ${mutedTextClass}`}>
                    {item.source} — {item.narrator}
                  </p>

                  <div
                    className="flex items-center gap-2 self-end sm:self-auto"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      onClick={(e) => handleCopyWasiya(item, e)}
                      className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF] font-cairo font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                    >
                      <CopyIconSvg className="w-3.5 h-3.5 text-[#5B5FEF]" />
                      <span>نسخ</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleShareWasiya(item, e)}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                    >
                      <ShareIconSvg className="w-3.5 h-3.5 text-white" />
                      <span>مشاركة</span>
                    </button>

                    <button
                      type="button"
                      onClick={(e) => handleToggleFavorite(item.id, e)}
                      className={`px-3 py-1.5 rounded-xl border font-cairo font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer ${
                        favoriteIds.includes(item.id)
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                      }`}
                    >
                      <BookmarkHeartSvg
                        filled={favoriteIds.includes(item.id)}
                        className={`w-3.5 h-3.5 ${
                          favoriteIds.includes(item.id) ? 'text-white' : 'text-[#5B5FEF]'
                        }`}
                      />
                      <span>مفضلة</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          الشاشة 3: تفاصيل الوصية (البطاقة الرئيسية + الشرح + الفوائد + المصدر)
      ===================================================================== */}
      {subScreen === 'detail' && selectedWasiya && (
        <div className="space-y-4 animate-fade-in">
          {/* الشريط العلوي: رجوع + مفضلة + مشاركة */}
          <div className={`rounded-[16px] p-4 border shadow-xs flex items-center justify-between gap-2 ${cardBgClass}`}>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setSubScreen(previousScreen)}
                aria-label="رجوع"
                className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <BackArrowSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
              <div>
                <h1 className="font-cairo font-bold text-base sm:text-lg">
                  {selectedWasiya.title}
                </h1>
                <p className={`font-cairo text-xs ${mutedTextClass}`}>
                  {selectedWasiya.subtopic}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleToggleFavorite(selectedWasiya.id)}
                aria-label="مفضلة"
                className={`w-10 h-10 rounded-xl border flex items-center justify-center active:scale-95 transition-all cursor-pointer ${
                  favoriteIds.includes(selectedWasiya.id)
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                }`}
              >
                <BookmarkHeartSvg
                  filled={favoriteIds.includes(selectedWasiya.id)}
                  className="w-5 h-5"
                />
              </button>
              <button
                type="button"
                onClick={() => handleShareWasiya(selectedWasiya)}
                aria-label="مشاركة"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer"
              >
                <ShareIconSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
            </div>
          </div>

          {/* البطاقة الرئيسية للوصية */}
          <div className={`rounded-[16px] p-5 border shadow-xs space-y-4 ${cardBgClass}`}>
            <div className="flex items-center justify-center gap-3">
              <span className="h-[1px] w-12 bg-[#5B5FEF]" />
              <span className="font-cairo font-bold text-sm text-[#5B5FEF]">الوصية النبوية</span>
              <span className="h-[1px] w-12 bg-[#5B5FEF]" />
            </div>

            <div className={`rounded-xl p-5 border ${innerBeigeBoxClass}`}>
              <p
                className="font-amiri text-center leading-[2.05]"
                style={{
                  fontSize: `${Math.round(20 * fontScale)}px`,
                  color: isDarkMode ? '#FFFFFF' : '#25263A',
                }}
              >
                «{selectedWasiya.text}»
              </p>
            </div>

            <div className="pt-2 border-t border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-cairo">
              <div className="flex items-center gap-2">
                <BookSourceSvg className="w-4 h-4 text-[#5B5FEF] shrink-0" />
                <span className={mutedTextClass}>{selectedWasiya.source}</span>
              </div>
              <div className="flex items-center gap-2">
                <NarratorSvg className="w-4 h-4 text-[#4CAF82] shrink-0" />
                <span className={mutedTextClass}>{selectedWasiya.narrator}</span>
              </div>
            </div>
          </div>

          {/* قسم "الشرح" */}
          <div className={`rounded-[16px] p-5 border shadow-xs space-y-2.5 ${cardBgClass}`}>
            <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
              الشرح والمعنى الإجمالي
            </h2>
            <p
              className="font-cairo leading-[1.9]"
              style={{ fontSize: `${Math.round(15 * fontScale)}px` }}
            >
              {selectedWasiya.explanation}
            </p>
          </div>

          {/* قسم "الفوائد" */}
          <div className={`rounded-[16px] p-5 border shadow-xs space-y-3 ${cardBgClass}`}>
            <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
              الفوائد والدروس المستفادة
            </h2>
            <ol className="space-y-2.5">
              {selectedWasiya.lessons.map((lesson, idx) => (
                <li
                  key={idx}
                  className={`rounded-xl p-3 border flex items-start gap-3 font-cairo ${innerBeigeBoxClass}`}
                  style={{ fontSize: `${Math.round(14 * fontScale)}px` }}
                >
                  <span className="w-6 h-6 rounded-full bg-[#5B5FEF] text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{lesson}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* قسم "المصدر" */}
          <div className={`rounded-[16px] p-5 border shadow-xs space-y-3 ${cardBgClass}`}>
            <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
              بيانات المصدر والتخريج
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm font-cairo">
              <div className={`rounded-xl p-3 border ${innerBeigeBoxClass}`}>
                <span className={`block text-xs ${mutedTextClass}`}>الكتاب:</span>
                <span className="font-bold">{selectedWasiya.book}</span>
              </div>
              <div className={`rounded-xl p-3 border ${innerBeigeBoxClass}`}>
                <span className={`block text-xs ${mutedTextClass}`}>رقم الحديث:</span>
                <span className="font-bold">{selectedWasiya.hadith_number}</span>
              </div>
              <div className={`rounded-xl p-3 border ${innerBeigeBoxClass}`}>
                <span className={`block text-xs ${mutedTextClass}`}>الراوي:</span>
                <span className="font-bold">{selectedWasiya.narrator}</span>
              </div>
              <div className={`rounded-xl p-3 border ${innerBeigeBoxClass}`}>
                <span className={`block text-xs ${mutedTextClass}`}>درجة الحديث:</span>
                <span className="font-bold text-[#4CAF82]">{selectedWasiya.grade}</span>
              </div>
            </div>
          </div>

          {/* أزرار أسفل الشاشة: نسخ | مشاركة | مفضلة | تكبير الخط */}
          <div className={`rounded-[16px] p-4 border shadow-xs grid grid-cols-2 sm:grid-cols-4 gap-2.5 ${cardBgClass}`}>
            <button
              type="button"
              onClick={() => handleCopyWasiya(selectedWasiya)}
              className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF] font-cairo font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
            >
              <CopyIconSvg className="w-4 h-4 text-[#5B5FEF]" />
              <span>نسخ</span>
            </button>

            <button
              type="button"
              onClick={() => handleShareWasiya(selectedWasiya)}
              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
            >
              <ShareIconSvg className="w-4 h-4 text-white" />
              <span>مشاركة</span>
            </button>

            <button
              type="button"
              onClick={() => handleToggleFavorite(selectedWasiya.id)}
              className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer ${
                favoriteIds.includes(selectedWasiya.id)
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                  : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
              }`}
            >
              <BookmarkHeartSvg
                filled={favoriteIds.includes(selectedWasiya.id)}
                className="w-4 h-4"
              />
              <span>مفضلة</span>
            </button>

            <button
              type="button"
              onClick={handleCycleFontScale}
              className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF] font-cairo font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
            >
              <FontZoomSvg className="w-4 h-4 text-[#5B5FEF]" />
              <span>تكبير الخط</span>
            </button>
          </div>
        </div>
      )}

      {/* =====================================================================
          الشاشة 4: البحث الفوري مع الفلاتر
      ===================================================================== */}
      {subScreen === 'search' && (
        <div className="space-y-4 animate-fade-in">
          <div className={`rounded-[16px] p-4 border shadow-xs space-y-3.5 ${cardBgClass}`}>
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setSubScreen('home')}
                  aria-label="رجوع"
                  className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <BackArrowSvg className="w-5 h-5 text-[#5B5FEF]" />
                </button>
                <div>
                  <h1 className="font-cairo font-bold text-base sm:text-lg">
                    البحث في وصايا الرسول ﷺ
                  </h1>
                  <p className={`font-cairo text-xs ${mutedTextClass}`}>
                    النتائج المطابقة: {searchResults.length} وصية نبوية
                  </p>
                </div>
              </div>
            </div>

            {/* شريط البحث */}
            <div className={`rounded-xl px-3.5 py-2.5 border flex items-center gap-2.5 ${innerBeigeBoxClass}`}>
              <SearchIconSvg className="w-5 h-5 text-[#5B5FEF] shrink-0" />
              <input
                type="text"
                autoFocus
                value={globalSearchQuery}
                onChange={(e) => setGlobalSearchQuery(e.target.value)}
                placeholder="ابحث بنص الوصية، الشرح، الراوي، أو رقم الحديث..."
                className="w-full bg-transparent font-cairo text-sm focus:outline-none placeholder:text-[#77798C]"
              />
            </div>

            {/* فلاتر التصنيفات */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              <button
                type="button"
                onClick={() => setSearchCategoryFilter('all')}
                className={`px-3 py-1.5 rounded-xl font-cairo font-bold text-xs whitespace-nowrap transition-all cursor-pointer ${
                  searchCategoryFilter === 'all'
                    ? 'bg-[#5B5FEF] text-white'
                    : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                }`}
              >
                جميع التصنيفات
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSearchCategoryFilter(cat.id)}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold text-xs whitespace-nowrap transition-all cursor-pointer ${
                    searchCategoryFilter === cat.id
                      ? 'bg-[#5B5FEF] text-white'
                      : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            {/* فلاتر المصادر الحديثية */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
              {[
                { id: 'all', label: 'كل المصادر' },
                { id: 'البخاري', label: 'صحيح البخاري' },
                { id: 'مسلم', label: 'صحيح مسلم' },
                { id: 'الترمذي', label: 'جامع الترمذي' },
                { id: 'أبي داود', label: 'سنن أبي داود' },
                { id: 'ابن ماجه', label: 'سنن ابن ماجه' },
                { id: 'أحمد', label: 'مسند أحمد' },
              ].map((src) => (
                <button
                  key={src.id}
                  type="button"
                  onClick={() => setSearchBookFilter(src.id)}
                  className={`px-2.5 py-1 rounded-lg font-cairo font-bold text-[11px] whitespace-nowrap transition-all cursor-pointer ${
                    searchBookFilter === src.id
                      ? 'bg-[#5B5FEF] text-white'
                      : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                  }`}
                >
                  {src.label}
                </button>
              ))}
            </div>
          </div>

          {/* نتائج البحث الفورية */}
          <div className="space-y-3">
            {searchResults.map((item) => (
              <div
                key={item.id}
                onClick={() => openDetailScreen(item.id, 'search')}
                className={`rounded-[16px] p-4 border shadow-xs hover:border-[#5B5FEF] transition-all cursor-pointer space-y-3 ${cardBgClass}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <h2 className="font-cairo font-bold text-sm sm:text-base">{item.title}</h2>
                  <span className={`font-cairo text-xs ${mutedTextClass}`}>{item.subtopic}</span>
                </div>
                <div className={`rounded-xl p-3.5 border ${innerBeigeBoxClass}`}>
                  <p
                    className="font-amiri text-[18px] leading-[1.9]"
                    style={{ color: isDarkMode ? '#FFFFFF' : '#25263A' }}
                  >
                    «{item.text}»
                  </p>
                </div>
                <div className={`font-cairo text-xs ${mutedTextClass} flex items-center justify-between`}>
                  <span>{item.source}</span>
                  <span>{item.narrator}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          الشاشة 5: المفضلة (قائمة الوصايا المحفوظة بدون شارات)
      ===================================================================== */}
      {subScreen === 'favorites' && (
        <div className="space-y-4 animate-fade-in">
          <div className={`rounded-[16px] p-4 border shadow-xs flex items-center justify-between ${cardBgClass}`}>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setSubScreen('home')}
                aria-label="رجوع"
                className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer shrink-0"
              >
                <BackArrowSvg className="w-5 h-5 text-[#5B5FEF]" />
              </button>
              <div>
                <h1 className="font-cairo font-bold text-base sm:text-lg">
                  الوصايا المحفوظة في المفضلة
                </h1>
                <p className={`font-cairo text-xs ${mutedTextClass}`}>
                  عدد الوصايا المحفوظة: {favoriteWasaya.length}
                </p>
              </div>
            </div>
          </div>

          {favoriteWasaya.length === 0 ? (
            <div className={`rounded-[16px] p-8 border text-center space-y-3 ${cardBgClass}`}>
              <div className="flex justify-center">
                <WasayaMushafHeartSvg size={48} />
              </div>
              <p className="font-cairo font-bold text-base">
                لم تقم بحفظ أي وصية في المفضلة بعد
              </p>
              <p className={`font-cairo text-xs ${mutedTextClass}`}>
                اضغط على زر «مفضلة» أسفل أي وصية نبوية للرجوع إليها بسهولة في أي وقت
              </p>
              <button
                type="button"
                onClick={() => setSubScreen('home')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs cursor-pointer"
              >
                استعراض تصنيفات الوصايا
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {favoriteWasaya.map((item) => (
                <div
                  key={item.id}
                  onClick={() => openDetailScreen(item.id, 'favorites')}
                  className={`rounded-[16px] p-4 border shadow-xs hover:border-[#5B5FEF] transition-all cursor-pointer space-y-3 ${cardBgClass}`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-cairo font-bold text-sm sm:text-base">{item.title}</h2>
                    <span className={`font-cairo text-xs ${mutedTextClass}`}>{item.subtopic}</span>
                  </div>
                  <div className={`rounded-xl p-4 border ${innerBeigeBoxClass}`}>
                    <p
                      className="font-amiri text-[18px] leading-[1.95]"
                      style={{ color: isDarkMode ? '#FFFFFF' : '#25263A' }}
                    >
                      «{item.text}»
                    </p>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-1">
                    <span className={`font-cairo text-xs ${mutedTextClass}`}>
                      {item.source} — {item.narrator}
                    </span>
                    <div
                      className="flex items-center gap-2"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={(e) => handleCopyWasiya(item, e)}
                        className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs cursor-pointer"
                      >
                        نسخ
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleToggleFavorite(item.id, e)}
                        className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer"
                      >
                        إزالة
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
