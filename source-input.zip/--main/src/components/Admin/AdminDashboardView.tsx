import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Users,
  Activity,
  UserPlus,
  Smartphone,
  Bell,
  AlertTriangle,
  BookOpen,
  Search,
  RefreshCw,
  ArrowRight,
  Copy,
  Check,
  Ban,
  UserCheck,
  Trash2,
  Send,
  Eye,
  FileText,
  Settings,
  Lock,
  CheckCircle2,
  XCircle,
  Clock,
  MessageSquare,
  X,
  ChevronLeft,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSafeTheme } from '../../context/ThemeContext';
import { ScreenType, WardType } from '../../types';
import {
  AdminDashboardStats,
  AdminUserSummary,
  NotificationDeviceRecord,
  AdminNotificationRecord,
  UserReportRecord,
  AdminAuditLogRecord,
  SystemConfigRecord,
  AdminGroupSummary,
  ReportStatus,
  fetchAdminDashboardStats,
  fetchAdminUsersPage,
  searchAdminUsersInFirestore,
  inspectAdminUserDetails,
  updateUserAccountStatusByAdmin,
  setUserAdminRoleByAdmin,
  deleteUserCloudDataByAdmin,
  sendAdminBroadcastNotification,
  fetchAdminSentNotifications,
  deleteAdminNotificationById,
  fetchRegisteredNotificationDevices,
  fetchAdminWirdGroups,
  inspectAdminGroupSubcollections,
  toggleWirdGroupStatusByAdmin,
  deleteWirdGroupMessageByAdmin,
  deleteWirdGroupByAdmin,
  fetchAdminReports,
  updateReportStatusByAdmin,
  deleteReportByAdmin,
  fetchAdminAuditLogs,
  fetchGlobalSystemConfig,
  updateGlobalSystemConfigByAdmin,
  formatAdminOperationError,
  PRIMARY_ADMIN_EMAIL,
} from '../../utils/adminService';
import { QueryDocumentSnapshot, DocumentData } from 'firebase/firestore';

interface AdminDashboardViewProps {
  onBack: () => void;
  onNavigate: (screen: ScreenType) => void;
}

type AdminTabId =
  | 'overview'
  | 'users'
  | 'notifications'
  | 'groups'
  | 'reports'
  | 'audit_settings';

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  onBack,
  onNavigate,
}) => {
  const { currentUser, isAdmin, adminChecking, verifyAdminNow, openAuthModal } = useAuth();
  const { isGirly } = useSafeTheme();

  const [verifiedServerAdmin, setVerifiedServerAdmin] = useState<boolean | null>(null);
  const [verifyingAccess, setVerifyingAccess] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<AdminTabId>('overview');

  // Global feedback banners (only shown after a real operation completes or fails)
  const [operationError, setOperationError] = useState<string | null>(null);
  const [operationSuccess, setOperationSuccess] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  // 1. Overview Stats State
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [loadingStats, setLoadingStats] = useState<boolean>(false);

  // 2. Users State
  const [usersList, setUsersList] = useState<AdminUserSummary[]>([]);
  const [usersLastDoc, setUsersLastDoc] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [usersHasMore, setUsersHasMore] = useState<boolean>(false);
  const [loadingUsers, setLoadingUsers] = useState<boolean>(false);
  const [userSearchQuery, setUserSearchQuery] = useState<string>('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'admin' | 'user'>('all');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'suspended' | 'banned'>('all');

  // User Modals State
  const [inspectedUser, setInspectedUser] = useState<{
    profile: AdminUserSummary;
    rawProfile: Record<string, any>;
    deviceStatus: NotificationDeviceRecord | null;
    journeysCount: number;
    achievementsCount: number;
  } | null>(null);
  const [loadingInspectUser, setLoadingInspectUser] = useState<boolean>(false);

  const [statusModalUser, setStatusModalUser] = useState<AdminUserSummary | null>(null);
  const [newAccountStatus, setNewAccountStatus] = useState<'active' | 'suspended' | 'banned'>('active');
  const [statusReasonInput, setStatusReasonInput] = useState<string>('');
  const [savingUserStatus, setSavingUserStatus] = useState<boolean>(false);

  const [deleteModalUser, setDeleteModalUser] = useState<AdminUserSummary | null>(null);
  const [deleteConfirmInput, setDeleteConfirmInput] = useState<string>('');
  const [deletingUser, setDeletingUser] = useState<boolean>(false);

  const [roleProcessingUid, setRoleProcessingUid] = useState<string | null>(null);

  // 3. Notifications & Devices State
  const [sentNotifications, setSentNotifications] = useState<AdminNotificationRecord[]>([]);
  const [devicesList, setDevicesList] = useState<NotificationDeviceRecord[]>([]);
  const [loadingNotifsTab, setLoadingNotifsTab] = useState<boolean>(false);
  const [notifTitle, setNotifTitle] = useState<string>('');
  const [notifMessage, setNotifMessage] = useState<string>('');
  const [notifType, setNotifType] = useState<'general' | 'reminder' | 'milestone'>('general');
  const [notifTargetType, setNotifTargetType] = useState<'all' | 'user'>('all');
  const [notifTargetUid, setNotifTargetUid] = useState<string>('');
  const [notifActionScreen, setNotifActionScreen] = useState<ScreenType | ''>('');
  const [notifActionWard, setNotifActionWard] = useState<WardType | ''>('');
  const [sendingNotif, setSendingNotif] = useState<boolean>(false);

  // 4. Groups State
  const [groupsList, setGroupsList] = useState<AdminGroupSummary[]>([]);
  const [loadingGroups, setLoadingGroups] = useState<boolean>(false);
  const [groupSearchQuery, setGroupSearchQuery] = useState<string>('');
  const [inspectedGroup, setInspectedGroup] = useState<{
    group: AdminGroupSummary;
    members: Array<{ userId: string; displayName: string; role: string; dailyProgress: number; joinedAt: string }>;
    messages: Array<{ id: string; userId: string; userName: string; message: string; category: string; createdAt: string }>;
  } | null>(null);
  const [loadingGroupInspect, setLoadingGroupInspect] = useState<boolean>(false);
  const [processingGroupId, setProcessingGroupId] = useState<string | null>(null);

  // 5. Reports State
  const [reportsList, setReportsList] = useState<UserReportRecord[]>([]);
  const [loadingReports, setLoadingReports] = useState<boolean>(false);
  const [reportStatusFilter, setReportStatusFilter] = useState<'all' | ReportStatus>('all');
  const [selectedReport, setSelectedReport] = useState<UserReportRecord | null>(null);
  const [reportNewStatus, setReportNewStatus] = useState<ReportStatus>('open');
  const [reportAdminReply, setReportAdminReply] = useState<string>('');
  const [savingReport, setSavingReport] = useState<boolean>(false);

  // 6. Audit Logs & System Config State
  const [auditLogs, setAuditLogs] = useState<AdminAuditLogRecord[]>([]);
  const [systemConfig, setSystemConfig] = useState<SystemConfigRecord>({
    announcementEnabled: false,
    announcementTitle: '',
    announcementMessage: '',
    announcementType: 'info',
  });
  const [loadingAuditSettings, setLoadingAuditSettings] = useState<boolean>(false);
  const [savingSystemConfig, setSavingSystemConfig] = useState<boolean>(false);

  const showRealSuccess = (msg: string) => {
    setOperationError(null);
    setOperationSuccess(msg);
    setTimeout(() => {
      setOperationSuccess((prev) => (prev === msg ? null : prev));
    }, 5000);
  };

  const showRealError = (err: unknown) => {
    setOperationSuccess(null);
    setOperationError(formatAdminOperationError(err));
  };

  // Strict server-side RBAC check on mount and when user changes
  useEffect(() => {
    let active = true;
    const runVerification = async () => {
      setVerifyingAccess(true);
      try {
        const verified = await verifyAdminNow();
        if (active) {
          setVerifiedServerAdmin(verified);
        }
      } catch {
        if (active) {
          setVerifiedServerAdmin(false);
        }
      } finally {
        if (active) {
          setVerifyingAccess(false);
        }
      }
    };
    runVerification();
    return () => {
      active = false;
    };
  }, [currentUser?.uid, verifyAdminNow]);

  // Load Overview Dashboard Data
  const loadOverviewData = useCallback(async () => {
    setLoadingStats(true);
    setOperationError(null);
    try {
      const [fetchedStats, recentLogs, recentReports] = await Promise.all([
        fetchAdminDashboardStats(),
        fetchAdminAuditLogs(8).catch(() => []),
        fetchAdminReports().catch(() => []),
      ]);
      setStats(fetchedStats);
      setAuditLogs(recentLogs);
      setReportsList(recentReports);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingStats(false);
    }
  }, []);

  // Load Users Tab Data
  const loadInitialUsers = useCallback(async () => {
    setLoadingUsers(true);
    setOperationError(null);
    try {
      const res = await fetchAdminUsersPage({ pageSize: 25 });
      setUsersList(res.users);
      setUsersLastDoc(res.lastDoc);
      setUsersHasMore(res.hasMore);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingUsers(false);
    }
  }, []);

  const handleLoadMoreUsers = async () => {
    if (!usersLastDoc || loadingUsers) return;
    setLoadingUsers(true);
    setOperationError(null);
    try {
      const res = await fetchAdminUsersPage({ pageSize: 25, lastDoc: usersLastDoc });
      setUsersList((prev) => {
        const existingIds = new Set(prev.map((u) => u.uid));
        const uniqueNew = res.users.filter((u) => !existingIds.has(u.uid));
        return [...prev, ...uniqueNew];
      });
      setUsersLastDoc(res.lastDoc);
      setUsersHasMore(res.hasMore);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleSearchUsers = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoadingUsers(true);
    setOperationError(null);
    try {
      if (!userSearchQuery.trim()) {
        await loadInitialUsers();
        return;
      }
      const results = await searchAdminUsersInFirestore(userSearchQuery);
      setUsersList(results);
      setUsersHasMore(false);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingUsers(false);
    }
  };

  // Load Notifications & Devices Tab Data
  const loadNotificationsTabData = useCallback(async () => {
    setLoadingNotifsTab(true);
    setOperationError(null);
    try {
      const [notifs, devices] = await Promise.all([
        fetchAdminSentNotifications(30),
        fetchRegisteredNotificationDevices(40),
      ]);
      setSentNotifications(notifs);
      setDevicesList(devices);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingNotifsTab(false);
    }
  }, []);

  // Load Groups Tab Data
  const loadGroupsTabData = useCallback(async () => {
    setLoadingGroups(true);
    setOperationError(null);
    try {
      const list = await fetchAdminWirdGroups();
      setGroupsList(list);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingGroups(false);
    }
  }, []);

  // Load Reports Tab Data
  const loadReportsTabData = useCallback(async () => {
    setLoadingReports(true);
    setOperationError(null);
    try {
      const list = await fetchAdminReports();
      setReportsList(list);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingReports(false);
    }
  }, []);

  // Load Audit Logs & System Settings Tab Data
  const loadAuditAndSettingsData = useCallback(async () => {
    setLoadingAuditSettings(true);
    setOperationError(null);
    try {
      const [logs, cfg] = await Promise.all([
        fetchAdminAuditLogs(50),
        fetchGlobalSystemConfig(),
      ]);
      setAuditLogs(logs);
      if (cfg) setSystemConfig(cfg);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingAuditSettings(false);
    }
  }, []);

  // Trigger tab-specific data fetch when verified admin switches tabs
  useEffect(() => {
    if (!verifiedServerAdmin || !isAdmin) return;
    if (activeTab === 'overview') {
      loadOverviewData();
    } else if (activeTab === 'users') {
      loadInitialUsers();
    } else if (activeTab === 'notifications') {
      loadNotificationsTabData();
    } else if (activeTab === 'groups') {
      loadGroupsTabData();
    } else if (activeTab === 'reports') {
      loadReportsTabData();
    } else if (activeTab === 'audit_settings') {
      loadAuditAndSettingsData();
    }
  }, [
    verifiedServerAdmin,
    isAdmin,
    activeTab,
    loadOverviewData,
    loadInitialUsers,
    loadNotificationsTabData,
    loadGroupsTabData,
    loadReportsTabData,
    loadAuditAndSettingsData,
  ]);

  const handleCopyUid = (uid: string) => {
    navigator.clipboard.writeText(uid).catch(() => {});
    setCopiedUid(uid);
    setTimeout(() => setCopiedUid(null), 2000);
  };

  // ─── Real User Actions ───
  const handleInspectUser = async (uid: string) => {
    setLoadingInspectUser(true);
    setOperationError(null);
    try {
      const details = await inspectAdminUserDetails(uid);
      setInspectedUser(details);
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingInspectUser(false);
    }
  };

  const handleSaveUserAccountStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusModalUser) return;
    setSavingUserStatus(true);
    setOperationError(null);
    try {
      await updateUserAccountStatusByAdmin({
        targetUid: statusModalUser.uid,
        targetName: statusModalUser.displayName,
        newStatus: newAccountStatus,
        reason: statusReasonInput,
      });
      setUsersList((prev) =>
        prev.map((u) =>
          u.uid === statusModalUser.uid
            ? { ...u, accountStatus: newAccountStatus, statusReason: statusReasonInput.trim() || undefined }
            : u
        )
      );
      setStatusModalUser(null);
      showRealSuccess(`تم تحديث حالة حساب "${statusModalUser.displayName}" في قاعدة البيانات بنجاح.`);
    } catch (err) {
      showRealError(err);
    } finally {
      setSavingUserStatus(false);
    }
  };

  const handleToggleAdminRole = async (user: AdminUserSummary) => {
    const targetMakeAdmin = user.role !== 'admin';
    setRoleProcessingUid(user.uid);
    setOperationError(null);
    try {
      await setUserAdminRoleByAdmin({
        targetUid: user.uid,
        targetName: user.displayName,
        targetEmail: user.email,
        makeAdmin: targetMakeAdmin,
      });
      setUsersList((prev) =>
        prev.map((u) => (u.uid === user.uid ? { ...u, role: targetMakeAdmin ? 'admin' : 'user' } : u))
      );
      showRealSuccess(
        targetMakeAdmin
          ? `تم منح صلاحية مسؤول (Admin) للمستخدم "${user.displayName}" في سجل /admins بنجاح.`
          : `تم سحب صلاحية المسؤول من "${user.displayName}" وإرجاعه إلى مستخدم عادي (User).`
      );
    } catch (err) {
      showRealError(err);
    } finally {
      setRoleProcessingUid(null);
    }
  };

  const handleConfirmDeleteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deleteModalUser) return;
    if (deleteConfirmInput.trim() !== 'حذف') {
      setOperationError('يرجى كتابة كلمة "حذف" للتأكيد قبل تنفيذ الحذف النهائي.');
      return;
    }

    setDeletingUser(true);
    setOperationError(null);
    try {
      await deleteUserCloudDataByAdmin({
        targetUid: deleteModalUser.uid,
        targetName: deleteModalUser.displayName,
      });
      setUsersList((prev) => prev.filter((u) => u.uid !== deleteModalUser.uid));
      setDeleteModalUser(null);
      setDeleteConfirmInput('');
      showRealSuccess(`تم حذف السجل السحابي للمستخدم "${deleteModalUser.displayName}" وتحديث عداد المستخدمين.`);
    } catch (err) {
      showRealError(err);
    } finally {
      setDeletingUser(false);
    }
  };

  // ─── Real Notification Actions ───
  const handleSendBroadcastNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setSendingNotif(true);
    setOperationError(null);
    try {
      const created = await sendAdminBroadcastNotification({
        title: notifTitle,
        message: notifMessage,
        type: notifType,
        targetType: notifTargetType,
        targetUid: notifTargetUid,
        actionScreen: notifActionScreen,
        actionWard: notifActionWard,
      });
      setSentNotifications((prev) => [created, ...prev]);
      setNotifTitle('');
      setNotifMessage('');
      setNotifTargetUid('');
      showRealSuccess('تم إرسال الإشعار وحفظه في Firestore ليصل فورياً للمستخدمين المستهدفين.');
    } catch (err) {
      showRealError(err);
    } finally {
      setSendingNotif(false);
    }
  };

  const handleDeleteSentNotification = async (notif: AdminNotificationRecord) => {
    setOperationError(null);
    try {
      await deleteAdminNotificationById(notif.id, notif.title);
      setSentNotifications((prev) => prev.filter((n) => n.id !== notif.id));
      showRealSuccess(`تم حذف الإشعار "${notif.title}" من قاعدة البيانات.`);
    } catch (err) {
      showRealError(err);
    }
  };

  // ─── Real Group Moderation Actions ───
  const handleInspectGroup = async (group: AdminGroupSummary) => {
    setLoadingGroupInspect(true);
    setOperationError(null);
    try {
      const sub = await inspectAdminGroupSubcollections(group.id);
      setInspectedGroup({
        group,
        members: sub.members,
        messages: sub.messages,
      });
    } catch (err) {
      showRealError(err);
    } finally {
      setLoadingGroupInspect(false);
    }
  };

  const handleToggleGroupStatus = async (group: AdminGroupSummary) => {
    const nextActive = !group.isActive;
    setProcessingGroupId(group.id);
    setOperationError(null);
    try {
      await toggleWirdGroupStatusByAdmin(group.id, group.groupName, nextActive);
      setGroupsList((prev) =>
        prev.map((g) => (g.id === group.id ? { ...g, isActive: nextActive } : g))
      );
      if (inspectedGroup?.group.id === group.id) {
        setInspectedGroup({
          ...inspectedGroup,
          group: { ...inspectedGroup.group, isActive: nextActive },
        });
      }
      showRealSuccess(
        nextActive
          ? `تم إعادة تفعيل مجموعة "${group.groupName}".`
          : `تم إيقاف مجموعة "${group.groupName}".`
      );
    } catch (err) {
      showRealError(err);
    } finally {
      setProcessingGroupId(null);
    }
  };

  const handleDeleteGroupMessage = async (groupId: string, msgId: string, text: string) => {
    setOperationError(null);
    try {
      await deleteWirdGroupMessageByAdmin(groupId, msgId, text);
      if (inspectedGroup && inspectedGroup.group.id === groupId) {
        setInspectedGroup({
          ...inspectedGroup,
          messages: inspectedGroup.messages.filter((m) => m.id !== msgId),
        });
      }
      showRealSuccess('تم حذف الرسالة من حائط المجموعة فعلياً.');
    } catch (err) {
      showRealError(err);
    }
  };

  const handleDeleteGroup = async (group: AdminGroupSummary) => {
    setProcessingGroupId(group.id);
    setOperationError(null);
    try {
      await deleteWirdGroupByAdmin(group.id, group.groupName);
      setGroupsList((prev) => prev.filter((g) => g.id !== group.id));
      if (inspectedGroup?.group.id === group.id) {
        setInspectedGroup(null);
      }
      showRealSuccess(`تم حذف مجموعة "${group.groupName}" وجميع بياناتها الفرعية نهائياً.`);
    } catch (err) {
      showRealError(err);
    } finally {
      setProcessingGroupId(null);
    }
  };

  // ─── Real Report Moderation Actions ───
  const handleSaveReportUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReport) return;
    setSavingReport(true);
    setOperationError(null);
    try {
      await updateReportStatusByAdmin({
        reportId: selectedReport.id,
        subject: selectedReport.subject,
        newStatus: reportNewStatus,
        adminResponse: reportAdminReply,
        reporterUid: selectedReport.reporterUid,
        category: selectedReport.category,
      });
      const nowIso = new Date().toISOString();
      setReportsList((prev) =>
        prev.map((r) =>
          r.id === selectedReport.id
            ? {
                ...r,
                status: reportNewStatus,
                adminResponse: reportAdminReply.trim() || null,
                updatedAt: nowIso,
              }
            : r
        )
      );
      setSelectedReport(null);
      showRealSuccess('تم تحديث حالة البلاغ وحفظ الرد الإداري في Firestore بنجاح.');
    } catch (err) {
      showRealError(err);
    } finally {
      setSavingReport(false);
    }
  };

  const handleDeleteReport = async (rep: UserReportRecord) => {
    setOperationError(null);
    try {
      await deleteReportByAdmin(rep.id, rep.subject);
      setReportsList((prev) => prev.filter((r) => r.id !== rep.id));
      if (selectedReport?.id === rep.id) setSelectedReport(null);
      showRealSuccess(`تم حذف البلاغ "${rep.subject}" نهائياً.`);
    } catch (err) {
      showRealError(err);
    }
  };

  // ─── Real System Config Actions ───
  const handleSaveSystemConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSystemConfig(true);
    setOperationError(null);
    try {
      await updateGlobalSystemConfigByAdmin(systemConfig);
      showRealSuccess('تم حفظ إعدادات النظام والتنبيه العام في Firestore بنجاح.');
      const updatedLogs = await fetchAdminAuditLogs(50);
      setAuditLogs(updatedLogs);
    } catch (err) {
      showRealError(err);
    } finally {
      setSavingSystemConfig(false);
    }
  };

  // Format date helper (never fabricates dates)
  const formatRealDateTime = (isoOrNull?: string | null, msOrNull?: number | null): string => {
    if (isoOrNull) {
      const d = new Date(isoOrNull);
      if (!isNaN(d.getTime())) {
        return d.toLocaleString('ar-SA', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });
      }
    }
    if (typeof msOrNull === 'number' && msOrNull > 0) {
      const d = new Date(msOrNull);
      if (!isNaN(d.getTime())) {
        return d.toLocaleString('ar-SA', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        });
      }
    }
    return 'غير متاح';
  };

  const formatMetricValue = (val: number | null | undefined): string => {
    if (val === null || val === undefined || Number.isNaN(val)) {
      return 'غير متاح';
    }
    return val.toLocaleString('ar-EG');
  };

  // ─── 1. Verification Loading State ───
  if (verifyingAccess || adminChecking) {
    return (
      <div className="w-full max-w-2xl mx-auto py-16 px-4 text-center space-y-4 font-tajawal" dir="rtl">
        <div className="w-16 h-16 rounded-3xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center mx-auto text-[#5B5FEF]">
          <RefreshCw className="w-8 h-8 animate-spin" />
        </div>
        <h2 className="text-lg font-black text-[#25263A]">
          جاري التحقق الفعلي من صلاحيات المسؤول (Server RBAC)...
        </h2>
        <p className="text-xs text-[#77798C]">
          يتم الآن فحص سجل الصلاحيات الموثق في قاعدة بيانات Firebase Firestore.
        </p>
      </div>
    );
  }

  // ─── 2. Strict Access Denied Gate for Non-Admins & Guests ───
  if (!currentUser || !isAdmin || !verifiedServerAdmin) {
    return (
      <div className="w-full max-w-xl mx-auto py-12 px-4 font-tajawal animate-fade-in" dir="rtl">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E6E6F0] shadow-lg text-center space-y-5">
          <div className="w-16 h-16 rounded-3xl bg-red-50 border border-red-200 text-[#D95C6A] flex items-center justify-center mx-auto">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full bg-red-50 text-[#D95C6A] border border-red-200 text-xs font-black">
              منطقة محمية • 403 Forbidden
            </span>
            <h2 className="text-xl font-black text-[#25263A] pt-1">
              غير مصرح لك بالوصول إلى لوحة الإدارة
            </h2>
            <p className="text-xs text-[#77798C] leading-relaxed">
              لوحة إدارة رِفْق محمية عبر قواعد أمان Firebase Firestore وسجل صلاحيات المشرفين (`/admins`). لا يمكن لحسابات المستخدمين العاديين الوصول إلى هذه الصفحة أو استدعاء عملياتها.
            </p>
          </div>

          {currentUser ? (
            <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-right text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[#77798C] font-bold">الحساب الحالي:</span>
                <span className="font-bold text-[#25263A]" dir="ltr">
                  {currentUser.email || 'بدون بريد'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#77798C] font-bold">معرف UID:</span>
                <span className="font-mono text-[11px] text-[#25263A]" dir="ltr">
                  {currentUser.uid}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#77798C] font-bold">الدور الفعلي الموثق:</span>
                <span className="px-2 py-0.5 rounded-md bg-gray-200 text-gray-700 font-bold text-[11px]">
                  User (مستخدم عادي)
                </span>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#77798C]">
              أنت غير مسجل الدخول حالياً. إذا كنت تملك حساب مسؤول معتمد، يرجى تسجيل الدخول أولاً.
            </div>
          )}

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            {!currentUser && (
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black cursor-pointer transition-all"
              >
                تسجيل الدخول بحساب مسؤول
              </button>
            )}
            <button
              type="button"
              onClick={onBack}
              className="px-5 py-2.5 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-xs font-black cursor-pointer transition-all flex items-center gap-1.5"
            >
              <ArrowRight className="w-4 h-4" />
              <span>العودة إلى الرئيسية</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Filtered users in UI after server query
  const filteredUsers = usersList.filter((u) => {
    if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
    if (userStatusFilter !== 'all' && u.accountStatus !== userStatusFilter) return false;
    return true;
  });

  // Filtered groups
  const filteredGroups = groupsList.filter((g) => {
    if (!groupSearchQuery.trim()) return true;
    const q = groupSearchQuery.trim().toLowerCase();
    return (
      g.groupName.toLowerCase().includes(q) ||
      g.joinCode.toLowerCase().includes(q) ||
      g.adminName.toLowerCase().includes(q) ||
      g.id.toLowerCase().includes(q)
    );
  });

  // Filtered reports
  const filteredReports = reportsList.filter((r) => {
    if (reportStatusFilter === 'all') return true;
    if (reportStatusFilter === 'open') return r.status === 'open' || r.status === 'new';
    return r.status === reportStatusFilter;
  });

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-24 font-tajawal" dir="rtl">
      {/* ─── Top Admin Header Card ─── */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E6E6F0] relative overflow-hidden">
        <div
          className="absolute top-0 right-0 left-0 h-1.5"
          style={{ background: 'var(--theme-header-gradient)' }}
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <button
              type="button"
              onClick={onBack}
              className="w-10 h-10 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] flex items-center justify-center transition-colors cursor-pointer shrink-0"
              title="الرجوع"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg sm:text-xl font-black text-[#25263A]">
                  لوحة الإدارة المركزية • رِفْق
                </h1>
                <span
                  className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] flex items-center gap-1"
                  style={isGirly ? { borderColor: '#CFA06A', color: '#B56582' } : undefined}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin موثق</span>
                </span>
              </div>
              <p className="text-xs text-[#77798C] mt-0.5">
                متصل مباشرة بـ Firebase Firestore • المسؤول الحالي:{' '}
                <span className="font-bold text-[#25263A]" dir="ltr">
                  {currentUser.email || currentUser.uid}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            <button
              type="button"
              onClick={() => {
                if (activeTab === 'overview') loadOverviewData();
                else if (activeTab === 'users') loadInitialUsers();
                else if (activeTab === 'notifications') loadNotificationsTabData();
                else if (activeTab === 'groups') loadGroupsTabData();
                else if (activeTab === 'reports') loadReportsTabData();
                else if (activeTab === 'audit_settings') loadAuditAndSettingsData();
              }}
              className="px-3.5 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${
                  loadingStats ||
                  loadingUsers ||
                  loadingNotifsTab ||
                  loadingGroups ||
                  loadingReports ||
                  loadingAuditSettings
                    ? 'animate-spin'
                    : ''
                }`}
              />
              <span>تحديث البيانات</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-4 mt-4 border-t border-[#E6E6F0] no-scrollbar">
          {[
            { id: 'overview', label: '📊 لوحة التحكم', icon: Activity },
            { id: 'users', label: '👥 المستخدمون', icon: Users },
            { id: 'notifications', label: '🔔 الإشعارات والأجهزة', icon: Bell },
            { id: 'groups', label: '📖 مجموعات وِرد', icon: BookOpen },
            { id: 'reports', label: '⚠️ البلاغات المفتوحة', icon: AlertTriangle },
            { id: 'audit_settings', label: '📜 السجل والإعدادات', icon: FileText },
          ].map((tab) => {
            const isTabActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setOperationError(null);
                  setOperationSuccess(null);
                  setActiveTab(tab.id as AdminTabId);
                }}
                className={`px-3.5 py-2 rounded-2xl text-xs font-black whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 border ${
                  isTabActive
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                    : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:bg-[#EEEEFF]'
                }`}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ─── Real Operation Error / Success Banners ─── */}
      {operationError && (
        <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-800 text-xs font-bold flex items-start justify-between gap-3 animate-fade-in">
          <div className="flex items-start gap-2.5">
            <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-black text-red-900">فشلت العملية — تفاصيل الخطأ من الخادم:</div>
              <p className="leading-relaxed">{operationError}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOperationError(null)}
            className="p-1 rounded-lg hover:bg-red-100 text-red-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {operationSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{operationSuccess}</span>
          </div>
          <button
            type="button"
            onClick={() => setOperationSuccess(null)}
            className="p-1 rounded-lg hover:bg-emerald-100 text-emerald-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 1: 📊 لوحة التحكم (Real Server-Aggregated Overview)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fade-in">
          {/* 6 Core Real KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* 1. إجمالي المستخدمين */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">👥 إجمالي المستخدمين</span>
                <div className="w-10 h-10 rounded-2xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center border border-[#E6E6F0]">
                  <Users className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats ? '...' : formatMetricValue(stats?.totalUsers)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>المشرفون الموثقون: {formatMetricValue(stats?.totalAdminsCount)}</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('users')}
                  className="font-bold text-[#5B5FEF] hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>إدارة</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* 2. المستخدمون النشطون */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">🟢 المستخدمون النشطون</span>
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-[#4CAF82] flex items-center justify-center border border-emerald-200">
                  <Activity className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats ? '...' : formatMetricValue(stats?.activeUsers7d)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>خلال آخر 7 أيام</span>
                <span>آخر 24 ساعة: {formatMetricValue(stats?.activeUsers24h)}</span>
              </div>
            </div>

            {/* 3. التسجيلات الجديدة */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">🆕 التسجيلات الجديدة</span>
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                  <UserPlus className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats ? '...' : formatMetricValue(stats?.newUsers7d)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>خلال آخر 7 أيام</span>
                <span>اليوم: {formatMetricValue(stats?.newUsersToday)}</span>
              </div>
            </div>

            {/* 4. الأجهزة/التوكنات النشطة للإشعارات */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">
                  📱 الأجهزة النشطة للإشعارات
                </span>
                <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center border border-purple-200">
                  <Smartphone className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats
                  ? '...'
                  : formatMetricValue(stats?.activeNotificationDevices)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>
                  إجمالي الأجهزة المسجلة: {formatMetricValue(stats?.totalNotificationDevices)}
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('notifications')}
                  className="font-bold text-[#5B5FEF] hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>عرض</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* 5. الإشعارات المرسلة */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">🔔 الإشعارات المرسلة</span>
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-[#E8B84A] flex items-center justify-center border border-amber-200">
                  <Bell className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats
                  ? '...'
                  : formatMetricValue(stats?.sentNotificationsCount)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>مجموعات وِرد النشطة: {formatMetricValue(stats?.activeGroupsCount)}</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('notifications')}
                  className="font-bold text-[#5B5FEF] hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>إرسال جديد</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* 6. البلاغات المفتوحة */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs flex flex-col justify-between gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#77798C]">⚠️ البلاغات المفتوحة</span>
                <div className="w-10 h-10 rounded-2xl bg-red-50 text-[#D95C6A] flex items-center justify-center border border-red-200">
                  <AlertTriangle className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl font-black text-[#25263A]">
                {loadingStats && !stats ? '...' : formatMetricValue(stats?.openReportsCount)}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-2 border-t border-[#E6E6F0]">
                <span>إجمالي البلاغات: {formatMetricValue(stats?.totalReportsCount)}</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('reports')}
                  className="font-bold text-[#5B5FEF] hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <span>مراجعة</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Recent Audit Logs & Open Reports Quick View */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Recent Audit Logs */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
                <h3 className="font-black text-sm text-[#25263A] flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#5B5FEF]" />
                  <span>أحدث عمليات الإدارة الموثقة</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setActiveTab('audit_settings')}
                  className="text-xs font-bold text-[#5B5FEF] hover:underline cursor-pointer"
                >
                  عرض الكل
                </button>
              </div>

              {auditLogs.length === 0 ? (
                <div className="p-6 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                  لا توجد عمليات مسجلة في سجل التدقيق حتى الآن.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {auditLogs.slice(0, 5).map((log) => (
                    <div
                      key={log.id}
                      className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs space-y-1"
                    >
                      <p className="font-bold text-[#25263A]">{log.details}</p>
                      <div className="flex items-center justify-between text-[10px] text-[#77798C]">
                        <span dir="ltr">{log.adminEmail || log.adminUid}</span>
                        <span>{formatRealDateTime(log.createdAt)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Open Reports */}
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
                <h3 className="font-black text-sm text-[#25263A] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#D95C6A]" />
                  <span>أحدث البلاغات الواردة</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setActiveTab('reports')}
                  className="text-xs font-bold text-[#5B5FEF] hover:underline cursor-pointer"
                >
                  إدارة البلاغات
                </button>
              </div>

              {reportsList.length === 0 ? (
                <div className="p-6 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                  لا توجد بلاغات مسجلة في قاعدة البيانات حالياً.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {reportsList.slice(0, 5).map((rep) => (
                    <div
                      key={rep.id}
                      onClick={() => {
                        setSelectedReport(rep);
                        setReportNewStatus(rep.status);
                        setReportAdminReply(rep.adminResponse || '');
                        setActiveTab('reports');
                      }}
                      className="p-3 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/50 border border-[#E6E6F0] text-xs space-y-1 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-[#25263A] truncate">{rep.subject}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                            rep.status === 'open'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : rep.status === 'resolved'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {rep.status === 'open'
                            ? 'مفتوح'
                            : rep.status === 'in_progress'
                            ? 'قيد المعالجة'
                            : rep.status === 'resolved'
                            ? 'تم الحل'
                            : 'مغلق'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-[#77798C]">
                        <span>{rep.reporterName}</span>
                        <span>{formatRealDateTime(rep.createdAt)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 2: 👥 المستخدمون والبحث (Real Users & RBAC Management)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'users' && (
        <div className="space-y-5 animate-fade-in">
          {/* Search & Filter Card */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <form onSubmit={handleSearchUsers} className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#77798C] absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  placeholder="ابحث عن مستخدم بالـ UID أو البريد الإلكتروني أو الاسم..."
                  className="w-full pr-10 pl-4 py-2.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  disabled={loadingUsers}
                  className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black cursor-pointer transition-all"
                >
                  بحث فعلي
                </button>
                {userSearchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setUserSearchQuery('');
                      loadInitialUsers();
                    }}
                    className="px-3.5 py-2.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#77798C] hover:text-[#25263A] cursor-pointer"
                  >
                    إعادة ضبط
                  </button>
                )}
              </div>
            </form>

            {/* Filters */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#E6E6F0] text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[#77798C] font-bold">الدور:</span>
                {(['all', 'admin', 'user'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setUserRoleFilter(r)}
                    className={`px-3 py-1 rounded-xl font-bold cursor-pointer border ${
                      userRoleFilter === r
                        ? 'bg-[#EEEEFF] text-[#4145C7] border-[#5B5FEF]'
                        : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                    }`}
                  >
                    {r === 'all' ? 'الكل' : r === 'admin' ? 'مسؤول (Admin)' : 'مستخدم (User)'}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[#77798C] font-bold">الحالة:</span>
                {(['all', 'active', 'suspended', 'banned'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setUserStatusFilter(st)}
                    className={`px-3 py-1 rounded-xl font-bold cursor-pointer border ${
                      userStatusFilter === st
                        ? 'bg-[#EEEEFF] text-[#4145C7] border-[#5B5FEF]'
                        : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                    }`}
                  >
                    {st === 'all'
                      ? 'الكل'
                      : st === 'active'
                      ? 'نشط'
                      : st === 'suspended'
                      ? 'موقوف'
                      : 'محظور'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Users List */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-sm text-[#25263A]">
                قائمة المستخدمين الفعليين ({filteredUsers.length})
              </h3>
              <span className="text-[11px] text-[#77798C]">
                لا يتم حفظ أو عرض كلمات المرور نهائياً
              </span>
            </div>

            {loadingUsers && usersList.length === 0 ? (
              <div className="p-10 text-center text-xs text-[#77798C]">
                جاري تحميل سجلات المستخدمين من Firestore...
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="p-10 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لا يوجد مستخدمون مطابقون للبحث الحالي في قاعدة البيانات.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredUsers.map((u) => {
                  const isSelf = u.uid === currentUser.uid;
                  const isPrimaryOwner =
                    u.email && u.email.toLowerCase() === PRIMARY_ADMIN_EMAIL.toLowerCase();

                  return (
                    <div
                      key={u.uid}
                      className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex flex-col gap-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-black text-sm text-[#25263A]">
                              {u.displayName}
                            </span>
                            {isSelf && (
                              <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                                أنت
                              </span>
                            )}
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                                u.role === 'admin'
                                  ? 'bg-[#EEEEFF] text-[#4145C7] border border-[#5B5FEF]/40'
                                  : 'bg-white text-[#77798C] border border-[#E6E6F0]'
                              }`}
                            >
                              {u.role === 'admin' ? '🛡️ Admin' : '👤 User'}
                            </span>
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                u.accountStatus === 'active'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : u.accountStatus === 'suspended'
                                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                  : 'bg-red-50 text-red-700 border border-red-200'
                              }`}
                            >
                              {u.accountStatus === 'active'
                                ? 'نشط'
                                : u.accountStatus === 'suspended'
                                ? 'موقوف مؤقتاً'
                                : 'محظور'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#77798C]">
                            <span dir="ltr">{u.email || 'البريد: غير متاح'}</span>
                            <div className="flex items-center gap-1">
                              <span>UID:</span>
                              <code className="font-mono text-[11px] bg-white px-1.5 py-0.5 rounded border border-[#E6E6F0]" dir="ltr">
                                {u.uid}
                              </code>
                              <button
                                type="button"
                                onClick={() => handleCopyUid(u.uid)}
                                className="p-1 text-[#5B5FEF] hover:bg-white rounded cursor-pointer"
                                title="نسخ UID"
                              >
                                {copiedUid === u.uid ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleInspectUser(u.uid)}
                            disabled={loadingInspectUser}
                            className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5 text-[#5B5FEF]" />
                            <span>التفاصيل</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setNotifTargetType('user');
                              setNotifTargetUid(u.uid);
                              setActiveTab('notifications');
                            }}
                            className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          >
                            <Bell className="w-3.5 h-3.5 text-[#E8B84A]" />
                            <span>إشعار</span>
                          </button>

                          {!isSelf && !isPrimaryOwner && (
                            <>
                              <button
                                type="button"
                                disabled={roleProcessingUid === u.uid}
                                onClick={() => handleToggleAdminRole(u)}
                                className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span>
                                  {roleProcessingUid === u.uid
                                    ? '...'
                                    : u.role === 'admin'
                                    ? 'سحب Admin'
                                    : 'ترقية لـ Admin'}
                                </span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setStatusModalUser(u);
                                  setNewAccountStatus(u.accountStatus);
                                  setStatusReasonInput(u.statusReason || '');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-50 text-amber-700 border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>حالة الحساب</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setDeleteModalUser(u);
                                  setDeleteConfirmInput('');
                                }}
                                className="px-3 py-1.5 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>حذف السجل</span>
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Timestamps Row */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-[#E6E6F0] text-[11px] text-[#77798C]">
                        <div>
                          <span className="font-bold">تاريخ الإنشاء: </span>
                          <span>{formatRealDateTime(u.createdAt)}</span>
                        </div>
                        <div>
                          <span className="font-bold">آخر نشاط مسجل: </span>
                          <span>{formatRealDateTime(u.lastActiveAt, u.lastSyncedAt)}</span>
                        </div>
                        <div>
                          <span className="font-bold">تأكيد البريد: </span>
                          <span>{u.emailVerified ? 'موثق ✓' : 'غير موثق'}</span>
                        </div>
                      </div>

                      {u.statusReason && u.accountStatus !== 'active' && (
                        <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-[11px] text-red-700 font-bold">
                          سبب الإيقاف/الحظر المسجل: {u.statusReason}
                        </div>
                      )}
                    </div>
                  );
                })}

                {usersHasMore && (
                  <div className="pt-3 text-center">
                    <button
                      type="button"
                      onClick={handleLoadMoreUsers}
                      disabled={loadingUsers}
                      className="px-6 py-2.5 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] text-xs font-black text-[#5B5FEF] cursor-pointer"
                    >
                      {loadingUsers ? 'جاري التحميل...' : 'تحميل المزيد من المستخدمين'}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 3: 🔔 الإشعارات والأجهزة (Real Push/In-App Broadcast & Devices)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'notifications' && (
        <div className="space-y-6 animate-fade-in">
          {/* Send Real Notification Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="border-b border-[#E6E6F0] pb-3">
              <h3 className="font-black text-base text-[#25263A] flex items-center gap-2">
                <Send className="w-4 h-4 text-[#5B5FEF]" />
                <span>إرسال إشعار فوري للمستخدمين</span>
              </h3>
              <p className="text-xs text-[#77798C] mt-0.5">
                يتم حفظ الإشعار في `/admin_notifications` في Firestore وبثه لحظياً لجميع المستخدمين المتصلين أو لمستخدم محدد بالـ UID.
              </p>
            </div>

            <form onSubmit={handleSendBroadcastNotification} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    الجمهور المستهدف
                  </label>
                  <select
                    value={notifTargetType}
                    onChange={(e) => setNotifTargetType(e.target.value as 'all' | 'user')}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                  >
                    <option value="all">جميع مستخدمي رِفْق (بث عام)</option>
                    <option value="user">مستخدم محدد عبر معرف UID</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    تصنيف الإشعار
                  </label>
                  <select
                    value={notifType}
                    onChange={(e) =>
                      setNotifType(e.target.value as 'general' | 'reminder' | 'milestone')
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                  >
                    <option value="general">تنبيه عام (General)</option>
                    <option value="reminder">تذكير إيماني (Reminder)</option>
                    <option value="milestone">مناسبة / إنجاز (Milestone)</option>
                  </select>
                </div>
              </div>

              {notifTargetType === 'user' && (
                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    معرف المستخدم المستهدف (UID)
                  </label>
                  <input
                    type="text"
                    required
                    value={notifTargetUid}
                    onChange={(e) => setNotifTargetUid(e.target.value)}
                    placeholder="أدخل UID الخاص بالمستخدم"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-mono text-[#25263A]"
                    dir="ltr"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    عنوان الإشعار
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={180}
                    value={notifTitle}
                    onChange={(e) => setNotifTitle(e.target.value)}
                    placeholder="مثال: تذكير بقراءة سورة الكهف يوم الجمعة"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    توجيه عند النقر (اختياري)
                  </label>
                  <select
                    value={notifActionScreen}
                    onChange={(e) => setNotifActionScreen(e.target.value as ScreenType | '')}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                  >
                    <option value="">بدون توجيه خاص (الرئيسية)</option>
                    <option value="quran">القرآن الكريم</option>
                    <option value="athkar">موسوعة الأذكار</option>
                    <option value="tasbeeh">المسبحة المركزية</option>
                    <option value="wird">مجموعات وِرد | WIRD</option>
                    <option value="prayers">مواقيت الصلاة</option>
                    <option value="journey">رحلتي الإيمانية</option>
                    <option value="prophetic_biography">السيرة النبوية ﷺ</option>
                    <option value="our_history">تاريخنا الإسلامي</option>
                    <option value="dua_corner">ركن الدعاء والمناجاة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  نص رسالة الإشعار
                </label>
                <textarea
                  required
                  rows={3}
                  maxLength={1800}
                  value={notifMessage}
                  onChange={(e) => setNotifMessage(e.target.value)}
                  placeholder="اكتب محتوى الرسالة التي ستظهر للمستخدمين..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                />
              </div>

              <button
                type="submit"
                disabled={sendingNotif}
                className="px-6 py-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] disabled:opacity-50 text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Send className="w-4 h-4" />
                <span>{sendingNotif ? 'جاري الإرسال الفعلي...' : 'إرسال الإشعار الآن'}</span>
              </button>
            </form>
          </div>

          {/* Registered Notification Devices */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div>
                <h3 className="font-black text-sm text-[#25263A]">
                  📱 الأجهزة وحالات الإشعارات المسجلة ({devicesList.length})
                </h3>
                <p className="text-[11px] text-[#77798C]">
                  الأجهزة المفعلة فعلياً لاستقبال التنبيهات:{' '}
                  {devicesList.filter((d) => d.isActive).length}
                </p>
              </div>
            </div>

            {loadingNotifsTab ? (
              <div className="p-6 text-center text-xs text-[#77798C]">جاري التحميل...</div>
            ) : devicesList.length === 0 ? (
              <div className="p-6 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لا توجد أجهزة مسجلة في `/notification_devices` حتى الآن.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {devicesList.map((dev) => (
                  <div
                    key={dev.uid}
                    className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#25263A]">
                        {dev.displayName || dev.email || dev.uid}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          dev.isActive
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-gray-100 text-gray-600 border border-gray-200'
                        }`}
                      >
                        {dev.isActive ? 'نشط (Granted)' : `غير مفعّل (${dev.permissionStatus})`}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-[#77798C]">
                      <span>المنصة: {dev.platform === 'android' ? 'Android' : 'Web'}</span>
                      <span>آخر تحديث: {formatRealDateTime(dev.updatedAt)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sent Notifications History */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <h3 className="font-black text-sm text-[#25263A] border-b border-[#E6E6F0] pb-3">
              سجل الإشعارات الإدارية المرسلة ({sentNotifications.length})
            </h3>

            {sentNotifications.length === 0 ? (
              <div className="p-6 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لم يتم إرسال أي إشعارات إدارية سابقة.
              </div>
            ) : (
              <div className="space-y-3">
                {sentNotifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-start justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-xs text-[#25263A]">{n.title}</span>
                        <span className="px-2 py-0.5 rounded-full bg-white border border-[#E6E6F0] text-[10px] font-bold text-[#5B5FEF]">
                          {n.targetType === 'all' ? 'عام للجميع' : `مستخدم: ${n.targetUid}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#77798C] leading-relaxed">{n.message}</p>
                      <div className="text-[10px] text-[#77798C] pt-1">
                        بواسطة: {n.sentByName} • {formatRealDateTime(n.createdAt)}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteSentNotification(n)}
                      className="p-2 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] cursor-pointer shrink-0"
                      title="حذف الإشعار"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 4: 📖 مجموعات وِرد (Real Collaborative Wird Groups Moderation)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'groups' && (
        <div className="space-y-5 animate-fade-in">
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-black text-base text-[#25263A]">
                  إدارة مجموعات الختمة والورد التشاركي ({filteredGroups.length})
                </h3>
                <p className="text-xs text-[#77798C]">
                  جميع المجموعات المعروضة حقيقية من مجموعة `/groups` في Firestore
                </p>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-[#77798C] absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={groupSearchQuery}
                  onChange={(e) => setGroupSearchQuery(e.target.value)}
                  placeholder="بحث باسم المجموعة أو الكود..."
                  className="w-full pr-9 pl-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                />
              </div>
            </div>

            {loadingGroups ? (
              <div className="p-10 text-center text-xs text-[#77798C]">
                جاري تحميل مجموعات وِرد من Firestore...
              </div>
            ) : filteredGroups.length === 0 ? (
              <div className="p-10 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لا توجد مجموعات مسجلة في قاعدة البيانات حالياً.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredGroups.map((g) => (
                  <div
                    key={g.id}
                    className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-black text-sm text-[#25263A]">{g.groupName}</h4>
                        <span className="px-2 py-0.5 rounded-md bg-white border border-[#E6E6F0] font-mono text-[11px] font-bold text-[#5B5FEF]">
                          كود: {g.joinCode}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            g.isActive
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-red-50 text-red-700 border border-red-200'
                          }`}
                        >
                          {g.isActive ? 'نشطة' : 'موقوفة'}
                        </span>
                        <span className="px-2 py-0.5 rounded-full bg-white border border-[#E6E6F0] text-[10px] text-[#77798C]">
                          {g.isPublic ? 'عامة' : 'خاصة'}
                        </span>
                      </div>
                      <p className="text-xs text-[#77798C]">
                        المنشئ: {g.adminName} • اليوم {g.currentDay} من {g.targetDays} • تاريخ الإنشاء:{' '}
                        {formatRealDateTime(g.createdAt)}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleInspectGroup(g)}
                        disabled={loadingGroupInspect}
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#5B5FEF]" />
                        <span>الأعضاء والرسائل</span>
                      </button>

                      <button
                        type="button"
                        disabled={processingGroupId === g.id}
                        onClick={() => handleToggleGroupStatus(g)}
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-50 text-amber-700 border border-[#E6E6F0] text-xs font-bold cursor-pointer"
                      >
                        {g.isActive ? 'إيقاف المجموعة' : 'إعادة التفعيل'}
                      </button>

                      <button
                        type="button"
                        disabled={processingGroupId === g.id}
                        onClick={() => handleDeleteGroup(g)}
                        className="px-3 py-1.5 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] text-xs font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف نهائي</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 5: ⚠️ البلاغات المفتوحة (Real Reports & Support Resolution)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'reports' && (
        <div className="space-y-5 animate-fade-in">
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E6E6F0] pb-3">
              <div>
                <h3 className="font-black text-base text-[#25263A]">
                  إدارة البلاغات وتذاكر الدعم ({filteredReports.length})
                </h3>
                <p className="text-xs text-[#77798C]">
                  مراجعة بلاغات المستخدمين الحقيقية وتحديث حالتها والرد عليها رسمياً
                </p>
              </div>

              <div className="flex items-center gap-1.5 flex-wrap">
                {(['all', 'open', 'in_progress', 'resolved', 'closed'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setReportStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer border ${
                      reportStatusFilter === st
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                    }`}
                  >
                    {st === 'all'
                      ? 'الكل'
                      : st === 'open'
                      ? 'جديد'
                      : st === 'in_progress'
                      ? 'قيد المراجعة'
                      : st === 'resolved'
                      ? 'تم الحل'
                      : 'مغلق'}
                  </button>
                ))}
              </div>
            </div>

            {loadingReports ? (
              <div className="p-10 text-center text-xs text-[#77798C]">
                جاري تحميل البلاغات من Firestore...
              </div>
            ) : filteredReports.length === 0 ? (
              <div className="p-10 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لا توجد بلاغات في هذا التصنيف حالياً.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredReports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2.5"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-black border ${
                            rep.category === 'suggestion'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-rose-50 text-rose-700 border-rose-200'
                          }`}
                        >
                          {rep.category === 'suggestion' ? '💡 اقتراح ميزة' : '🐛 بلاغ مشكلة'}
                        </span>
                        {rep.issueType && (
                          <span className="text-[11px] font-bold text-[#4145C7]">
                            {rep.issueType}
                          </span>
                        )}
                        <span className="font-black text-sm text-[#25263A]">{rep.subject}</span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            rep.status === 'open' || rep.status === 'new'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : rep.status === 'in_progress'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : rep.status === 'resolved'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-gray-100 text-gray-600 border border-gray-200'
                          }`}
                        >
                          {rep.status === 'open' || rep.status === 'new'
                            ? 'جديد'
                            : rep.status === 'in_progress'
                            ? 'قيد المراجعة'
                            : rep.status === 'resolved'
                            ? 'تم الحل'
                            : 'مغلق'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedReport(rep);
                            setReportNewStatus(rep.status);
                            setReportAdminReply(rep.adminResponse || '');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>معالجة / رد</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteReport(rep)}
                          className="p-1.5 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] cursor-pointer"
                          title="حذف البلاغ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-[#25263A] leading-relaxed whitespace-pre-wrap">
                      {rep.description}
                    </p>

                    {rep.screenshotDataUrl && (
                      <div className="pt-1">
                        <img
                          src={rep.screenshotDataUrl}
                          alt="Screenshot"
                          className="max-h-48 rounded-xl border border-[#E6E6F0] object-contain bg-white p-1"
                        />
                      </div>
                    )}

                    {rep.deviceInfo && (
                      <div className="flex flex-wrap items-center gap-2 text-[10px] text-[#77798C] bg-white px-3 py-1.5 rounded-xl border border-[#E6E6F0]">
                        <span className="font-bold text-[#25263A]">معلومات الجهاز:</span>
                        <span>الإصدار: v{rep.deviceInfo.appVersion}</span>
                        <span>•</span>
                        <span>{rep.deviceInfo.platform}</span>
                        <span>•</span>
                        <span dir="ltr">{rep.deviceInfo.browserOrOs}</span>
                        <span>•</span>
                        <span dir="ltr">{rep.deviceInfo.screenResolution}</span>
                      </div>
                    )}

                    <div className="flex flex-wrap items-center gap-4 text-[11px] text-[#77798C] pt-1 border-t border-[#E6E6F0]">
                      <span className="font-mono text-[10px]" dir="ltr">
                        ID: #{rep.id}
                      </span>
                      <span>المُبلّغ: {rep.reporterName}</span>
                      <span dir="ltr">{rep.reporterEmail || rep.reporterUid}</span>
                      <span>التاريخ: {formatRealDateTime(rep.createdAt)}</span>
                      {rep.targetId && <span>المعرف المرتبط: {rep.targetId}</span>}
                    </div>

                    {rep.adminResponse && (
                      <div className="p-3 rounded-xl bg-white border border-[#5B5FEF]/30 text-xs space-y-1">
                        <div className="font-black text-[#5B5FEF]">الرد الإداري المسجل:</div>
                        <p className="text-[#25263A] whitespace-pre-wrap">{rep.adminResponse}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          TAB 6: 📜 السجل والإعدادات (Immutable Audit Logs & System Config)
         ═══════════════════════════════════════════════════════════════════ */}
      {activeTab === 'audit_settings' && (
        <div className="space-y-6 animate-fade-in">
          {/* Global Announcement Banner Configuration */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="border-b border-[#E6E6F0] pb-3">
              <h3 className="font-black text-base text-[#25263A] flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#5B5FEF]" />
                <span>إعدادات التنبيه العام للتطبيق (`/system_config/app_settings`)</span>
              </h3>
              <p className="text-xs text-[#77798C] mt-0.5">
                يظهر هذا الشريط الإعلاني لجميع مستخدمي التطبيق في الشاشة الرئيسية عند تفعيله.
              </p>
            </div>

            <form onSubmit={handleSaveSystemConfig} className="space-y-4">
              <label className="flex items-center justify-between p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] cursor-pointer">
                <div>
                  <div className="font-black text-xs text-[#25263A]">
                    تفعيل ظهور التنبيه العام في الشاشة الرئيسية
                  </div>
                  <div className="text-[11px] text-[#77798C]">
                    عند التفعيل، سيقرأ التطبيق الإعدادات مباشرة من Firestore
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={systemConfig.announcementEnabled}
                  onChange={(e) =>
                    setSystemConfig({ ...systemConfig, announcementEnabled: e.target.checked })
                  }
                  className="w-5 h-5 accent-[#5B5FEF] cursor-pointer"
                />
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    عنوان التنبيه
                  </label>
                  <input
                    type="text"
                    maxLength={150}
                    value={systemConfig.announcementTitle}
                    onChange={(e) =>
                      setSystemConfig({ ...systemConfig, announcementTitle: e.target.value })
                    }
                    placeholder="مثال: تحديث جديد أو تذكير موسمي مبارك"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                    نمط التنبيه
                  </label>
                  <select
                    value={systemConfig.announcementType}
                    onChange={(e) =>
                      setSystemConfig({
                        ...systemConfig,
                        announcementType: e.target.value as 'info' | 'warning' | 'celebration',
                      })
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                  >
                    <option value="info">معلوماتي هادئ (Info)</option>
                    <option value="celebration">مناسبة مباركة (Celebration)</option>
                    <option value="warning">تنبيه مهم (Warning)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  نص التنبيه العام
                </label>
                <textarea
                  rows={2}
                  maxLength={950}
                  value={systemConfig.announcementMessage}
                  onChange={(e) =>
                    setSystemConfig({ ...systemConfig, announcementMessage: e.target.value })
                  }
                  placeholder="اكتب الرسالة المختصرة التي ستظهر في أعلى الشاشة الرئيسية..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                />
              </div>

              <button
                type="submit"
                disabled={savingSystemConfig}
                className="px-6 py-2.5 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] disabled:opacity-50 text-white font-black text-xs cursor-pointer transition-all"
              >
                {savingSystemConfig ? 'جاري الحفظ...' : 'حفظ إعدادات النظام فعلياً'}
              </button>
            </form>
          </div>

          {/* Immutable Audit Logs */}
          <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div>
                <h3 className="font-black text-sm text-[#25263A]">
                  📜 سجل التدقيق الإداري غير القابل للتعديل (`/admin_audit_logs`)
                </h3>
                <p className="text-[11px] text-[#77798C]">
                  محمي بقواعد أمان Firestore (`allow update, delete: if false`) لضمان الشفافية الكاملة
                </p>
              </div>
            </div>

            {loadingAuditSettings ? (
              <div className="p-8 text-center text-xs text-[#77798C]">جاري التحميل...</div>
            ) : auditLogs.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#77798C] bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0]">
                لا توجد عمليات مسجلة بعد.
              </div>
            ) : (
              <div className="space-y-2.5">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-black text-[#25263A]">{log.details}</span>
                      <span className="px-2 py-0.5 rounded-md bg-white border border-[#E6E6F0] font-mono text-[10px] text-[#5B5FEF]">
                        {log.actionType}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center justify-between text-[11px] text-[#77798C]">
                      <span dir="ltr">المسؤول: {log.adminEmail || log.adminUid}</span>
                      <span>الهدف: {log.targetId}</span>
                      <span>{formatRealDateTime(log.createdAt)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════
          MODALS FOR REAL ACTIONS
         ═══════════════════════════════════════════════════════════════════ */}

      {/* 1. Inspect User Details Modal */}
      {inspectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-3xl max-w-lg w-full max-h-[88vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
            <div className="p-5 border-b border-[#E6E6F0] flex items-center justify-between bg-[#F7F7FC]">
              <div>
                <h3 className="font-black text-base text-[#25263A]">
                  بيانات المستخدم الفعلية من Firestore
                </h3>
                <p className="text-xs text-[#77798C]" dir="ltr">
                  UID: {inspectedUser.profile.uid}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectedUser(null)}
                className="w-8 h-8 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div className="text-[#77798C]">الاسم</div>
                  <div className="font-black text-[#25263A] mt-0.5">
                    {inspectedUser.profile.displayName}
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div className="text-[#77798C]">البريد الإلكتروني</div>
                  <div className="font-bold text-[#25263A] mt-0.5 truncate" dir="ltr">
                    {inspectedUser.profile.email || 'غير متاح'}
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div className="text-[#77798C]">الدور الموثق</div>
                  <div className="font-black text-[#5B5FEF] mt-0.5">
                    {inspectedUser.profile.role === 'admin' ? 'Admin (مسؤول)' : 'User (مستخدم)'}
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div className="text-[#77798C]">حالة الحساب</div>
                  <div className="font-black text-[#25263A] mt-0.5">
                    {inspectedUser.profile.accountStatus === 'active'
                      ? 'نشط'
                      : inspectedUser.profile.accountStatus === 'suspended'
                      ? 'موقوف مؤقتاً'
                      : 'محظور'}
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2">
                <div className="font-black text-[#25263A]">الإحصائيات السحابية المسجلة للمستخدم:</div>
                <div className="grid grid-cols-2 gap-2 text-[#77798C]">
                  <div>
                    إجمالي التسبيحات:{' '}
                    <span className="font-bold text-[#25263A]">
                      {inspectedUser.profile.stats?.totalTasbeeh ?? 'غير متاح'}
                    </span>
                  </div>
                  <div>
                    السلسلة الحالية:{' '}
                    <span className="font-bold text-[#25263A]">
                      {inspectedUser.profile.stats?.currentStreak ?? 'غير متاح'}
                    </span>
                  </div>
                  <div>
                    الرحلات المسجلة:{' '}
                    <span className="font-bold text-[#25263A]">{inspectedUser.journeysCount}</span>
                  </div>
                  <div>
                    الأوسمة المحققة:{' '}
                    <span className="font-bold text-[#25263A]">
                      {inspectedUser.achievementsCount}
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-1.5">
                <div className="font-black text-[#25263A]">حالة جهاز الإشعارات:</div>
                {inspectedUser.deviceStatus ? (
                  <div className="text-[#77798C] space-y-1">
                    <div>المنصة: {inspectedUser.deviceStatus.platform}</div>
                    <div>الإذن: {inspectedUser.deviceStatus.permissionStatus}</div>
                    <div>
                      آخر اتصال للجهاز: {formatRealDateTime(inspectedUser.deviceStatus.updatedAt)}
                    </div>
                  </div>
                ) : (
                  <div className="text-[#77798C]">غير متاح</div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Change Account Status Modal */}
      {statusModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-[#E6E6F0] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <h3 className="font-black text-base text-[#25263A]">
                تعديل حالة حساب: {statusModalUser.displayName}
              </h3>
              <button
                type="button"
                onClick={() => setStatusModalUser(null)}
                className="w-8 h-8 rounded-full bg-[#F7F7FC] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUserAccountStatus} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  الحالة الجديدة للحساب
                </label>
                <select
                  value={newAccountStatus}
                  onChange={(e) =>
                    setNewAccountStatus(e.target.value as 'active' | 'suspended' | 'banned')
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                >
                  <option value="active">نشط (Active) — مسموح بالوصول الكامل</option>
                  <option value="suspended">موقوف مؤقتاً (Suspended)</option>
                  <option value="banned">محظور نهائياً (Banned)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  سبب الإجراء (يظهر للمستخدم في حال الإيقاف أو الحظر)
                </label>
                <textarea
                  rows={3}
                  value={statusReasonInput}
                  onChange={(e) => setStatusReasonInput(e.target.value)}
                  placeholder="اكتب سبب الإيقاف أو الحظر..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStatusModalUser(null)}
                  className="px-4 py-2 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#77798C] cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={savingUserStatus}
                  className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-black cursor-pointer"
                >
                  {savingUserStatus ? 'جاري التنفيذ...' : 'حفظ وتطبيق فوراً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Delete User Cloud Record Confirmation Modal */}
      {deleteModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-[#E6E6F0] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <h3 className="font-black text-base text-[#D95C6A]">
                تأكيد حذف السجل السحابي للمستخدم
              </h3>
              <button
                type="button"
                onClick={() => setDeleteModalUser(null)}
                className="w-8 h-8 rounded-full bg-[#F7F7FC] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmDeleteUser} className="space-y-4">
              <p className="text-xs text-[#77798C] leading-relaxed">
                سيؤدي هذا الإجراء إلى حذف وثيقة المستخدم{' '}
                <span className="font-black text-[#25263A]">{deleteModalUser.displayName}</span> (
                <code className="font-mono">{deleteModalUser.uid}</code>) وجميع مجموعاته الفرعية في
                Firestore بشكل نهائي. للتأكيد اكتب كلمة <strong>حذف</strong> أدناه:
              </p>

              <input
                type="text"
                required
                value={deleteConfirmInput}
                onChange={(e) => setDeleteConfirmInput(e.target.value)}
                placeholder='اكتب كلمة "حذف" للتأكيد'
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
              />

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteModalUser(null)}
                  className="px-4 py-2 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#77798C] cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={deletingUser || deleteConfirmInput.trim() !== 'حذف'}
                  className="px-5 py-2 rounded-xl bg-[#D95C6A] disabled:opacity-50 text-white text-xs font-black cursor-pointer"
                >
                  {deletingUser ? 'جاري الحذف...' : 'تأكيد الحذف النهائي'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Inspect Group Members & Wall Messages Modal */}
      {inspectedGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[88vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
            <div className="p-5 border-b border-[#E6E6F0] flex items-center justify-between bg-[#F7F7FC]">
              <div>
                <h3 className="font-black text-base text-[#25263A]">
                  تفاصيل مجموعة: {inspectedGroup.group.groupName}
                </h3>
                <p className="text-xs text-[#77798C]">
                  كود الانضمام: {inspectedGroup.group.joinCode} • الأعضاء ({inspectedGroup.members.length}) • الرسائل ({inspectedGroup.messages.length})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInspectedGroup(null)}
                className="w-8 h-8 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-5 text-xs">
              {/* Members */}
              <div className="space-y-2">
                <h4 className="font-black text-xs text-[#25263A]">
                  أعضاء المجموعة ({inspectedGroup.members.length})
                </h4>
                {inspectedGroup.members.length === 0 ? (
                  <div className="p-4 rounded-xl bg-[#F7F7FC] text-[#77798C]">
                    لا يوجد أعضاء مسجلون في المجموعة الفرعية.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {inspectedGroup.members.map((m) => (
                      <div
                        key={m.userId}
                        className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-[#25263A]">{m.displayName}</div>
                          <div className="text-[10px] text-[#77798C]" dir="ltr">
                            {m.userId}
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-white border border-[#E6E6F0] text-[10px] font-bold">
                          {m.role === 'admin' ? 'مشرف المجموعة' : 'عضو'}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Wall Messages */}
              <div className="space-y-2">
                <h4 className="font-black text-xs text-[#25263A]">
                  رسائل حائط المجموعة ({inspectedGroup.messages.length})
                </h4>
                {inspectedGroup.messages.length === 0 ? (
                  <div className="p-4 rounded-xl bg-[#F7F7FC] text-[#77798C]">
                    لا توجد رسائل منشورة في هذه المجموعة.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {inspectedGroup.messages.map((msg) => (
                      <div
                        key={msg.id}
                        className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-start justify-between gap-2"
                      >
                        <div className="space-y-1">
                          <div className="font-bold text-[#25263A]">{msg.userName}</div>
                          <p className="text-[#77798C] leading-relaxed">{msg.message}</p>
                          <div className="text-[10px] text-[#77798C]">
                            {formatRealDateTime(msg.createdAt)}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            handleDeleteGroupMessage(
                              inspectedGroup.group.id,
                              msg.id,
                              msg.message
                            )
                          }
                          className="p-1.5 rounded-lg bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] cursor-pointer shrink-0"
                          title="حذف الرسالة المخالفة"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. Process & Reply to Report Modal */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-[#E6E6F0] space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <h3 className="font-black text-base text-[#25263A]">معالجة البلاغ والرد الرسمي</h3>
              <button
                type="button"
                onClick={() => setSelectedReport(null)}
                className="w-8 h-8 rounded-full bg-[#F7F7FC] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs space-y-1">
              <div className="font-black text-[#25263A]">{selectedReport.subject}</div>
              <p className="text-[#77798C]">{selectedReport.description}</p>
            </div>

            <form onSubmit={handleSaveReportUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  تحديث حالة البلاغ
                </label>
                <select
                  value={reportNewStatus}
                  onChange={(e) => setReportNewStatus(e.target.value as ReportStatus)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A]"
                >
                  <option value="open">جديد (New / Open)</option>
                  <option value="in_progress">قيد المراجعة (In Progress)</option>
                  <option value="resolved">تم الحل (Resolved)</option>
                  <option value="closed">مغلق (Closed)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  رد الإدارة (يظهر للمستخدم في سجل بلاغاته)
                </label>
                <textarea
                  rows={3}
                  maxLength={2000}
                  value={reportAdminReply}
                  onChange={(e) => setReportAdminReply(e.target.value)}
                  placeholder="اكتب رد الإدارة أو الإجراء المتخذ..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A]"
                />
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedReport(null)}
                  className="px-4 py-2 rounded-xl bg-[#F7F7FC] text-xs font-bold text-[#77798C] cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={savingReport}
                  className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-black cursor-pointer"
                >
                  {savingReport ? 'جاري الحفظ...' : 'حفظ التحديث'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
