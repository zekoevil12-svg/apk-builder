import React, { useState } from 'react';
import { Sparkles, ArrowLeft, Copy, Check, Share2, BookOpen } from 'lucide-react';
import { getCurrentMomentDhikr } from '../../utils/momentDhikrService';
import { DhikrShareModal } from '../DhikrShareModal';

interface MomentDhikrCardProps {
  onOpenMomentDhikr: (dhikrId?: string) => void;
}

export const MomentDhikrCard: React.FC<MomentDhikrCardProps> = ({
  onOpenMomentDhikr,
}) => {
  const dhikr = getCurrentMomentDhikr();
  const [copied, setCopied] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Time slot label
  const hour = new Date().getHours();
  let slotLabel = 'ذكر الفجر';
  if (hour >= 8 && hour < 12) slotLabel = 'ذكر الضحى';
  else if (hour >= 12 && hour < 16) slotLabel = 'ذكر الظهر';
  else if (hour >= 16 && hour < 20) slotLabel = 'ذكر العصر';
  else if (hour >= 20 || hour < 4) slotLabel = 'ذكر الليل';

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const formatted = `«${dhikr.text}»\n\nالمصدر: ${dhikr.source}\n\n[منقول من تطبيق «رِفْق | RIFQ»]`;
    navigator.clipboard.writeText(formatted);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsShareModalOpen(true);
  };

  return (
    <>
      <div 
        onClick={() => onOpenMomentDhikr(dhikr.id)}
        className="w-full rounded-[20px] p-5 sm:p-6 bg-[#FFFFFF] border border-[#E6E6F0] shadow-[0_2px_12px_rgba(37,38,58,0.04)] hover:border-[#5B5FEF]/40 hover:shadow-[0_6px_20px_rgba(91,95,239,0.08)] transition-all duration-300 cursor-pointer relative overflow-hidden font-tajawal select-none group"
        dir="rtl"
      >
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#72B7E8]/10 rounded-full blur-2xl pointer-events-none" />

        {/* Top Header Row */}
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-[#E6E6F0] mb-3">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-[#EEEEFF] text-[#5B5FEF]">
              <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
            </span>
            <div>
              <h3 className="text-sm font-black text-[#25263A] flex items-center gap-1.5">
                <span>ذكر اللحظة</span>
                <span className="text-[#77798C] font-normal">·</span>
                <span className="text-xs font-bold text-[#5B5FEF]">
                  {slotLabel}
                </span>
              </h3>
            </div>
          </div>

          <span className="text-xs font-bold text-[#5B5FEF] group-hover:translate-x-[-3px] transition-transform flex items-center gap-1">
            <span>اقرأ المزيد</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </span>
        </div>

        {/* The Dhikr Text */}
        <p 
          className="text-[#25263A] text-base sm:text-lg leading-relaxed font-bold font-amiri text-center my-3 line-clamp-3 group-hover:text-[#4145C7] transition-colors"
          style={{ fontFamily: 'Amiri, Tajawal, serif' }}
        >
          {dhikr.text}
        </p>

        {/* Source info & Action Buttons */}
        <div className="mt-4 pt-3 border-t border-[#E6E6F0] flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs text-[#77798C] font-semibold truncate">
            <BookOpen className="w-3.5 h-3.5 text-[#72B7E8] shrink-0" />
            <span className="truncate">{dhikr.source}</span>
          </div>

          <div className="flex items-center gap-1.5 shrink-0" onClick={e => e.stopPropagation()}>
            {/* Quick Copy Button */}
            <button
              onClick={handleCopy}
              className="p-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] transition-all active:scale-95 cursor-pointer"
              title="نسخ الذكر"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            {/* Quick Share Button */}
            <button
              onClick={handleShare}
              className="p-1.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white transition-all active:scale-95 cursor-pointer"
              title="مشاركة الذكر"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Share Modal */}
      <DhikrShareModal
        dhikr={dhikr}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        wardTitle={`ذكر اللحظة · ${slotLabel}`}
      />
    </>
  );
};
