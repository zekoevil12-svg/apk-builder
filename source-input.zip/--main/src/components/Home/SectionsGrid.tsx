import React, { useState } from 'react';
import { ScreenType } from '../../types';
import { RifqSectionIcon, getSectionAccentMeta } from './RifqSectionIcons';
import { useTheme } from '../../context/ThemeContext';

export type HomeSectionGroup = 'all' | 'quran_sunnah' | 'fiqh_worship' | 'athkar_tasbeeh' | 'tools_profile';

export interface SectionItem {
  id: ScreenType;
  title: string;
  pngAsset: string;
  group?: Exclude<HomeSectionGroup, 'all'>;
}

interface SectionCardProps {
  item: SectionItem;
  isActive?: boolean;
  onNavigate: (screen: ScreenType) => void;
}

/**
 * بطاقة القسم بتصميم رِفْق العصري الجديد:
 * - خلفية بيضاء (#FFFFFF)، حدود ناعمة (#E6E6F0)، ظل خفيف جدًا
 * - أيقونة SVG احترافية باللون الأساسي (#5B5FEF) مع لمسة Accent مخصصة لكل قسم (#E8B84A / #72B7E8 / #E99AC7)
 * - عنوان القسم بلون النص الأساسي (#25263A)
 */
export const SectionCard: React.FC<SectionCardProps> = ({
  item,
  isActive = false,
  onNavigate,
}) => {
  const [isTouched, setIsTouched] = useState(false);
  const { themeId } = useTheme();
  const accentMeta = getSectionAccentMeta(item.id, themeId);

  return (
    <div className="group flex flex-col items-center justify-center w-full">
      <button
        id={`grid-section-${item.id}`}
        type="button"
        onClick={() => onNavigate(item.id)}
        onTouchStart={() => setIsTouched(true)}
        onTouchEnd={() => setIsTouched(false)}
        onTouchCancel={() => setIsTouched(false)}
        aria-label={item.title}
        className={`relative w-full min-h-[118px] bg-[#FFFFFF] rounded-[16px] p-2.5 flex flex-col items-center justify-center text-center select-none cursor-pointer border transition-all duration-200 active:scale-95 ${
          isActive || isTouched
            ? 'border-[#5B5FEF] shadow-[0_4px_14px_rgba(91,95,239,0.14)] -translate-y-0.5'
            : 'border-[#E6E6F0] shadow-[0_2px_8px_rgba(37,38,58,0.03)] hover:border-[#5B5FEF]/50 hover:shadow-[0_6px_16px_rgba(91,95,239,0.10)] hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5B5FEF]'
        }`}
      >
        {/* لمسة Accent علوية ناعمة حسب طبيعة القسم */}
        <span
          className="w-5 h-1 rounded-full mb-1.5 opacity-80 transition-all duration-200 group-hover:w-7"
          style={{ backgroundColor: accentMeta.accent }}
        />

        {/* دائرة الأيقونة الموحدة بإطار ذهبي هادئ وخلفية فاتحة */}
        <div
          className={`w-[58px] h-[58px] mx-auto rounded-full flex items-center justify-center shrink-0 transition-transform duration-200 ${
            isActive || isTouched ? 'scale-105' : 'group-hover:scale-105'
          }`}
        >
          <RifqSectionIcon screenId={item.id} size={56} />
        </div>

        {/* اسم القسم بخط Cairo Bold ولون #25263A */}
        <span className="font-cairo font-bold text-[13px] text-[#25263A] group-hover:text-[#5B5FEF] leading-[1.3] text-center line-clamp-2 w-full mt-2 transition-colors">
          {item.title}
        </span>
      </button>
    </div>
  );
};

interface SectionsGridProps {
  onNavigate: (screen: ScreenType) => void;
  activeScreen?: ScreenType;
  renderCard?: (item: SectionItem, isActive: boolean) => React.ReactNode;
}

export const HOME_SECTIONS: SectionItem[] = [
  // الصف 1: المسبحة | المواقيت | القرآن | القرآن — استماع | وِرد | WIRD
  { id: 'tasbeeh', title: 'المسبحة', pngAsset: 'assets/icons/menu/ic_misbaha.png', group: 'athkar_tasbeeh' },
  { id: 'prayers', title: 'المواقيت', pngAsset: 'assets/icons/menu/ic_mosque.png', group: 'fiqh_worship' },
  { id: 'quran', title: 'القرآن', pngAsset: 'assets/icons/menu/ic_quran.png', group: 'quran_sunnah' },
  { id: 'quran_audio', title: 'القرآن — استماع', pngAsset: 'assets/icons/menu/ic_quran_audio.png', group: 'quran_sunnah' },
  { id: 'wird', title: 'وِرد | WIRD', pngAsset: 'assets/icons/menu/ic_wird.png', group: 'athkar_tasbeeh' },

  // الصف 2: الأربعون النووية | وصايا الرسول ﷺ | السيرة النبوية | تاريخنا | قصص الصحابة | قصص الأطفال | الأحاديث | غريب القرآن | أحكام التجويد
  { id: 'arbain_nawawiya', title: 'الأربعون النووية', pngAsset: 'assets/icons/menu/ic_arbain_nawawiya.png', group: 'quran_sunnah' },
  { id: 'wasaya', title: 'وصايا الرسول ﷺ', pngAsset: 'assets/icons/menu/ic_wasaya.png', group: 'quran_sunnah' },
  { id: 'prophetic_biography', title: 'السيرة النبوية', pngAsset: 'assets/icons/menu/ic_seerah.svg', group: 'quran_sunnah' },
  { id: 'our_history', title: 'تاريخنا', pngAsset: 'assets/icons/menu/ic_seerah.svg', group: 'quran_sunnah' },
  { id: 'companions_stories', title: 'قصص الصحابة', pngAsset: 'assets/icons/menu/ic_companions.png', group: 'quran_sunnah' },
  { id: 'kids_stories', title: 'قصص الأطفال', pngAsset: 'assets/icons/menu/ic_kids_stories.png', group: 'quran_sunnah' },
  { id: 'hadith', title: 'الأحاديث', pngAsset: 'assets/icons/menu/ic_hadith.png', group: 'quran_sunnah' },
  { id: 'gharib_quran', title: 'غريب القرآن', pngAsset: 'assets/icons/menu/ic_gharib.png', group: 'quran_sunnah' },
  { id: 'tajweed', title: 'أحكام التجويد', pngAsset: 'assets/icons/menu/ic_tajweed.png', group: 'quran_sunnah' },

  // الصف 3: الفقه الميسر | آية وفائدة | الزكاة والمواريث | التقويم والصيام | الحج والعمرة
  { id: 'fiqh_muyassar', title: 'الفقه الميسر', pngAsset: 'assets/icons/menu/ic_fiqh_muyassar.png', group: 'fiqh_worship' },
  { id: 'tadabbur', title: 'آية وفائدة', pngAsset: 'assets/icons/menu/ic_tadabbur.png', group: 'quran_sunnah' },
  { id: 'zakat_mawarith', title: 'الزكاة والمواريث', pngAsset: 'assets/icons/menu/ic_zakat.png', group: 'fiqh_worship' },
  { id: 'hijri_fasting', title: 'التقويم والصيام', pngAsset: 'assets/icons/menu/ic_hijri.png', group: 'fiqh_worship' },
  { id: 'hajj_umrah', title: 'الحج والعمرة', pngAsset: 'assets/icons/menu/ic_hajj.png', group: 'fiqh_worship' },

  // الصف 4: الرقية والطب النبوي | الأذكار | ركن الدعاء | تعلّم الوضوء والصلاة | رِفْق للمرأة
  { id: 'ruqyah_medicine', title: 'الرقية والطب النبوي', pngAsset: 'assets/icons/menu/ic_ruqyah.png', group: 'fiqh_worship' },
  { id: 'athkar', title: 'الأذكار', pngAsset: 'assets/icons/menu/ic_azkar.png', group: 'athkar_tasbeeh' },
  { id: 'dua_corner', title: 'ركن الدعاء', pngAsset: 'assets/icons/menu/ic_azkar.png', group: 'athkar_tasbeeh' },
  { id: 'wudu_prayer', title: '🕌 تعلّم الوضوء والصلاة', pngAsset: 'assets/icons/menu/ic_wudu.png', group: 'fiqh_worship' },
  { id: 'muslim_woman', title: 'رِفْق للمرأة', pngAsset: 'assets/icons/menu/ic_woman_flower.png', group: 'fiqh_worship' },

  // الصف 5: أثر طيّب | أمانة | رحلتي | حصاد الأعمال | التذكيرات اليومية | أسماء الله
  { id: 'athar_tayyib', title: 'أثر طيّب', pngAsset: 'assets/icons/menu/ic_athar_tayyib.png', group: 'athkar_tasbeeh' },
  { id: 'amana', title: 'أمانة', pngAsset: 'assets/icons/menu/ic_amana.png', group: 'fiqh_worship' },
  { id: 'journey', title: 'رحلتي', pngAsset: 'assets/icons/menu/ic_palm_tree.png', group: 'athkar_tasbeeh' },
  { id: 'harvest', title: 'حصاد الأعمال', pngAsset: 'assets/icons/menu/ic_trophy.png', group: 'athkar_tasbeeh' },
  { id: 'daily_reminders', title: 'التذكيرات اليومية', pngAsset: 'assets/icons/menu/ic_morning.png', group: 'athkar_tasbeeh' },
  { id: 'asmaa_allah', title: 'أسماء الله', pngAsset: 'assets/icons/menu/ic_allah_names.png', group: 'athkar_tasbeeh' },

  // الصف 6: الإحصائيات | الملف الشخصي | الإعدادات | تواصل المطور
  { id: 'stats', title: 'الإحصائيات', pngAsset: 'assets/icons/menu/ic_statistics.png', group: 'tools_profile' },
  { id: 'profile', title: 'الملف الشخصي', pngAsset: 'assets/icons/menu/ic_user.png', group: 'tools_profile' },
  { id: 'settings', title: 'الإعدادات', pngAsset: 'assets/icons/menu/ic_settings.png', group: 'tools_profile' },
  { id: 'credits', title: 'تواصل المطور', pngAsset: 'assets/icons/menu/ic_contact.png', group: 'tools_profile' },
];

export const SectionsGrid: React.FC<SectionsGridProps> = ({
  onNavigate,
  activeScreen,
  renderCard,
}) => {
  return (
    <div
      className="grid grid-cols-4 md:grid-cols-5 gap-[10px]"
      role="navigation"
      aria-label="شبكة أقسام تطبيق رِفْق"
    >
      {HOME_SECTIONS.map((item) => {
        const isActive = activeScreen === item.id;
        if (renderCard) {
          return <React.Fragment key={item.id}>{renderCard(item, isActive)}</React.Fragment>;
        }
        return (
          <SectionCard
            key={item.id}
            item={item}
            isActive={isActive}
            onNavigate={onNavigate}
          />
        );
      })}
    </div>
  );
};
