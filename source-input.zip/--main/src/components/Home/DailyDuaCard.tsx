import React, { useState, useCallback } from 'react';
import { RefreshCw, Copy, Share2, Check, CheckCircle2 } from 'lucide-react';
import { DhikrShareModal } from '../DhikrShareModal';
import { AthkarSectionSvg, QuranSectionSvg } from './RifqSectionIcons';
import { ScreenType } from '../../types';

interface DailyDuaCardProps {
  onShowToast?: (message: string) => void;
  onNavigate?: (screen: ScreenType) => void;
}

interface RippleItem {
  id: number;
  x: number;
  y: number;
  size: number;
}

const DUAS_LIST: { text: string; source: string }[] = [
  {
    text: '«اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا»',
    source: 'سنن ابن ماجه'
  },
  {
    text: '«يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ»',
    source: 'جامع الترمذي'
  },
  {
    text: '«اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ»',
    source: 'سنن أبي داود'
  },
  {
    text: '«رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ»',
    source: 'سورة البقرة: 201'
  },
  {
    text: '«اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي»',
    source: 'جامع الترمذي'
  },
  {
    text: '«اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ، وَغَلَبَةِ الرِّجَالِ»',
    source: 'صحيح البخاري'
  },
  {
    text: '«لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ»',
    source: 'سورة الأنبياء: 87'
  },
  {
    text: '«اللَّهُمَّ حَاسِبْنِي حِسَابًا يَسِيرًا»',
    source: 'مسند الإمام أحمد'
  }
];

export const DailyDuaCard: React.FC<DailyDuaCardProps> = ({ onShowToast, onNavigate }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isRotating, setIsRotating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copyRipples, setCopyRipples] = useState<RippleItem[]>([]);
  const [shareRipples, setShareRipples] = useState<RippleItem[]>([]);
  const [localToast, setLocalToast] = useState<string | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const currentDua = DUAS_LIST[currentIndex];

  const triggerRipple = (
    e: React.MouseEvent<HTMLButtonElement>,
    setRipples: React.Dispatch<React.SetStateAction<RippleItem[]>>
  ) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.5;
    const x = e.clientX ? e.clientX - rect.left : rect.width / 2;
    const y = e.clientY ? e.clientY - rect.top : rect.height / 2;
    const newRipple: RippleItem = { id: Date.now() + Math.random(), x, y, size };

    setRipples((prev) => [...prev, newRipple]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== newRipple.id));
    }, 600);
  };

  const handleNextDua = () => {
    setIsRotating(true);
    setCurrentIndex((prev) => (prev + 1) % DUAS_LIST.length);
    setTimeout(() => setIsRotating(false), 300);
  };

  const showToastNotification = useCallback((msg: string) => {
    if (onShowToast) {
      onShowToast(msg);
    }
    setLocalToast(msg);
    setTimeout(() => setLocalToast(null), 2500);
  }, [onShowToast]);

  const handleCopy = async (e: React.MouseEvent<HTMLButtonElement>) => {
    triggerRipple(e, setCopyRipples);

    const fullText = `${currentDua.text}\n[${currentDua.source}]\n— من تطبيق رِفْق | RIFQ`;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(fullText);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = fullText;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      showToastNotification('تم نسخ الدعاء بنجاح');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      showToastNotification('تم نسخ الدعاء بنجاح');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = (e: React.MouseEvent<HTMLButtonElement>) => {
    triggerRipple(e, setShareRipples);
    setIsShareModalOpen(true);
  };

  return (
    <div id="daily-dua-card" className="relative w-full bg-[#FFFFFF] rounded-[20px] p-6 border border-[#E6E6F0] shadow-[0_2px_12px_rgba(37,38,58,0.04)] text-right animate-fade-in transition-all duration-300" dir="rtl">
      
      {/* ── Toast Notification Banner في أسفل الشاشة ── */}
      {localToast && (
        <div
          className="fixed bottom-22 sm:bottom-20 right-1/2 translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-full text-xs font-black shadow-xl flex items-center gap-2.5 border border-[#5B5FEF]/40 pointer-events-none whitespace-nowrap animate-fade-in transition-all"
        >
          <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0 animate-bounce" />
          <span>{localToast}</span>
        </div>
      )}

      {/* Top Header: Title + Refresh Button */}
      <div className="flex items-center justify-between pb-3.5 border-b border-[#E6E6F0]">
        <div className="flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0">
            <AthkarSectionSvg size={22} />
          </span>
          <h3 className="text-lg font-black text-[#25263A] font-tajawal">
            دعاء اليوم
          </h3>
        </div>

        <button
          id="btn-next-dua"
          type="button"
          onClick={handleNextDua}
          title="تغيير الدعاء"
          aria-label="تغيير الدعاء"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#EEEEFF] text-[#4145C7] hover:bg-[#E2E2FF] active:scale-95 transition-all cursor-pointer group"
        >
          <RefreshCw className={`w-4 h-4 text-[#5B5FEF] transition-transform duration-300 ${isRotating ? 'rotate-180 text-[#4145C7]' : 'group-hover:rotate-45'}`} />
          <span className="text-xs font-bold text-[#4145C7]">دعاء آخر</span>
        </button>
      </div>

      {/* Dua Content with large, clear Arabic font (18px) */}
      <div className="py-5 my-1 flex flex-col items-center text-center">
        <p className="text-[18px] font-bold text-[#25263A] leading-[1.75] font-amiri select-text">
          {currentDua.text}
        </p>
        <span className="mt-3 text-xs font-bold text-[#77798C] inline-flex items-center gap-1.5">
          <QuranSectionSvg size={16} />
          <span>{currentDua.source}</span>
        </span>
      </div>

      {/* Bottom Action Buttons: Copy & Share with Ripple Effect */}
      <div className="flex items-center gap-3.5 pt-3.5 border-t border-[#E6E6F0]">
        {/* Copy Button (Secondary: #EEEEFF / #4145C7) */}
        <button
          id="btn-copy-dua"
          type="button"
          onClick={handleCopy}
          className="relative overflow-hidden flex-1 py-3 px-4 rounded-[14px] bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all duration-150 cursor-pointer"
        >
          {copyRipples.map((ripple) => (
            <span
              key={ripple.id}
              style={{
                left: ripple.x,
                top: ripple.y,
                width: ripple.size,
                height: ripple.size,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute rounded-full bg-[#5B5FEF]/20 pointer-events-none animate-ripple"
            />
          ))}

          {copied ? (
            <>
              <Check className="w-[18px] h-[18px] text-[#4CAF82] animate-scale-in" />
              <span className="text-[#4CAF82] font-black">تم النسخ</span>
            </>
          ) : (
            <>
              <Copy className="w-[18px] h-[18px] text-[#4145C7]" />
              <span>نسخ الدعاء</span>
            </>
          )}
        </button>

        {/* Share Button (Primary: #5B5FEF / #FFFFFF) */}
        <button
          id="btn-share-dua"
          type="button"
          onClick={handleShare}
          className="relative overflow-hidden flex-1 py-3 px-4 rounded-[14px] bg-[#5B5FEF] hover:bg-[#4145C7] active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-[0_3px_10px_rgba(91,95,239,0.25)] transition-all duration-150 cursor-pointer"
        >
          {shareRipples.map((ripple) => (
            <span
              key={ripple.id}
              style={{
                left: ripple.x,
                top: ripple.y,
                width: ripple.size,
                height: ripple.size,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
            />
          ))}

          <Share2 className="w-[18px] h-[18px] text-white" />
          <span className="text-white font-black">مشاركة</span>
        </button>
      </div>

      {/* Link to Dua Corner */}
      {onNavigate && (
        <button
          type="button"
          onClick={() => onNavigate('dua_corner')}
          className="w-full mt-3 py-2 px-3 rounded-xl bg-[#F8F8FC] hover:bg-[#F0EFF8] active:scale-[0.99] border border-[#E6E6F0] text-xs font-black text-[#5B5FEF] flex items-center justify-center gap-1.5 transition-all cursor-pointer"
        >
          <span>🤲 تصفح جميع الأدعية المأثورة والخاصة في «ركن الدعاء»</span>
          <span className="text-sm">←</span>
        </button>
      )}

      {/* Share Modal for Daily Dua */}
      <DhikrShareModal
        dhikr={{
          text: currentDua.text,
          source: currentDua.source,
          title: 'دُعَاءُ الْيَوْمِ الْمُبَارَكُ'
        }}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </div>
  );
};
