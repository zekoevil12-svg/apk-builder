import React, { useState, useEffect } from 'react';
import { RifqLogo } from './RifqLogo';

interface SplashScreenProps {
  onFinish: () => void;
  durationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ 
  onFinish, 
  durationMs = 2600 
}) => {
  const [progress, setProgress] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    // Progress bar smooth interpolation from 0% to 100%
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const calculatedProgress = Math.min(100, Math.round((elapsed / durationMs) * 100));
      setProgress(calculatedProgress);

      if (elapsed >= durationMs) {
        clearInterval(interval);
        handleExit();
      }
    }, 25);

    return () => clearInterval(interval);
  }, [durationMs]);

  const handleExit = () => {
    setIsExiting(true);
    setTimeout(() => {
      onFinish();
    }, 350); // 350ms smooth exit fade
  };

  return (
    <div 
      className={`fixed inset-0 z-50 flex flex-col justify-between items-center p-6 sm:p-8 bg-[#F7F7FC] text-[#25263A] select-none font-tajawal overflow-hidden transition-opacity duration-350 ${
        isExiting ? 'opacity-0 scale-102 pointer-events-none' : 'opacity-100'
      }`}
      dir="rtl"
    >
      {/* ─── BACKGROUND SUBTLE ISLAMIC ARABESQUE PATTERN ─── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="islamicGrid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path
                d="M 30 0 L 60 30 L 30 60 L 0 30 Z"
                fill="none"
                stroke="#5B5FEF"
                strokeWidth="0.6"
                strokeDasharray="2 4"
                opacity="0.35"
              />
              <circle cx="30" cy="30" r="12" fill="none" stroke="#E8B84A" strokeWidth="0.5" opacity="0.5" />
              <polygon points="30,22 36,30 30,38 24,30" fill="none" stroke="#72B7E8" strokeWidth="0.4" opacity="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#islamicGrid)" />
        </svg>

        {/* Ambient Top & Bottom Vignettes */}
        <div className="absolute top-0 right-0 left-0 h-40 bg-gradient-to-b from-[#5B5FEF]/8 to-transparent" />
        <div className="absolute bottom-0 right-0 left-0 h-40 bg-gradient-to-t from-[#E99AC7]/10 to-transparent" />
      </div>

      {/* ─── TOP: SKIP BUTTON (RIGHT / RTL) ─── */}
      <div className="w-full max-w-md flex justify-start z-10 pt-2">
        <button
          type="button"
          onClick={handleExit}
          className="text-xs font-bold text-[#4145C7] bg-[#EEEEFF] hover:bg-[#5B5FEF] hover:text-white active:scale-95 px-4 py-1.5 rounded-full border border-[#E6E6F0] transition-all cursor-pointer shadow-2xs"
          title="تخطي شاشة البداية"
        >
          تخطي
        </button>
      </div>

      {/* ─── CENTER: LOGO + TITLES + AYAH ─── */}
      <div className="flex flex-col items-center text-center my-auto z-10 max-w-sm px-4">
        {/* Glow Halo behind Logo */}
        <div className="relative mb-2">
          <div className="absolute -inset-6 rounded-full bg-[#5B5FEF]/15 blur-2xl animate-pulse pointer-events-none" />
          <div className="absolute -inset-10 rounded-full bg-[#72B7E8]/15 blur-3xl pointer-events-none" />

          {/* Logo with Fade-in, Scale 0.8->1, and subtle pulse animation */}
          <div className="relative animate-splash-logo">
            <RifqLogo 
              size={180} 
              variant="emblem" 
              withGlow={true}
              className="drop-shadow-xl filter"
            />
          </div>
        </div>

        {/* App Title "رِفْق" */}
        <h1 
          className="text-[42px] leading-tight font-black font-amiri tracking-wide mt-1 drop-shadow-2xs select-none text-[#5B5FEF]"
        >
          رِفْـق
        </h1>

        {/* Latin Word "RIFQ" */}
        <span 
          className="text-[20px] font-extrabold text-[#25263A] tracking-[6px] uppercase font-tajawal -mt-1 select-none"
        >
          RIFQ
        </span>

        {/* Decorative 8-point Islamic star divider */}
        <div className="flex items-center gap-3 my-3 opacity-85">
          <div className="w-10 h-px bg-gradient-to-r from-transparent to-[#5B5FEF]" />
          <div className="w-2.5 h-2.5 rotate-45 border border-[#E8B84A] bg-[#E8B84A]/20" />
          <div className="w-10 h-px bg-gradient-to-l from-transparent to-[#5B5FEF]" />
        </div>

        {/* Quranic Ayah in elegant text */}
        <p className="text-[14px] leading-relaxed text-[#77798C] font-amiri font-semibold max-w-xs px-2 select-none">
          ﴿فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ﴾
        </p>
      </div>

      {/* ─── BOTTOM: LINEAR PROGRESS BAR + LOADING TEXT ─── */}
      <div className="w-full max-w-xs flex flex-col items-center space-y-2.5 pb-4 z-10">
        {/* Elegant Linear Progress Bar */}
        <div className="w-full h-1.5 bg-[#EEEEFF] rounded-full overflow-hidden p-0.5 border border-[#E6E6F0]">
          <div 
            className="h-full bg-gradient-to-r from-[#5B5FEF] via-[#72B7E8] to-[#E8B84A] rounded-full transition-all duration-75 ease-out shadow-xs"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Small text below: "جارٍ التحميل..." with percentage */}
        <div className="flex items-center justify-between w-full px-1 text-[11px] text-[#77798C] font-medium select-none">
          <span>جارٍ التحميل...</span>
          <span className="font-mono text-[#5B5FEF] font-bold">{progress}%</span>
        </div>
      </div>
    </div>
  );
};
