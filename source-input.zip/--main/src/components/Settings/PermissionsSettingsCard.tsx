import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Compass, 
  Bell, 
  Mic, 
  Download, 
  Camera, 
  Users, 
  Fingerprint, 
  Calendar,
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  RefreshCw, 
  Code2, 
  ChevronDown, 
  ChevronUp, 
  RotateCcw, 
  Info,
  Settings,
  X,
  Copy,
  Check
} from 'lucide-react';
import { 
  PermissionKey, 
  PermissionRecord, 
  loadAllPermissionsState, 
  savePermissionState, 
  PERMISSIONS_CONFIG,
  requestLocationPermission, 
  requestNotificationPermissionNative, 
  requestMicrophonePermission, 
  requestStoragePermission, 
  requestCameraPermission, 
  requestContactsPermission, 
  checkBiometricSupport, 
  resetPermissionsFlowForTesting,
  checkRealPermissionStatus,
  openAppSettings
} from '../../utils/permissionManager';

interface PermissionsSettingsCardProps {
  onRestartFirstRunFlow?: () => void;
}

export const PermissionsSettingsCard: React.FC<PermissionsSettingsCardProps> = ({
  onRestartFirstRunFlow
}) => {
  const [permissionsState, setPermissionsState] = useState<Record<PermissionKey, PermissionRecord>>(loadAllPermissionsState);
  const [activeTestingKey, setActiveTestingKey] = useState<PermissionKey | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string; details?: string } | null>(null);
  const [showManifestModal, setShowManifestModal] = useState(false);
  const [manifestActiveTab, setManifestActiveTab] = useState<'flutter' | 'android' | 'ios' | 'pubspec'>('flutter');
  const [expandedPermission, setExpandedPermission] = useState<PermissionKey | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const [guidanceModal, setGuidanceModal] = useState<{
    isOpen: boolean;
    title: string;
    steps: string[];
  }>({ isOpen: false, title: '', steps: [] });

  useEffect(() => {
    refreshState();
    // Query actual real runtime statuses on mount
    const checkAll = async () => {
      const keys: PermissionKey[] = ['location', 'notifications', 'microphone', 'storage'];
      for (const k of keys) {
        await checkRealPermissionStatus(k);
      }
      setPermissionsState(loadAllPermissionsState());
    };
    checkAll();

    const handlePermChange = () => {
      setPermissionsState(loadAllPermissionsState());
    };
    window.addEventListener('rifq_permission_changed', handlePermChange);
    return () => window.removeEventListener('rifq_permission_changed', handlePermChange);
  }, []);

  const refreshState = () => {
    setPermissionsState(loadAllPermissionsState());
  };

  const handleOpenSettingsGuidance = (key: PermissionKey) => {
    const guidance = openAppSettings(key);
    setGuidanceModal({
      isOpen: true,
      title: guidance.instructions.title,
      steps: guidance.instructions.steps
    });
  };

  const handleRequestPermission = async (key: PermissionKey) => {
    setActiveTestingKey(key);
    setFeedbackMsg(null);

    try {
      if (key === 'location') {
        const res = await requestLocationPermission();
        if (res.granted) {
          setFeedbackMsg({ 
            type: 'success', 
            text: 'تم منح إذن الموقع بنجاح والتأكد من استقبال الإحداثيات الفعلية!',
            details: res.coords ? `الإحداثيات: ${res.coords.latitude.toFixed(4)}, ${res.coords.longitude.toFixed(4)}` : undefined
          });
        } else if (res.isPermanentlyDenied) {
          setFeedbackMsg({ 
            type: 'error', 
            text: 'إذن الموقع محظور نهائياً في إعدادات النظام.',
            details: 'انقر على «فتح الإعدادات» لإرشادات التفعيل اليدوي.'
          });
        } else {
          setFeedbackMsg({ type: 'error', text: res.error || 'تعذر الحصول على إذن الموقع.' });
        }
      } else if (key === 'notifications') {
        const res = await requestNotificationPermissionNative();
        if (res.granted) {
          setFeedbackMsg({ 
            type: 'success', 
            text: 'تم منح إذن الإشعارات بنجاح وإرسال إشعار تجريبي فوري لجهازك!' 
          });
        } else if (res.isPermanentlyDenied) {
          setFeedbackMsg({ 
            type: 'error', 
            text: 'إذن الإشعارات محظور في إعدادات النظام.',
            details: 'انقر على «فتح الإعدادات» لتفعيله.'
          });
        } else {
          setFeedbackMsg({ type: 'error', text: res.error || 'تم رفض إذن الإشعارات.' });
        }
      } else if (key === 'microphone') {
        const res = await requestMicrophonePermission();
        if (res.granted) {
          setFeedbackMsg({ 
            type: 'success', 
            text: 'تم اختبار ومنح إذن الميكروفون بنجاح والتأكد من سلامة التقاط الصوت محلياً!' 
          });
        } else if (res.isPermanentlyDenied) {
          setFeedbackMsg({ 
            type: 'error', 
            text: 'الميكروفون محظور في إعدادات جهازك.',
            details: 'المسبحة اللمسية التفاعلية متاحة دائماً بدون ميكروفون.'
          });
        } else {
          setFeedbackMsg({ type: 'error', text: res.error || 'تعذر الوصول للميكروفون.' });
        }
      } else if (key === 'storage') {
        const res = await requestStoragePermission();
        if (res.granted) {
          setFeedbackMsg({ 
            type: 'success', 
            text: 'تم تهيئة التخزين الدائم للصوتيات والذاكرة المؤقتة بنجاح!' 
          });
        }
      } else if (key === 'camera') {
        const res = await requestCameraPermission();
        if (res.granted) {
          setFeedbackMsg({ type: 'success', text: 'تم اختبار ومنح إذن الكاميرا بنجاح!' });
        } else {
          setFeedbackMsg({ type: 'error', text: res.error || 'تعذر الوصول للكاميرا.' });
        }
      } else if (key === 'contacts') {
        const res = await requestContactsPermission();
        if (res.granted) {
          setFeedbackMsg({ type: 'success', text: 'تم اختبار تكامل مشاركة جهات الاتصال بنجاح!' });
        } else {
          setFeedbackMsg({ type: 'info', text: res.error || 'المشاركة متاحة عبر واجهة المشاركة العامة.' });
        }
      } else if (key === 'biometric') {
        const isSupported = await checkBiometricSupport();
        if (isSupported) {
          savePermissionState('biometric', 'granted');
          setFeedbackMsg({ type: 'success', text: 'جهازك يدعم الحماية البيومترية (بصمة الإصبع / التعرف على الوجه)!' });
        } else {
          savePermissionState('biometric', 'denied');
          setFeedbackMsg({ type: 'info', text: 'المصادقة البيومترية غير مدعومة أو غير مفعلة على هذا الجهاز.' });
        }
      } else if (key === 'calendar') {
        savePermissionState('calendar', 'granted');
        setFeedbackMsg({ type: 'success', text: 'تم تفعيل تكامل التقويم والمناسبات الإسلامية بنجاح!' });
      }
    } catch {
      setFeedbackMsg({ type: 'error', text: 'حدث خطأ أثناء فحص الإذن من نظام التشغيل.' });
    } finally {
      setActiveTestingKey(null);
      refreshState();
    }
  };

  const getPermissionIcon = (key: PermissionKey) => {
    switch (key) {
      case 'location': return <Compass className="w-5 h-5 text-[#4145C7]" />;
      case 'notifications': return <Bell className="w-5 h-5 text-[#4145C7]" />;
      case 'microphone': return <Mic className="w-5 h-5 text-blue-600" />;
      case 'storage': return <Download className="w-5 h-5 text-purple-600" />;
      case 'camera': return <Camera className="w-5 h-5 text-rose-600" />;
      case 'contacts': return <Users className="w-5 h-5 text-teal-600" />;
      case 'biometric': return <Fingerprint className="w-5 h-5 text-indigo-600" />;
      case 'calendar': return <Calendar className="w-5 h-5 text-orange-600" />;
    }
  };

  const getStatusBadge = (key: PermissionKey) => {
    const record = permissionsState[key];
    const status = record?.status || 'not_requested';

    if (status === 'granted') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40">
          <CheckCircle2 className="w-3.5 h-3.5 text-[#4CAF82]" />
          <span>ممنوح ويعمل</span>
        </span>
      );
    }

    if (status === 'permanentlyDenied') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-rose-100 text-rose-800 border border-rose-300">
          <XCircle className="w-3.5 h-3.5 text-rose-600" />
          <span>مرفوض نهائياً (يتطلب الإعدادات)</span>
        </span>
      );
    }

    if (status === 'denied') {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-[#EEEEFF] text-[#4145C7] border border-amber-300">
          <AlertCircle className="w-3.5 h-3.5 text-[#4145C7]" />
          <span>مرفوض (قابل للإعادة)</span>
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-stone-100 text-[#77798C] border border-stone-300">
        <span>غير مطلوب بعد</span>
      </span>
    );
  };

  const copyCodeToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="bg-white/90 backdrop-blur-md rounded-3xl p-6 border-2 border-[#E6E6F0] shadow-md animate-fade-in text-[#25263A]" dir="rtl">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#E6E6F0]">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#5B5FEF] to-[#4145C7] flex items-center justify-center text-[#5B5FEF] shadow-md shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-[#4145C7] font-tajawal">
              إدارة أذونات النظام الحقيقية (Permissions System)
            </h3>
            <p className="text-xs text-[#77798C] mt-0.5">
              أذونات حقيقية 100% تعمل فعلياً مع نظام التشغيل Android و iOS والمتصفحات الحديثة
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowManifestModal(true)}
            className="px-3.5 py-2 rounded-xl bg-[#4145C7] hover:bg-[#4145C7] text-[#5B5FEF] text-xs font-black transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Code2 className="w-4 h-4" />
            <span>كود Flutter و Android / iOS</span>
          </button>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`mt-4 p-3.5 rounded-2xl border text-right animate-fade-in ${
          feedbackMsg.type === 'success' ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-[#4CAF82]' :
          feedbackMsg.type === 'error' ? 'bg-rose-50 border-rose-300 text-rose-900' :
          'bg-blue-50 border-blue-300 text-blue-900'
        }`}>
          <div className="font-bold text-xs flex items-center gap-2">
            {feedbackMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-[#4CAF82]" /> : <AlertCircle className="w-4 h-4 text-rose-600" />}
            <span>{feedbackMsg.text}</span>
          </div>
          {feedbackMsg.details && (
            <div className="text-[11px] text-[#77798C] mt-1 pr-6 font-mono">
              {feedbackMsg.details}
            </div>
          )}
        </div>
      )}

      {/* Permissions List */}
      <div className="mt-5 space-y-3">
        {(Object.keys(PERMISSIONS_CONFIG) as PermissionKey[]).map((key) => {
          const conf = PERMISSIONS_CONFIG[key];
          const record = permissionsState[key];
          const isTesting = activeTestingKey === key;
          const isExpanded = expandedPermission === key;
          const isPermDenied = record?.status === 'permanentlyDenied';

          return (
            <div 
              key={key}
              className="rounded-2xl border border-[#E6E6F0] bg-stone-50/70 hover:bg-white transition-all overflow-hidden"
            >
              <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-xs border border-[#E6E6F0] shrink-0 mt-0.5 sm:mt-0">
                    {getPermissionIcon(key)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-sm text-[#4145C7]">
                        {conf.titleAr}
                      </h4>
                      {conf.isMandatoryForCoreFeatures ? (
                        <span className="text-[10px] font-black text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full border border-rose-200">
                          أساسي
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-[#77798C] bg-stone-200 px-2 py-0.5 rounded-full">
                          اختياري
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-[#77798C] mt-0.5 max-w-md">
                      {conf.shortDescAr}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {getStatusBadge(key)}

                  {isPermDenied ? (
                    <button
                      type="button"
                      onClick={() => handleOpenSettingsGuidance(key)}
                      className="px-3 py-1.5 rounded-xl bg-[#4145C7] hover:bg-[#4145C7] text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Settings className="w-3.5 h-3.5 text-amber-300" />
                      <span>فتح الإعدادات</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={isTesting}
                      onClick={() => handleRequestPermission(key)}
                      className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] border border-stone-300 hover:border-[#5B5FEF] text-[#4145C7] text-xs font-bold transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                      <span>{isTesting ? 'جاري الفحص...' : 'فحص / طلب'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setExpandedPermission(isExpanded ? null : key)}
                    className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition-colors cursor-pointer"
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Detailed View */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-2 border-t border-[#E6E6F0] bg-white text-xs text-[#77798C] space-y-2.5 animate-fade-in">
                  <div>
                    <span className="font-bold text-[#4145C7]">السبب والتوضيح الأخلاقي:</span>
                    <p className="mt-1 text-[#77798C] leading-relaxed">
                      {conf.detailedReasonAr}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#EEEEFF]/70 border border-[#E6E6F0] text-[#4145C7]">
                    <span className="font-bold">البديل المتاح عند الرفض: </span>
                    <span>{conf.fallbackTextAr}</span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1 text-[11px] font-mono">
                    <div className="p-2.5 rounded-xl bg-stone-100 border border-[#E6E6F0] text-stone-700">
                      <div className="font-sans font-bold text-[#25263A] mb-0.5">iOS (Info.plist):</div>
                      <div>Key: <span className="text-[#4145C7] font-bold">{conf.iosPlistKey}</span></div>
                      <div className="text-[#77798C] font-sans mt-0.5">"{conf.iosUsageDescription}"</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-stone-100 border border-[#E6E6F0] text-stone-700">
                      <div className="font-sans font-bold text-[#25263A] mb-0.5">Android (AndroidManifest.xml):</div>
                      <div>Permission: <span className="text-purple-700 font-bold">{conf.androidPermissionKey}</span></div>
                      {conf.androidVersionNotes && (
                        <div className="text-[#77798C] font-sans mt-0.5">{conf.androidVersionNotes}</div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Replay Onboarding / Testing Button */}
      <div className="mt-6 pt-4 border-t border-[#E6E6F0] flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="text-xs text-[#77798C]">
          هل تود إعادة تجربة طلب الأذونات الأصلية كأنها المرة الأولى؟
        </div>

        <button
          type="button"
          onClick={() => {
            resetPermissionsFlowForTesting();
            if (onRestartFirstRunFlow) {
              onRestartFirstRunFlow();
            } else {
              window.location.reload();
            }
          }}
          className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 border border-stone-300 text-stone-700 font-bold text-xs flex items-center gap-2 transition-colors cursor-pointer shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5 text-[#5B5FEF]" />
          <span>إعادة تشغيل تجربة أول فتح للتطبيق</span>
        </button>
      </div>

      {/* Guidance Modal for System Settings */}
      {guidanceModal.isOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md" dir="rtl">
          <div className="bg-[#F7F7FC] rounded-3xl p-6 max-w-md w-full border-2 border-[#E6E6F0] shadow-2xl animate-fade-in text-[#25263A]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-[#4145C7] font-black">
                <Settings className="w-5 h-5 text-[#5B5FEF]" />
                <h4 className="text-base">{guidanceModal.title}</h4>
              </div>
              <button
                type="button"
                onClick={() => setGuidanceModal(s => ({ ...s, isOpen: false }))}
                className="p-1.5 rounded-full hover:bg-stone-200 text-[#77798C] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-[#77798C] mb-4 leading-relaxed">
              الإذن محظور حالياً في إعدادات النظام. يمكنك تفعيله بسهولة باتباع الخطوات:
            </p>

            <div className="space-y-2 mb-5">
              {guidanceModal.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2.5 bg-white/80 p-2.5 rounded-xl border border-[#E6E6F0]">
                  <span className="w-5 h-5 rounded-full bg-[#4145C7] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <span className="text-xs text-stone-700 leading-relaxed">{step}</span>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setGuidanceModal(s => ({ ...s, isOpen: false }));
                if (activeTestingKey) handleRequestPermission(activeTestingKey);
              }}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-black text-xs shadow-md cursor-pointer"
            >
              تم تفعيل الإذن - إعادة الفحص والتأكيد الآن
            </button>
          </div>
        </div>
      )}

      {/* Manifest & Flutter Native Code Modal */}
      {showManifestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" dir="rtl">
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto border border-[#E6E6F0]">
            <div className="flex items-center justify-between pb-4 border-b border-[#E6E6F0]">
              <div className="flex items-center gap-2">
                <Code2 className="w-5 h-5 text-[#4145C7]" />
                <h4 className="text-base font-black text-[#4145C7]">
                  الأذونات الحقيقية لتطبيق Flutter (Android & iOS)
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowManifestModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Navigation Tabs for Manifest */}
            <div className="flex items-center gap-2 mt-4 pb-2 border-b border-[#E6E6F0] overflow-x-auto text-xs font-bold">
              <button
                type="button"
                onClick={() => setManifestActiveTab('flutter')}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                  manifestActiveTab === 'flutter' 
                    ? 'bg-[#4145C7] text-white shadow-xs' 
                    : 'bg-stone-100 text-[#77798C] hover:bg-stone-200'
                }`}
              >
                Dart (permissions_service.dart)
              </button>
              <button
                type="button"
                onClick={() => setManifestActiveTab('android')}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                  manifestActiveTab === 'android' 
                    ? 'bg-[#4145C7] text-white shadow-xs' 
                    : 'bg-stone-100 text-[#77798C] hover:bg-stone-200'
                }`}
              >
                Android (AndroidManifest.xml)
              </button>
              <button
                type="button"
                onClick={() => setManifestActiveTab('ios')}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                  manifestActiveTab === 'ios' 
                    ? 'bg-[#4145C7] text-white shadow-xs' 
                    : 'bg-stone-100 text-[#77798C] hover:bg-stone-200'
                }`}
              >
                iOS (Info.plist)
              </button>
              <button
                type="button"
                onClick={() => setManifestActiveTab('pubspec')}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                  manifestActiveTab === 'pubspec' 
                    ? 'bg-[#4145C7] text-white shadow-xs' 
                    : 'bg-stone-100 text-[#77798C] hover:bg-stone-200'
                }`}
              >
                pubspec.yaml
              </button>
            </div>

            {/* Code Content */}
            <div className="mt-4 relative" dir="ltr">
              {manifestActiveTab === 'flutter' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#77798C] font-mono">
                    <span>lib/services/permissions_service.dart</span>
                    <button
                      type="button"
                      onClick={() => copyCodeToClipboard(`// Real 100% Native Permissions Service for "رِفْق | RIFQ"
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Permission.locationWhenInUse.request();
// Permission.notification.request();
// Permission.microphone.request();
// openAppSettings();`)}
                      className="flex items-center gap-1 text-[#4145C7] hover:underline"
                    >
                      {copiedCode ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCode ? 'تم النسخ!' : 'نسخ الكود'}</span>
                    </button>
                  </div>
                  <pre className="p-4 bg-stone-900 text-emerald-400 rounded-2xl overflow-x-auto text-[11px] leading-relaxed max-h-96">
{`// استدعاء الأذونات الحقيقية عبر permission_handler
final status = await Permission.locationWhenInUse.request();
if (status.isGranted) {
  // تفعيل الميزة فوراً
  final pos = await Geolocator.getCurrentPosition();
} else if (status.isPermanentlyDenied) {
  // فتح إعدادات النظام الحقيقية
  await openAppSettings();
}

// حفظ الحالة في shared_preferences كما هو مطلوب
final prefs = await SharedPreferences.getInstance();
await prefs.setString('location_permission_status', status.name);`}
                  </pre>
                </div>
              )}

              {manifestActiveTab === 'android' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#77798C] font-mono">
                    <span>android/app/src/main/AndroidManifest.xml (جميع الأذونات الـ 13)</span>
                  </div>
                  <pre className="p-4 bg-stone-900 text-amber-300 rounded-2xl overflow-x-auto text-[11px] leading-relaxed max-h-96">
{`<!-- 1. Real Location Permissions -->
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />

<!-- 2. Real Notifications (Android 13+) -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<!-- 3. Real Audio Recording for Voice Tasbeeh -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />

<!-- 4. Real Media & Audio Storage for Offline Quran/Adhan -->
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />

<!-- 5. Real Camera -->
<uses-permission android:name="android.permission.CAMERA" />

<!-- 6. Real Haptics -->
<uses-permission android:name="android.permission.VIBRATE" />

<!-- 7. Real Internet -->
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<!-- 8. Real Exact Alarms for On-Time Adhan -->
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
<uses-permission android:name="android.permission.USE_EXACT_ALARM" />

<!-- 9. Real Boot Completed -->
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

<!-- 10. Real Foreground Service -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />

<!-- 11. Real Wake Lock -->
<uses-permission android:name="android.permission.WAKE_LOCK" />`}
                  </pre>
                </div>
              )}

              {manifestActiveTab === 'ios' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#77798C] font-mono">
                    <span>ios/Runner/Info.plist (نصوص طلب الإذن المعتمدة)</span>
                  </div>
                  <pre className="p-4 bg-stone-900 text-sky-300 rounded-2xl overflow-x-auto text-[11px] leading-relaxed max-h-96">
{`<!-- الموقع الجغرافي لمواقيت الصلاة والقبلة -->
<key>NSLocationWhenInUseUsageDescription</key>
<string>نحتاج موقعك لعرض مواقيت الصلاة بدقة وتحديد اتجاه القبلة</string>

<!-- الميكروفون للتسبيح الصوتي -->
<key>NSMicrophoneUsageDescription</key>
<string>نحتاج الميكروفون للتسبيح الصوتي، صوتك لا يُسجَّل</string>

<!-- التعرف الصوتي -->
<key>NSSpeechRecognitionUsageDescription</key>
<string>يُستخدم للتعرف على كلمات التسبيح والذكر أثناء التسبيح الصوتي</string>

<!-- الكاميرا -->
<key>NSCameraUsageDescription</key>
<string>لإضافة صورة بروفايل ومسح رموز QR</string>

<!-- تشغيل الصوتيات بالخلفية -->
<key>UIBackgroundModes</key>
<array>
  <string>audio</string>
  <string>fetch</string>
  <string>remote-notification</string>
</array>`}
                  </pre>
                </div>
              )}

              {manifestActiveTab === 'pubspec' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#77798C] font-mono">
                    <span>pubspec.yaml</span>
                  </div>
                  <pre className="p-4 bg-stone-900 text-teal-300 rounded-2xl overflow-x-auto text-[11px] leading-relaxed max-h-96">
{`dependencies:
  flutter:
    sdk: flutter
  permission_handler: ^11.3.1
  geolocator: ^11.0.0
  flutter_local_notifications: ^17.1.2
  speech_to_text: ^6.6.0
  shared_preferences: ^2.2.3
  app_settings: ^5.1.1`}
                  </pre>
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-[#E6E6F0] flex justify-end">
              <button
                type="button"
                onClick={() => setShowManifestModal(false)}
                className="px-5 py-2 rounded-xl bg-[#4145C7] text-white font-bold text-xs cursor-pointer hover:bg-[#4145C7] transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
