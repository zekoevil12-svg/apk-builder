import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowRight,
  RotateCcw,
  Eye,
  EyeOff,
  CheckCircle2,
  Sparkles,
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  Keyboard,
  Hand,
  BookOpen,
  FileText,
  Check,
  AlertCircle,
  Sliders,
  Layers,
} from 'lucide-react';
import { TahfeezPlan } from '../../types';
import { getSurahDetail } from '../../utils/quranService';
import { AyahItem } from '../../data/quranData';
import {
  TAHFEEZ_RECITERS,
  getAudioAyahUrl,
  loadSelectedTahfeezReciter,
  saveSelectedTahfeezReciter,
} from '../../utils/tahfeezService';
import { soundManager } from '../../utils/audio';

interface DailyMemorizationViewProps {
  plan: TahfeezPlan;
  initialRecitationActive?: boolean;
  onBack: () => void;
  onCompleteDay: (planId: string, ayahsCount: number) => void;
  onShowToast: (msg: string) => void;
}

export type HideLevel = 0 | 25 | 50 | 75 | 100;
type RecitationMode = 'progressive_hide' | 'writing_test';
type DisplayScope = 'single_ayah' | 'full_page';
type MaskStyle = 'blur' | 'hidden';
type HideUnit = 'word' | 'ayah';

/**
 * Normalize Arabic Quranic words for fair comparison with user's typed text
 * (removes tashkeel, Uthmani symbols, and normalizes Alef/Ta-Marbuta/Ya)
 */
export function normalizeArabicForComparison(text: string): string {
  return text
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/[ىئ]/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/[^\u0621-\u064A0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Determines whether a specific word index should be hidden under the chosen progressive hide level
 */
export function isWordHiddenAtLevel(
  wordIdx: number,
  totalWordsInAyah: number,
  ayahIdx: number,
  level: HideLevel
): boolean {
  if (level === 0) return false;
  if (level === 100) return true;

  if (totalWordsInAyah <= 2) {
    return level >= 50 ? wordIdx === totalWordsInAyah - 1 : wordIdx === 1;
  }

  const offset = (wordIdx + ayahIdx) % 4;
  if (level === 25) {
    return offset === 1;
  }
  if (level === 50) {
    return (wordIdx + ayahIdx) % 2 === 1;
  }
  if (level === 75) {
    return offset !== 0;
  }
  return false;
}

/**
 * Determines whether a word in an Ayah should be hidden when hiding by whole Ayahs progressively
 */
export function isAyahWordHiddenAtLevel(
  wordIdx: number,
  totalWordsInAyah: number,
  ayahIdx: number,
  totalAyahs: number,
  level: HideLevel
): boolean {
  if (level === 0) return false;
  if (level === 100) return true;

  if (level === 25) {
    // Hide the second half of each verse so the beginning of each verse acts as a cue
    return wordIdx >= Math.ceil(totalWordsInAyah * 0.6);
  }
  if (level === 50) {
    // Keep only the first 1-2 words of each verse as a cue, hide the rest of the verse
    const cueWords = totalWordsInAyah > 4 ? 2 : 1;
    return wordIdx >= cueWords;
  }
  if (level === 75) {
    // Keep only the very first word of even verses, hide odd verses completely
    if (ayahIdx % 2 === 1) return true;
    return wordIdx >= 1;
  }
  return true;
}

export const DailyMemorizationView: React.FC<DailyMemorizationViewProps> = ({
  plan,
  initialRecitationActive = false,
  onBack,
  onCompleteDay,
  onShowToast,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [sessionAyahs, setSessionAyahs] = useState<AyahItem[]>([]);
  const [currentAyahIndex, setCurrentAyahIndex] = useState<number>(0);
  const [repetitionCount, setRepetitionCount] = useState<number>(0);
  const targetRepetitions = 5;

  // «وضع التسميع» (Recitation Mode) states
  const [isRecitationModeOn, setIsRecitationModeOn] = useState<boolean>(initialRecitationActive);
  const [recitationMode, setRecitationMode] = useState<RecitationMode>('progressive_hide');
  const [displayScope, setDisplayScope] = useState<DisplayScope>('full_page');
  const [hideLevel, setHideLevel] = useState<HideLevel>(initialRecitationActive ? 50 : 0);
  const [maskStyle, setMaskStyle] = useState<MaskStyle>('blur'); // 'blur' (نص مموه) | 'hidden' (نص مخفي)
  const [hideUnit, setHideUnit] = useState<HideUnit>('ayah'); // 'ayah' (إخفاء الآيات تدريجياً) | 'word' (إخفاء الكلمات)
  const [revealedWordKeys, setRevealedWordKeys] = useState<Set<string>>(new Set());
  const [revealedAyahNumbers, setRevealedAyahNumbers] = useState<Set<number>>(new Set());
  const [hasTestedMemorization, setHasTestedMemorization] = useState<boolean>(initialRecitationActive);
  const [showPreCompletePrompt, setShowPreCompletePrompt] = useState<boolean>(false);

  // Written recitation states
  const [typedRecitation, setTypedRecitation] = useState<string>('');
  const [writingChecked, setWritingChecked] = useState<boolean>(false);

  // Audio states
  const [reciterId, setReciterId] = useState<string>(loadSelectedTahfeezReciter);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const versesCardRef = useRef<HTMLDivElement | null>(null);

  // Determine current day ayah range
  const safeStartAyah = Math.max(1, (plan?.startAyah || 1) + (plan?.completedAyahs || 0));
  const startAyah = safeStartAyah;
  const endAyah = Math.max(
    startAyah,
    Math.min(plan?.endAyah || 30, startAyah + (plan?.dailyAyahsGoal || 5) - 1)
  );

  useEffect(() => {
    let isMounted = true;
    async function fetchAyahs() {
      setLoading(true);
      try {
        const surahDetail = await getSurahDetail(plan?.surahNumber || 67);
        if (isMounted && surahDetail && Array.isArray(surahDetail.ayahs)) {
          const validAyahs = surahDetail.ayahs.filter(
            (a): a is AyahItem => Boolean(a && typeof a.text === 'string')
          );
          const filtered = validAyahs.filter(
            (a) => a.numberInSurah >= startAyah && a.numberInSurah <= endAyah
          );
          setSessionAyahs(
            filtered.length > 0
              ? filtered
              : validAyahs.slice(0, Math.max(1, plan?.dailyAyahsGoal || 5))
          );
        }
      } catch (err) {
        console.error('Failed to load ayahs', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    fetchAyahs();

    return () => {
      isMounted = false;
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [plan?.surahNumber, startAyah, endAyah, plan?.dailyAyahsGoal]);

  const currentAyah = sessionAyahs[currentAyahIndex];

  // Stop audio on ayah change
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  }, [currentAyahIndex, reciterId]);

  // Toggle main «وضع التسميع» switch
  const handleToggleRecitationMode = () => {
    soundManager.triggerHaptic(25);
    if (!isRecitationModeOn) {
      setIsRecitationModeOn(true);
      const nextLevel: HideLevel = hideLevel === 0 ? 50 : hideLevel;
      setHideLevel(nextLevel);
      setRevealedWordKeys(new Set());
      setRevealedAyahNumbers(new Set());
      setHasTestedMemorization(true);
      setShowPreCompletePrompt(false);
      onShowToast('تم تفعيل «وضع التسميع» — اضغط على أي آية أو كلمة مخفية/مموهة لإظهارها');
    } else {
      setIsRecitationModeOn(false);
      setHideLevel(0);
      setRevealedWordKeys(new Set());
      setRevealedAyahNumbers(new Set());
      onShowToast('تم إيقاف وضع التسميع وإظهار كامل النص');
    }
  };

  // Select specific progressive hide level
  const handleSelectHideLevel = (level: HideLevel) => {
    setHideLevel(level);
    setIsRecitationModeOn(level > 0);
    setRevealedWordKeys(new Set());
    setRevealedAyahNumbers(new Set());
    if (level > 0) {
      setHasTestedMemorization(true);
      setShowPreCompletePrompt(false);
      soundManager.triggerHaptic(20);
    }
  };

  // Cycle progressive hide level: 0 -> 25 -> 50 -> 75 -> 100 -> 0
  const handleStepProgressiveHide = () => {
    const levels: HideLevel[] = [0, 25, 50, 75, 100];
    const nextIdx = (levels.indexOf(hideLevel) + 1) % levels.length;
    const nextLevel = levels[nextIdx];
    handleSelectHideLevel(nextLevel);
    onShowToast(
      nextLevel === 0
        ? 'تم إظهار جميع الآيات بالكامل'
        : `وضع التسميع: إخفاء الآيات تدريجيًا بنسبة ${nextLevel}% — اضغط على الآية أو الكلمة لإظهارها`
    );
  };

  // Toggle reveal of a single word on touch/click
  const handleToggleWordReveal = (wordKey: string) => {
    soundManager.triggerHaptic(15);
    setHasTestedMemorization(true);
    setRevealedWordKeys((prev) => {
      const next = new Set(prev);
      if (next.has(wordKey)) {
        next.delete(wordKey);
      } else {
        next.add(wordKey);
      }
      return next;
    });
  };

  // Toggle reveal of a whole Ayah on touch/click
  const handleToggleAyahReveal = (ayahNumberInSurah: number, wordsCount: number) => {
    soundManager.triggerHaptic(20);
    setHasTestedMemorization(true);
    const isCurrentlyRevealed = revealedAyahNumbers.has(ayahNumberInSurah);

    setRevealedAyahNumbers((prev) => {
      const next = new Set(prev);
      if (isCurrentlyRevealed) {
        next.delete(ayahNumberInSurah);
      } else {
        next.add(ayahNumberInSurah);
      }
      return next;
    });

    setRevealedWordKeys((prev) => {
      const next = new Set(prev);
      for (let wIdx = 0; wIdx < wordsCount; wIdx++) {
        const key = `${ayahNumberInSurah}-${wIdx}`;
        if (isCurrentlyRevealed) {
          next.delete(key);
        } else {
          next.add(key);
        }
      }
      return next;
    });
  };

  // Ayahs currently visible based on displayScope
  const displayedAyahs = useMemo(() => {
    if (displayScope === 'single_ayah') {
      return currentAyah ? [{ ayah: currentAyah, idx: currentAyahIndex }] : [];
    }
    return sessionAyahs.map((ayah, idx) => ({ ayah, idx }));
  }, [displayScope, currentAyah, currentAyahIndex, sessionAyahs]);

  // Compute all hidden word keys in current view for "Reveal Next" & progress stats
  const hiddenWordsStats = useMemo(() => {
    const allHiddenKeys: string[] = [];
    let totalWords = 0;

    displayedAyahs.forEach(({ ayah, idx }) => {
      const words = ayah.text.trim().split(/\s+/).filter(Boolean);
      totalWords += words.length;
      words.forEach((_, wIdx) => {
        const isHidden =
          hideUnit === 'ayah'
            ? isAyahWordHiddenAtLevel(wIdx, words.length, idx, displayedAyahs.length, hideLevel)
            : isWordHiddenAtLevel(wIdx, words.length, idx, hideLevel);
        if (isHidden) {
          allHiddenKeys.push(`${ayah.numberInSurah}-${wIdx}`);
        }
      });
    });

    const revealedCount = allHiddenKeys.filter((k) => revealedWordKeys.has(k)).length;
    const nextUnrevealedKey = allHiddenKeys.find((k) => !revealedWordKeys.has(k)) || null;

    return {
      totalWords,
      totalHidden: allHiddenKeys.length,
      revealedCount,
      remainingHidden: Math.max(0, allHiddenKeys.length - revealedCount),
      nextUnrevealedKey,
      allHiddenKeys,
    };
  }, [displayedAyahs, hideLevel, hideUnit, revealedWordKeys]);

  const handleRevealNextWord = () => {
    if (!hiddenWordsStats.nextUnrevealedKey) return;
    soundManager.triggerHaptic(20);
    setHasTestedMemorization(true);
    setRevealedWordKeys((prev) => {
      const next = new Set(prev);
      next.add(hiddenWordsStats.nextUnrevealedKey!);
      return next;
    });
  };

  const handleRevealAllTemporary = () => {
    soundManager.triggerHaptic(20);
    setRevealedWordKeys(new Set(hiddenWordsStats.allHiddenKeys));
    setRevealedAyahNumbers(new Set(displayedAyahs.map((d) => d.ayah.numberInSurah)));
  };

  const handleRehideAll = () => {
    soundManager.triggerHaptic(20);
    setRevealedWordKeys(new Set());
    setRevealedAyahNumbers(new Set());
  };

  // Written Recitation Evaluation
  const writingEvaluation = useMemo(() => {
    const targetText =
      displayScope === 'single_ayah'
        ? currentAyah?.text || ''
        : sessionAyahs.map((a) => a.text).join(' ');

    const originalWords = targetText.trim().split(/\s+/).filter(Boolean);
    const userWords = typedRecitation.trim().split(/\s+/).filter(Boolean);

    const results = originalWords.map((origWord, i) => {
      const userWord = userWords[i] || '';
      const normOrig = normalizeArabicForComparison(origWord);
      const normUser = normalizeArabicForComparison(userWord);
      const isMatch = normUser.length > 0 && normOrig === normUser;
      return {
        origWord,
        userWord,
        isMatch,
      };
    });

    const correctCount = results.filter((r) => r.isMatch).length;
    const accuracy =
      originalWords.length > 0
        ? Math.round((correctCount / originalWords.length) * 100)
        : 0;

    return {
      originalWords,
      userWords,
      results,
      correctCount,
      totalWords: originalWords.length,
      accuracy,
    };
  }, [displayScope, currentAyah, sessionAyahs, typedRecitation]);

  const togglePlayAudio = () => {
    if (!currentAyah) return;

    if (isPlaying && audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
      return;
    }

    const audioUrl = getAudioAyahUrl(reciterId, plan.surahNumber, currentAyah.numberInSurah);
    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
    } else {
      audioRef.current.src = audioUrl;
    }

    audioRef.current.loop = isLooping;

    audioRef.current.onended = () => {
      if (isLooping) {
        setRepetitionCount((prev) => prev + 1);
      } else {
        setIsPlaying(false);
        if (currentAyahIndex < sessionAyahs.length - 1) {
          setCurrentAyahIndex((prev) => prev + 1);
        }
      }
    };

    audioRef.current.onerror = () => {
      setIsPlaying(false);
      onShowToast('تعذر تشغيل التسجيل الصوتي حالياً');
    };

    audioRef.current
      .play()
      .then(() => setIsPlaying(true))
      .catch((e) => {
        console.warn('Audio play failed', e);
        setIsPlaying(false);
      });
  };

  const toggleLoop = () => {
    const next = !isLooping;
    setIsLooping(next);
    if (audioRef.current) {
      audioRef.current.loop = next;
    }
    onShowToast(next ? 'تم تفعيل التكرار التلقائي للآية' : 'تم إيقاف التكرار التلقائي');
  };

  const handleTasbeehRepetition = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(30);
      } catch {}
    }
    soundManager.triggerHaptic(30);

    setRepetitionCount((prev) => prev + 1);

    if (repetitionCount + 1 === targetRepetitions) {
      onShowToast('بارك الله فيك! أكملت 5 تكرارات للآية بنجاح');
    }
  };

  const handleConfirmCompleteWird = () => {
    soundManager.triggerHaptic(60);
    onCompleteDay(plan.id, sessionAyahs.length);
    onShowToast('هنيئاً لك! تم تأكيد إتمام الورد وتحديث جدول التكرار المتباعد');
    onBack();
  };

  const handleAttemptCompleteClick = () => {
    if (!hasTestedMemorization && hideLevel === 0 && typedRecitation.trim().length === 0) {
      setShowPreCompletePrompt(true);
      soundManager.triggerHaptic(30);
      return;
    }
    handleConfirmCompleteWird();
  };

  return (
    <div className="space-y-4 select-none" dir="rtl">
      {/* Top Bar */}
      <div className="flex items-center justify-between bg-white px-4 py-3 rounded-2xl border border-[#E6E6F0] shadow-2xs flex-wrap gap-2">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-stone-700 hover:text-[#5B5FEF] font-bold text-sm transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span>رجوع للتحفيظ</span>
        </button>

        <div className="text-center">
          <h2 className="text-base font-black text-[#25263A]">سورة {plan.surahName}</h2>
          <span className="text-xs text-[#4145C7] font-semibold">
            الآيات ({startAyah} - {endAyah}) • اليوم {plan.currentDay}
          </span>
        </div>

        {/* Reciter Selector */}
        <select
          value={reciterId}
          onChange={(e) => {
            const val = e.target.value;
            setReciterId(val);
            saveSelectedTahfeezReciter(val);
            onShowToast('تم تغيير القارئ');
          }}
          className="bg-stone-50 border border-[#E6E6F0] rounded-xl px-2.5 py-1 text-xs font-bold text-[#25263A] focus:outline-none focus:ring-1 focus:ring-[#5B5FEF]"
        >
          {TAHFEEZ_RECITERS.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="bg-white rounded-3xl p-12 border border-[#E6E6F0] text-center flex flex-col items-center justify-center gap-3">
          <div className="w-10 h-10 border-3 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-bold text-[#25263A]">جاري تحميل آيات الورد المبارك...</p>
        </div>
      ) : (
        <>
          {/* ── شريط ولوحة «وضع التسميع» (إخفاء الآيات تدريجياً - نص مموه أو مخفي) ── */}
          <div
            ref={versesCardRef}
            className={`rounded-3xl p-4 sm:p-5 border-2 transition-all shadow-xs space-y-3.5 ${
              isRecitationModeOn || hideLevel > 0
                ? 'bg-gradient-to-br from-[#FFFFFF] via-[#F7F7FC] to-[#EEEEFF] border-[#5B5FEF]'
                : 'bg-white border-[#E6E6F0]'
            }`}
          >
            {/* Header Row: Toggle «وضع التسميع» */}
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center border transition-colors shrink-0 ${
                    isRecitationModeOn || hideLevel > 0
                      ? 'bg-[#5B5FEF] text-white border-[#E8B84A] shadow-xs'
                      : 'bg-[#F7F7FC] text-[#5B5FEF] border-[#E6E6F0]'
                  }`}
                >
                  <EyeOff className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm sm:text-base font-black text-[#25263A]">
                      وضع التسميع (اختبار الحفظ)
                    </h3>
                    {(isRecitationModeOn || hideLevel > 0) && (
                      <span className="px-2.5 py-0.5 rounded-full bg-[#5B5FEF] text-white text-[10px] font-black">
                        مفعّل ({hideLevel}%)
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-[#77798C] font-semibold">
                    إخفاء الآيات تدريجيًا (نص مموه أو مخفي) وتظهر عند الضغط عليها لاختبار قوة حفظك قبل إتمام الورد
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  id="btn-toggle-recitation-mode"
                  onClick={handleToggleRecitationMode}
                  className={`px-4 py-2.5 rounded-xl font-cairo font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-2xs ${
                    isRecitationModeOn || hideLevel > 0
                      ? 'bg-[#5B5FEF] hover:bg-[#4145C7] text-white'
                      : 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white'
                  }`}
                >
                  {isRecitationModeOn || hideLevel > 0 ? (
                    <>
                      <Eye className="w-4 h-4" />
                      <span>إيقاف وضع التسميع (إظهار الكل)</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-4 h-4" />
                      <span>تفعيل وضع التسميع الآن</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* شريط المستويات التدريجية لإخفاء الآيات */}
            <div className="space-y-2.5 pt-2 border-t border-[#E6E6F0]">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-black text-[#25263A] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>مستوى إخفاء الآيات تدريجيًا:</span>
                </span>

                {/* اختيار نمط الإخفاء: نص مموه (ضبابي) | نص مخفي (نقاط) */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <div className="flex items-center bg-white p-1 rounded-xl border border-[#E6E6F0]">
                    <button
                      type="button"
                      onClick={() => {
                        setRecitationMode('progressive_hide');
                        setMaskStyle('blur');
                        if (hideLevel === 0) handleSelectHideLevel(50);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        recitationMode === 'progressive_hide' && maskStyle === 'blur'
                          ? 'bg-[#5B5FEF] text-white shadow-2xs'
                          : 'text-[#25263A] hover:bg-[#F7F7FC]'
                      }`}
                    >
                      نص مموه (ضبابي)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setRecitationMode('progressive_hide');
                        setMaskStyle('hidden');
                        if (hideLevel === 0) handleSelectHideLevel(50);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        recitationMode === 'progressive_hide' && maskStyle === 'hidden'
                          ? 'bg-[#5B5FEF] text-white shadow-2xs'
                          : 'text-[#25263A] hover:bg-[#F7F7FC]'
                      }`}
                    >
                      نص مخفي (نقاط)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setRecitationMode('writing_test');
                        setHasTestedMemorization(true);
                        setWritingChecked(false);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                        recitationMode === 'writing_test'
                          ? 'bg-[#5B5FEF] text-white shadow-2xs'
                          : 'text-[#25263A] hover:bg-[#F7F7FC]'
                      }`}
                    >
                      <Keyboard className="w-3 h-3" />
                      <span>تسميع كتابي</span>
                    </button>
                  </div>

                  {/* وحدة الإخفاء: بالآية أو بالكلمة */}
                  {recitationMode === 'progressive_hide' && (
                    <div className="flex items-center bg-white p-1 rounded-xl border border-[#E6E6F0]">
                      <button
                        type="button"
                        onClick={() => {
                          setHideUnit('ayah');
                          setRevealedWordKeys(new Set());
                          setRevealedAyahNumbers(new Set());
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                          hideUnit === 'ayah'
                            ? 'bg-[#25263A] text-white'
                            : 'text-[#25263A] hover:bg-[#F7F7FC]'
                        }`}
                      >
                        إخفاء الآيات
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setHideUnit('word');
                          setRevealedWordKeys(new Set());
                          setRevealedAyahNumbers(new Set());
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                          hideUnit === 'word'
                            ? 'bg-[#25263A] text-white'
                            : 'text-[#25263A] hover:bg-[#F7F7FC]'
                        }`}
                      >
                        إخفاء الكلمات
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* أزرار مراحل الإخفاء التدريجي (0% -> 25% -> 50% -> 75% -> 100%) */}
              {recitationMode === 'progressive_hide' && (
                <div className="grid grid-cols-5 gap-1.5">
                  {(
                    [
                      { level: 0 as HideLevel, label: 'إظهار الكل', sub: 'قراءة' },
                      { level: 25 as HideLevel, label: 'إخفاء 25%', sub: 'مرحلة 1' },
                      { level: 50 as HideLevel, label: 'إخفاء 50%', sub: 'مرحلة 2' },
                      { level: 75 as HideLevel, label: 'إخفاء 75%', sub: 'مرحلة 3' },
                      { level: 100 as HideLevel, label: 'إخفاء 100%', sub: 'تسميع كامل' },
                    ]
                  ).map((item) => (
                    <button
                      key={item.level}
                      type="button"
                      onClick={() => handleSelectHideLevel(item.level)}
                      className={`py-2 px-1.5 rounded-xl font-cairo border transition-all flex flex-col items-center justify-center cursor-pointer ${
                        hideLevel === item.level
                          ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white border-[#5B5FEF] shadow-xs scale-[1.02]'
                          : 'bg-white text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                      }`}
                    >
                      <span className="font-black text-xs">{item.label}</span>
                      <span
                        className={`text-[10px] font-semibold ${
                          hideLevel === item.level ? 'text-amber-100' : 'text-[#77798C]'
                        }`}
                      >
                        {item.sub}
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {/* شريط إحصائيات الكشف وأزرار المساعدة السريعة عند تفعيل الإخفاء */}
              {recitationMode === 'progressive_hide' && hideLevel > 0 && (
                <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs font-bold">
                  <div className="flex items-center gap-2 text-[#4CAF82]">
                    <Hand className="w-4 h-4 text-[#5B5FEF]" />
                    <span>
                      اضغط على أي آية أو كلمة {maskStyle === 'blur' ? 'مموهة' : 'مخفية'} لإظهارها • تم كشف:{' '}
                      {hiddenWordsStats.revealedCount} من {hiddenWordsStats.totalHidden}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {hiddenWordsStats.nextUnrevealedKey && (
                      <button
                        type="button"
                        onClick={handleRevealNextWord}
                        className="px-3 py-1 rounded-xl bg-white hover:bg-[#F7F7FC] text-[#4145C7] border border-[#E6E6F0] text-[11px] font-bold cursor-pointer shadow-2xs"
                      >
                        إظهار الكلمة التالية
                      </button>
                    )}
                    {hiddenWordsStats.remainingHidden > 0 && (
                      <button
                        type="button"
                        onClick={handleRevealAllTemporary}
                        className="px-3 py-1 rounded-xl bg-white hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-[11px] font-bold cursor-pointer"
                      >
                        كشف الكل مؤقتاً
                      </button>
                    )}
                    {hiddenWordsStats.revealedCount > 0 && (
                      <button
                        type="button"
                        onClick={handleRehideAll}
                        className="px-3 py-1 rounded-xl bg-[#25263A] text-white text-[11px] font-bold cursor-pointer"
                      >
                        إعادة الإخفاء للتسميع
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* ── البطاقة الرئيسية لعرض الآيات (مع الإخفاء التدريجي / التمويه / الكشف بالضغط) ── */}
          <div className="bg-white rounded-3xl p-5 sm:p-7 border-2 border-[#E6E6F0] shadow-[0_6px_25px_rgba(201,168,76,0.14)] relative overflow-hidden">
            {/* Top Accent Strip */}
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7]" />

            {/* Ayah Header Indicator + Display Scope Switcher */}
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-xs font-black">
                <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
                <span>
                  {displayScope === 'full_page'
                    ? `آيات الورد اليومي (${startAyah} - ${endAyah}) من سورة ${plan.surahName}`
                    : `الآية ${currentAyah?.numberInSurah || startAyah} من سورة ${plan.surahName}`}
                </span>
              </span>

              {/* نطاق العرض: صفحة الورد كاملة أو آية بآية */}
              <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl border border-[#E6E6F0]">
                <button
                  type="button"
                  onClick={() => setDisplayScope('full_page')}
                  className={`px-2.5 py-1 rounded-lg font-cairo font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer ${
                    displayScope === 'full_page'
                      ? 'bg-white text-[#25263A] shadow-2xs'
                      : 'text-[#77798C] hover:text-[#25263A]'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>صفحة الورد كاملة ({sessionAyahs.length} آيات)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDisplayScope('single_ayah')}
                  className={`px-2.5 py-1 rounded-lg font-cairo font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer ${
                    displayScope === 'single_ayah'
                      ? 'bg-white text-[#25263A] shadow-2xs'
                      : 'text-[#77798C] hover:text-[#25263A]'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>آية بآية</span>
                </button>
              </div>
            </div>

            {recitationMode === 'progressive_hide' ? (
              /* ── وضع إخفاء الآيات تدريجياً (نص مموه أو مخفي) مع الإظهار عند الضغط ── */
              <div className="min-h-[200px] p-4 sm:p-6 bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] text-right leading-[2.7] sm:leading-[3.0]">
                {hideLevel > 0 && (
                  <div className="mb-4 pb-2.5 border-b border-[#E6E6F0] flex items-center justify-between flex-wrap gap-2 text-xs font-cairo">
                    <span className="text-[#4145C7] font-bold flex items-center gap-1.5">
                      <Hand className="w-4 h-4 text-[#5B5FEF]" />
                      <span>
                        {hideUnit === 'ayah'
                          ? 'اضغط على أي كلمة أو على رقم الآية ﴿ ﴾ لإظهار الآية كاملة والتحقق من حفظك'
                          : 'اضغط على أي كلمة مموهة أو مخفية لإظهارها فوراً والتحقق من صحة تسميعك'}
                      </span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] font-black">
                      {maskStyle === 'blur' ? 'نص مموه' : 'نص مخفي'} • {hideLevel}%
                    </span>
                  </div>
                )}

                <div className="font-amiri text-2xl sm:text-3xl text-[#25263A] font-semibold">
                  {displayedAyahs.map(({ ayah, idx }) => {
                    const words = ayah.text.trim().split(/\s+/).filter(Boolean);
                    const isWholeAyahRevealed = revealedAyahNumbers.has(ayah.numberInSurah);

                    return (
                      <React.Fragment key={ayah.numberInSurah}>
                        {words.map((word, wIdx) => {
                          const wordKey = `${ayah.numberInSurah}-${wIdx}`;
                          const shouldHide =
                            hideUnit === 'ayah'
                              ? isAyahWordHiddenAtLevel(
                                  wIdx,
                                  words.length,
                                  idx,
                                  displayedAyahs.length,
                                  hideLevel
                                )
                              : isWordHiddenAtLevel(wIdx, words.length, idx, hideLevel);

                          const isRevealed =
                            isWholeAyahRevealed || revealedWordKeys.has(wordKey);

                          // 1. Word is not hidden at this level
                          if (!shouldHide) {
                            return (
                              <span
                                key={wordKey}
                                className="inline-block mx-1 py-0.5 text-[#25263A] transition-all duration-200"
                              >
                                {word}
                              </span>
                            );
                          }

                          // 2. Word was hidden, and user tapped/clicked to reveal it
                          if (isRevealed) {
                            return (
                              <button
                                key={wordKey}
                                type="button"
                                onClick={() =>
                                  hideUnit === 'ayah'
                                    ? handleToggleAyahReveal(ayah.numberInSurah, words.length)
                                    : handleToggleWordReveal(wordKey)
                                }
                                title="اضغط لإخفاء النص مجدداً"
                                className="inline-block mx-1 px-2 py-0.5 rounded-xl bg-[#4CAF82]/12 border border-[#4CAF82]/40 text-[#4CAF82] font-bold transition-all duration-300 cursor-pointer hover:bg-[#4CAF82]/12"
                              >
                                {word}
                              </button>
                            );
                          }

                          // 3. Word is hidden: render either BLURRED text (نص مموه) or HIDDEN placeholder (نص مخفي)
                          if (maskStyle === 'blur') {
                            return (
                              <button
                                key={wordKey}
                                type="button"
                                onClick={() =>
                                  hideUnit === 'ayah'
                                    ? handleToggleAyahReveal(ayah.numberInSurah, words.length)
                                    : handleToggleWordReveal(wordKey)
                                }
                                title="اضغط لإظهار النص المموه"
                                className="inline-block mx-1 px-2 py-0.5 rounded-xl bg-[#F7F7FC]/90 hover:bg-[#EEEEFF]/60 border border-dashed border-[#5B5FEF]/70 text-[#25263A] transition-all duration-200 cursor-pointer active:scale-95 align-middle"
                              >
                                <span
                                  className="inline-block select-none pointer-events-none"
                                  style={{
                                    filter: 'blur(6px)',
                                    WebkitFilter: 'blur(6px)',
                                    opacity: 0.75,
                                  }}
                                >
                                  {word}
                                </span>
                              </button>
                            );
                          }

                          // 'hidden' style (نص مخفي)
                          const minChars = Math.max(3, Math.min(8, word.length));
                          return (
                            <button
                              key={wordKey}
                              type="button"
                              onClick={() =>
                                hideUnit === 'ayah'
                                  ? handleToggleAyahReveal(ayah.numberInSurah, words.length)
                                  : handleToggleWordReveal(wordKey)
                              }
                              title="اضغط لإظهار الكلمة المخفية"
                              style={{ minWidth: `${minChars * 11 + 18}px` }}
                              className="inline-flex items-center justify-center mx-1 px-2.5 py-0.5 rounded-xl bg-[#EEEEFF] hover:bg-[#EEEEFF]/80 active:scale-95 border-2 border-dashed border-[#5B5FEF] text-[#4145C7] font-cairo text-sm font-bold align-middle transition-all duration-200 cursor-pointer shadow-2xs"
                            >
                              <span className="tracking-widest select-none">••••</span>
                            </button>
                          );
                        })}

                        {/* Ayah End Marker — clicking it in Recitation Mode reveals/hides the whole Ayah */}
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentAyahIndex(idx);
                            if (hideLevel > 0) {
                              handleToggleAyahReveal(ayah.numberInSurah, words.length);
                            }
                          }}
                          className={`inline-flex items-center justify-center px-2 h-8 mx-1.5 text-sm font-bold rounded-full border align-middle cursor-pointer transition-all ${
                            isWholeAyahRevealed && hideLevel > 0
                              ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                              : idx === currentAyahIndex
                              ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                              : 'text-[#5B5FEF] border-[#E6E6F0] hover:bg-[#F7F7FC]'
                          }`}
                          title={
                            hideLevel > 0
                              ? `اضغط لإظهار/إخفاء الآية ${ayah.numberInSurah} كاملة`
                              : `الآية ${ayah.numberInSurah}`
                          }
                        >
                          ﴿{ayah.numberInSurah}﴾
                        </button>
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* ── وضع اختبار التسميع بالكتابة ── */
              <div className="space-y-4 text-right">
                <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="font-cairo font-bold text-xs text-[#25263A]">
                      اكتب{' '}
                      {displayScope === 'single_ayah'
                        ? `الآية (${currentAyah?.numberInSurah || startAyah})`
                        : `آيات الورد (${startAyah} - ${endAyah})`}{' '}
                      من حفظك (بدون الحاجة للتشكيل):
                    </span>
                    <span className="font-cairo font-bold text-xs text-[#4CAF82]">
                      الكلمات المطابقة: {writingEvaluation.correctCount} /{' '}
                      {writingEvaluation.totalWords} ({writingEvaluation.accuracy}%)
                    </span>
                  </div>

                  <textarea
                    rows={displayScope === 'full_page' ? 4 : 3}
                    value={typedRecitation}
                    onChange={(e) => {
                      setTypedRecitation(e.target.value);
                      setHasTestedMemorization(true);
                    }}
                    placeholder="ابدأ بكتابة الآيات الكريمة هنا لاختبار قوة حفظك قبل إتمام الورد..."
                    className="w-full p-3.5 rounded-xl bg-white border-2 border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-amiri text-xl sm:text-2xl text-[#25263A] leading-relaxed"
                  />

                  <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setWritingChecked(true);
                          setHasTestedMemorization(true);
                        }}
                        className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>تحقق من التسميع الكتابي</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setTypedRecitation('');
                          setWritingChecked(false);
                        }}
                        className="px-3 py-2 rounded-xl bg-white hover:bg-stone-100 text-[#25263A] border border-[#E6E6F0] font-cairo font-bold text-xs cursor-pointer"
                      >
                        مسح وإعادة الكتابة
                      </button>
                    </div>

                    <span className="font-cairo text-[11px] text-[#77798C]">
                      يتم التصحيح الفوري مع مراعاة فروق الهمزات والتشكيل تلقائياً
                    </span>
                  </div>
                </div>

                {/* معاينة التصحيح كلمة بكلمة */}
                <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2">
                  <div className="flex items-center justify-between text-xs font-cairo font-bold text-[#25263A]">
                    <span>مقارنة تسميعك بالنص القرآني (اضغط على أي كلمة لكشفها):</span>
                    <span
                      className={
                        writingEvaluation.accuracy >= 80
                          ? 'text-[#4CAF82]'
                          : 'text-[#5B5FEF]'
                      }
                    >
                      الدقة: {writingEvaluation.accuracy}%
                    </span>
                  </div>

                  <div className="font-amiri text-xl sm:text-2xl leading-[2.4] pt-1">
                    {writingEvaluation.results.map((item, idx) => {
                      const wordKey = `write-hint-${idx}`;
                      const isHintRevealed = revealedWordKeys.has(wordKey);

                      if (item.isMatch) {
                        return (
                          <span
                            key={idx}
                            className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/30 font-bold"
                          >
                            {item.origWord}
                          </span>
                        );
                      }

                      if (writingChecked && item.userWord) {
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => handleToggleWordReveal(wordKey)}
                            className="inline-flex items-center gap-1 mx-1 px-2 py-0.5 rounded-lg bg-[#D95C6A]/10 text-[#D95C6A] border border-[#D95C6A]/40 font-bold cursor-pointer"
                            title="اضغط لإظهار الصواب"
                          >
                            <span className="line-through opacity-75">{item.userWord}</span>
                            <span className="text-[#4CAF82]">{item.origWord}</span>
                          </button>
                        );
                      }

                      if (isHintRevealed) {
                        return (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => handleToggleWordReveal(wordKey)}
                            className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#F7F7FC] text-[#4145C7] border border-[#5B5FEF] font-bold cursor-pointer"
                          >
                            {item.origWord}
                          </button>
                        );
                      }

                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleToggleWordReveal(wordKey)}
                          className="inline-block mx-1 px-2.5 py-0.5 rounded-lg bg-[#EEEEFF] hover:bg-[#EEEEFF]/70 text-[#4145C7] border border-dashed border-[#5B5FEF] font-cairo text-xs font-bold cursor-pointer"
                          title="اضغط لكشف هذه الكلمة"
                        >
                          ••••
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Pagination Controls for verses */}
            <div className="flex items-center justify-center gap-3 mt-4">
              <button
                type="button"
                onClick={() => setCurrentAyahIndex((prev) => Math.max(0, prev - 1))}
                disabled={currentAyahIndex === 0}
                className="p-2 rounded-xl border border-[#E6E6F0] text-[#77798C] hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                title="الآية السابقة"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-1.5">
                {sessionAyahs.map((_, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setCurrentAyahIndex(idx)}
                    className={`h-2.5 rounded-full transition-all cursor-pointer ${
                      idx === currentAyahIndex
                        ? 'w-7 bg-[#5B5FEF]'
                        : 'w-2.5 bg-stone-200 hover:bg-[#EEEEFF]0'
                    }`}
                  />
                ))}
              </div>

              <button
                type="button"
                onClick={() =>
                  setCurrentAyahIndex((prev) => Math.min(sessionAyahs.length - 1, prev + 1))
                }
                disabled={currentAyahIndex === sessionAyahs.length - 1}
                className="p-2 rounded-xl border border-[#E6E6F0] text-[#77798C] hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                title="الآية التالية"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            </div>

            {/* Action Bar: استمع | كرر | وضع التسميع (إخفاء تدريجي) */}
            <div className="grid grid-cols-3 gap-2.5 mt-5 pt-4 border-t border-[#E6E6F0]">
              {/* 1. استمع */}
              <button
                type="button"
                id="btn-listen-ayah"
                onClick={togglePlayAudio}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                  isPlaying
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-[#25263A]'
                }`}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4" />
                ) : (
                  <Play className="w-4 h-4 text-[#5B5FEF]" />
                )}
                <span>{isPlaying ? 'إيقاف التلاوة' : 'استمع للآية'}</span>
              </button>

              {/* 2. كرر */}
              <button
                type="button"
                id="btn-repeat-ayah"
                onClick={toggleLoop}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                  isLooping
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-[#25263A]'
                }`}
              >
                <RotateCcw
                  className={`w-4 h-4 ${isLooping ? 'text-white' : 'text-[#5B5FEF]'}`}
                />
                <span>تكرار {isLooping ? '(مفعل)' : ''}</span>
              </button>

              {/* 3. وضع التسميع التدريجي */}
              <button
                type="button"
                id="btn-hide-text"
                onClick={() => {
                  setRecitationMode('progressive_hide');
                  handleStepProgressiveHide();
                }}
                className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                  hideLevel > 0
                    ? 'bg-[#25263A] text-white shadow-xs'
                    : 'bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                }`}
              >
                {hideLevel === 100 ? (
                  <Eye className="w-4 h-4 text-[#5B5FEF]" />
                ) : (
                  <EyeOff className="w-4 h-4 text-[#5B5FEF]" />
                )}
                <span>
                  {hideLevel === 0
                    ? 'وضع التسميع (إخفاء تدريجي)'
                    : hideLevel === 100
                    ? 'إظهار الآيات'
                    : `وضع التسميع (${hideLevel}%)`}
                </span>
              </button>
            </div>
          </div>

          {/* Section: عداد التكرار والتثبيت */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-right w-full sm:w-auto">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-sm font-black text-[#25263A]">تكرار التثبيت والإتقان</span>
                <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] text-xs font-black">
                  {repetitionCount} / {targetRepetitions} تكرارات
                </span>
              </div>
              <p className="text-xs text-[#77798C]">
                كرر الآيات 5 مرات ثم فعّل «وضع التسميع» لاختبار قوة حفظك قبل تأكيد إتمام الورد
              </p>

              {/* Progress bar */}
              <div className="w-full sm:w-64 h-2 rounded-full bg-stone-100 overflow-hidden mt-2">
                <div
                  className="h-full bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] transition-all duration-300"
                  style={{
                    width: `${Math.min(100, (repetitionCount / targetRepetitions) * 100)}%`,
                  }}
                />
              </div>
            </div>

            <button
              type="button"
              id="btn-tasbeeh-repeat"
              onClick={handleTasbeehRepetition}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white font-black text-sm shadow-[0_4px_16px_rgba(201,168,76,0.3)] hover:brightness-105 active:scale-95 transition-all cursor-pointer"
            >
              <span>سبّح للتكرار (+1)</span>
            </button>
          </div>

          {/* ── نافذة تنبيهية اختيارية قبل تأكيد إتمام الورد إن لم يتم تجربة وضع التسميع بعد ── */}
          {showPreCompletePrompt && (
            <div className="bg-gradient-to-br from-[#FFFFFF] to-[#F7F7FC] rounded-2xl p-4 sm:p-5 border-2 border-[#5B5FEF] shadow-md space-y-3 animate-fade-in">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-[#EEEEFF] border border-[#5B5FEF] flex items-center justify-center shrink-0">
                  <EyeOff className="w-4 h-4 text-[#5B5FEF]" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-[#25263A]">
                    هل ترغب في اختبار حفظك عبر «وضع التسميع» قبل تأكيد إتمام الورد؟
                  </h4>
                  <p className="text-xs text-[#77798C] leading-relaxed">
                    يتيح لك «وضع التسميع» إخفاء الآيات تدريجيًا (كنص مموه أو مخفي) وإظهارها عند الضغط عليها للتأكد من ثبات حفظك قبل تسجيل إتمام الورد.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowPreCompletePrompt(false);
                    setRecitationMode('progressive_hide');
                    setMaskStyle('blur');
                    handleSelectHideLevel(50);
                    versesCardRef.current?.scrollIntoView({ behavior: 'smooth' });
                    onShowToast('تم تفعيل «وضع التسميع» (إخفاء 50%) — اضغط على الآيات المموهة لاختبار حفظك');
                  }}
                  className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-xs flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <EyeOff className="w-4 h-4" />
                  <span>تجربة «وضع التسميع» أولاً (إخفاء تدريجي)</span>
                </button>

                <button
                  type="button"
                  onClick={handleConfirmCompleteWird}
                  className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد إتمام الورد مباشرة</span>
                </button>
              </div>
            </div>
          )}

          {/* Bottom Completion Button: "تأكيد إتمام الورد (أتممت الحفظ)" أخضر #5B5FEF */}
          <button
            type="button"
            id="btn-complete-daily"
            onClick={handleAttemptCompleteClick}
            className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-base shadow-[0_6px_20px_rgba(27,94,32,0.25)] active:scale-98 transition-all cursor-pointer"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-200" />
            <span>
              {hasTestedMemorization
                ? 'تأكيد إتمام الورد بعد التسميع ✅'
                : 'أتممت الحفظ — تأكيد إتمام الورد ✅'}
            </span>
          </button>
        </>
      )}
    </div>
  );
};
