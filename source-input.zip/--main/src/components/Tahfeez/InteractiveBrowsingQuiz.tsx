import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  ArrowRight,
  Search,
  Volume2,
  RotateCcw,
  ChevronLeft,
  Settings,
  Download,
  Loader2,
  X,
  BookOpen,
  Keyboard,
  Sparkles,
  Database,
} from 'lucide-react';
import { SURAH_LIST } from '../../data/quranData';
import { soundManager } from '../../utils/audio';
import {
  getAudioAyahUrl,
  loadSelectedTahfeezReciter,
  loadTahfeezStats,
  saveTahfeezStats,
} from '../../utils/tahfeezService';
import {
  QuizDifficultyLevel,
  InteractiveBrowsingQuestion,
  InteractiveQuizMistake,
  InteractiveQuizResultRow,
  InteractiveQuizSettings,
  SqliteTablesStats,
  SQLITE_DDL_SCHEMA,
  ALL_ARABIC_LETTERS,
  normalizeArabicLetterForMatch,
  stripArabicTashkeel,
  initializeInteractiveQuizDatabase,
  getSqliteTablesOverview,
  ensureSurahInQuranTables,
  generateInteractiveBrowsingQuestions,
  downloadFullQuranUthmaniToDb,
  getSyncedSurahIds,
  isFullQuranSyncedOffline,
  saveInteractiveQuizResult,
  loadInteractiveQuizResultsSync,
  loadInteractiveQuizSettings,
  saveInteractiveQuizSettings,
} from '../../utils/interactiveQuranQuizDb';
import {
  InteractiveMushafSvg,
  TrophyMedalSvg,
  CheckMarkSvg,
  CrossMarkSvg,
  HintLampSvg,
  OfflineReadySvg,
  AyahOctagonBadgeSvg,
} from './InteractiveQuizIcons';

interface InteractiveBrowsingQuizProps {
  onBack?: () => void;
  onShowToast?: (msg: string) => void;
  initialSurahId?: number;
  embedded?: boolean;
}

type ScreenStep = 'setup' | 'testing' | 'result';

export const InteractiveBrowsingQuiz: React.FC<InteractiveBrowsingQuizProps> = ({
  onBack,
  onShowToast,
  initialSurahId = 67, // سورة الملك افتراضياً أو آخر سورة
  embedded = false,
}) => {
  // ── الشاشة الحالية: إعداد الاختبار | الاختبار التفاعلي | النتيجة ──
  const [step, setStep] = useState<ScreenStep>('setup');

  // ── إعدادات الاختبار (الشاشة 1) ──
  const [selectedSurahId, setSelectedSurahId] = useState<number>(initialSurahId);
  const [surahSearchQuery, setSurahSearchQuery] = useState<string>('');
  const [isSurahDropdownOpen, setIsSurahDropdownOpen] = useState<boolean>(false);
  const [fromAyah, setFromAyah] = useState<number>(1);
  const [toAyah, setToAyah] = useState<number>(() => {
    const meta = SURAH_LIST.find((s) => s.number === initialSurahId);
    return meta ? Math.min(20, meta.numberOfAyahs) : 20;
  });
  const [questionsCount, setQuestionsCount] = useState<5 | 10 | 15 | 20>(10);
  const [difficulty, setDifficulty] = useState<QuizDifficultyLevel>('easy');

  // ── إعدادات العرض والتفضيلات ──
  const [settings, setSettings] = useState<InteractiveQuizSettings>(loadInteractiveQuizSettings);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);

  // ── حالة المزامنة والعمل Offline ──
  const [syncedSurahs, setSyncedSurahs] = useState<number[]>(getSyncedSurahIds);
  const [fullOfflineReady, setFullOfflineReady] = useState<boolean>(isFullQuranSyncedOffline);
  const [isDownloadingFullQuran, setIsDownloadingFullQuran] = useState<boolean>(false);
  const [downloadProgress, setDownloadProgress] = useState<{ percent: number; label: string }>({
    percent: 0,
    label: '',
  });
  const [isLoadingQuestions, setIsLoadingQuestions] = useState<boolean>(false);
  const [dbStats, setDbStats] = useState<SqliteTablesStats | null>(null);
  const [showSchemaModal, setShowSchemaModal] = useState<boolean>(false);
  const [activeDbInspectorTab, setActiveDbInspectorTab] = useState<
    'quran_words' | 'quiz_questions' | 'ddl'
  >('quran_words');

  // ── حالة جلسة الاختبار التفاعلي (الشاشة 2) ──
  const [questions, setQuestions] = useState<InteractiveBrowsingQuestion[]>([]);
  const [currentQIdx, setCurrentQIdx] = useState<number>(0);
  const [activeSlotIdx, setActiveSlotIdx] = useState<number>(0);
  // slotId -> الحرف المكتمل مع تشكيله
  const [filledSlots, setFilledSlots] = useState<Record<string, string>>({});
  // الحرف الخاطئ المضغوط حالياً لإظهار تنبيه أحمر فوري بدون إعادة تحميل
  const [wrongTappedLetter, setWrongTappedLetter] = useState<string | null>(null);
  const [slotErrorFlash, setSlotErrorFlash] = useState<boolean>(false);
  const [questionCompleted, setQuestionCompleted] = useState<boolean>(false);
  const [useFullKeyboard, setUseFullKeyboard] = useState<boolean>(false);
  const [showWordsInspector, setShowWordsInspector] = useState<boolean>(false);

  // ── الإحصائيات والنتائج للجلسة الحالية ──
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [mistakes, setMistakes] = useState<InteractiveQuizMistake[]>([]);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [savedResultsHistory, setSavedResultsHistory] = useState<InteractiveQuizResultRow[]>(
    loadInteractiveQuizResultsSync
  );

  // ── الصوت للتلاوة الحقيقية للآية ──
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const advanceTimeoutRef = useRef<number | null>(null);

  const selectedSurahMeta = useMemo(
    () => SURAH_LIST.find((s) => s.number === selectedSurahId) || SURAH_LIST[0],
    [selectedSurahId]
  );

  // فلترة السور الـ 114 بالاسم أو الرقم
  const filteredSurahs = useMemo(() => {
    const q = stripArabicTashkeel(surahSearchQuery.trim());
    const rawQ = surahSearchQuery.trim();
    if (!rawQ) return SURAH_LIST;
    return SURAH_LIST.filter((s) => {
      const cleanName = stripArabicTashkeel(s.name);
      return (
        cleanName.includes(q) ||
        s.name.includes(rawQ) ||
        String(s.number) === rawQ ||
        s.englishName.toLowerCase().includes(rawQ.toLowerCase())
      );
    });
  }, [surahSearchQuery]);

  // تهيئة جداول SQLite (quran_words و quiz_questions) تلقائياً عند فتح المكون أو تغيير السورة
  useEffect(() => {
    let mounted = true;
    initializeInteractiveQuizDatabase()
      .then(() => getSqliteTablesOverview(selectedSurahId))
      .then((overview) => {
        if (mounted) {
          setDbStats(overview);
          setSyncedSurahs(getSyncedSurahIds());
          setFullOfflineReady(isFullQuranSyncedOffline());
        }
      })
      .catch((err) => console.warn('Error initializing SQLite tables:', err));
    return () => {
      mounted = false;
    };
  }, [selectedSurahId]);

  // مؤقت الاختبار الفعلي
  useEffect(() => {
    if (step !== 'testing') return;
    const timer = window.setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [step]);

  // تنظيف الصوت والمؤقتات عند الخروج
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      if (advanceTimeoutRef.current) {
        window.clearTimeout(advanceTimeoutRef.current);
      }
    };
  }, []);

  const updateSettings = (patch: Partial<InteractiveQuizSettings>) => {
    const updated = { ...settings, ...patch };
    setSettings(updated);
    saveInteractiveQuizSettings(updated);
  };

  // عند تغيير السورة المختارة، ضبط نطاق الآيات تلقائياً
  const handleSelectSurah = (surahNumber: number) => {
    const meta = SURAH_LIST.find((s) => s.number === surahNumber) || SURAH_LIST[0];
    setSelectedSurahId(surahNumber);
    setFromAyah(1);
    setToAyah(Math.min(20, meta.numberOfAyahs));
    setIsSurahDropdownOpen(false);
    setSurahSearchQuery('');
  };

  // تحميل المصحف الكامل Offline
  const handleDownloadFullQuran = async () => {
    if (isDownloadingFullQuran) return;
    setIsDownloadingFullQuran(true);
    setDownloadProgress({ percent: 2, label: 'جاري بدء التحميل من api.alquran.cloud...' });

    const ok = await downloadFullQuranUthmaniToDb((percent, label) => {
      setDownloadProgress({ percent, label });
    });

    setIsDownloadingFullQuran(false);
    setSyncedSurahs(getSyncedSurahIds());
    setFullOfflineReady(isFullQuranSyncedOffline());

    if (ok) {
      onShowToast?.('تم حفظ المصحف العثماني كاملاً في قاعدة البيانات للعمل بدون إنترنت');
    } else {
      onShowToast?.('تم تفعيل السور المتاحة محلياً، تأكد من الاتصال لتحميل بقية السور');
    }
  };

  // بدء الاختبار الفعلي
  const handleStartQuiz = async (customQuestions?: InteractiveBrowsingQuestion[]) => {
    if (advanceTimeoutRef.current) {
      window.clearTimeout(advanceTimeoutRef.current);
    }
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    }

    setIsLoadingQuestions(true);
    try {
      const safeFrom = Math.max(1, Math.min(fromAyah, toAyah, selectedSurahMeta.numberOfAyahs));
      const safeTo = Math.min(
        selectedSurahMeta.numberOfAyahs,
        Math.max(fromAyah, toAyah, safeFrom)
      );
      setFromAyah(safeFrom);
      setToAyah(safeTo);

      const generated =
        customQuestions && customQuestions.length > 0
          ? customQuestions
          : await generateInteractiveBrowsingQuestions({
              surah_id: selectedSurahId,
              from_ayah: safeFrom,
              to_ayah: safeTo,
              questions_count: questionsCount,
              difficulty,
            });

      setSyncedSurahs(getSyncedSurahIds());

      if (generated.length === 0) {
        onShowToast?.('تعذر تجهيز آيات السورة، يرجى التحقق من نطاق الآيات');
        setIsLoadingQuestions(false);
        return;
      }

      setQuestions(generated);
      setCurrentQIdx(0);
      setActiveSlotIdx(0);
      setFilledSlots({});
      setWrongTappedLetter(null);
      setQuestionCompleted(false);
      setCorrectCount(0);
      setWrongCount(0);
      setMistakes([]);
      setElapsedSeconds(0);
      setStep('testing');
    } catch (e) {
      console.error('Error starting interactive browsing quiz:', e);
      onShowToast?.('حدث خطأ أثناء تحميل آيات الاختبار');
    } finally {
      setIsLoadingQuestions(false);
    }
  };

  const currentQuestion = questions[currentQIdx] || null;
  const currentMissingSlot = currentQuestion?.missingSlots[activeSlotIdx] || null;

  // إنهاء الاختبار وحفظ النتيجة في قاعدة البيانات
  const finalizeQuizSession = useCallback(
    async (finalCorrect: number, finalWrong: number, finalMistakes: InteractiveQuizMistake[]) => {
      const totalAttempts = Math.max(1, finalCorrect + finalWrong);
      const accuracy = Math.round((finalCorrect / totalAttempts) * 100);

      const resultRow: InteractiveQuizResultRow = {
        id: `ibq_${Date.now()}`,
        surah_id: selectedSurahId,
        surah_name: selectedSurahMeta.name,
        from_ayah: fromAyah,
        to_ayah: toAyah,
        questions_count: questions.length,
        difficulty,
        score: finalCorrect,
        correct_answers: finalCorrect,
        wrong_answers: finalWrong,
        accuracy_percent: accuracy,
        elapsed_seconds: elapsedSeconds,
        mistakes: finalMistakes,
        created_at: new Date().toISOString(),
      };

      await saveInteractiveQuizResult(resultRow);
      setSavedResultsHistory(loadInteractiveQuizResultsSync());

      // تحديث إحصائيات التحفيظ العامة للمستخدم
      const stats = loadTahfeezStats();
      saveTahfeezStats({
        ...stats,
        quizzesPassed: (stats.quizzesPassed || 0) + 1,
        totalRepetitions: (stats.totalRepetitions || 0) + questions.length,
      });

      setStep('result');
    },
    [selectedSurahId, selectedSurahMeta.name, fromAyah, toAyah, questions.length, difficulty, elapsedSeconds]
  );

  // الانتقال للسؤال التالي بدون إعادة تحميل الصفحة
  const handleNextQuestion = useCallback(
    (latestCorrect = correctCount, latestWrong = wrongCount, latestMistakes = mistakes) => {
      if (advanceTimeoutRef.current) {
        window.clearTimeout(advanceTimeoutRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
        setIsPlayingAudio(false);
      }

      if (currentQIdx < questions.length - 1) {
        setCurrentQIdx((prev) => prev + 1);
        setActiveSlotIdx(0);
        setFilledSlots({});
        setWrongTappedLetter(null);
        setQuestionCompleted(false);
      } else {
        finalizeQuizSession(latestCorrect, latestWrong, latestMistakes);
      }
    },
    [currentQIdx, questions.length, correctCount, wrongCount, mistakes, finalizeQuizSession]
  );

  // التحقق الفوري عند ضغط المستخدم على حرف من لوحة الحروف
  const handleTapLetterOption = (tappedLetter: string) => {
    if (!currentQuestion || !currentMissingSlot || questionCompleted) return;

    const normalizedTapped = normalizeArabicLetterForMatch(tappedLetter);
    const normalizedTarget = currentMissingSlot.normalizedCorrectLetter;
    const isCorrect =
      tappedLetter === currentMissingSlot.correctBaseLetter ||
      (normalizedTapped.length > 0 && normalizedTapped === normalizedTarget);

    if (isCorrect) {
      if (settings.enableSoundEffects) {
        soundManager.triggerHaptic(35);
      }
      setWrongTappedLetter(null);
      setSlotErrorFlash(false);

      const nextFilled = {
        ...filledSlots,
        [currentMissingSlot.slotId]: currentMissingSlot.originalClusterWithTashkeel,
      };
      setFilledSlots(nextFilled);

      const newCorrect = correctCount + 1;
      setCorrectCount(newCorrect);

      // هل بقي حرف ناقص آخر في نفس الآية؟
      if (activeSlotIdx < currentQuestion.missingSlots.length - 1) {
        setActiveSlotIdx((prev) => prev + 1);
      } else {
        // اكتملت جميع الحروف الناقصة في هذه الآية بنجاح!
        setQuestionCompleted(true);
        if (settings.autoAdvanceQuestion) {
          advanceTimeoutRef.current = window.setTimeout(() => {
            handleNextQuestion(newCorrect, wrongCount, mistakes);
          }, 1100);
        }
      }
    } else {
      // إجابة خاطئة — تحقق حقيقي مقابل النص الأصلي
      if (settings.enableSoundEffects) {
        soundManager.triggerHaptic(60);
      }
      setWrongTappedLetter(tappedLetter);
      setSlotErrorFlash(true);
      window.setTimeout(() => setSlotErrorFlash(false), 550);

      const newWrong = wrongCount + 1;
      setWrongCount(newWrong);

      const targetWord = currentQuestion.words.find(
        (w) => w.word_index === currentMissingSlot.wordIndex
      );

      const mistakeItem: InteractiveQuizMistake = {
        surah_id: currentQuestion.surah_id,
        surah_name: currentQuestion.surah_name,
        ayah_number: currentQuestion.ayah_number,
        word_index: currentMissingSlot.wordIndex,
        word_text: targetWord?.word_text || '',
        word_text_without_tashkeel: targetWord?.word_text_without_tashkeel || '',
        ayah_text: currentQuestion.ayah_text,
        correct_letter: currentMissingSlot.correctBaseLetter,
        selected_wrong_letter: tappedLetter,
        cluster_index: currentMissingSlot.clusterIndex,
      };

      setMistakes((prev) => [...prev, mistakeItem]);
    }
  };

  // تلميح: كشف الحرف الحالي عند طلب المساعدة
  const handleRevealHint = () => {
    if (!currentQuestion || !currentMissingSlot || questionCompleted) return;
    handleTapLetterOption(currentMissingSlot.correctBaseLetter);
  };

  // تشغيل التلاوة الصوتية للآية الحالية
  const handlePlayCurrentAyahAudio = () => {
    if (!currentQuestion) return;
    if (isPlayingAudio && audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
      return;
    }

    const reciterId = loadSelectedTahfeezReciter();
    const url = getAudioAyahUrl(reciterId, currentQuestion.surah_id, currentQuestion.ayah_number);

    if (audioRef.current) {
      audioRef.current.pause();
    }
    const audio = new Audio(url);
    audioRef.current = audio;
    setIsPlayingAudio(true);

    audio.onended = () => setIsPlayingAudio(false);
    audio.onerror = () => {
      setIsPlayingAudio(false);
      onShowToast?.('تعذر تشغيل التلاوة الصوتية حالياً');
    };
    audio.play().catch(() => {
      setIsPlayingAudio(false);
    });
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  const isSelectedSurahOffline = syncedSurahs.includes(selectedSurahId);

  return (
    <div className="space-y-4 select-none text-right font-cairo" dir="rtl">
      {/* ── الشريط العلوي: رجوع + "التصفح التفاعلي" + الإعدادات ── */}
      <div className="flex items-center justify-between bg-white px-4 py-3 rounded-2xl border border-[#E6E6F0] shadow-2xs">
        <div className="flex items-center gap-2">
          {(onBack || step !== 'setup') && (
            <button
              type="button"
              onClick={() => {
                if (step !== 'setup') {
                  if (audioRef.current) audioRef.current.pause();
                  setIsPlayingAudio(false);
                  setStep('setup');
                } else if (onBack) {
                  onBack();
                }
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/60 text-[#25263A] font-bold text-xs transition-colors cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
              <span>{step === 'setup' ? 'رجوع' : 'إعداد الاختبار'}</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <InteractiveMushafSvg size={24} color="#E8B84A" />
          <div className="text-center">
            <h2 className="text-sm sm:text-base font-black text-[#25263A]">التصفح التفاعلي</h2>
            <p className="text-[10px] font-bold text-[#77798C]">
              اختبار إكمال الحروف الناقصة من مصحف المدينة
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsSettingsModalOpen(true)}
          className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] transition-colors cursor-pointer"
          title="إعدادات التصفح التفاعلي"
        >
          <Settings className="w-4 h-4 text-[#5B5FEF]" />
        </button>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          📱 الشاشة 1: إعداد الاختبار (Setup Screen)
         ═══════════════════════════════════════════════════════════════════════ */}
      {step === 'setup' && (
        <div className="space-y-4">
          {/* بطاقة حالة مصدر القرآن وبنية بيانات SQLite (quran_words & quiz_questions) */}
          <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white border border-[#E6E6F0] flex items-center justify-center shrink-0">
                  <OfflineReadySvg
                    size={22}
                    color={fullOfflineReady || isSelectedSurahOffline ? '#4CAF82' : '#E8B84A'}
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black text-[#25263A]">
                      قاعدة بيانات SQLite مهيأة للعمل دون اتصال (Offline)
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/30 text-[10px] font-black">
                      {syncedSurahs.length} / 114 سورة مفهرسة
                    </span>
                  </div>
                  <p className="text-[11px] font-semibold text-[#77798C] mt-0.5">
                    جداول SQLite النشطة: quran_words ({dbStats?.totalWordsRows ?? '...'} كلمة) •
                    quiz_questions ({dbStats?.totalQuizQuestionsRows ?? '...'} سؤال تفاعلي جاهز)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowSchemaModal((prev) => !prev)}
                  className="px-3 py-2 rounded-xl bg-white hover:bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] text-xs font-black flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Database className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>{showSchemaModal ? 'إخفاء بنية الجداول' : 'معاينة جداول SQLite'}</span>
                </button>

                {!fullOfflineReady && (
                  <button
                    type="button"
                    disabled={isDownloadingFullQuran}
                    onClick={handleDownloadFullQuran}
                    className="px-3.5 py-2 rounded-xl bg-white hover:bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] text-xs font-black flex items-center justify-center gap-1.5 shrink-0 cursor-pointer transition-all disabled:opacity-60"
                  >
                    {isDownloadingFullQuran ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-[#5B5FEF]" />
                        <span>{downloadProgress.percent}%</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5 text-[#5B5FEF]" />
                        <span>تحميل المصحف كاملاً Offline</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            {/* إحصائيات سريعة لجدولَي quran_words و quiz_questions للسورة المختارة */}
            {dbStats && (
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#E6E6F0]">
                <div className="bg-white px-3 py-2 rounded-xl border border-[#E6E6F0] text-center">
                  <span className="text-[10px] font-bold text-[#77798C] block">
                    جدول quran_words (سورة {selectedSurahMeta.name})
                  </span>
                  <span className="text-sm font-black text-[#25263A]">
                    {dbStats.surahWordsCount} كلمة مقطعة
                  </span>
                </div>
                <div className="bg-white px-3 py-2 rounded-xl border border-[#E6E6F0] text-center">
                  <span className="text-[10px] font-bold text-[#77798C] block">
                    جدول quiz_questions (سورة {selectedSurahMeta.name})
                  </span>
                  <span className="text-sm font-black text-[#4CAF82]">
                    {dbStats.surahQuestionsCount} سؤال Offline
                  </span>
                </div>
                <div className="bg-white px-3 py-2 rounded-xl border border-[#E6E6F0] text-center">
                  <span className="text-[10px] font-bold text-[#77798C] block">
                    جدول quran_ayahs (سورة {selectedSurahMeta.name})
                  </span>
                  <span className="text-sm font-black text-[#4145C7]">
                    {dbStats.surahAyahsCount} آية عثمانية
                  </span>
                </div>
              </div>
            )}

            {/* مستكشف جداول SQLite التفاعلي (quran_words & quiz_questions & DDL) */}
            {showSchemaModal && dbStats && (
              <div className="bg-white rounded-2xl p-4 border-2 border-[#E6E6F0] space-y-3 mt-2">
                <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-[#E6E6F0]">
                  <div className="flex items-center gap-1.5">
                    {(
                      [
                        { id: 'quran_words', label: `جدول quran_words (${dbStats.surahWordsCount})` },
                        {
                          id: 'quiz_questions',
                          label: `جدول quiz_questions (${dbStats.surahQuestionsCount})`,
                        },
                        { id: 'ddl', label: 'مخطط SQLite (CREATE TABLE)' },
                      ] as const
                    ).map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setActiveDbInspectorTab(t.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                          activeDbInspectorTab === t.id
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]/60'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                  <span className="text-[10px] font-mono font-bold text-[#4CAF82]">
                    SQLite Ready • Offline First
                  </span>
                </div>

                {activeDbInspectorTab === 'quran_words' && (
                  <div className="overflow-x-auto max-h-60">
                    <table className="w-full text-right text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#F7F7FC] text-[#25263A] font-black border-b border-[#E6E6F0]">
                          <th className="p-2">id</th>
                          <th className="p-2">surah_id</th>
                          <th className="p-2">ayah_number</th>
                          <th className="p-2">word_index</th>
                          <th className="p-2">word_text</th>
                          <th className="p-2">word_text_without_tashkeel</th>
                          <th className="p-2">position</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dbStats.sampleWords.map((w) => (
                          <tr
                            key={w.id}
                            className="border-b border-[#E6E6F0] hover:bg-[#F7F7FC]"
                          >
                            <td className="p-2 font-mono text-[11px] text-[#77798C]">{w.id}</td>
                            <td className="p-2 font-bold">{w.surah_id}</td>
                            <td className="p-2 font-bold">{w.ayah_number}</td>
                            <td className="p-2 font-mono">{w.word_index}</td>
                            <td className="p-2 font-amiri text-base font-bold text-[#25263A]">
                              {w.word_text}
                            </td>
                            <td className="p-2 font-bold text-[#4145C7]">
                              {w.word_text_without_tashkeel}
                            </td>
                            <td className="p-2 font-mono">{w.position}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {activeDbInspectorTab === 'quiz_questions' && (
                  <div className="overflow-x-auto max-h-60">
                    <table className="w-full text-right text-xs border-collapse">
                      <thead>
                        <tr className="bg-[#F7F7FC] text-[#25263A] font-black border-b border-[#E6E6F0]">
                          <th className="p-2">id</th>
                          <th className="p-2">ayah</th>
                          <th className="p-2">word_id</th>
                          <th className="p-2">word_text</th>
                          <th className="p-2">masked_word_preview</th>
                          <th className="p-2">difficulty</th>
                          <th className="p-2">الحروف الناقصة والخيارات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dbStats.sampleQuestions.map((q) => (
                          <tr
                            key={q.id}
                            className="border-b border-[#E6E6F0] hover:bg-[#F7F7FC]"
                          >
                            <td className="p-2 font-mono text-[11px] text-[#77798C]">{q.id}</td>
                            <td className="p-2 font-bold">{q.ayah_number}</td>
                            <td className="p-2 font-mono text-[11px]">{q.word_id}</td>
                            <td className="p-2 font-amiri text-base font-bold text-[#25263A]">
                              {q.word_text}
                            </td>
                            <td className="p-2 font-amiri text-base font-bold text-[#5B5FEF]">
                              {q.masked_word_preview}
                            </td>
                            <td className="p-2">
                              <span className="px-2 py-0.5 rounded-full bg-[#F7F7FC] text-[#25263A] text-[10px] font-black">
                                {q.difficulty}
                              </span>
                            </td>
                            <td className="p-2 text-[11px] font-bold text-[#4CAF82]">
                              {q.missing_slots
                                .map(
                                  (s) =>
                                    `الحرف (${s.correctBaseLetter}) ← [${s.options.join('، ')}]`
                                )
                                .join(' | ')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {activeDbInspectorTab === 'ddl' && (
                  <pre
                    dir="ltr"
                    className="p-3 rounded-xl bg-[#1E1E1E] text-amber-100 font-mono text-[11px] overflow-x-auto max-h-60 leading-relaxed text-left"
                  >
                    {SQLITE_DDL_SCHEMA}
                  </pre>
                )}
              </div>
            )}
          </div>

          {isDownloadingFullQuran && (
            <div className="bg-white rounded-2xl p-3.5 border border-[#E6E6F0] space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#25263A]">
                <span>{downloadProgress.label}</span>
                <span className="text-[#5B5FEF] font-black">{downloadProgress.percent}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-[#F7F7FC] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#E8B84A] to-[#4CAF82] transition-all duration-300"
                  style={{ width: `${downloadProgress.percent}%` }}
                />
              </div>
            </div>
          )}

          {/* البطاقة الرئيسية لإعداد الاختبار */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-[#E6E6F0] shadow-xs space-y-5">
            {/* 【1】 اختيار السورة (Dropdown بـ 114 سورة + بحث بالاسم) */}
            <div className="space-y-2">
              <label className="block text-xs sm:text-sm font-black text-[#25263A]">
                1. اختيار السورة (114 سورة):
              </label>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsSurahDropdownOpen((prev) => !prev)}
                  className="w-full flex items-center justify-between px-4 py-3.5 rounded-2xl bg-[#F7F7FC] border-2 border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white font-black text-xs flex items-center justify-center">
                      {selectedSurahMeta.number}
                    </span>
                    <div className="text-right">
                      <span className="font-amiri text-lg font-bold text-[#25263A] block leading-tight">
                        سورة {selectedSurahMeta.name}
                      </span>
                      <span className="text-[11px] font-semibold text-[#77798C]">
                        {selectedSurahMeta.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} •{' '}
                        {selectedSurahMeta.numberOfAyahs} آية • الجزء {selectedSurahMeta.juz} • صفحة{' '}
                        {selectedSurahMeta.page}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isSelectedSurahOffline && (
                      <span className="px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] text-[10px] font-black">
                        محفوظة Offline
                      </span>
                    )}
                    <ChevronLeft
                      className={`w-4 h-4 text-[#5B5FEF] transition-transform ${
                        isSurahDropdownOpen ? '-rotate-90' : ''
                      }`}
                    />
                  </div>
                </button>

                {isSurahDropdownOpen && (
                  <div className="absolute z-40 top-full mt-2 right-0 left-0 bg-white rounded-2xl border-2 border-[#5B5FEF] shadow-xl p-3 space-y-2.5 max-h-80 flex flex-col">
                    {/* حقل البحث بالاسم أو الرقم */}
                    <div className="relative">
                      <Search className="w-4 h-4 text-[#5B5FEF] absolute right-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={surahSearchQuery}
                        onChange={(e) => setSurahSearchQuery(e.target.value)}
                        placeholder="ابحث باسم السورة أو رقمها (1 - 114)..."
                        className="w-full pr-9 pl-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                        autoFocus
                      />
                    </div>

                    {/* قائمة السور الـ 114 */}
                    <div className="overflow-y-auto space-y-1 flex-1 pr-0.5">
                      {filteredSurahs.map((s) => {
                        const isSelected = s.number === selectedSurahId;
                        const isOffline = syncedSurahs.includes(s.number);
                        return (
                          <button
                            key={s.number}
                            type="button"
                            onClick={() => handleSelectSurah(s.number)}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-right transition-colors cursor-pointer ${
                              isSelected
                                ? 'bg-[#5B5FEF] text-white'
                                : 'hover:bg-[#F7F7FC] text-[#25263A]'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span
                                className={`w-6 h-6 rounded-lg text-[11px] font-black flex items-center justify-center ${
                                  isSelected
                                    ? 'bg-white text-[#25263A]'
                                    : 'bg-[#EEEEFF] text-[#4145C7]'
                                }`}
                              >
                                {s.number}
                              </span>
                              <span className="font-amiri text-base font-bold">سورة {s.name}</span>
                            </div>

                            <div className="flex items-center gap-2 text-[11px] font-bold">
                              <span className={isSelected ? 'text-white/90' : 'text-[#77798C]'}>
                                {s.numberOfAyahs} آية
                              </span>
                              {isOffline && (
                                <span
                                  className={`px-1.5 py-0.5 rounded text-[9px] font-black ${
                                    isSelected
                                      ? 'bg-white/20 text-white'
                                      : 'bg-[#4CAF82]/12 text-[#4CAF82]'
                                  }`}
                                >
                                  Offline
                                </span>
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 【2】 نطاق الآيات (من آية → إلى آية) */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs sm:text-sm font-black text-[#25263A]">
                  2. نطاق الآيات (من 1 إلى {selectedSurahMeta.numberOfAyahs}):
                </label>
                <span className="text-xs font-bold text-[#4145C7]">
                  النطاق المختار: {Math.max(1, toAyah - fromAyah + 1)} آية
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]">
                  <span className="text-[11px] font-bold text-[#77798C] block mb-1">من آية:</span>
                  <input
                    type="number"
                    min={1}
                    max={selectedSurahMeta.numberOfAyahs}
                    value={fromAyah}
                    onChange={(e) => {
                      const val = Math.max(
                        1,
                        Math.min(selectedSurahMeta.numberOfAyahs, Number(e.target.value) || 1)
                      );
                      setFromAyah(val);
                      if (val > toAyah) setToAyah(val);
                    }}
                    className="w-full bg-white px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-black text-[#25263A] text-center focus:outline-none focus:border-[#5B5FEF]"
                  />
                </div>

                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]">
                  <span className="text-[11px] font-bold text-[#77798C] block mb-1">إلى آية:</span>
                  <input
                    type="number"
                    min={fromAyah}
                    max={selectedSurahMeta.numberOfAyahs}
                    value={toAyah}
                    onChange={(e) => {
                      const val = Math.max(
                        fromAyah,
                        Math.min(
                          selectedSurahMeta.numberOfAyahs,
                          Number(e.target.value) || selectedSurahMeta.numberOfAyahs
                        )
                      );
                      setToAyah(val);
                    }}
                    className="w-full bg-white px-3 py-2 rounded-xl border border-[#E6E6F0] text-sm font-black text-[#25263A] text-center focus:outline-none focus:border-[#5B5FEF]"
                  />
                </div>
              </div>

              {/* أزرار تحديد سريع للنطاق */}
              <div className="flex items-center gap-1.5 flex-wrap">
                {[
                  {
                    label: `كامل السورة (1 - ${selectedSurahMeta.numberOfAyahs})`,
                    from: 1,
                    to: selectedSurahMeta.numberOfAyahs,
                  },
                  {
                    label: `من 1 إلى ${Math.min(10, selectedSurahMeta.numberOfAyahs)}`,
                    from: 1,
                    to: Math.min(10, selectedSurahMeta.numberOfAyahs),
                  },
                  {
                    label: `من 1 إلى ${Math.min(20, selectedSurahMeta.numberOfAyahs)}`,
                    from: 1,
                    to: Math.min(20, selectedSurahMeta.numberOfAyahs),
                  },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setFromAyah(preset.from);
                      setToAyah(preset.to);
                    }}
                    className={`px-3 py-1 rounded-xl text-[11px] font-bold border transition-all cursor-pointer ${
                      fromAyah === preset.from && toAyah === preset.to
                        ? 'bg-[#EEEEFF] border-[#5B5FEF] text-[#25263A]'
                        : 'bg-[#F7F7FC] border-transparent text-[#77798C] hover:text-[#25263A]'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 【3】 عدد الأسئلة (5 / 10 / 15 / 20) */}
            <div className="space-y-2">
              <label className="block text-xs sm:text-sm font-black text-[#25263A]">
                3. عدد الأسئلة:
              </label>
              <div className="grid grid-cols-4 gap-2.5">
                {([5, 10, 15, 20] as const).map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setQuestionsCount(cnt)}
                    className={`py-3 rounded-2xl border-2 font-black text-sm transition-all cursor-pointer ${
                      questionsCount === cnt
                        ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white border-[#5B5FEF] shadow-xs'
                        : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A] hover:bg-[#F7F7FC]'
                    }`}
                  >
                    {cnt} أسئلة
                  </button>
                ))}
              </div>
            </div>

            {/* 【4】 مستوى الصعوبة */}
            <div className="space-y-2">
              <label className="block text-xs sm:text-sm font-black text-[#25263A]">
                4. مستوى الصعوبة:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {(
                  [
                    {
                      id: 'easy' as QuizDifficultyLevel,
                      title: 'سهل',
                      desc: 'إخفاء حرف واحد من الكلمة (4 خيارات)',
                    },
                    {
                      id: 'medium' as QuizDifficultyLevel,
                      title: 'متوسط',
                      desc: 'إخفاء حرفين من الكلمة أو الآية (6 خيارات)',
                    },
                    {
                      id: 'hard' as QuizDifficultyLevel,
                      title: 'صعب',
                      desc: 'إخفاء 3 حروف من الكلمة أو الآية (8 خيارات)',
                    },
                  ]
                ).map((lvl) => {
                  const active = difficulty === lvl.id;
                  return (
                    <button
                      key={lvl.id}
                      type="button"
                      onClick={() => setDifficulty(lvl.id)}
                      className={`p-3.5 rounded-2xl border-2 text-right transition-all cursor-pointer ${
                        active
                          ? 'bg-[#F7F7FC] border-[#5B5FEF] shadow-xs'
                          : 'bg-white border-[#E6E6F0] hover:border-[#E6E6F0]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-black text-[#25263A]">{lvl.title}</span>
                        <span
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            active ? 'border-[#5B5FEF] bg-[#5B5FEF]' : 'border-stone-300'
                          }`}
                        >
                          {active && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </span>
                      </div>
                      <p className="text-[11px] font-semibold text-[#77798C] leading-relaxed">
                        {lvl.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* زر بدء الاختبار */}
            <button
              type="button"
              disabled={isLoadingQuestions}
              onClick={() => handleStartQuiz()}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white font-black text-sm sm:text-base shadow-[0_6px_20px_rgba(201,168,76,0.35)] hover:brightness-105 active:scale-99 transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-60"
            >
              {isLoadingQuestions ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>جاري تجهيز الكلمات والآيات من مصحف المدينة...</span>
                </>
              ) : (
                <>
                  <InteractiveMushafSvg size={22} color="#FFFFFF" />
                  <span>
                    بدء اختبار التصفح التفاعلي (سورة {selectedSurahMeta.name} • الآيات {fromAyah} -{' '}
                    {toAyah})
                  </span>
                </>
              )}
            </button>
          </div>

          {/* سجل نتائج الاختبارات المحفوظة في قاعدة البيانات */}
          {savedResultsHistory.length > 0 && (
            <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs sm:text-sm font-black text-[#25263A]">
                  سجل نتائجك المحفوظة (SQLite Offline):
                </h3>
                <span className="text-[11px] font-bold text-[#77798C]">
                  {savedResultsHistory.length} اختبار محفوظ
                </span>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {savedResultsHistory.slice(0, 6).map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-[#25263A]">
                          سورة {item.surah_name} (الآيات {item.from_ayah} - {item.to_ayah})
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            item.accuracy_percent >= 80
                              ? 'bg-[#4CAF82]/12 text-[#4CAF82]'
                              : 'bg-[#EEEEFF] text-[#4145C7]'
                          }`}
                        >
                          الدقة {item.accuracy_percent}%
                        </span>
                      </div>
                      <p className="text-[11px] font-semibold text-[#77798C]">
                        صحيح: {item.correct_answers} • خطأ: {item.wrong_answers} • الوقت:{' '}
                        {formatTime(item.elapsed_seconds)}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedSurahId(item.surah_id);
                        setFromAyah(item.from_ayah);
                        setToAyah(item.to_ayah);
                        setDifficulty(item.difficulty);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#4145C7] hover:text-white text-[#25263A] text-[11px] font-black transition-colors cursor-pointer"
                    >
                      اختيار النطاق
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          📱 الشاشة 2: شاشة الاختبار والتصفح التفاعلي (Testing Screen)
         ═══════════════════════════════════════════════════════════════════════ */}
      {step === 'testing' && currentQuestion && (
        <div className="space-y-4">
          {/* شريط معلومات التقدم والنتيجة اللحظية */}
          <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-2xs space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-black text-[#25263A]">
                  سورة {currentQuestion.surah_name} • الآية {currentQuestion.ayah_number}
                </span>
                <span className="px-2.5 py-1 rounded-xl bg-[#F7F7FC] text-[11px] font-bold text-[#77798C]">
                  صفحة {currentQuestion.page_number} • الجزء {currentQuestion.juz_number}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-xs font-black text-[#4CAF82]">
                  <CheckMarkSvg size={16} color="#4CAF82" />
                  <span>{correctCount}</span>
                </div>
                <div className="flex items-center gap-1 text-xs font-black text-[#D95C6A]">
                  <CrossMarkSvg size={16} color="#D95C6A" />
                  <span>{wrongCount}</span>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-[#F7F7FC] text-[#25263A] font-mono text-xs font-bold">
                  {formatTime(elapsedSeconds)}
                </span>
              </div>
            </div>

            {/* شريط تقدم الأسئلة */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] font-bold text-[#77798C]">
                <span>
                  السؤال {currentQIdx + 1} من {questions.length}
                </span>
                <span>
                  الحروف المكتملة في الآية: {Object.keys(filledSlots).length} /{' '}
                  {currentQuestion.missingSlots.length}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-[#F7F7FC] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] transition-all duration-300"
                  style={{
                    width: `${Math.round(((currentQIdx + 1) / questions.length) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* بطاقة مصحف المدينة التفاعلية (عرض الآيات وتقطيع الكلمات والحروف) */}
          <div className="bg-[#F7F7FC] rounded-3xl p-5 sm:p-7 border-2 border-[#5B5FEF] shadow-[0_8px_30px_rgba(201,168,76,0.12)] relative overflow-hidden space-y-4">
            {/* زخرفة رأس الصفحة */}
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0]">
              <span className="text-xs font-black text-[#4145C7]">
                اضغط على الحرف الناقص لإكمال الكلمة القرآنية:
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowWordsInspector((prev) => !prev)}
                  className="px-2.5 py-1 rounded-xl bg-white border border-[#E6E6F0] text-[11px] font-bold text-[#25263A] hover:bg-[#F7F7FC] cursor-pointer"
                >
                  {showWordsInspector ? 'إخفاء تقطيع الكلمات' : 'تقطيع الكلمات'}
                </button>
                <button
                  type="button"
                  onClick={handlePlayCurrentAyahAudio}
                  className={`px-3 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1 border transition-colors cursor-pointer ${
                    isPlayingAudio
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-white text-[#25263A] border-[#E6E6F0] hover:bg-[#F7F7FC]'
                  }`}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>{isPlayingAudio ? 'إيقاف' : 'استماع للآية'}</span>
                </button>
              </div>
            </div>

            {/* سياق الآية السابقة (اختياري لتعزيز التصفح التفاعلي) */}
            {settings.showContextAyahs && currentQuestion.previous_ayah && (
              <div className="font-amiri text-lg sm:text-xl text-[#77798C]/80 leading-[2.2] bg-[#F7F7FC]/50 px-4 py-2.5 rounded-2xl border border-[#E6E6F0]">
                <span>{currentQuestion.previous_ayah.ayah_text}</span>
                <AyahOctagonBadgeSvg number={currentQuestion.previous_ayah.ayah_number} size={26} />
              </div>
            )}

            {/* الآية الحالية محل الاختبار التفاعلي */}
            <div
              className="font-amiri text-[#25263A] leading-[2.75] py-3 text-center"
              style={{ fontSize: `${settings.fontSize}px` }}
            >
              {currentQuestion.words.map((wordRow) => {
                const clusters = currentQuestion.wordClustersMap[wordRow.word_index] || [];
                const wordSlots = currentQuestion.missingSlots.filter(
                  (s) => s.wordIndex === wordRow.word_index
                );

                // إذا لم تكن هذه الكلمة تحتوي على حرف ناقص، تُعرض كاملةً كما في المصحف
                if (wordSlots.length === 0) {
                  return (
                    <span
                      key={wordRow.id}
                      className="inline-block mx-1.5 text-[#25263A] transition-colors"
                    >
                      {settings.showTashkeel
                        ? wordRow.word_text
                        : wordRow.word_text_without_tashkeel}
                    </span>
                  );
                }

                // الكلمة المستهدفة التي تحتوي على حرف (أو حروف) ناقصة
                return (
                  <span
                    key={wordRow.id}
                    className="inline-flex items-baseline mx-1.5 px-2.5 py-0.5 rounded-2xl bg-white border-2 border-[#E6E6F0] shadow-2xs"
                  >
                    {clusters.map((cluster) => {
                      const slot = wordSlots.find(
                        (s) => s.clusterIndex === cluster.clusterIndex
                      );

                      if (!slot) {
                        return (
                          <span key={cluster.clusterIndex} className="text-[#25263A]">
                            {settings.showTashkeel
                              ? cluster.clusterWithTashkeel
                              : cluster.baseLetter}
                          </span>
                        );
                      }

                      const isFilled = Boolean(filledSlots[slot.slotId]);
                      const isCurrentActive =
                        !isFilled && currentMissingSlot?.slotId === slot.slotId;

                      if (isFilled) {
                        return (
                          <span
                            key={cluster.clusterIndex}
                            className="inline-block px-1 mx-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] font-bold border border-[#4CAF82]/40 transition-all"
                          >
                            {settings.showTashkeel
                              ? slot.originalClusterWithTashkeel
                              : slot.correctBaseLetter}
                          </span>
                        );
                      }

                      return (
                        <span
                          key={cluster.clusterIndex}
                          className={`inline-flex items-center justify-center min-w-[34px] h-[38px] px-1.5 mx-1 rounded-xl border-2 font-cairo text-sm font-black align-middle transition-all ${
                            isCurrentActive
                              ? slotErrorFlash
                                ? 'bg-[#D95C6A]/15 border-[#D95C6A] text-[#D95C6A] scale-105'
                                : 'bg-[#EEEEFF] border-[#5B5FEF] text-[#25263A] ring-2 ring-[#5B5FEF]/30'
                              : 'bg-[#F7F7FC] border-dashed border-[#77798C]/50 text-[#77798C]'
                          }`}
                        >
                          ؟
                        </span>
                      );
                    })}
                  </span>
                );
              })}

              <AyahOctagonBadgeSvg number={currentQuestion.ayah_number} size={34} />
            </div>

            {/* سياق الآية التالية */}
            {settings.showContextAyahs && currentQuestion.next_ayah && (
              <div className="font-amiri text-lg sm:text-xl text-[#77798C]/80 leading-[2.2] bg-[#F7F7FC]/50 px-4 py-2.5 rounded-2xl border border-[#E6E6F0]">
                <span>{currentQuestion.next_ayah.ayah_text}</span>
                <AyahOctagonBadgeSvg number={currentQuestion.next_ayah.ayah_number} size={26} />
              </div>
            )}

            {/* معاينة جدول تقطيع الكلمات (quran_words) بدقة 100% */}
            {showWordsInspector && (
              <div className="p-3.5 rounded-2xl bg-white border border-[#E6E6F0] space-y-2">
                <div className="flex items-center justify-between text-[11px] font-black text-[#4145C7]">
                  <span>
                    جدول quran_words للآية ({currentQuestion.words.length} كلمات مقطعة بدقة 100%):
                  </span>
                  <span>surah_id: {currentQuestion.surah_id}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {currentQuestion.words.map((w) => (
                    <div
                      key={w.id}
                      className="px-2.5 py-1 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-center"
                    >
                      <span className="font-amiri text-sm font-bold text-[#25263A] block">
                        {w.word_text}
                      </span>
                      <span className="text-[10px] text-[#77798C] font-mono block">
                        #{w.position}: {w.word_text_without_tashkeel}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* ── لوحة اختيار الحروف الناقصة (تتحقق فوراً بدون إعادة تحميل) ── */}
          <div className="bg-white rounded-3xl p-5 border-2 border-[#E6E6F0] shadow-xs space-y-4">
            {questionCompleted ? (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-[#4CAF82]/12 border border-[#4CAF82]/35">
                <div className="flex items-center gap-2.5">
                  <CheckMarkSvg size={26} color="#4CAF82" />
                  <div>
                    <h4 className="text-sm font-black text-[#4145C7]">
                      أحسنت! اكتملت الحروف الناقصة في الآية الكريمة بنجاح
                    </h4>
                    <p className="font-amiri text-base text-[#25263A] mt-0.5">
                      ﴿{currentQuestion.ayah_text}﴾
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleNextQuestion()}
                  className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs shrink-0 cursor-pointer transition-colors"
                >
                  {currentQIdx < questions.length - 1 ? 'الآية التالية' : 'عرض النتيجة النهائية'}
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-[#25263A]">
                      اختر الحرف الناقص رقم ({activeSlotIdx + 1} من{' '}
                      {currentQuestion.missingSlots.length}):
                    </span>
                    {wrongTappedLetter && (
                      <span className="px-2.5 py-0.5 rounded-lg bg-[#D95C6A]/10 text-[#D95C6A] border border-[#D95C6A]/30 text-[11px] font-black">
                        حرف «{wrongTappedLetter}» غير مطابق للنص الأصلي، حاول مجدداً
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleRevealHint}
                      className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <HintLampSvg size={16} color="#E8B84A" />
                      <span>تلميح بالحرف</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setUseFullKeyboard((prev) => !prev)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 cursor-pointer ${
                        useFullKeyboard
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      <Keyboard className="w-3.5 h-3.5" />
                      <span>{useFullKeyboard ? 'خيارات محددة' : 'كل الحروف'}</span>
                    </button>
                  </div>
                </div>

                {/* أزرار الحروف */}
                {!useFullKeyboard && currentMissingSlot ? (
                  <div className="grid grid-cols-4 sm:grid-cols-4 gap-3">
                    {currentMissingSlot.options.map((letter) => {
                      const isWrongTapped = wrongTappedLetter === letter;
                      return (
                        <button
                          key={letter}
                          type="button"
                          onClick={() => handleTapLetterOption(letter)}
                          className={`py-4 rounded-2xl border-2 font-amiri text-2xl sm:text-3xl font-bold transition-all cursor-pointer active:scale-95 ${
                            isWrongTapped
                              ? 'bg-[#D95C6A] text-white border-[#D95C6A]'
                              : 'bg-[#F7F7FC] hover:bg-[#F7F7FC] border-[#E6E6F0] hover:border-[#5B5FEF] text-[#25263A] shadow-2xs'
                          }`}
                        >
                          {letter}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="grid grid-cols-6 sm:grid-cols-9 gap-2">
                    {ALL_ARABIC_LETTERS.map((letter) => {
                      const isWrongTapped = wrongTappedLetter === letter;
                      return (
                        <button
                          key={letter}
                          type="button"
                          onClick={() => handleTapLetterOption(letter)}
                          className={`py-2.5 rounded-xl border font-amiri text-xl font-bold transition-all cursor-pointer active:scale-95 ${
                            isWrongTapped
                              ? 'bg-[#D95C6A] text-white border-[#D95C6A]'
                              : 'bg-[#F7F7FC] hover:bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A]'
                          }`}
                        >
                          {letter}
                        </button>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          📱 الشاشة 3: شاشة النتيجة ومراجعة الأخطاء (Results Screen)
         ═══════════════════════════════════════════════════════════════════════ */}
      {step === 'result' && (
        <div className="space-y-4">
          <div className="bg-white rounded-3xl p-6 border-2 border-[#5B5FEF] shadow-sm text-center space-y-5">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-[#F7F7FC] border-2 border-[#5B5FEF] flex items-center justify-center">
              <TrophyMedalSvg size={38} color="#E8B84A" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg sm:text-xl font-black text-[#25263A]">
                نتيجة اختبار التصفح التفاعلي
              </h3>
              <p className="text-xs font-bold text-[#77798C]">
                سورة {selectedSurahMeta.name} • الآيات ({fromAyah} - {toAyah}) • تم الحفظ في قاعدة
                البيانات
              </p>
            </div>

            {/* بطاقات الإحصائيات الأربع */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                <span className="text-2xl font-black text-[#5B5FEF] block">
                  {Math.round((correctCount / Math.max(1, correctCount + wrongCount)) * 100)}%
                </span>
                <span className="text-[11px] font-bold text-[#77798C]">نسبة الدقة</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#4CAF82]/12 border border-[#4CAF82]/30">
                <span className="text-2xl font-black text-[#4CAF82] block">{correctCount}</span>
                <span className="text-[11px] font-bold text-[#4145C7]">حروف صحيحة</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#D95C6A]/10 border border-[#D95C6A]/30">
                <span className="text-2xl font-black text-[#D95C6A] block">{wrongCount}</span>
                <span className="text-[11px] font-bold text-[#D95C6A]">محاولات خاطئة</span>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                <span className="text-2xl font-black text-[#25263A] block font-mono">
                  {formatTime(elapsedSeconds)}
                </span>
                <span className="text-[11px] font-bold text-[#77798C]">الوقت الفعلي</span>
              </div>
            </div>

            {/* أزرار الإجراءات بعد النتيجة */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => handleStartQuiz()}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة نفس الاختبار</span>
              </button>

              <button
                type="button"
                onClick={() => setStep('setup')}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] font-black text-xs cursor-pointer"
              >
                اختيار سورة أو نطاق جديد
              </button>
            </div>
          </div>

          {/* مراجعة الأخطاء التفصيلية */}
          {mistakes.length > 0 && (
            <div className="bg-white rounded-3xl p-5 border-2 border-[#D95C6A]/30 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CrossMarkSvg size={20} color="#D95C6A" />
                  <h4 className="text-sm font-black text-[#25263A]">
                    مراجعة الكلمات والحروف التي تحتاج تثبيت ({mistakes.length}):
                  </h4>
                </div>
              </div>

              <div className="space-y-2.5">
                {mistakes.map((m, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className="text-[#4145C7]">
                        سورة {m.surah_name} • الآية {m.ayah_number}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-lg bg-[#D95C6A]/10 text-[#D95C6A]">
                          اخترت: {m.selected_wrong_letter}
                        </span>
                        <span className="px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82]">
                          الصحيح: {m.correct_letter}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
                      <span className="font-amiri text-lg font-bold text-[#25263A]">
                        الكلمة: «{m.word_text}»
                      </span>
                      <span className="font-amiri text-sm text-[#77798C]">﴿{m.ayah_text}﴾</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── نافذة إعدادات التصفح التفاعلي ── */}
      {isSettingsModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-5 border-2 border-[#5B5FEF] shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0]">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#5B5FEF]" />
                <h3 className="text-base font-black text-[#25263A]">إعدادات التصفح التفاعلي</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSettingsModalOpen(false)}
                className="p-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-[#25263A] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              {/* حجم خط القرآن */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-[#25263A]">
                  <span>حجم خط المصحف (Amiri):</span>
                  <span className="text-[#5B5FEF] font-black">{settings.fontSize}px</span>
                </div>
                <input
                  type="range"
                  min={22}
                  max={40}
                  step={2}
                  value={settings.fontSize}
                  onChange={(e) => updateSettings({ fontSize: Number(e.target.value) })}
                  className="w-full accent-[#E8B84A]"
                />
              </div>

              {/* إظهار التشكيل */}
              <label className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] cursor-pointer">
                <span className="text-xs font-black text-[#25263A]">
                  إظهار التشكيل العثماني على الكلمات
                </span>
                <input
                  type="checkbox"
                  checked={settings.showTashkeel}
                  onChange={(e) => updateSettings({ showTashkeel: e.target.checked })}
                  className="w-4 h-4 accent-[#E8B84A]"
                />
              </label>

              {/* إظهار الآية السابقة واللاحقة */}
              <label className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] cursor-pointer">
                <span className="text-xs font-black text-[#25263A]">
                  عرض سياق الآيات (السابقة والتالية في الصفحة)
                </span>
                <input
                  type="checkbox"
                  checked={settings.showContextAyahs}
                  onChange={(e) => updateSettings({ showContextAyahs: e.target.checked })}
                  className="w-4 h-4 accent-[#E8B84A]"
                />
              </label>

              {/* الانتقال التلقائي */}
              <label className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] cursor-pointer">
                <span className="text-xs font-black text-[#25263A]">
                  الانتقال التلقائي للآية التالية بعد الإكمال
                </span>
                <input
                  type="checkbox"
                  checked={settings.autoAdvanceQuestion}
                  onChange={(e) => updateSettings({ autoAdvanceQuestion: e.target.checked })}
                  className="w-4 h-4 accent-[#E8B84A]"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() => setIsSettingsModalOpen(false)}
              className="w-full py-3 rounded-2xl bg-[#5B5FEF] text-white font-black text-xs cursor-pointer"
            >
              حفظ وإغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
