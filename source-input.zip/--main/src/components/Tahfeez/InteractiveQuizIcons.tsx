import React from 'react';

interface SvgIconProps {
  size?: number;
  className?: string;
  color?: string;
}

/**
 * أيقونة «التصفح التفاعلي» — مصحف مفتوح مع حروف مضيئة وإشارة إكمال
 */
export const InteractiveMushafSvg: React.FC<SvgIconProps> = ({
  size = 24,
  className = '',
  color = '#E8B84A',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M12 5.5C10.2 4.3 7.4 3.8 4.5 4.2C3.67 4.31 3 5.02 3 5.86V17.6C3 18.54 3.82 19.26 4.75 19.13C7.45 18.76 10.1 19.2 12 20.5C13.9 19.2 16.55 18.76 19.25 19.13C20.18 19.26 21 18.54 21 17.6V5.86C21 5.02 20.33 4.31 19.5 4.2C16.6 3.8 13.8 4.3 12 5.5Z"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill={color}
      fillOpacity="0.1"
    />
    <path
      d="M12 5.5V20.5"
      stroke={color}
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    {/* Missing letter interactive box on right page */}
    <rect
      x="14.2"
      y="8.2"
      width="4.2"
      height="4.2"
      rx="1.2"
      stroke={color}
      strokeWidth="1.5"
      strokeDasharray="1.5 1.5"
      fill={color}
      fillOpacity="0.18"
    />
    <path
      d="M15.6 10.3L16.2 10.9L17.4 9.6"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* Lines on left page */}
    <path
      d="M5.8 9.2H9.5M5.8 12.2H9.5M5.8 15.2H8.5M14.5 15.2H18.2"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

export const CompleteAyahSvg: React.FC<SvgIconProps> = ({
  size = 20,
  className = '',
  color = 'currentColor',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M16.5 3.5L20.5 7.5L8.5 19.5H4.5V15.5L16.5 3.5Z"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M14 6L18 10"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    <path
      d="M12 20H20"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeDasharray="2.5 2.5"
    />
  </svg>
);

export const ReorderAyahsSvg: React.FC<SvgIconProps> = ({
  size = 20,
  className = '',
  color = 'currentColor',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M10 6H20M10 12H20M10 18H20"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    <rect x="3.5" y="4" width="4" height="4" rx="1" stroke={color} strokeWidth="1.6" />
    <rect x="3.5" y="10" width="4" height="4" rx="1" stroke={color} strokeWidth="1.6" />
    <rect x="3.5" y="16" width="4" height="4" rx="1" stroke={color} strokeWidth="1.6" />
  </svg>
);

export const ChoiceAyahSvg: React.FC<SvgIconProps> = ({
  size = 20,
  className = '',
  color = 'currentColor',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.8" />
    <circle cx="12" cy="12" r="5" stroke={color} strokeWidth="1.6" strokeDasharray="2 2" />
    <circle cx="12" cy="12" r="2" fill={color} />
  </svg>
);

export const TrophyMedalSvg: React.FC<SvgIconProps> = ({
  size = 32,
  className = '',
  color = '#E8B84A',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M8 21H16M12 17V21M7 4H17V9C17 11.7614 14.7614 14 12 14C9.23858 14 7 11.7614 7 9V4Z"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill={color}
      fillOpacity="0.14"
    />
    <path
      d="M7 6H4V8C4 9.65685 5.34315 11 7 11M17 6H20V8C20 9.65685 18.6569 11 17 11"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M12 6.8L12.7 8.2L14.2 8.4L13.1 9.5L13.4 11L12 10.2L10.6 11L10.9 9.5L9.8 8.4L11.3 8.2L12 6.8Z"
      fill={color}
    />
  </svg>
);

export const CheckMarkSvg: React.FC<SvgIconProps> = ({
  size = 18,
  className = '',
  color = '#4CAF82',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <circle cx="12" cy="12" r="9.5" fill={color} fillOpacity="0.14" stroke={color} strokeWidth="1.8" />
    <path
      d="M8 12.3L10.7 15L16.2 9.5"
      stroke={color}
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const CrossMarkSvg: React.FC<SvgIconProps> = ({
  size = 18,
  className = '',
  color = '#D95C6A',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <circle cx="12" cy="12" r="9.5" fill={color} fillOpacity="0.14" stroke={color} strokeWidth="1.8" />
    <path
      d="M9 9L15 15M15 9L9 15"
      stroke={color}
      strokeWidth="2.2"
      strokeLinecap="round"
    />
  </svg>
);

export const HintLampSvg: React.FC<SvgIconProps> = ({
  size = 18,
  className = '',
  color = '#E8B84A',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M9 18H15M10 21H14M12 3C8.68629 3 6 5.68629 6 9C6 11.2208 7.2066 13.1599 9 14.1973V15.5C9 16.0523 9.44772 16.5 10 16.5H14C14.5523 16.5 15 16.0523 15 15.5V14.1973C16.7934 13.1599 18 11.2208 18 9C18 5.68629 15.3137 3 12 3Z"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill={color}
      fillOpacity="0.12"
    />
  </svg>
);

export const OfflineReadySvg: React.FC<SvgIconProps> = ({
  size = 18,
  className = '',
  color = '#4CAF82',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
  >
    <path
      d="M6.5 19H17.5C20 19 21.5 17.2 21.5 15C21.5 13 20 11.3 18 11.1C17.4 7.6 14.4 5 10.8 5C7.1 5 4 7.8 3.6 11.5C2.1 12.1 1.5 13.6 1.5 15.2C1.5 17.3 3.5 19 6.5 19Z"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      fill={color}
      fillOpacity="0.1"
    />
    <path
      d="M9.2 13.2L11.1 15.1L15.2 11"
      stroke={color}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const ArrowUpSvg: React.FC<SvgIconProps> = ({
  size = 16,
  className = '',
  color = 'currentColor',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M18 15L12 9L6 15"
      stroke={color}
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const ArrowDownSvg: React.FC<SvgIconProps> = ({
  size = 16,
  className = '',
  color = 'currentColor',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M6 9L12 15L18 9"
      stroke={color}
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const AyahOctagonBadgeSvg: React.FC<{ number: number; size?: number }> = ({
  number,
  size = 30,
}) => (
  <span
    className="inline-flex items-center justify-center relative mx-1.5 align-middle select-none"
    style={{ width: size, height: size }}
  >
    <svg
      width={size}
      height={size}
      viewBox="0 0 36 36"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="absolute inset-0"
    >
      <path
        d="M18 2L23.5 6.5L30.5 6.5L30.5 13.5L35 19L30.5 24.5L30.5 31.5L23.5 31.5L18 35L12.5 31.5L5.5 31.5L5.5 24.5L1 19L5.5 13.5L5.5 6.5L12.5 6.5L18 2Z"
        fill="#F7F7FC"
        stroke="#5B5FEF"
        strokeWidth="1.8"
      />
      <circle cx="18" cy="18.5" r="11.5" stroke="#E8B84A" strokeWidth="0.9" strokeDasharray="2 1.5" />
    </svg>
    <span className="relative z-10 font-cairo font-black text-[11px] text-[#25263A] leading-none pt-0.5">
      {number}
    </span>
  </span>
);
