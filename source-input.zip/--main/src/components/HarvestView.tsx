import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trophy, 
  Flame, 
  Crown, 
  ChevronRight, 
  ChevronLeft, 
  ArrowRight, 
  Sparkles, 
  Calendar as CalendarIcon, 
  CheckCircle2,
  Lock,
  Check,
  X,
  Award,
  UserCheck
} from 'lucide-react';
import { DailyRecord, ScreenType, UserSettings, DailyPrayerTracker } from '../types';
import { RANKS } from '../data/athkarData';
import { calculateStreaks, calculateTotalLifetimeTasbeeh, getCurrentRank } from '../utils/storage';
import {
  evaluateAchievementBadges,
  AchievementBadgeStatus,
} from '../utils/achievementBadges';
import { HarvestSectionSvg } from './Home/RifqSectionIcons';
import {
  FOCUS_PRAYER_LIST,
  FocusPrayerKey,
  loadPrayerTrackerHistory,
  savePrayerTrackerStatus,
  calculatePrayerJourneyStats,
  loadPrayerFocusSettings,
} from '../utils/prayerFocusService';

interface HarvestViewProps {
  history: Record<string, DailyRecord>;
  todayRecord: DailyRecord;
  settings: UserSettings;
  onNavigate: (screen: ScreenType) => void;
}

export const HarvestView: React.FC<HarvestViewProps> = ({
  history,
  todayRecord,
  settings,
  onNavigate,
}) => {
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(8); // 8 is September (0-indexed)
  const [selectedDayRecord, setSelectedDayRecord] = useState<DailyRecord | null>(null);
  const [prayerHistory, setPrayerHistory] = useState<Record<string, DailyPrayerTracker>>(
    loadPrayerTrackerHistory
  );
  const [focusSettings, setFocusSettings] = useState(loadPrayerFocusSettings);
  const [activePrayerConfirmKey, setActivePrayerConfirmKey] = useState<FocusPrayerKey | null>(null);
  const [badgeFilter, setBadgeFilter] = useState<'all' | 'unlocked' | 'in_progress'>('all');
  const [selectedBadge, setSelectedBadge] = useState<AchievementBadgeStatus | null>(null);

  const { badges, unlockedBadges, sevenDayChallenge } = useMemo(
    () => evaluateAchievementBadges(history),
    [history]
  );

  const filteredBadges = useMemo(() => {
    if (badgeFilter === 'unlocked') return badges.filter((b) => b.isUnlocked);
    if (badgeFilter === 'in_progress') return badges.filter((b) => !b.isUnlocked);
    return badges;
  }, [badges, badgeFilter]);

  useEffect(() => {
    const syncPrayers = () => setPrayerHistory(loadPrayerTrackerHistory());
    const syncFocus = () => setFocusSettings(loadPrayerFocusSettings());
    window.addEventListener('rifq-prayer-tracker-updated', syncPrayers);
    window.addEventListener('rifq-prayer-focus-changed', syncFocus);
    return () => {
      window.removeEventListener('rifq-prayer-tracker-updated', syncPrayers);
      window.removeEventListener('rifq-prayer-focus-changed', syncFocus);
    };
  }, []);

  const prayerJourney = useMemo(
    () => calculatePrayerJourneyStats(prayerHistory, new Date()),
    [prayerHistory]
  );

  const todayDateKey = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
  }, []);

  const handleConfirmPrayerInHarvest = (prayerKey: FocusPrayerKey) => {
    const isAlreadyDone = prayerJourney.todayPrayers[prayerKey];
    if (isAlreadyDone) {
      const next = savePrayerTrackerStatus(todayDateKey, prayerKey, 'none');
      setPrayerHistory(next);
    } else {
      setActivePrayerConfirmKey(prayerKey);
    }
  };

  const totalLifetime = calculateTotalLifetimeTasbeeh(history);
  const { currentStreak, longestStreak } = calculateStreaks(history);
  const { currentRank, nextRank, progressPercent, remainingToNext } = getCurrentRank(totalLifetime);

  const monthNames = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(prev => prev - 1);
    } else {
      setCurrentMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(prev => prev + 1);
    } else {
      setCurrentMonth(prev => prev + 1);
    }
  };

  // Generate calendar days for the currentMonth/Year
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(currentYear, currentMonth, 1).getDay(); // 0 is Sunday, 6 is Saturday
  // In Arab calendar, Saturday (س) is index 0 or Sunday (ح)
  // Let's align week starting Saturday: Saturday(6), Sunday(0), Monday(1), Tuesday(2), Wednesday(3), Thursday(4), Friday(5)
  const satBasedFirstDay = (firstDayOfWeek + 1) % 7;

  const today = new Date();
  const isCurrentMonth = today.getFullYear() === currentYear && today.getMonth() === currentMonth;
  const currentDayNum = today.getDate();

  const dailyGoal = settings.dailyGoal || 100;
  const todayAchieved = todayRecord.totalCount;
  const dailyGoalPercent = Math.min(100, Math.round((todayAchieved / dailyGoal) * 100));

  const weekHeaders = ['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج']; // سبت، أحد، اثنين، ثلاثاء، أربعاء، خميس، جمعة

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6 pb-16 select-none" dir="rtl">
      
      {/* Top Bar: "حساد الأعمال" in Gold with 🏆 */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E6E6F0] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('tasbeeh')}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="الرجوع للرئيسية"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2.5">
            <HarvestSectionSvg size={32} />
            <h2 className="text-xl font-extrabold text-[#5B5FEF] font-tajawal">
              حصاد الأعمال
            </h2>
          </div>
        </div>

        <div className="text-xs bg-[#EEEEFF] text-[#4145C7] font-bold px-3 py-1.5 rounded-full flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>المجموع: {totalLifetime.toLocaleString('ar-EG')}</span>
        </div>
      </div>

      {/* 1. قسم الاستمرارية (Streak Section) */}
      <div className="bg-[#F7F7FC] rounded-2xl p-5 border border-[#E6E6F0] shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#EEEEFF] rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
        
        <div className="grid grid-cols-3 items-center text-center">
          {/* Left: Days current streak in gold */}
          <div className="flex flex-col items-center">
            <span className="text-xs text-[#77798C] font-semibold">أيام الاستمرار</span>
            <span className="text-3xl sm:text-4xl font-black text-[#5B5FEF] mt-1 font-tajawal">
              {currentStreak}
            </span>
            <span className="text-[11px] text-[#77798C]">أيام متتالية</span>
          </div>

          {/* Center: Flame Icon */}
          <div className="flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-orange-400 to-amber-300 p-0.5 shadow-lg flex items-center justify-center animate-pulse">
              <div className="w-full h-full bg-white rounded-full flex items-center justify-center text-3xl">
                🔥
              </div>
            </div>
          </div>

          {/* Right: Longest Streak in green */}
          <div className="flex flex-col items-center">
            <span className="text-xs text-[#77798C] font-semibold">أطول سلسلة</span>
            <span className="text-3xl sm:text-4xl font-black text-[#4CAF82] mt-1 font-tajawal">
              {longestStreak}
            </span>
            <span className="text-[11px] text-[#77798C]">يوماً متواصلاً</span>
          </div>
        </div>
      </div>

      {/* 1.25. نظام مكافآت الإنجاز والشارات الرمزية (Achievement Rewards & 7-Day Badges System) */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-5">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E6E6F0]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-[#E8B84A] flex items-center justify-center shadow-xs shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-[#25263A] font-tajawal">
                  مكافآت الإنجاز والشارات الرمزية
                </h3>
                <span className="text-xs font-bold text-[#5B5FEF]">
                  · {unlockedBadges.length} من {badges.length} شارات
                </span>
              </div>
              <p className="text-xs text-[#77798C] mt-0.5">
                احصل على شارات رمزية عند إكمال 7 أيام متتالية من الأذكار وتُعرض في ملفك الشخصي
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('profile')}
            className="px-3.5 py-2 rounded-xl bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#4145C7] hover:text-white text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-center"
          >
            <UserCheck className="w-4 h-4" />
            <span>عرض الشارات في ملفي الشخصي</span>
          </button>
        </div>

        {/* Featured 7-Day Consecutive Athkar Streak Challenge Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#F7F7FC] via-[#FFFFFF] to-[#EEEEFF]/70 border border-[#5B5FEF]/25 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl border-2 shrink-0 transition-transform ${
                  sevenDayChallenge.isSevenDayBadgeUnlocked
                    ? 'bg-gradient-to-tr from-[#E8B84A]/20 to-amber-100 border-[#E8B84A] shadow-sm'
                    : 'bg-white border-[#E6E6F0]'
                }`}
              >
                🏅
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-sm sm:text-base font-black text-[#25263A]">
                    وسام المواظب السبعي (7 أيام متتالية)
                  </h4>
                  <span className="text-xs font-bold text-[#5B5FEF]">
                    {sevenDayChallenge.isSevenDayBadgeUnlocked
                      ? `· مكتسب ✓ (${sevenDayChallenge.completedSevenDayCycles} أسبوع)`
                      : `· متبقي ${sevenDayChallenge.remainingDaysForNextBadge} أيام`}
                  </span>
                </div>
                <p className="text-xs text-[#77798C] mt-0.5 leading-relaxed">
                  أكمل الأذكار لمدة 7 أيام متتالية دون انقطاع لتحصل على شارة الأسبوع المبارك في ملفك الشخصي.
                </p>
              </div>
            </div>

            <div className="text-right sm:text-left shrink-0">
              <span className="text-xl font-black text-[#5B5FEF] tabular-nums">
                {sevenDayChallenge.daysInCurrentCycle}/7
              </span>
              <span className="block text-[11px] text-[#77798C] font-bold">
                أيام الدورة الحالية
              </span>
            </div>
          </div>

          {/* 7-Day Visual Chain */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2 pt-1">
            {sevenDayChallenge.lastSevenDaysChain.map((step) => (
              <div
                key={step.dayIndex}
                className={`p-2 rounded-xl border text-center flex flex-col items-center justify-center gap-1 transition-all ${
                  step.isCompleted
                    ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white shadow-2xs'
                    : step.isCurrentTarget
                    ? 'bg-white border-[#E8B84A] text-[#25263A] ring-2 ring-[#E8B84A]/30'
                    : 'bg-white/80 border-[#E6E6F0] text-[#77798C]'
                }`}
              >
                <span className="text-[10px] font-bold opacity-90">{step.label}</span>
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                    step.isCompleted
                      ? 'bg-[#E8B84A] text-[#25263A]'
                      : step.isCurrentTarget
                      ? 'bg-[#EEEEFF] text-[#5B5FEF]'
                      : 'bg-[#F7F7FC] text-[#77798C]'
                  }`}
                >
                  {step.isCompleted ? '✓' : step.dayIndex === 7 ? '🏅' : step.dayIndex}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Interactive Filter Tabs for Badges */}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1 p-1 bg-[#F7F7FC] rounded-xl border border-[#E6E6F0]">
            <button
              type="button"
              onClick={() => setBadgeFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                badgeFilter === 'all'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'text-[#77798C] hover:text-[#25263A]'
              }`}
            >
              الكل ({badges.length})
            </button>
            <button
              type="button"
              onClick={() => setBadgeFilter('unlocked')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                badgeFilter === 'unlocked'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'text-[#77798C] hover:text-[#25263A]'
              }`}
            >
              المكتسبة ({unlockedBadges.length})
            </button>
            <button
              type="button"
              onClick={() => setBadgeFilter('in_progress')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                badgeFilter === 'in_progress'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'text-[#77798C] hover:text-[#25263A]'
              }`}
            >
              قيد التقدم ({badges.length - unlockedBadges.length})
            </button>
          </div>

          <span className="text-[11px] text-[#77798C]">
            اضغط على أي شارة لعرض تفاصيل الاستحقاق
          </span>
        </div>

        {/* Badges Grid */}
        {filteredBadges.length === 0 ? (
          <div className="text-center py-6 bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] text-xs text-[#77798C] space-y-1.5">
            <div className="text-2xl">🏅</div>
            <div className="font-bold text-[#25263A]">
              {badgeFilter === 'unlocked'
                ? 'لم تكتسب شارات بعد — واصل الأذكار اليومية لفتح شارتك الأولى!'
                : 'جميع الشارات مكتسبة، بارك الله في همتك!'}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {filteredBadges.map((badge) => (
              <button
                key={badge.id}
                type="button"
                onClick={() => setSelectedBadge(badge)}
                className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between gap-2 relative overflow-hidden ${
                  badge.isUnlocked
                    ? 'bg-gradient-to-b from-white to-[#EEEEFF]/60 border-[#5B5FEF] shadow-2xs hover:-translate-y-0.5'
                    : 'bg-[#F7F7FC]/70 border-[#E6E6F0] opacity-80 hover:opacity-100 hover:border-[#5B5FEF]/40'
                }`}
              >
                <div className="flex items-start justify-between gap-2 w-full">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center text-2xl border shrink-0 ${
                      badge.isUnlocked
                        ? 'bg-white border-[#E8B84A] shadow-2xs'
                        : 'bg-white/70 border-[#E6E6F0] grayscale'
                    }`}
                  >
                    {badge.icon}
                  </div>
                  {badge.isUnlocked ? (
                    <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-[#77798C] shrink-0" />
                  )}
                </div>

                <div className="space-y-0.5 w-full">
                  <div className="text-xs font-black text-[#25263A] line-clamp-1">
                    {badge.title}
                  </div>
                  <div className="text-[10px] text-[#77798C] line-clamp-1">
                    {badge.subtitle}
                  </div>
                </div>

                {/* Progress bar and numeric counter */}
                <div className="w-full space-y-1 pt-1">
                  <div className="flex items-center justify-between text-[10px] font-bold text-[#77798C] tabular-nums">
                    <span>
                      {Math.min(badge.currentValue, badge.targetValue).toLocaleString('ar-EG')} /{' '}
                      {badge.targetValue.toLocaleString('ar-EG')}
                    </span>
                    <span className={badge.isUnlocked ? 'text-[#4CAF82]' : 'text-[#5B5FEF]'}>
                      {badge.progressPercent}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-[#E6E6F0] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        badge.isUnlocked
                          ? 'bg-gradient-to-r from-[#4CAF82] to-[#E8B84A]'
                          : 'bg-[#5B5FEF]'
                      }`}
                      style={{ width: `${badge.progressPercent}%` }}
                    />
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 1.5. قسم رحلتي وحصاد الصلوات الخمس (My Journey & Prayer Preservation Challenge) */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E6E6F0]">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-xl shrink-0">
              🕌
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-[#25263A] font-tajawal">
                  رحلة المحافظة على الصلاة
                </h3>
                <span className="text-xs font-bold text-[#5B5FEF]">
                  · اليوم {prayerJourney.currentJourneyDay}
                </span>
              </div>
              <p className="text-xs text-[#77798C] mt-0.5">
                سجل صلاتك الموحد في حصاد العبادات ورحلتي ({prayerJourney.todayCompletedCount}/5 صلوات اليوم)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap self-start sm:self-center">
            <button
              type="button"
              onClick={() => onNavigate('journey')}
              className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
            >
              <span>🌱 فتح قسم رحلتي</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="px-3.5 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-[#5B5FEF]" />
              <span>
                وضع الصلاة والتركيز ({focusSettings.enabled ? 'مفعّل' : 'إعداد'})
              </span>
            </button>
          </div>
        </div>

        {/* 5 Daily Prayers Row: الفجر ✓ الظهر ✓ العصر ✓ المغرب ✓ العشاء ✓ */}
        <div className="grid grid-cols-5 gap-2">
          {FOCUS_PRAYER_LIST.map((p) => {
            const isDone = prayerJourney.todayPrayers[p.key];
            return (
              <button
                key={p.key}
                type="button"
                onClick={() => handleConfirmPrayerInHarvest(p.key)}
                className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                  isDone
                    ? 'bg-[#4CAF82]/12 border-[#4CAF82] text-[#25263A] shadow-2xs'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#77798C] hover:border-[#5B5FEF]'
                }`}
              >
                <span className="text-lg">{p.icon}</span>
                <span className="text-xs font-black text-[#25263A]">{p.nameAr}</span>
                <span
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-black ${
                    isDone
                      ? 'bg-[#4CAF82] text-white'
                      : 'bg-white border border-gray-300 text-transparent'
                  }`}
                >
                  ✓
                </span>
              </button>
            );
          })}
        </div>

        {/* Inline Confirmation Prompt: «هل أديت صلاة ...؟» [ نعم، صليت ] [ لاحقًا ] */}
        {activePrayerConfirmKey && (
          <div className="p-4 rounded-2xl bg-[#EEEEFF]/70 border border-[#5B5FEF]/40 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fade-in">
            <div className="text-sm font-black text-[#25263A]">
              هل أديت صلاة{' '}
              {FOCUS_PRAYER_LIST.find((p) => p.key === activePrayerConfirmKey)?.nameAr}؟
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  const next = savePrayerTrackerStatus(
                    todayDateKey,
                    activePrayerConfirmKey,
                    'on_time'
                  );
                  setPrayerHistory(next);
                  setActivePrayerConfirmKey(null);
                }}
                className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-[#4CAF82] text-white text-xs font-black flex items-center justify-center gap-1 cursor-pointer"
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>نعم، صليت</span>
              </button>
              <button
                type="button"
                onClick={() => setActivePrayerConfirmKey(null)}
                className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-white text-[#77798C] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
              >
                لاحقًا
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 2. قسم الورد اليومي (Daily Goal Section) */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-3">
        <div className="text-center py-1">
          <p className="text-sm font-semibold text-[#5B5FEF] italic font-amiri">
            « وَاصِلِ الْمَسِيرَ، فَالْأَجْرُ عَظِيمٌ وَالْبَرَكَةُ فِي دَوَامِ الذِّكْرِ »
          </p>
        </div>

        <div className="flex items-center justify-between px-2">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-[#4CAF82]">
              {todayAchieved}
            </span>
            <span className="text-gray-400 text-lg">/</span>
            <span className="text-2xl sm:text-3xl font-black text-[#5B5FEF]">
              {dailyGoal}
            </span>
          </div>
          <span className="text-xs font-bold text-[#77798C] bg-[#F7F7FC] px-3 py-1.5 rounded-full">
            إنجاز اليوم: {dailyGoalPercent}%
          </span>
        </div>

        {/* Horizontal Progress Bar in Gold Gradient */}
        <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-[#E6E6F0]">
          <div
            className="h-full bg-gradient-to-r from-[#5B5FEF] via-[#E8B84A] to-amber-300 rounded-full transition-all duration-300"
            style={{ width: `${dailyGoalPercent}%` }}
          />
        </div>
      </div>

      {/* 3. قسم المرتبة الحالية (Current Rank Section) */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-2xl shadow-inner">
              👑
            </div>
            <div>
              <span className="text-xs text-gray-400 font-medium">المرتبة الحالية:</span>
              <h3 className="text-2xl font-black text-[#5B5FEF] font-tajawal">
                {currentRank.name}
              </h3>
            </div>
          </div>

          <span className="text-xs font-bold bg-[#4CAF82]/12 text-[#4145C7] px-3 py-1 rounded-full border border-[#4CAF82]/40">
            المستوى {currentRank.level} من 8
          </span>
        </div>

        {/* Progress to Next Rank */}
        {nextRank && (
          <div className="space-y-2 bg-[#F7F7FC]/60 p-3.5 rounded-xl border border-[#E6E6F0]">
            <div className="flex justify-between items-center text-xs">
              <span className="text-[#77798C] font-medium">
                باقي <span className="font-bold text-[#4145C7]">{remainingToNext.toLocaleString('ar-EG')}</span> للوصول لمرتبة: <span className="font-bold text-[#5B5FEF]">{nextRank.name}</span>
              </span>
              <span className="font-bold text-[#5B5FEF]">{progressPercent}%</span>
            </div>

            <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-[#E8B84A] rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        {/* Ranks Ladder List (1 to 8) */}
        <div className="pt-2">
          <h4 className="text-xs font-bold text-[#77798C] mb-2">سلّم المراتب والأوسمة:</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {RANKS.map((r) => {
              const isAchieved = totalLifetime >= r.min;
              const isCurrent = currentRank.level === r.level;

              return (
                <div
                  key={r.level}
                  className={`p-2.5 rounded-xl border text-center transition-all ${
                    isCurrent
                      ? 'bg-[#EEEEFF]/90 border-[#5B5FEF] shadow-sm ring-2 ring-[#5B5FEF]/30'
                      : isAchieved
                      ? 'bg-[#4CAF82]/12/70 border-[#4CAF82]/40 text-[#4CAF82]'
                      : 'bg-gray-50/60 border-[#E6E6F0] opacity-60'
                  }`}
                >
                  <div className="text-xl mb-1">{r.badge}</div>
                  <div className="text-xs font-bold truncate">{r.name}</div>
                  <div className="text-[10px] text-[#77798C] mt-0.5">
                    {r.min.toLocaleString('ar-EG')}+
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. قسم التقويم الشهري (Monthly Calendar Section) */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-4">
        {/* Calendar Navigation Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={handleNextMonth}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="الشهر التالي"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-[#5B5FEF]" />
            <h3 className="text-lg font-bold text-[#5B5FEF] font-tajawal">
              {monthNames[currentMonth]} {currentYear}
            </h3>
          </div>

          <button
            onClick={handlePrevMonth}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="الشهر السابق"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        {/* Days of Week Headers */}
        <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs text-[#5B5FEF]">
          {weekHeaders.map((day, idx) => (
            <div key={idx} className="py-1">
              {day}
            </div>
          ))}
        </div>

        {/* Month Grid */}
        <div className="grid grid-cols-7 gap-1 text-center text-sm">
          {/* Empty offset days */}
          {Array.from({ length: satBasedFirstDay }).map((_, idx) => (
            <div key={`empty-${idx}`} className="h-10 sm:h-12" />
          ))}

          {/* Actual days */}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const dayNum = idx + 1;
            const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const record = history[dateStr];
            const hasActivity = record && record.totalCount > 0;
            const isToday = isCurrentMonth && dayNum === currentDayNum;
            const isFuture = isCurrentMonth && dayNum > currentDayNum;

            return (
              <button
                key={dayNum}
                onClick={() => record && setSelectedDayRecord(record)}
                disabled={!hasActivity}
                className={`h-10 sm:h-12 rounded-xl flex flex-col items-center justify-center relative transition-all ${
                  hasActivity
                    ? 'bg-[#5B5FEF] text-white font-bold shadow-xs hover:scale-105 cursor-pointer'
                    : isToday
                    ? 'bg-white text-[#25263A] font-bold border-2 border-[#4CAF82]'
                    : isFuture
                    ? 'text-gray-300 cursor-default'
                    : 'bg-white text-[#25263A] hover:bg-[#F7F7FC] border border-[#E6E6F0]'
                }`}
              >
                <span className="text-sm leading-none">{dayNum}</span>
                {hasActivity && (
                  <span className="text-[9px] opacity-90 mt-0.5 leading-none">
                    {record.totalCount}
                  </span>
                )}
                {isToday && !hasActivity && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#4CAF82] absolute bottom-1" />
                )}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-[#77798C] pt-2 border-t border-[#E6E6F0]">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-md bg-[#5B5FEF]" />
            <span>يوم فيه ذكر</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-md border-2 border-[#4CAF82]" />
            <span>اليوم الحالي</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-md bg-white border border-[#E6E6F0]" />
            <span>يوم فارغ</span>
          </div>
        </div>
      </div>

      {/* Day Details Modal */}
      {selectedDayRecord && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
          onClick={() => setSelectedDayRecord(null)}
        >
          <div 
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] space-y-4 relative text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedDayRecord(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 rounded-full bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto text-2xl">
              📅
            </div>

            <h3 className="text-lg font-bold text-[#25263A]">
              تفاصيل يوم {selectedDayRecord.date}
            </h3>

            <div className="grid grid-cols-2 gap-2 text-center py-2">
              <div className="bg-[#F7F7FC] p-3 rounded-xl">
                <span className="text-xs text-[#77798C] block">إجمالي التسبيحات</span>
                <span className="text-xl font-bold text-[#5B5FEF]">
                  {selectedDayRecord.totalCount}
                </span>
              </div>
              <div className="bg-[#F7F7FC] p-3 rounded-xl">
                <span className="text-xs text-[#77798C] block">الأذكار المكتملة</span>
                <span className="text-xl font-bold text-[#4CAF82]">
                  {selectedDayRecord.completedAthkarCount}
                </span>
              </div>
            </div>

            {/* Dhikr Breakdown */}
            {selectedDayRecord.dhikrCounts && Object.keys(selectedDayRecord.dhikrCounts).length > 0 && (
              <div className="text-right space-y-1.5 border-t border-[#E6E6F0] pt-3 max-h-40 overflow-y-auto">
                <span className="text-xs font-bold text-[#77798C] block">تفصيل الأذكار:</span>
                {Object.entries(selectedDayRecord.dhikrCounts).map(([text, cnt]) => (
                  <div key={text} className="flex justify-between items-center text-xs text-gray-700 bg-gray-50 p-2 rounded-lg">
                    <span className="font-semibold truncate max-w-[180px]">{text}</span>
                    <span className="text-[#4145C7] font-bold">{cnt} مرة</span>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={() => setSelectedDayRecord(null)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-sm shadow-md transition-all"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* Badge Details Modal */}
      {selectedBadge && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
          onClick={() => setSelectedBadge(null)}
        >
          <div
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] space-y-4 relative text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedBadge(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div
              className={`w-20 h-20 rounded-3xl mx-auto flex items-center justify-center text-4xl border-2 shadow-sm ${
                selectedBadge.isUnlocked
                  ? 'bg-gradient-to-tr from-[#EEEEFF] to-amber-50 border-[#E8B84A]'
                  : 'bg-[#F7F7FC] border-[#E6E6F0] grayscale'
              }`}
            >
              {selectedBadge.icon}
            </div>

            <div className="space-y-1">
              <div className="text-xs font-bold text-[#5B5FEF]">
                {selectedBadge.isUnlocked ? 'شارة مكتسبة في ملفك الشخصي ✓' : 'شارة قيد التقدم'}
              </div>
              <h3 className="text-lg font-black text-[#25263A]">
                {selectedBadge.title}
              </h3>
              <p className="text-xs text-[#77798C] leading-relaxed">
                {selectedBadge.description}
              </p>
            </div>

            <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0] space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-[#77798C]">التقدم الحالي:</span>
                <span className="text-[#25263A] tabular-nums">
                  {selectedBadge.currentValue.toLocaleString('ar-EG')} /{' '}
                  {selectedBadge.targetValue.toLocaleString('ar-EG')} {selectedBadge.unitLabel}
                </span>
              </div>
              <div className="w-full h-2 bg-[#E6E6F0] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#5B5FEF] to-[#E8B84A] rounded-full transition-all"
                  style={{ width: `${selectedBadge.progressPercent}%` }}
                />
              </div>
              {selectedBadge.unlockedAt && (
                <div className="text-[11px] text-[#4CAF82] font-bold pt-1">
                  تاريخ الاكتساب: {selectedBadge.unlockedAt}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setSelectedBadge(null);
                  onNavigate('profile');
                }}
                className="flex-1 py-2.5 rounded-xl bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] font-bold text-xs transition-colors cursor-pointer"
              >
                عرض في الملف الشخصي
              </button>
              <button
                type="button"
                onClick={() => setSelectedBadge(null)}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
