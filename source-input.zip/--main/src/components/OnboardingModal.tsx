import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Sparkles } from 'lucide-react';

interface OnboardingModalProps {
  onComplete: () => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({ onComplete }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      icon: '📿',
      title: 'تتبع أذكارك اليومية',
      description: 'سجل تسبيحاتك وأذكارك اليومية بسهولة مع عدادات ذكية وحفظ تلقائي وفوري للتقدم.',
      accent: 'from-emerald-600 to-green-800',
    },
    {
      icon: '🔥',
      title: 'حافظ على استمراريتك',
      description: 'التزم بالذكر يومياً وابنِ سلسلة مباركة من المواظبة لترتقي في مراتب الذاكرين.',
      accent: 'from-amber-500 to-orange-600',
    },
    {
      icon: '📊',
      title: 'إحصائيات متقدمة',
      description: 'تابع تقدمك من خلال رسوم بيانية وتقارير مفصلة لكل ساعة ويوم وشهر بالكامل.',
      accent: 'from-blue-600 to-indigo-800',
    },
    {
      icon: '⭐',
      title: 'ابدأ رحلتك الآن',
      description: 'انطلق في رياض الذكر والاستغفار واجعل لسانك رطباً دائماً بذكر الله جل جلاله.',
      accent: 'from-amber-400 to-[#E8B84A]',
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(prev => prev - 1);
    }
  };

  const slide = slides[currentSlide];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md" dir="rtl">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col border border-[#E6E6F0] animate-fade-in">
        
        {/* Top Bar with Skip */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-[#4CAF82] font-semibold bg-[#4CAF82]/12 px-2.5 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>مرحباً بك</span>
          </div>

          {currentSlide < slides.length - 1 ? (
            <button
              onClick={onComplete}
              className="text-sm font-semibold text-gray-400 hover:text-[#25263A] transition-colors px-2 py-1"
            >
              تخطي
            </button>
          ) : (
            <div className="w-10" />
          )}
        </div>

        {/* Slide Content */}
        <div className="px-6 py-6 flex flex-col items-center text-center">
          {/* Icon Badge */}
          <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-[#F7F7FC] to-white border-4 border-[#E6E6F0] flex items-center justify-center shadow-lg mb-6 transform hover:scale-105 transition-transform">
            <span className="text-5xl">{slide.icon}</span>
          </div>

          <h3 className="text-2xl font-bold text-[#25263A] mb-3 font-tajawal">
            {slide.title}
          </h3>

          <p className="text-sm text-[#77798C] leading-relaxed max-w-xs mb-8 min-h-[55px]">
            {slide.description}
          </p>

          {/* Dots Indicator */}
          <div className="flex items-center justify-center gap-2 mb-4">
            {slides.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                aria-label={`الانتقال للشريحة ${idx + 1}`}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  idx === currentSlide
                    ? 'w-8 bg-[#5B5FEF]'
                    : 'w-2.5 bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="p-5 bg-[#F7F7FC] border-t border-[#E6E6F0] flex items-center justify-between gap-3">
          {currentSlide > 0 ? (
            <button
              onClick={handlePrev}
              className="px-4 py-2.5 rounded-xl border border-gray-300 text-[#77798C] hover:bg-white text-sm font-medium transition-colors flex items-center gap-1.5"
            >
              <ArrowRight className="w-4 h-4" />
              <span>السابق</span>
            </button>
          ) : (
            <div />
          )}

          {currentSlide < slides.length - 1 ? (
            <button
              onClick={handleNext}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-2"
            >
              <span>التالي</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onComplete}
              className="w-full py-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-extrabold text-base shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 animate-bounce"
            >
              <Sparkles className="w-5 h-5" />
              <span>ابدأ الرحلة الآن</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
