import React, { useState, useEffect } from 'react';
import { Sparkles, Clock, Flame, Plus, Play, Dices, MapPin, ChevronLeft } from 'lucide-react';
import { WidgetSize, WidgetTheme, PrayerKey, PrayerSettings } from '../../types';
import { WIDGET_THEMES } from '../../utils/widgetThemes';
import { getTodayRecord, recordTasbeehCount, calculateStreaks, calculateTotalLifetimeTasbeeh, loadSettings, loadHistory } from '../../utils/storage';
import { calculateAllPrayerData, CalculatedPrayerData, formatPrayerTime, formatRemainingTime } from '../../utils/prayerCalculator';
import { getCurrentCity, getPrayerSettings } from '../../utils/prayerScheduler';
import { EXPLORER_ATHKAR } from '../../data/athkarData';
import { soundManager } from '../../utils/audio';
import { WidgetTargetPrayer, WidgetStatsMode } from '../../utils/widgetService';

interface MultiWidgetProps {
  size?: WidgetSize;
  theme?: WidgetTheme;
  targetPrayer?: WidgetTargetPrayer;
  statsMode?: WidgetStatsMode;
  customDhikr?: string;
  interactive?: boolean;
  onOpenApp?: () => void;
  onNavigateScreen?: (screen: any) => void;
  className?: string;
}

export const MultiWidget: React.FC<MultiWidgetProps> = ({
  size = 'large',
  theme = 'navy',
  targetPrayer = 'next',
  statsMode = 'today_count',
  customDhikr,
  interactive = true,
  onOpenApp,
  onNavigateScreen,
  className = '',
}) => {
  const [todayRecord, setTodayRecord] = useState(() => getTodayRecord(loadHistory()));
  const [streak, setStreak] = useState(0);
  const [lifetimeTotal, setLifetimeTotal] = useState(0);
  const [prayerData, setPrayerData] = useState<CalculatedPrayerData | null>(null);
  const [displayedPrayerKey, setDisplayedPrayerKey] = useState<PrayerKey>('fajr');
  const [displayedPrayerTime, setDisplayedPrayerTime] = useState<Date>(new Date());
  const [remainingCountdown, setRemainingCountdown] = useState<string>('--:--');
  const [dhikrIndex, setDhikrIndex] = useState(0);
  const [manualDhikrCycled, setManualDhikrCycled] = useState(false);
  const [cityName, setCityName] = useState('القاهرة');

  const styles = WIDGET_THEMES[theme];

  useEffect(() => {
    setManualDhikrCycled(false);
  }, [customDhikr]);

  useEffect(() => {
    const update = () => {
      const hist = loadHistory();
      setTodayRecord(getTodayRecord(hist));
      setStreak(calculateStreaks(hist).currentStreak);
      setLifetimeTotal(calculateTotalLifetimeTasbeeh(hist));

      const city = getCurrentCity();
      const prayerSettings = getPrayerSettings();
      setCityName(city.nameAr || 'القاهرة');

      const now = new Date();
      const calc = calculateAllPrayerData(city.latitude, city.longitude, now, prayerSettings);
      setPrayerData(calc);

      let activeKey: PrayerKey = calc.nextPrayer;
      let activeTime: Date = calc.nextPrayerTime;
      if (targetPrayer && targetPrayer !== 'next') {
        activeKey = targetPrayer as PrayerKey;
        const todayTarget = calc.times[activeKey];
        if (todayTarget && todayTarget.getTime() > now.getTime()) {
          activeTime = todayTarget;
        } else {
          const tomorrow = new Date(now);
          tomorrow.setDate(tomorrow.getDate() + 1);
          const tomorrowCalc = calculateAllPrayerData(city.latitude, city.longitude, tomorrow, prayerSettings);
          activeTime = tomorrowCalc.times[activeKey] || todayTarget;
        }
      }
      setDisplayedPrayerKey(activeKey);
      setDisplayedPrayerTime(activeTime);

      const diff = activeTime.getTime() - now.getTime();
      const formatted = formatRemainingTime(diff);
      const padZero = (n: number) => n.toString().padStart(2, '0');
      setRemainingCountdown(`${padZero(formatted.hours)}:${padZero(formatted.minutes)}:${padZero(formatted.seconds)}`);
    };

    update();
    const interval = setInterval(update, 1000);
    window.addEventListener('storage', update);
    window.addEventListener('rifq-user-data-synced', update);
    window.addEventListener('rifq-local-data-mutated', update);
    window.addEventListener('rifq-widget-increments-merged', update);
    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', update);
      window.removeEventListener('rifq-user-data-synced', update);
      window.removeEventListener('rifq-local-data-mutated', update);
      window.removeEventListener('rifq-widget-increments-merged', update);
    };
  }, [targetPrayer]);

  const handleIncrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactive) return;
    soundManager.playBeadClick(0.6, 'wooden_bead');
    soundManager.triggerHaptic(20);
    const settings = loadSettings();
    const res = recordTasbeehCount(customDhikr || settings.rosaryDhikr || 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', 1);
    setTodayRecord(res.todayRecord);
  };

  const handleNextDhikr = (e: React.MouseEvent) => {
    e.stopPropagation();
    setManualDhikrCycled(true);
    soundManager.triggerHaptic(10);
    setDhikrIndex((prev) => (prev + 1) % EXPLORER_ATHKAR.length);
  };

  const nextPrayerName = prayerData ? (
    displayedPrayerKey === 'fajr' ? 'الفجر' :
    displayedPrayerKey === 'sunrise' ? 'الشروق' :
    displayedPrayerKey === 'dhuhr' ? 'الظهر' :
    displayedPrayerKey === 'asr' ? 'العصر' :
    displayedPrayerKey === 'maghrib' ? 'المغرب' : 'العشاء'
  ) : '...';

  const nextPrayerTimeStr = prayerData ? formatPrayerTime(displayedPrayerTime, '12h') : '--:--';
  const dhikrTextToDisplay =
    !manualDhikrCycled && customDhikr && customDhikr.trim().length > 0
      ? customDhikr.trim()
      : (EXPLORER_ATHKAR[dhikrIndex] || EXPLORER_ATHKAR[0]).text;

  const primaryStatLabel =
    statsMode === 'streak'
      ? 'سلسلة المواظبة:'
      : statsMode === 'lifetime'
      ? 'حصاد التسبيح:'
      : statsMode === 'completed_athkar'
      ? 'إنجاز الأوراد:'
      : 'تسبيح اليوم:';

  const primaryStatNumber =
    statsMode === 'streak'
      ? streak
      : statsMode === 'lifetime'
      ? lifetimeTotal
      : statsMode === 'completed_athkar'
      ? todayRecord.completedAthkarCount || 0
      : todayRecord.totalCount || 0;

  const primaryStatSub =
    statsMode === 'today_count'
      ? `هدف اليوم: ${loadSettings().dailyGoal || 100}`
      : `تسبيح اليوم: ${(todayRecord.totalCount || 0).toLocaleString('ar-EG')}`;

  return (
    <div
      onClick={onOpenApp}
      dir="rtl"
      style={styles.containerStyle}
      className={`relative w-full rounded-3xl p-5 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
    >
      {/* Top Bar */}
      <div className={`flex items-center justify-between z-10 pb-3 border-b ${styles.divider}`}>
        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-0.5 rounded-full text-xs font-black flex items-center gap-1.5 ${styles.badge} ${styles.badgeText}`}>
            <Sparkles className="w-3.5 h-3.5" />
            <span>ويدجت «رِفْق» الشامل</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs font-bold">
          <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full font-black ${styles.highlightBadge}`}>
            <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>{streak} أيام</span>
          </span>
          <span className={`text-[11px] font-bold ${styles.secondaryText}`}>
            {cityName}
          </span>
        </div>
      </div>

      {/* 2-Column Split: Tasbeeh & Next Prayer */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-3 z-10">
        {/* Box 1: Tasbeeh Counter */}
        <div className={`p-3.5 rounded-2xl flex items-center justify-between ${styles.subCard}`}>
          <div>
            <span className={`text-[10px] font-bold block ${styles.secondaryText}`}>
              {primaryStatLabel}
            </span>
            <div className={`text-2xl font-black font-tajawal ${styles.primaryText}`}>
              {primaryStatNumber.toLocaleString('ar-EG')}
            </div>
            <span className={`text-[10px] font-black ${styles.accentText}`}>
              {primaryStatSub}
            </span>
          </div>

          <button
            type="button"
            onClick={handleIncrement}
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-black transition-transform active:scale-90 cursor-pointer shadow-md ${styles.button}`}
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>

        {/* Box 2: Next Prayer */}
        <div className={`p-3.5 rounded-2xl flex items-center justify-between ${styles.subCard}`}>
          <div>
            <span className={`text-[10px] font-bold block ${styles.secondaryText}`}>
              {targetPrayer && targetPrayer !== 'next' ? 'موعد الصلاة المختارة:' : 'الصلاة القادمة:'}
            </span>
            <div className={`text-lg font-black font-tajawal ${styles.accentText}`}>
              صلاة {nextPrayerName}
            </div>
            <span className={`text-xs font-bold ${styles.primaryText}`}>
              {nextPrayerTimeStr}
            </span>
          </div>

          <div className={`text-left font-mono text-xs font-black px-2.5 py-1.5 rounded-xl ${styles.highlightBadge}`}>
            <span className={`block text-[8px] text-right font-sans ${styles.secondaryText}`}>المتبقي</span>
            {remainingCountdown}
          </div>
        </div>
      </div>

      {/* Bottom Box: Daily Dhikr Quote */}
      <div className={`p-3 rounded-2xl z-10 flex items-center justify-between gap-2 ${styles.subCard}`}>
        <div className="truncate">
          <span className={`text-[9px] font-bold block ${styles.secondaryText}`}>
            ذكر مبارك:
          </span>
          <p className={`font-amiri text-sm font-bold truncate ${styles.primaryText}`}>
            «{dhikrTextToDisplay}»
          </p>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={handleNextDhikr}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer shrink-0 ${styles.subtleButton}`}
            title="تغيير الذكر"
          >
            <Dices className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
