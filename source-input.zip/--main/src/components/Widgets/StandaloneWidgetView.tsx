import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, ExternalLink } from 'lucide-react';
import { WidgetType, WidgetTheme, WidgetSize } from '../../types';
import { TasbeehWidget } from './TasbeehWidget';
import { PrayerWidget } from './PrayerWidget';
import { DhikrWidget } from './DhikrWidget';
import { MultiWidget } from './MultiWidget';

interface StandaloneWidgetViewProps {
  widgetType: WidgetType;
  theme?: WidgetTheme;
  size?: WidgetSize;
  onOpenFullApp: () => void;
}

export const StandaloneWidgetView: React.FC<StandaloneWidgetViewProps> = ({
  widgetType,
  theme = 'navy',
  size = 'medium',
  onOpenFullApp,
}) => {
  return (
    <div className="min-h-screen w-full bg-[#0F172A] flex flex-col items-center justify-center p-4 selection:bg-amber-400 selection:text-black">
      {/* Background Ambient Aura */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#4145C7]/40 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 translate-y-1/2 w-96 h-96 bg-[#EEEEFF] rounded-full blur-3xl" />
      </div>

      {/* Widget Container */}
      <div className="w-full max-w-md z-10 space-y-4">
        {widgetType === 'tasbeeh' && (
          <TasbeehWidget size={size} theme={theme} onOpenApp={onOpenFullApp} />
        )}
        {widgetType === 'prayer' && (
          <PrayerWidget size={size} theme={theme} onOpenApp={onOpenFullApp} />
        )}
        {widgetType === 'dhikr' && (
          <DhikrWidget size={size} theme={theme} onOpenApp={onOpenFullApp} />
        )}
        {widgetType === 'multi' && (
          <MultiWidget size={size} theme={theme} onOpenApp={onOpenFullApp} />
        )}

        {/* Discrete Footer Link to Open Full App */}
        <div className="flex items-center justify-between px-2 text-xs font-bold text-stone-400" dir="rtl">
          <button
            type="button"
            onClick={onOpenFullApp}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-stone-200 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>فتح تطبيق رِفْق | RIFQ الكامل</span>
          </button>

          <span className="text-[10px] text-[#77798C] font-mono">
            widget mode
          </span>
        </div>
      </div>
    </div>
  );
};
