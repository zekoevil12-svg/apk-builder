import React, { useState, useEffect } from 'react';
import { Sparkles, Flame, Plus, Check } from 'lucide-react';
import { WidgetSize, WidgetTheme } from '../../types';
import { WIDGET_THEMES } from '../../utils/widgetThemes';
import { getTodayRecord, recordTasbeehCount, calculateStreaks, calculateTotalLifetimeTasbeeh, loadSettings, loadHistory } from '../../utils/storage';
import { soundManager } from '../../utils/audio';
import { WidgetStatsMode } from '../../utils/widgetService';

interface TasbeehWidgetProps {
  size?: WidgetSize;
  theme?: WidgetTheme;
  customDhikr?: string;
  statsMode?: WidgetStatsMode;
  interactive?: boolean;
  onOpenApp?: () => void;
  className?: string;
  onCountIncremented?: (count: number) => void;
}

export const TasbeehWidget: React.FC<TasbeehWidgetProps> = ({
  size = 'medium',
  theme = 'navy',
  customDhikr,
  statsMode = 'today_count',
  interactive = true,
  onOpenApp,
  className = '',
  onCountIncremented,
}) => {
  const [todayRecord, setTodayRecord] = useState(() => getTodayRecord(loadHistory()));
  const [streak, setStreak] = useState(0);
  const [lifetimeTotal, setLifetimeTotal] = useState(0);
  const [activeDhikr, setActiveDhikr] = useState(customDhikr || 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ');
  const [isBumping, setIsBumping] = useState(false);
  const [dailyGoal, setDailyGoal] = useState(100);

  const styles = WIDGET_THEMES[theme];

  const refreshData = () => {
    const hist = loadHistory();
    const rec = getTodayRecord(hist);
    setTodayRecord(rec);
    const s = calculateStreaks(hist);
    setStreak(s.currentStreak);
    setLifetimeTotal(calculateTotalLifetimeTasbeeh(hist));
    const settings = loadSettings();
    if (settings.dailyGoal) setDailyGoal(settings.dailyGoal);
    if (customDhikr) {
      setActiveDhikr(customDhikr);
    } else if (settings.rosaryDhikr) {
      setActiveDhikr(settings.rosaryDhikr);
    }
  };

  useEffect(() => {
    refreshData();
    const handleStorage = () => refreshData();
    window.addEventListener('storage', handleStorage);
    window.addEventListener('rifq-user-data-synced', handleStorage);
    window.addEventListener('rifq-local-data-mutated', handleStorage);
    window.addEventListener('rifq-widget-increments-merged', handleStorage);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('rifq-user-data-synced', handleStorage);
      window.removeEventListener('rifq-local-data-mutated', handleStorage);
      window.removeEventListener('rifq-widget-increments-merged', handleStorage);
    };
  }, [customDhikr]);

  const count = todayRecord.totalCount || 0;
  const completedAthkar = todayRecord.completedAthkarCount || 0;
  const progressPercent = Math.min(100, Math.round((count / Math.max(1, dailyGoal)) * 100));

  const primaryStatValue =
    statsMode === 'streak'
      ? streak
      : statsMode === 'lifetime'
      ? lifetimeTotal
      : statsMode === 'completed_athkar'
      ? completedAthkar
      : count;

  const badgeTitle =
    statsMode === 'streak'
      ? 'سلسلة المواظبة اليومية'
      : statsMode === 'lifetime'
      ? 'إجمالي حصاد التسبيح'
      : statsMode === 'completed_athkar'
      ? 'إنجاز الأوراد اليومي'
      : 'عداد التسبيح اليومي';

  const subtitleLabel =
    statsMode === 'streak'
      ? `يوم متتالي • اليوم: ${count.toLocaleString('ar-EG')}`
      : statsMode === 'lifetime'
      ? `إجمالي الكل • اليوم: ${count.toLocaleString('ar-EG')}`
      : statsMode === 'completed_athkar'
      ? `أذكار مكتملة • التسبيح: ${count.toLocaleString('ar-EG')}`
      : `الهدف: ${dailyGoal.toLocaleString('ar-EG')}`;

  const handleIncrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactive) return;

    soundManager.playBeadClick(0.6, 'wooden_bead');
    soundManager.triggerHaptic(20);

    const res = recordTasbeehCount(activeDhikr, 1);
    setTodayRecord(res.todayRecord);
    setIsBumping(true);
    setTimeout(() => setIsBumping(false), 200);

    if (onCountIncremented) {
      onCountIncremented(res.todayRecord.totalCount);
    }
  };

  const handleSelectDhikr = (dhikr: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveDhikr(dhikr);
  };

  // Circular progress math for Small size
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  // ════════════════ SMALL SIZE (2x2) ════════════════
  if (size === 'small') {
    return (
      <div
        onClick={onOpenApp}
        dir="rtl"
        style={styles.containerStyle}
        className={`relative aspect-square w-full rounded-3xl p-4 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
      >
        {/* Subtle Islamic Geometry Watermark */}
        <div className="absolute -left-6 -bottom-6 w-28 h-28 rounded-full bg-white/5 pointer-events-none" />

        {/* Top bar: App badge & streak */}
        <div className="flex items-center justify-between z-10">
          <div className={`px-2 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 ${styles.badge} ${styles.badgeText}`}>
            <Sparkles className="w-2.5 h-2.5" />
            <span>رِفْق</span>
          </div>

          <div className={`flex items-center gap-1 text-[11px] font-black px-2 py-0.5 rounded-full ${styles.highlightBadge}`}>
            <Flame className="w-3 h-3 text-amber-500 fill-amber-500" />
            <span>{streak}</span>
          </div>
        </div>

        {/* Center: Circular Progress & Count */}
        <div className="flex flex-col items-center justify-center my-auto z-10 relative">
          <div className="relative w-24 h-24 flex items-center justify-center">
            <svg className="w-24 h-24 -rotate-90" viewBox="0 0 80 80">
              <circle
                cx="40"
                cy="40"
                r={radius}
                stroke={styles.ringTrack}
                strokeWidth="6"
                fill="none"
              />
              <circle
                cx="40"
                cy="40"
                r={radius}
                stroke={styles.ringFill}
                strokeWidth="6"
                fill="none"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className="transition-all duration-300"
              />
            </svg>

            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className={`text-2xl font-black font-tajawal tracking-tight transition-transform duration-150 ${isBumping ? 'scale-125' : ''} ${styles.primaryText}`}>
                {primaryStatValue.toLocaleString('ar-EG')}
              </span>
              <span className={`text-[9px] font-bold ${styles.secondaryText}`}>
                {statsMode === 'streak'
                  ? 'يوم متتالي'
                  : statsMode === 'lifetime'
                  ? 'إجمالي'
                  : statsMode === 'completed_athkar'
                  ? 'أوراد اليوم'
                  : `/ ${dailyGoal.toLocaleString('ar-EG')}`}
              </span>
            </div>
          </div>

          <span className={`text-[10px] font-bold truncate max-w-full text-center px-1 mt-1 ${styles.secondaryText}`}>
            {activeDhikr}
          </span>
        </div>

        {/* Bottom Quick Tap Action Button */}
        <div className="z-10 pt-1 flex items-center justify-between gap-1">
          <span className={`text-[10px] font-black ${styles.accentText}`}>
            {progressPercent}%
          </span>

          <button
            type="button"
            onClick={handleIncrement}
            title="تسبيح سريع +1"
            className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black transition-transform active:scale-90 cursor-pointer ${styles.button}`}
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // ════════════════ MEDIUM SIZE (4x2) ════════════════
  return (
    <div
      onClick={onOpenApp}
      dir="rtl"
      style={styles.containerStyle}
      className={`relative w-full rounded-3xl p-4 sm:p-5 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
    >
      {/* Decorative background aura */}
      <div className="absolute -left-10 -bottom-10 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute right-1/3 -top-10 w-32 h-32 rounded-full bg-amber-400/5 pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between z-10 mb-2">
        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-0.5 rounded-full text-[11px] font-black flex items-center gap-1.5 ${styles.badge} ${styles.badgeText}`}>
            <Sparkles className="w-3 h-3" />
            <span>{badgeTitle}</span>
          </div>

          <span className={`text-xs font-bold ${styles.secondaryText}`}>
            «رِفْق | RIFQ»
          </span>
        </div>

        <div className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-black ${styles.highlightBadge}`}>
          <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>سلسلة {streak} يوم</span>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-12 gap-3 items-center z-10 my-auto">
        {/* Left/Main Column: Active Dhikr & Quick Switches */}
        <div className="col-span-7 sm:col-span-8 flex flex-col justify-center space-y-2">
          <div className="space-y-0.5">
            <span className={`text-[10px] font-bold ${styles.secondaryText}`}>
              الذكر الحالي:
            </span>
            <h4 className={`text-sm sm:text-base font-black font-tajawal truncate ${styles.primaryText}`}>
              {activeDhikr}
            </h4>
          </div>

          {/* Quick Dhikr Chips */}
          <div className="flex flex-wrap gap-1 pt-0.5">
            {['سُبْحَانَ اللَّهِ', 'الْحَمْدُ لِلَّهِ', 'أَسْتَغْفِرُ اللَّهَ'].map((d) => (
              <button
                key={d}
                type="button"
                onClick={(e) => handleSelectDhikr(d, e)}
                className={`text-[10px] px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                  activeDhikr.includes(d)
                    ? styles.activeChip
                    : `${styles.subtleButton} hover:opacity-90`
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Right Column: Large Counter & Quick +1 Button */}
        <div className="col-span-5 sm:col-span-4 flex items-center justify-end gap-3">
          <div className="text-left flex flex-col items-end">
            <div className={`text-3xl sm:text-4xl font-black font-tajawal tracking-tight transition-transform duration-150 ${isBumping ? 'scale-110' : ''} ${styles.primaryText}`}>
              {primaryStatValue.toLocaleString('ar-EG')}
            </div>
            <span className={`text-[10px] font-bold ${styles.secondaryText}`}>
              {subtitleLabel}
            </span>
          </div>

          <button
            type="button"
            onClick={handleIncrement}
            title="تسبيح +1"
            className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black transition-transform active:scale-90 cursor-pointer shadow-lg shrink-0 ${styles.button}`}
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Bottom Progress Bar */}
      <div className="z-10 mt-2 space-y-1">
        <div className="flex items-center justify-between text-[10px] font-bold">
          <span className={styles.secondaryText}>
            إنجاز ورد اليوم
          </span>
          <span className={`flex items-center gap-1 font-black ${styles.accentText}`}>
            {progressPercent >= 100 && <Check className="w-3 h-3 text-emerald-500 inline" />}
            <span>{progressPercent}%</span>
          </span>
        </div>

        <div className={`w-full h-2 rounded-full overflow-hidden ${styles.progressBarBg}`}>
          <div
            className={`h-full rounded-full transition-all duration-500 ${styles.progressBarFill}`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
