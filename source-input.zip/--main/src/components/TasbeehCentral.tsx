import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  Minus,
  RotateCcw,
  BarChart3,
  Settings,
  ChevronDown,
  Volume2,
  VolumeX,
  Smartphone,
  Share2,
  Check,
  Plus,
  Trash2,
  Edit3,
  Target,
  Clock,
  BookOpen,
  Menu,
  Flame,
  RefreshCw,
  Download,
  Moon,
  Sun,
  Bell,
  ArrowRight,
  AlertTriangle,
  ListFilter,
  Sliders,
  Layers,
  Award,
  CheckCircle2,
  X,
  TrendingUp,
  Sparkles,
  Search,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
  Cell,
} from 'recharts';
import confetti from 'canvas-confetti';
import { DailyRecord, ScreenType, UserSettings, RosaryThemeId } from '../types';
import { soundManager } from '../utils/audio';
import { getRosaryTheme, ROSARY_THEMES } from '../utils/rosaryThemes';
import { InteractiveRosaryView } from './Rosary/InteractiveRosaryView';
import { DhikrSelectorModal } from './Rosary/DhikrSelectorModal';
import {
  initMisbahaSqliteTables,
  recordMisbahaTasbeeh,
  decrementMisbahaTasbeeh,
  resetMisbahaCurrentCounter,
  resetAllMisbahaStatistics,
  updateMisbahaSettingsInSqlite,
  addCustomDhikrToSqlite,
  updateCustomDhikrInSqlite,
  deleteCustomDhikrFromSqlite,
  deleteMisbahaSessionFromSqlite,
  formatSessionDuration,
  getMisbahaAdvancedStats,
  ADHKAR_LIST_CATEGORIES,
  AUTHENTIC_BUILTIN_ADHKAR,
  MisbahaSoundOption,
  MisbahaVibrationOption,
  CustomAdhkarSqliteRow,
  WirdCategoryType,
  PREDEFINED_WIRD_CATEGORIES,
  loadUserCustomWirdCategories,
  addUserCustomWirdCategory,
} from '../utils/misbahaSqlite';
import { addCustomDhikr, updateCustomDhikr, deleteCustomDhikr } from '../utils/storage';

interface TasbeehCentralProps {
  todayRecord: DailyRecord;
  settings: UserSettings;
  onIncrement: (dhikrText: string, amount?: number) => void;
  onDecrement: () => void;
  onResetCounter: () => void;
  onNavigate: (screen: ScreenType) => void;
  currentStreak: number;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onOpenSidebar?: () => void;
}

type MisbahaSubScreen =
  | 'main'
  | 'goals'
  | 'custom_adhkar'
  | 'settings'
  | 'stats'
  | 'history'
  | 'hisn_quick';

// Quick Hisn Al-Muslim authentic supplications for the fast-access view
const QUICK_HISN_SUPPLICATIONS = [
  {
    id: 'hisn_morning_1',
    category: 'أذكار الصباح والمساء',
    title: 'سيد الاستغفار',
    text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ',
    target: 1,
    source: 'صحيح البخاري',
  },
  {
    id: 'hisn_prayer_1',
    category: 'أذكار بعد السلام من الصلاة',
    title: 'التسبيح والتحميد والتكبير دبر الصلاة',
    text: 'سُبْحَانَ اللَّهِ (33) وَالْحَمْدُ لِلَّهِ (33) وَاللَّهُ أَكْبَرُ (33) وَلَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
    target: 33,
    source: 'صحيح مسلم',
  },
  {
    id: 'hisn_distress_1',
    category: 'دعاء الكرب والهم',
    title: 'دعاء تفريج الكرب العظيم',
    text: 'لَا إِلَهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ السَّمَاوَاتِ وَرَبُّ الْأَرْضِ وَرَبُّ الْعَرْشِ الْكَرِيمِ',
    target: 3,
    source: 'متفق عليه',
  },
  {
    id: 'hisn_protection_1',
    category: 'التحصين اليومي',
    title: 'تحصين الصباح والمساء',
    text: 'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
    target: 3,
    source: 'سنن أبي داود والترمذي',
  },
  {
    id: 'hisn_sleep_1',
    category: 'أذكار النوم',
    title: 'التسبيح عند النوم',
    text: 'سُبْحَانَ اللَّهِ وَالْحَمْدُ لِلَّهِ وَاللَّهُ أَكْبَرُ',
    target: 33,
    source: 'متفق عليه',
  },
];

// Clean SVG Mosque Icon (No Emoji)
const MosqueSvgIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3c-2.5 2.2-4 4.5-4 7h8c0-2.5-1.5-4.8-4-7Z" />
    <path d="M12 2v1" />
    <path d="M5 10v11h14V10" />
    <path d="M3 21h18" />
    <path d="M9 21v-5a3 3 0 0 1 6 0v5" />
    <path d="M5 10H3v11" />
    <path d="M21 21V10h-2" />
  </svg>
);

// Clean White SVG Misbaha Beads Icon for the 120px Green Tasbeeh Button
const WhiteMisbahaSvgIcon: React.FC<{ className?: string }> = ({ className = 'w-11 h-11' }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className}>
    <circle cx="32" cy="12" r="4.5" fill="currentColor" />
    <circle cx="44" cy="15" r="4.2" fill="currentColor" fillOpacity="0.92" />
    <circle cx="52" cy="25" r="4.2" fill="currentColor" fillOpacity="0.88" />
    <circle cx="53" cy="37" r="4.2" fill="currentColor" fillOpacity="0.85" />
    <circle cx="46" cy="47" r="4.2" fill="currentColor" fillOpacity="0.88" />
    <circle cx="32" cy="51" r="5" fill="currentColor" />
    <circle cx="18" cy="47" r="4.2" fill="currentColor" fillOpacity="0.88" />
    <circle cx="11" cy="37" r="4.2" fill="currentColor" fillOpacity="0.85" />
    <circle cx="12" cy="25" r="4.2" fill="currentColor" fillOpacity="0.88" />
    <circle cx="20" cy="15" r="4.2" fill="currentColor" fillOpacity="0.92" />
    <path d="M32 56v6M29 61h6" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
  </svg>
);

export const TasbeehCentral: React.FC<TasbeehCentralProps> = ({
  settings,
  onIncrement,
  onDecrement,
  onResetCounter,
  onNavigate,
  onUpdateSettings,
  onOpenSidebar,
}) => {
  // Load initial SQLite state
  const [sqliteData, setSqliteData] = useState(() => initMisbahaSqliteTables());
  const [isLoadingShimmer, setIsLoadingShimmer] = useState(true);
  const [activeSubScreen, setActiveSubScreen] = useState<MisbahaSubScreen>('main');
  const [viewMode, setViewMode] = useState<'circle' | 'beads_3d'>('circle');

  // Dropdown & Modals state
  const [isDhikrDropdownOpen, setIsDhikrDropdownOpen] = useState(false);
  const [confirmModalType, setConfirmModalType] = useState<'reset_counter' | 'reset_stats' | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Interactive button states
  const [isTasbeehPressed, setIsTasbeehPressed] = useState(false);
  const [counterPulse, setCounterPulse] = useState(false);
  const [cycleCompletedBanner, setCycleCompletedBanner] = useState<number | null>(null);

  // Custom Adhkar Form state
  const [newDhikrText, setNewDhikrText] = useState('');
  const [newDhikrTarget, setNewDhikrTarget] = useState<number>(100);
  const [newWirdType, setNewWirdType] = useState<WirdCategoryType>('daily');
  const [newDhikrListName, setNewDhikrListName] = useState<string>('ورد التسبيح اليومي العام');
  const [customWirdInput, setCustomWirdInput] = useState<string>('');
  const [newDhikrNotes, setNewDhikrNotes] = useState<string>('');
  const [wirdTypeFilter, setWirdTypeFilter] = useState<'all' | WirdCategoryType>('all');
  const [selectedListFilter, setSelectedListFilter] = useState<string>('الكل');
  const [customSearchQuery, setCustomSearchQuery] = useState('');
  const [isDhikrModalOpen, setIsDhikrModalOpen] = useState(false);
  const [editingDhikrId, setEditingDhikrId] = useState<string | null>(null);
  const [editDhikrText, setEditDhikrText] = useState('');
  const [editDhikrTarget, setEditDhikrTarget] = useState<number>(100);
  const [editWirdType, setEditWirdType] = useState<WirdCategoryType>('daily');
  const [editDhikrListName, setEditDhikrListName] = useState<string>('ورد التسبيح اليومي العام');
  const [editDhikrNotes, setEditDhikrNotes] = useState<string>('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Goals custom inputs
  const [customDailyInput, setCustomDailyInput] = useState('');
  const [customWeeklyInput, setCustomWeeklyInput] = useState('');
  const [customMonthlyInput, setCustomMonthlyInput] = useState('');
  const [weeklyRechartMode, setWeeklyRechartMode] = useState<'bar' | 'area'>('bar');
  const [dailyRechartMode, setDailyRechartMode] = useState<'area' | 'bar'>('area');

  const longPressTimerRef = useRef<number | null>(null);
  const longPressIntervalRef = useRef<number | null>(null);

  // Brief shimmer effect on mount while SQLite tables initialize
  useEffect(() => {
    const tables = initMisbahaSqliteTables();
    setSqliteData({ ...tables });
    const timer = window.setTimeout(() => {
      setIsLoadingShimmer(false);
    }, 220);
    return () => clearTimeout(timer);
  }, []);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2600);
  }, []);

  const refreshSqliteState = useCallback(() => {
    const tables = initMisbahaSqliteTables();
    setSqliteData({
      sessions: [...tables.sessions],
      customAdhkar: [...tables.customAdhkar],
      dailyStats: [...tables.dailyStats],
      settings: { ...tables.settings },
      streak: { ...tables.streak },
    });
  }, []);

  // Refresh Misbaha state immediately when user switches account or Firestore syncs
  useEffect(() => {
    const handleCloudSynced = () => {
      refreshSqliteState();
    };
    window.addEventListener('rifq-user-data-synced', handleCloudSynced);
    return () => {
      window.removeEventListener('rifq-user-data-synced', handleCloudSynced);
    };
  }, [refreshSqliteState]);

  const dbSettings = sqliteData.settings;
  const isDarkMode = dbSettings.dark_mode === 1 || Boolean(settings.rosaryDarkMode);
  const activeTheme = getRosaryTheme(dbSettings.theme || settings.rosaryTheme || 'gold');

  const advancedStats = useMemo(() => {
    return getMisbahaAdvancedStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sqliteData]);

  const currentDhikr = dbSettings.current_dhikr || 'سُبْحَانَ اللَّهِ';
  const currentCount = dbSettings.current_count || 0;
  const currentTarget = dbSettings.current_target; // 0 = open (∞)
  const progressPercent =
    currentTarget > 0 ? Math.min(100, Math.round((currentCount / currentTarget) * 100)) : 100;

  // 280px Circle SVG math (radius = 124, stroke = 8)
  const circleRadius = 124;
  const circleCircumference = 2 * Math.PI * circleRadius;
  const circleDashOffset =
    currentTarget > 0
      ? circleCircumference - (progressPercent / 100) * circleCircumference
      : 0;

  // Golden confetti celebration on cycle completion
  const fireGoldenConfetti = useCallback(() => {
    try {
      confetti({
        particleCount: 65,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#E99AC7', '#E8B84A', '#FFE082', '#5B5FEF', '#FFFFFF'],
      });
    } catch {
      // ignore if canvas-confetti fails in restricted environment
    }
  }, []);

  // Main Tasbeeh increment handler
  const handleTasbeehPress = useCallback(() => {
    const vol = (dbSettings.sound_volume ?? 75) / 100;
    const soundType = dbSettings.sound || 'wood';
    const vibLevel = dbSettings.vibration || 'medium';

    if (soundType !== 'silent' && vol > 0) {
      soundManager.playBeadClick(vol, soundType);
    }
    if (vibLevel !== 'none') {
      soundManager.triggerVibrationByLevel(vibLevel);
    }

    setCounterPulse(true);
    window.setTimeout(() => setCounterPulse(false), 180);

    const result = recordMisbahaTasbeeh(1);
    onIncrement(currentDhikr, 1);
    refreshSqliteState();

    if (result.completedCycle) {
      const completedTarget = currentTarget > 0 ? currentTarget : 100;
      setCycleCompletedBanner(completedTarget);
      if (soundType !== 'silent' && vol > 0) {
        soundManager.playCompletionChime(vol);
      }
      if (vibLevel !== 'none') {
        soundManager.triggerHaptic([60, 70, 60, 70, 140]);
      }
      fireGoldenConfetti();
      window.setTimeout(() => {
        setCycleCompletedBanner(null);
      }, 4000);
    }
  }, [
    dbSettings.sound_volume,
    dbSettings.sound,
    dbSettings.vibration,
    currentDhikr,
    currentTarget,
    onIncrement,
    refreshSqliteState,
    fireGoldenConfetti,
  ]);

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    setIsTasbeehPressed(true);
    handleTasbeehPress();

    longPressTimerRef.current = window.setTimeout(() => {
      longPressIntervalRef.current = window.setInterval(() => {
        handleTasbeehPress();
      }, 150);
    }, 480);
  };

  const handlePointerUpOrLeave = () => {
    setIsTasbeehPressed(false);
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    if (longPressIntervalRef.current) {
      clearInterval(longPressIntervalRef.current);
      longPressIntervalRef.current = null;
    }
  };

  // Decrement -1 handler
  const handleDecrementCount = () => {
    if (currentCount <= 0 && advancedStats.todayCount <= 0) return;
    decrementMisbahaTasbeeh();
    onDecrement();
    refreshSqliteState();
    showToast('تم إنقاص العداد بواحد (-1)');
  };

  // Select Dhikr handler
  const handleSelectDhikr = (text: string, targetVal: number) => {
    updateMisbahaSettingsInSqlite({
      current_dhikr: text,
      current_target: targetVal,
    });
    onUpdateSettings({
      rosaryDhikr: text,
      rosaryTarget: targetVal,
    });
    setIsDhikrDropdownOpen(false);
    refreshSqliteState();
    showToast('تم تغيير الذكر الحالي بنجاح');
  };

  // Share Achievement as text
  const handleShareAchievementText = async () => {
    const shareText = [
      'إحصائياتي في المسبحة المركزية — تطبيق رِفْق | RIFQ',
      `• الذكر الحالي: ${currentDhikr}`,
      `• تسبيحات اليوم: ${advancedStats.todayCount}`,
      `• الدورات المكتملة: ${advancedStats.totalCycles}`,
      `• السلسلة الحالية: ${advancedStats.currentStreak} يوم متتالي`,
      `• إجمالي التسبيحات: ${advancedStats.totalLifetimeCount}`,
      `«${advancedStats.motivationalText}»`,
    ].join('\n');

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'إنجازي في المسبحة المركزية - رِفْق',
          text: shareText,
        });
        return;
      } catch {
        // fallback to clipboard
      }
    }
    try {
      await navigator.clipboard.writeText(shareText);
      showToast('تم نسخ تفاصيل الإنجاز لمشاركتها');
    } catch {
      showToast('تم تجهيز نص الإنجاز للمشاركة');
    }
  };

  // Generate & Share Statistics as High-Res PNG Image
  const handleShareStatsAsImage = async () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1080;
      canvas.height = 1350;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // 1. Beige to Soft Cream Gradient Background
      const bgGrad = ctx.createLinearGradient(0, 0, 1080, 1350);
      bgGrad.addColorStop(0, '#F7F7FC');
      bgGrad.addColorStop(0.5, '#F7F7FC');
      bgGrad.addColorStop(1, '#F7F7FC');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 1080, 1350);

      // 2. Subtle Islamic Geometric Pattern (3% Gold Opacity)
      ctx.strokeStyle = 'rgba(201, 168, 76, 0.08)';
      ctx.lineWidth = 2;
      for (let x = 90; x < 1080; x += 180) {
        for (let y = 90; y < 1350; y += 180) {
          ctx.beginPath();
          ctx.arc(x, y, 65, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // 3. Outer Gold Frame
      ctx.strokeStyle = '#E99AC7';
      ctx.lineWidth = 5;
      ctx.strokeRect(48, 48, 984, 1254);

      ctx.strokeStyle = 'rgba(201, 168, 76, 0.35)';
      ctx.lineWidth = 2;
      ctx.strokeRect(64, 64, 952, 1222);

      // 4. Header Title
      ctx.fillStyle = '#E99AC7';
      ctx.font = 'bold 54px Cairo, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('المسبحة المركزية — رِفْق | RIFQ', 540, 165);

      ctx.fillStyle = '#25263A';
      ctx.font = 'bold 34px Cairo, sans-serif';
      ctx.fillText('بطاقة حصاد الذكر والإحصائيات', 540, 230);

      // 5. Current Dhikr Box
      ctx.fillStyle = '#FFFFFF';
      ctx.strokeStyle = '#E99AC7';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.roundRect(100, 280, 880, 190, 28);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#77798C';
      ctx.font = '26px Cairo, sans-serif';
      ctx.fillText('الذكر الحالي', 540, 335);

      ctx.fillStyle = '#5B5FEF';
      ctx.font = 'bold 44px Amiri, serif';
      ctx.fillText(currentDhikr.slice(0, 55), 540, 415);

      // 6. Stats Grid (4 Boxes)
      const statBoxes = [
        { label: 'تسبيحات اليوم', val: `${advancedStats.todayCount}`, x: 100, y: 510 },
        { label: 'إجمالي الأسبوع', val: `${advancedStats.weekCount}`, x: 560, y: 510 },
        { label: 'الدورات المكتملة', val: `${advancedStats.totalCycles}`, x: 100, y: 730 },
        { label: 'السلسلة المتتالية', val: `${advancedStats.currentStreak} يوم`, x: 560, y: 730 },
      ];

      for (const b of statBoxes) {
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = '#E99AC7';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.roundRect(b.x, b.y, 420, 185, 24);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#E99AC7';
        ctx.font = 'bold 62px Cairo, sans-serif';
        ctx.fillText(b.val, b.x + 210, b.y + 95);

        ctx.fillStyle = '#25263A';
        ctx.font = 'bold 28px Cairo, sans-serif';
        ctx.fillText(b.label, b.x + 210, b.y + 150);
      }

      // 7. Lifetime & Motivational Footer Banner
      ctx.fillStyle = '#5B5FEF';
      ctx.beginPath();
      ctx.roundRect(100, 960, 880, 190, 28);
      ctx.fill();

      ctx.fillStyle = '#E8B84A';
      ctx.font = 'bold 34px Cairo, sans-serif';
      ctx.fillText(`إجمالي التسبيحات الكلي: ${advancedStats.totalLifetimeCount}`, 540, 1030);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '28px Cairo, sans-serif';
      ctx.fillText(advancedStats.motivationalText, 540, 1095);

      ctx.fillStyle = '#77798C';
      ctx.font = '24px Cairo, sans-serif';
      ctx.fillText(`تاريخ الإصدار: ${new Date().toLocaleDateString('ar-EG')}`, 540, 1235);

      // Export and Download / Share
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `rifq-misbaha-stats-${Date.now()}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      showToast('تم حفظ وتحميل بطاقة الإحصائيات كصورة بنجاح');
    } catch {
      showToast('تعذر توليد الصورة في هذا المتصفح');
    }
  };

  // Add Custom Dhikr Handler with Wird Categorization
  const handleAddCustomDhikrSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDhikrText.trim()) return;

    const finalListName =
      newWirdType === 'custom' && customWirdInput.trim()
        ? customWirdInput.trim()
        : newDhikrListName;

    if (newWirdType === 'custom' && customWirdInput.trim()) {
      addUserCustomWirdCategory(customWirdInput.trim());
    }

    addCustomDhikrToSqlite(
      newDhikrText.trim(),
      newDhikrTarget,
      finalListName,
      newWirdType,
      newDhikrNotes.trim()
    );

    // Sync with storage
    addCustomDhikr({
      text: newDhikrText.trim(),
      countTarget: newDhikrTarget,
      category: 'custom',
      source: finalListName,
      virtue: newDhikrNotes.trim() || undefined,
    });

    setNewDhikrText('');
    setNewDhikrTarget(100);
    setCustomWirdInput('');
    setNewDhikrNotes('');
    refreshSqliteState();
    showToast('تمت إضافة الذكر وتصنيفه في الورد بنجاح');
  };

  // Save Edited Custom Dhikr
  const handleSaveEditedDhikr = (id: string) => {
    if (!editDhikrText.trim()) return;
    updateCustomDhikrInSqlite(id, {
      text: editDhikrText.trim(),
      target: editDhikrTarget,
      list_name: editDhikrListName.trim(),
      wird_type: editWirdType,
      notes: editDhikrNotes.trim(),
    });

    updateCustomDhikr(id, {
      text: editDhikrText.trim(),
      countTarget: editDhikrTarget,
      source: editDhikrListName.trim(),
      virtue: editDhikrNotes.trim() || undefined,
    });

    setEditingDhikrId(null);
    refreshSqliteState();
    showToast('تم تحديث الذكر والورد بنجاح');
  };

  // Delete Custom Dhikr
  const handleDeleteCustomDhikr = (id: string) => {
    deleteCustomDhikrFromSqlite(id);
    deleteCustomDhikr(id);
    setDeleteConfirmId(null);
    refreshSqliteState();
    showToast('تم حذف الذكر المخصص');
  };

  // Filtered Custom Adhkar by Wird Type & List & Search
  const filteredCustomAdhkar = useMemo(() => {
    const q = customSearchQuery.trim().toLowerCase();
    return sqliteData.customAdhkar.filter((item) => {
      const matchesWirdType = wirdTypeFilter === 'all' || item.wird_type === wirdTypeFilter;
      const matchesList = selectedListFilter === 'الكل' || item.list_name === selectedListFilter;
      const matchesQuery =
        !q ||
        item.text.toLowerCase().includes(q) ||
        item.list_name.toLowerCase().includes(q) ||
        (item.notes && item.notes.toLowerCase().includes(q));
      return matchesWirdType && matchesList && matchesQuery;
    });
  }, [sqliteData.customAdhkar, wirdTypeFilter, selectedListFilter, customSearchQuery]);

  // Surface styling tokens based on Light/Dark mode while strictly preserving Rifq palette
  const bgContainerStyle = isDarkMode
    ? 'bg-gradient-to-b from-[#25263A] to-[#25263A] text-[#F7F7FC]'
    : 'bg-gradient-to-b from-[#FFFFFF] to-[#F7F7FC] text-[#25263A]';

  const cardSurfaceClass = isDarkMode
    ? 'bg-[#25263A] border border-[#E6E6F0] text-[#F7F7FC] rounded-[20px] shadow-[0_4px_12px_rgba(0,0,0,0.25)]'
    : 'bg-[#FFFFFF] border border-[#E6E6F0] text-[#25263A] rounded-[20px] shadow-[0_4px_12px_rgba(0,0,0,0.06)]';

  return (
    <div
      className={`w-full max-w-2xl mx-auto rounded-[24px] p-3 sm:p-5 select-none relative overflow-hidden transition-colors duration-300 font-cairo animate-fade-in ${bgContainerStyle}`}
      dir="rtl"
    >
      {/* Subtle 3% Gold Islamic Geometric Pattern Overlay */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(#E99AC7 2px, transparent 2px), radial-gradient(#E99AC7 2px, transparent 2px)`,
          backgroundSize: '36px 36px',
          backgroundPosition: '0 0, 18px 18px',
        }}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-white border border-[#5B5FEF] px-4 py-2.5 rounded-2xl shadow-lg flex items-center gap-2 text-xs font-bold animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-[#5B5FEF] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="relative z-10 space-y-4">
        {/* ══════════════════════════════════════════════════════════════════
            【الشريط العلوي】
            • يمين: ☰ القائمة + "المسبحة المركزية" Cairo Bold ذهبي
            • يسار: أيقونة الإحصائيات + الإعدادات
            • خلفية بيج مع حد ذهبي رفيع أسفل
           ══════════════════════════════════════════════════════════════════ */}
        <header
          className={`w-full flex items-center justify-between px-3.5 py-3 rounded-t-[18px] border-b border-[#5B5FEF] ${
            isDarkMode ? 'bg-[#25263A]' : 'bg-[#F7F7FC]'
          }`}
        >
          {/* يمين: ☰ القائمة + "المسبحة المركزية" Cairo Bold ذهبي */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                if (activeSubScreen !== 'main') {
                  setActiveSubScreen('main');
                } else if (onOpenSidebar) {
                  onOpenSidebar();
                } else {
                  onNavigate('home');
                }
              }}
              className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title={activeSubScreen !== 'main' ? 'العودة للمسبحة المركزية' : 'القائمة'}
              aria-label="القائمة"
            >
              {activeSubScreen !== 'main' ? (
                <ArrowRight className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
            <div>
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#5B5FEF] tracking-tight whitespace-nowrap">
                المسبحة المركزية
              </h1>
              <p className="text-[11px] text-[#77798C] font-cairo">
                {activeTheme.nameAr} · {dbSettings.sound === 'silent' ? 'صامت' : 'صوت مفعل'}
              </p>
            </div>
          </div>

          {/* يسار: أيقونة الإحصائيات + الإعدادات + الوضع الليلي */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                const nextDark = isDarkMode ? 0 : 1;
                updateMisbahaSettingsInSqlite({ dark_mode: nextDark });
                onUpdateSettings({ rosaryDarkMode: nextDark === 1 });
                refreshSqliteState();
              }}
              className="min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title={isDarkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
              aria-label="تبديل الوضع الليلي"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={() => setActiveSubScreen(activeSubScreen === 'stats' ? 'main' : 'stats')}
              className={`min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                activeSubScreen === 'stats'
                  ? 'bg-[#5B5FEF] text-white'
                  : 'text-[#5B5FEF] hover:bg-[#EEEEFF]'
              }`}
              title="الإحصائيات المتقدمة"
              aria-label="الإحصائيات"
            >
              <BarChart3 className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() =>
                setActiveSubScreen(activeSubScreen === 'settings' ? 'main' : 'settings')
              }
              className={`min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                activeSubScreen === 'settings'
                  ? 'bg-[#5B5FEF] text-white'
                  : 'text-[#5B5FEF] hover:bg-[#EEEEFF]'
              }`}
              title="إعدادات المسبحة"
              aria-label="الإعدادات"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* ══════════════════════════════════════════════════════════════════
            【شريط التنقل بين الشاشات الفرعية الستة】
            الرئيسية | الأهداف | الأذكار المخصصة | الإحصائيات | السجل | الإعدادات | حصن المسلم
           ══════════════════════════════════════════════════════════════════ */}
        <nav
          aria-label="أقسام المسبحة المركزية"
          className={`w-full flex items-center gap-1.5 overflow-x-auto p-1.5 rounded-2xl border border-[#E6E6F0] scrollbar-none ${
            isDarkMode ? 'bg-[#25263A]' : 'bg-white'
          }`}
        >
          {[
            { id: 'main', label: 'العداد الرئيسي', icon: Layers },
            { id: 'goals', label: 'الأهداف', icon: Target },
            { id: 'custom_adhkar', label: 'أذكار مخصصة', icon: Plus },
            { id: 'stats', label: 'الإحصائيات', icon: BarChart3 },
            { id: 'history', label: 'السجل', icon: Clock },
            { id: 'settings', label: 'الإعدادات', icon: Sliders },
            { id: 'hisn_quick', label: 'حصن المسلم', icon: BookOpen },
          ].map((tab) => {
            const IconComp = tab.icon;
            const isActive = activeSubScreen === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveSubScreen(tab.id as MisbahaSubScreen)}
                className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all cursor-pointer min-h-[40px] ${
                  isActive
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : isDarkMode
                    ? 'text-[#F7F7FC]/80 hover:bg-[#EEEEFF]'
                    : 'text-[#25263A] hover:bg-[#F7F7FC]'
                }`}
              >
                <IconComp className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => onNavigate('daily_reminders')}
            className={`px-3 py-2 rounded-xl text-xs font-cairo font-bold whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-all cursor-pointer min-h-[40px] border border-[#E6E6F0] ${
              isDarkMode
                ? 'text-[#5B5FEF] hover:bg-[#EEEEFF]'
                : 'text-[#4145C7] hover:bg-[#EEEEFF]'
            }`}
          >
            <Bell className="w-3.5 h-3.5 shrink-0 text-[#5B5FEF]" />
            <span>التذكيرات اليومية</span>
          </button>
        </nav>

        {/* ══════════════════════════════════════════════════════════════════
            الشاشة الرئيسية للمسبحة (MAIN VIEW)
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'main' && (
          <div className="space-y-4">
            {/* 【بطاقة الذكر الحالي】 */}
            <section className={`${cardSurfaceClass} p-4 sm:p-5 space-y-3`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[#5B5FEF]">
                  <MosqueSvgIcon className="w-5 h-5" />
                  <span className="text-xs font-cairo font-bold text-[#77798C]">
                    الذكر الحالي
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      setViewMode(viewMode === 'circle' ? 'beads_3d' : 'circle')
                    }
                    className="px-2.5 py-1.5 rounded-xl border border-[#E6E6F0] text-[11px] font-cairo font-bold text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
                  >
                    {viewMode === 'circle' ? 'عرض السبحة التفاعلية' : 'عرض الدائرة الكبيرة'}
                  </button>

                  <button
                    type="button"
                    onClick={() => onNavigate('daily_reminders')}
                    className="px-2.5 py-1.5 rounded-xl border border-[#E6E6F0] text-[11px] font-cairo font-bold text-[#4CAF82] hover:bg-[#EEEEFF] transition-colors cursor-pointer flex items-center gap-1"
                    title="جدولة التذكيرات اليومية للأدعية والتسبيح"
                  >
                    <Bell className="w-3.5 h-3.5 text-[#5B5FEF]" />
                    <span>تذكير يومي</span>
                  </button>
                </div>
              </div>

              {/* نص الذكر الشرعي: Amiri 32px */}
              <div className="py-3 text-center">
                <p
                  className={`font-amiri text-[28px] sm:text-[32px] leading-relaxed font-bold select-text ${
                    isDarkMode ? 'text-[#F7F7FC]' : 'text-[#25263A]'
                  }`}
                >
                  {currentDhikr}
                </p>
              </div>

              {/* أزرار تغيير الذكر وتخصيص الأوراد */}
              <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                <button
                  type="button"
                  onClick={() => setIsDhikrModalOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] via-[#4145C7] to-[#4145C7] hover:brightness-110 text-white shadow-xs text-xs font-cairo font-bold flex items-center gap-2 transition-all cursor-pointer min-h-[44px]"
                  title="فتح مكتبة واختيار الأذكار والأوراد المخصصة"
                >
                  <BookOpen className="w-4 h-4 text-amber-300" />
                  <span>مكتبة الأذكار والأوراد</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                </button>

                <button
                  type="button"
                  onClick={() => setIsDhikrDropdownOpen(!isDhikrDropdownOpen)}
                  className="px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#5B5FEF] text-xs font-cairo font-bold flex items-center gap-1.5 transition-all cursor-pointer min-h-[44px]"
                  title="قائمة سريعة لتغيير الذكر"
                >
                  <RefreshCw className="w-4 h-4 text-[#5B5FEF]" />
                  <span>اختيار سريع</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#5B5FEF] transition-transform ${
                      isDhikrDropdownOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                <button
                  type="button"
                  onClick={() => setActiveSubScreen('custom_adhkar')}
                  className="px-3.5 py-2.5 rounded-xl bg-white hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-cairo font-bold flex items-center gap-1.5 transition-all cursor-pointer min-h-[44px]"
                  title="إنشاء وتخصيص ذكر جديد وحفظه في الأوراد"
                >
                  <Plus className="w-4 h-4 text-[#5B5FEF]" />
                  <span>إنشاء ورد مخصص</span>
                </button>
              </div>

              {/* القائمة المنسدلة لتغيير الذكر */}
              {isDhikrDropdownOpen && (
                <div
                  className={`mt-3 pt-3 border-t border-[#E6E6F0] space-y-2 max-h-68 overflow-y-auto`}
                >
                  {/* رأس القائمة مع زر الانتقال للمكتبة */}
                  <div className="p-2.5 bg-gradient-to-r from-amber-50 to-indigo-50 border border-amber-200/80 rounded-xl flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 text-xs font-cairo font-bold text-[#4145C7]">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>أورادك اليومية والمناسبات</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setIsDhikrDropdownOpen(false);
                        setIsDhikrModalOpen(true);
                      }}
                      className="px-2.5 py-1 bg-[#5B5FEF] hover:bg-[#4145C7] text-white rounded-lg text-[11px] font-cairo font-bold cursor-pointer transition-colors shadow-2xs"
                    >
                      إدارة وتخصيص الأوراد
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-xs font-cairo font-bold text-[#77798C] px-1">
                    <span>الأذكار المأثورة والمخصصة</span>
                    <span>الهدف الافتراضي</span>
                  </div>

                  {/* Custom Adhkar from SQLite first */}
                  {sqliteData.customAdhkar.map((custom) => {
                    const isSelected = currentDhikr === custom.text;
                    return (
                      <button
                        key={custom.id}
                        type="button"
                        onClick={() => handleSelectDhikr(custom.text, custom.target)}
                        className={`w-full p-2.5 rounded-xl text-right flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-[#EEEEFF] border border-[#5B5FEF] text-[#4145C7] font-bold'
                            : isDarkMode
                            ? 'hover:bg-white/5 text-[#F7F7FC]'
                            : 'hover:bg-[#F7F7FC] text-[#25263A]'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <p className="font-amiri text-base truncate">{custom.text}</p>
                          <p className="text-[11px] text-[#77798C] font-cairo">
                            {custom.list_name} · استُخدم {custom.usage_count} مرة
                          </p>
                        </div>
                        <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums shrink-0">
                          {custom.target === 0 ? 'مفتوح' : `${custom.target} مرة`}
                        </span>
                      </button>
                    );
                  })}

                  {/* Built-in Authentic Adhkar */}
                  {AUTHENTIC_BUILTIN_ADHKAR.map((item) => {
                    const isSelected = currentDhikr === item.text;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectDhikr(item.text, item.target)}
                        className={`w-full p-2.5 rounded-xl text-right flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-[#EEEEFF] border border-[#5B5FEF] text-[#4145C7] font-bold'
                            : isDarkMode
                            ? 'hover:bg-white/5 text-[#F7F7FC]'
                            : 'hover:bg-[#F7F7FC] text-[#25263A]'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <p className="font-amiri text-base truncate">{item.text}</p>
                          <p className="text-[11px] text-[#77798C] font-cairo truncate">
                            {item.virtue}
                          </p>
                        </div>
                        <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums shrink-0">
                          {item.target} مرة
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </section>

            {/* إشعار إتمام الدورة الذهبي */}
            {cycleCompletedBanner !== null && (
              <div className="w-full bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-[#25263A] p-3.5 rounded-[20px] shadow-md flex items-center justify-between animate-fade-in border border-white/50">
                <div className="flex items-center gap-2.5">
                  <Award className="w-6 h-6 text-[#25263A] shrink-0" />
                  <div>
                    <p className="font-cairo font-bold text-sm">
                      ما شاء الله! أتممت دورة كاملة ({cycleCompletedBanner} تسبيحة)
                    </p>
                    <p className="text-xs opacity-85 font-cairo">
                      تم حفظ الجلسة في السجل وزيادة عداد الدورات تلقائياً
                    </p>
                  </div>
                </div>
                <span className="font-cairo font-bold text-sm tabular-nums">
                  +{cycleCompletedBanner}
                </span>
              </div>
            )}

            {/* أزرار اختيار هدف الدورة السريع: 100 / 500 / 1000 / مفتوح */}
            <div className="flex items-center justify-center gap-2 flex-wrap">
              {[
                { val: 33, label: '33' },
                { val: 100, label: '100' },
                { val: 500, label: '500' },
                { val: 1000, label: '1000' },
                { val: 0, label: 'مفتوح ∞' },
              ].map((opt) => {
                const isSelected = currentTarget === opt.val;
                return (
                  <button
                    key={opt.val}
                    type="button"
                    onClick={() => {
                      updateMisbahaSettingsInSqlite({ current_target: opt.val });
                      onUpdateSettings({ rosaryTarget: opt.val });
                      refreshSqliteState();
                    }}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer min-h-[38px] tabular-nums ${
                      isSelected
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : isDarkMode
                        ? 'bg-[#25263A] text-[#F7F7FC] border border-[#E6E6F0] hover:bg-[#EEEEFF]'
                        : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:bg-[#F7F7FC]'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            {viewMode === 'beads_3d' ? (
              <InteractiveRosaryView
                onNavigate={onNavigate}
                userSettings={settings}
                overrideDhikrText={currentDhikr}
                overrideTarget={currentTarget}
                overrideTheme={dbSettings.theme}
                hideInternalDhikrCard={true}
                onDhikrChange={(newText, newTarget) =>
                  handleSelectDhikr(newText, newTarget || 100)
                }
                onSyncGlobalCount={() => handleTasbeehPress()}
              />
            ) : (
              /* ══════════════════════════════════════════════════════════════════
                 【الدائرة الكبيرة (العداد) — 280px】
                 ■ الدائرة: 280px
                 ■ خلفية تدرج ذهبي خفيف + ظل داخلي وخارجي
                 ■ شريط تقدم دائري ذهبي متدرج 8px
                 ■ الرقم: Cairo Bold 72px ذهبي
                 ■ "من 100": Cairo Regular 18px رمادي #77798C
                 ══════════════════════════════════════════════════════════════════ */
              <div className={`${cardSurfaceClass} p-5 flex flex-col items-center space-y-5`}>
                <div
                  className="relative w-[280px] h-[280px] rounded-full flex items-center justify-center"
                  style={{
                    background: isDarkMode
                      ? 'radial-gradient(circle, rgba(201,168,76,0.14) 0%, rgba(42,27,22,0.95) 75%)'
                      : 'radial-gradient(circle, var(--theme-surface) 0%, var(--theme-background) 65%, var(--theme-primary-light) 100%)',
                    boxShadow: isDarkMode
                      ? 'inset 0 4px 18px rgba(201,168,76,0.18), 0 10px 28px rgba(0,0,0,0.45)'
                      : 'inset 0 4px 16px color-mix(in srgb, var(--theme-primary) 14%, transparent), 0 8px 24px color-mix(in srgb, var(--theme-primary) 12%, transparent)',
                  }}
                >
                  {/* SVG Progress Ring (280x280, strokeWidth 8px) */}
                  <svg className="w-[280px] h-[280px] -rotate-90 absolute inset-0">
                    <defs>
                      <linearGradient id="misbahaGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="var(--theme-accent)" />
                        <stop offset="50%" stopColor="var(--theme-primary)" />
                        <stop offset="100%" stopColor="var(--theme-primary-dark)" />
                      </linearGradient>
                    </defs>

                    {/* Background Track */}
                    <circle
                      cx="140"
                      cy="140"
                      r={circleRadius}
                      fill="transparent"
                      stroke={isDarkMode ? 'rgba(201,168,76,0.15)' : 'var(--theme-border)'}
                      strokeWidth="8"
                    />

                    {/* Active Gold Progress Ring */}
                    <circle
                      cx="140"
                      cy="140"
                      r={circleRadius}
                      fill="transparent"
                      stroke="url(#misbahaGoldGrad)"
                      strokeWidth="8"
                      strokeDasharray={circleCircumference}
                      strokeDashoffset={circleDashOffset}
                      strokeLinecap="round"
                      className="transition-all duration-200 ease-out"
                    />
                  </svg>

                  {/* Counter Number & Target Label */}
                  <div className="relative z-10 flex flex-col items-center justify-center text-center px-4">
                    {isLoadingShimmer ? (
                      <div className="w-32 h-20 rounded-2xl bg-[#EEEEFF] animate-pulse" />
                    ) : (
                      <span
                        className={`font-cairo font-bold text-[72px] leading-none tabular-nums transition-transform duration-150 ${
                          counterPulse ? 'scale-110' : 'scale-100'
                        }`}
                        style={{ color: 'var(--theme-primary)' }}
                      >
                        {currentCount}
                      </span>
                    )}

                    <span className="font-cairo font-normal text-[18px] text-[#77798C] mt-2 tabular-nums">
                      {currentTarget > 0 ? `من ${currentTarget}` : 'هدف مفتوح ∞'}
                    </span>
                  </div>
                </div>

                {/* شريط التقدم الأفقي + النسبة المئوية */}
                <div className="w-full max-w-xs space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-cairo">
                    <span className="text-[#77798C]">التقدم في الدورة الحالية</span>
                    <span className="font-bold text-[#5B5FEF] tabular-nums">
                      {currentTarget > 0 ? `${progressPercent}%` : 'مفتوح'}
                    </span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-l from-[#5B5FEF] to-[#72B7E8] transition-all duration-200"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* ══════════════════════════════════════════════════════════════════
                    【زر التسبيح الرئيسي 120px + الأزرار الجانبية】
                    • يمين: نقصان -1
                    • المنتصف: دائرة خضراء 120px (#5B5FEF → #4CAF82) + أيقونة مسبحة SVG بيضاء + "سبّح" Cairo Bold
                    • يسار: إعادة تعيين
                   ══════════════════════════════════════════════════════════════════ */}
                <div className="w-full flex items-center justify-center gap-6 sm:gap-10 pt-2 pb-1">
                  {/* يمين (في اتجاه RTL أول عنصر يظهر يميناً): نقصان -1 */}
                  <button
                    type="button"
                    onClick={handleDecrementCount}
                    disabled={currentCount === 0 && advancedStats.todayCount === 0}
                    className={`flex flex-col items-center justify-center gap-1 min-w-[68px] min-h-[68px] rounded-2xl border border-[#E6E6F0] transition-all active:scale-95 disabled:opacity-35 disabled:cursor-not-allowed cursor-pointer ${
                      isDarkMode
                        ? 'bg-[#25263A] text-[#F7F7FC] hover:bg-[#EEEEFF]'
                        : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                    }`}
                    title="نقصان -1"
                    aria-label="نقصان 1"
                  >
                    <Minus className="w-5 h-5 text-[#25263A] dark:text-[#F7F7FC]" />
                    <span className="text-[11px] font-cairo font-bold">نقصان -1</span>
                  </button>

                  {/* زر التسبيح الرئيسي: دائرة 120px متكيفة مع الثيم */}
                  <button
                    type="button"
                    onPointerDown={handlePointerDown}
                    onPointerUp={handlePointerUpOrLeave}
                    onPointerLeave={handlePointerUpOrLeave}
                    aria-label="سبّح"
                    style={{
                      background: 'var(--theme-hero-gradient)',
                      boxShadow: isTasbeehPressed
                        ? '0 0 32px color-mix(in srgb, var(--theme-primary) 65%, transparent)'
                        : '0 10px 28px color-mix(in srgb, var(--theme-primary) 38%, transparent)',
                    }}
                    className={`w-[120px] h-[120px] rounded-full bg-gradient-to-b from-[#5B5FEF] to-[#4145C7] text-white flex flex-col items-center justify-center gap-1 cursor-pointer select-none border-4 border-[#E6E6F0] transition-all duration-150 ${
                      isTasbeehPressed ? 'scale-95' : 'scale-100'
                    }`}
                  >
                    <WhiteMisbahaSvgIcon className="w-11 h-11 text-white" />
                    <span className="font-cairo font-bold text-lg text-white tracking-wide">
                      سبّح
                    </span>
                  </button>

                  {/* يسار: إعادة تعيين */}
                  <button
                    type="button"
                    onClick={() => setConfirmModalType('reset_counter')}
                    className={`flex flex-col items-center justify-center gap-1 min-w-[68px] min-h-[68px] rounded-2xl border border-[#E6E6F0] transition-all active:scale-95 cursor-pointer ${
                      isDarkMode
                        ? 'bg-[#25263A] text-[#F7F7FC] hover:bg-[#D95C6A]/20'
                        : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#D95C6A]/10'
                    }`}
                    title="إعادة تعيين العداد"
                    aria-label="إعادة تعيين"
                  >
                    <RotateCcw className="w-5 h-5 text-[#D95C6A]" />
                    <span className="text-[11px] font-cairo font-bold">إعادة تعيين</span>
                  </button>
                </div>
              </div>
            )}

            {/* ══════════════════════════════════════════════════════════════════
                【الإحصائيات السريعة】
                3 بطاقات:
                • تسبيحات اليوم
                • الدورات
                • السلسلة
               ══════════════════════════════════════════════════════════════════ */}
            <section className="grid grid-cols-3 gap-2.5 sm:gap-3">
              {/* 1. تسبيحات اليوم */}
              <div
                onClick={() => setActiveSubScreen('goals')}
                className={`${cardSurfaceClass} p-3.5 text-center cursor-pointer hover:border-[#5B5FEF] transition-colors`}
              >
                <div className="w-8 h-8 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto mb-1.5">
                  <Target className="w-4 h-4" />
                </div>
                <div className="font-cairo font-bold text-xl sm:text-2xl text-[#5B5FEF] tabular-nums">
                  {advancedStats.todayCount}
                </div>
                <div className="text-xs font-cairo font-bold mt-0.5">تسبيحات اليوم</div>
                <div className="text-[10px] text-[#77798C] font-cairo mt-0.5 tabular-nums">
                  {dbSettings.daily_target > 0
                    ? `الهدف: ${dbSettings.daily_target}`
                    : 'هدف مفتوح'}
                </div>
              </div>

              {/* 2. الدورات */}
              <div
                onClick={() => setActiveSubScreen('history')}
                className={`${cardSurfaceClass} p-3.5 text-center cursor-pointer hover:border-[#5B5FEF] transition-colors`}
              >
                <div className="w-8 h-8 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center mx-auto mb-1.5">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div className="font-cairo font-bold text-xl sm:text-2xl text-[#4145C7] tabular-nums">
                  {advancedStats.totalCycles}
                </div>
                <div className="text-xs font-cairo font-bold mt-0.5">الدورات</div>
                <div className="text-[10px] text-[#77798C] font-cairo mt-0.5 tabular-nums">
                  {advancedStats.totalSessions} جلسة مسجلة
                </div>
              </div>

              {/* 3. السلسلة */}
              <div
                onClick={() => setActiveSubScreen('stats')}
                className={`${cardSurfaceClass} p-3.5 text-center cursor-pointer hover:border-[#5B5FEF] transition-colors`}
              >
                <div className="w-8 h-8 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto mb-1.5">
                  <Flame className="w-4 h-4" />
                </div>
                <div className="font-cairo font-bold text-xl sm:text-2xl text-[#5B5FEF] tabular-nums">
                  {advancedStats.currentStreak}
                </div>
                <div className="text-xs font-cairo font-bold mt-0.5">السلسلة</div>
                <div className="text-[10px] text-[#77798C] font-cairo mt-0.5 tabular-nums">
                  أطول سلسلة: {advancedStats.longestStreak} يوم
                </div>
              </div>
            </section>

            {/* شريط النص التحفيزي للسلسلة + المشاركة السريعة */}
            <div className={`${cardSurfaceClass} p-3.5 flex items-center justify-between gap-3`}>
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center shrink-0">
                  <Flame className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-cairo font-bold truncate">
                    {advancedStats.motivationalText}
                  </p>
                  <p className="text-[11px] text-[#77798C] font-cairo">
                    الأسبوع: {advancedStats.weekCount} · الشهر: {advancedStats.monthCount}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleShareAchievementText}
                className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-xs font-cairo font-bold flex items-center gap-1.5 shrink-0 cursor-pointer min-h-[40px]"
              >
                <Share2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                <span>مشاركة</span>
              </button>
            </div>

            {/* ══════════════════════════════════════════════════════════════════
                【10】بطاقة حصن المسلم السريع في الأسفل
               ══════════════════════════════════════════════════════════════════ */}
            <section className={`${cardSurfaceClass} p-4 flex items-center justify-between gap-3`}>
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-11 h-11 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0] text-[#5B5FEF] flex items-center justify-center shrink-0">
                  <MosqueSvgIcon className="w-6 h-6" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-cairo font-bold text-sm">حصن المسلم السريع</h3>
                  <p className="text-xs text-[#77798C] font-cairo truncate">
                    أذكار الصباح والمساء وأدعية التحصين النبوية الموثقة
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveSubScreen('hisn_quick')}
                  className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-xs font-cairo font-bold cursor-pointer min-h-[40px]"
                >
                  عرض سريع
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('hisn_almuslim')}
                  className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-cairo font-bold cursor-pointer min-h-[40px]"
                >
                  فتح حصن المسلم
                </button>
              </div>
            </section>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 1: الأهداف (GOALS)】
            • هدف يومي: 100 / 500 / 1000 / ∞ مفتوح
            • هدف أسبوعي
            • هدف شهري
            • شريط تقدم لكل هدف
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'goals' && (
          <div className="space-y-4 animate-fade-in">
            <div className={`${cardSurfaceClass} p-5 space-y-4`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#5B5FEF]" />
                  <h2 className="font-cairo font-bold text-base">الأهداف اليومية والأسبوعية والشهرية</h2>
                </div>
                <span className="text-xs text-[#77798C] font-cairo">تُحفظ تلقائياً في SQLite</span>
              </div>

              {/* 1. الهدف اليومي */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-sm">الهدف اليومي</span>
                  <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums">
                    {advancedStats.todayCount} /{' '}
                    {dbSettings.daily_target === 0 ? 'مفتوح ∞' : dbSettings.daily_target}
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-3 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-[#5B5FEF] to-[#4145C7] transition-all duration-300"
                    style={{
                      width: `${
                        dbSettings.daily_target > 0
                          ? Math.min(
                              100,
                              Math.round((advancedStats.todayCount / dbSettings.daily_target) * 100)
                            )
                          : 100
                      }%`,
                    }}
                  />
                </div>

                <div className="grid grid-cols-4 gap-2 pt-1">
                  {[
                    { val: 100, label: '100' },
                    { val: 500, label: '500' },
                    { val: 1000, label: '1000' },
                    { val: 0, label: 'مفتوح ∞' },
                  ].map((opt) => {
                    const active = dbSettings.daily_target === opt.val;
                    return (
                      <button
                        key={opt.val}
                        type="button"
                        onClick={() => {
                          updateMisbahaSettingsInSqlite({
                            daily_target: opt.val,
                            current_target: opt.val,
                          });
                          onUpdateSettings({ dailyGoal: opt.val, rosaryTarget: opt.val });
                          refreshSqliteState();
                          showToast('تم تحديث الهدف اليومي');
                        }}
                        className={`py-2.5 rounded-xl text-xs font-cairo font-bold cursor-pointer transition-all ${
                          active
                            ? 'bg-[#5B5FEF] text-white shadow-xs'
                            : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:bg-[#EEEEFF]'
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="number"
                    min="1"
                    placeholder="أو أدخل هدفاً يومياً مخصصاً..."
                    value={customDailyInput}
                    onChange={(e) => setCustomDailyInput(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo focus:outline-none focus:border-[#5B5FEF]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const val = parseInt(customDailyInput, 10);
                      if (!isNaN(val) && val > 0) {
                        updateMisbahaSettingsInSqlite({ daily_target: val, current_target: val });
                        onUpdateSettings({ dailyGoal: val });
                        setCustomDailyInput('');
                        refreshSqliteState();
                        showToast(`تم تعيين الهدف اليومي: ${val}`);
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    حفظ
                  </button>
                </div>
              </div>

              <hr className="border-[#E6E6F0]" />

              {/* 2. الهدف الأسبوعي */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-sm">الهدف الأسبوعي</span>
                  <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums">
                    {advancedStats.weekCount} / {dbSettings.weekly_target} (
                    {Math.min(
                      100,
                      Math.round((advancedStats.weekCount / Math.max(1, dbSettings.weekly_target)) * 100)
                    )}
                    %)
                  </span>
                </div>

                <div className="w-full h-3 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-[#5B5FEF] to-[#72B7E8] transition-all duration-300"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          (advancedStats.weekCount / Math.max(1, dbSettings.weekly_target)) * 100
                        )
                      )}%`,
                    }}
                  />
                </div>

                <div className="grid grid-cols-4 gap-2 pt-1">
                  {[1000, 3000, 7000, 10000].map((val) => {
                    const active = dbSettings.weekly_target === val;
                    return (
                      <button
                        key={val}
                        type="button"
                        onClick={() => {
                          updateMisbahaSettingsInSqlite({ weekly_target: val });
                          onUpdateSettings({ weeklyGoal: val });
                          refreshSqliteState();
                          showToast('تم تحديث الهدف الأسبوعي');
                        }}
                        className={`py-2 rounded-xl text-xs font-cairo font-bold tabular-nums cursor-pointer ${
                          active
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                        }`}
                      >
                        {val}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="number"
                    min="100"
                    placeholder="هدف أسبوعي مخصص..."
                    value={customWeeklyInput}
                    onChange={(e) => setCustomWeeklyInput(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const val = parseInt(customWeeklyInput, 10);
                      if (!isNaN(val) && val > 0) {
                        updateMisbahaSettingsInSqlite({ weekly_target: val });
                        setCustomWeeklyInput('');
                        refreshSqliteState();
                        showToast(`تم تعيين الهدف الأسبوعي: ${val}`);
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    حفظ
                  </button>
                </div>
              </div>

              <hr className="border-[#E6E6F0]" />

              {/* 3. الهدف الشهري */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-cairo font-bold text-sm">الهدف الشهري</span>
                  <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums">
                    {advancedStats.monthCount} / {dbSettings.monthly_target} (
                    {Math.min(
                      100,
                      Math.round(
                        (advancedStats.monthCount / Math.max(1, dbSettings.monthly_target)) * 100
                      )
                    )}
                    %)
                  </span>
                </div>

                <div className="w-full h-3 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-[#5B5FEF] via-[#E99AC7] to-[#E8B84A] transition-all duration-300"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          (advancedStats.monthCount / Math.max(1, dbSettings.monthly_target)) * 100
                        )
                      )}%`,
                    }}
                  />
                </div>

                <div className="grid grid-cols-4 gap-2 pt-1">
                  {[5000, 15000, 30000, 50000].map((val) => {
                    const active = dbSettings.monthly_target === val;
                    return (
                      <button
                        key={val}
                        type="button"
                        onClick={() => {
                          updateMisbahaSettingsInSqlite({ monthly_target: val });
                          onUpdateSettings({ monthlyGoal: val });
                          refreshSqliteState();
                          showToast('تم تحديث الهدف الشهري');
                        }}
                        className={`py-2 rounded-xl text-xs font-cairo font-bold tabular-nums cursor-pointer ${
                          active
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                        }`}
                      >
                        {val}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="number"
                    min="500"
                    placeholder="هدف شهري مخصص..."
                    value={customMonthlyInput}
                    onChange={(e) => setCustomMonthlyInput(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const val = parseInt(customMonthlyInput, 10);
                      if (!isNaN(val) && val > 0) {
                        updateMisbahaSettingsInSqlite({ monthly_target: val });
                        setCustomMonthlyInput('');
                        refreshSqliteState();
                        showToast(`تم تعيين الهدف الشهري: ${val}`);
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    حفظ
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 2: الأذكار والأوراد المخصصة (CUSTOM DHIKR & WIRDS)】
            • إضافة وتخصيص الأذكار
            • تحديد عدد التكرارات (الهدف)
            • تصنيفها إلى أوراد يومية وأوراد مناسبات خاصة وأوراد مخصصة
            • تعديل + حذف مع تأكيد
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'custom_adhkar' && (
          <div className="space-y-4 animate-fade-in">
            {/* بطاقة ملخص وإحصاء الأوراد المخصصة */}
            <div className={`${cardSurfaceClass} p-4 sm:p-5 border border-amber-400/30 shadow-xs space-y-3`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-[#5B5FEF] flex items-center justify-center font-bold text-lg">
                    ✨
                  </div>
                  <div>
                    <h2 className="font-cairo font-bold text-base text-[#25263A] dark:text-white">
                      أذكاري وأورادي المخصصة
                    </h2>
                    <p className="text-xs text-[#77798C]">
                      أنشئ أذكارك الخاصة، حدد عدد التكرارات، ورتّبها في أوراد يومية أو للمناسبات الخاصة
                    </p>
                  </div>
                </div>
              </div>

              {/* إحصائيات سريعة للأوراد */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <span className="text-[11px] text-[#77798C] block">إجمالي الأذكار</span>
                  <span className="font-bold text-sm text-[#5B5FEF] font-mono block mt-0.5">
                    {sqliteData.customAdhkar.length}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <span className="text-[11px] text-[#77798C] block">أوراد يومية 🌅</span>
                  <span className="font-bold text-sm text-amber-600 font-mono block mt-0.5">
                    {sqliteData.customAdhkar.filter((a) => a.wird_type === 'daily' || !a.wird_type).length}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <span className="text-[11px] text-[#77798C] block">مناسبات خاصة 🌙</span>
                  <span className="font-bold text-sm text-purple-600 font-mono block mt-0.5">
                    {sqliteData.customAdhkar.filter((a) => a.wird_type === 'special_occasion').length}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <span className="text-[11px] text-[#77798C] block">التسبيحات المنجزة</span>
                  <span className="font-bold text-sm text-emerald-600 font-mono block mt-0.5">
                    {sqliteData.customAdhkar.reduce((sum, item) => sum + (item.usage_count || 0), 0)}
                  </span>
                </div>
              </div>
            </div>

            {/* نماذج مأثورة سريعة للاقتباس والتخصيص */}
            <div className={`${cardSurfaceClass} p-4 space-y-2.5`}>
              <span className="text-xs font-cairo font-bold text-[#77798C] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>نماذج أذكار نبوية مقترحة للتخصيص الفوري (اضغط للاقتباس):</span>
              </span>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
                {[
                  {
                    label: 'لا حول ولا قوة إلا بالله',
                    text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
                    target: 100,
                    wirdType: 'daily' as WirdCategoryType,
                    listName: 'ورد التسبيح اليومي العام',
                    notes: 'كنز من كنوز الجنة ودواء للهم والغم',
                  },
                  {
                    label: 'حسبنا الله ونعم الوكيل',
                    text: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ',
                    target: 100,
                    wirdType: 'special_occasion' as WirdCategoryType,
                    listName: 'ورد تفريج الكرب والهم والشدائد',
                    notes: 'أمان لكل خائف ومكروب',
                  },
                  {
                    label: 'دعاء ليلة القدر',
                    text: 'اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي',
                    target: 100,
                    wirdType: 'special_occasion' as WirdCategoryType,
                    listName: 'ورد شهر رمضان وليالي القدر',
                    notes: 'وصية رسول الله ﷺ لعائشة رضي الله عنها',
                  },
                  {
                    label: 'دعوة ذي النون',
                    text: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
                    target: 100,
                    wirdType: 'special_occasion' as WirdCategoryType,
                    listName: 'ورد تفريج الكرب والهم والشدائد',
                    notes: 'تفريج الكروب والهموم وقضاء الحوائج',
                  },
                  {
                    label: 'سيد الاستغفار',
                    text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ',
                    target: 33,
                    wirdType: 'daily' as WirdCategoryType,
                    listName: 'ورد الصباح والمساء',
                    notes: 'من قالها موقناً بها فمات من يومه أو ليلته دخل الجنة',
                  },
                  {
                    label: 'الصلاة الإبراهيمية',
                    text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ',
                    target: 100,
                    wirdType: 'special_occasion' as WirdCategoryType,
                    listName: 'ورد يوم الجمعة المباركة',
                    notes: 'صلاة الله بها عشراً وحط عشر خطيئات',
                  },
                ].map((tpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setNewDhikrText(tpl.text);
                      setNewDhikrTarget(tpl.target);
                      setNewWirdType(tpl.wirdType);
                      setNewDhikrListName(tpl.listName);
                      setNewDhikrNotes(tpl.notes);
                      soundManager.triggerHaptic(20);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] hover:border-[#5B5FEF] border border-[#E6E6F0] text-[#25263A] whitespace-nowrap text-xs font-bold transition-all cursor-pointer shrink-0"
                  >
                    <span>{tpl.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* نموذج إضافة وتخصيص ذكر مخصص جديد */}
            <form
              onSubmit={handleAddCustomDhikrSubmit}
              className={`${cardSurfaceClass} p-5 space-y-4`}
            >
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-[#5B5FEF]" />
                  <h3 className="font-cairo font-bold text-base text-[#25263A] dark:text-white">
                    إنشاء ذكر أو ورد جديد
                  </h3>
                </div>
                <span className="text-xs text-[#77798C]">حفظ دائم في قاعدة البيانات</span>
              </div>

              {/* نص الذكر */}
              <div className="space-y-1.5">
                <label className="block text-xs font-cairo font-bold">
                  نص الذكر أو الدعاء المبارك:
                </label>
                <textarea
                  rows={2}
                  required
                  value={newDhikrText}
                  onChange={(e) => setNewDhikrText(e.target.value)}
                  placeholder="اكتب نص الذكر، مثل: سُبْحَانَ اللَّهِ وَبِحَمْدِهِ عَدَدَ خَلْقِهِ..."
                  className="w-full p-3 rounded-xl border border-[#E6E6F0] bg-transparent font-amiri text-lg focus:outline-hidden focus:border-[#5B5FEF] leading-relaxed"
                />
              </div>

              {/* عدد التكرارات والهدف */}
              <div className="space-y-1.5">
                <label className="block text-xs font-cairo font-bold">
                  عدد التكرارات المستهدف:
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  <input
                    type="number"
                    min="0"
                    max="10000"
                    value={newDhikrTarget}
                    onChange={(e) => setNewDhikrTarget(parseInt(e.target.value, 10) || 0)}
                    className="w-28 px-3 py-2 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo font-bold tabular-nums focus:outline-hidden text-center"
                  />
                  <div className="flex gap-1.5 flex-wrap">
                    {[33, 100, 300, 500, 1000, 0].map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setNewDhikrTarget(t)}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                          newDhikrTarget === t
                            ? 'bg-[#5B5FEF] text-white shadow-2xs'
                            : 'bg-[#F7F7FC] text-gray-700 hover:bg-[#EEEEFF] border border-[#E6E6F0]'
                        }`}
                      >
                        {t === 0 ? 'مفتوح (∞)' : `${t}`}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* تصنيف الورد (أوراد يومية / مناسبات خاصة / مخصص) */}
              <div className="space-y-2">
                <label className="block text-xs font-cairo font-bold">
                  تصنيف الورد أو المناسبة:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setNewWirdType('daily');
                      setNewDhikrListName('ورد التسبيح اليومي العام');
                    }}
                    className={`p-3 rounded-xl text-center font-cairo font-bold border transition-all cursor-pointer ${
                      newWirdType === 'daily'
                        ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                        : 'bg-[#F7F7FC] text-gray-700 border-[#E6E6F0] hover:bg-amber-50'
                    }`}
                  >
                    <span className="block text-base">🌅</span>
                    <span className="text-xs block mt-1">ورد يومي راتب</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNewWirdType('special_occasion');
                      setNewDhikrListName('ورد يوم الجمعة المباركة');
                    }}
                    className={`p-3 rounded-xl text-center font-cairo font-bold border transition-all cursor-pointer ${
                      newWirdType === 'special_occasion'
                        ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                        : 'bg-[#F7F7FC] text-gray-700 border-[#E6E6F0] hover:bg-purple-50'
                    }`}
                  >
                    <span className="block text-base">🌙</span>
                    <span className="text-xs block mt-1">ورد مناسبة خاصة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setNewWirdType('custom');
                      setCustomWirdInput('');
                    }}
                    className={`p-3 rounded-xl text-center font-cairo font-bold border transition-all cursor-pointer ${
                      newWirdType === 'custom'
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                        : 'bg-[#F7F7FC] text-gray-700 border-[#E6E6F0] hover:bg-emerald-50'
                    }`}
                  >
                    <span className="block text-base">✨</span>
                    <span className="text-xs block mt-1">ورد مخصص باسمي</span>
                  </button>
                </div>

                {/* اسم القائمة / الورد */}
                {newWirdType !== 'custom' ? (
                  <select
                    value={newDhikrListName}
                    onChange={(e) => setNewDhikrListName(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-xl border border-[#E6E6F0] text-xs font-cairo font-bold focus:outline-hidden ${
                      isDarkMode ? 'bg-[#25263A] text-[#F7F7FC]' : 'bg-white text-[#25263A]'
                    }`}
                  >
                    {PREDEFINED_WIRD_CATEGORIES.filter((c) => c.type === newWirdType).map((cat) => (
                      <option key={cat.id} value={cat.name}>
                        {cat.icon} {cat.name} ({cat.description})
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    required
                    placeholder="اكتب اسم الورد المخصص (مثال: ورد قيام الليل، ورد الشفاء، ورد الاختبارات)"
                    value={customWirdInput}
                    onChange={(e) => setCustomWirdInput(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo font-bold focus:outline-hidden"
                  />
                )}
              </div>

              {/* فضل الذكر أو المناسبة (اختياري) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-cairo font-bold">
                  فضله أو النية والمناسبة (اختياري):
                </label>
                <input
                  type="text"
                  placeholder="مثال: يقرأ في الصباح لنيل بركة اليوم، أو بعد صلاة الظهر"
                  value={newDhikrNotes}
                  onChange={(e) => setNewDhikrNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-[#E6E6F0] bg-transparent text-xs font-cairo focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white font-cairo font-bold text-xs shadow-md hover:brightness-105 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>حفظ الذكر وتصنيفه في الورد</span>
              </button>
            </form>

            {/* تصفية وعرض الأذكار المخصصة */}
            <div className={`${cardSurfaceClass} p-4 sm:p-5 space-y-4`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2">
                <div className="flex items-center gap-2">
                  <ListFilter className="w-4 h-4 text-[#5B5FEF]" />
                  <h3 className="font-cairo font-bold text-sm">قائمة الأذكار والأوراد المحفوظة</h3>
                </div>
                <span className="text-xs text-[#77798C] tabular-nums">
                  المعروض: {filteredCustomAdhkar.length} من {sqliteData.customAdhkar.length}
                </span>
              </div>

              {/* شريط البحث في الأذكار المخصصة */}
              <div className="relative">
                <input
                  type="text"
                  value={customSearchQuery}
                  onChange={(e) => setCustomSearchQuery(e.target.value)}
                  placeholder="ابحث في أذكارك بنص الذكر أو اسم الورد أو الفضل..."
                  className="w-full bg-[#F7F7FC] focus:bg-white border border-[#E6E6F0] focus:border-[#5B5FEF] rounded-xl py-2.5 pr-9 pl-9 text-xs font-cairo text-[#25263A] focus:outline-hidden transition-all placeholder:text-[#77798C]"
                />
                <Search className="w-4 h-4 text-[#77798C] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                {customSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setCustomSearchQuery('')}
                    className="absolute left-3 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer"
                    title="مسح البحث"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* أزرار تصفية حسب نوع الورد */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                <button
                  type="button"
                  onClick={() => setWirdTypeFilter('all')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors ${
                    wirdTypeFilter === 'all'
                      ? 'bg-[#5B5FEF] text-white shadow-2xs'
                      : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                  }`}
                >
                  كافة الأنواع ({sqliteData.customAdhkar.length})
                </button>

                <button
                  type="button"
                  onClick={() => setWirdTypeFilter('daily')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdTypeFilter === 'daily'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-amber-50 text-amber-900 border border-amber-200'
                  }`}
                >
                  <span>🌅</span>
                  <span>أوراد يومية</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWirdTypeFilter('special_occasion')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdTypeFilter === 'special_occasion'
                      ? 'bg-purple-600 text-white shadow-2xs'
                      : 'bg-purple-50 text-purple-900 border border-purple-200'
                  }`}
                >
                  <span>🌙</span>
                  <span>أوراد مناسبات خاصة</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWirdTypeFilter('custom')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdTypeFilter === 'custom'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  }`}
                >
                  <span>✨</span>
                  <span>أوراد مخصصة</span>
                </button>
              </div>

              {filteredCustomAdhkar.length === 0 ? (
                <div className="py-10 text-center space-y-2 bg-[#F7F7FC] rounded-2xl border border-dashed border-[#E6E6F0] p-6">
                  <span className="text-3xl block">📖</span>
                  <p className="font-cairo font-bold text-sm text-[#25263A]">
                    لا توجد أذكار في هذا التصنيف حالياً
                  </p>
                  <p className="text-xs text-[#77798C] max-w-sm mx-auto">
                    استخدم النموذج أعلاه أو اضغط على أي نموذج مقترح لإنشاء وردك المفضل وتحديد تكراراته
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredCustomAdhkar.map((item: CustomAdhkarSqliteRow) => {
                    const isEditing = editingDhikrId === item.id;
                    const isConfirmingDelete = deleteConfirmId === item.id;

                    return (
                      <div
                        key={item.id}
                        className={`p-4 rounded-2xl border transition-all ${
                          currentDhikr === item.text
                            ? 'bg-[#4CAF82]/12 border-2 border-[#5B5FEF] shadow-xs'
                            : 'border-[#E6E6F0] hover:border-gray-300'
                        }`}
                      >
                        {isEditing ? (
                          /* نموذج التعديل المضمن */
                          <div className="space-y-3 bg-[#F7F7FC] p-3.5 rounded-xl border border-[#5B5FEF]">
                            <span className="font-cairo font-bold text-xs text-[#5B5FEF] block">
                              تعديل الذكر المخصص والورد
                            </span>
                            <textarea
                              rows={2}
                              value={editDhikrText}
                              onChange={(e) => setEditDhikrText(e.target.value)}
                              className="w-full p-2.5 rounded-xl border border-[#5B5FEF] bg-white font-amiri text-base focus:outline-hidden"
                            />
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                              <div>
                                <label className="text-[10px] text-[#77798C] block mb-1 font-bold">
                                  الهدف (التكرار):
                                </label>
                                <input
                                  type="number"
                                  min="0"
                                  value={editDhikrTarget}
                                  onChange={(e) =>
                                    setEditDhikrTarget(parseInt(e.target.value, 10) || 0)
                                  }
                                  className="w-full px-2.5 py-2 rounded-xl border border-[#E6E6F0] bg-white text-xs font-cairo font-bold text-center"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] text-[#77798C] block mb-1 font-bold">
                                  نوع الورد:
                                </label>
                                <select
                                  value={editWirdType}
                                  onChange={(e) =>
                                    setEditWirdType(e.target.value as WirdCategoryType)
                                  }
                                  className="w-full px-2.5 py-2 rounded-xl border border-[#E6E6F0] bg-white text-xs font-cairo font-bold"
                                >
                                  <option value="daily">ورد يومي 🌅</option>
                                  <option value="special_occasion">مناسبة خاصة 🌙</option>
                                  <option value="custom">ورد مخصص ✨</option>
                                </select>
                              </div>

                              <div>
                                <label className="text-[10px] text-[#77798C] block mb-1 font-bold">
                                  اسم الورد:
                                </label>
                                <input
                                  type="text"
                                  value={editDhikrListName}
                                  onChange={(e) => setEditDhikrListName(e.target.value)}
                                  className="w-full px-2.5 py-2 rounded-xl border border-[#E6E6F0] bg-white text-xs font-cairo font-bold"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="text-[10px] text-[#77798C] block mb-1 font-bold">
                                فضل الذكر أو المناسبة (اختياري):
                              </label>
                              <input
                                type="text"
                                value={editDhikrNotes}
                                onChange={(e) => setEditDhikrNotes(e.target.value)}
                                className="w-full px-2.5 py-2 rounded-xl border border-[#E6E6F0] bg-white text-xs font-cairo"
                              />
                            </div>

                            <div className="flex items-center gap-2 pt-1">
                              <button
                                type="button"
                                onClick={() => handleSaveEditedDhikr(item.id)}
                                className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold cursor-pointer"
                              >
                                حفظ التعديلات
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingDhikrId(null)}
                                className="px-3.5 py-2 rounded-xl bg-gray-200 text-[#25263A] text-xs font-cairo font-bold cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </div>
                          </div>
                        ) : (
                          /* بطاقة العرض المعتادة */
                          <>
                            <div className="flex items-start justify-between gap-3">
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 flex-wrap mb-1">
                                  <span
                                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                      item.wird_type === 'special_occasion'
                                        ? 'bg-purple-100 text-purple-900 border-purple-200'
                                        : item.wird_type === 'custom'
                                        ? 'bg-emerald-100 text-emerald-900 border-emerald-200'
                                        : 'bg-amber-100 text-amber-900 border-amber-200'
                                    }`}
                                  >
                                    {item.wird_type === 'special_occasion'
                                      ? '🌙 ورد مناسبة خاصة'
                                      : item.wird_type === 'custom'
                                      ? '✨ ورد مخصص'
                                      : '🌅 ورد يومي'}
                                  </span>

                                  <span className="text-xs text-[#5B5FEF] font-bold">
                                    {item.list_name}
                                  </span>
                                </div>

                                <p className="font-amiri text-lg sm:text-xl font-bold leading-relaxed text-[#25263A] dark:text-[#F7F7FC]">
                                  {item.text}
                                </p>

                                {item.notes && (
                                  <p className="text-xs text-[#77798C] font-serif leading-relaxed">
                                    {item.notes}
                                  </p>
                                )}
                              </div>

                              <button
                                type="button"
                                onClick={() => {
                                  handleSelectDhikr(item.text, item.target);
                                  setActiveSubScreen('main');
                                }}
                                className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-cairo font-bold shrink-0 cursor-pointer shadow-xs transition-colors"
                              >
                                تسبيح الآن
                              </button>
                            </div>

                            <div className="flex items-center justify-between pt-2.5 mt-2 text-xs text-[#77798C] border-t border-[#E6E6F0]">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-[#5B5FEF] tabular-nums">
                                  الهدف: {item.target === 0 ? 'مفتوح (∞)' : `${item.target} مرة`}
                                </span>
                                <span>·</span>
                                <span className="tabular-nums">
                                  مرات الإنجاز: {item.usage_count || 0}
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingDhikrId(item.id);
                                    setEditDhikrText(item.text);
                                    setEditDhikrTarget(item.target);
                                    setEditWirdType(item.wird_type || 'daily');
                                    setEditDhikrListName(item.list_name);
                                    setEditDhikrNotes(item.notes || '');
                                  }}
                                  className="p-1.5 rounded-lg hover:bg-[#EEEEFF] text-[#5B5FEF] cursor-pointer transition-colors"
                                  title="تعديل هذا الذكر"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeleteConfirmId(item.id)}
                                  className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600 cursor-pointer transition-colors"
                                  title="حذف هذا الذكر"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* تأكيد الحذف */}
                            {isConfirmingDelete && (
                              <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-900 animate-fade-in">
                                <span className="font-bold">
                                  هل أنت متأكد من حذف هذا الذكر من الورد؟
                                </span>
                                <div className="flex items-center gap-2">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteCustomDhikr(item.id)}
                                    className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold text-xs cursor-pointer"
                                  >
                                    نعم، احذف
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeleteConfirmId(null)}
                                    className="px-2.5 py-1 bg-gray-200 text-gray-700 rounded-lg font-bold text-xs cursor-pointer"
                                  >
                                    تراجع
                                  </button>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 3: الإعدادات (SETTINGS)】
            • أصوات النقر: خشبي (افتراضي) | ماء | جرس ذهبي | صامت + مستوى الصوت (Slider)
            • الاهتزاز: خفيف | متوسط | قوي | بدون
            • ثيمات المسبحة: ذهبي كلاسيكي | أخضر زمردي | أزرق ملكي | بني دافئ | وردي هادئ
            • إعادة تعيين: تصفير العداد | تصفير الإحصائيات (مع تأكيد)
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'settings' && (
          <div className="space-y-4 animate-fade-in">
            {/* 1. أصوات النقر ومستوى الصوت */}
            <div className={`${cardSurfaceClass} p-5 space-y-4`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <div className="flex items-center gap-2">
                  {dbSettings.sound === 'silent' ? (
                    <VolumeX className="w-5 h-5 text-[#77798C]" />
                  ) : (
                    <Volume2 className="w-5 h-5 text-[#5B5FEF]" />
                  )}
                  <h2 className="font-cairo font-bold text-base">أصوات النقر ومستوى الصوت</h2>
                </div>
                <span className="text-xs font-cairo font-bold text-[#5B5FEF] tabular-nums">
                  {dbSettings.sound_volume}%
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    { id: 'wood', label: 'خشبي (افتراضي)' },
                    { id: 'water', label: 'ماء' },
                    { id: 'golden_bell', label: 'جرس ذهبي' },
                    { id: 'silent', label: 'صامت' },
                  ] as { id: MisbahaSoundOption; label: string }[]
                ).map((snd) => {
                  const active = dbSettings.sound === snd.id;
                  return (
                    <button
                      key={snd.id}
                      type="button"
                      onClick={() => {
                        updateMisbahaSettingsInSqlite({ sound: snd.id });
                        onUpdateSettings({
                          soundEnabled: snd.id !== 'silent',
                          soundType: snd.id,
                        });
                        if (snd.id !== 'silent') {
                          soundManager.playBeadClick(
                            (dbSettings.sound_volume ?? 75) / 100,
                            snd.id
                          );
                        }
                        refreshSqliteState();
                      }}
                      className={`py-2.5 px-3 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer ${
                        active
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:bg-[#EEEEFF]'
                      }`}
                    >
                      {snd.label}
                    </button>
                  );
                })}
              </div>

              {/* Volume Slider */}
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-xs font-cairo">
                  <span>مستوى الصوت</span>
                  <span className="font-bold tabular-nums">{dbSettings.sound_volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={dbSettings.sound_volume}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    updateMisbahaSettingsInSqlite({ sound_volume: val });
                    onUpdateSettings({ soundVolume: val / 100 });
                    refreshSqliteState();
                  }}
                  onMouseUp={() => {
                    if (dbSettings.sound !== 'silent') {
                      soundManager.playBeadClick(
                        (dbSettings.sound_volume ?? 75) / 100,
                        dbSettings.sound
                      );
                    }
                  }}
                  className="w-full accent-[#E99AC7] cursor-pointer"
                />
              </div>
            </div>

            {/* 2. مستوى الاهتزاز */}
            <div className={`${cardSurfaceClass} p-5 space-y-3.5`}>
              <div className="flex items-center gap-2 border-b border-[#E6E6F0] pb-2.5">
                <Smartphone className="w-5 h-5 text-[#5B5FEF]" />
                <h2 className="font-cairo font-bold text-base">قوة الاهتزاز عند التسبيح</h2>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {(
                  [
                    { id: 'light', label: 'خفيف' },
                    { id: 'medium', label: 'متوسط' },
                    { id: 'strong', label: 'قوي' },
                    { id: 'none', label: 'بدون' },
                  ] as { id: MisbahaVibrationOption; label: string }[]
                ).map((vib) => {
                  const active = dbSettings.vibration === vib.id;
                  return (
                    <button
                      key={vib.id}
                      type="button"
                      onClick={() => {
                        updateMisbahaSettingsInSqlite({ vibration: vib.id });
                        onUpdateSettings({
                          vibrationEnabled: vib.id !== 'none',
                          vibrationLevel: vib.id,
                        });
                        soundManager.triggerVibrationByLevel(vib.id);
                        refreshSqliteState();
                      }}
                      className={`py-2.5 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer ${
                        active
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] hover:bg-[#EEEEFF]'
                      }`}
                    >
                      {vib.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. ثيمات المسبحة الخمسة */}
            <div className={`${cardSurfaceClass} p-5 space-y-3.5`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <h2 className="font-cairo font-bold text-base">ثيمات المسبحة</h2>
                <span className="text-xs text-[#77798C] font-cairo">{activeTheme.nameAr}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {ROSARY_THEMES.map((theme) => {
                  const isSelected = dbSettings.theme === theme.id;
                  return (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() => {
                        updateMisbahaSettingsInSqlite({ theme: theme.id as RosaryThemeId });
                        onUpdateSettings({ rosaryTheme: theme.id as RosaryThemeId });
                        refreshSqliteState();
                        showToast(`تم تفعيل ثيم: ${theme.nameAr}`);
                      }}
                      className={`p-3 rounded-2xl border text-right flex items-center justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#5B5FEF] bg-[#EEEEFF] font-bold'
                          : 'border-[#E6E6F0] hover:bg-[#F7F7FC]/60'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-7 h-7 rounded-full border-2 border-white shadow-xs shrink-0"
                          style={{ backgroundColor: theme.previewColor }}
                        />
                        <div>
                          <div className="text-xs font-cairo font-bold">{theme.nameAr}</div>
                          <div className="text-[10px] text-[#77798C] font-cairo">
                            {theme.subtitleAr}
                          </div>
                        </div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-[#4145C7] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. إعادة التعيين (تصفير العداد + تصفير الإحصائيات مع تأكيد) */}
            <div className={`${cardSurfaceClass} p-5 space-y-3 border-[#D95C6A]/40`}>
              <div className="flex items-center gap-2 text-[#D95C6A]">
                <AlertTriangle className="w-5 h-5" />
                <h2 className="font-cairo font-bold text-base">إعادة التعيين والتصفير</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setConfirmModalType('reset_counter')}
                  className="py-3 px-4 rounded-xl bg-[#F7F7FC] hover:bg-[#D95C6A]/10 text-[#25263A] border border-[#E6E6F0] text-xs font-cairo font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4 text-[#D95C6A]" />
                  <span>تصفير العداد الحالي</span>
                </button>

                <button
                  type="button"
                  onClick={() => setConfirmModalType('reset_stats')}
                  className="py-3 px-4 rounded-xl bg-[#D95C6A] hover:bg-[#D95C6A] text-white text-xs font-cairo font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>تصفير جميع الإحصائيات والسجل</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 4: الإحصائيات المتقدمة + الإنجازات النصية + السلسلة + المشاركة】
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'stats' && (
          <div className="space-y-4 animate-fade-in">
            {/* 1. ملخص الفترات الزمنية: اليوم | الأسبوع | الشهر | السنة */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { label: 'اليوم', val: advancedStats.todayCount },
                { label: 'الأسبوع', val: advancedStats.weekCount },
                { label: 'الشهر', val: advancedStats.monthCount },
                { label: 'السنة', val: advancedStats.yearCount },
              ].map((stat) => (
                <div key={stat.label} className={`${cardSurfaceClass} p-4 text-center`}>
                  <div className="font-cairo font-bold text-2xl text-[#5B5FEF] tabular-nums">
                    {stat.val}
                  </div>
                  <div className="text-xs text-[#77798C] font-cairo font-bold mt-1">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

            {/* 2. بطاقة السلسلة (أيام متتالية + أطول سلسلة + نص تحفيزي) */}
            <div className={`${cardSurfaceClass} p-5 space-y-3`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-[#5B5FEF]" />
                  <h3 className="font-cairo font-bold text-base">سلسلة المواظبة اليومية</h3>
                </div>
                <span className="text-xs font-cairo font-bold text-[#4145C7]">
                  {advancedStats.motivationalText}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="p-3.5 rounded-2xl bg-[#F7F7FC] text-[#25263A] text-center">
                  <div className="font-cairo font-bold text-2xl text-[#5B5FEF] tabular-nums">
                    {advancedStats.currentStreak} يوم
                  </div>
                  <div className="text-xs font-cairo font-bold mt-0.5">الأيام المتتالية الحالية</div>
                </div>
                <div className="p-3.5 rounded-2xl bg-[#F7F7FC] text-[#25263A] text-center">
                  <div className="font-cairo font-bold text-2xl text-[#4145C7] tabular-nums">
                    {advancedStats.longestStreak} يوم
                  </div>
                  <div className="text-xs font-cairo font-bold mt-0.5">أطول سلسلة مسجلة</div>
                </div>
              </div>
            </div>

            {/* 3. الرسم البياني الأسبوعي التفاعلي (Recharts Weekly Bar / Area Chart) */}
            <div className={`${cardSurfaceClass} p-5 space-y-4`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E6F0] pb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#5B5FEF]" />
                  <div>
                    <h3 className="font-cairo font-bold text-base">
                      الرسم البياني الأسبوعي للتسبيحات (7 أيام)
                    </h3>
                    <span className="text-xs text-[#77798C] font-cairo tabular-nums">
                      إجمالي الأسبوع: {advancedStats.weekCount.toLocaleString('ar-EG')} تسبيحة
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl self-start sm:self-auto text-xs font-cairo font-bold">
                  <button
                    type="button"
                    onClick={() => setWeeklyRechartMode('bar')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      weeklyRechartMode === 'bar'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    أعمدة
                  </button>
                  <button
                    type="button"
                    onClick={() => setWeeklyRechartMode('area')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      weeklyRechartMode === 'area'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    منحنى
                  </button>
                </div>
              </div>

              <div className="w-full h-60 pt-2" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  {weeklyRechartMode === 'bar' ? (
                    <BarChart
                      data={advancedStats.weeklyChart}
                      margin={{ top: 10, right: 12, left: -18, bottom: 4 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                      <XAxis
                        dataKey="dayNameAr"
                        tick={{ fontSize: 11, fill: isDarkMode ? '#F7F7FC' : '#25263A', fontWeight: 700 }}
                        tickLine={false}
                        axisLine={{ stroke: '#E99AC7' }}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: '#77798C' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      {dbSettings.daily_target > 0 && (
                        <ReferenceLine
                          y={dbSettings.daily_target}
                          stroke="#5B5FEF"
                          strokeDasharray="4 4"
                          strokeWidth={1.5}
                        />
                      )}
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const day = payload[0].payload as (typeof advancedStats.weeklyChart)[0];
                            return (
                              <div
                                className="bg-white text-[#25263A] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                                dir="rtl"
                              >
                                <p className="font-bold border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                                  <span>{day.dayNameAr}</span>
                                  <span className="text-[#77798C] tabular-nums">{day.date.slice(5)}</span>
                                </p>
                                <div className="flex items-center justify-between gap-3 font-bold">
                                  <span className="text-[#77798C]">التسبيحات:</span>
                                  <span className="text-sm text-[#4145C7] tabular-nums">
                                    {day.count.toLocaleString('ar-EG')}
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="count" name="التسبيحات" radius={[8, 8, 0, 0]} maxBarSize={42}>
                        {advancedStats.weeklyChart.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={entry.isToday ? '#5B5FEF' : '#E99AC7'}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  ) : (
                    <AreaChart
                      data={advancedStats.weeklyChart}
                      margin={{ top: 10, right: 12, left: -18, bottom: 4 }}
                    >
                      <defs>
                        <linearGradient id="misbahaWeeklyArea" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#E99AC7" stopOpacity={0.55} />
                          <stop offset="95%" stopColor="#E99AC7" stopOpacity={0.05} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                      <XAxis
                        dataKey="dayNameAr"
                        tick={{ fontSize: 11, fill: isDarkMode ? '#F7F7FC' : '#25263A', fontWeight: 700 }}
                        tickLine={false}
                        axisLine={{ stroke: '#E99AC7' }}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: '#77798C' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      {dbSettings.daily_target > 0 && (
                        <ReferenceLine
                          y={dbSettings.daily_target}
                          stroke="#5B5FEF"
                          strokeDasharray="4 4"
                          strokeWidth={1.5}
                        />
                      )}
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const day = payload[0].payload as (typeof advancedStats.weeklyChart)[0];
                            return (
                              <div
                                className="bg-white text-[#25263A] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                                dir="rtl"
                              >
                                <p className="font-bold border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                                  <span>{day.dayNameAr}</span>
                                  <span className="text-[#77798C] tabular-nums">{day.date.slice(5)}</span>
                                </p>
                                <div className="flex items-center justify-between gap-3 font-bold">
                                  <span className="text-[#77798C]">التسبيحات:</span>
                                  <span className="text-sm text-[#5B5FEF] tabular-nums">
                                    {day.count.toLocaleString('ar-EG')}
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="count"
                        stroke="#5B5FEF"
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#misbahaWeeklyArea)"
                        activeDot={{ r: 5, fill: '#5B5FEF', stroke: '#FFFFFF', strokeWidth: 2 }}
                      />
                    </AreaChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>

            {/* 3-ب. الرسم البياني للتوزيع اليومي على مدار 24 ساعة (Recharts Daily Hourly Chart) */}
            <div className={`${cardSurfaceClass} p-5 space-y-4`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E6F0] pb-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-[#4145C7]" />
                  <div>
                    <h3 className="font-cairo font-bold text-base">
                      التمثيل البياني للتسبيحات اليومية (حسب الساعات)
                    </h3>
                    <span className="text-xs text-[#77798C] font-cairo tabular-nums">
                      توزيع تسبيحات اليوم ({advancedStats.todayCount.toLocaleString('ar-EG')}) على مدار 24 ساعة
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl self-start sm:self-auto text-xs font-cairo font-bold">
                  <button
                    type="button"
                    onClick={() => setDailyRechartMode('area')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      dailyRechartMode === 'area'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    منحنى
                  </button>
                  <button
                    type="button"
                    onClick={() => setDailyRechartMode('bar')}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      dailyRechartMode === 'bar'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    أعمدة
                  </button>
                </div>
              </div>

              <div className="w-full h-56 pt-2" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  {dailyRechartMode === 'area' ? (
                    <AreaChart
                      data={advancedStats.todayHourlyChart}
                      margin={{ top: 10, right: 12, left: -20, bottom: 4 }}
                    >
                      <defs>
                        <linearGradient id="misbahaDailyHourlyGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#5B5FEF" stopOpacity={0.45} />
                          <stop offset="95%" stopColor="#E99AC7" stopOpacity={0.04} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 10, fill: '#77798C' }}
                        tickLine={false}
                        interval={3}
                        axisLine={{ stroke: '#E99AC7' }}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#77798C' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const h = payload[0].payload as (typeof advancedStats.todayHourlyChart)[0];
                            return (
                              <div
                                className="bg-white text-[#25263A] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                                dir="rtl"
                              >
                                <p className="font-bold border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                                  <span>الساعة {h.label}</span>
                                  <span className="text-[#77798C]">{h.periodAr}</span>
                                </p>
                                <div className="flex items-center justify-between gap-3 font-bold">
                                  <span className="text-[#77798C]">التسبيحات:</span>
                                  <span className="text-sm text-[#4145C7] tabular-nums">
                                    {h.count.toLocaleString('ar-EG')}
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="count"
                        stroke="#5B5FEF"
                        strokeWidth={2.5}
                        fillOpacity={1}
                        fill="url(#misbahaDailyHourlyGrad)"
                        activeDot={{ r: 5, fill: '#E99AC7', stroke: '#5B5FEF', strokeWidth: 2 }}
                      />
                    </AreaChart>
                  ) : (
                    <BarChart
                      data={advancedStats.todayHourlyChart}
                      margin={{ top: 10, right: 12, left: -20, bottom: 4 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 10, fill: '#77798C' }}
                        tickLine={false}
                        interval={3}
                        axisLine={{ stroke: '#E99AC7' }}
                      />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#77798C' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const h = payload[0].payload as (typeof advancedStats.todayHourlyChart)[0];
                            return (
                              <div
                                className="bg-white text-[#25263A] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                                dir="rtl"
                              >
                                <p className="font-bold border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                                  <span>الساعة {h.label}</span>
                                  <span className="text-[#77798C]">{h.periodAr}</span>
                                </p>
                                <div className="flex items-center justify-between gap-3 font-bold">
                                  <span className="text-[#77798C]">التسبيحات:</span>
                                  <span className="text-sm text-[#5B5FEF] tabular-nums">
                                    {h.count.toLocaleString('ar-EG')}
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="count" fill="#E99AC7" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  )}
                </ResponsiveContainer>
              </div>
            </div>

            {/* 4. التمثيل البياني لأكثر الأذكار استخداماً (Recharts Horizontal Bar Chart) */}
            <div className={`${cardSurfaceClass} p-5 space-y-3`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <h3 className="font-cairo font-bold text-base">التمثيل البياني لأكثر الأذكار استخداماً</h3>
                <button
                  type="button"
                  onClick={() => onNavigate('stats')}
                  className="text-xs font-cairo font-bold text-[#4145C7] hover:underline cursor-pointer"
                >
                  فتح لوحة الإحصائيات الشاملة
                </button>
              </div>
              {advancedStats.mostUsedAdhkar.length === 0 ? (
                <p className="text-xs text-[#77798C] font-cairo py-4 text-center">
                  لا توجد بيانات مسجلة بعد. ابدأ التسبيح لتظهر إحصائيات الأذكار بيانياً هنا.
                </p>
              ) : (
                <div className="w-full h-56 pt-2" dir="ltr">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={advancedStats.mostUsedAdhkar}
                      layout="vertical"
                      margin={{ top: 5, right: 16, left: 8, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E6E6F0" />
                      <XAxis
                        type="number"
                        tick={{ fontSize: 11, fill: '#77798C' }}
                        tickLine={false}
                        axisLine={{ stroke: '#E99AC7' }}
                        allowDecimals={false}
                      />
                      <YAxis
                        type="category"
                        dataKey="shortDhikr"
                        width={125}
                        tick={{ fontSize: 11, fill: isDarkMode ? '#F7F7FC' : '#25263A', fontWeight: 700 }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const item = payload[0].payload as (typeof advancedStats.mostUsedAdhkar)[0];
                            return (
                              <div
                                className="bg-white text-[#25263A] p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs max-w-xs"
                                dir="rtl"
                              >
                                <p className="font-amiri font-bold text-sm mb-1 border-b border-[#E6E6F0] pb-1">
                                  {item.dhikr}
                                </p>
                                <div className="flex items-center justify-between gap-3 font-bold">
                                  <span className="text-[#77798C]">العدد:</span>
                                  <span className="text-[#4145C7] tabular-nums">
                                    {item.count.toLocaleString('ar-EG')} تسبيحة ({item.percentage}%)
                                  </span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="count" radius={[0, 8, 8, 0]} maxBarSize={26}>
                        {advancedStats.mostUsedAdhkar.map((_, idx) => (
                          <Cell
                            key={`adhkar-cell-${idx}`}
                            fill={idx === 0 ? '#5B5FEF' : '#E99AC7'}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* 5. الإنجازات (بدون شارات — نصوص صريحة فقط) */}
            <div className={`${cardSurfaceClass} p-5 space-y-3`}>
              <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                <h3 className="font-cairo font-bold text-base">الإنجازات</h3>
                <span className="text-xs text-[#77798C] font-cairo">
                  مكتمل: {advancedStats.achievements.filter((a) => a.completed).length} من{' '}
                  {advancedStats.achievements.length}
                </span>
              </div>

              <div className="divide-y divide-[#E99AC7]/20">
                {advancedStats.achievements.map((ach) => (
                  <div key={ach.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <p
                        className={`font-cairo font-bold text-sm ${
                          ach.completed ? 'text-[#4145C7]' : ''
                        }`}
                      >
                        {ach.title}
                      </p>
                      <p className="text-xs text-[#77798C] font-cairo">{ach.description}</p>
                    </div>
                    <div className="text-left shrink-0 font-cairo">
                      <span
                        className={`text-xs font-bold tabular-nums ${
                          ach.completed ? 'text-[#4145C7]' : 'text-[#5B5FEF]'
                        }`}
                      >
                        {ach.completed ? 'مكتمل' : `${ach.current} / ${ach.target}`}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 6. أزرار مشاركة الإنجاز ومشاركة الإحصائيات كصورة */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleShareAchievementText}
                className="py-3.5 px-4 rounded-2xl bg-[#5B5FEF] hover:bg-[#b8963b] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>مشاركة الإنجاز</span>
              </button>

              <button
                type="button"
                onClick={handleShareStatsAsImage}
                className="py-3.5 px-4 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>مشاركة الإحصائيات كصورة</span>
              </button>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 5: السجل (HISTORY — جدول misbaha_sessions)】
            • كل الجلسات
            • التاريخ والوقت
            • الذكر
            • عدد التسبيحات
            • المدة
            • زر حذف
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'history' && (
          <div className={`${cardSurfaceClass} p-5 space-y-4 animate-fade-in`}>
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#5B5FEF]" />
                <h2 className="font-cairo font-bold text-base">سجل جلسات التسبيح</h2>
              </div>
              <span className="text-xs text-[#77798C] font-cairo tabular-nums">
                {sqliteData.sessions.length} جلسة
              </span>
            </div>

            {sqliteData.sessions.length === 0 ? (
              <div className="py-10 text-center space-y-1.5">
                <p className="font-cairo font-bold text-sm text-[#77798C]">
                  لا توجد جلسات مسجلة في السجل حتى الآن
                </p>
                <p className="text-xs text-[#77798C]">
                  عند إتمام دورة كاملة أو تصفير العداد بعد التسبيح، تُحفظ الجلسة هنا تلقائياً مع مدتها الزمنية
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {sqliteData.sessions.map((sess) => {
                  const dateObj = new Date(sess.created_at);
                  const formattedDate = dateObj.toLocaleDateString('ar-EG', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  });

                  return (
                    <div
                      key={sess.id}
                      className="p-3.5 rounded-2xl border border-[#E6E6F0] flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1 space-y-1">
                        <p className="font-amiri font-bold text-base truncate">{sess.dhikr}</p>
                        <div className="flex items-center flex-wrap gap-1.5 text-xs text-[#77798C] font-cairo tabular-nums">
                          <span>العدد: {sess.count}</span>
                          <span>·</span>
                          <span>الهدف: {sess.target === 0 ? 'مفتوح' : sess.target}</span>
                          <span>·</span>
                          <span>المدة: {formatSessionDuration(sess.duration)}</span>
                          <span>·</span>
                          <span>{formattedDate}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          deleteMisbahaSessionFromSqlite(sess.id);
                          refreshSqliteState();
                          showToast('تم حذف الجلسة من السجل');
                        }}
                        className="p-2 rounded-xl hover:bg-[#D95C6A]/15 text-[#D95C6A] transition-colors shrink-0 cursor-pointer"
                        title="حذف الجلسة"
                        aria-label="حذف الجلسة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            【الشاشة الفرعية 6: حصن المسلم السريع (HISN AL-MUSLIM QUICK)】
           ══════════════════════════════════════════════════════════════════ */}
        {activeSubScreen === 'hisn_quick' && (
          <div className="space-y-3.5 animate-fade-in">
            <div className={`${cardSurfaceClass} p-4 flex items-center justify-between`}>
              <div>
                <h2 className="font-cairo font-bold text-base">حصن المسلم السريع</h2>
                <p className="text-xs text-[#77798C] font-cairo">
                  اضغط على أي ذكر لبدء التسبيح به فوراً أو افتح موسوعة حصن المسلم الكاملة
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('hisn_almuslim')}
                className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold shrink-0 cursor-pointer"
              >
                الموسوعة الكاملة
              </button>
            </div>

            {QUICK_HISN_SUPPLICATIONS.map((item) => (
              <div key={item.id} className={`${cardSurfaceClass} p-4 space-y-2.5`}>
                <div className="flex items-center justify-between text-xs text-[#77798C] font-cairo">
                  <span>
                    {item.category} · {item.title}
                  </span>
                  <span className="tabular-nums">التكرار: {item.target}</span>
                </div>
                <p className="font-amiri text-xl leading-relaxed font-bold">{item.text}</p>
                <div className="flex items-center justify-between pt-2 border-t border-[#E6E6F0]">
                  <span className="text-xs text-[#77798C] font-cairo">المصدر: {item.source}</span>
                  <button
                    type="button"
                    onClick={() => {
                      handleSelectDhikr(item.text, item.target);
                      setActiveSubScreen('main');
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-cairo font-bold cursor-pointer"
                  >
                    تسبيح بهذا الذكر
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          نوافذ التأكيد (تصفير العداد / تصفير الإحصائيات)
         ══════════════════════════════════════════════════════════════════ */}
      {confirmModalType && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
          dir="rtl"
        >
          <div className="bg-white text-[#25263A] rounded-[24px] p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] space-y-4">
            <div className="flex items-center justify-between">
              <div className="w-11 h-11 rounded-2xl bg-[#D95C6A]/10 text-[#D95C6A] flex items-center justify-center">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <button
                type="button"
                onClick={() => setConfirmModalType(null)}
                className="p-1.5 rounded-lg text-[#77798C] hover:bg-gray-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-1.5">
              <h3 className="font-cairo font-bold text-base text-[#25263A]">
                {confirmModalType === 'reset_counter'
                  ? 'تأكيد تصفير العداد الحالي'
                  : 'تأكيد تصفير جميع الإحصائيات والسجل'}
              </h3>
              <p className="text-xs text-[#77798C] font-cairo leading-relaxed">
                {confirmModalType === 'reset_counter'
                  ? 'هل تريد إعادة تعيين العداد الحالي إلى الصفر؟ سيتم حفظ الجلسة الحالية في السجل ولن تفقد إحصائياتك العامة.'
                  : 'تحذير: سيؤدي هذا الإجراء إلى مسح سجل الجلسات وتصفير جميع الإحصائيات والدورات والسلسلة بالكامل. هل أنت متأكد؟'}
              </p>
            </div>

            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (confirmModalType === 'reset_counter') {
                    resetMisbahaCurrentCounter(true);
                    onResetCounter();
                    refreshSqliteState();
                    showToast('تم تصفير العداد الحالي وحفظ الجلسة');
                  } else {
                    resetAllMisbahaStatistics();
                    onResetCounter();
                    refreshSqliteState();
                    showToast('تم تصفير جميع الإحصائيات والسجل');
                  }
                  setConfirmModalType(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-[#D95C6A] hover:bg-[#D95C6A] text-white font-cairo font-bold text-xs cursor-pointer"
              >
                {confirmModalType === 'reset_counter' ? 'تصفير العداد' : 'نعم، تصفير الكل'}
              </button>

              <button
                type="button"
                onClick={() => setConfirmModalType(null)}
                className="flex-1 py-2.5 rounded-xl bg-[#F7F7FC] hover:bg-gray-200 text-[#25263A] font-cairo font-bold text-xs cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* نافذة اختيار وتخصيص الأذكار والأوراد الكاملة */}
      <DhikrSelectorModal
        isOpen={isDhikrModalOpen}
        onClose={() => setIsDhikrModalOpen(false)}
        selectedDhikr={currentDhikr}
        onSelectDhikr={(text, target) => {
          handleSelectDhikr(text, target || currentTarget);
          setIsDhikrModalOpen(false);
        }}
      />
    </div>
  );
};
