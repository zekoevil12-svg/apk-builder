import React, { useState, useEffect, useCallback } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  Sparkles,
  CheckCircle2,
  Droplets,
  BookOpen,
  Award,
  BarChart3,
  HeartHandshake,
} from 'lucide-react';
import { WuduGuideView } from './WuduGuideView';
import { PrayerGuideView } from './PrayerGuideView';
import { PrayerAthkarView } from './PrayerAthkarView';
import { InteractiveQuizView } from './InteractiveQuizView';
import { MyProgressView } from './MyProgressView';
import { WuduPrayerIllustration, IllustrationType } from './WuduPrayerIllustration';
import { WuduPrayerSectionSvg } from '../Home/RifqSectionIcons';
import {
  PrayerWuduLearningData,
  loadLocalPrayerWuduProgress,
  syncPrayerWuduProgressWithFirestore,
  subscribeToPrayerWuduProgress,
  hasAnyLearningActivity,
} from '../../utils/wuduPrayerLearningService';

interface WuduPrayerMainViewProps {
  onBackToHome: () => void;
}

type ActiveSubScreen = 'hub' | 'wudu' | 'prayer' | 'athkar' | 'review' | 'progress';

interface HubCardDefinition {
  id: Exclude<ActiveSubScreen, 'hub'>;
  title: string;
  description: string;
  buttonText: string;
  illustrationType: IllustrationType;
  accentColor: string;
  badgeText: (data: PrayerWuduLearningData) => string;
  isCompleted: (data: PrayerWuduLearningData) => boolean;
  iconNode: React.ReactNode;
}

const HUB_CARDS: HubCardDefinition[] = [
  {
    id: 'wudu',
    title: '💧 تعلّم الوضوء',
    description: 'تعلّم خطوات الوضوء التسع بالترتيب الصحيح مع الرسومات التوضيحية والشرح البسيط لكل خطوة.',
    buttonText: 'ابدأ درس الوضوء',
    illustrationType: 'card_wudu',
    accentColor: '#72B7E8',
    badgeText: (d) => `${d.wuduProgress.completedStepNumbers.length} / 9 خطوات`,
    isCompleted: (d) => d.wuduProgress.isCompleted,
    iconNode: <Droplets className="w-5 h-5 text-[#0288D1]" />,
  },
  {
    id: 'prayer',
    title: '🕌 تعلّم الصلاة',
    description: 'تعلّم الصلوات الخمس (الفجر، الظهر، العصر، المغرب، العشاء)، عدد ركعاتها، وحركاتها وما نقوله فيها.',
    buttonText: 'ادخل تعلّم الصلاة',
    illustrationType: 'card_prayer',
    accentColor: '#5B5FEF',
    badgeText: (d) => {
      const doneCount = Object.values(d.prayerProgress || {}).filter((p) => p?.isCompleted).length;
      return `${doneCount} / 5 صلوات`;
    },
    isCompleted: (d) =>
      Object.values(d.prayerProgress || {}).filter((p) => p?.isCompleted).length >= 5,
    iconNode: <Sparkles className="w-5 h-5 text-[#5B5FEF]" />,
  },
  {
    id: 'athkar',
    title: '🤲 أذكار الصلاة',
    description: 'الأذكار والأدعية النبوية الصحيحة المرتبطة بالوضوء وداخل الصلاة وبعد السلام منها.',
    buttonText: 'استعرض أذكار الصلاة',
    illustrationType: 'card_athkar',
    accentColor: '#E8B84A',
    badgeText: (d) =>
      d.completedLessons.includes('athkar_prayer') ? 'مكتمل ✓' : 'أذكار موثقة',
    isCompleted: (d) => d.completedLessons.includes('athkar_prayer'),
    iconNode: <HeartHandshake className="w-5 h-5 text-[#B78103]" />,
  },
  {
    id: 'review',
    title: '📚 المراجعة',
    description: 'راجع خطوات الوضوء وحركات الصلاة بالصور، وشارك في تمارين الترتيب التفاعلية وأسئلة المراجعة.',
    buttonText: 'ابدأ المراجعة والتمارين',
    illustrationType: 'card_review',
    accentColor: '#4CAF82',
    badgeText: (d) =>
      d.quizResults.length > 0 ? `${d.quizResults.length} مراجعة مكتملة` : 'تمارين تفاعلية',
    isCompleted: (d) => d.completedLessons.includes('review'),
    iconNode: <BookOpen className="w-5 h-5 text-[#2E8B62]" />,
  },
  {
    id: 'progress',
    title: '📊 تقدمي',
    description: 'تابع تقدمك الحقيقي في خطوات الوضوء، والصلوات الخمس، والدروس المكتملة، ونتائج المراجعة.',
    buttonText: 'شاهد تقدمي',
    illustrationType: 'card_progress',
    accentColor: '#5B5FEF',
    badgeText: (d) =>
      hasAnyLearningActivity(d)
        ? `${d.completedSteps.length} خطوة منجزة`
        : 'ابدأ أول درس 🌱',
    isCompleted: (d) => d.completedLessons.length >= 3,
    iconNode: <BarChart3 className="w-5 h-5 text-[#5B5FEF]" />,
  },
];

export const WuduPrayerMainView: React.FC<WuduPrayerMainViewProps> = ({ onBackToHome }) => {
  const [activeScreen, setActiveScreen] = useState<ActiveSubScreen>('hub');
  const [progressData, setProgressData] = useState<PrayerWuduLearningData>(() =>
    loadLocalPrayerWuduProgress()
  );

  // Sync with Firebase Firestore on mount and subscribe to real-time updates
  useEffect(() => {
    syncPrayerWuduProgressWithFirestore()
      .then((fresh) => setProgressData(fresh))
      .catch(() => {});

    const unsubscribe = subscribeToPrayerWuduProgress((fresh) => {
      setProgressData(fresh);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleProgressUpdated = useCallback((next: PrayerWuduLearningData) => {
    setProgressData(next);
  }, []);

  if (activeScreen === 'wudu') {
    return (
      <WuduGuideView
        onBack={() => setActiveScreen('hub')}
        onGoToQuiz={() => setActiveScreen('review')}
        progressData={progressData}
        onProgressUpdated={handleProgressUpdated}
      />
    );
  }

  if (activeScreen === 'prayer') {
    return (
      <PrayerGuideView
        onBack={() => setActiveScreen('hub')}
        onGoToQuiz={() => setActiveScreen('review')}
        progressData={progressData}
        onProgressUpdated={handleProgressUpdated}
      />
    );
  }

  if (activeScreen === 'athkar') {
    return (
      <PrayerAthkarView
        onBack={() => setActiveScreen('hub')}
        progressData={progressData}
        onProgressUpdated={handleProgressUpdated}
      />
    );
  }

  if (activeScreen === 'review') {
    return (
      <InteractiveQuizView
        onBack={() => setActiveScreen('hub')}
        progressData={progressData}
        onProgressUpdated={handleProgressUpdated}
      />
    );
  }

  if (activeScreen === 'progress') {
    return (
      <MyProgressView
        onBack={() => setActiveScreen('hub')}
        onStartWuduLesson={() => setActiveScreen('wudu')}
        onStartPrayerLesson={() => setActiveScreen('prayer')}
        progressData={progressData}
      />
    );
  }

  return (
    <div className="space-y-6 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي للشاشة الرئيسية للقسم */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 md:p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToHome}
            aria-label="الرجوع للرئيسية"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-cairo font-bold border border-[#E6E6F0] dark:border-stone-700 hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer"
          >
            <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
            <span className="text-xs md:text-sm">الرئيسية</span>
          </button>

          <div className="flex items-center gap-2.5">
            <WuduPrayerSectionSvg size={42} />
            <div>
              <h1 className="text-lg sm:text-xl md:text-2xl font-black font-cairo text-[#25263A] dark:text-stone-100">
                🕌 تعلّم الوضوء والصلاة
              </h1>
              <p className="text-xs md:text-sm font-cairo font-bold text-[#6F7285] dark:text-stone-400 mt-0.5">
                اتعلّم الوضوء والصلاة خطوة بخطوة بطريقة سهلة وممتعة.
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setActiveScreen('progress')}
          className="px-3.5 py-2 rounded-xl bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 font-cairo font-black text-xs flex items-center gap-1.5 cursor-pointer hover:brightness-95 transition-all"
        >
          <Award className="w-4 h-4" />
          <span>
            {hasAnyLearningActivity(progressData)
              ? `تقدمي (${progressData.completedSteps.length} خطوة)`
              : 'سجل تقدمي'}
          </span>
        </button>
      </div>

      {/* لوحة ترحيبية بصرية للأطفال */}
      <div className="relative overflow-hidden rounded-[26px] bg-gradient-to-l from-[#EEEEFF] via-white to-[#EAF7F0] dark:from-stone-900 dark:via-stone-900 dark:to-stone-800 p-5 md:p-7 border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-3 max-w-xl text-center md:text-right">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-white dark:bg-stone-800 border border-[#E6E6F0] dark:border-stone-700 text-[#4145C7] dark:text-amber-300 text-xs font-cairo font-black shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
              <span>دليل بصري تفاعلي مبسّط للأطفال بالرسومات الأصلية</span>
            </span>

            <h2 className="text-xl md:text-2xl font-black font-cairo text-[#25263A] dark:text-stone-100 leading-snug">
              🕌 تعلّم الوضوء والصلاة
            </h2>

            <p className="text-xs md:text-base font-cairo font-bold text-[#6F7285] dark:text-stone-300 leading-relaxed">
              اتعلّم الوضوء والصلاة خطوة بخطوة بطريقة سهلة وممتعة.
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setActiveScreen('wudu')}
                className="px-5 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-xs md:text-sm shadow-md hover:brightness-105 active:scale-95 transition-all cursor-pointer"
              >
                💧 ابدأ بتعلّم الوضوء
              </button>
              <button
                type="button"
                onClick={() => setActiveScreen('prayer')}
                className="px-5 py-3 rounded-2xl bg-[#4CAF82] text-white font-cairo font-black text-xs md:text-sm shadow-md hover:brightness-105 active:scale-95 transition-all cursor-pointer"
              >
                🕌 ابدأ بتعلّم الصلاة
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <WuduPrayerIllustration type="hands" size={115} />
            <WuduPrayerIllustration type="takbeer" size={115} />
          </div>
        </div>
      </div>

      {/* البطاقات الخمس الكبيرة للأجزاء الأساسية */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {HUB_CARDS.map((card, index) => {
          const completed = card.isCompleted(progressData);
          const isWideLast = index === HUB_CARDS.length - 1;

          return (
            <div
              key={card.id}
              onClick={() => setActiveScreen(card.id)}
              className={`group bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF] p-5 md:p-6 shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col sm:flex-row items-center justify-between gap-5 ${
                isWideLast ? 'md:col-span-2' : ''
              }`}
            >
              {/* الرسم التعليمي الأصلي للبطاقة */}
              <div className="shrink-0 flex flex-col items-center">
                <WuduPrayerIllustration
                  type={card.illustrationType}
                  size={112}
                  className="group-hover:scale-105 transition-transform"
                />
              </div>

              {/* محتوى البطاقة وزر الدخول */}
              <div className="flex-1 space-y-2.5 text-center sm:text-right w-full">
                <div className="flex flex-wrap items-center justify-center sm:justify-between gap-2">
                  <div className="inline-flex items-center gap-2">
                    <span className="w-9 h-9 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 border border-[#E6E6F0] dark:border-stone-700 flex items-center justify-center">
                      {card.iconNode}
                    </span>
                    <h3 className="font-cairo font-black text-lg md:text-xl text-[#25263A] dark:text-stone-100 group-hover:text-[#5B5FEF] transition-colors">
                      {card.title}
                    </h3>
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-cairo font-black border ${
                      completed
                        ? 'bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 border-[#4CAF82]/40'
                        : 'bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285] dark:text-stone-300 border-[#E6E6F0] dark:border-stone-700'
                    }`}
                  >
                    {completed && <CheckCircle2 className="w-3.5 h-3.5 text-[#4CAF82]" />}
                    <span>{card.badgeText(progressData)}</span>
                  </span>
                </div>

                <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300 leading-relaxed">
                  {card.description}
                </p>

                <div className="pt-1 flex justify-center sm:justify-end">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveScreen(card.id);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] group-hover:bg-[#4145C7] text-white font-cairo font-black text-xs md:text-sm shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
                  >
                    <span>{card.buttonText}</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
