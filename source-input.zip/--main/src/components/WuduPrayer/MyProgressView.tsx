import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Award,
  BookOpen,
  BarChart3,
  Sparkles,
} from 'lucide-react';
import { WUDU_STEPS, PRAYER_DEFINITIONS } from '../../data/wuduPrayerData';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';
import {
  PrayerWuduLearningData,
  hasAnyLearningActivity,
} from '../../utils/wuduPrayerLearningService';

interface MyProgressViewProps {
  onBack: () => void;
  onStartWuduLesson: () => void;
  onStartPrayerLesson: () => void;
  progressData: PrayerWuduLearningData;
}

function formatArabicTimestamp(iso: string | null): string {
  if (!iso) return 'لم يبدأ بعد';
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return 'لم يبدأ بعد';
    return new Intl.DateTimeFormat('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }).format(d);
  } catch {
    return iso.slice(0, 16).replace('T', ' ');
  }
}

export const MyProgressView: React.FC<MyProgressViewProps> = ({
  onBack,
  onStartWuduLesson,
  onStartPrayerLesson,
  progressData,
}) => {
  const hasActivity = hasAnyLearningActivity(progressData);
  const completedWuduCount = progressData.wuduProgress.completedStepNumbers.length;
  const totalWuduCount = WUDU_STEPS.length;
  const wuduPercent = Math.round((completedWuduCount / totalWuduCount) * 100);

  const completedPrayersList = PRAYER_DEFINITIONS.filter(
    (p) => progressData.prayerProgress[p.id]?.isCompleted
  );

  return (
    <div className="space-y-5 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer border border-[#E6E6F0] dark:border-stone-700"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-xs md:text-sm font-cairo">الرئيسية للقسم</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-xl font-black font-cairo text-[#25263A] dark:text-stone-100">
            📊 تقدمي في تعلّم الوضوء والصلاة
          </h2>
          <p className="text-[11px] md:text-xs text-[#6F7285] dark:text-stone-400 font-cairo">
            سجل تقدمك الفعلي المحفوظ في حسابك خطوة بخطوة
          </p>
        </div>

        <div className="w-16" />
      </div>

      {/* حالة فارغة حقيقية إذا لم يبدأ الطفل أي درس بعد */}
      {!hasActivity ? (
        <div className="bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-dashed border-[#E6E6F0] dark:border-stone-800 p-8 md:p-10 text-center space-y-5 shadow-xs">
          <div className="flex justify-center">
            <WuduPrayerIllustration type="card_progress" size={140} />
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="font-cairo font-black text-xl md:text-2xl text-[#25263A] dark:text-stone-100">
              لسه مبدأناش، ابدأ أول درس 🌱
            </h3>
            <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-400 leading-relaxed">
              لم تقم بفتح أي درس أو خطوة حتى الآن. ابدأ الآن بتعلّم الوضوء أو الصلاة خطوة بخطوة ليظهر تقدمك الحقيقي هنا!
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={onStartWuduLesson}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-sm shadow-md cursor-pointer hover:brightness-105 active:scale-95 transition-all"
            >
              💧 ابدأ أول درس: تعلّم الوضوء
            </button>
            <button
              type="button"
              onClick={onStartPrayerLesson}
              className="px-6 py-3.5 rounded-2xl bg-[#4CAF82] text-white font-cairo font-black text-sm shadow-md cursor-pointer hover:brightness-105 active:scale-95 transition-all"
            >
              🕌 ابدأ تعلّم الصلاة
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* بطاقة آخر نشاط وآخر درس وخطوة تم الوصول إليها */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div className="bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-cairo font-black text-[#5B5FEF]">
                <BookOpen className="w-4 h-4" />
                <span>آخر درس تم فتحه</span>
              </div>
              <p className="font-cairo font-black text-sm md:text-base text-[#25263A] dark:text-stone-100">
                {progressData.lastLesson || 'لم يحدد بعد'}
              </p>
            </div>

            <div className="bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-cairo font-black text-[#2E8B62]">
                <Sparkles className="w-4 h-4" />
                <span>آخر خطوة تم الوصول إليها</span>
              </div>
              <p className="font-cairo font-black text-sm md:text-base text-[#25263A] dark:text-stone-100">
                {progressData.lastStep || 'لم يحدد بعد'}
              </p>
            </div>

            <div className="bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-cairo font-black text-[#B78103]">
                <Clock className="w-4 h-4" />
                <span>آخر نشاط</span>
              </div>
              <p className="font-cairo font-bold text-xs md:text-sm text-[#25263A] dark:text-stone-100">
                {formatArabicTimestamp(progressData.lastOpenedAt)}
              </p>
            </div>
          </div>

          {/* تقدم خطوات الوضوء المكتملة */}
          <div className="bg-white dark:bg-[#1E1E1E] p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                  💧 خطوات الوضوء المكتملة ({completedWuduCount} من {totalWuduCount})
                </h3>
                <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-400">
                  {progressData.wuduProgress.isCompleted
                    ? 'أتممت جميع خطوات الوضوء التسع بنجاح!'
                    : 'أكمل بقية الخطوات لإتمام درس الوضوء كاملًا'}
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-black text-xs">
                {wuduPercent}%
              </span>
            </div>

            <div className="w-full h-3 bg-[#F7F7FC] dark:bg-stone-800 rounded-full overflow-hidden border border-[#E6E6F0] dark:border-stone-700">
              <div
                className="h-full bg-gradient-to-l from-[#72B7E8] via-[#5B5FEF] to-[#4CAF82] rounded-full transition-all duration-500"
                style={{ width: `${wuduPercent}%` }}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {WUDU_STEPS.map((s) => {
                const done = progressData.wuduProgress.completedStepNumbers.includes(
                  s.stepNumber
                );
                return (
                  <div
                    key={s.stepNumber}
                    className={`p-3 rounded-xl border flex items-center justify-between gap-2 text-xs font-cairo font-bold ${
                      done
                        ? 'bg-[#4CAF82]/10 border-[#4CAF82]/40 text-[#25263A] dark:text-stone-100'
                        : 'bg-[#F7F7FC] dark:bg-stone-900 border-[#E6E6F0] dark:border-stone-800 text-[#6F7285]'
                    }`}
                  >
                    <span>
                      {s.stepNumber}. {s.title}
                    </span>
                    {done && <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />}
                  </div>
                );
              })}
            </div>
          </div>

          {/* الصلوات الخمس التي تم تعلمها */}
          <div className="bg-white dark:bg-[#1E1E1E] p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                  🕌 الصلوات التي تم تعلمها ({completedPrayersList.length} من 5)
                </h3>
                <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-400">
                  تفصيل التقدم الحقيقي في كل صلاة من الصلوات الخمس
                </p>
              </div>
              <BarChart3 className="w-5 h-5 text-[#5B5FEF]" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {PRAYER_DEFINITIONS.map((p) => {
                const pProg = progressData.prayerProgress[p.id];
                const doneSteps = pProg?.completedStepIds?.length || 0;
                const totalSteps = pProg?.totalSteps || 16;
                const pct = Math.min(100, Math.round((doneSteps / totalSteps) * 100));

                return (
                  <div
                    key={p.id}
                    className={`p-3.5 rounded-2xl border flex flex-col items-center text-center gap-2 ${
                      pProg?.isCompleted
                        ? 'bg-[#4CAF82]/10 border-[#4CAF82]'
                        : 'bg-[#F7F7FC] dark:bg-stone-900 border-[#E6E6F0] dark:border-stone-800'
                    }`}
                  >
                    <WuduPrayerIllustration type={p.illustrationType} size={56} />
                    <span className="font-cairo font-black text-xs md:text-sm text-[#25263A] dark:text-stone-100">
                      {p.name}
                    </span>
                    <span className="text-[11px] font-cairo font-bold text-[#6F7285]">
                      {doneSteps} / {totalSteps} حركة ({pct}%)
                    </span>
                    <div className="w-full h-2 bg-white dark:bg-stone-800 rounded-full overflow-hidden border border-[#E6E6F0] dark:border-stone-700">
                      <div
                        className="h-full bg-[#4CAF82] rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* نتائج المراجعة والاختبارات */}
          <div className="bg-white dark:bg-[#1E1E1E] p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100 flex items-center gap-2">
                <Award className="w-5 h-5 text-[#E8B84A]" />
                <span>نتائج المراجعة والتمارين ({progressData.quizResults.length})</span>
              </h3>
              <span className="text-xs font-cairo font-bold text-[#6F7285]">
                الدروس المكتملة: {progressData.completedLessons.length}
              </span>
            </div>

            {progressData.quizResults.length === 0 ? (
              <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800 text-center font-cairo text-xs text-[#6F7285]">
                لم تقم بإجراء أي اختبار في قسم «المراجعة» حتى الآن.
              </div>
            ) : (
              <div className="space-y-2">
                {progressData.quizResults.slice(0, 10).map((q) => (
                  <div
                    key={q.id}
                    className="p-3.5 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <span className="font-cairo font-black text-xs md:text-sm text-[#25263A] dark:text-stone-100 block">
                        {q.title}
                      </span>
                      <span className="font-cairo text-[11px] text-[#6F7285]">
                        {formatArabicTimestamp(q.completedAt)}
                      </span>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-black text-xs">
                      {q.score} / {q.total}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
