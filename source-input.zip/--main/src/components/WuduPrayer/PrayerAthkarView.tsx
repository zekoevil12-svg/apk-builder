import React, { useState, useEffect } from 'react';
import { ArrowRight, BookOpen, CheckCircle2, Sparkles } from 'lucide-react';
import { PRAYER_ATHKAR_ITEMS, PrayerAthkarItem } from '../../data/wuduPrayerData';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';
import {
  PrayerWuduLearningData,
  persistPrayerWuduProgress,
} from '../../utils/wuduPrayerLearningService';

interface PrayerAthkarViewProps {
  onBack: () => void;
  progressData: PrayerWuduLearningData;
  onProgressUpdated: (next: PrayerWuduLearningData) => void;
}

export const PrayerAthkarView: React.FC<PrayerAthkarViewProps> = ({
  onBack,
  progressData,
  onProgressUpdated,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'wudu' | 'inside_prayer' | 'after_prayer'
  >('all');

  useEffect(() => {
    persistPrayerWuduProgress((prev) => ({
      ...prev,
      lastLesson: 'أذكار الصلاة والوضوء',
      lastLessonId: 'athkar_prayer',
      lastStep: 'استعراض أذكار الصلاة والوضوء',
    })).then(onProgressUpdated);
  }, [onProgressUpdated]);

  const handleToggleReadDhikr = async (item: PrayerAthkarItem) => {
    const stepKey = `athkar_${item.id}`;
    const nextData = await persistPrayerWuduProgress((prev) => {
      const nextCompletedSteps = Array.from(new Set([...prev.completedSteps, stepKey]));
      const allAthkarDone = PRAYER_ATHKAR_ITEMS.every((a) =>
        nextCompletedSteps.includes(`athkar_${a.id}`)
      );
      const nextLessons = allAthkarDone
        ? Array.from(new Set([...prev.completedLessons, 'athkar_prayer']))
        : prev.completedLessons;

      return {
        ...prev,
        completedSteps: nextCompletedSteps,
        completedLessons: nextLessons,
        lastLesson: 'أذكار الصلاة والوضوء',
        lastLessonId: 'athkar_prayer',
        lastStep: item.title,
      };
    });
    onProgressUpdated(nextData);
  };

  const filteredAthkar =
    selectedCategory === 'all'
      ? PRAYER_ATHKAR_ITEMS
      : PRAYER_ATHKAR_ITEMS.filter((i) => i.category === selectedCategory);

  return (
    <div className="space-y-5 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer border border-[#E6E6F0] dark:border-stone-700"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-xs md:text-sm font-cairo">الرئيسية للقسم</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-xl font-black font-cairo text-[#25263A] dark:text-stone-100">
            🤲 أذكار الصلاة والوضوء
          </h2>
          <p className="text-[11px] md:text-xs text-[#6F7285] dark:text-stone-400 font-cairo">
            الأذكار النبوية الصحيحة الثابتة مع موضع كل ذكر وشرحه ومصدره
          </p>
        </div>

        <div className="w-16" />
      </div>

      {/* بطاقة ترحيبية بالرسم التعليمي */}
      <div className="bg-white dark:bg-[#1E1E1E] rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 p-5 flex flex-col sm:flex-row items-center gap-4 shadow-xs">
        <WuduPrayerIllustration type="card_athkar" size={96} className="shrink-0" />
        <div className="space-y-1.5 text-center sm:text-right">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#4CAF82]/12 text-[#2E8B62] dark:text-emerald-300 text-xs font-cairo font-black">
            <Sparkles className="w-3.5 h-3.5" />
            <span>أذكار صحيحة موثقة من السنة النبوية</span>
          </div>
          <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
            احفظ أذكار وضوئك وصلاتك خطوة بخطوة
          </h3>
          <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300 leading-relaxed">
            اضغط على زر «قرأت وتعلّمت هذا الذكر» أسفل كل بطاقة لتسجيله في تقدمك الحقيقي.
          </p>
        </div>
      </div>

      {/* أزرار تصفية الأذكار */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'الكل (' + PRAYER_ATHKAR_ITEMS.length + ')' },
          { id: 'wudu', label: '💧 أذكار الوضوء' },
          { id: 'inside_prayer', label: '🕌 أذكار داخل الصلاة' },
          { id: 'after_prayer', label: '🤲 أذكار بعد السلام من الصلاة' },
        ].map((tab) => {
          const active = selectedCategory === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() =>
                setSelectedCategory(
                  tab.id as 'all' | 'wudu' | 'inside_prayer' | 'after_prayer'
                )
              }
              className={`px-4 py-2 rounded-xl font-cairo font-black text-xs shrink-0 transition-all cursor-pointer border ${
                active
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                  : 'bg-white dark:bg-[#1E1E1E] text-[#6F7285] dark:text-stone-300 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* قائمة بطاقات الأذكار */}
      <div className="space-y-4">
        {filteredAthkar.map((item) => {
          const isLearned = progressData.completedSteps.includes(`athkar_${item.id}`);
          return (
            <div
              key={item.id}
              className={`bg-white dark:bg-[#1E1E1E] rounded-[24px] border-2 p-5 shadow-xs space-y-4 transition-all ${
                isLearned
                  ? 'border-[#4CAF82]/50'
                  : 'border-[#E6E6F0] dark:border-stone-800'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="px-3 py-1 rounded-full bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 font-cairo font-black text-xs">
                    {item.categoryLabel}
                  </span>
                  <h4 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                    {item.title}
                  </h4>
                </div>

                {isLearned && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 text-xs font-cairo font-black">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>تم تعلّمه</span>
                  </span>
                )}
              </div>

              {/* النص العربي */}
              <div className="p-4 md:p-5 rounded-2xl bg-[#FFFDF5] dark:bg-stone-900 border border-[#E8B84A]/50">
                <p className="font-amiri font-bold text-lg md:text-xl text-[#25263A] dark:text-amber-100 leading-loose">
                  « {item.arabicText} »
                </p>
              </div>

              {/* موضع الذكر + الشرح المختصر + المصدر */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-cairo">
                <div className="p-3 rounded-xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                  <span className="font-black text-[#5B5FEF] dark:text-amber-300 block mb-1">
                    📍 موضع الذكر:
                  </span>
                  <p className="text-[#25263A] dark:text-stone-200 leading-relaxed font-bold">
                    {item.position}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                  <span className="font-black text-[#2E8B62] dark:text-emerald-300 block mb-1">
                    💡 شرح مختصر:
                  </span>
                  <p className="text-[#25263A] dark:text-stone-200 leading-relaxed">
                    {item.explanation}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                  <span className="font-black text-[#4145C7] dark:text-amber-300 flex items-center gap-1 mb-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>المصدر:</span>
                  </span>
                  <p className="text-[#6F7285] dark:text-stone-300 leading-relaxed font-bold">
                    {item.source}
                  </p>
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => handleToggleReadDhikr(item)}
                  className={`px-4 py-2 rounded-xl font-cairo font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    isLearned
                      ? 'bg-[#4CAF82] text-white'
                      : 'bg-[#F7F7FC] dark:bg-stone-800 hover:bg-[#5B5FEF] text-[#25263A] dark:text-stone-200 hover:text-white border border-[#E6E6F0] dark:border-stone-700'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isLearned ? 'تم حفظ تعلّم هذا الذكر' : 'قرأت وتعلّمت هذا الذكر'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
