import React from 'react';

export type IllustrationType = 
  // Wudu postures (9 distinct steps)
  | 'niyyah' 
  | 'hands' 
  | 'mouth' 
  | 'nose' 
  | 'face' 
  | 'arms' 
  | 'head'
  | 'ears'
  | 'feet'
  | 'head_ears_feet'
  // Prayer postures
  | 'qiyam_ready'
  | 'takbeer' 
  | 'qiyam' 
  | 'rukoo' 
  | 'itidal' 
  | 'sujood' 
  | 'julus' 
  | 'rising'
  | 'tashahhud' 
  | 'tasleem'
  // Main hub cards & 5 prayers
  | 'card_wudu'
  | 'card_prayer'
  | 'card_athkar'
  | 'card_review'
  | 'card_progress'
  | 'prayer_fajr'
  | 'prayer_dhuhr'
  | 'prayer_asr'
  | 'prayer_maghrib'
  | 'prayer_isha'
  // Extra categories
  | 'ghusl'
  | 'jamaah'
  | 'witr';

interface WuduPrayerIllustrationProps {
  type: IllustrationType;
  className?: string;
  size?: number;
}

export const WuduPrayerIllustration: React.FC<WuduPrayerIllustrationProps> = ({ 
  type, 
  className = '', 
  size = 180 
}) => {
  return (
    <div 
      className={`relative rounded-full flex items-center justify-center select-none shadow-[0_8px_24px_rgba(3,169,244,0.22)] border-4 border-white dark:border-stone-800 overflow-hidden bg-gradient-to-b from-[#E1F5FE] via-[#B3E5FC] to-[#72B7E8] dark:from-[#0d3448] dark:via-[#092231] dark:to-[#04131d] ${className}`}
      style={{ width: `${size}px`, height: `${size}px` }}
    >
      {/* Background Soft Islamic Aura & Decorative Radial Glow */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 200 200">
        <defs>
          <linearGradient id="auraGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#72B7E8" stopOpacity="0.15" />
          </linearGradient>
          <radialGradient id="waterPool" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#E0F7FA" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#72B7E8" stopOpacity="0.2" />
          </radialGradient>
          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient Ring & Geometric Islamic Eight-Pointed Star Details */}
        <circle cx="100" cy="100" r="92" fill="none" stroke="#FFFFFF" strokeWidth="1.5" opacity="0.65" />
        <circle cx="100" cy="100" r="84" fill="none" stroke="#72B7E8" strokeWidth="1" strokeDasharray="4 4" opacity="0.4" />
        <circle cx="100" cy="100" r="70" fill="url(#auraGlow)" opacity="0.35" />

        {/* Dynamic Water Wave Ripples at bottom */}
        <path d="M0,165 Q45,150 100,165 T200,165 L200,200 L0,200 Z" fill="#72B7E8" opacity="0.3" />
        <path d="M0,175 Q55,165 105,178 T200,175 L200,200 L0,200 Z" fill="#72B7E8" opacity="0.2" />
      </svg>

      {/* Main High-Detail SVG Character Canvas (200x200 Coordinate Space) */}
      <div className="relative z-10 w-full h-full flex items-center justify-center p-2">
        <svg 
          viewBox="0 0 200 200" 
          className="w-full h-full drop-shadow-[0_4px_8px_rgba(0,0,0,0.08)]"
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* DEFINITIONS FOR SHADING & GRADIENTS */}
          <defs>
            {/* Skin gradient with warm highlights */}
            <linearGradient id="skinGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFE0B2" />
              <stop offset="100%" stopColor="#FFCC80" />
            </linearGradient>
            {/* Thobe white cloth shaded gradient */}
            <linearGradient id="thobeGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="85%" stopColor="#F5F5F5" />
              <stop offset="100%" stopColor="#E6E6F0" />
            </linearGradient>
            {/* Taqiyah / Cap */}
            <linearGradient id="taqiyahGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E8EAF6" />
            </linearGradient>
            {/* Gold accents */}
            <linearGradient id="goldAcc" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#E8B84A" />
              <stop offset="100%" stopColor="#72B7E8" />
            </linearGradient>
            {/* Water Flow */}
            <linearGradient id="waterFlow" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#72B7E8" />
              <stop offset="50%" stopColor="#72B7E8" />
              <stop offset="100%" stopColor="#01579B" />
            </linearGradient>
          </defs>

          {/* ══════════════════════════════════════════════
              WUDU POSTURES (High Polished Illustrations)
             ══════════════════════════════════════════════ */}

          {type === 'niyyah' && (
            <g id="illustration-niyyah">
              {/* Wash Basin / Counter */}
              <rect x="35" y="145" width="130" height="30" rx="15" fill="#ECEFF1" stroke="#77798C" strokeWidth="2.5" />
              <ellipse cx="100" cy="145" rx="50" ry="12" fill="#CFD8DC" stroke="#77798C" strokeWidth="1.5" />
              <ellipse cx="100" cy="146" rx="42" ry="9" fill="#72B7E8" opacity="0.6" />

              {/* Modern Islamic Chrome Faucet */}
              <path d="M78 145 V118 Q78 102 96 102 Q108 102 108 116 V124" stroke="#77798C" strokeWidth="4.5" strokeLinecap="round" />
              <circle cx="78" cy="120" r="5" fill="#B0BEC5" />

              {/* Sparkling Crystal Water Flow */}
              <path d="M108 124 L107 145" stroke="url(#waterFlow)" strokeWidth="3.5" strokeLinecap="round" strokeDasharray="4 2" />
              <circle cx="107" cy="136" r="2.5" fill="#E1F5FE" />
              <circle cx="112" cy="142" r="2" fill="#E1F5FE" />

              {/* Boy Torso */}
              <path d="M68 96 Q100 88 132 96 L140 152 Q100 160 60 152 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
              <path d="M100 96 V135" stroke="#E6E6F0" strokeWidth="2" />

              {/* Peaceful Head with Taqiyah */}
              <ellipse cx="100" cy="62" rx="22" ry="24" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M78 58 C78 36 122 36 122 58 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              {/* Taqiyah Islamic Pattern Hem */}
              <path d="M78 58 Q100 62 122 58" stroke="#5B5FEF" strokeWidth="2.5" />

              {/* Smiling peaceful face */}
              <path d="M89 60 Q94 63 97 60" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
              <path d="M103 60 Q106 63 111 60" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
              <path d="M94 72 Q100 78 106 72" stroke="#D95C6A" strokeWidth="2.5" strokeLinecap="round" />

              {/* Glowing Heart of Niyyah (Pure Intention) */}
              <g transform="translate(100, 115) scale(0.9)">
                <path d="M0 -4 C-6 -14 -20 -10 -20 2 C-20 12 0 24 0 24 C0 24 20 12 20 2 C20 -10 6 -14 0 -4 Z" fill="#E99AC7" stroke="#FFFFFF" strokeWidth="2" />
                <circle cx="-6" cy="0" r="2" fill="#FFFFFF" opacity="0.8" />
              </g>

              {/* Sparkling Stars */}
              <path d="M135 70 L137 75 L142 77 L137 79 L135 84 L133 79 L128 77 L133 75 Z" fill="#E8B84A" />
            </g>
          )}

          {type === 'hands' && (
            <g id="illustration-hands">
              {/* Water Splash Burst in Center */}
              <circle cx="100" cy="100" r="48" fill="url(#waterPool)" />
              <circle cx="100" cy="54" r="5" fill="#72B7E8" />
              <path d="M100 42 Q92 56 100 62 Q108 56 100 42 Z" fill="#72B7E8" />
              <circle cx="68" cy="78" r="3.5" fill="#72B7E8" />
              <circle cx="134" cy="74" r="3.5" fill="#72B7E8" />
              <circle cx="100" cy="148" r="3.5" fill="#72B7E8" />

              {/* Forearms with Thobe Cuffs Rolled Up */}
              <path d="M38 126 L68 108 L78 122 L48 140 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <path d="M162 126 L132 108 L122 122 L152 140 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />

              {/* White Thobe Sleeves */}
              <rect x="25" y="128" width="28" height="26" rx="6" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" transform="rotate(-30 39 141)" />
              <rect x="147" y="128" width="28" height="26" rx="6" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" transform="rotate(30 161 141)" />

              {/* Two Intertwined Hands Washing Between Fingers */}
              {/* Left Palm & Fingers */}
              <ellipse cx="88" cy="102" rx="16" ry="20" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(-15 88 102)" />
              {/* Right Palm & Fingers */}
              <ellipse cx="112" cy="102" rx="16" ry="20" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(15 112 102)" />

              {/* Interlaced Fingers Detail */}
              <path d="M82 82 Q88 94 92 104" stroke="#E8B84A" strokeWidth="3" strokeLinecap="round" />
              <path d="M92 78 Q96 90 98 102" stroke="#E8B84A" strokeWidth="3" strokeLinecap="round" />
              <path d="M108 78 Q104 90 102 102" stroke="#E8B84A" strokeWidth="3" strokeLinecap="round" />
              <path d="M118 82 Q112 94 108 104" stroke="#E8B84A" strokeWidth="3" strokeLinecap="round" />

              {/* Dynamic Water Bubbles & Rings Around Hands */}
              <ellipse cx="100" cy="104" rx="34" ry="12" fill="none" stroke="#72B7E8" strokeWidth="2.5" strokeDasharray="6 4" />
              <circle cx="86" cy="94" r="4" fill="#FFFFFF" opacity="0.8" />
              <circle cx="114" cy="94" r="4" fill="#FFFFFF" opacity="0.8" />
            </g>
          )}

          {type === 'mouth' && (
            <g id="illustration-mouth">
              {/* Head Profile tilted happily */}
              <ellipse cx="96" cy="74" rx="28" ry="30" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              {/* Taqiyah */}
              <path d="M68 70 C68 40 124 40 124 70 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M68 70 Q96 76 124 70" stroke="#5B5FEF" strokeWidth="2.5" />

              {/* Closed Joyful Eyes */}
              <path d="M84 70 Q90 64 96 70" stroke="#25263A" strokeWidth="2.5" strokeLinecap="round" />
              {/* Mouth with gentle water swirl */}
              <ellipse cx="114" cy="84" rx="10" ry="7" fill="#E1F5FE" stroke="#72B7E8" strokeWidth="2" />
              <path d="M110 84 Q114 80 118 84" stroke="#72B7E8" strokeWidth="2" strokeLinecap="round" />

              {/* Right Hand cupping clean water to mouth */}
              <ellipse cx="130" cy="92" rx="14" ry="10" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(-20 130 92)" />
              <path d="M124 96 Q134 94 140 102" stroke="#E8B84A" strokeWidth="2" />

              {/* Water Splash droplets around mouth */}
              <circle cx="120" cy="74" r="3.5" fill="#72B7E8" />
              <circle cx="136" cy="80" r="2.5" fill="#72B7E8" />
              <circle cx="114" cy="96" r="3" fill="#72B7E8" />

              {/* Body */}
              <path d="M62 108 Q96 100 130 108 L142 165 Q96 175 50 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {type === 'nose' && (
            <g id="illustration-nose">
              {/* Head Profile */}
              <ellipse cx="96" cy="74" rx="28" ry="30" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              {/* Taqiyah */}
              <path d="M68 70 C68 40 124 40 124 70 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M68 70 Q96 76 124 70" stroke="#5B5FEF" strokeWidth="2.5" />

              {/* Gentle Eye */}
              <path d="M84 70 Q90 64 96 70" stroke="#25263A" strokeWidth="2.5" strokeLinecap="round" />

              {/* Nose with Water Stream & Bubbles */}
              <path d="M102 74 Q112 78 104 84" stroke="#25263A" strokeWidth="2.5" strokeLinecap="round" />
              <ellipse cx="112" cy="82" rx="7" ry="5" fill="#72B7E8" opacity="0.85" stroke="#72B7E8" strokeWidth="1.5" />

              {/* Hand assisting inhalation/exhalation */}
              <ellipse cx="128" cy="94" rx="14" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <circle cx="116" cy="72" r="3" fill="#72B7E8" />
              <circle cx="124" cy="76" r="2.5" fill="#72B7E8" />

              {/* Body */}
              <path d="M62 108 Q96 100 130 108 L142 165 Q96 175 50 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {type === 'face' && (
            <g id="illustration-face">
              {/* Aura of Purity */}
              <circle cx="100" cy="80" r="54" fill="url(#waterPool)" />

              {/* Full Face Child Facing Forward */}
              <ellipse cx="100" cy="78" rx="30" ry="32" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <path d="M70 70 C70 38 130 38 130 70 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M70 70 Q100 76 130 70" stroke="#5B5FEF" strokeWidth="2.5" />

              {/* Happy eyes and smile */}
              <circle cx="88" cy="76" r="3" fill="#25263A" />
              <circle cx="112" cy="76" r="3" fill="#25263A" />
              <path d="M93 90 Q100 96 107 90" stroke="#D95C6A" strokeWidth="2.5" strokeLinecap="round" />
              <circle cx="82" cy="84" r="5" fill="#FF8A80" opacity="0.4" />
              <circle cx="118" cy="84" r="5" fill="#FF8A80" opacity="0.4" />

              {/* Two Hands Washing Both Sides of Face */}
              <ellipse cx="64" cy="82" rx="10" ry="16" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(-15 64 82)" />
              <ellipse cx="136" cy="82" rx="10" ry="16" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(15 136 82)" />

              {/* Water streams flowing gently across face from forehead to chin */}
              <path d="M72 58 Q100 48 128 58" stroke="#72B7E8" strokeWidth="3" strokeLinecap="round" strokeDasharray="5 3" />
              <path d="M66 94 Q100 108 134 94" stroke="#72B7E8" strokeWidth="3" strokeLinecap="round" strokeDasharray="5 3" />

              {/* Thobe */}
              <path d="M68 116 Q100 110 132 116 L144 170 Q100 180 56 170 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {type === 'arms' && (
            <g id="illustration-arms">
              {/* Washing Right Arm from Fingers through the Elbow */}
              <path d="M46 102 L112 76 L146 112 L80 138 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2.5" />

              {/* Left Hand Washing Forearm */}
              <ellipse cx="94" cy="98" rx="15" ry="22" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(35 94 98)" />

              {/* Elbow Highlight with Golden Circle Indicator */}
              <circle cx="146" cy="112" r="14" fill="none" stroke="#5B5FEF" strokeWidth="3.5" strokeDasharray="4 2" />
              <text x="146" y="116" textAnchor="middle" fill="#4145C7" fontSize="10" fontWeight="bold" fontFamily="sans-serif">المرفق</text>

              {/* Rolled Thobe Sleeve */}
              <rect x="142" y="96" width="30" height="34" rx="8" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" transform="rotate(45 157 113)" />

              {/* Water streams along forearm */}
              <path d="M60 88 Q96 74 136 94" stroke="#72B7E8" strokeWidth="3.5" strokeLinecap="round" />
              <circle cx="80" cy="86" r="3.5" fill="#E1F5FE" />
              <circle cx="116" cy="84" r="3.5" fill="#E1F5FE" />
              <circle cx="102" cy="120" r="3.5" fill="#72B7E8" />
            </g>
          )}

          {type === 'head' && (
            <g id="illustration-head">
              {/* Boy Head without cap showing wet hair being wiped */}
              <ellipse cx="100" cy="84" rx="28" ry="30" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              {/* Modest neat hair */}
              <path d="M72 78 C72 44 128 44 128 78 C118 64 82 64 72 78 Z" fill="#4E342E" />
              {/* Gentle eyes and smile */}
              <circle cx="89" cy="84" r="2.8" fill="#25263A" />
              <circle cx="111" cy="84" r="2.8" fill="#25263A" />
              <path d="M93 96 Q100 101 107 96" stroke="#D95C6A" strokeWidth="2.5" strokeLinecap="round" />

              {/* Two Wet Hands Wiping Top of Head from Front to Back */}
              <ellipse cx="78" cy="52" rx="14" ry="8" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(-18 78 52)" />
              <ellipse cx="122" cy="52" rx="14" ry="8" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(18 122 52)" />

              {/* Motion Arrow over head (Front <-> Back) */}
              <path d="M68 34 Q100 20 132 34" stroke="#5B5FEF" strokeWidth="3" strokeLinecap="round" strokeDasharray="4 3" />
              <polygon points="132,34 124,29 126,38" fill="#5B5FEF" />
              <polygon points="68,34 76,29 74,38" fill="#5B5FEF" />

              {/* Water droplets */}
              <circle cx="100" cy="42" r="3" fill="#72B7E8" />
              <circle cx="84" cy="40" r="2.5" fill="#E1F5FE" />
              <circle cx="116" cy="40" r="2.5" fill="#E1F5FE" />

              {/* Thobe */}
              <path d="M70 118 Q100 112 130 118 L142 170 Q100 180 58 170 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {type === 'ears' && (
            <g id="illustration-ears">
              {/* Head */}
              <ellipse cx="100" cy="82" rx="28" ry="30" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <path d="M72 74 C72 44 128 44 128 74 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Highlighted Left & Right Ears */}
              <ellipse cx="68" cy="84" rx="7" ry="11" fill="url(#skinGrad)" stroke="#5B5FEF" strokeWidth="2.5" />
              <ellipse cx="132" cy="84" rx="7" ry="11" fill="url(#skinGrad)" stroke="#5B5FEF" strokeWidth="2.5" />
              <circle cx="68" cy="84" r="14" fill="none" stroke="#4CAF82" strokeWidth="2" strokeDasharray="3 2" />
              <circle cx="132" cy="84" r="14" fill="none" stroke="#4CAF82" strokeWidth="2" strokeDasharray="3 2" />

              {/* Index fingers & Thumbs wiping ears */}
              <ellipse cx="52" cy="92" rx="10" ry="13" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(-20 52 92)" />
              <ellipse cx="148" cy="92" rx="10" ry="13" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" transform="rotate(20 148 92)" />

              {/* Eyes & Smile */}
              <circle cx="89" cy="82" r="2.8" fill="#25263A" />
              <circle cx="111" cy="82" r="2.8" fill="#25263A" />
              <path d="M93 94 Q100 99 107 94" stroke="#D95C6A" strokeWidth="2.5" strokeLinecap="round" />

              {/* Thobe */}
              <path d="M70 116 Q100 110 130 116 L142 170 Q100 180 58 170 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {(type === 'feet' || type === 'head_ears_feet') && (
            <g id="illustration-head-feet">
              {/* Washing Foot to Ankle Bones (Ka'bayn) */}
              <ellipse cx="100" cy="140" rx="55" ry="18" fill="url(#waterPool)" />

              {/* Foot Form */}
              <path d="M50 85 L84 85 L90 128 L146 128 Q158 128 158 142 L154 150 Q100 162 60 148 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2.5" />

              {/* Ka'b (Ankle Bone) Highlighted */}
              <circle cx="94" cy="124" r="12" fill="none" stroke="#5B5FEF" strokeWidth="3.5" strokeDasharray="4 2" />
              <circle cx="94" cy="124" r="3" fill="#72B7E8" />
              <text x="94" y="106" textAnchor="middle" fill="#4145C7" fontSize="11" fontWeight="bold">الكعب</text>

              {/* Flowing Water Over Feet */}
              <path d="M78 110 Q115 95 152 135" stroke="#72B7E8" strokeWidth="4" strokeLinecap="round" />
              <circle cx="118" cy="120" r="4" fill="#E1F5FE" />
              <circle cx="138" cy="142" r="3.5" fill="#72B7E8" />
              <circle cx="86" cy="144" r="3.5" fill="#72B7E8" />
            </g>
          )}

          {type === 'qiyam_ready' && (
            <g id="illustration-qiyam-ready">
              {/* Prayer Rug facing Qibla */}
              <ellipse cx="100" cy="176" rx="62" ry="14" fill="#E6E6F0" stroke="#4CAF82" strokeWidth="2.5" />
              {/* Qibla Arch Indicator in background */}
              <path d="M66 150 V72 Q100 42 134 72 V150" fill="none" stroke="#E8B84A" strokeWidth="2" strokeDasharray="4 3" opacity="0.7" />

              {/* Child standing calmly facing Qibla with hands at sides before Takbeer */}
              <ellipse cx="100" cy="48" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M84 44 C84 26 116 26 116 44 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <circle cx="94" cy="49" r="2.2" fill="#25263A" />
              <circle cx="106" cy="49" r="2.2" fill="#25263A" />
              <path d="M96 57 Q100 60 104 57" stroke="#D95C6A" strokeWidth="2" strokeLinecap="round" />

              <path d="M78 68 Q100 64 122 68 L130 164 Q100 171 70 164 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
              <ellipse cx="68" cy="112" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <ellipse cx="132" cy="112" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <ellipse cx="88" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
              <ellipse cx="112" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
            </g>
          )}

          {type === 'rising' && (
            <g id="illustration-rising">
              <ellipse cx="100" cy="176" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />
              {/* Upward Motion Arrows indicating rising to next Rak'ah */}
              <path d="M52 128 V76" stroke="#4CAF82" strokeWidth="3.5" strokeLinecap="round" />
              <polygon points="52,66 45,78 59,78" fill="#4CAF82" />
              <path d="M148 128 V76" stroke="#4CAF82" strokeWidth="3.5" strokeLinecap="round" />
              <polygon points="148,66 141,78 155,78" fill="#4CAF82" />

              {/* Child rising upright */}
              <ellipse cx="100" cy="52" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M84 48 C84 30 116 30 116 48 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M78 72 Q100 68 122 72 L130 164 Q100 171 70 164 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
              <rect x="88" y="82" width="24" height="12" rx="6" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <ellipse cx="88" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
              <ellipse cx="112" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
            </g>
          )}

          {/* ══════════════════════════════════════════════
              PRAYER POSTURES (High Polished Illustrations)
             ══════════════════════════════════════════════ */}

          {type === 'takbeer' && (
            <g id="illustration-takbeer">
              {/* Prayer Rug base */}
              <ellipse cx="100" cy="178" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              {/* Boy Head & Taqiyah */}
              <ellipse cx="100" cy="46" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M84 42 C84 24 116 24 116 42 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M84 42 Q100 46 116 42" stroke="#5B5FEF" strokeWidth="2" />

              {/* Raised Hands Level with Shoulders / Earlobes */}
              <ellipse cx="64" cy="48" rx="7" ry="13" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <ellipse cx="136" cy="48" rx="7" ry="13" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />

              {/* Sleeves raised */}
              <path d="M78 68 L68 56 M122 68 L132 56" stroke="url(#thobeGrad)" strokeWidth="8" strokeLinecap="round" />

              {/* Thobe Standing Upright */}
              <path d="M78 66 Q100 62 122 66 L130 165 Q100 172 70 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />

              {/* Feet side by side */}
              <ellipse cx="88" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
              <ellipse cx="112" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />

              {/* Takbeer Sparks */}
              <path d="M100 18 L102 24 L108 26 L102 28 L100 34 L98 28 L92 26 L98 24 Z" fill="#E8B84A" />
            </g>
          )}

          {type === 'qiyam' && (
            <g id="illustration-qiyam">
              <ellipse cx="100" cy="178" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              {/* Head looking down towards Sujood spot */}
              <ellipse cx="100" cy="48" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M84 44 C84 26 116 26 116 44 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />
              <path d="M84 44 Q100 48 116 44" stroke="#5B5FEF" strokeWidth="2" />
              {/* Eyes looking humbly down */}
              <path d="M92 50 Q96 54 100 50" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
              <path d="M100 50 Q104 54 108 50" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />

              {/* Folded Hands on Chest (Right over Left) */}
              <path d="M74 72 Q100 84 126 72" stroke="url(#thobeGrad)" strokeWidth="10" strokeLinecap="round" />
              <rect x="88" y="75" width="24" height="12" rx="6" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M96 75 V87" stroke="#E8B84A" strokeWidth="1.5" />

              {/* Upright Thobe */}
              <path d="M78 68 Q100 64 122 68 L130 165 Q100 172 70 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />

              {/* Feet */}
              <ellipse cx="88" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
              <ellipse cx="112" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
            </g>
          )}

          {type === 'rukoo' && (
            <g id="illustration-rukoo">
              {/* 90-degree Straight Back Line indicator */}
              <line x1="50" y1="84" x2="135" y2="84" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="3 2" />

              {/* Head aligned with straight back */}
              <ellipse cx="56" cy="84" rx="16" ry="15" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M46 72 C36 84 36 96 46 100 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Torso Level Horizontal */}
              <path d="M68 84 L132 84 L132 150" stroke="url(#thobeGrad)" strokeWidth="20" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M68 84 L132 84 L132 150" stroke="#E6E6F0" strokeWidth="2" fill="none" />

              {/* Hands Grasping Knees with Spread Fingers */}
              <ellipse cx="94" cy="120" rx="8" ry="11" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2" />
              <path d="M72 88 L94 120" stroke="url(#thobeGrad)" strokeWidth="8" strokeLinecap="round" />

              {/* Straight Legs */}
              <line x1="126" y1="110" x2="126" y2="165" stroke="#E6E6F0" strokeWidth="3" />
              <ellipse cx="128" cy="168" rx="9" ry="4.5" fill="url(#skinGrad)" />
            </g>
          )}

          {type === 'itidal' && (
            <g id="illustration-itidal">
              <ellipse cx="100" cy="178" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              {/* Straight Upright Standing from Rukoo */}
              <ellipse cx="100" cy="46" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M84 42 C84 24 116 24 116 42 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Hands at Sides or Raised in Prayer */}
              <path d="M72 68 L64 96 M128 68 L136 96" stroke="url(#thobeGrad)" strokeWidth="8" strokeLinecap="round" />
              <ellipse cx="64" cy="98" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <ellipse cx="136" cy="98" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />

              <path d="M78 66 Q100 62 122 66 L130 165 Q100 172 70 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
              <ellipse cx="88" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
              <ellipse cx="112" cy="168" rx="8" ry="4" fill="url(#skinGrad)" />
            </g>
          )}

          {type === 'sujood' && (
            <g id="illustration-sujood">
              {/* Prayer Rug Baseline */}
              <rect x="25" y="152" width="150" height="12" rx="6" fill="#72B7E8" opacity="0.3" />
              <line x1="20" y1="156" x2="180" y2="156" stroke="#5B5FEF" strokeWidth="2.5" />

              {/* Forehead and Nose Touching Ground */}
              <ellipse cx="50" cy="144" rx="15" ry="14" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M42 136 C42 122 62 122 62 136 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Arched Back in reverent Sujood */}
              <path d="M60 142 Q95 86 135 116 L148 152" stroke="url(#thobeGrad)" strokeWidth="22" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M60 142 Q95 86 135 116 L148 152" stroke="#E6E6F0" strokeWidth="2" fill="none" />

              {/* Two Palms Flat beside ears on floor */}
              <ellipse cx="68" cy="150" rx="9" ry="5" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />

              {/* Knees on Ground */}
              <circle cx="118" cy="152" r="6" fill="#E6E6F0" />

              {/* Toes Pressed and Pointed toward Qibla */}
              <circle cx="152" cy="152" r="5" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />

              {/* Number 7 Highlight for 7 Bones of Sujood */}
              <circle cx="100" cy="62" r="16" fill="url(#goldAcc)" stroke="#FFFFFF" strokeWidth="2" />
              <text x="100" y="68" textAnchor="middle" fill="#25263A" fontSize="15" fontWeight="bold" fontFamily="sans-serif">٧</text>
            </g>
          )}

          {type === 'julus' && (
            <g id="illustration-julus">
              <ellipse cx="100" cy="168" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              {/* Sitting between two Sujoods calmly */}
              <ellipse cx="96" cy="62" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M80 58 C80 40 112 40 112 58 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Upright Torso */}
              <path d="M78 82 Q96 78 114 82 L128 145 L64 145 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />

              {/* Hands resting flat on thighs */}
              <ellipse cx="80" cy="132" rx="7" ry="6" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <ellipse cx="112" cy="132" rx="7" ry="6" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />

              {/* Folded Left Foot underneath & Upright Right Foot */}
              <path d="M60 148 Q96 142 132 148" stroke="#E6E6F0" strokeWidth="4" strokeLinecap="round" />
            </g>
          )}

          {type === 'tashahhud' && (
            <g id="illustration-tashahhud">
              <ellipse cx="100" cy="168" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              <ellipse cx="94" cy="62" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M78 58 C78 40 110 40 110 58 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              <path d="M76 82 Q94 78 112 82 L126 145 L62 145 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />

              {/* Left hand flat on knee */}
              <ellipse cx="76" cy="132" rx="7" ry="6" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />

              {/* Right Hand with Raised Index Finger Pointing Tawheed */}
              <ellipse cx="112" cy="132" rx="7" ry="7" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <line x1="112" y1="132" x2="124" y2="114" stroke="url(#skinGrad)" strokeWidth="4.5" strokeLinecap="round" />
              <line x1="112" y1="132" x2="124" y2="114" stroke="#E8B84A" strokeWidth="1" strokeLinecap="round" />

              {/* Golden Tawheed Sparkle on fingertip */}
              <circle cx="126" cy="112" r="3.5" fill="#E8B84A" />
              <path d="M126 104 L127 109 L132 110 L127 111 L126 116 L125 111 L120 110 L125 109 Z" fill="#72B7E8" />
            </g>
          )}

          {type === 'tasleem' && (
            <g id="illustration-tasleem">
              <ellipse cx="100" cy="168" rx="60" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="4 2" />

              {/* Head Turned to the Right looking over right shoulder */}
              <ellipse cx="112" cy="62" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M96 58 C96 40 128 40 128 58 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Cheerful Smile */}
              <path d="M116 66 Q122 70 126 66" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />

              <path d="M78 82 Q96 78 114 82 L128 145 L64 145 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />

              {/* Peaceful Green Ribbon of Salam */}
              <path d="M128 56 Q146 50 162 62" stroke="#4CAF82" strokeWidth="3" strokeLinecap="round" strokeDasharray="4 2" />
              <text x="146" y="50" textAnchor="middle" fill="#5B5FEF" fontSize="10" fontWeight="bold">السلام</text>
            </g>
          )}

          {type === 'ghusl' && (
            <g id="illustration-ghusl">
              {/* Rain Shower / Full Water Stream */}
              <rect x="75" y="24" width="50" height="12" rx="6" fill="#77798C" stroke="#455A64" strokeWidth="2" />
              <path d="M100 12 V24" stroke="#455A64" strokeWidth="5" />

              {/* Multiple Fresh Streams of Water */}
              <line x1="82" y1="36" x2="72" y2="75" stroke="#72B7E8" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="6 3" />
              <line x1="92" y1="36" x2="88" y2="85" stroke="#72B7E8" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="6 3" />
              <line x1="100" y1="36" x2="100" y2="90" stroke="#72B7E8" strokeWidth="3" strokeLinecap="round" strokeDasharray="6 3" />
              <line x1="108" y1="36" x2="112" y2="85" stroke="#72B7E8" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="6 3" />
              <line x1="118" y1="36" x2="128" y2="75" stroke="#72B7E8" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="6 3" />

              {/* Child Standing Joyfully Purifying */}
              <ellipse cx="100" cy="95" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M78 120 Q100 112 122 120 L132 175 Q100 185 68 175 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {type === 'jamaah' && (
            <g id="illustration-jamaah">
              {/* Prayer Rugs Aligned in Rows */}
              <ellipse cx="100" cy="115" rx="40" ry="10" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="1.5" />
              <ellipse cx="100" cy="165" rx="65" ry="14" fill="#E6E6F0" stroke="#5B5FEF" strokeWidth="1.5" />

              {/* Imam Leading in Front */}
              <ellipse cx="100" cy="72" rx="12" ry="14" fill="url(#skinGrad)" />
              <path d="M88 68 C88 54 112 54 112 68 Z" fill="url(#taqiyahGrad)" />
              <path d="M85 86 Q100 82 115 86 L120 115 Q100 120 80 115 Z" fill="url(#thobeGrad)" stroke="#5B5FEF" strokeWidth="2" />

              {/* Golden Mihrab Arc behind Imam */}
              <path d="M75 110 C75 50 125 50 125 110" fill="none" stroke="#5B5FEF" strokeWidth="2" strokeDasharray="3 2" />

              {/* Two Followers (Ma'moom) in Aligned Row Behind */}
              {/* Left Follower */}
              <ellipse cx="62" cy="120" rx="11" ry="13" fill="url(#skinGrad)" />
              <path d="M51 116 C51 104 73 104 73 116 Z" fill="url(#taqiyahGrad)" />
              <path d="M48 133 Q62 129 76 133 L80 165 Q62 170 44 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="1.5" />

              {/* Right Follower */}
              <ellipse cx="138" cy="120" rx="11" ry="13" fill="url(#skinGrad)" />
              <path d="M127 116 C127 104 149 104 149 116 Z" fill="url(#taqiyahGrad)" />
              <path d="M124 133 Q138 129 152 133 L156 165 Q138 170 120 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="1.5" />
            </g>
          )}

          {type === 'witr' && (
            <g id="illustration-witr">
              {/* Night Crescent Moon & Stars */}
              <path d="M145 28 C132 28 120 40 124 55 C132 55 144 48 148 38 C148 33 147 30 145 28 Z" fill="#E8B84A" stroke="#E8B84A" strokeWidth="1" />
              <circle cx="160" cy="50" r="2" fill="#FFFFFF" />
              <circle cx="120" cy="32" r="2" fill="#FFFFFF" />

              {/* Boy standing in Qunoot with hands cupped in prayer */}
              <ellipse cx="88" cy="74" rx="16" ry="18" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" />
              <path d="M72 70 C72 52 104 52 104 70 Z" fill="url(#taqiyahGrad)" stroke="#B0BEC5" strokeWidth="2" />

              {/* Raised Hands Cupped in Supplication */}
              <ellipse cx="106" cy="88" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" transform="rotate(-25 106 88)" />
              <ellipse cx="116" cy="92" rx="6" ry="9" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="1.5" transform="rotate(-15 116 92)" />

              <path d="M68 94 Q88 90 108 94 L116 165 Q88 172 60 165 Z" fill="url(#thobeGrad)" stroke="#E6E6F0" strokeWidth="2" />
            </g>
          )}

          {/* ══════════════════════════════════════════════
              MAIN CARDS & 5 PRAYERS ORIGINAL ILLUSTRATIONS
             ══════════════════════════════════════════════ */}
          {type === 'card_wudu' && (
            <g id="illustration-card-wudu">
              <circle cx="100" cy="105" r="52" fill="#E1F5FE" opacity="0.7" />
              <path d="M100 42 C100 42 66 84 66 110 C66 129 81 144 100 144 C119 144 134 129 134 110 C134 84 100 42 100 42 Z" fill="url(#waterFlow)" stroke="#FFFFFF" strokeWidth="3" />
              <path d="M84 108 C84 120 92 128 102 128" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
              <circle cx="138" cy="64" r="7" fill="#E8B84A" />
              <circle cx="62" cy="74" r="5" fill="#72B7E8" />
            </g>
          )}

          {type === 'card_prayer' && (
            <g id="illustration-card-prayer">
              {/* Mosque Dome & Minaret */}
              <rect x="52" y="106" width="96" height="48" rx="6" fill="#FFFFFF" stroke="#5B5FEF" strokeWidth="2.5" />
              <path d="M60 106 C60 68 140 68 140 106 Z" fill="#5B5FEF" />
              <circle cx="100" cy="58" r="6" fill="#E8B84A" />
              <path d="M90 154 V124 Q100 114 110 124 V154 Z" fill="#E8B84A" />
              <rect x="142" y="64" width="14" height="90" rx="4" fill="#FFFFFF" stroke="#5B5FEF" strokeWidth="2" />
              <path d="M142 64 L149 48 L156 64 Z" fill="#E8B84A" />
            </g>
          )}

          {type === 'card_athkar' && (
            <g id="illustration-card-athkar">
              {/* Cupped Hands with Noor/Beads */}
              <circle cx="100" cy="72" r="22" fill="#FFF8E1" stroke="#E8B84A" strokeWidth="2" />
              <path d="M100 56 L104 66 L114 70 L104 74 L100 84 L96 74 L86 70 L96 66 Z" fill="#E8B84A" />
              <path d="M58 124 Q78 148 98 132 L98 104 Q76 104 58 124 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2.5" />
              <path d="M142 124 Q122 148 102 132 L102 104 Q124 104 142 124 Z" fill="url(#skinGrad)" stroke="#E8B84A" strokeWidth="2.5" />
            </g>
          )}

          {type === 'card_review' && (
            <g id="illustration-card-review">
              {/* Open Educational Book with Checkmark Star */}
              <path d="M46 74 Q73 66 100 76 Q127 66 154 74 V142 Q127 134 100 144 Q73 134 46 142 Z" fill="#FFFFFF" stroke="#5B5FEF" strokeWidth="3" />
              <line x1="100" y1="76" x2="100" y2="144" stroke="#5B5FEF" strokeWidth="2.5" />
              <circle cx="100" cy="54" r="16" fill="#4CAF82" stroke="#FFFFFF" strokeWidth="2.5" />
              <path d="M93 54 L98 59 L108 49" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
            </g>
          )}

          {type === 'card_progress' && (
            <g id="illustration-card-progress">
              {/* Rising Progress Steps & Star Badge */}
              <rect x="54" y="122" width="22" height="32" rx="5" fill="#72B7E8" />
              <rect x="88" y="100" width="22" height="54" rx="5" fill="#5B5FEF" />
              <rect x="122" y="78" width="22" height="76" rx="5" fill="#4CAF82" />
              <circle cx="133" cy="54" r="15" fill="#E8B84A" stroke="#FFFFFF" strokeWidth="2" />
              <polygon points="133,44 136,51 143,51 137,55 139,62 133,58 127,62 129,55 123,51 130,51" fill="#FFFFFF" />
            </g>
          )}

          {type === 'prayer_fajr' && (
            <g id="illustration-prayer-fajr">
              {/* Dawn Horizon & Mosque Silhouette */}
              <circle cx="100" cy="116" r="34" fill="#FFCC80" opacity="0.85" />
              <path d="M30 130 Q100 112 170 130 L170 175 L30 175 Z" fill="#5B5FEF" opacity="0.85" />
              <path d="M74 130 C74 98 126 98 126 130 Z" fill="#25263A" />
              <circle cx="100" cy="90" r="4" fill="#E8B84A" />
            </g>
          )}

          {type === 'prayer_dhuhr' && (
            <g id="illustration-prayer-dhuhr">
              {/* Bright Midday Sun */}
              <circle cx="100" cy="88" r="32" fill="#E8B84A" stroke="#FFFFFF" strokeWidth="3" />
              <circle cx="100" cy="88" r="44" fill="none" stroke="#E8B84A" strokeWidth="3" strokeDasharray="6 6" />
              <path d="M68 148 C68 118 132 118 132 148 Z" fill="#FFFFFF" stroke="#5B5FEF" strokeWidth="2.5" />
            </g>
          )}

          {type === 'prayer_asr' && (
            <g id="illustration-prayer-asr">
              {/* Warm Afternoon Sun & Gentle Clouds */}
              <circle cx="114" cy="84" r="28" fill="#FFB74D" />
              <rect x="48" y="96" width="76" height="26" rx="13" fill="#FFFFFF" stroke="#E6E6F0" strokeWidth="2" />
              <circle cx="74" cy="94" r="16" fill="#FFFFFF" />
              <circle cx="98" cy="90" r="20" fill="#FFFFFF" />
            </g>
          )}

          {type === 'prayer_maghrib' && (
            <g id="illustration-prayer-maghrib">
              {/* Sunset Horizon */}
              <circle cx="100" cy="122" r="34" fill="#FF8A65" />
              <path d="M25 126 L175 126 L175 175 L25 175 Z" fill="#4145C7" />
              <path d="M76 126 C76 96 124 96 124 126 Z" fill="#25263A" />
            </g>
          )}

          {type === 'prayer_isha' && (
            <g id="illustration-prayer-isha">
              {/* Serene Night Sky, Crescent & Stars */}
              <circle cx="100" cy="100" r="64" fill="#25263A" />
              <path d="M112 64 C94 64 82 80 86 98 C98 98 114 88 118 74 C118 69 115 66 112 64 Z" fill="#E8B84A" />
              <circle cx="70" cy="72" r="3" fill="#FFFFFF" />
              <circle cx="132" cy="102" r="2.5" fill="#FFFFFF" />
              <circle cx="78" cy="118" r="2" fill="#E8B84A" />
            </g>
          )}
        </svg>
      </div>
    </div>
  );
};
