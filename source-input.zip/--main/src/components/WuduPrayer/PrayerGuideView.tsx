import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  ArrowRight,
  Sparkles,
  CheckCircle2,
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Award,
  Layers,
} from 'lucide-react';
import {
  PRAYER_DEFINITIONS,
  WHAT_TO_SAY_IN_PRAYER,
  buildPrayerStepSequence,
  PrayerDefinition,
} from '../../data/wuduPrayerData';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';
import {
  FivePrayerId,
  PrayerWuduLearningData,
  persistPrayerWuduProgress,
} from '../../utils/wuduPrayerLearningService';

interface PrayerGuideViewProps {
  onBack: () => void;
  onGoToQuiz?: () => void;
  initialSubTab?: 'prayers' | 'what_to_say';
  initialPrayerId?: FivePrayerId;
  progressData: PrayerWuduLearningData;
  onProgressUpdated: (next: PrayerWuduLearningData) => void;
}

export const PrayerGuideView: React.FC<PrayerGuideViewProps> = ({
  onBack,
  onGoToQuiz,
  initialSubTab = 'prayers',
  initialPrayerId = 'fajr',
  progressData,
  onProgressUpdated,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'prayers' | 'what_to_say'>(initialSubTab);
  const [selectedPrayerId, setSelectedPrayerId] = useState<FivePrayerId>(initialPrayerId);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [showPrayerDoneBanner, setShowPrayerDoneBanner] = useState<boolean>(false);

  const selectedPrayer: PrayerDefinition = useMemo(
    () => PRAYER_DEFINITIONS.find((p) => p.id === selectedPrayerId) || PRAYER_DEFINITIONS[0],
    [selectedPrayerId]
  );

  const prayerSteps = useMemo(
    () => buildPrayerStepSequence(selectedPrayerId),
    [selectedPrayerId]
  );

  const currentMovement = prayerSteps[currentStepIndex] || prayerSteps[0];
  const prayerProgressObj = progressData.prayerProgress[selectedPrayerId];
  const completedStepIds = prayerProgressObj?.completedStepIds || [];

  const recordPrayerStepProgress = useCallback(
    async (prayerId: FivePrayerId, stepIdx: number, markComplete = false) => {
      const seq = buildPrayerStepSequence(prayerId);
      const stepObj = seq[stepIdx] || seq[0];
      const prayerDef = PRAYER_DEFINITIONS.find((p) => p.id === prayerId) || PRAYER_DEFINITIONS[0];

      const nextData = await persistPrayerWuduProgress((prev) => {
        const prevPrayer = prev.prayerProgress[prayerId] || {
          prayerId,
          completedStepIds: [],
          totalSteps: seq.length,
          isCompleted: false,
          lastStepIndex: 0,
          completedAt: null,
        };

        const nextStepIds = Array.from(new Set([...prevPrayer.completedStepIds, stepObj.id]));
        const isDone = markComplete || nextStepIds.length >= seq.length;
        const lessonId = `prayer_${prayerId}`;
        const nextLessons = isDone
          ? Array.from(new Set([...prev.completedLessons, lessonId]))
          : prev.completedLessons;

        return {
          ...prev,
          prayerProgress: {
            ...prev.prayerProgress,
            [prayerId]: {
              prayerId,
              completedStepIds: nextStepIds,
              totalSteps: seq.length,
              isCompleted: isDone,
              lastStepIndex: stepIdx,
              completedAt: isDone
                ? prevPrayer.completedAt || new Date().toISOString()
                : prevPrayer.completedAt,
            },
          },
          completedSteps: Array.from(new Set([...prev.completedSteps, stepObj.id])),
          completedLessons: nextLessons,
          lastLesson: `تعلّم ${prayerDef.name}`,
          lastLessonId: lessonId,
          lastStep: `${stepObj.rakahLabel} — ${stepObj.title}`,
        };
      });

      onProgressUpdated(nextData);
    },
    [onProgressUpdated]
  );

  // Sync progress when step or selected prayer changes in 'prayers' tab
  useEffect(() => {
    if (activeSubTab === 'prayers') {
      recordPrayerStepProgress(selectedPrayerId, currentStepIndex, false);
    }
  }, [activeSubTab, selectedPrayerId, currentStepIndex, recordPrayerStepProgress]);

  // Record opening "What do I say in Prayer?" when switching to that tab
  useEffect(() => {
    if (activeSubTab === 'what_to_say') {
      persistPrayerWuduProgress((prev) => ({
        ...prev,
        completedLessons: Array.from(new Set([...prev.completedLessons, 'what_to_say'])),
        lastLesson: 'ماذا أقول في الصلاة؟',
        lastLessonId: 'what_to_say',
        lastStep: 'أذكار وأقوال الصلاة',
      })).then(onProgressUpdated);
    }
  }, [activeSubTab, onProgressUpdated]);

  const handleSelectPrayer = (pid: FivePrayerId) => {
    setSelectedPrayerId(pid);
    setCurrentStepIndex(0);
    setShowPrayerDoneBanner(false);
  };

  const handleSelectRakah = (rakahNum: number) => {
    const firstIdxInRakah = prayerSteps.findIndex((s) => s.rakahNumber === rakahNum);
    if (firstIdxInRakah >= 0) {
      setShowPrayerDoneBanner(false);
      setCurrentStepIndex(firstIdxInRakah);
    }
  };

  const handleNextMovement = () => {
    if (currentStepIndex < prayerSteps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
      setShowPrayerDoneBanner(false);
    } else {
      recordPrayerStepProgress(selectedPrayerId, currentStepIndex, true);
      setShowPrayerDoneBanner(true);
    }
  };

  const handlePrevMovement = () => {
    if (showPrayerDoneBanner) {
      setShowPrayerDoneBanner(false);
      return;
    }
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  const prayerProgressPercent = Math.min(
    100,
    Math.round((completedStepIds.length / Math.max(1, prayerSteps.length)) * 100)
  );

  return (
    <div className="space-y-5 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer border border-[#E6E6F0] dark:border-stone-700"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-xs md:text-sm font-cairo">الرئيسية للقسم</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-xl font-black font-cairo text-[#25263A] dark:text-stone-100">
            🕌 تعلّم الصلاة خطوة بخطوة
          </h2>
          <p className="text-[11px] md:text-xs text-[#6F7285] dark:text-stone-400 font-cairo">
            الصلوات الخمس • عدد الركعات • الحركات وما نقوله في كل ركن
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-[#F7F7FC] dark:bg-stone-900 p-1 rounded-xl border border-[#E6E6F0] dark:border-stone-800">
          <button
            type="button"
            onClick={() => setActiveSubTab('prayers')}
            className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-black transition-all cursor-pointer ${
              activeSubTab === 'prayers'
                ? 'bg-[#5B5FEF] text-white shadow-2xs'
                : 'text-[#6F7285] hover:text-[#25263A] dark:text-stone-300'
            }`}
          >
            🕌 الصلوات الخمس
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('what_to_say')}
            className={`px-3 py-1.5 rounded-lg text-xs font-cairo font-black transition-all cursor-pointer ${
              activeSubTab === 'what_to_say'
                ? 'bg-[#5B5FEF] text-white shadow-2xs'
                : 'text-[#6F7285] hover:text-[#25263A] dark:text-stone-300'
            }`}
          >
            📖 ماذا أقول في الصلاة؟
          </button>
        </div>
      </div>

      {/* التبويب الأول: الصلوات الخمس وخطواتها */}
      {activeSubTab === 'prayers' && (
        <>
          {/* بطاقات اختيار الصلوات الخمس مع رسوماتها الأصلية وعدد الركعات */}
          <div className="bg-white dark:bg-[#1E1E1E] p-4 md:p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs md:text-sm font-black font-cairo text-[#25263A] dark:text-stone-100 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#5B5FEF]" />
                <span>اختر الصلاة لتتعلّم عدد ركعاتها وخطواتها بالترتيب:</span>
              </h3>
              <span className="text-[11px] font-cairo font-bold text-[#6F7285]">5 صلوات يومية</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5">
              {PRAYER_DEFINITIONS.map((prayer) => {
                const isSelected = selectedPrayer.id === prayer.id;
                const pProg = progressData.prayerProgress[prayer.id];
                const isPrayerCompleted = Boolean(pProg?.isCompleted);

                return (
                  <button
                    key={prayer.id}
                    type="button"
                    onClick={() => handleSelectPrayer(prayer.id)}
                    className={`relative p-3 rounded-[20px] text-center transition-all duration-200 cursor-pointer border-2 flex flex-col items-center justify-between gap-1.5 ${
                      isSelected
                        ? 'bg-gradient-to-b from-[#EEEEFF] to-white dark:from-stone-800 dark:to-stone-900 border-[#5B5FEF] shadow-sm scale-[1.02]'
                        : 'bg-[#F7F7FC] dark:bg-stone-900 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF]/50'
                    }`}
                  >
                    {isPrayerCompleted && (
                      <span
                        className="absolute top-2 left-2 text-[#4CAF82]"
                        title="تم إكمال تعلم هذه الصلاة"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </span>
                    )}

                    <WuduPrayerIllustration type={prayer.illustrationType} size={64} />

                    <div className="space-y-0.5">
                      <span className="block font-cairo font-black text-xs md:text-sm text-[#25263A] dark:text-stone-100">
                        {prayer.name}
                      </span>
                      <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-cairo font-black bg-[#5B5FEF] text-white">
                        {prayer.rakatsText} ({prayer.rakats})
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* بطاقة تعريف الصلاة المختارة وشرح عدد الركعات بوضوح للطفل */}
          <div className="bg-white dark:bg-[#1E1E1E] p-4 md:p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E6E6F0] dark:border-stone-800 pb-3.5">
              <div className="flex items-center gap-3">
                <WuduPrayerIllustration type={selectedPrayer.illustrationType} size={56} />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                      {selectedPrayer.name}
                    </h3>
                    <span className="px-3 py-0.5 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-black text-xs border border-[#4CAF82]/30">
                      عدد ركعاتها: {selectedPrayer.rakatsText}
                    </span>
                  </div>
                  <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-400 mt-0.5">
                    {selectedPrayer.kidSummary}
                  </p>
                </div>
              </div>

              <div className="text-left">
                <span className="inline-block px-3 py-1 rounded-xl bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 font-cairo font-bold text-xs">
                  {selectedPrayer.recitationStyle}
                </span>
              </div>
            </div>

            {/* أزرار الركعات الواضحة جدًا للطفل (الركعة الأولى، الركعة الثانية...) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-cairo font-black text-[#25263A] dark:text-stone-200">
                  🔢 ركعات {selectedPrayer.name} ({selectedPrayer.rakatsText}):
                </span>
                <span className="text-xs font-cairo font-bold text-[#5B5FEF]">
                  أنت الآن في: {currentMovement.rakahLabel}
                </span>
              </div>

              <div
                className="grid gap-2"
                style={{
                  gridTemplateColumns: `repeat(${selectedPrayer.rakats}, minmax(0, 1fr))`,
                }}
              >
                {selectedPrayer.rakatLabels.map((rLabel, idx) => {
                  const rNum = idx + 1;
                  const isCurrentRakah =
                    currentMovement.rakahNumber === rNum && !showPrayerDoneBanner;
                  return (
                    <button
                      key={rLabel}
                      type="button"
                      onClick={() => handleSelectRakah(rNum)}
                      className={`py-2.5 px-3 rounded-2xl font-cairo font-black text-xs md:text-sm transition-all cursor-pointer border text-center ${
                        isCurrentRakah
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-sm'
                          : 'bg-[#F7F7FC] dark:bg-stone-900 text-[#25263A] dark:text-stone-200 border-[#E6E6F0] dark:border-stone-700 hover:border-[#5B5FEF]'
                      }`}
                    >
                      {rLabel}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* مؤشر التقدم الكلي في الصلاة المختارة */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs font-cairo">
                <span className="font-bold text-[#6F7285] dark:text-stone-400">
                  مؤشر التقدم في {selectedPrayer.name} (الحركة {currentStepIndex + 1} من{' '}
                  {prayerSteps.length})
                </span>
                <span className="font-black text-[#2E8B62] dark:text-emerald-300">
                  {prayerProgressPercent}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-[#F7F7FC] dark:bg-stone-800 rounded-full overflow-hidden border border-[#E6E6F0] dark:border-stone-700">
                <div
                  className="h-full bg-gradient-to-l from-[#5B5FEF] to-[#4CAF82] rounded-full transition-all duration-300"
                  style={{ width: `${prayerProgressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* بطاقة الحركة الحالية بالرسم التعليمي الأصلي */}
          {!showPrayerDoneBanner ? (
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-[#E6E6F0] dark:border-stone-800 p-5 md:p-7 shadow-sm space-y-6">
              {/* رأس الحركة */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E6E6F0] dark:border-stone-800 pb-4">
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-base flex items-center justify-center shadow-xs">
                    {currentStepIndex + 1}
                  </span>
                  <div>
                    <span className="text-xs font-cairo font-black text-[#5B5FEF] dark:text-amber-300 block">
                      {selectedPrayer.name} • {currentMovement.rakahLabel}
                    </span>
                    <h4 className="text-lg md:text-2xl font-black font-cairo text-[#25263A] dark:text-stone-100">
                      {currentMovement.title}
                    </h4>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-bold text-xs border border-[#4CAF82]/30">
                    {currentMovement.fiqhRule}
                  </span>
                  <span className="px-3 py-1 rounded-full bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285] dark:text-stone-300 font-cairo font-bold text-xs border border-[#E6E6F0] dark:border-stone-700">
                    {currentMovement.repetitionText}
                  </span>
                </div>
              </div>

              {/* الرسم التعليمي الأصلي الكبير للحركة */}
              <div className="flex flex-col items-center justify-center py-4 bg-gradient-to-b from-[#F5F7FF] via-[#F7F7FC] to-white dark:from-stone-900 dark:to-stone-900/40 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 p-5">
                <WuduPrayerIllustration type={currentMovement.illustrationType} size={220} />
                <span className="mt-3 text-xs font-cairo font-bold text-[#4145C7] dark:text-amber-300 bg-white dark:bg-stone-800 px-3.5 py-1 rounded-full border border-[#E6E6F0] dark:border-stone-700">
                  {currentMovement.rakahLabel} — {currentMovement.title}
                </span>
              </div>

              {/* الشرح وما يجب فعله وما يقال */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                    <span className="font-cairo font-black text-xs text-[#5B5FEF] dark:text-amber-300 block mb-1">
                      📘 شرح الحركة ببساطة:
                    </span>
                    <p className="font-cairo font-bold text-xs md:text-sm text-[#25263A] dark:text-stone-100 leading-relaxed">
                      {currentMovement.simpleExplanation}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#4CAF82]/8 border border-[#4CAF82]/25">
                    <span className="font-cairo font-black text-xs text-[#2E8B62] dark:text-emerald-300 block mb-1">
                      🧍 ما يجب فعله في هذه الحركة:
                    </span>
                    <p className="font-cairo font-bold text-xs md:text-sm text-[#25263A] dark:text-stone-100 leading-relaxed">
                      {currentMovement.whatToDo}
                    </p>
                  </div>
                </div>

                {/* ما يقال في هذه المرحلة */}
                <div className="p-4 md:p-5 rounded-2xl bg-[#FFFDF5] dark:bg-stone-900 border-2 border-[#E8B84A]/50">
                  <span className="font-cairo font-black text-xs text-[#B78103] dark:text-amber-300 block mb-1.5">
                    📖 ما يقال في هذه المرحلة:
                  </span>
                  <p className="font-amiri font-bold text-lg md:text-xl text-[#25263A] dark:text-amber-100 leading-loose whitespace-pre-line">
                    {currentMovement.whatToSay}
                  </p>
                </div>
              </div>

              {/* أزرار السابق والتالي */}
              <div className="flex items-center justify-between gap-3 pt-2 border-t border-[#E6E6F0] dark:border-stone-800">
                <button
                  type="button"
                  onClick={handlePrevMovement}
                  disabled={currentStepIndex === 0}
                  className={`flex-1 py-3.5 px-4 rounded-2xl font-cairo font-black text-sm md:text-base flex items-center justify-center gap-2 transition-all ${
                    currentStepIndex === 0
                      ? 'bg-[#F7F7FC] dark:bg-stone-900 text-stone-300 dark:text-stone-600 border border-[#E6E6F0] dark:border-stone-800 cursor-not-allowed'
                      : 'bg-[#F7F7FC] dark:bg-stone-800 hover:bg-[#EEEEFF] text-[#25263A] dark:text-stone-100 border border-[#E6E6F0] dark:border-stone-700 cursor-pointer active:scale-95'
                  }`}
                >
                  <ChevronRight className="w-5 h-5" />
                  <span>السابق</span>
                </button>

                <button
                  type="button"
                  onClick={handleNextMovement}
                  className="flex-[1.6] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white font-cairo font-black text-sm md:text-base shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
                >
                  <span>
                    {currentStepIndex < prayerSteps.length - 1
                      ? `الحركة التالية (${currentStepIndex + 2} / ${prayerSteps.length})`
                      : `إتمام تعلم ${selectedPrayer.name}`}
                  </span>
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-[#4CAF82] p-6 md:p-8 shadow-md text-center space-y-5 animate-fade-in">
              <div className="w-16 h-16 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] flex items-center justify-center mx-auto">
                <Award className="w-9 h-9" />
              </div>

              <div className="space-y-1.5">
                <h3 className="font-cairo font-black text-xl md:text-2xl text-[#25263A] dark:text-stone-100">
                  تقبّل الله! أتممت خطوات {selectedPrayer.name} ({selectedPrayer.rakatsText}) 🌟
                </h3>
                <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300">
                  لقد تعلّمت جميع حركات وأقوال {selectedPrayer.name} خطوة بخطوة.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowPrayerDoneBanner(false);
                    setCurrentStepIndex(0);
                  }}
                  className="px-5 py-3 rounded-2xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-cairo font-bold text-xs md:text-sm border border-[#E6E6F0] dark:border-stone-700 cursor-pointer hover:bg-[#EEEEFF]"
                >
                  إعادة خطوات {selectedPrayer.name}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveSubTab('what_to_say')}
                  className="px-5 py-3 rounded-2xl bg-[#EEEEFF] text-[#4145C7] font-cairo font-black text-xs md:text-sm cursor-pointer hover:brightness-95"
                >
                  📖 ماذا أقول في الصلاة؟
                </button>

                {onGoToQuiz && (
                  <button
                    type="button"
                    onClick={onGoToQuiz}
                    className="px-5 py-3 rounded-2xl bg-[#4CAF82] text-white font-cairo font-black text-xs md:text-sm cursor-pointer hover:brightness-105"
                  >
                    📚 مراجعة الصلاة
                  </button>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* التبويب الثاني: 📖 ماذا أقول في الصلاة؟ */}
      {activeSubTab === 'what_to_say' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-[#EEEEFF] via-white to-[#FFFDF5] dark:from-stone-900 dark:to-stone-800 p-5 rounded-[24px] border border-[#E6E6F0] dark:border-stone-800">
            <div className="flex items-center gap-2 text-[#4145C7] dark:text-amber-300 font-cairo font-black text-base md:text-lg">
              <BookOpen className="w-5 h-5" />
              <h3>📖 ماذا أقول في الصلاة؟</h3>
            </div>
            <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300 mt-1 leading-relaxed">
              جميع الأقوال والأذكار الصحيحة التي نقولها داخل الصلاة من تكبيرة الإحرام حتى التسليم مع شرح مبسط لكل ذكر.
            </p>
          </div>

          <div className="space-y-3.5">
            {WHAT_TO_SAY_IN_PRAYER.map((item, idx) => (
              <div
                key={item.id}
                className="bg-white dark:bg-[#1E1E1E] rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 p-5 shadow-xs space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-[#5B5FEF] text-white font-cairo font-black text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                      {item.title}
                    </h4>
                  </div>

                  <span className="px-3 py-1 rounded-full bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 font-cairo font-bold text-xs">
                    متى يقال: {item.whenSaid}
                  </span>
                </div>

                {/* النص العربي الموثق */}
                <div className="p-4 rounded-2xl bg-[#FFFDF5] dark:bg-stone-900 border border-[#E8B84A]/45">
                  <p className="font-amiri font-bold text-lg md:text-xl text-[#25263A] dark:text-amber-100 leading-loose">
                    « {item.arabicText} »
                  </p>
                </div>

                {/* الشرح البسيط للطفل والمصدر */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs font-cairo">
                  <div className="p-3 rounded-xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                    <span className="font-black text-[#4CAF82] block mb-0.5">
                      💡 شرح بسيط للطفل:
                    </span>
                    <p className="text-[#25263A] dark:text-stone-200 leading-relaxed">
                      {item.kidExplanation}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                    <span className="font-black text-[#5B5FEF] dark:text-amber-300 block mb-0.5">
                      📚 المصدر والتوثيق:
                    </span>
                    <p className="text-[#6F7285] dark:text-stone-300 leading-relaxed">
                      {item.source}
                    </p>
                    {item.fiqhNote && (
                      <p className="text-[11px] text-[#4145C7] dark:text-amber-200 mt-1 font-bold">
                        • {item.fiqhNote}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
