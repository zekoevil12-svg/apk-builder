import React, { useState, useEffect, useCallback } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Award,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  ListChecks,
} from 'lucide-react';
import { WUDU_STEPS, DUAA_AFTER_WUDU } from '../../data/wuduPrayerData';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';
import {
  PrayerWuduLearningData,
  persistPrayerWuduProgress,
} from '../../utils/wuduPrayerLearningService';

interface WuduGuideViewProps {
  onBack: () => void;
  onGoToQuiz?: () => void;
  progressData: PrayerWuduLearningData;
  onProgressUpdated: (next: PrayerWuduLearningData) => void;
}

export const WuduGuideView: React.FC<WuduGuideViewProps> = ({
  onBack,
  onGoToQuiz,
  progressData,
  onProgressUpdated,
}) => {
  const totalSteps = WUDU_STEPS.length;

  // Start at the user's last reached step (or step 0 if starting fresh)
  const [currentIndex, setCurrentIndex] = useState<number>(() => {
    const lastNum = progressData.wuduProgress.lastStepNumber;
    if (lastNum && lastNum >= 1 && lastNum <= totalSteps) {
      return lastNum - 1;
    }
    return 0;
  });

  const [viewMode, setViewMode] = useState<'interactive' | 'all_steps'>('interactive');
  const [showCompletionCard, setShowCompletionCard] = useState<boolean>(false);

  const currentStep = WUDU_STEPS[currentIndex] || WUDU_STEPS[0];
  const completedStepNumbers = progressData.wuduProgress.completedStepNumbers;

  const recordStepVisitAndComplete = useCallback(
    async (stepNumber: number, markLessonDone = false) => {
      const stepObj = WUDU_STEPS.find((s) => s.stepNumber === stepNumber) || WUDU_STEPS[0];
      const nextData = await persistPrayerWuduProgress((prev) => {
        const nextNumbers = Array.from(
          new Set([...prev.wuduProgress.completedStepNumbers, stepNumber])
        ).sort((a, b) => a - b);
        const allDone = markLessonDone || nextNumbers.length >= totalSteps;
        const stepKey = `wudu_step_${stepNumber}`;
        const nextCompletedSteps = Array.from(new Set([...prev.completedSteps, stepKey]));
        const nextCompletedLessons = allDone
          ? Array.from(new Set([...prev.completedLessons, 'wudu']))
          : prev.completedLessons;

        return {
          ...prev,
          wuduProgress: {
            completedStepNumbers: nextNumbers,
            isCompleted: allDone,
            lastStepNumber: stepNumber,
            completedAt: allDone
              ? prev.wuduProgress.completedAt || new Date().toISOString()
              : prev.wuduProgress.completedAt,
          },
          completedSteps: nextCompletedSteps,
          completedLessons: nextCompletedLessons,
          lastLesson: 'تعلّم الوضوء',
          lastLessonId: 'wudu',
          lastStep: `الخطوة ${stepNumber}: ${stepObj.title}`,
        };
      });
      onProgressUpdated(nextData);
    },
    [onProgressUpdated, totalSteps]
  );

  // Record opening current step on mount / step change
  useEffect(() => {
    recordStepVisitAndComplete(currentStep.stepNumber, false);
  }, [currentStep.stepNumber, recordStepVisitAndComplete]);

  const handleNextStep = () => {
    if (currentIndex < totalSteps - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      setShowCompletionCard(false);
    } else {
      recordStepVisitAndComplete(totalSteps, true);
      setShowCompletionCard(true);
    }
  };

  const handlePrevStep = () => {
    if (showCompletionCard) {
      setShowCompletionCard(false);
      return;
    }
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const progressPercent = Math.round((completedStepNumbers.length / totalSteps) * 100);

  return (
    <div className="space-y-5 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer border border-[#E6E6F0] dark:border-stone-700"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-xs md:text-sm font-cairo">الرئيسية للقسم</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-xl font-black font-cairo text-[#25263A] dark:text-stone-100">
            💧 تعلّم الوضوء خطوة بخطوة
          </h2>
          <p className="text-[11px] md:text-xs text-[#6F7285] dark:text-stone-400 font-cairo">
            صفة الوضوء الصحيح بالترتيب ({totalSteps} خطوات مصورة)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() =>
              setViewMode((prev) => (prev === 'interactive' ? 'all_steps' : 'interactive'))
            }
            className="px-3 py-2 rounded-xl bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 text-xs font-bold font-cairo flex items-center gap-1.5 cursor-pointer hover:brightness-95 transition-all"
          >
            <ListChecks className="w-4 h-4" />
            <span>{viewMode === 'interactive' ? 'عرض كل الخطوات' : 'الدرس التفاعلي'}</span>
          </button>
        </div>
      </div>

      {/* مؤشر تقدم الطفل */}
      <div className="bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs md:text-sm font-bold font-cairo text-[#25263A] dark:text-stone-200 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
            <span>
              تقدمك في خطوات الوضوء ({completedStepNumbers.length} من {totalSteps})
            </span>
          </span>
          <span className="text-xs font-black font-cairo px-2.5 py-0.5 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300">
            {progressPercent}%
          </span>
        </div>

        {/* شريط التقدم */}
        <div className="w-full h-3 bg-[#F7F7FC] dark:bg-stone-800 rounded-full overflow-hidden border border-[#E6E6F0] dark:border-stone-700">
          <div
            className="h-full bg-gradient-to-l from-[#72B7E8] via-[#5B5FEF] to-[#4CAF82] rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* أرقام الخطوات التسع السريعة */}
        <div className="grid grid-cols-9 gap-1.5 pt-1">
          {WUDU_STEPS.map((s, idx) => {
            const isCurrent = idx === currentIndex && !showCompletionCard;
            const isDone = completedStepNumbers.includes(s.stepNumber);
            return (
              <button
                key={s.stepNumber}
                type="button"
                onClick={() => {
                  setShowCompletionCard(false);
                  setViewMode('interactive');
                  setCurrentIndex(idx);
                }}
                className={`h-9 rounded-xl font-cairo font-black text-xs flex items-center justify-center transition-all cursor-pointer border ${
                  isCurrent
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-sm scale-105'
                    : isDone
                    ? 'bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 border-[#4CAF82]/40'
                    : 'bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285] border-[#E6E6F0] dark:border-stone-700'
                }`}
                title={s.title}
              >
                {s.stepNumber}
              </button>
            );
          })}
        </div>
      </div>

      {/* وضع الدرس التفاعلي خطوة بخطوة */}
      {viewMode === 'interactive' && !showCompletionCard && (
        <div className="bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-[#E6E6F0] dark:border-stone-800 p-5 md:p-7 shadow-sm space-y-6">
          {/* رأس الخطوة */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E6E6F0] dark:border-stone-800 pb-4">
            <div className="flex items-center gap-2.5">
              <span className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-base flex items-center justify-center shadow-xs">
                {currentStep.stepNumber}
              </span>
              <div>
                <span className="text-[11px] font-bold font-cairo text-[#5B5FEF] dark:text-amber-300 block">
                  الخطوة {currentStep.stepNumber} من {totalSteps}
                </span>
                <h3 className="text-lg md:text-2xl font-black font-cairo text-[#25263A] dark:text-stone-100">
                  {currentStep.title}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 text-xs font-bold font-cairo border border-[#5B5FEF]/20">
                {currentStep.repetitionBadge}
              </span>
              <span className="px-3 py-1 rounded-full bg-[#4CAF82]/12 text-[#2E8B62] dark:text-emerald-300 text-xs font-bold font-cairo border border-[#4CAF82]/30">
                {currentStep.fiqhStatus}
              </span>
            </div>
          </div>

          {/* الرسم التعليمي الأصلي الكبير للخطوة */}
          <div className="flex flex-col items-center justify-center py-3 bg-gradient-to-b from-[#F0F9FF] via-[#F7F7FC] to-white dark:from-stone-900 dark:to-stone-900/40 rounded-[24px] border border-[#DCEEFB] dark:border-stone-800 p-5">
            <WuduPrayerIllustration type={currentStep.illustrationType} size={220} />
            <span className="mt-3 text-xs font-bold font-cairo text-[#4145C7] dark:text-sky-300 bg-white dark:bg-stone-800 px-3.5 py-1 rounded-full border border-[#E6E6F0] dark:border-stone-700 shadow-2xs">
              رسم توضيحي: {currentStep.title}
            </span>
          </div>

          {/* الشرح المبسط جدًا للطفل */}
          <div className="space-y-3">
            <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
              <h4 className="font-cairo font-black text-xs md:text-sm text-[#5B5FEF] dark:text-amber-300 mb-1.5">
                💡 كيف أقوم بهذه الخطوة؟
              </h4>
              <p className="font-cairo font-bold text-sm md:text-base text-[#25263A] dark:text-stone-100 leading-relaxed">
                {currentStep.description}
              </p>
              <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300 mt-2 leading-relaxed">
                {currentStep.whatToDo}
              </p>
            </div>

            {currentStep.whatToSay && (
              <div className="p-4 rounded-2xl bg-[#FFFDF5] dark:bg-stone-900 border border-[#E8B84A]/50">
                <h4 className="font-cairo font-black text-xs text-[#B78103] dark:text-amber-300 mb-1">
                  🤲 ماذا أقول هنا؟
                </h4>
                <p className="font-amiri font-bold text-lg md:text-xl text-[#25263A] dark:text-amber-100 leading-relaxed">
                  « {currentStep.whatToSay} »
                </p>
              </div>
            )}

            {/* فائدة ودليل موثق */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-[#4CAF82]/8 border border-[#4CAF82]/25">
                <span className="font-cairo font-black text-xs text-[#2E8B62] dark:text-emerald-300 block mb-1">
                  🌟 نصيحة للطفل الذكي:
                </span>
                <p className="font-cairo text-xs text-[#25263A] dark:text-stone-200 leading-relaxed">
                  {currentStep.tip}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800">
                <span className="font-cairo font-black text-xs text-[#4145C7] dark:text-amber-300 flex items-center gap-1 mb-1">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>الدليل الشرعي الموثق:</span>
                </span>
                <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-300 leading-relaxed">
                  {currentStep.evidence}
                </p>
              </div>
            </div>
          </div>

          {/* أزرار التنقل الكبيرة: السابق والتالي */}
          <div className="flex items-center justify-between gap-3 pt-2 border-t border-[#E6E6F0] dark:border-stone-800">
            <button
              type="button"
              onClick={handlePrevStep}
              disabled={currentIndex === 0}
              className={`flex-1 py-3.5 px-4 rounded-2xl font-cairo font-black text-sm md:text-base flex items-center justify-center gap-2 transition-all ${
                currentIndex === 0
                  ? 'bg-[#F7F7FC] dark:bg-stone-900 text-stone-300 dark:text-stone-600 border border-[#E6E6F0] dark:border-stone-800 cursor-not-allowed'
                  : 'bg-[#F7F7FC] dark:bg-stone-800 hover:bg-[#EEEEFF] text-[#25263A] dark:text-stone-100 border border-[#E6E6F0] dark:border-stone-700 cursor-pointer active:scale-95'
              }`}
            >
              <ChevronRight className="w-5 h-5" />
              <span>السابق</span>
            </button>

            <button
              type="button"
              onClick={handleNextStep}
              className="flex-[1.6] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white font-cairo font-black text-sm md:text-base shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
            >
              <span>
                {currentIndex < totalSteps - 1
                  ? `الخطوة التالية (${currentIndex + 2} / ${totalSteps})`
                  : 'إتمام درس الوضوء ودعاء الختام'}
              </span>
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* بطاقة إتمام درس الوضوء ودعاء ما بعد الوضوء */}
      {viewMode === 'interactive' && showCompletionCard && (
        <div className="bg-white dark:bg-[#1E1E1E] rounded-[26px] border-2 border-[#4CAF82] p-6 md:p-8 shadow-md text-center space-y-5 animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] flex items-center justify-center mx-auto">
            <Award className="w-9 h-9" />
          </div>

          <div className="space-y-1.5">
            <h3 className="font-cairo font-black text-xl md:text-2xl text-[#25263A] dark:text-stone-100">
              أحسنت! أتممت خطوات الوضوء التسع بنجاح 🌟
            </h3>
            <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300">
              بعد الانتهاء من غسل الرجلين، يُسنّ أن نقول الذكر النبوي بعد الوضوء:
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#FFFDF5] dark:bg-stone-900 border-2 border-[#E8B84A]/50 max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-cairo font-black text-[#B78103] dark:text-amber-300 block">
              🤲 الذكر بعد الفراغ من الوضوء
            </span>
            <p className="font-amiri font-bold text-xl md:text-2xl text-[#25263A] dark:text-amber-100 leading-loose">
              « {DUAA_AFTER_WUDU} »
            </p>
            <p className="text-[11px] font-cairo font-bold text-[#2E8B62] dark:text-emerald-300">
              قال رسول الله ﷺ: «مَا مِنْكُمْ مِنْ أَحَدٍ يَتَوَضَّأُ فَيُبْلِغُ أَوْ فَيُسْبِغُ الْوُضُوءَ ثُمَّ يَقُولُ: أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَأَنَّ مُحَمَّدًا عَبْدُ اللَّهِ وَرَسُولُهُ، إِلَّا فُتِحَتْ لَهُ أَبْوَابُ الْجَنَّةِ الثَّمَانِيَةُ يَدْخُلُ مِنْ أَيِّهَا شَاءَ» (صحيح مسلم 234).
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                setShowCompletionCard(false);
                setCurrentIndex(0);
              }}
              className="px-5 py-3 rounded-2xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-cairo font-bold text-xs md:text-sm border border-[#E6E6F0] dark:border-stone-700 cursor-pointer hover:bg-[#EEEEFF]"
            >
              إعادة استعراض الخطوات من البداية
            </button>

            {onGoToQuiz && (
              <button
                type="button"
                onClick={onGoToQuiz}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-black text-xs md:text-sm shadow-sm cursor-pointer hover:brightness-105"
              >
                📚 انتقل إلى مراجعة الوضوء
              </button>
            )}

            <button
              type="button"
              onClick={onBack}
              className="px-5 py-3 rounded-2xl bg-[#4CAF82] text-white font-cairo font-black text-xs md:text-sm shadow-sm cursor-pointer hover:brightness-105"
            >
              العودة للشاشة الرئيسية للقسم
            </button>
          </div>
        </div>
      )}

      {/* وضع عرض جميع الخطوات التسع دفعة واحدة */}
      {viewMode === 'all_steps' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {WUDU_STEPS.map((step, idx) => {
            const isDone = completedStepNumbers.includes(step.stepNumber);
            return (
              <div
                key={step.stepNumber}
                onClick={() => {
                  setCurrentIndex(idx);
                  setShowCompletionCard(false);
                  setViewMode('interactive');
                }}
                className="bg-white dark:bg-[#1E1E1E] rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF] p-4 shadow-xs flex items-center gap-4 cursor-pointer transition-all hover:-translate-y-0.5"
              >
                <WuduPrayerIllustration type={step.illustrationType} size={92} className="shrink-0" />
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-cairo font-black text-[#5B5FEF]">
                      الخطوة {step.stepNumber} • {step.repetitionBadge}
                    </span>
                    {isDone && (
                      <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
                    )}
                  </div>
                  <h4 className="font-cairo font-black text-sm md:text-base text-[#25263A] dark:text-stone-100">
                    {step.title}
                  </h4>
                  <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-300 line-clamp-2 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
