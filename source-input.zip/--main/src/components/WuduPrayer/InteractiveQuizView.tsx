import React, { useState, useMemo, useEffect } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Award,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import {
  WUDU_STEPS,
  PRAYER_RAKAT_STEPS,
  PRAYER_DEFINITIONS,
  QUIZ_QUESTIONS,
} from '../../data/wuduPrayerData';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';
import {
  PrayerWuduLearningData,
  persistPrayerWuduProgress,
} from '../../utils/wuduPrayerLearningService';

interface InteractiveQuizViewProps {
  onBack: () => void;
  progressData?: PrayerWuduLearningData;
  onProgressUpdated?: (next: PrayerWuduLearningData) => void;
}

type ReviewMainTab = 'wudu_review' | 'prayer_review' | 'order_game' | 'quiz_questions';

export const InteractiveQuizView: React.FC<InteractiveQuizViewProps> = ({
  onBack,
  onProgressUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<ReviewMainTab>('wudu_review');

  // 1. State for Ordering Exercise ("رتب خطوات الوضوء" / "رتب حركات الصلاة")
  const [orderingTopic, setOrderingTopic] = useState<'wudu' | 'prayer'>('wudu');
  const [selectedOrderIds, setSelectedOrderIds] = useState<number[]>([]);
  const [orderFeedback, setOrderFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // 2. State for Interactive Quiz ("ما الخطوة التالية؟" & أسئلة المراجعة)
  const [quizCategoryFilter, setQuizCategoryFilter] = useState<'all' | 'wudu' | 'prayer'>('all');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [selectedOptionIdx, setSelectedOptionIdx] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isQuizFinished, setIsQuizFinished] = useState<boolean>(false);

  useEffect(() => {
    persistPrayerWuduProgress((prev) => ({
      ...prev,
      lastLesson: 'المراجعة والاختبارات',
      lastLessonId: 'review',
      lastStep: 'مراجعة الوضوء والصلاة',
    })).then((next) => onProgressUpdated?.(next));
  }, [onProgressUpdated]);

  // Deterministic shuffled pool for the ordering exercise
  const orderingTargetItems = useMemo(() => {
    if (orderingTopic === 'wudu') {
      return WUDU_STEPS.map((s) => ({
        stepNumber: s.stepNumber,
        title: s.title,
        illustrationType: s.illustrationType,
      }));
    }
    return PRAYER_RAKAT_STEPS.map((s) => ({
      stepNumber: s.stepNumber,
      title: s.title,
      illustrationType: s.illustrationType,
    }));
  }, [orderingTopic]);

  const scrambledOrderItems = useMemo(() => {
    const arr = [...orderingTargetItems];
    // Deterministic permutation so child must actually read and tap in order 1..N
    const perm = [3, 0, 6, 1, 8, 4, 2, 7, 5, 9];
    return perm
      .filter((idx) => idx < arr.length)
      .map((idx) => arr[idx]);
  }, [orderingTargetItems]);

  const handleTapOrderItem = async (stepNumber: number) => {
    const expectedNextStep = selectedOrderIds.length + 1;
    if (stepNumber === expectedNextStep) {
      const nextSelected = [...selectedOrderIds, stepNumber];
      setSelectedOrderIds(nextSelected);

      if (nextSelected.length === orderingTargetItems.length) {
        setOrderFeedback({
          type: 'success',
          message:
            orderingTopic === 'wudu'
              ? 'ممتاز! رتّبت خطوات الوضوء التسع بالترتيب الصحيح الكامل 🌟'
              : 'ممتاز! رتّبت حركات الصلاة العشر بالترتيب الصحيح الكامل 🌟',
        });

        const nextData = await persistPrayerWuduProgress((prev) => ({
          ...prev,
          completedLessons: Array.from(new Set([...prev.completedLessons, 'review'])),
          lastLesson: 'المراجعة والاختبارات',
          lastLessonId: 'review',
          lastStep:
            orderingTopic === 'wudu'
              ? 'إتمام ترتيب خطوات الوضوء'
              : 'إتمام ترتيب حركات الصلاة',
          quizResults: [
            {
              id: `order_${orderingTopic}_${Date.now()}`,
              quizType: orderingTopic === 'wudu' ? 'wudu_order' : 'prayer_order',
              title:
                orderingTopic === 'wudu'
                  ? 'ترتيب خطوات الوضوء التسع'
                  : 'ترتيب حركات الصلاة بالترتيب',
              score: orderingTargetItems.length,
              total: orderingTargetItems.length,
              completedAt: new Date().toISOString(),
            },
            ...prev.quizResults,
          ],
        }));
        onProgressUpdated?.(nextData);
      } else {
        setOrderFeedback({
          type: 'success',
          message: `صحيح! الخطوة رقم (${stepNumber}) في مكانها الصحيح. اختر الخطوة رقم (${stepNumber + 1}).`,
        });
      }
    } else {
      setOrderFeedback({
        type: 'error',
        message: `ليست هذه هي الخطوة رقم (${expectedNextStep})، فكّر قليلًا وحاول مرة أخرى!`,
      });
    }
  };

  const resetOrderingGame = (topic: 'wudu' | 'prayer' = orderingTopic) => {
    setOrderingTopic(topic);
    setSelectedOrderIds([]);
    setOrderFeedback(null);
  };

  // Filtered Quiz Questions
  const filteredQuizQuestions = useMemo(() => {
    if (quizCategoryFilter === 'all') return QUIZ_QUESTIONS;
    return QUIZ_QUESTIONS.filter((q) => q.category === quizCategoryFilter);
  }, [quizCategoryFilter]);

  const currentQuestion =
    filteredQuizQuestions[currentQuestionIdx] || filteredQuizQuestions[0];

  const handleSelectQuizOption = (idx: number) => {
    if (selectedOptionIdx !== null) return;
    setSelectedOptionIdx(idx);
    if (idx === currentQuestion.correctIndex) {
      setScore((prev) => prev + 1);
    }
  };

  const handleNextQuizQuestion = async () => {
    if (currentQuestionIdx < filteredQuizQuestions.length - 1) {
      setCurrentQuestionIdx((prev) => prev + 1);
      setSelectedOptionIdx(null);
    } else {
      setIsQuizFinished(true);
      const nextData = await persistPrayerWuduProgress((prev) => ({
        ...prev,
        completedLessons: Array.from(new Set([...prev.completedLessons, 'review'])),
        lastLesson: 'المراجعة والاختبارات',
        lastLessonId: 'review',
        lastStep: 'إتمام اختبار المراجعة',
        quizResults: [
          {
            id: `quiz_${quizCategoryFilter}_${Date.now()}`,
            quizType: 'next_step',
            title:
              quizCategoryFilter === 'wudu'
                ? 'اختبار مراجعة الوضوء'
                : quizCategoryFilter === 'prayer'
                ? 'اختبار مراجعة الصلاة'
                : 'الاختبار الشامل للوضوء والصلاة',
            score,
            total: filteredQuizQuestions.length,
            completedAt: new Date().toISOString(),
          },
          ...prev.quizResults,
        ],
      }));
      onProgressUpdated?.(nextData);
    }
  };

  const resetQuiz = (cat: 'all' | 'wudu' | 'prayer' = quizCategoryFilter) => {
    setQuizCategoryFilter(cat);
    setCurrentQuestionIdx(0);
    setSelectedOptionIdx(null);
    setScore(0);
    setIsQuizFinished(false);
  };

  return (
    <div className="space-y-5 pb-14 animate-fade-in" dir="rtl">
      {/* الشريط العلوي */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-100 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer border border-[#E6E6F0] dark:border-stone-700"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-xs md:text-sm font-cairo">الرئيسية للقسم</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-xl font-black font-cairo text-[#25263A] dark:text-stone-100">
            📚 المراجعة والاختبارات التفاعلية
          </h2>
          <p className="text-[11px] md:text-xs text-[#6F7285] dark:text-stone-400 font-cairo">
            راجع خطوات الوضوء والصلاة بالصور واختبر معلوماتك
          </p>
        </div>

        <div className="w-16" />
      </div>

      {/* تبويبات المراجعة الأربع */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[
          { id: 'wudu_review', label: '💧 مراجعة الوضوء' },
          { id: 'prayer_review', label: '🕌 مراجعة الصلاة' },
          { id: 'order_game', label: '🔢 رتّب الخطوات' },
          { id: 'quiz_questions', label: '❓ ما الخطوة التالية؟' },
        ].map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as ReviewMainTab)}
              className={`py-3 px-3 rounded-2xl font-cairo font-black text-xs md:text-sm transition-all cursor-pointer border text-center ${
                active
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-sm'
                  : 'bg-white dark:bg-[#1E1E1E] text-[#25263A] dark:text-stone-200 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 1. 💧 مراجعة الوضوء البصرية */}
      {activeTab === 'wudu_review' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-[#1E1E1E] p-4 md:p-5 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                💧 ملخص خطوات الوضوء التسع بالصور
              </h3>
              <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-400">
                شاهد جميع خطوات الوضوء مرتبةً من الخطوة الأولى إلى التاسعة قبل بدء التمرين
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                resetOrderingGame('wudu');
                setActiveTab('order_game');
              }}
              className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-black text-xs cursor-pointer hover:brightness-105"
            >
              ابدأ تمرين: رتّب خطوات الوضوء
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {WUDU_STEPS.map((step) => (
              <div
                key={step.stepNumber}
                className="bg-white dark:bg-[#1E1E1E] rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 p-4 flex flex-col items-center text-center space-y-2.5 shadow-2xs"
              >
                <div className="w-full flex items-center justify-between">
                  <span className="w-7 h-7 rounded-lg bg-[#5B5FEF] text-white font-cairo font-black text-xs flex items-center justify-center">
                    {step.stepNumber}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300 font-cairo font-bold text-[11px]">
                    {step.repetitionBadge}
                  </span>
                </div>

                <WuduPrayerIllustration type={step.illustrationType} size={120} />

                <h4 className="font-cairo font-black text-sm md:text-base text-[#25263A] dark:text-stone-100">
                  {step.title}
                </h4>
                <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-300 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. 🕌 مراجعة الصلاة البصرية */}
      {activeTab === 'prayer_review' && (
        <div className="space-y-5">
          {/* ملخص عدد ركعات الصلوات الخمس */}
          <div className="bg-white dark:bg-[#1E1E1E] p-4 md:p-5 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                🕌 مراجعة عدد ركعات الصلوات الخمس
              </h3>
              <button
                type="button"
                onClick={() => {
                  resetOrderingGame('prayer');
                  setActiveTab('order_game');
                }}
                className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-cairo font-black text-xs cursor-pointer hover:brightness-105"
              >
                ابدأ تمرين: رتّب حركات الصلاة
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {PRAYER_DEFINITIONS.map((p) => (
                <div
                  key={p.id}
                  className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800 flex flex-col items-center text-center gap-1.5"
                >
                  <WuduPrayerIllustration type={p.illustrationType} size={56} />
                  <span className="font-cairo font-black text-xs md:text-sm text-[#25263A] dark:text-stone-100">
                    {p.name}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-black text-xs">
                    {p.rakatsText} ({p.rakats})
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* ملخص حركات الصلاة بالصور */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {PRAYER_RAKAT_STEPS.map((step) => (
              <div
                key={step.stepNumber}
                className="bg-white dark:bg-[#1E1E1E] rounded-[22px] border border-[#E6E6F0] dark:border-stone-800 p-4 flex flex-col items-center text-center space-y-2.5 shadow-2xs"
              >
                <div className="w-full flex items-center justify-between">
                  <span className="w-7 h-7 rounded-lg bg-[#5B5FEF] text-white font-cairo font-black text-xs flex items-center justify-center">
                    {step.stepNumber}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 font-cairo font-bold text-[11px]">
                    {step.fiqhRule}
                  </span>
                </div>

                <WuduPrayerIllustration type={step.illustrationType} size={120} />

                <h4 className="font-cairo font-black text-sm md:text-base text-[#25263A] dark:text-stone-100">
                  {step.title}
                </h4>
                <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-300 leading-relaxed">
                  {step.postureDescription}
                </p>
                <div className="w-full p-2 rounded-xl bg-[#FFFDF5] dark:bg-stone-900 border border-[#E8B84A]/40 font-amiri font-bold text-sm text-[#25263A] dark:text-amber-100">
                  {step.phrase}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. 🔢 تمرين الترتيب التفاعلي ("رتب خطوات الوضوء" / "رتب حركات الصلاة") */}
      {activeTab === 'order_game' && (
        <div className="bg-white dark:bg-[#1E1E1E] rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 p-5 md:p-6 shadow-xs space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E6E6F0] dark:border-stone-800 pb-4">
            <div>
              <h3 className="font-cairo font-black text-base md:text-lg text-[#25263A] dark:text-stone-100">
                🔢 تمرين الترتيب التفاعلي
              </h3>
              <p className="font-cairo text-xs text-[#6F7285] dark:text-stone-400">
                اضغط على البطاقات بالترتيب الصحيح من الخطوة الأولى حتى الأخيرة ({selectedOrderIds.length} /{' '}
                {orderingTargetItems.length})
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => resetOrderingGame('wudu')}
                className={`px-3.5 py-2 rounded-xl font-cairo font-black text-xs cursor-pointer transition-all ${
                  orderingTopic === 'wudu'
                    ? 'bg-[#5B5FEF] text-white'
                    : 'bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285]'
                }`}
              >
                💧 رتّب خطوات الوضوء
              </button>
              <button
                type="button"
                onClick={() => resetOrderingGame('prayer')}
                className={`px-3.5 py-2 rounded-xl font-cairo font-black text-xs cursor-pointer transition-all ${
                  orderingTopic === 'prayer'
                    ? 'bg-[#5B5FEF] text-white'
                    : 'bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285]'
                }`}
              >
                🕌 رتّب حركات الصلاة
              </button>
              <button
                type="button"
                onClick={() => resetOrderingGame(orderingTopic)}
                className="p-2 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-stone-200 border border-[#E6E6F0] dark:border-stone-700 cursor-pointer"
                title="إعادة البدء"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {orderFeedback && (
            <div
              className={`p-3.5 rounded-2xl font-cairo font-bold text-xs md:text-sm flex items-center gap-2 ${
                orderFeedback.type === 'success'
                  ? 'bg-[#4CAF82]/15 text-[#2E8B62] dark:text-emerald-300 border border-[#4CAF82]/40'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
              }`}
            >
              {orderFeedback.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 shrink-0" />
              )}
              <span>{orderFeedback.message}</span>
            </div>
          )}

          {/* شبكة البطاقات غير المرتبة */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {scrambledOrderItems.map((item) => {
              const placedOrderIndex = selectedOrderIds.indexOf(item.stepNumber);
              const isPlaced = placedOrderIndex !== -1;

              return (
                <button
                  key={item.stepNumber}
                  type="button"
                  disabled={isPlaced}
                  onClick={() => handleTapOrderItem(item.stepNumber)}
                  className={`p-3.5 rounded-[20px] border-2 flex flex-col items-center text-center gap-2 transition-all ${
                    isPlaced
                      ? 'bg-[#4CAF82]/12 border-[#4CAF82] opacity-85 cursor-default'
                      : 'bg-[#F7F7FC] dark:bg-stone-900 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF] cursor-pointer active:scale-95'
                  }`}
                >
                  <div className="w-full flex items-center justify-between">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-cairo font-black ${
                        isPlaced
                          ? 'bg-[#4CAF82] text-white'
                          : 'bg-white dark:bg-stone-800 text-[#6F7285]'
                      }`}
                    >
                      {isPlaced ? `الترتيب: ${placedOrderIndex + 1} ✓` : 'اضغط للاختيار'}
                    </span>
                  </div>

                  <WuduPrayerIllustration type={item.illustrationType} size={84} />

                  <span className="font-cairo font-black text-xs md:text-sm text-[#25263A] dark:text-stone-100">
                    {item.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. ❓ اختبار "ما الخطوة التالية؟" وأسئلة المراجعة */}
      {activeTab === 'quiz_questions' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-[#1E1E1E] p-4 rounded-[22px] border border-[#E6E6F0] dark:border-stone-800">
            <div className="flex items-center gap-2">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'wudu', label: '💧 أسئلة الوضوء' },
                { id: 'prayer', label: '🕌 أسئلة الصلاة' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => resetQuiz(f.id as 'all' | 'wudu' | 'prayer')}
                  className={`px-3.5 py-1.5 rounded-xl font-cairo font-black text-xs cursor-pointer transition-all ${
                    quizCategoryFilter === f.id
                      ? 'bg-[#5B5FEF] text-white'
                      : 'bg-[#F7F7FC] dark:bg-stone-800 text-[#6F7285]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <span className="text-xs font-cairo font-black text-[#4CAF82]">
              النتيجة الحالية: {score} / {filteredQuizQuestions.length}
            </span>
          </div>

          {!isQuizFinished ? (
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[24px] border border-[#E6E6F0] dark:border-stone-800 p-5 md:p-6 shadow-xs space-y-5">
              <div className="flex items-center justify-between text-xs font-cairo font-bold text-[#6F7285]">
                <span>
                  السؤال {currentQuestionIdx + 1} من {filteredQuizQuestions.length}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-[#EEEEFF] dark:bg-stone-800 text-[#4145C7] dark:text-amber-300">
                  {currentQuestion.category === 'wudu' ? '💧 الوضوء' : '🕌 الصلاة'}
                </span>
              </div>

              <h3 className="font-cairo font-black text-base md:text-xl text-[#25263A] dark:text-stone-100 leading-relaxed">
                {currentQuestion.question}
              </h3>

              <div className="space-y-2.5">
                {currentQuestion.options.map((opt, idx) => {
                  const isAnswered = selectedOptionIdx !== null;
                  const isSelected = selectedOptionIdx === idx;
                  const isCorrect = idx === currentQuestion.correctIndex;

                  let btnStyle =
                    'bg-[#F7F7FC] dark:bg-stone-900 border-[#E6E6F0] dark:border-stone-800 hover:border-[#5B5FEF] text-[#25263A] dark:text-stone-100';
                  if (isAnswered) {
                    if (isCorrect) {
                      btnStyle =
                        'bg-[#4CAF82]/15 border-[#4CAF82] text-[#2E8B62] dark:text-emerald-300';
                    } else if (isSelected) {
                      btnStyle =
                        'bg-rose-50 dark:bg-rose-950/40 border-rose-400 text-rose-700 dark:text-rose-300';
                    } else {
                      btnStyle = 'opacity-60 border-[#E6E6F0] dark:border-stone-800';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={isAnswered}
                      onClick={() => handleSelectQuizOption(idx)}
                      className={`w-full p-4 rounded-2xl border-2 text-right font-cairo font-bold text-xs md:text-sm flex items-center justify-between gap-3 transition-all cursor-pointer ${btnStyle}`}
                    >
                      <span>{opt}</span>
                      {isAnswered && isCorrect && (
                        <CheckCircle2 className="w-5 h-5 text-[#4CAF82] shrink-0" />
                      )}
                      {isAnswered && isSelected && !isCorrect && (
                        <XCircle className="w-5 h-5 text-rose-500 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {selectedOptionIdx !== null && (
                <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] dark:border-stone-800 space-y-2 animate-fade-in">
                  <div className="flex items-center gap-1.5 text-xs font-cairo font-black text-[#5B5FEF] dark:text-amber-300">
                    <Sparkles className="w-4 h-4" />
                    <span>الشرح والتوضيح:</span>
                  </div>
                  <p className="font-cairo text-xs md:text-sm text-[#25263A] dark:text-stone-200 leading-relaxed">
                    {currentQuestion.explanation}
                  </p>
                  <p className="font-cairo text-[11px] font-bold text-[#6F7285] flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>المصدر: {currentQuestion.source}</span>
                  </p>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={handleNextQuizQuestion}
                      className="px-6 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-black text-xs md:text-sm cursor-pointer hover:brightness-105"
                    >
                      {currentQuestionIdx < filteredQuizQuestions.length - 1
                        ? 'السؤال التالي'
                        : 'إنهاء وحفظ النتيجة'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white dark:bg-[#1E1E1E] rounded-[24px] border-2 border-[#4CAF82] p-6 md:p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#4CAF82]/15 text-[#2E8B62] flex items-center justify-center mx-auto">
                <Award className="w-9 h-9" />
              </div>
              <h3 className="font-cairo font-black text-xl text-[#25263A] dark:text-stone-100">
                أنهيت الاختبار بنجاح! النتيجة: {score} من {filteredQuizQuestions.length}
              </h3>
              <p className="font-cairo text-xs md:text-sm text-[#6F7285] dark:text-stone-300">
                تم حفظ نتيجتك الحقيقية في سجل «تقدمي».
              </p>
              <button
                type="button"
                onClick={() => resetQuiz(quizCategoryFilter)}
                className="px-6 py-3 rounded-2xl bg-[#5B5FEF] text-white font-cairo font-black text-xs md:text-sm cursor-pointer hover:brightness-105 inline-flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة الاختبار</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
