import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  X, 
  Share2, 
  Download, 
  Copy, 
  Check, 
  Image as ImageIcon, 
  FileText, 
  Sparkles, 
  Send,
  MessageCircle,
  Palette,
  Eye,
  BookMarked,
  Repeat
} from 'lucide-react';
import { DhikrItem } from '../types';

export interface DhikrShareData {
  id?: string;
  text: string;
  source?: string;
  virtue?: string;
  countTarget?: number;
  category?: string;
  title?: string;
}

interface DhikrShareModalProps {
  dhikr: DhikrShareData | DhikrItem | null;
  isOpen: boolean;
  onClose: () => void;
}

type ShareTheme = 'emerald' | 'parchment' | 'midnight';

export const DhikrShareModal: React.FC<DhikrShareModalProps> = ({
  dhikr,
  isOpen,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'image' | 'text'>('image');
  const [theme, setTheme] = useState<ShareTheme>('emerald');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const [copiedImage, setCopiedImage] = useState(false);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Formatted Text for Social Media with application branding
  const getFormattedText = useCallback(() => {
    if (!dhikr) return '';

    const title = dhikr.title || (dhikr.category ? `أذكار ${dhikr.category}` : 'ذكر ودعاء مأثور');
    const parts: string[] = [
      `✨ ${title} ✨`,
      '',
      `« ${dhikr.text} »`,
      ''
    ];

    if (dhikr.virtue) {
      parts.push(`💡 الفضل والبركة: ${dhikr.virtue}`);
    }
    if (dhikr.source) {
      parts.push(`📚 المصدر: ${dhikr.source}`);
    }
    if (dhikr.countTarget && dhikr.countTarget > 1) {
      parts.push(`🔢 التكرار الموصى به: ${dhikr.countTarget} مرات`);
    }

    parts.push('');
    parts.push('📲 منقول من تطبيق «رِفْق | RIFQ» - رفيقك اليومي للأذكار والقرآن والسنة 🌿');

    return parts.join('\n');
  }, [dhikr]);

  const formattedText = getFormattedText();

  // Draw Card on Canvas (1080x1080 High-DPI standard)
  const renderCardToCanvas = useCallback(() => {
    if (!dhikr) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 1080;
    const H = 1080;
    canvas.width = W;
    canvas.height = H;

    // Theme definitions
    const themes = {
      emerald: {
        bgStart: '#0D3512',
        bgMid: '#16501E',
        bgEnd: '#09240D',
        borderGold: '#E0C068',
        borderInner: '#E8B84A',
        textTitle: '#FCE7A1',
        textMain: '#FFFFFF',
        textSecondary: '#E8F5E9',
        badgeBg: 'rgba(9, 36, 13, 0.8)',
        badgeBorder: '#E8B84A',
        brandText: '#D1E7DD',
        patternColor: 'rgba(201, 168, 76, 0.08)'
      },
      parchment: {
        bgStart: '#F7F7FC',
        bgMid: '#F7F7FC',
        bgEnd: '#F7F7FC',
        borderGold: '#4145C7',
        borderInner: '#E8B84A',
        textTitle: '#4145C7',
        textMain: '#25263A',
        textSecondary: '#25263A',
        badgeBg: 'rgba(255, 255, 255, 0.88)',
        badgeBorder: '#E8B84A',
        brandText: '#4145C7',
        patternColor: 'rgba(158, 116, 34, 0.06)'
      },
      midnight: {
        bgStart: '#0B1120',
        bgMid: '#111D36',
        bgEnd: '#060A14',
        borderGold: '#E8B84A',
        borderInner: '#E8B84A',
        textTitle: '#FDE68A',
        textMain: '#F8FAFC',
        textSecondary: '#CBD5E1',
        badgeBg: 'rgba(15, 23, 42, 0.85)',
        badgeBorder: '#E8B84A',
        brandText: '#94A3B8',
        patternColor: 'rgba(245, 158, 11, 0.07)'
      }
    };

    const cfg = themes[theme];

    // 1. Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, cfg.bgStart);
    bgGrad.addColorStop(0.5, cfg.bgMid);
    bgGrad.addColorStop(1, cfg.bgEnd);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // 2. Subtle Islamic Geometric Diagonals
    ctx.strokeStyle = cfg.patternColor;
    ctx.lineWidth = 1.5;
    const step = 60;
    for (let x = 0; x <= W; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + step * 4, H);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x - step * 4, H);
      ctx.stroke();
    }

    // 3. Multi-layer Frames
    const padOuter = 40;
    const padInner = 56;

    // Outer Border
    ctx.strokeStyle = cfg.borderGold;
    ctx.lineWidth = 4;
    ctx.strokeRect(padOuter, padOuter, W - padOuter * 2, H - padOuter * 2);

    // Inner Border
    ctx.strokeStyle = cfg.borderInner;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(padInner, padInner, W - padInner * 2, H - padInner * 2);

    // Corner Ornament Diamonds
    const drawCornerDiamond = (cx: number, cy: number, size: number) => {
      ctx.save();
      ctx.fillStyle = cfg.borderGold;
      ctx.beginPath();
      ctx.moveTo(cx, cy - size);
      ctx.lineTo(cx + size, cy);
      ctx.lineTo(cx, cy + size);
      ctx.lineTo(cx - size, cy);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const cOffset = padOuter + 8;
    drawCornerDiamond(cOffset, cOffset, 10);
    drawCornerDiamond(W - cOffset, cOffset, 10);
    drawCornerDiamond(cOffset, H - cOffset, 10);
    drawCornerDiamond(W - cOffset, H - cOffset, 10);

    // 4. Header Section
    ctx.direction = 'rtl';
    ctx.textAlign = 'center';

    // Bismillah
    ctx.fillStyle = cfg.textTitle;
    ctx.font = 'bold 34px "Amiri", "Tajawal", serif';
    ctx.fillText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', W / 2, 120);

    // Decorative Separator & Title
    ctx.font = 'bold 24px "Amiri", "Tajawal", serif';
    ctx.fillStyle = cfg.borderGold;
    const headerTitle = dhikr.title || (dhikr.category ? `أَذْكَارُ ${dhikr.category.toUpperCase()}` : 'ذِكْـرٌ وَدُعَـاءٌ مُبَارَكٌ');
    ctx.fillText(`— ❖  ${headerTitle}  ❖ —`, W / 2, 168);

    // 5. Main Dhikr Text (Word-wrapped with automatic font scaling)
    const maxTextWidth = W - 180;
    const textLen = dhikr.text.length;
    let dhikrFontSize = 40;

    if (textLen > 300) {
      dhikrFontSize = 26;
    } else if (textLen > 200) {
      dhikrFontSize = 30;
    } else if (textLen > 120) {
      dhikrFontSize = 35;
    } else if (textLen < 60) {
      dhikrFontSize = 46;
    }

    ctx.font = `bold ${dhikrFontSize}px "Amiri", "Tajawal", serif`;
    const fullText = `« ${dhikr.text} »`;

    // Wrap text
    const words = fullText.split(' ');
    const lines: string[] = [];
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = currentLine + ' ' + word;
      const metrics = ctx.measureText(testLine);
      if (metrics.width < maxTextWidth) {
        currentLine = testLine;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);

    // Render Dhikr Text centered vertically in main canvas body
    const lineHeight = dhikrFontSize * 1.75;
    const totalLinesHeight = lines.length * lineHeight;
    let startY = 240 + Math.max(0, (480 - totalLinesHeight) / 2);

    ctx.fillStyle = cfg.textMain;
    for (let i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], W / 2, startY + i * lineHeight);
    }

    // 6. Metadata Badge (Lower Panel)
    const hasVirtue = Boolean(dhikr.virtue);
    const hasSource = Boolean(dhikr.source);
    const hasCount = Boolean(dhikr.countTarget && dhikr.countTarget > 1);

    const badgeW = W - 200;
    const badgeH = hasVirtue ? 170 : 130;
    const badgeX = (W - badgeW) / 2;
    const badgeY = H - 90 - badgeH;
    const cornerRadius = 24;

    ctx.save();
    ctx.beginPath();
    ctx.roundRect(badgeX, badgeY, badgeW, badgeH, cornerRadius);
    ctx.fillStyle = cfg.badgeBg;
    ctx.fill();
    ctx.strokeStyle = cfg.badgeBorder;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    let curBadgeY = badgeY + 45;

    // Virtue (if present)
    if (hasVirtue) {
      ctx.fillStyle = cfg.textTitle;
      ctx.font = 'bold 22px "Tajawal", sans-serif';
      const virtueLine = `💡 الفضل: ${dhikr.virtue}`;
      ctx.fillText(virtueLine.length > 55 ? virtueLine.slice(0, 52) + '...' : virtueLine, W / 2, curBadgeY);
      curBadgeY += 45;
    }

    // Source & Repeats row
    const metaParts: string[] = [];
    if (hasSource) metaParts.push(`المصدر: ${dhikr.source}`);
    if (hasCount) metaParts.push(`التكرار: ${dhikr.countTarget} مرات`);

    if (metaParts.length > 0) {
      ctx.fillStyle = cfg.textSecondary;
      ctx.font = 'bold 24px "Tajawal", sans-serif';
      ctx.fillText(metaParts.join('  •  '), W / 2, curBadgeY);
    }

    // 7. Bottom Brand / Watermark
    ctx.fillStyle = cfg.brandText;
    ctx.font = '500 21px "Tajawal", sans-serif';
    ctx.fillText('تطبيق رِفْق | RIFQ • رفيقك اليومي للأذكار والقرآن والسنة 🌿', W / 2, 1020);

    // Update Image Preview
    const dataUrl = canvas.toDataURL('image/png', 0.95);
    setImagePreviewUrl(dataUrl);
  }, [dhikr, theme]);

  // Redraw when modal opens or theme/dhikr changes
  useEffect(() => {
    if (isOpen && dhikr) {
      if (document.fonts) {
        document.fonts.ready.then(() => {
          renderCardToCanvas();
        });
      }
      const t = setTimeout(() => {
        renderCardToCanvas();
      }, 60);
      return () => clearTimeout(t);
    }
  }, [isOpen, dhikr, theme, renderCardToCanvas]);

  if (!isOpen || !dhikr) return null;

  // Handle Download Image
  const handleDownloadImage = () => {
    if (!canvasRef.current) return;
    setIsGenerating(true);
    try {
      const dataUrl = canvasRef.current.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      const safeTitle = (dhikr.title || 'dhikr').replace(/\s+/g, '_');
      a.download = `rifq_${safeTitle}_${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } finally {
      setIsGenerating(false);
    }
  };

  // Handle Web Share with Image File
  const handleShareImage = async () => {
    if (!canvasRef.current) return;
    setIsGenerating(true);

    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) {
          handleDownloadImage();
          setIsGenerating(false);
          return;
        }

        const file = new File([blob], `rifq_dhikr.png`, { type: 'image/png' });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          try {
            await navigator.share({
              files: [file],
              title: 'ذكر مبارك من تطبيق رِفْق',
              text: `«${dhikr.text}» - من تطبيق رِفْق | RIFQ`
            });
          } catch {
            // User cancelled
          }
        } else {
          // Fallback: download
          handleDownloadImage();
        }
        setIsGenerating(false);
      }, 'image/png');
    } catch {
      handleDownloadImage();
      setIsGenerating(false);
    }
  };

  // Handle Copy Image to Clipboard
  const handleCopyImage = async () => {
    if (!canvasRef.current) return;
    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;
        try {
          const item = new ClipboardItem({ 'image/png': blob });
          await navigator.clipboard.write([item]);
          setCopiedImage(true);
          setTimeout(() => setCopiedImage(false), 2500);
        } catch {
          handleDownloadImage();
        }
      }, 'image/png');
    } catch {
      handleDownloadImage();
    }
  };

  // Handle Copy Formatted Text
  const handleCopyFormattedText = () => {
    navigator.clipboard.writeText(formattedText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Social Media Direct Share Links
  const handleShareWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank');
  };

  const handleShareTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank');
  };

  const handleShareTwitter = () => {
    const tweetText = `«${dhikr.text}»\n\n${dhikr.source ? `📚 ${dhikr.source}` : ''}\n🌿 عبر تطبيق رِفْق | RIFQ`;
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}`;
    window.open(url, '_blank');
  };

  const handleShareFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(formattedText)}`;
    window.open(url, '_blank');
  };

  const handleNativeShareText = () => {
    if (navigator.share) {
      navigator.share({
        title: 'ذكر مبارك',
        text: formattedText,
        url: window.location.href
      }).catch(() => {});
    } else {
      handleCopyFormattedText();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs font-tajawal animate-fade-in" 
      dir="rtl"
    >
      {/* Hidden Canvas used for high-DPI rendering */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Modal Container */}
      <div className="w-full max-w-xl max-h-[92vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E6E6F0]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center border border-[#E6E6F0] text-amber-200">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-amber-200">
                مشاركة الذكر النبوي والدعاء
              </h3>
              <p className="text-xs text-emerald-100/85">
                كصورة مصممة فاخرة أو نص منسق مع بصمة التطبيق
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection: Image Card vs Formatted Text */}
        <div className="grid grid-cols-2 bg-[#F7F7FC] p-1.5 border-b border-[#E6E6F0]">
          <button
            onClick={() => setActiveTab('image')}
            className={`py-2.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'image'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>بطاقة مصممة فاخرة 🎨</span>
          </button>

          <button
            onClick={() => setActiveTab('text')}
            className={`py-2.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'text'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:text-[#25263A]'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>نص منسق للنشر ✍️</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">

          {/* ══════ TAB 1: DESIGNED IMAGE CARD ══════ */}
          {activeTab === 'image' && (
            <div className="space-y-4 animate-fade-in">
              
              {/* Theme Picker */}
              <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]/80 flex items-center justify-between gap-2">
                <span className="text-xs font-black text-gray-700 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-[#5B5FEF]" />
                  <span>طابع التصميم:</span>
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setTheme('emerald')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'emerald'
                        ? 'bg-[#5B5FEF] text-amber-200 shadow-2xs font-black ring-2 ring-[#5B5FEF]'
                        : 'bg-white text-gray-700 hover:bg-[#4CAF82]/12 border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span>زمردي نبوي</span>
                  </button>

                  <button
                    onClick={() => setTheme('parchment')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'parchment'
                        ? 'bg-[#4145C7] text-amber-100 shadow-2xs font-black ring-2 ring-[#5B5FEF]'
                        : 'bg-white text-gray-700 hover:bg-[#EEEEFF] border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-200 border border-amber-400" />
                    <span>مخطوطة عتيقة</span>
                  </button>

                  <button
                    onClick={() => setTheme('midnight')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      theme === 'midnight'
                        ? 'bg-[#0B1120] text-amber-300 shadow-2xs font-black ring-2 ring-amber-400'
                        : 'bg-white text-gray-700 hover:bg-slate-100 border border-[#E6E6F0]'
                    }`}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-900" />
                    <span>كحلي وسكينة</span>
                  </button>
                </div>
              </div>

              {/* Visual Card Preview */}
              <div className="relative group rounded-2xl overflow-hidden border-2 border-[#E6E6F0] shadow-md bg-gray-100 flex items-center justify-center">
                {imagePreviewUrl ? (
                  <img
                    src={imagePreviewUrl}
                    alt="بطاقة الذكر المصممة"
                    className="w-full max-h-[360px] object-contain rounded-2xl select-none"
                  />
                ) : (
                  <div className="py-24 text-center text-gray-400 text-xs flex flex-col items-center gap-2">
                    <Sparkles className="w-6 h-6 text-amber-400 animate-spin" />
                    <span>جاري إنشاء البطاقة المصممة...</span>
                  </div>
                )}

                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  <span>معاينة عالية الدقة 1080×1080</span>
                </div>
              </div>

              {/* Action Buttons for Image */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                {/* 1. Share Image Direct */}
                <button
                  onClick={handleShareImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4CAF82] text-white text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Share2 className="w-4 h-4 text-amber-300" />
                  <span>مشاركة الصورة</span>
                </button>

                {/* 2. Download Image */}
                <button
                  onClick={handleDownloadImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-[#25263A] text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل البطاقة (PNG)</span>
                </button>

                {/* 3. Copy Image to Clipboard */}
                <button
                  onClick={handleCopyImage}
                  disabled={isGenerating}
                  className="py-3 px-3 rounded-2xl bg-white hover:bg-gray-100 text-[#25263A] border border-[#E6E6F0] text-xs font-black shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {copiedImage ? (
                    <>
                      <Check className="w-4 h-4 text-[#4CAF82]" />
                      <span className="text-[#4CAF82]">تم نسخ الصورة!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#77798C]" />
                      <span>نسخ الصورة</span>
                    </>
                  )}
                </button>
              </div>

              {/* Social Channels Quick Share */}
              <div className="pt-2 border-t border-[#E6E6F0]">
                <span className="text-xs font-bold text-[#77798C] block mb-2 text-center">
                  مشاركة النص والبطاقة مباشرة عبر التطبيقات:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={handleShareWhatsApp}
                    className="py-2 px-3 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 text-[#4CAF82]" />
                    <span>واتساب</span>
                  </button>

                  <button
                    onClick={handleShareTelegram}
                    className="py-2 px-3 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-sky-600" />
                    <span>تليجرام</span>
                  </button>

                  <button
                    onClick={handleShareTwitter}
                    className="py-2 px-3 rounded-xl bg-gray-50 hover:bg-gray-100 text-[#25263A] border border-[#E6E6F0] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span className="font-bold">𝕏</span>
                    <span>تويتر / X</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* ══════ TAB 2: FORMATTED TEXT FOR SOCIAL MEDIA ══════ */}
          {activeTab === 'text' && (
            <div className="space-y-4 animate-fade-in">
              
              <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0]/80 flex items-center justify-between">
                <span className="text-xs font-black text-gray-700">
                  النص الجاهز للمشاركة عبر تطبيقات المحادثة والمنشورات:
                </span>
                <span className="text-[11px] font-bold text-[#4145C7] bg-[#4CAF82]/12 px-2.5 py-1 rounded-lg border border-[#4CAF82]/40">
                  شامل لبصمة التطبيق والمصدر ✨
                </span>
              </div>

              {/* Text Preview Box */}
              <div className="p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-inner font-tajawal text-sm text-[#25263A] whitespace-pre-line leading-relaxed select-text">
                {formattedText}
              </div>

              {/* Text Action Toolbar */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={handleCopyFormattedText}
                  className="py-3 px-4 rounded-2xl bg-[#5B5FEF] hover:bg-[#4CAF82] text-white text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {copiedText ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>تم نسخ النص بنجاح! 📋</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-amber-200" />
                      <span>نسخ النص الكامل بالبصمة</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleNativeShareText}
                  className="py-3 px-4 rounded-2xl bg-gradient-to-r from-[#E8B84A] to-[#E8B84A] hover:from-[#E8B84A] hover:to-[#E8B84A] text-[#25263A] text-xs font-black shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>مشاركة النص فوراً</span>
                </button>
              </div>

              {/* Social Channels Quick Share */}
              <div className="pt-2 border-t border-[#E6E6F0]">
                <span className="text-xs font-bold text-[#77798C] block mb-2 text-center">
                  مشاركة سريعة عبر المنصات:
                </span>
                <div className="grid grid-cols-4 gap-2">
                  <button
                    onClick={handleShareWhatsApp}
                    className="py-2.5 px-2 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 text-[#4CAF82]" />
                    <span>واتساب</span>
                  </button>

                  <button
                    onClick={handleShareTelegram}
                    className="py-2.5 px-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-sky-600" />
                    <span>تليجرام</span>
                  </button>

                  <button
                    onClick={handleShareTwitter}
                    className="py-2.5 px-2 rounded-xl bg-gray-50 hover:bg-gray-100 text-[#25263A] border border-[#E6E6F0] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span className="font-bold">𝕏</span>
                    <span>X</span>
                  </button>

                  <button
                    onClick={handleShareFacebook}
                    className="py-2.5 px-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span className="font-bold">f</span>
                    <span>فيسبوك</span>
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer Brand */}
        <div className="bg-[#F7F7FC] px-5 py-3 border-t border-[#E6E6F0] flex items-center justify-between text-[11px] text-[#77798C]">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span className="font-semibold text-gray-700">تطبيق رِفْق | RIFQ</span>
            <span className="text-gray-300">•</span>
            <span>الدال على الخير كفاعله</span>
          </div>
          <span className="text-[#4145C7] font-bold">بصمة موثقة ومجانية ✨</span>
        </div>

      </div>
    </div>
  );
};
