import React, { useState, useEffect } from 'react';
import { X, Check, Calendar, Trophy, BarChart3, Clock, Sparkles } from 'lucide-react';
import { DailyPrayerTracker, PrayerKey, PrayerTrackingStatus } from '../../types';
import { triggerHaptic } from '../../utils/prayerAudio';
import {
  loadPrayerTrackerHistory,
  savePrayerTrackerStatus,
} from '../../utils/prayerFocusService';

interface PrayerTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDateStr: string; // YYYY-MM-DD
}

const PRAYER_NAMES: { key: PrayerKey; nameAr: string; icon: string }[] = [
  { key: 'fajr', nameAr: 'الفجر', icon: '🌅' },
  { key: 'dhuhr', nameAr: 'الظهر', icon: '🕛' },
  { key: 'asr', nameAr: 'العصر', icon: '🌇' },
  { key: 'maghrib', nameAr: 'المغرب', icon: '🌆' },
  { key: 'isha', nameAr: 'العشاء', icon: '🌃' }
];

const STATUS_CONFIG: Record<
  PrayerTrackingStatus,
  { label: string; bg: string; text: string; border: string; icon: string }
> = {
  mosque: {
    label: 'في المسجد 🕌',
    bg: 'bg-[#4CAF82]/12',
    text: 'text-[#4CAF82]',
    border: 'border-[#4CAF82]/40',
    icon: '🕌'
  },
  on_time: {
    label: 'في وقتها ✅',
    bg: 'bg-blue-100',
    text: 'text-blue-900',
    border: 'border-blue-400',
    icon: '✅'
  },
  late: {
    label: 'قضاءً ⏳',
    bg: 'bg-[#EEEEFF]',
    text: 'text-[#4145C7]',
    border: 'border-amber-400',
    icon: '⏳'
  },
  missed: {
    label: 'فائتة ❌',
    bg: 'bg-rose-100',
    text: 'text-rose-900',
    border: 'border-rose-300',
    icon: '❌'
  },
  none: {
    label: 'لم تُسجل',
    bg: 'bg-gray-100',
    text: 'text-[#77798C]',
    border: 'border-[#E6E6F0]',
    icon: '⚪'
  }
};

export const PrayerTrackerModal: React.FC<PrayerTrackerModalProps> = ({
  isOpen,
  onClose,
  currentDateStr
}) => {
  const [trackerHistory, setTrackerHistory] = useState<Record<string, DailyPrayerTracker>>(
    loadPrayerTrackerHistory
  );

  useEffect(() => {
    const syncHistory = () => {
      setTrackerHistory(loadPrayerTrackerHistory());
    };
    window.addEventListener('rifq-prayer-tracker-updated', syncHistory);
    return () => window.removeEventListener('rifq-prayer-tracker-updated', syncHistory);
  }, []);

  const todayData: DailyPrayerTracker = trackerHistory[currentDateStr] || {
    date: currentDateStr,
    prayers: {
      fajr: 'none',
      sunrise: 'none',
      dhuhr: 'none',
      asr: 'none',
      maghrib: 'none',
      isha: 'none'
    }
  };

  const setPrayerStatus = (prayerKey: PrayerKey, status: PrayerTrackingStatus) => {
    triggerHaptic(30);
    const next = savePrayerTrackerStatus(currentDateStr, prayerKey, status);
    setTrackerHistory(next);
  };

  // Calculations for today
  const trackedCount = PRAYER_NAMES.filter((p) => {
    const st = todayData.prayers[p.key];
    return st === 'mosque' || st === 'on_time' || st === 'late';
  }).length;
  const mosqueCount = PRAYER_NAMES.filter((p) => todayData.prayers[p.key] === 'mosque').length;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
              📊
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">سجل وتتبع الصلوات الخمس</h3>
              <p className="text-xs text-emerald-200">حافظ على صلاتك وراقب التزامك اليومي والأسبوعي</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Today Summary Score */}
        <div className="p-4 bg-[#EEEEFF]/80 border-b border-[#E6E6F0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-emerald-700 text-amber-300 flex items-center justify-center font-black text-lg shadow-sm">
              {trackedCount}/5
            </div>
            <div>
              <h4 className="font-bold text-sm text-[#25263A]">صلوات اليوم المؤداة</h4>
              <p className="text-xs text-[#77798C]">
                منها {mosqueCount} صلوات في المسجد جماعة 🕌
              </p>
            </div>
          </div>
          <div className="text-left">
            <span className="text-lg font-black text-[#4145C7]">
              {Math.round((trackedCount / 5) * 100)}%
            </span>
            <span className="text-xs text-[#77798C] block">نسبة الالتزام</span>
          </div>
        </div>

        {/* Prayer List Status Toggles */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {PRAYER_NAMES.map((prayer) => {
            const currentStatus = todayData.prayers[prayer.key] || 'none';

            return (
              <div
                key={prayer.key}
                className="p-3.5 rounded-2xl border border-[#E6E6F0]/80 bg-white hover:border-amber-300 transition-all shadow-2xs flex flex-col gap-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{prayer.icon}</span>
                    <span className="font-bold text-sm text-[#25263A]">صلاة {prayer.nameAr}</span>
                  </div>
                  <span
                    className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${STATUS_CONFIG[currentStatus].bg} ${STATUS_CONFIG[currentStatus].text} ${STATUS_CONFIG[currentStatus].border}`}
                  >
                    {STATUS_CONFIG[currentStatus].label}
                  </span>
                </div>

                {/* 4 Status Option Buttons */}
                <div className="grid grid-cols-4 gap-1.5 text-xs font-bold">
                  <button
                    onClick={() => setPrayerStatus(prayer.key, 'mosque')}
                    className={`py-1.5 px-1 rounded-xl transition-all border cursor-pointer ${
                      currentStatus === 'mosque'
                        ? 'bg-[#5B5FEF] text-white border-emerald-700 shadow-xs'
                        : 'bg-[#4CAF82]/12 text-[#4CAF82] border-[#4CAF82]/40 hover:bg-[#4CAF82]/12'
                    }`}
                  >
                    مسجد 🕌
                  </button>
                  <button
                    onClick={() => setPrayerStatus(prayer.key, 'on_time')}
                    className={`py-1.5 px-1 rounded-xl transition-all border cursor-pointer ${
                      currentStatus === 'on_time'
                        ? 'bg-blue-600 text-white border-blue-700 shadow-xs'
                        : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                    }`}
                  >
                    بالوقت ✅
                  </button>
                  <button
                    onClick={() => setPrayerStatus(prayer.key, 'late')}
                    className={`py-1.5 px-1 rounded-xl transition-all border cursor-pointer ${
                      currentStatus === 'late'
                        ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                        : 'bg-[#EEEEFF] text-[#4145C7] border-[#E6E6F0] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    قضاءً ⏳
                  </button>
                  <button
                    onClick={() => setPrayerStatus(prayer.key, 'missed')}
                    className={`py-1.5 px-1 rounded-xl transition-all border cursor-pointer ${
                      currentStatus === 'missed'
                        ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                        : 'bg-gray-50 text-[#77798C] border-[#E6E6F0] hover:bg-rose-50 hover:text-rose-700'
                    }`}
                  >
                    فائتة ❌
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-gray-50 border-t border-[#E6E6F0] text-center text-xs text-[#77798C]">
          «إن الصلاة كانت على المؤمنين كتاباً موقوتاً» • يتم حفظ السجل تلقائياً
        </div>
      </div>
    </div>
  );
};
