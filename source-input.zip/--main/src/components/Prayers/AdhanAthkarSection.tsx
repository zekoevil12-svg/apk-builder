import React, { useState } from 'react';
import { Volume2, Sparkles, BookOpen, Check, Copy, ArrowRight, ShieldCheck } from 'lucide-react';
import { triggerHaptic } from '../../utils/prayerAudio';

interface AdhanDhikrItem {
  id: string;
  stage: string;
  title: string;
  arabicText: string;
  translationOrInstruction: string;
  virtue: string;
  hadithSource: string;
  targetCount: number;
}

const ADHAN_ATHKAR: AdhanDhikrItem[] = [
  {
    id: 'adhan-1',
    stage: 'أثناء سماع الأذان',
    title: 'متابعة المؤذن والحوقلة عند الحيعلتين',
    arabicText: 'يُردد السامع مثل ما يقول المؤذن حرفاً بحرف، إلا عند قوله:\n«حَيَّ عَلَى الصَّلَاةِ، حَيَّ عَلَى الْفَلَاحِ»\nفيقول السامع:\n«لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ»',
    translationOrInstruction: 'وفي أذان الفجر عند قول المؤذن: «الصلاة خير من النوم»، يقول السامع مثله: «الصلاة خير من النوم».',
    virtue: '«إذا قال المؤذن: الله أكبر الله أكبر، فقال أحدكم: الله أكبر الله أكبر... من قلبه دخل الجنة».',
    hadithSource: 'صحيح مسلم (385)',
    targetCount: 1
  },
  {
    id: 'adhan-2',
    stage: 'عقب انتهاء الأذان',
    title: 'الشهادة بالتوحيد والرضا بالله ورسوله ودينه',
    arabicText: '«وَأَنَا أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَنَّ مُحَمَّداً عَبْدُهُ وَرَسُولُهُ، رَضِيتُ بِاللَّهِ رَبّاً، وَبِمُحَمَّدٍ رَسُولاً، وَبِالإِسْلَامِ دِيناً».',
    translationOrInstruction: 'يُقال عقب فراغ المؤذن من التشهد أو عقب انتهاء الأذان مباشرة.',
    virtue: '«مَنْ قَالَ حِينَ يَسْمَعُ الْمُؤَذِّنَ... غُفِرَ لَهُ ذَنْبُهُ».',
    hadithSource: 'صحيح مسلم (386)',
    targetCount: 1
  },
  {
    id: 'adhan-3',
    stage: 'عقب الأذان',
    title: 'الصلاة الإبراهيمية على النبي ﷺ',
    arabicText: '«اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ، اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ».',
    translationOrInstruction: 'الصلاة على النبي ﷺ بأي صيغة مشروعة والأفضل الصلاة الإبراهيمية.',
    virtue: '«فَإِنَّهُ مَنْ صَلَّى عَلَيَّ صَلَاةً صَلَّى اللَّهُ عَلَيْهِ بِهَا عَشْراً».',
    hadithSource: 'صحيح مسلم (384)',
    targetCount: 1
  },
  {
    id: 'adhan-4',
    stage: 'عقب الأذان',
    title: 'سؤال الوسيلة والفضيلة والمقام المحمود',
    arabicText: '«اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ، وَالصَّلَاةِ الْقَائِمَةِ، آتِ مُحَمَّداً الْوَسِيلَةَ وَالْفَضِيلَةَ، وَابْعَثْهُ مَقَاماً مَحْمُوداً الَّذِي وَعَدْتَهُ».',
    translationOrInstruction: 'الوسيلة: أعلى منزلة في الجنة لا تنبغي إلا لعبد واحد وهو رسول الله ﷺ.',
    virtue: '«مَنْ قَالَ حِينَ يَسْمَعُ النِّدَاءَ... حَلَّتْ لَهُ شَفَاعَتِي يَوْمَ الْقِيَامَةِ».',
    hadithSource: 'صحيح البخاري (614)',
    targetCount: 1
  },
  {
    id: 'adhan-5',
    stage: 'بين الأذان والإقامة',
    title: 'الدعاء المستجاب بين الأذان والإقامة',
    arabicText: 'وقت مبارك يُستحب فيه للمسلم أن يسأل الله تعالى من خيري الدنيا والآخرة لنفسه ووالديه وأهله وأمته.',
    translationOrInstruction: 'التوجه إلى الله تعالى بالدعاء بإخلاص ورجاء وحضور قلب.',
    virtue: '«إِنَّ الدُّعَاءَ لَا يُرَدُّ بَيْنَ الأَذَانِ وَالإِقَامَةِ، فَادْعُوا».',
    hadithSource: 'سنن أبي داود (521) والترمذي (212) - صحيح',
    targetCount: 1
  },
  {
    id: 'adhan-6',
    stage: 'آداب المسجد',
    title: 'دعاء دخول المسجد والخروج منه',
    arabicText: 'عند الدخول (بالرجل اليمنى):\n«بِسْمِ اللَّهِ، وَالصَّلَاةُ وَالسَّلَامُ عَلَى رَسُولِ اللَّهِ، اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ».\n\nعند الخروج (بالرجل اليسرى):\n«بِسْمِ اللَّهِ، وَالصَّلَاةُ وَالسَّلَامُ عَلَى رَسُولِ اللَّهِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ، اللَّهُمَّ اعْصِمْنِي مِنَ الشَّيْطَانِ الرَّجِيمِ».',
    translationOrInstruction: 'تقديم اليمين عند الدخول مع السكينة، واليسار عند الخروج.',
    virtue: 'سنة نبوية جليلة تحفظ المسلم وتفتح له أبواب رحمة الرحمن وفضله.',
    hadithSource: 'صحيح مسلم (713) وسنن ابن ماجه',
    targetCount: 1
  }
];

export const AdhanAthkarSection: React.FC = () => {
  const [completedIds, setCompletedIds] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleComplete = (id: string) => {
    triggerHaptic(25);
    setCompletedIds((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleCopy = (item: AdhanDhikrItem) => {
    triggerHaptic(20);
    const text = `${item.title}\n\n${item.arabicText}\n\nفضل الذكر: ${item.virtue}\nالمصدر: ${item.hadithSource}`;
    navigator.clipboard?.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const completedCount = Object.values(completedIds).filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* Banner */}
      <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white rounded-3xl p-4 sm:p-5 border border-amber-400/30 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
            📢
          </div>
          <div>
            <h2 className="font-tajawal font-black text-base sm:text-lg text-amber-200">
              أذكار وسنن الأذان والإقامة
            </h2>
            <p className="text-xs text-emerald-200">
              السنن النبوية الخمس المؤكدة عند سماع النداء ونيل شفاعة النبي ﷺ
            </p>
          </div>
        </div>

        <div className="bg-white/10 px-3 py-1.5 rounded-xl text-center border border-white/15">
          <span className="text-[10px] text-amber-200 block">الإنجاز اليومي</span>
          <span className="font-bold text-sm text-white">
            {completedCount} / {ADHAN_ATHKAR.length}
          </span>
        </div>
      </div>

      {/* Grid of Dhikr Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {ADHAN_ATHKAR.map((item, idx) => {
          const isDone = completedIds[item.id];

          return (
            <div
              key={item.id}
              className={`rounded-2xl border transition-all p-4 flex flex-col justify-between ${
                isDone
                  ? 'bg-emerald-50/70 border-emerald-300 shadow-2xs'
                  : 'bg-white border-[#E6E6F0] hover:border-amber-300 hover:shadow-xs'
              }`}
            >
              <div>
                {/* Stage Tag & Header */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#5B5FEF]/20">
                    {item.stage}
                  </span>
                  <span className="text-xs font-mono font-bold text-gray-400">
                    #{idx + 1}
                  </span>
                </div>

                <h3 className="font-black text-sm text-[#25263A] mb-2">{item.title}</h3>

                {/* Arabic Text */}
                <div className="bg-amber-50/50 border border-amber-200/50 rounded-xl p-3 text-sm font-serif leading-relaxed text-[#25263A] whitespace-pre-line text-center">
                  {item.arabicText}
                </div>

                {/* Instruction / Translation */}
                <p className="text-xs text-[#77798C] mt-2 leading-relaxed">
                  {item.translationOrInstruction}
                </p>

                {/* Virtue Box */}
                <div className="mt-2.5 p-2 rounded-xl bg-[#EEEEFF]/60 border border-[#E6E6F0] text-xs">
                  <span className="font-bold text-[#4CAF82] block text-[11px]">فضله العظيم:</span>
                  <p className="text-[#25263A] mt-0.5 leading-relaxed font-serif">{item.virtue}</p>
                  <span className="text-[10px] text-gray-400 block mt-0.5">
                    المصدر: {item.hadithSource}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-2 pt-3 border-t border-gray-100 mt-3">
                <button
                  onClick={() => handleCopy(item)}
                  className="px-2.5 py-1.5 rounded-xl text-xs font-bold text-gray-500 hover:text-[#5B5FEF] hover:bg-gray-100 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  {copiedId === item.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-600">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ الذكر</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => toggleComplete(item.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isDone
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-[#5B5FEF] hover:text-white'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{isDone ? 'تم القول بنجاح' : 'تحديد كمقروء'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
