import React, { useState, useEffect } from 'react';
import {
  Volume2,
  Play,
  Square,
  Check,
  Radio,
  Sliders,
  Sparkles,
  Award,
  Music,
  BellRing
} from 'lucide-react';
import { MUADHIN_OPTIONS, MuadhinOption } from '../../data/prayersData';
import { PrayerSettings } from '../../types';
import {
  playAdhanAudio,
  stopAdhanAudio,
  isAdhanPlaying,
  subscribeToAdhanState,
  triggerHaptic
} from '../../utils/prayerAudio';

interface MuadhinAudioShowcaseProps {
  settings: PrayerSettings;
  onUpdateSettings: (newSettings: PrayerSettings) => void;
}

export const MuadhinAudioShowcase: React.FC<MuadhinAudioShowcaseProps> = ({
  settings,
  onUpdateSettings
}) => {
  const [playingId, setPlayingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToAdhanState((isPlaying) => {
      if (!isPlaying) {
        setPlayingId(null);
      }
    });
    return unsub;
  }, []);

  const handlePlaySample = (muadhin: MuadhinOption) => {
    triggerHaptic(25);
    if (playingId === muadhin.id) {
      stopAdhanAudio();
      setPlayingId(null);
    } else {
      stopAdhanAudio();
      setPlayingId(muadhin.id);
      playAdhanAudio(
        muadhin,
        () => setPlayingId(null),
        () => setPlayingId(null),
        muadhin.nameAr,
        'adhan'
      );
    }
  };

  const handleSelectDefaultMuadhin = (id: string) => {
    triggerHaptic(30);
    onUpdateSettings({
      ...settings,
      selectedMuadhin: id
    });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white rounded-3xl p-4 sm:p-5 border border-amber-400/30 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
            🕌
          </div>
          <div>
            <h2 className="font-tajawal font-black text-base sm:text-lg text-amber-200">
              أصوات الأذان ونخبة مؤذني العالم الإسلامي
            </h2>
            <p className="text-xs text-emerald-200">
              استمع لنداء الحق بأعذب الأصوات التاريخية والحجازية والمصرية والمسجد الأقصى
            </p>
          </div>
        </div>
      </div>

      {/* Muadhin Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {MUADHIN_OPTIONS.map((muadhin) => {
          const isSelected = settings.selectedMuadhin === muadhin.id;
          const isCurrentlyPlaying = playingId === muadhin.id;

          return (
            <div
              key={muadhin.id}
              className={`rounded-2xl border p-4 transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-gradient-to-br from-amber-50 via-white to-amber-50/50 border-amber-400 shadow-md ring-1 ring-amber-300/50'
                  : 'bg-white border-[#E6E6F0] hover:border-amber-300 hover:shadow-xs'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5">
                    {muadhin.badgeText && (
                      <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                        {muadhin.badgeText}
                      </span>
                    )}
                    <span className="text-[11px] text-gray-500 font-mono">
                      ⏱ {muadhin.durationText}
                    </span>
                  </div>

                  {isSelected && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-600 text-white flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      <span>المؤذن الافتراضي</span>
                    </span>
                  )}
                </div>

                <h3 className="font-black text-sm text-[#25263A]">{muadhin.nameAr}</h3>
                <p className="text-xs text-[#5B5FEF] font-bold mt-0.5">{muadhin.cityAr}</p>
                <p className="text-xs text-[#77798C] mt-2 leading-relaxed">
                  {muadhin.descriptionAr}
                </p>
              </div>

              {/* Actions row */}
              <div className="flex items-center justify-between gap-2 pt-3 border-t border-gray-100 mt-3">
                <button
                  type="button"
                  onClick={() => handlePlaySample(muadhin)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
                    isCurrentlyPlaying
                      ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse'
                      : 'bg-amber-500 hover:bg-amber-600 text-white'
                  }`}
                >
                  {isCurrentlyPlaying ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-white" />
                      <span>إيقاف الصوت</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-white" />
                      <span>استماع للأذان</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => handleSelectDefaultMuadhin(muadhin.id)}
                  disabled={isSelected}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-100 text-emerald-800 cursor-default'
                      : 'bg-gray-100 hover:bg-[#5B5FEF] hover:text-white text-gray-700'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>{isSelected ? 'مُفعّل كافتراضي' : 'تعيين للأذان'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
