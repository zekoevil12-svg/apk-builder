import React from 'react';
import { X, Calendar, Sparkles, Clock, CheckCircle2, ChevronLeft, Moon } from 'lucide-react';
import { ISLAMIC_OCCASIONS } from '../../data/prayersData';
import { triggerHaptic } from '../../utils/prayerAudio';

interface IslamicCalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  hijriDay: number;
  hijriMonth: number;
  hijriYear: number;
  hijriFormatted: string;
  hijriAdjustment: number;
  onUpdateAdjustment: (adj: number) => void;
}

export const IslamicCalendarModal: React.FC<IslamicCalendarModalProps> = ({
  isOpen,
  onClose,
  hijriDay,
  hijriMonth,
  hijriYear,
  hijriFormatted,
  hijriAdjustment,
  onUpdateAdjustment
}) => {
  if (!isOpen) return null;

  // Compute days difference between current hijri date and occasion
  const occasionsWithCountdown = ISLAMIC_OCCASIONS.map((occ) => {
    // Approximate days until occasion (assuming ~30 days per month)
    let currentTotalDays = (hijriMonth - 1) * 29.5 + hijriDay;
    let targetTotalDays = (occ.hijriMonth - 1) * 29.5 + occ.hijriDay;

    let diffDays = Math.round(targetTotalDays - currentTotalDays);
    if (diffDays < 0) {
      // It's in the next year
      diffDays += 354;
    }

    return {
      ...occ,
      daysRemaining: diffDays
    };
  }).sort((a, b) => a.daysRemaining - b.daysRemaining);

  const nearestOccasion = occasionsWithCountdown[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
              🌙
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">التقويم الهجري والمناسبات الإسلامية</h3>
              <p className="text-xs text-emerald-200">أعظم المناسبات النبوية والعبادات الموسمية مع العد التنازلي</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Hijri Date & Adjustment Bar */}
        <div className="p-4 bg-[#EEEEFF]/80 border-b border-[#E6E6F0] flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-[#4145C7] font-bold block">التاريخ الهجري اليوم:</span>
              <span className="text-base sm:text-lg font-black text-[#4145C7]">{hijriFormatted}</span>
            </div>
            <div className="text-left">
              <span className="text-xs text-[#77798C] block">تعديل رؤية الهلال</span>
              <div className="flex items-center gap-1 mt-1">
                {[-2, -1, 0, 1, 2].map((adj) => (
                  <button
                    key={adj}
                    onClick={() => {
                      triggerHaptic(20);
                      onUpdateAdjustment(adj);
                    }}
                    className={`w-7 h-7 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      hijriAdjustment === adj
                        ? 'bg-[#5B5FEF] text-amber-300 shadow-xs'
                        : 'bg-white text-gray-700 border border-[#E6E6F0] hover:bg-[#EEEEFF]'
                    }`}
                  >
                    {adj > 0 ? `+${adj}` : adj}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Nearest Occasion Banner */}
          {nearestOccasion && (
            <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white p-3 rounded-2xl flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">✨</span>
                <div>
                  <span className="text-[11px] text-amber-200 font-bold block">أقرب مناسبة إسلامية قادمة:</span>
                  <span className="text-sm font-bold">{nearestOccasion.nameAr}</span>
                </div>
              </div>
              <div className="px-3 py-1 bg-amber-400 text-emerald-950 rounded-xl font-black text-xs shadow-xs">
                {nearestOccasion.daysRemaining === 0
                  ? 'اليوم المبارك! 🎉'
                  : `متبقي ${nearestOccasion.daysRemaining} يوم`}
              </div>
            </div>
          )}
        </div>

        {/* Occasions List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {occasionsWithCountdown.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-2xl border border-[#E6E6F0] bg-white hover:border-amber-300 transition-all shadow-2xs flex flex-col gap-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🕌</span>
                  <div>
                    <h4 className="font-bold text-sm text-[#25263A]">{item.nameAr}</h4>
                    <span className="text-xs text-[#4145C7] font-medium">
                      {item.hijriDay} {item.hijriMonthName}
                    </span>
                  </div>
                </div>

                <div className="text-left">
                  <span
                    className={`text-xs px-2.5 py-1 rounded-xl font-bold ${
                      item.daysRemaining === 0
                        ? 'bg-[#5B5FEF] text-white'
                        : item.daysRemaining <= 30
                        ? 'bg-[#EEEEFF] text-[#4145C7] border border-amber-300'
                        : 'bg-gray-100 text-[#77798C]'
                    }`}
                  >
                    {item.daysRemaining === 0 ? 'اليوم!' : `باقي ${item.daysRemaining} يوم`}
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#77798C] leading-relaxed pr-1">
                {item.description}
              </p>

              {item.virtues && item.virtues.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.virtues.map((v, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40/60 px-2 py-0.5 rounded-lg"
                    >
                      ✓ {v}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-[#E6E6F0] text-center text-xs text-[#77798C]">
          قال تعالى: ﴿يَسْأَلُونَكَ عَنِ الْأَهِلَّةِ ۖ قُلْ هِيَ مَوَاقِيتُ لِلنَّاسِ وَالْحَجِّ﴾
        </div>
      </div>
    </div>
  );
};
