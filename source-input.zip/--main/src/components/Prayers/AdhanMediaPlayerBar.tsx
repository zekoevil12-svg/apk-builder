import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Square,
  Volume2,
  VolumeX,
  Sparkles,
  Sliders,
  Check,
  X,
  AlertTriangle
} from 'lucide-react';
import {
  subscribeToAdhanPlayer,
  AdhanPlayerState,
  pauseAdhanAudio,
  resumeAdhanAudio,
  stopAdhanAudio,
  seekAdhanAudio,
  setAdhanVolume,
  toggleAdhanMute,
  triggerHaptic
} from '../../utils/prayerAudio';

function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export const AdhanMediaPlayerBar: React.FC = () => {
  const [playerState, setPlayerState] = useState<AdhanPlayerState>({
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    duration: 0,
    volume: 0.9,
    isMuted: false,
    muadhinName: '',
    muadhinCity: '',
    prayerName: '',
    soundMode: 'adhan',
    hasError: false
  });

  const [showVolumePopup, setShowVolumePopup] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToAdhanPlayer((state) => {
      setPlayerState(state);
    });
    return () => unsubscribe();
  }, []);

  // Show if audio is playing or paused
  if (!playerState.isPlaying && !playerState.isPaused && !playerState.hasError) {
    return null;
  }

  const progressPercent =
    playerState.duration > 0
      ? Math.min(100, Math.max(0, (playerState.currentTime / playerState.duration) * 100))
      : 0;

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPercent = parseFloat(e.target.value);
    const newTime = (newPercent / 100) * playerState.duration;
    seekAdhanAudio(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setAdhanVolume(val);
  };

  return (
    <div
      id="adhan-media-player-bar"
      className="fixed bottom-4 left-4 right-4 md:left-auto md:right-6 md:w-[480px] z-50 bg-[#0F2A1D] border border-amber-400/40 rounded-3xl p-3.5 sm:p-4 shadow-2xl backdrop-blur-xl text-white animate-in fade-in slide-in-from-bottom-6 duration-300"
      dir="rtl"
    >
      {/* Top row: Title, Mode & Dismiss */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2.5 min-w-0">
          {/* Animated sound wave / equalizer indicator */}
          <div className="w-9 h-9 rounded-2xl bg-amber-400/20 border border-amber-400/30 flex items-center justify-center shrink-0">
            {playerState.isPlaying ? (
              <div className="flex items-end gap-0.5 h-4">
                <span className="w-1 bg-amber-300 rounded-full animate-[bounce_0.8s_infinite] h-3"></span>
                <span className="w-1 bg-amber-400 rounded-full animate-[bounce_1.1s_infinite] h-4"></span>
                <span className="w-1 bg-amber-300 rounded-full animate-[bounce_0.9s_infinite] h-2.5"></span>
              </div>
            ) : (
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-black text-xs sm:text-sm text-amber-200 truncate">
                {playerState.prayerName ? `أذان صلاة ${playerState.prayerName}` : 'صوت الأذان المبارك'}
              </span>
              <span className="text-[10px] bg-[#5B5FEF]/80 text-emerald-200 px-2 py-0.5 rounded-full font-bold shrink-0">
                {playerState.soundMode === 'takbeer' ? 'الله أكبر فقط' : 'أذان كامل'}
              </span>
            </div>
            <span className="text-[11px] text-emerald-200/80 block truncate">
              {playerState.muadhinName} {playerState.muadhinCity ? `• ${playerState.muadhinCity}` : ''}
            </span>
          </div>
        </div>

        {/* Close / Stop button */}
        <button
          onClick={() => {
            triggerHaptic(20);
            stopAdhanAudio();
          }}
          className="w-8 h-8 rounded-xl bg-white/10 hover:bg-rose-500/30 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          title="إيقاف الأذان"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Warning banner if muted */}
      {(playerState.isMuted || playerState.volume === 0) && (
        <div className="mb-2.5 px-3 py-1.5 bg-amber-500/20 border border-amber-400/40 rounded-xl flex items-center justify-between text-[11px] text-amber-200">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-300" />
            <span>الصوت مكتوم حالياً في المشغل</span>
          </div>
          <button
            onClick={() => {
              toggleAdhanMute();
              if (playerState.volume === 0) setAdhanVolume(0.85);
            }}
            className="underline font-bold hover:text-white cursor-pointer"
          >
            إلغاء الكتم 🔊
          </button>
        </div>
      )}

      {/* Progress / Scrubber Bar */}
      <div className="space-y-1 mb-2">
        <div className="relative flex items-center">
          <input
            type="range"
            min="0"
            max="100"
            step="0.1"
            value={progressPercent}
            onChange={handleSeek}
            className="w-full h-1.5 bg-emerald-950/80 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
        </div>
        <div className="flex items-center justify-between text-[10px] text-emerald-200/70 font-mono font-medium">
          <span>{formatTime(playerState.currentTime)}</span>
          <span>{formatTime(playerState.duration)}</span>
        </div>
      </div>

      {/* Controls Row */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2">
          {/* Play / Pause Toggle */}
          {playerState.isPlaying ? (
            <button
              onClick={() => {
                triggerHaptic(20);
                pauseAdhanAudio();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-emerald-950 font-black text-xs flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5 fill-emerald-950" />
              <span>إيقاف مؤقت</span>
            </button>
          ) : (
            <button
              onClick={() => {
                triggerHaptic(20);
                resumeAdhanAudio();
              }}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black text-xs flex items-center gap-1.5 shadow-md transition-transform active:scale-95 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-emerald-950" />
              <span>متابعة الأذان</span>
            </button>
          )}

          {/* Stop Button */}
          <button
            onClick={() => {
              triggerHaptic(20);
              stopAdhanAudio();
            }}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Square className="w-3 h-3 fill-white" />
            <span>إنهاء</span>
          </button>
        </div>

        {/* Volume & Mute Controls */}
        <div className="relative flex items-center gap-2">
          <button
            onClick={() => {
              triggerHaptic(15);
              toggleAdhanMute();
            }}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            title={playerState.isMuted ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
          >
            {playerState.isMuted || playerState.volume === 0 ? (
              <VolumeX className="w-4 h-4 text-rose-300" />
            ) : (
              <Volume2 className="w-4 h-4 text-amber-300" />
            )}
          </button>

          {/* Quick Volume Slider */}
          <div className="hidden sm:flex items-center gap-1.5 w-24">
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={playerState.isMuted ? 0 : playerState.volume}
              onChange={handleVolumeChange}
              className="w-full h-1.5 bg-emerald-950 rounded-lg appearance-none cursor-pointer accent-amber-400"
              title="مستوى صوت الأذان"
            />
            <span className="text-[10px] text-amber-300/90 font-bold font-mono w-7 text-left">
              {Math.round((playerState.isMuted ? 0 : playerState.volume) * 100)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
