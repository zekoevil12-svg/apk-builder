import React, { useState, useMemo } from 'react';
import { Search, MapPin, Navigation, Star, Check, X, Globe, Sparkles, Building } from 'lucide-react';
import { CityLocation } from '../../types';
import { CITIES_DATABASE } from '../../data/citiesData';

interface CitySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCity: CityLocation;
  onSelectCity: (city: CityLocation) => void;
  onUseGps: () => void;
  isLocatingGps: boolean;
  gpsError: string | null;
}

export const CitySelectorModal: React.FC<CitySelectorModalProps> = ({
  isOpen,
  onClose,
  currentCity,
  onSelectCity,
  onUseGps,
  isLocatingGps,
  gpsError
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'egypt' | 'arab' | 'world'>('all');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('rafiq_favorite_cities');
      return saved ? JSON.parse(saved) : ['eg-cairo', 'sa-makkah', 'sa-madinah', 'ps-jerusalem'];
    } catch {
      return ['eg-cairo', 'sa-makkah', 'sa-madinah', 'ps-jerusalem'];
    }
  });

  const toggleFavorite = (cityId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavoriteIds((prev) => {
      const next = prev.includes(cityId) ? prev.filter((id) => id !== cityId) : [...prev, cityId];
      try {
        localStorage.setItem('rafiq_favorite_cities', JSON.stringify(next));
      } catch {
        // Ignored
      }
      return next;
    });
  };

  const filteredCities = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return CITIES_DATABASE.filter((city) => {
      const matchesCategory =
        selectedCategory === 'all' || city.regionCategory === selectedCategory;

      if (!matchesCategory) return false;

      if (!q) return true;

      return (
        city.nameAr.toLowerCase().includes(q) ||
        city.nameEn.toLowerCase().includes(q) ||
        city.countryAr.toLowerCase().includes(q) ||
        city.countryEn.toLowerCase().includes(q) ||
        (city.governorateAr && city.governorateAr.toLowerCase().includes(q))
      );
    });
  }, [searchQuery, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0]/60 overflow-hidden">
        {/* Modal Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
              📍
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">اختيار المدينة وتحديد الموقع</h3>
              <p className="text-xs text-emerald-200">جميع محافظات مصر، الدول العربية وعواصم العالم</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* GPS Quick Action */}
        <div className="p-3.5 bg-[#EEEEFF]/70 border-b border-[#E6E6F0]/50 flex flex-col gap-2">
          <button
            onClick={onUseGps}
            disabled={isLocatingGps}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-bold rounded-2xl shadow-xs flex items-center justify-center gap-2 text-sm transition-all disabled:opacity-60 cursor-pointer"
          >
            <Navigation className={`w-4 h-4 text-amber-300 ${isLocatingGps ? 'animate-spin' : ''}`} />
            <span>{isLocatingGps ? 'جاري تحديد موقعك الدقيق عبر الأقمار الصناعية (GPS)...' : 'تحديد موقعي التلقائي الدقيق (GPS)'}</span>
          </button>

          {gpsError && (
            <p className="text-xs text-rose-600 font-medium text-center bg-rose-50 p-2 rounded-xl border border-rose-200">
              ⚠️ {gpsError}
            </p>
          )}
        </div>

        {/* Search Input & Category Filters */}
        <div className="p-3.5 border-b border-[#E6E6F0] flex flex-col gap-2.5">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن محافظة (القاهرة، الإسكندرية...) أو دولة أو مدينة..."
              className="w-full bg-gray-50 border border-[#E6E6F0] rounded-2xl py-2.5 pr-10 pl-4 text-sm focus:outline-hidden focus:border-[#5B5FEF] focus:bg-white transition-all text-[#25263A]"
            />
            <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#77798C]"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-[#5B5FEF] text-white'
                  : 'bg-gray-100 text-[#77798C] hover:bg-gray-200'
              }`}
            >
              الكل ({CITIES_DATABASE.length})
            </button>
            <button
              onClick={() => setSelectedCategory('egypt')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap flex items-center gap-1 cursor-pointer ${
                selectedCategory === 'egypt'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-[#EEEEFF] text-[#4145C7] hover:bg-[#EEEEFF] border border-[#E6E6F0]/60'
              }`}
            >
              <span>🇪🇬</span>
              <span>محافظات مصر (٢٧)</span>
            </button>
            <button
              onClick={() => setSelectedCategory('arab')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap flex items-center gap-1 cursor-pointer ${
                selectedCategory === 'arab'
                  ? 'bg-[#5B5FEF] text-white'
                  : 'bg-gray-100 text-[#77798C] hover:bg-gray-200'
              }`}
            >
              <span>🌙</span>
              <span>الدول العربية</span>
            </button>
            <button
              onClick={() => setSelectedCategory('world')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors whitespace-nowrap flex items-center gap-1 cursor-pointer ${
                selectedCategory === 'world'
                  ? 'bg-[#5B5FEF] text-white'
                  : 'bg-gray-100 text-[#77798C] hover:bg-gray-200'
              }`}
            >
              <Globe className="w-3 h-3" />
              <span>مدن العالم</span>
            </button>
          </div>
        </div>

        {/* Cities List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2 max-h-[420px]">
          {filteredCities.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <Building className="w-12 h-12 mx-auto mb-2 text-gray-300 stroke-1" />
              <p className="text-sm font-bold">لم نجد مدينة مطابقة لبحثك</p>
              <p className="text-xs text-gray-400 mt-1">جرب البحث باسم آخر أو استخدم زر تحديد الموقع عبر GPS</p>
            </div>
          ) : (
            filteredCities.map((city) => {
              const isSelected = currentCity.id === city.id || (currentCity.nameAr === city.nameAr && currentCity.countryAr === city.countryAr);
              const isFav = favoriteIds.includes(city.id);

              return (
                <div
                  key={city.id}
                  onClick={() => {
                    onSelectCity(city);
                    onClose();
                  }}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer group ${
                    isSelected
                      ? 'bg-[#EEEEFF]/90 border-amber-400 shadow-sm'
                      : 'bg-white border-[#E6E6F0]/70 hover:border-amber-300 hover:bg-[#EEEEFF]/30'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 ${
                        isSelected
                          ? 'bg-[#5B5FEF] text-amber-300 shadow-xs'
                          : 'bg-gray-100 text-[#77798C] group-hover:bg-[#EEEEFF] group-hover:text-[#4145C7]'
                      }`}
                    >
                      {city.regionCategory === 'egypt' ? '🇪🇬' : city.regionCategory === 'arab' ? '🌙' : '🌍'}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-[#25263A]">{city.nameAr}</span>
                        {city.governorateAr && (
                          <span className="text-[10px] bg-[#EEEEFF] text-[#4145C7] px-1.5 py-0.5 rounded-md font-medium">
                            {city.governorateAr}
                          </span>
                        )}
                        {isSelected && (
                          <span className="text-[10px] bg-[#5B5FEF] text-white px-2 py-0.5 rounded-full font-bold">
                            الحالي
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-[#77798C] mt-0.5">
                        <span>{city.countryAr} ({city.nameEn})</span>
                        <span>•</span>
                        <span className="text-[11px] font-mono text-gray-400">
                          {city.latitude.toFixed(2)}°, {city.longitude.toFixed(2)}°
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => toggleFavorite(city.id, e)}
                      title={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                      className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                        isFav
                          ? 'text-amber-500 hover:bg-[#EEEEFF]'
                          : 'text-gray-300 hover:text-amber-500 hover:bg-gray-100'
                      }`}
                    >
                      <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400 text-amber-500' : ''}`} />
                    </button>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-gray-50 border-t border-[#E6E6F0] text-center text-xs text-[#77798C]">
          يتم حساب المواقيت بدقة علمية وفق إحداثيات المدينة المختارة
        </div>
      </div>
    </div>
  );
};
