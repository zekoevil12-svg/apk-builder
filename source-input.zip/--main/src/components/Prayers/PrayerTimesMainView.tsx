import React, { useState, useEffect, useMemo } from 'react';
import {
  Compass,
  Settings,
  Calendar,
  BarChart3,
  BookOpen,
  MapPin,
  Bell,
  BellOff,
  Sparkles,
  Volume2,
  ChevronDown,
  ChevronUp,
  Moon,
  Sun,
  Clock,
  Radio,
  Square,
  Lock,
  X,
  Play,
  Check,
  Share2,
  CalendarDays,
  HeartHandshake
} from 'lucide-react';
import {
  CityLocation,
  PrayerKey,
  PrayerSettings,
  DailyPrayerTracker,
  PrayerTrackingStatus
} from '../../types';
import { DEFAULT_PRAYER_SETTINGS } from '../../data/citiesData';
import { PRAYERS_METADATA, MUADHIN_OPTIONS } from '../../data/prayersData';
import {
  calculateAllPrayerData,
  formatPrayerTime,
  formatRemainingTime
} from '../../utils/prayerCalculator';
import {
  playAdhanAudio,
  stopAdhanAudio,
  triggerHaptic,
  subscribeToAdhanState
} from '../../utils/prayerAudio';
import {
  getNotificationPermission,
  requestNotificationPermission
} from '../../utils/notifications';
import { checkAndTriggerPrayerAdhanNow } from '../../utils/prayerScheduler';
import { CitySelectorModal } from './CitySelectorModal';
import { QiblaCompassView } from './QiblaCompassView';
import { PrayerSettingsModal } from './PrayerSettingsModal';
import { PostPrayerAthkarModal } from './PostPrayerAthkarModal';
import { PrayerTrackerModal } from './PrayerTrackerModal';
import { IslamicCalendarModal } from './IslamicCalendarModal';
import { AdhanMediaPlayerBar } from './AdhanMediaPlayerBar';
import { CelestialSunArc } from './CelestialSunArc';
import { MonthlyPrayerTimetable } from './MonthlyPrayerTimetable';
import { AdhanAthkarSection } from './AdhanAthkarSection';
import { PrayerFiqhGuide } from './PrayerFiqhGuide';
import { MuadhinAudioShowcase } from './MuadhinAudioShowcase';
import { PrayersSectionSvg } from '../Home/RifqSectionIcons';
import { PrayerFocusSettingsCard } from '../PrayerFocus/PrayerFocusSettingsCard';
import {
  loadPrayerFocusSettings,
  PrayerFocusSettings,
  startInAppPrayerMode,
  loadPrayerTrackerHistory,
  savePrayerTrackerStatus
} from '../../utils/prayerFocusService';

type PrayerTab = 'today' | 'timetable' | 'muadhins' | 'athkar' | 'fiqh';

const TRACKER_STATUS_BADGES: Record<
  PrayerTrackingStatus,
  { label: string; icon: string; bg: string; text: string; border: string }
> = {
  mosque: {
    label: 'في المسجد',
    icon: '🕌',
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200'
  },
  on_time: {
    label: 'في وقتها',
    icon: '✅',
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    border: 'border-blue-200'
  },
  late: {
    label: 'قضاءً',
    icon: '⏳',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200'
  },
  missed: {
    label: 'فائتة',
    icon: '❌',
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    border: 'border-rose-200'
  },
  none: {
    label: 'لم تسجل',
    icon: '⚪',
    bg: 'bg-gray-50',
    text: 'text-gray-500',
    border: 'border-gray-200'
  }
};

interface PrayerTimesMainViewProps {
  onBackToTasbih?: () => void;
}

export const PrayerTimesMainView: React.FC<PrayerTimesMainViewProps> = () => {
  // Navigation Tabs State
  const [activeTab, setActiveTab] = useState<PrayerTab>('today');

  // 1. Current City State
  const [currentCity, setCurrentCity] = useState<CityLocation>(() => {
    try {
      const saved = localStorage.getItem('rafiq_current_city');
      return saved
        ? JSON.parse(saved)
        : {
            id: 'eg-cairo',
            nameAr: 'القاهرة',
            nameEn: 'Cairo',
            countryAr: 'مصر',
            countryEn: 'Egypt',
            governorateAr: 'محافظة القاهرة',
            latitude: 30.0444,
            longitude: 31.2357,
            timezone: 'Africa/Cairo',
            defaultMethod: 'Egyptian',
            regionCategory: 'egypt'
          };
    } catch {
      return {
        id: 'eg-cairo',
        nameAr: 'القاهرة',
        nameEn: 'Cairo',
        countryAr: 'مصر',
        countryEn: 'Egypt',
        governorateAr: 'محافظة القاهرة',
        latitude: 30.0444,
        longitude: 31.2357,
        timezone: 'Africa/Cairo',
        defaultMethod: 'Egyptian',
        regionCategory: 'egypt'
      };
    }
  });

  // 2. Prayer Settings State
  const [prayerSettings, setPrayerSettings] = useState<PrayerSettings>(() => {
    try {
      const saved = localStorage.getItem('rafiq_prayer_settings');
      return saved ? JSON.parse(saved) : DEFAULT_PRAYER_SETTINGS;
    } catch {
      return DEFAULT_PRAYER_SETTINGS;
    }
  });

  // 3. UI Modal States
  const [isCityModalOpen, setIsCityModalOpen] = useState(false);
  const [isQiblaModalOpen, setIsQiblaModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAthkarModalOpen, setIsAthkarModalOpen] = useState(false);
  const [isTrackerModalOpen, setIsTrackerModalOpen] = useState(false);
  const [isCalendarModalOpen, setIsCalendarModalOpen] = useState(false);
  const [isFocusModalOpen, setIsFocusModalOpen] = useState(false);
  const [focusSettings, setFocusSettings] = useState<PrayerFocusSettings>(loadPrayerFocusSettings);

  // Prayer Tracker Status State
  const [trackerHistory, setTrackerHistory] = useState<Record<string, DailyPrayerTracker>>(
    loadPrayerTrackerHistory
  );

  useEffect(() => {
    const syncFocus = () => setFocusSettings(loadPrayerFocusSettings());
    window.addEventListener('rifq-prayer-focus-changed', syncFocus);
    return () => window.removeEventListener('rifq-prayer-focus-changed', syncFocus);
  }, []);

  useEffect(() => {
    const syncTracker = () => setTrackerHistory(loadPrayerTrackerHistory());
    window.addEventListener('rifq-prayer-tracker-updated', syncTracker);
    return () => window.removeEventListener('rifq-prayer-tracker-updated', syncTracker);
  }, []);

  // 4. Expandable prayer card details
  const [expandedPrayerKey, setExpandedPrayerKey] = useState<PrayerKey | null>(null);

  // 5. GPS State
  const [isLocatingGps, setIsLocatingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // 6. Live Clock State (updates every second)
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  // Live playing adhan state
  const [activeAdhanTitle, setActiveAdhanTitle] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToAdhanState((isPlaying, title) => {
      setActiveAdhanTitle(isPlaying ? title || 'الأذان' : null);
    });
    return unsub;
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Save Settings
  const handleUpdateSettings = (newSettings: PrayerSettings) => {
    setPrayerSettings(newSettings);
    try {
      localStorage.setItem('rafiq_prayer_settings', JSON.stringify(newSettings));
    } catch {
      // Ignored
    }
    checkAndTriggerPrayerAdhanNow();
  };

  // Save City
  const handleSelectCity = (city: CityLocation) => {
    setCurrentCity(city);
    if (city.defaultMethod && prayerSettings.method === 'Egyptian' && city.countryAr !== 'مصر') {
      handleUpdateSettings({ ...prayerSettings, method: city.defaultMethod });
    }
    try {
      localStorage.setItem('rafiq_current_city', JSON.stringify(city));
    } catch {
      // Ignored
    }
    checkAndTriggerPrayerAdhanNow();
  };

  // GPS Auto-detection handler
  const handleUseGps = () => {
    if (!navigator.geolocation) {
      setGpsError('خاصية تحديد الموقع (GPS) غير مدعومة في متصفحك.');
      return;
    }

    setIsLocatingGps(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        let detectedName = 'موقعي الحالي (GPS)';
        let detectedCountry = 'العالم';

        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&accept-language=ar`
          );
          if (res.ok) {
            const data = await res.json();
            const city =
              data.address?.city ||
              data.address?.town ||
              data.address?.state ||
              data.address?.county ||
              'موقعي';
            const country = data.address?.country || 'موقعي';
            detectedName = city;
            detectedCountry = country;
          }
        } catch {
          // Fallback to coordinates
        }

        const newCity: CityLocation = {
          id: `gps-${latitude.toFixed(2)}-${longitude.toFixed(2)}`,
          nameAr: detectedName,
          nameEn: 'GPS Location',
          countryAr: detectedCountry,
          countryEn: 'Current Location',
          latitude,
          longitude,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'Africa/Cairo',
          defaultMethod: detectedCountry.includes('مصر') ? 'Egyptian' : 'MuslimWorldLeague',
          regionCategory: detectedCountry.includes('مصر') ? 'egypt' : 'world'
        };

        handleSelectCity(newCity);
        setIsLocatingGps(false);
        setIsCityModalOpen(false);
        triggerHaptic([40, 40]);
      },
      (err) => {
        setIsLocatingGps(false);
        let msg = 'تعذر الوصول للموقع. يرجى تفعيل إذن الموقع الجغرافي للمتصفح.';
        if (err.code === err.PERMISSION_DENIED) {
          msg = 'تم رفض إذن الوصول للموقع. يرجى السماح بالموقع من إعدادات المتصفح.';
        }
        setGpsError(msg);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  };

  // Toggle notification for specific prayer
  const toggleNotification = (pkey: PrayerKey, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(25);
    const currentVal = prayerSettings.notifications[pkey] !== false;
    const nextVal = !currentVal;
    if (nextVal && getNotificationPermission() === 'default') {
      requestNotificationPermission();
    }
    const nextSettings: PrayerSettings = {
      ...prayerSettings,
      notifications: {
        ...prayerSettings.notifications,
        [pkey]: nextVal
      }
    };
    handleUpdateSettings(nextSettings);
  };

  // Play Adhan audio for specific prayer directly
  const handlePlayPrayerAdhan = (pkey: PrayerKey, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(25);
    const alertDetail = prayerSettings.prayerAlerts?.[pkey];
    const customMuadhin = MUADHIN_OPTIONS.find((m) => m.id === alertDetail?.customMuadhinId);
    const defaultMuadhin =
      MUADHIN_OPTIONS.find((m) => m.id === prayerSettings.selectedMuadhin) || MUADHIN_OPTIONS[0];
    const chosen = customMuadhin || defaultMuadhin;
    const pMeta = PRAYERS_METADATA[pkey];

    playAdhanAudio(
      chosen,
      undefined,
      undefined,
      chosen.nameAr,
      alertDetail?.mode === 'takbeer' ? 'takbeer' : 'adhan',
      pMeta.nameAr
    );
  };

  // 7. Calculate Prayer Times using adhan engine
  const prayerData = useMemo(() => {
    return calculateAllPrayerData(
      currentCity.latitude,
      currentCity.longitude,
      currentTime,
      prayerSettings
    );
  }, [currentCity, currentTime, prayerSettings]);

  // Today Date string for tracker (YYYY-MM-DD)
  const todayStr = `${currentTime.getFullYear()}-${(currentTime.getMonth() + 1)
    .toString()
    .padStart(2, '0')}-${currentTime.getDate().toString().padStart(2, '0')}`;

  const todayTracker = trackerHistory[todayStr]?.prayers || {};

  // Quick 1-tap tracker status cycle
  const handleCycleTrackerStatus = (pkey: PrayerKey, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(30);
    const currentStatus = todayTracker[pkey] || 'none';
    const sequence: PrayerTrackingStatus[] = ['none', 'mosque', 'on_time', 'late'];
    const nextIndex = (sequence.indexOf(currentStatus) + 1) % sequence.length;
    const nextStatus = sequence[nextIndex];
    const next = savePrayerTrackerStatus(todayStr, pkey, nextStatus);
    setTrackerHistory(next);
  };

  const prayersList: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  // Fasting Day Detection
  const dayOfWeek = currentTime.getDay(); // 1 = Monday, 4 = Thursday
  const hijriDay = prayerData.hijriDate.day;
  const isRamadan = prayerData.hijriDate.month === 9;
  const isArafah = prayerData.hijriDate.month === 12 && hijriDay === 9;
  const isAshura = prayerData.hijriDate.month === 1 && hijriDay === 10;
  const isWhiteDays = hijriDay >= 13 && hijriDay <= 15;
  const isSunnahFasting = dayOfWeek === 1 || dayOfWeek === 4 || isWhiteDays || isArafah || isAshura;
  const isFastingToday = isRamadan || isSunnahFasting;

  const fastingTitle = isRamadan
    ? 'صيام شهر رمضان المبارك'
    : isArafah
    ? 'صيام يوم عرفة العظيم'
    : isAshura
    ? 'صيام يوم عاشوراء'
    : isWhiteDays
    ? 'صيام الأيام البيض المباركة'
    : dayOfWeek === 1
    ? 'صيام يوم الإثنين (سنة نبوية)'
    : 'صيام يوم الخميس (سنة نبوية)';

  // Remaining time to Iftar
  const timeToIftarMs = Math.max(0, prayerData.iftarTime.getTime() - currentTime.getTime());
  const iftarRemaining = formatRemainingTime(timeToIftarMs);

  // Dynamic Background gradient based on current prayer / time of day
  const dynamicBackgroundStyle = useMemo(() => {
    switch (prayerData.currentPrayer) {
      case 'fajr':
        return 'from-[#0f172a] via-[#1e1b4b] to-[#311042]';
      case 'sunrise':
        return 'from-[#7c2d12] via-[#b45309] to-[#d97706]';
      case 'dhuhr':
        return 'from-[#0369a1] via-[#72B7E8] to-[#0f766e]';
      case 'asr':
        return 'from-[#9a3412] via-[#c2410c] to-[#78350f]';
      case 'maghrib':
        return 'from-[#831843] via-[#4c0519] to-[#1e1b4b]';
      case 'isha':
      default:
        return 'from-[#020617] via-[#0f172a] to-[#062419]';
    }
  }, [prayerData.currentPrayer]);

  const nextPrayerMeta = PRAYERS_METADATA[prayerData.nextPrayer];

  return (
    <div className="w-full space-y-4 text-[#25263A] animate-fade-in" dir="rtl">
      {/* 1. TOP SECTION BANNER */}
      <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white rounded-3xl p-4 sm:p-5 shadow-lg border border-amber-400/30 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-11 h-11 rounded-2xl bg-[#F7F7FC] border border-amber-400/50 flex items-center justify-center shadow-xs shrink-0">
            <PrayersSectionSvg size={32} />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-black text-amber-200 tracking-tight font-tajawal">
              مواقيت الصلاة والأذان
            </h1>
            <p className="text-xs text-emerald-200">
              {currentCity.nameAr} • دقة فلكية عالية مع المسار الشمسي والإمساكية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => setIsQiblaModalOpen(true)}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-amber-400/20 hover:bg-amber-400/30 text-amber-200 border border-amber-400/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            title="اتجاه القبلة"
          >
            <Compass className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">اتجاه القبلة</span>
          </button>

          <button
            onClick={() => setIsSettingsModalOpen(true)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="إعدادات المواقيت"
          >
            <Settings className="w-5 h-5 text-amber-200" />
          </button>
        </div>
      </div>

      {/* ACTIVE ADHAN PLAYBACK BAR */}
      {activeAdhanTitle && (
        <div className="bg-gradient-to-r from-amber-500 via-emerald-700 to-[#5B5FEF] text-white p-3.5 rounded-2xl shadow-lg border border-amber-300/40 flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center shrink-0">
              <Volume2 className="w-5 h-5 text-amber-200 animate-pulse" />
            </div>
            <div>
              <span className="font-black text-xs sm:text-sm text-white block">
                يُرفع الآن الأذان المبارك
              </span>
              <span className="text-[11px] text-amber-100">{activeAdhanTitle}</span>
            </div>
          </div>
          <button
            onClick={() => stopAdhanAudio()}
            className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Square className="w-3.5 h-3.5 fill-white" />
            <span>إيقاف الأذان</span>
          </button>
        </div>
      )}

      {/* 2. TAB NAVIGATION BAR */}
      <div className="bg-white p-1.5 rounded-2xl border border-[#E6E6F0] flex items-center gap-1 overflow-x-auto text-xs font-bold shadow-2xs scrollbar-none">
        <button
          onClick={() => {
            triggerHaptic(20);
            setActiveTab('today');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'today'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-100'
          }`}
        >
          <Sun className="w-4 h-4" />
          <span>اليوم والمسار الشمسي</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic(20);
            setActiveTab('timetable');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'timetable'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-100'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>جدول الشهر والإمساكية</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic(20);
            setActiveTab('muadhins');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'muadhins'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-100'
          }`}
        >
          <Volume2 className="w-4 h-4" />
          <span>أصوات المؤذنين</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic(20);
            setActiveTab('athkar');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'athkar'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-100'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>أذكار الأذان والإقامة</span>
        </button>

        <button
          onClick={() => {
            triggerHaptic(20);
            setActiveTab('fiqh');
          }}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
            activeTab === 'fiqh'
              ? 'bg-[#5B5FEF] text-white shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A] hover:bg-gray-100'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>فقه وأحكام الصلاة</span>
        </button>
      </div>

      {/* 3. TAB CONTENT */}
      {activeTab === 'timetable' && (
        <MonthlyPrayerTimetable currentCity={currentCity} settings={prayerSettings} />
      )}

      {activeTab === 'muadhins' && (
        <MuadhinAudioShowcase settings={prayerSettings} onUpdateSettings={handleUpdateSettings} />
      )}

      {activeTab === 'athkar' && <AdhanAthkarSection />}

      {activeTab === 'fiqh' && <PrayerFiqhGuide />}

      {activeTab === 'today' && (
        <div className="space-y-4">
          {/* HERO CARD WITH DYNAMIC BACKGROUND */}
          <div
            className={`relative rounded-3xl p-5 sm:p-6 text-white shadow-xl overflow-hidden transition-all duration-700 bg-gradient-to-br ${dynamicBackgroundStyle}`}
          >
            <div className="absolute -left-8 -bottom-8 w-48 h-48 opacity-10 pointer-events-none text-white">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
                <path d="M12 2l2.5 3.5h-5L12 2zm-7 8l1.5-3h11l1.5 3H5zm-2 3h18v7H3v-7zm2-2h14v2H5v-2zm7 3a3 3 0 0 0-3 3h6a3 3 0 0 0-3-3z" />
              </svg>
            </div>

            {/* Header row in card: Dates & City */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/15 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-amber-400/20 text-amber-300 border border-amber-400/40 px-2.5 py-0.5 rounded-full font-bold">
                    {prayerData.hijriDate.dayName}
                  </span>
                  <button
                    onClick={() => setIsCalendarModalOpen(true)}
                    className="text-sm sm:text-base font-black text-amber-200 hover:text-amber-100 flex items-center gap-1 cursor-pointer"
                  >
                    <span>{prayerData.hijriDate.formatted}</span>
                    <Moon className="w-3.5 h-3.5 text-amber-300" />
                  </button>
                </div>
                <p className="text-xs text-emerald-200/90 mt-0.5">
                  {currentTime.toLocaleDateString('ar-EG', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}{' '}
                  م
                </p>
              </div>

              {/* City Selector Button */}
              <button
                onClick={() => setIsCityModalOpen(true)}
                className="self-start sm:self-center px-3.5 py-2 rounded-2xl bg-black/25 hover:bg-black/40 border border-white/20 text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer backdrop-blur-xs shadow-xs"
              >
                <MapPin className="w-4 h-4 text-amber-300 shrink-0" />
                <span>
                  {currentCity.nameAr}، {currentCity.countryAr}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-300" />
              </button>
            </div>

            {/* Centerpiece: Next Prayer & Live Countdown */}
            <div className="py-5 sm:py-6 flex flex-col items-center justify-center text-center">
              <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-400/40 px-4 py-1.5 rounded-full mb-3 shadow-inner">
                <span className="text-lg">{nextPrayerMeta.icon}</span>
                <span className="text-xs font-bold text-amber-200">الصلاة القادمة:</span>
                <span className="text-sm font-black text-white">{nextPrayerMeta.nameAr}</span>
              </div>

              {/* Next Prayer Exact Time */}
              <div className="text-3xl sm:text-4xl font-black text-amber-300 font-mono tracking-tight drop-shadow-md">
                {formatPrayerTime(prayerData.nextPrayerTime, prayerSettings.timeFormat)}
              </div>

              {/* Live Countdown Clock */}
              <div className="mt-3 flex items-center gap-2 sm:gap-3">
                {(() => {
                  const rem = formatRemainingTime(prayerData.timeRemainingMs);
                  return (
                    <>
                      <div className="bg-black/30 border border-white/15 px-3 py-1.5 rounded-xl text-center min-w-[58px]">
                        <span className="text-xl sm:text-2xl font-black font-mono text-white block">
                          {rem.hours.toString().padStart(2, '0')}
                        </span>
                        <span className="text-[10px] text-emerald-200">ساعة</span>
                      </div>
                      <span className="text-xl font-bold text-amber-300">:</span>
                      <div className="bg-black/30 border border-white/15 px-3 py-1.5 rounded-xl text-center min-w-[58px]">
                        <span className="text-xl sm:text-2xl font-black font-mono text-white block">
                          {rem.minutes.toString().padStart(2, '0')}
                        </span>
                        <span className="text-[10px] text-emerald-200">دقيقة</span>
                      </div>
                      <span className="text-xl font-bold text-amber-300">:</span>
                      <div className="bg-black/30 border border-white/15 px-3 py-1.5 rounded-xl text-center min-w-[58px]">
                        <span className="text-xl sm:text-2xl font-black font-mono text-amber-300 block">
                          {rem.seconds.toString().padStart(2, '0')}
                        </span>
                        <span className="text-[10px] text-amber-200">ثانية</span>
                      </div>
                    </>
                  );
                })()}
              </div>

              <p className="text-xs text-amber-100/80 mt-2 font-medium">
                {prayerData.timeRemainingText}
              </p>
            </div>

            {/* Footer Highlights: Suhur, Iftar, Qibla Bearing */}
            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-white/15 text-center text-xs">
              <div className="bg-black/20 p-2 rounded-xl">
                <span className="text-[10px] text-emerald-200 block">الإمساك / السحور</span>
                <span className="font-mono font-bold text-white text-xs sm:text-sm mt-0.5 block">
                  {formatPrayerTime(prayerData.suhurTime, prayerSettings.timeFormat)}
                </span>
              </div>

              <div className="bg-black/20 p-2 rounded-xl">
                <span className="text-[10px] text-emerald-200 block">الإفطار (المغرب)</span>
                <span className="font-mono font-bold text-white text-xs sm:text-sm mt-0.5 block">
                  {formatPrayerTime(prayerData.iftarTime, prayerSettings.timeFormat)}
                </span>
              </div>

              <div
                onClick={() => setIsQiblaModalOpen(true)}
                className="bg-black/20 p-2 rounded-xl cursor-pointer hover:bg-black/30 transition-colors"
              >
                <span className="text-[10px] text-amber-300 flex items-center justify-center gap-1">
                  <span>اتجاه القبلة</span>
                  <Compass className="w-3 h-3" />
                </span>
                <span className="font-mono font-bold text-white text-xs sm:text-sm mt-0.5 block">
                  {prayerData.qiblaBearing}°
                </span>
              </div>
            </div>
          </div>

          {/* CELESTIAL SUN ARC COMPONENT */}
          <CelestialSunArc
            prayerData={prayerData}
            settings={prayerSettings}
            currentTime={currentTime}
          />

          {/* FASTING STATUS BANNER (If today is a Sunnah or Ramadan fasting day) */}
          {isFastingToday && (
            <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-emerald-600 text-white p-4 rounded-3xl shadow-md border border-amber-300/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-fade-in">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-white/20 flex items-center justify-center text-2xl shrink-0">
                  🥣
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-sm text-white">{fastingTitle}</span>
                    <span className="text-[10px] bg-white/25 px-2 py-0.5 rounded-full font-bold">
                      تقبل الله طاعتكم
                    </span>
                  </div>
                  <p className="text-xs text-amber-100 mt-0.5 font-serif">
                    «ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الأَجْرُ إِنْ شَاءَ اللَّهُ»
                  </p>
                </div>
              </div>

              <div className="bg-black/25 px-3 py-2 rounded-2xl text-left border border-white/20 shrink-0 self-start sm:self-auto">
                <span className="text-[10px] text-amber-200 block">باقي على مدفع الإفطار</span>
                <span className="font-mono font-black text-sm text-white">
                  {iftarRemaining.hours > 0 ? `${iftarRemaining.hours} س و ` : ''}
                  {iftarRemaining.minutes} دقيقة
                </span>
              </div>
            </div>
          )}

          {/* QUICK NAVIGATION BAR (Athkar, Tracker, Calendar, Qibla) */}
          <div className="grid grid-cols-4 gap-2 text-xs font-bold">
            <button
              onClick={() => setIsTrackerModalOpen(true)}
              className="p-3 rounded-2xl bg-white border border-[#E6E6F0]/80 hover:border-amber-400 hover:bg-[#EEEEFF]/50 transition-all flex flex-col items-center justify-center gap-1.5 shadow-2xs cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-[#4CAF82]/12 text-[#4CAF82] flex items-center justify-center group-hover:scale-105 transition-transform">
                <BarChart3 className="w-5 h-5" />
              </div>
              <span className="text-[#25263A]">سجل الصلوات</span>
            </button>

            <button
              onClick={() => setIsAthkarModalOpen(true)}
              className="p-3 rounded-2xl bg-white border border-[#E6E6F0]/80 hover:border-amber-400 hover:bg-[#EEEEFF]/50 transition-all flex flex-col items-center justify-center gap-1.5 shadow-2xs cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center group-hover:scale-105 transition-transform">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-[#25263A]">أذكار الصلاة</span>
            </button>

            <button
              onClick={() => setIsCalendarModalOpen(true)}
              className="p-3 rounded-2xl bg-white border border-[#E6E6F0]/80 hover:border-amber-400 hover:bg-[#EEEEFF]/50 transition-all flex flex-col items-center justify-center gap-1.5 shadow-2xs cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Calendar className="w-5 h-5" />
              </div>
              <span className="text-[#25263A]">المناسبات</span>
            </button>

            <button
              onClick={() => setIsQiblaModalOpen(true)}
              className="p-3 rounded-2xl bg-white border border-[#E6E6F0]/80 hover:border-amber-400 hover:bg-[#EEEEFF]/50 transition-all flex flex-col items-center justify-center gap-1.5 shadow-2xs cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                <Compass className="w-5 h-5" />
              </div>
              <span className="text-[#25263A]">بوصلة القبلة</span>
            </button>
          </div>

          {/* PRAYER FOCUS AND CONCENTRATION CARD */}
          <div className="bg-gradient-to-r from-[#1E1B4B] via-[#2A1B54] to-[#1E1B4B] text-white rounded-3xl p-4 sm:p-5 border border-amber-400/40 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-2xl shrink-0 animate-pulse">
                🕌
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-cairo font-black text-sm sm:text-base text-amber-200">
                    وضع الصلاة والخشوع
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-400/30 flex items-center gap-1">
                    <BellOff className="w-3 h-3" />
                    <span>إسكات التنبيهات المشتتة للذهن</span>
                  </span>
                </div>
                <p className="text-xs text-indigo-200 mt-1 leading-relaxed">
                  مؤقت تنازلي دقيق مع إسكات التنبيهات، واقتراحات لأذكار ما بعد الصلاة والتسبيح المأثور
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  const targetPrayer =
                    prayerData.currentPrayer !== 'sunrise' && prayerData.currentPrayer
                      ? prayerData.currentPrayer
                      : 'dhuhr';
                  startInAppPrayerMode({
                    prayerKey: targetPrayer,
                    durationMinutes: 20
                  });
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white font-black text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-all"
              >
                <span>بدء وضع الصلاة والخشوع الآن 🕌</span>
              </button>

              <button
                type="button"
                onClick={() => setIsFocusModalOpen(true)}
                className="w-full sm:w-auto p-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-indigo-200 hover:text-white border border-white/10 transition-colors cursor-pointer text-xs font-bold flex items-center justify-center gap-1.5"
                title="إعدادات الحماية المتقدمة"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>إعدادات القفل</span>
              </button>
            </div>
          </div>

          {/* 4. THE 6 PRAYER TIME CARDS */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-sm font-black text-[#25263A] flex items-center gap-2">
                <span>المواقيت الخمس وشروق الشمس</span>
                <span className="text-xs font-normal text-[#77798C]">
                  (طريقة{' '}
                  {prayerSettings.method === 'Egyptian'
                    ? 'المساحة المصرية'
                    : prayerSettings.method}
                  )
                </span>
              </h2>
              <button
                onClick={() => setIsSettingsModalOpen(true)}
                className="text-xs text-[#4CAF82] font-bold hover:underline cursor-pointer"
              >
                تعديل الطريقة
              </button>
            </div>

            {prayersList.map((pkey) => {
              const meta = PRAYERS_METADATA[pkey];
              const pTime = prayerData.times[pkey];
              const isCurrent = prayerData.currentPrayer === pkey;
              const isNext = prayerData.nextPrayer === pkey;
              const isNotified = prayerSettings.notifications[pkey] !== false;
              const isExpanded = expandedPrayerKey === pkey;
              const trackerStatus = todayTracker[pkey] || 'none';
              const trackerBadge = TRACKER_STATUS_BADGES[trackerStatus];
              const isFivePrayer = pkey !== 'sunrise';

              return (
                <div
                  key={pkey}
                  onClick={() => setExpandedPrayerKey(isExpanded ? null : pkey)}
                  className={`rounded-2xl border transition-all duration-300 overflow-hidden cursor-pointer ${
                    isNext
                      ? 'bg-gradient-to-l from-amber-50/90 via-white to-amber-50/40 border-amber-400 shadow-md ring-2 ring-amber-300/40'
                      : isCurrent
                      ? 'bg-[#4CAF82]/12/80 border-[#4CAF82]/40 shadow-sm'
                      : 'bg-white border-[#E6E6F0]/80 hover:border-[#E6E6F0] hover:shadow-xs'
                  }`}
                >
                  <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    {/* Left: Icon & Names */}
                    <div className="flex items-center gap-3.5">
                      <div
                        className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl shrink-0 transition-transform ${
                          isNext
                            ? 'bg-amber-400 text-emerald-950 shadow-xs scale-105'
                            : isCurrent
                            ? 'bg-[#5B5FEF] text-amber-200 shadow-xs'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {meta.icon}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-black text-base text-[#25263A]">{meta.nameAr}</h3>
                          <span className="text-[11px] text-[#77798C] font-medium">
                            ({meta.nameEn})
                          </span>
                          {isNext && (
                            <span className="text-[10px] bg-amber-500 text-white font-black px-2 py-0.5 rounded-full shadow-2xs animate-pulse">
                              القادمة
                            </span>
                          )}
                          {isCurrent && (
                            <span className="text-[10px] bg-[#5B5FEF] text-white font-black px-2 py-0.5 rounded-full shadow-2xs">
                              الحالية
                            </span>
                          )}

                          {/* Quick 1-tap Tracker Badge for the 5 prayers */}
                          {isFivePrayer && (
                            <button
                              type="button"
                              onClick={(e) => handleCycleTrackerStatus(pkey, e)}
                              title="اضغط للتغيير: في المسجد / في وقتها / قضاءً"
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 transition-all cursor-pointer ${trackerBadge.bg} ${trackerBadge.text} ${trackerBadge.border} hover:brightness-95`}
                            >
                              <span>{trackerBadge.icon}</span>
                              <span>{trackerBadge.label}</span>
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-[#77798C] mt-0.5">{meta.timeOfDayText}</p>
                      </div>
                    </div>

                    {/* Right: Exact Time, Audio Preview, Notification Toggle */}
                    <div className="flex items-center justify-between sm:justify-end gap-3 self-end sm:self-auto w-full sm:w-auto border-t sm:border-t-0 pt-2 sm:pt-0">
                      <div className="text-right sm:text-left">
                        <div className="text-lg sm:text-xl font-black font-mono text-[#25263A]">
                          {formatPrayerTime(pTime, prayerSettings.timeFormat)}
                        </div>
                        {isNext && (
                          <div className="text-[10px] text-[#4145C7] font-bold">
                            {prayerData.timeRemainingText}
                          </div>
                        )}
                      </div>

                      {/* Instant Adhan Audio Preview button */}
                      <button
                        type="button"
                        onClick={(e) => handlePlayPrayerAdhan(pkey, e)}
                        title="استماع فوري للأذان لهذه الصلاة"
                        className="w-9 h-9 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-800 flex items-center justify-center transition-colors cursor-pointer"
                      >
                        <Volume2 className="w-4 h-4 text-amber-700" />
                      </button>

                      {/* Bell Notification Toggle */}
                      <button
                        type="button"
                        onClick={(e) => toggleNotification(pkey, e)}
                        title={isNotified ? 'إلغاء التنبيه' : 'تفعيل التنبيه'}
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                          isNotified
                            ? 'bg-[#EEEEFF] text-[#4145C7] hover:bg-amber-200'
                            : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                        }`}
                      >
                        {isNotified ? (
                          <Bell className="w-4 h-4 fill-amber-500 text-[#4145C7]" />
                        ) : (
                          <BellOff className="w-4 h-4" />
                        )}
                      </button>

                      <div className="text-gray-400">
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expandable Sunnah & Virtue Card */}
                  {isExpanded && (
                    <div className="bg-[#EEEEFF]/60 border-t border-[#E6E6F0]/50 p-4 space-y-3 text-xs animate-fade-in">
                      {/* Per-Prayer Alert & Custom Muadhin Summary */}
                      {(() => {
                        const alertDetail = prayerSettings.prayerAlerts?.[pkey];
                        const customMuadhin = MUADHIN_OPTIONS.find(
                          (m) => m.id === alertDetail?.customMuadhinId
                        );
                        const defaultMuadhin =
                          MUADHIN_OPTIONS.find((m) => m.id === prayerSettings.selectedMuadhin) ||
                          MUADHIN_OPTIONS[0];
                        const chosenMuadhin = customMuadhin || defaultMuadhin;
                        const mode = alertDetail?.mode || 'adhan';

                        return (
                          <div className="p-2.5 bg-white rounded-xl border border-[#4CAF82]/40 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <div className="w-7 h-7 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] flex items-center justify-center shrink-0">
                                <Radio className="w-3.5 h-3.5" />
                              </div>
                              <div>
                                <span className="font-black text-[#25263A] block text-[11px]">
                                  تنبيه {meta.nameAr}:{' '}
                                  {mode === 'adhan'
                                    ? `أذان بصوت (${chosenMuadhin.nameAr})`
                                    : mode === 'takbeer'
                                    ? `تكبيرات (${chosenMuadhin.nameAr})`
                                    : mode === 'chime'
                                    ? 'نغمة وقار هادئة'
                                    : 'إشعار صامت'}
                                </span>
                                <span className="text-[10px] text-[#77798C]">
                                  {customMuadhin
                                    ? 'تم تعيين مؤذن خاص لهذه الصلاة'
                                    : 'يتبع المؤذن الافتراضي للتطبيق'}
                                </span>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setIsSettingsModalOpen(true);
                              }}
                              className="px-2.5 py-1 bg-[#5B5FEF] hover:bg-[#4145C7] text-white rounded-lg text-[10px] font-bold shrink-0 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <span>تغيير التنبيه</span>
                              <Settings className="w-3 h-3" />
                            </button>
                          </div>
                        );
                      })()}

                      <div className="font-bold text-[#25263A] flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-[#4145C7]" />
                        <span>
                          السنن والنوافل المرتبطة (
                          {meta.rakats > 0 ? `${meta.rakats} ركعات فريضة` : 'نافلة'}):
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-gray-700 pt-1">
                        <div className="bg-white p-2.5 rounded-xl border border-[#E6E6F0]/60">
                          <span className="font-bold text-[#4CAF82] block">
                            سنة ما قبل الصلاة:
                          </span>
                          <span className="mt-0.5 block">{meta.sunanBefore}</span>
                        </div>
                        <div className="bg-white p-2.5 rounded-xl border border-[#E6E6F0]/60">
                          <span className="font-bold text-[#4CAF82] block">
                            سنة ما بعد الصلاة:
                          </span>
                          <span className="mt-0.5 block">{meta.sunanAfter}</span>
                        </div>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-[#E6E6F0]/60 text-gray-700">
                        <span className="font-bold text-[#4145C7] block">
                          فضل الصلاة والحديث الشريف:
                        </span>
                        <p className="mt-1 leading-relaxed font-serif text-[13px]">
                          {meta.hadithVirtue}
                        </p>
                        <span className="text-[10px] text-gray-400 block mt-1">
                          المصدر: {meta.hadithSource}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* 5. EXTRA SACRED TIMES (Qiyam, Last Third of Night) */}
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#E6E6F0]/70 shadow-2xs space-y-3">
            <div className="flex items-center gap-2 text-[#25263A] font-black text-sm">
              <Moon className="w-4 h-4 text-indigo-700" />
              <span>أوقات قيام الليل المباركة والثلث الأخير</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-indigo-50/70 rounded-2xl border border-indigo-200/60 flex items-center justify-between">
                <div>
                  <span className="font-bold text-indigo-950 block">منتصف الليل الشرعي</span>
                  <span className="text-[#77798C] text-[11px]">انتهاء وقت العشاء المختار</span>
                </div>
                <span className="font-mono font-black text-indigo-900 text-sm">
                  {formatPrayerTime(
                    prayerData.sunnahTimes.middleOfTheNight,
                    prayerSettings.timeFormat
                  )}
                </span>
              </div>

              <div className="p-3 bg-[#EEEEFF]/70 rounded-2xl border border-[#E6E6F0]/60 flex items-center justify-between">
                <div>
                  <span className="font-bold text-amber-950 flex items-center gap-1">
                    <span>الثلث الأخير من الليل</span>
                    <Sparkles className="w-3.5 h-3.5 text-[#4145C7]" />
                  </span>
                  <span className="text-[#77798C] text-[11px]">وقت النزول الإلهي واستجابة الدعاء</span>
                </div>
                <span className="font-mono font-black text-[#4145C7] text-sm">
                  {formatPrayerTime(
                    prayerData.sunnahTimes.lastThirdOfTheNight,
                    prayerSettings.timeFormat
                  )}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-[#77798C] leading-relaxed text-center pt-1 border-t border-[#E6E6F0]">
              «ينزل ربنا تبارك وتعالى كل ليلة إلى السماء الدنيا حين يبقى ثلث الليل الآخر فيقول: من
              يدعوني فأستجيب له، من يسألني فأعطيه، من يستغفرني فأغفر له»
            </p>
          </div>
        </div>
      )}

      {/* Floating Interactive Adhan Media Player Bar */}
      <AdhanMediaPlayerBar />

      {/* ALL MODALS & DRAWERS */}
      <CitySelectorModal
        isOpen={isCityModalOpen}
        onClose={() => setIsCityModalOpen(false)}
        currentCity={currentCity}
        onSelectCity={handleSelectCity}
        onUseGps={handleUseGps}
        isLocatingGps={isLocatingGps}
        gpsError={gpsError}
      />

      <QiblaCompassView
        isOpen={isQiblaModalOpen}
        onClose={() => setIsQiblaModalOpen(false)}
        qiblaBearing={prayerData.qiblaBearing}
        distanceToKaabaKm={prayerData.distanceToKaabaKm}
        currentCity={currentCity}
      />

      <PrayerSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={prayerSettings}
        onUpdateSettings={handleUpdateSettings}
      />

      <PostPrayerAthkarModal
        isOpen={isAthkarModalOpen}
        onClose={() => setIsAthkarModalOpen(false)}
      />

      <PrayerTrackerModal
        isOpen={isTrackerModalOpen}
        onClose={() => setIsTrackerModalOpen(false)}
        currentDateStr={todayStr}
      />

      <IslamicCalendarModal
        isOpen={isCalendarModalOpen}
        onClose={() => setIsCalendarModalOpen(false)}
        hijriDay={prayerData.hijriDate.day}
        hijriMonth={prayerData.hijriDate.month}
        hijriYear={prayerData.hijriDate.year}
        hijriFormatted={prayerData.hijriDate.formatted}
        hijriAdjustment={prayerSettings.hijriAdjustment}
        onUpdateAdjustment={(adj) =>
          handleUpdateSettings({ ...prayerSettings, hijriAdjustment: adj })
        }
      />

      {isFocusModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in"
          dir="rtl"
          onClick={() => setIsFocusModalOpen(false)}
        >
          <div
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setIsFocusModalOpen(false)}
              className="absolute top-4 left-4 z-20 w-8 h-8 rounded-full bg-[#F7F7FC] hover:bg-gray-200 text-[#25263A] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
            <PrayerFocusSettingsCard />
          </div>
        </div>
      )}
    </div>
  );
};
