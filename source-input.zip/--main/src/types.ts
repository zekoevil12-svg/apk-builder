export type ScreenType = 'home' | 'tasbeeh' | 'daily_reminders' | 'prayers' | 'athkar' | 'quran' | 'quran_audio' | 'hadith' | 'arbain_nawawiya' | 'ward' | 'wird' | 'gharib_quran' | 'tajweed' | 'tadabbur' | 'zakat_mawarith' | 'hijri_fasting' | 'hajj_umrah' | 'ruqyah_medicine' | 'companions_stories' | 'prophetic_biography' | 'wasaya' | 'kids_stories' | 'fiqh_muyassar' | 'harvest' | 'journey' | 'stats' | 'settings' | 'credits' | 'profile' | 'widgets' | 'ramadan' | 'muslim_woman' | 'wudu_prayer' | 'asmaa_allah' | 'athar_tayyib' | 'amana' | 'moment_dhikr' | 'hisn_almuslim' | 'our_history' | 'dua_corner' | 'admin';

export type TahfeezPlanType = 'juz' | 'surah' | 'page_daily' | 'custom';

export interface TahfeezPlan {
  id: string;
  title: string;
  type: TahfeezPlanType;
  surahNumber: number;
  surahName: string;
  startAyah: number;
  endAyah: number;
  totalAyahs: number;
  completedAyahs: number;
  dailyAyahsGoal: number;
  durationDays: number;
  reminderTime: string; // e.g. "07:00"
  currentDay: number;
  createdAt: string;
  lastStudiedAt?: string;
  isCompleted: boolean;
}

export interface SpacedRepetitionStep {
  dayOffset: number;
  title: string;
  isDone: boolean;
  dueDate: string;
}

export interface TahfeezReviewItem {
  id: string;
  planId: string;
  surahName: string;
  surahNumber: number;
  ayahRange: string;
  memorizedDate: string;
  stage: number; // 0 to 5 (day 0, 1, 3, 7, 14, 30)
  steps: SpacedRepetitionStep[];
  nextDueDate: string;
  status: 'pending' | 'due_today' | 'completed';
}

export interface TahfeezStats {
  totalMemorizedAyahs: number;
  totalMemorizedJuz: number;
  completedSurahsCount: number;
  streakDays: number;
  totalRepetitions: number;
  quizzesPassed: number;
}

export type AthkarCategory = 'all' | 'quran' | 'sunnah' | 'favorites' | 'morning' | 'evening' | 'sleep' | 'prayer' | 'custom';

export type WardType = 'morning' | 'evening' | 'sleep' | 'prayer';

export interface DhikrItem {
  id: string;
  text: string;
  countTarget: number;
  countDone: number;
  category: AthkarCategory;
  source: string;
  virtue?: string;
  isFavorite?: boolean;
  isCustom?: boolean;
}

export interface DailyRecord {
  date: string; // YYYY-MM-DD
  totalCount: number;
  sessionsCount: number;
  completedAthkarCount: number;
  freeCount: number;
  hourlyCounts: number[]; // 24 hours 0..23
  dhikrCounts: Record<string, number>;
}

export type RosaryThemeId = 'gold' | 'emerald' | 'sapphire' | 'brown' | 'rose' | 'onyx' | 'amber' | 'pearl';

export interface UserSettings {
  soundEnabled: boolean;
  soundVolume: number;
  soundType: 'wood' | 'water' | 'golden_bell' | 'silent' | 'wooden_bead' | 'crystal_click' | 'soft_chime';
  vibrationEnabled: boolean;
  vibrationLevel?: 'light' | 'medium' | 'strong' | 'none';
  themeFont: 'tajawal' | 'amiri';
  defaultTarget: number;
  dailyGoal: number;
  weeklyGoal?: number;
  monthlyGoal?: number;
  hasCompletedOnboarding: boolean;
  morningReminderTime: string;
  eveningReminderTime: string;
  remindersEnabled: boolean;
  pushNotificationsEnabled: boolean;
  // 5-Daily Dhikr Notification Settings
  dhikrNotificationsEnabled?: boolean;
  fajrNotificationTime?: string;
  duhaNotificationTime?: string;
  dhuhrNotificationTime?: string;
  asrNotificationTime?: string;
  nightNotificationTime?: string;
  // Rosary Customization Fields
  rosaryDhikr: string;
  rosaryTarget: number;
  rosarySoundEnabled: boolean;
  rosaryVibrationEnabled: boolean;
  rosaryTheme?: RosaryThemeId;
  rosaryDarkMode?: boolean;
  // App-wide Theme & Appearance Fields
  themeId?: 'default' | 'gold' | 'day' | 'night' | 'nature' | 'islamic' | 'sky' | 'lavender' | 'desert' | 'serenity' | 'girly';
  themeMode?: 'light' | 'dark' | 'system';
  themeUpdatedAt?: string;
}

export interface RankInfo {
  level: number;
  name: string;
  min: number;
  max: number;
  badge: string;
  description: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'reminder' | 'milestone' | 'general';
  actionWard?: WardType;
  actionScreen?: ScreenType;
  actionDhikrId?: string;
  signatureKey?: string;
}

export interface ActiveDhikrPreset {
  id: string;
  title: string;
  text: string;
  target: number;
  reward?: string;
}

export type PrayerKey = 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export type CalculationMethodKey =
  | 'Egyptian'
  | 'UmmAlQura'
  | 'MuslimWorldLeague'
  | 'Karachi'
  | 'NorthAmerica'
  | 'Dubai'
  | 'Qatar'
  | 'Kuwait'
  | 'Turkey'
  | 'Singapore'
  | 'Custom';

export type MadhabKey = 'shafi' | 'hanafi';

export interface CityLocation {
  id: string;
  nameAr: string;
  nameEn: string;
  countryAr: string;
  countryEn: string;
  regionCategory: 'egypt' | 'arab' | 'world';
  governorateAr?: string;
  latitude: number;
  longitude: number;
  timezone?: string;
  defaultMethod?: CalculationMethodKey;
}

export type PrayerTrackingStatus = 'mosque' | 'on_time' | 'late' | 'missed' | 'none';

export interface DailyPrayerTracker {
  date: string; // YYYY-MM-DD
  prayers: Record<PrayerKey, PrayerTrackingStatus>;
}

export type PrayerSoundMode = 'adhan' | 'takbeer' | 'chime' | 'silent' | 'off';

export interface PrayerAlertDetail {
  mode: PrayerSoundMode;
  customMuadhinId?: string;
  preReminder?: boolean;
}

export interface PrayerSettings {
  method: CalculationMethodKey;
  madhab: MadhabKey;
  timeFormat: '12h' | '24h';
  hijriAdjustment: number; // -2, -1, 0, 1, 2
  notifications: Record<PrayerKey, boolean>;
  prayerAlerts?: Record<PrayerKey, PrayerAlertDetail>;
  preAdhanReminderMinutes: number; // 0, 10, 15, 30
  iqamaMinutes: Record<PrayerKey, number>;
  selectedMuadhin: string;
  soundEnabled: boolean;
  manualOffsets: Record<PrayerKey, number>; // in minutes
  showSunnah: boolean;
  silentModeReminder: boolean;
}

export type WidgetSize = 'small' | 'medium' | 'large';
export type WidgetTheme = 'navy' | 'gold' | 'midnight' | 'cream';
export type WidgetType = 'tasbeeh' | 'prayer' | 'dhikr' | 'multi';

export interface WidgetConfig {
  type: WidgetType;
  size: WidgetSize;
  theme: WidgetTheme;
}

export type {
  CompanionCategoryId,
  CompanionCategory,
  CompanionStory,
  CompanionHadith,
  CompanionProfile,
} from './data/companionsTypes';

export interface CompanionCategorySqliteRow {
  id: string;
  name: string;
  icon: string;
  description: string;
  count_label: string;
  order_number: number;
}

export interface CompanionSqliteRow {
  id: string;
  category_id: string;
  category_ids_json: string;
  name: string;
  full_name: string;
  title: string;
  birth_date: string;
  death_date: string;
  birth_place: string;
  bio: string;
  virtues_json: string;
  hadiths_count: string;
  hadiths_json: string;
  death_details: string;
  lessons_json: string;
  sources_json: string;
  gender: 'male' | 'female';
  order_number: number;
  is_favorite: number; // 0 | 1
}

export interface CompanionStorySqliteRow {
  id: string;
  companion_id: string;
  title: string;
  content: string;
  reference: string;
  order_number: number;
}

export interface CompanionFavoriteSqliteRow {
  id: string;
  companion_id: string;
  added_at: string;
}

