import {
  CompanionCategory,
  CompanionCategoryId,
  CompanionProfile,
  COMPANION_CATEGORIES,
} from './companionsTypes';
import { COMPANIONS_PART_1 } from './companionsDataPart1';
import { COMPANIONS_PART_2 } from './companionsDataPart2';
import { COMPANIONS_PART_3 } from './companionsDataPart3';

export type {
  CompanionCategory,
  CompanionCategoryId,
  CompanionProfile,
};

export { COMPANION_CATEGORIES };

export const ALL_COMPANIONS: CompanionProfile[] = [
  ...COMPANIONS_PART_1,
  ...COMPANIONS_PART_2,
  ...COMPANIONS_PART_3,
].sort((a, b) => a.order_number - b.order_number);

export function getCompanionsByCategory(categoryId: CompanionCategoryId | 'all'): CompanionProfile[] {
  if (categoryId === 'all') return ALL_COMPANIONS;
  return ALL_COMPANIONS.filter((c) => c.category_ids.includes(categoryId));
}

export function normalizeArabicText(input: string): string {
  return input
    .replace(/[\u064B-\u065F\u0670]/g, '') // remove tashkeel
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
    .toLowerCase();
}

export function searchCompanions(query: string, categoryId: CompanionCategoryId | 'all' = 'all'): CompanionProfile[] {
  const base = getCompanionsByCategory(categoryId);
  const q = normalizeArabicText(query);
  if (!q) return base;
  return base.filter((c) => {
    const searchable = normalizeArabicText(
      [
        c.name,
        c.full_name,
        c.title,
        c.bio,
        c.birth_place,
        ...c.virtues,
        ...c.stories.map((s) => `${s.title} ${s.content} ${s.reference}`),
        ...c.hadiths.map((h) => `${h.text} ${h.source}`),
        ...c.lessons,
        ...c.sources,
      ].join(' ')
    );
    return searchable.includes(q);
  });
}
