import { CityLocation, PrayerSettings } from '../types';

export const CITIES_DATABASE: CityLocation[] = [
  // ==========================================
  // جمهورية مصر العربية - جميع المحافظات (27 محافظة)
  // ==========================================
  {
    id: 'eg-cairo',
    nameAr: 'القاهرة',
    nameEn: 'Cairo',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة القاهرة',
    latitude: 30.0444,
    longitude: 31.2357,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-giza',
    nameAr: 'الجيزة',
    nameEn: 'Giza',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الجيزة',
    latitude: 30.0131,
    longitude: 31.2089,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-alexandria',
    nameAr: 'الإسكندرية',
    nameEn: 'Alexandria',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الإسكندرية',
    latitude: 31.2001,
    longitude: 29.9187,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-dakahlia',
    nameAr: 'المنصورة (الدقهلية)',
    nameEn: 'Mansoura (Dakahlia)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الدقهلية',
    latitude: 31.0409,
    longitude: 31.3785,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-sharqia',
    nameAr: 'الزقازيق (الشرقية)',
    nameEn: 'Zagazig (Sharqia)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الشرقية',
    latitude: 30.5877,
    longitude: 31.5020,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-qalyubia-banha',
    nameAr: 'بنها (القليوبية)',
    nameEn: 'Banha (Qalyubia)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة القليوبية',
    latitude: 30.4660,
    longitude: 31.1853,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-qalyubia-shobra',
    nameAr: 'شبرا الخيمة (القليوبية)',
    nameEn: 'Shubra El Kheima',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة القليوبية',
    latitude: 30.1286,
    longitude: 31.2422,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-gharbia-tanta',
    nameAr: 'طنطا (الغربية)',
    nameEn: 'Tanta (Gharbia)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الغربية',
    latitude: 30.7865,
    longitude: 31.0004,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-gharbia-mahalla',
    nameAr: 'المحلة الكبرى (الغربية)',
    nameEn: 'El Mahalla El Kubra',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الغربية',
    latitude: 30.9706,
    longitude: 31.1669,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-monufia',
    nameAr: 'شبين الكوم (المنوفية)',
    nameEn: 'Shibin El Kom (Monufia)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة المنوفية',
    latitude: 30.5567,
    longitude: 31.0118,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-damietta',
    nameAr: 'دمياط',
    nameEn: 'Damietta',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة دمياط',
    latitude: 31.4175,
    longitude: 31.8144,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-kafr-el-sheikh',
    nameAr: 'كفر الشيخ',
    nameEn: 'Kafr El Sheikh',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة كفر الشيخ',
    latitude: 31.1107,
    longitude: 30.9388,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-beheira',
    nameAr: 'دمنهور (البحيرة)',
    nameEn: 'Damanhur (Beheira)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة البحيرة',
    latitude: 31.0409,
    longitude: 30.4704,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-ismailia',
    nameAr: 'الإسماعيلية',
    nameEn: 'Ismailia',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الإسماعيلية',
    latitude: 30.5965,
    longitude: 32.2715,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-port-said',
    nameAr: 'بورسعيد',
    nameEn: 'Port Said',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة بورسعيد',
    latitude: 31.2653,
    longitude: 32.3019,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-suez',
    nameAr: 'السويس',
    nameEn: 'Suez',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة السويس',
    latitude: 29.9668,
    longitude: 32.5498,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-north-sinai',
    nameAr: 'العريش (شمال سيناء)',
    nameEn: 'Arish (North Sinai)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة شمال سيناء',
    latitude: 31.1316,
    longitude: 33.7984,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-south-sinai-sharm',
    nameAr: 'شرم الشيخ (جنوب سيناء)',
    nameEn: 'Sharm El Sheikh (South Sinai)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة جنوب سيناء',
    latitude: 27.9158,
    longitude: 34.3299,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-south-sinai-tur',
    nameAr: 'طور سيناء (جنوب سيناء)',
    nameEn: 'El Tor (South Sinai)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة جنوب سيناء',
    latitude: 28.2415,
    longitude: 33.6228,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-fayoum',
    nameAr: 'الفيوم',
    nameEn: 'Fayoum',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الفيوم',
    latitude: 29.3084,
    longitude: 30.8428,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-beni-suef',
    nameAr: 'بني سويف',
    nameEn: 'Beni Suef',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة بني سويف',
    latitude: 29.0661,
    longitude: 31.0994,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-minya',
    nameAr: 'المنيا',
    nameEn: 'Minya',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة المنيا',
    latitude: 28.1099,
    longitude: 30.7503,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-asyut',
    nameAr: 'أسيوط',
    nameEn: 'Asyut',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة أسيوط',
    latitude: 27.1801,
    longitude: 31.1837,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-sohag',
    nameAr: 'سوهاج',
    nameEn: 'Sohag',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة سوهاج',
    latitude: 26.5569,
    longitude: 31.6948,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-qena',
    nameAr: 'قنا',
    nameEn: 'Qena',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة قنا',
    latitude: 26.1551,
    longitude: 32.7160,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-luxor',
    nameAr: 'الأقصر',
    nameEn: 'Luxor',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الأقصر',
    latitude: 25.6872,
    longitude: 32.6396,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-aswan',
    nameAr: 'أسوان',
    nameEn: 'Aswan',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة أسوان',
    latitude: 24.0889,
    longitude: 32.8998,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-red-sea',
    nameAr: 'الغردقة (البحر الأحمر)',
    nameEn: 'Hurghada (Red Sea)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة البحر الأحمر',
    latitude: 27.2579,
    longitude: 33.8116,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-new-valley',
    nameAr: 'الخارجة (الوادي الجديد)',
    nameEn: 'Kharga (New Valley)',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة الوادي الجديد',
    latitude: 25.4514,
    longitude: 30.5475,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-matrouh',
    nameAr: 'مرسى مطروح',
    nameEn: 'Marsa Matruh',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة مطروح',
    latitude: 31.3543,
    longitude: 27.2373,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'eg-siwa',
    nameAr: 'واحة سيوة (مطروح)',
    nameEn: 'Siwa Oasis',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    regionCategory: 'egypt',
    governorateAr: 'محافظة مطروح',
    latitude: 29.2032,
    longitude: 25.5195,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian'
  },

  // ==========================================
  // الدول والمدن العربية والإسلامية
  // ==========================================
  // المملكة العربية السعودية
  {
    id: 'sa-makkah',
    nameAr: 'مكة المكرمة',
    nameEn: 'Makkah Al-Mukarramah',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 21.4225,
    longitude: 39.8262,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-madinah',
    nameAr: 'المدينة المنورة',
    nameEn: 'Madinah Al-Munawwarah',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 24.5247,
    longitude: 39.5692,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-riyadh',
    nameAr: 'الرياض',
    nameEn: 'Riyadh',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 24.7136,
    longitude: 46.6753,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-jeddah',
    nameAr: 'جدة',
    nameEn: 'Jeddah',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 21.5433,
    longitude: 39.1728,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-dammam',
    nameAr: 'الدمام والخبر',
    nameEn: 'Dammam & Khobar',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 26.4207,
    longitude: 50.0888,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-taif',
    nameAr: 'الطائف',
    nameEn: 'Taif',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 21.2854,
    longitude: 40.4222,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-tabuk',
    nameAr: 'تبوك',
    nameEn: 'Tabuk',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 28.3835,
    longitude: 36.5662,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'sa-abha',
    nameAr: 'أبها وعسير',
    nameEn: 'Abha',
    countryAr: 'المملكة العربية السعودية',
    countryEn: 'Saudi Arabia',
    regionCategory: 'arab',
    latitude: 18.2164,
    longitude: 42.5053,
    timezone: 'Asia/Riyadh',
    defaultMethod: 'UmmAlQura'
  },

  // الإمارات العربية المتحدة
  {
    id: 'ae-dubai',
    nameAr: 'دبي',
    nameEn: 'Dubai',
    countryAr: 'الإمارات العربية المتحدة',
    countryEn: 'United Arab Emirates',
    regionCategory: 'arab',
    latitude: 25.2048,
    longitude: 55.2708,
    timezone: 'Asia/Dubai',
    defaultMethod: 'Dubai'
  },
  {
    id: 'ae-abu-dhabi',
    nameAr: 'أبوظبي',
    nameEn: 'Abu Dhabi',
    countryAr: 'الإمارات العربية المتحدة',
    countryEn: 'United Arab Emirates',
    regionCategory: 'arab',
    latitude: 24.4539,
    longitude: 54.3773,
    timezone: 'Asia/Dubai',
    defaultMethod: 'Dubai'
  },
  {
    id: 'ae-sharjah',
    nameAr: 'الشارقة',
    nameEn: 'Sharjah',
    countryAr: 'الإمارات العربية المتحدة',
    countryEn: 'United Arab Emirates',
    regionCategory: 'arab',
    latitude: 25.3463,
    longitude: 55.4209,
    timezone: 'Asia/Dubai',
    defaultMethod: 'Dubai'
  },
  {
    id: 'ae-al-ain',
    nameAr: 'العين',
    nameEn: 'Al Ain',
    countryAr: 'الإمارات العربية المتحدة',
    countryEn: 'United Arab Emirates',
    regionCategory: 'arab',
    latitude: 24.2075,
    longitude: 55.7447,
    timezone: 'Asia/Dubai',
    defaultMethod: 'Dubai'
  },

  // الكويت
  {
    id: 'kw-kuwait-city',
    nameAr: 'مدينة الكويت',
    nameEn: 'Kuwait City',
    countryAr: 'دولة الكويت',
    countryEn: 'Kuwait',
    regionCategory: 'arab',
    latitude: 29.3759,
    longitude: 47.9774,
    timezone: 'Asia/Kuwait',
    defaultMethod: 'Kuwait'
  },
  {
    id: 'kw-hawalli',
    nameAr: 'حولي والأحمدي',
    nameEn: 'Hawalli & Ahmadi',
    countryAr: 'دولة الكويت',
    countryEn: 'Kuwait',
    regionCategory: 'arab',
    latitude: 29.3330,
    longitude: 48.0160,
    timezone: 'Asia/Kuwait',
    defaultMethod: 'Kuwait'
  },

  // قطر
  {
    id: 'qa-doha',
    nameAr: 'الدوحة',
    nameEn: 'Doha',
    countryAr: 'دولة قطر',
    countryEn: 'Qatar',
    regionCategory: 'arab',
    latitude: 25.2854,
    longitude: 51.5310,
    timezone: 'Asia/Qatar',
    defaultMethod: 'Qatar'
  },
  {
    id: 'qa-al-rayyan',
    nameAr: 'الريان والوكرة',
    nameEn: 'Al Rayyan & Al Wakrah',
    countryAr: 'دولة قطر',
    countryEn: 'Qatar',
    regionCategory: 'arab',
    latitude: 25.2919,
    longitude: 51.4244,
    timezone: 'Asia/Qatar',
    defaultMethod: 'Qatar'
  },

  // البحرين
  {
    id: 'bh-manama',
    nameAr: 'المنامة',
    nameEn: 'Manama',
    countryAr: 'مملكة البحرين',
    countryEn: 'Bahrain',
    regionCategory: 'arab',
    latitude: 26.2285,
    longitude: 50.5860,
    timezone: 'Asia/Bahrain',
    defaultMethod: 'UmmAlQura'
  },

  // سلطنة عمان
  {
    id: 'om-muscat',
    nameAr: 'مسقط',
    nameEn: 'Muscat',
    countryAr: 'سلطنة عُمان',
    countryEn: 'Oman',
    regionCategory: 'arab',
    latitude: 23.5880,
    longitude: 58.3829,
    timezone: 'Asia/Muscat',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'om-salalah',
    nameAr: 'صلالة',
    nameEn: 'Salalah',
    countryAr: 'سلطنة عُمان',
    countryEn: 'Oman',
    regionCategory: 'arab',
    latitude: 17.0151,
    longitude: 54.0924,
    timezone: 'Asia/Muscat',
    defaultMethod: 'UmmAlQura'
  },

  // فلسطين
  {
    id: 'ps-jerusalem',
    nameAr: 'القدس الشريف',
    nameEn: 'Jerusalem (Al-Quds)',
    countryAr: 'دولة فلسطين',
    countryEn: 'Palestine',
    regionCategory: 'arab',
    latitude: 31.7683,
    longitude: 35.2137,
    timezone: 'Asia/Gaza',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'ps-gaza',
    nameAr: 'غزة',
    nameEn: 'Gaza',
    countryAr: 'دولة فلسطين',
    countryEn: 'Palestine',
    regionCategory: 'arab',
    latitude: 31.5017,
    longitude: 34.4668,
    timezone: 'Asia/Gaza',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'ps-ramallah',
    nameAr: 'رام الله والبيرة',
    nameEn: 'Ramallah',
    countryAr: 'دولة فلسطين',
    countryEn: 'Palestine',
    regionCategory: 'arab',
    latitude: 31.9038,
    longitude: 35.2034,
    timezone: 'Asia/Hebron',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'ps-hebron',
    nameAr: 'الخليل',
    nameEn: 'Hebron (Al-Khalil)',
    countryAr: 'دولة فلسطين',
    countryEn: 'Palestine',
    regionCategory: 'arab',
    latitude: 31.5326,
    longitude: 35.0998,
    timezone: 'Asia/Hebron',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'ps-nablus',
    nameAr: 'نابلس وجنين',
    nameEn: 'Nablus & Jenin',
    countryAr: 'دولة فلسطين',
    countryEn: 'Palestine',
    regionCategory: 'arab',
    latitude: 32.2227,
    longitude: 35.2621,
    timezone: 'Asia/Hebron',
    defaultMethod: 'Egyptian'
  },

  // الأردن
  {
    id: 'jo-amman',
    nameAr: 'عمّان',
    nameEn: 'Amman',
    countryAr: 'المملكة الأردنية الهاشمية',
    countryEn: 'Jordan',
    regionCategory: 'arab',
    latitude: 31.9454,
    longitude: 35.9284,
    timezone: 'Asia/Amman',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'jo-irbid',
    nameAr: 'إربد والزرقاء',
    nameEn: 'Irbid & Zarqa',
    countryAr: 'المملكة الأردنية الهاشمية',
    countryEn: 'Jordan',
    regionCategory: 'arab',
    latitude: 32.5568,
    longitude: 35.8469,
    timezone: 'Asia/Amman',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'jo-aqaba',
    nameAr: 'العقبة',
    nameEn: 'Aqaba',
    countryAr: 'المملكة الأردنية الهاشمية',
    countryEn: 'Jordan',
    regionCategory: 'arab',
    latitude: 29.5321,
    longitude: 35.0063,
    timezone: 'Asia/Amman',
    defaultMethod: 'Egyptian'
  },

  // سوريا
  {
    id: 'sy-damascus',
    nameAr: 'دمشق',
    nameEn: 'Damascus',
    countryAr: 'الجمهورية العربية السورية',
    countryEn: 'Syria',
    regionCategory: 'arab',
    latitude: 33.5138,
    longitude: 36.2765,
    timezone: 'Asia/Damascus',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'sy-aleppo',
    nameAr: 'حلب',
    nameEn: 'Aleppo',
    countryAr: 'الجمهورية العربية السورية',
    countryEn: 'Syria',
    regionCategory: 'arab',
    latitude: 36.2021,
    longitude: 37.1343,
    timezone: 'Asia/Damascus',
    defaultMethod: 'MuslimWorldLeague'
  },

  // العراق
  {
    id: 'iq-baghdad',
    nameAr: 'بغداد',
    nameEn: 'Baghdad',
    countryAr: 'جمهورية العراق',
    countryEn: 'Iraq',
    regionCategory: 'arab',
    latitude: 33.3152,
    longitude: 44.3661,
    timezone: 'Asia/Baghdad',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'iq-mosul',
    nameAr: 'الموصل وأربيل',
    nameEn: 'Mosul & Erbil',
    countryAr: 'جمهورية العراق',
    countryEn: 'Iraq',
    regionCategory: 'arab',
    latitude: 36.3400,
    longitude: 43.1300,
    timezone: 'Asia/Baghdad',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'iq-basra',
    nameAr: 'البصرة',
    nameEn: 'Basra',
    countryAr: 'جمهورية العراق',
    countryEn: 'Iraq',
    regionCategory: 'arab',
    latitude: 30.5081,
    longitude: 47.7835,
    timezone: 'Asia/Baghdad',
    defaultMethod: 'MuslimWorldLeague'
  },

  // لبنان
  {
    id: 'lb-beirut',
    nameAr: 'بيروت',
    nameEn: 'Beirut',
    countryAr: 'الجمهورية اللبنانية',
    countryEn: 'Lebanon',
    regionCategory: 'arab',
    latitude: 33.8938,
    longitude: 35.5018,
    timezone: 'Asia/Beirut',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'lb-tripoli',
    nameAr: 'طرابلس الشام وصيدا',
    nameEn: 'Tripoli & Sidon',
    countryAr: 'الجمهورية اللبنانية',
    countryEn: 'Lebanon',
    regionCategory: 'arab',
    latitude: 34.4367,
    longitude: 35.8497,
    timezone: 'Asia/Beirut',
    defaultMethod: 'MuslimWorldLeague'
  },

  // المغرب
  {
    id: 'ma-rabat',
    nameAr: 'الرباط',
    nameEn: 'Rabat',
    countryAr: 'المملكة المغربية',
    countryEn: 'Morocco',
    regionCategory: 'arab',
    latitude: 34.0209,
    longitude: -6.8416,
    timezone: 'Africa/Casablanca',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'ma-casablanca',
    nameAr: 'الدار البيضاء',
    nameEn: 'Casablanca',
    countryAr: 'المملكة المغربية',
    countryEn: 'Morocco',
    regionCategory: 'arab',
    latitude: 33.5731,
    longitude: -7.5898,
    timezone: 'Africa/Casablanca',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'ma-marrakech',
    nameAr: 'مراكش وفاس',
    nameEn: 'Marrakech & Fes',
    countryAr: 'المملكة المغربية',
    countryEn: 'Morocco',
    regionCategory: 'arab',
    latitude: 31.6295,
    longitude: -7.9811,
    timezone: 'Africa/Casablanca',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'ma-tangier',
    nameAr: 'طنجة وتطوان',
    nameEn: 'Tangier & Tetouan',
    countryAr: 'المملكة المغربية',
    countryEn: 'Morocco',
    regionCategory: 'arab',
    latitude: 35.7595,
    longitude: -5.8340,
    timezone: 'Africa/Casablanca',
    defaultMethod: 'MuslimWorldLeague'
  },

  // الجزائر
  {
    id: 'dz-algiers',
    nameAr: 'الجزائر العاصمة',
    nameEn: 'Algiers',
    countryAr: 'الجمهورية الجزائرية',
    countryEn: 'Algeria',
    regionCategory: 'arab',
    latitude: 36.7538,
    longitude: 3.0588,
    timezone: 'Africa/Algiers',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'dz-oran',
    nameAr: 'وهران',
    nameEn: 'Oran',
    countryAr: 'الجمهورية الجزائرية',
    countryEn: 'Algeria',
    regionCategory: 'arab',
    latitude: 35.6976,
    longitude: -0.6337,
    timezone: 'Africa/Algiers',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'dz-constantine',
    nameAr: 'قسنطينة وعنابة',
    nameEn: 'Constantine & Annaba',
    countryAr: 'الجمهورية الجزائرية',
    countryEn: 'Algeria',
    regionCategory: 'arab',
    latitude: 36.3650,
    longitude: 6.6147,
    timezone: 'Africa/Algiers',
    defaultMethod: 'MuslimWorldLeague'
  },

  // تونس
  {
    id: 'tn-tunis',
    nameAr: 'تونس العاصمة',
    nameEn: 'Tunis',
    countryAr: 'الجمهورية التونسية',
    countryEn: 'Tunisia',
    regionCategory: 'arab',
    latitude: 36.8065,
    longitude: 10.1815,
    timezone: 'Africa/Tunis',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'tn-sfax',
    nameAr: 'صفاقس وسوسة',
    nameEn: 'Sfax & Sousse',
    countryAr: 'الجمهورية التونسية',
    countryEn: 'Tunisia',
    regionCategory: 'arab',
    latitude: 34.7406,
    longitude: 10.7603,
    timezone: 'Africa/Tunis',
    defaultMethod: 'MuslimWorldLeague'
  },

  // ليبيا
  {
    id: 'ly-tripoli',
    nameAr: 'طرابلس الغرب',
    nameEn: 'Tripoli',
    countryAr: 'دولة ليبيا',
    countryEn: 'Libya',
    regionCategory: 'arab',
    latitude: 32.8872,
    longitude: 13.1913,
    timezone: 'Africa/Tripoli',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'ly-benghazi',
    nameAr: 'بنغازي ومصراتة',
    nameEn: 'Benghazi & Misrata',
    countryAr: 'دولة ليبيا',
    countryEn: 'Libya',
    regionCategory: 'arab',
    latitude: 32.1166,
    longitude: 20.0686,
    timezone: 'Africa/Tripoli',
    defaultMethod: 'MuslimWorldLeague'
  },

  // السودان
  {
    id: 'sd-khartoum',
    nameAr: 'الخرطوم وأم درمان',
    nameEn: 'Khartoum & Omdurman',
    countryAr: 'جمهورية السودان',
    countryEn: 'Sudan',
    regionCategory: 'arab',
    latitude: 15.5007,
    longitude: 32.5599,
    timezone: 'Africa/Khartoum',
    defaultMethod: 'Egyptian'
  },
  {
    id: 'sd-port-sudan',
    nameAr: 'بورتسودان',
    nameEn: 'Port Sudan',
    countryAr: 'جمهورية السودان',
    countryEn: 'Sudan',
    regionCategory: 'arab',
    latitude: 19.6175,
    longitude: 37.2164,
    timezone: 'Africa/Khartoum',
    defaultMethod: 'Egyptian'
  },

  // اليمن
  {
    id: 'ye-sanaa',
    nameAr: 'صنعاء',
    nameEn: 'Sanaa',
    countryAr: 'الجمهورية اليمنية',
    countryEn: 'Yemen',
    regionCategory: 'arab',
    latitude: 15.3694,
    longitude: 44.1910,
    timezone: 'Asia/Aden',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'ye-aden',
    nameAr: 'عدن والمكلا',
    nameEn: 'Aden & Mukalla',
    countryAr: 'الجمهورية اليمنية',
    countryEn: 'Yemen',
    regionCategory: 'arab',
    latitude: 12.7855,
    longitude: 45.0187,
    timezone: 'Asia/Aden',
    defaultMethod: 'UmmAlQura'
  },
  {
    id: 'ye-taiz',
    nameAr: 'تعز والحديدة',
    nameEn: 'Taiz & Hodeidah',
    countryAr: 'الجمهورية اليمنية',
    countryEn: 'Yemen',
    regionCategory: 'arab',
    latitude: 13.5776,
    longitude: 44.0199,
    timezone: 'Asia/Aden',
    defaultMethod: 'UmmAlQura'
  },

  // موريتانيا
  {
    id: 'mr-nouakchott',
    nameAr: 'نواكشوط',
    nameEn: 'Nouakchott',
    countryAr: 'الجمهورية الإسلامية الموريتانية',
    countryEn: 'Mauritania',
    regionCategory: 'arab',
    latitude: 18.0735,
    longitude: -15.9582,
    timezone: 'Africa/Nouakchott',
    defaultMethod: 'MuslimWorldLeague'
  },

  // الصومال
  {
    id: 'so-mogadishu',
    nameAr: 'مقديشو',
    nameEn: 'Mogadishu',
    countryAr: 'جمهورية الصومال الفيدرالية',
    countryEn: 'Somalia',
    regionCategory: 'arab',
    latitude: 2.0469,
    longitude: 45.3182,
    timezone: 'Africa/Mogadishu',
    defaultMethod: 'MuslimWorldLeague'
  },

  // جيبوتي
  {
    id: 'dj-djibouti',
    nameAr: 'جيبوتي العاصمة',
    nameEn: 'Djibouti City',
    countryAr: 'جمهورية جيبوتي',
    countryEn: 'Djibouti',
    regionCategory: 'arab',
    latitude: 11.8251,
    longitude: 42.5903,
    timezone: 'Africa/Djibouti',
    defaultMethod: 'MuslimWorldLeague'
  },

  // جزر القمر
  {
    id: 'km-moroni',
    nameAr: 'موروني',
    nameEn: 'Moroni',
    countryAr: 'جمهورية جزر القمر',
    countryEn: 'Comoros',
    regionCategory: 'arab',
    latitude: -11.7172,
    longitude: 43.2473,
    timezone: 'Indian/Comoro',
    defaultMethod: 'MuslimWorldLeague'
  },

  // ==========================================
  // عواصم ومدن العالم الإسلامي والعالمي
  // ==========================================
  // تركيا
  {
    id: 'tr-istanbul',
    nameAr: 'إسطنبول',
    nameEn: 'Istanbul',
    countryAr: 'تركيا',
    countryEn: 'Turkey',
    regionCategory: 'world',
    latitude: 41.0082,
    longitude: 28.9784,
    timezone: 'Europe/Istanbul',
    defaultMethod: 'Turkey'
  },
  {
    id: 'tr-ankara',
    nameAr: 'أنقرة',
    nameEn: 'Ankara',
    countryAr: 'تركيا',
    countryEn: 'Turkey',
    regionCategory: 'world',
    latitude: 39.9334,
    longitude: 32.8597,
    timezone: 'Europe/Istanbul',
    defaultMethod: 'Turkey'
  },

  // بريطانيا
  {
    id: 'gb-london',
    nameAr: 'لندن',
    nameEn: 'London',
    countryAr: 'المملكة المتحدة',
    countryEn: 'United Kingdom',
    regionCategory: 'world',
    latitude: 51.5074,
    longitude: -0.1278,
    timezone: 'Europe/London',
    defaultMethod: 'MuslimWorldLeague'
  },
  {
    id: 'gb-birmingham',
    nameAr: 'برمنغهام ومانشستر',
    nameEn: 'Birmingham & Manchester',
    countryAr: 'المملكة المتحدة',
    countryEn: 'United Kingdom',
    regionCategory: 'world',
    latitude: 52.4862,
    longitude: -1.8904,
    timezone: 'Europe/London',
    defaultMethod: 'MuslimWorldLeague'
  },

  // فرنسا
  {
    id: 'fr-paris',
    nameAr: 'باريس',
    nameEn: 'Paris',
    countryAr: 'فرنسا',
    countryEn: 'France',
    regionCategory: 'world',
    latitude: 48.8566,
    longitude: 2.3522,
    timezone: 'Europe/Paris',
    defaultMethod: 'MuslimWorldLeague'
  },

  // ألمانيا
  {
    id: 'de-berlin',
    nameAr: 'برلين وفرانكفورت',
    nameEn: 'Berlin & Frankfurt',
    countryAr: 'ألمانيا',
    countryEn: 'Germany',
    regionCategory: 'world',
    latitude: 52.5200,
    longitude: 13.4050,
    timezone: 'Europe/Berlin',
    defaultMethod: 'MuslimWorldLeague'
  },

  // الولايات المتحدة
  {
    id: 'us-new-york',
    nameAr: 'نيويورك',
    nameEn: 'New York',
    countryAr: 'الولايات المتحدة الأمريكية',
    countryEn: 'United States',
    regionCategory: 'world',
    latitude: 40.7128,
    longitude: -74.0060,
    timezone: 'America/New_York',
    defaultMethod: 'NorthAmerica'
  },
  {
    id: 'us-chicago',
    nameAr: 'شيكاغو',
    nameEn: 'Chicago',
    countryAr: 'الولايات المتحدة الأمريكية',
    countryEn: 'United States',
    regionCategory: 'world',
    latitude: 41.8781,
    longitude: -87.6298,
    timezone: 'America/Chicago',
    defaultMethod: 'NorthAmerica'
  },
  {
    id: 'us-los-angeles',
    nameAr: 'لوس أنجلوس',
    nameEn: 'Los Angeles',
    countryAr: 'الولايات المتحدة الأمريكية',
    countryEn: 'United States',
    regionCategory: 'world',
    latitude: 34.0522,
    longitude: -118.2437,
    timezone: 'America/Los_Angeles',
    defaultMethod: 'NorthAmerica'
  },
  {
    id: 'us-houston',
    nameAr: 'هيوستن ودالاس',
    nameEn: 'Houston & Dallas',
    countryAr: 'الولايات المتحدة الأمريكية',
    countryEn: 'United States',
    regionCategory: 'world',
    latitude: 29.7604,
    longitude: -95.3698,
    timezone: 'America/Chicago',
    defaultMethod: 'NorthAmerica'
  },

  // كندا
  {
    id: 'ca-toronto',
    nameAr: 'تورونتو ومونتريال',
    nameEn: 'Toronto & Montreal',
    countryAr: 'كندا',
    countryEn: 'Canada',
    regionCategory: 'world',
    latitude: 43.6532,
    longitude: -79.3832,
    timezone: 'America/Toronto',
    defaultMethod: 'NorthAmerica'
  },

  // ماليزيا
  {
    id: 'my-kuala-lumpur',
    nameAr: 'كوالالمبور',
    nameEn: 'Kuala Lumpur',
    countryAr: 'ماليزيا',
    countryEn: 'Malaysia',
    regionCategory: 'world',
    latitude: 3.1390,
    longitude: 101.6869,
    timezone: 'Asia/Kuala_Lumpur',
    defaultMethod: 'MuslimWorldLeague'
  },

  // إندونيسيا
  {
    id: 'id-jakarta',
    nameAr: 'جاكرتا',
    nameEn: 'Jakarta',
    countryAr: 'إندونيسيا',
    countryEn: 'Indonesia',
    regionCategory: 'world',
    latitude: -6.2088,
    longitude: 106.8456,
    timezone: 'Asia/Jakarta',
    defaultMethod: 'MuslimWorldLeague'
  },

  // باكستان
  {
    id: 'pk-karachi',
    nameAr: 'كراتشي',
    nameEn: 'Karachi',
    countryAr: 'باكستان',
    countryEn: 'Pakistan',
    regionCategory: 'world',
    latitude: 24.8607,
    longitude: 67.0011,
    timezone: 'Asia/Karachi',
    defaultMethod: 'Karachi'
  },
  {
    id: 'pk-islamabad',
    nameAr: 'إسلام أباد ولاهور',
    nameEn: 'Islamabad & Lahore',
    countryAr: 'باكستان',
    countryEn: 'Pakistan',
    regionCategory: 'world',
    latitude: 33.6844,
    longitude: 73.0479,
    timezone: 'Asia/Karachi',
    defaultMethod: 'Karachi'
  },

  // الهند
  {
    id: 'in-delhi',
    nameAr: 'نيودلهي ومومباي',
    nameEn: 'New Delhi & Mumbai',
    countryAr: 'الهند',
    countryEn: 'India',
    regionCategory: 'world',
    latitude: 28.6139,
    longitude: 77.2090,
    timezone: 'Asia/Kolkata',
    defaultMethod: 'Karachi'
  },

  // روسيا
  {
    id: 'ru-moscow',
    nameAr: 'موسكو وقازان',
    nameEn: 'Moscow & Kazan',
    countryAr: 'روسيا',
    countryEn: 'Russia',
    regionCategory: 'world',
    latitude: 55.7558,
    longitude: 37.6173,
    timezone: 'Europe/Moscow',
    defaultMethod: 'MuslimWorldLeague'
  },

  // إسبانيا
  {
    id: 'es-madrid',
    nameAr: 'مدريد وقرطبة وغرناطة',
    nameEn: 'Madrid & Cordoba',
    countryAr: 'إسبانيا',
    countryEn: 'Spain',
    regionCategory: 'world',
    latitude: 40.4168,
    longitude: -3.7038,
    timezone: 'Europe/Madrid',
    defaultMethod: 'MuslimWorldLeague'
  },

  // البوسنة والهرسك
  {
    id: 'ba-sarajevo',
    nameAr: 'سراييفو',
    nameEn: 'Sarajevo',
    countryAr: 'البوسنة والهرسك',
    countryEn: 'Bosnia & Herzegovina',
    regionCategory: 'world',
    latitude: 43.8563,
    longitude: 18.4131,
    timezone: 'Europe/Sarajevo',
    defaultMethod: 'MuslimWorldLeague'
  },

  // أوزبكستان
  {
    id: 'uz-tashkent',
    nameAr: 'طشقند وسمرقند وبخارى',
    nameEn: 'Tashkent & Samarkand',
    countryAr: 'أوزبكستان',
    countryEn: 'Uzbekistan',
    regionCategory: 'world',
    latitude: 41.2995,
    longitude: 69.2401,
    timezone: 'Asia/Tashkent',
    defaultMethod: 'Karachi'
  },

  // أستراليا
  {
    id: 'au-sydney',
    nameAr: 'سيدني وملبورن',
    nameEn: 'Sydney & Melbourne',
    countryAr: 'أستراليا',
    countryEn: 'Australia',
    regionCategory: 'world',
    latitude: -33.8688,
    longitude: 151.2093,
    timezone: 'Australia/Sydney',
    defaultMethod: 'MuslimWorldLeague'
  },

  // اليابان
  {
    id: 'jp-tokyo',
    nameAr: 'طوكيو',
    nameEn: 'Tokyo',
    countryAr: 'اليابان',
    countryEn: 'Japan',
    regionCategory: 'world',
    latitude: 35.6762,
    longitude: 139.6503,
    timezone: 'Asia/Tokyo',
    defaultMethod: 'MuslimWorldLeague'
  }
];

export const DEFAULT_CITY: CityLocation = CITIES_DATABASE[0]; // القاهرة

export const DEFAULT_PRAYER_SETTINGS: PrayerSettings = {
  method: 'Egyptian' as const,
  madhab: 'shafi' as const,
  timeFormat: '12h' as const,
  hijriAdjustment: 0,
  notifications: {
    fajr: true,
    sunrise: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true
  },
  prayerAlerts: {
    fajr: { mode: 'adhan', customMuadhinId: 'egypt-refaat', preReminder: true },
    sunrise: { mode: 'chime', preReminder: false },
    dhuhr: { mode: 'adhan', customMuadhinId: 'makkah', preReminder: true },
    asr: { mode: 'adhan', customMuadhinId: 'madinah', preReminder: true },
    maghrib: { mode: 'adhan', customMuadhinId: 'abdulbaset', preReminder: true },
    isha: { mode: 'adhan', customMuadhinId: 'al-qatami', preReminder: true }
  },
  preAdhanReminderMinutes: 15,
  iqamaMinutes: {
    fajr: 20,
    sunrise: 0,
    dhuhr: 15,
    asr: 15,
    maghrib: 10,
    isha: 15
  },
  selectedMuadhin: 'egypt-refaat',
  soundEnabled: true,
  manualOffsets: {
    fajr: 0,
    sunrise: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0
  },
  showSunnah: true,
  silentModeReminder: true
};
