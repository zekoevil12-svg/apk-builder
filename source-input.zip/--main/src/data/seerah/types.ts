export type SeerahPeriodId =
  | 'pre_mission'
  | 'birth_upbringing'
  | 'revelation_mission'
  | 'makkah_dawah'
  | 'hijrah_ethiopia_taif_israa'
  | 'aqabah_hijrah_madinah'
  | 'madinah_foundation'
  | 'battles_expeditions'
  | 'fath_makkah_hunayn_tabuk'
  | 'delegations_farewell_hajj'
  | 'illness_passing';

export interface SeerahPeriodMeta {
  id: SeerahPeriodId;
  order: number;
  title: string;
  subtitle: string;
  dateRange: string;
  description: string;
  iconName: string;
  accentColor: string;
}

export interface SeerahVerse {
  id: string;
  surahName: string;
  surahNumber: number;
  ayahNumbers: string;
  text: string;
  contextNote?: string;
}

export interface SeerahHadith {
  id: string;
  text: string;
  source: string;
  reference?: string;
  grade: string;
  narrator?: string;
}

export interface SeerahSourceRef {
  id: string;
  bookTitle: string;
  author: string;
  volumeOrSection?: string;
  note?: string;
}

export interface SeerahSubsection {
  id: string;
  title: string;
  paragraphs: string[];
  scholarlyNote?: string;
}

export interface SeerahSection {
  id: string;
  order: number;
  title: string;
  subtitle?: string;
  paragraphs: string[];
  subsections?: SeerahSubsection[];
  scholarlyNotes?: string[];
}

export interface SeerahChapter {
  id: string;
  slug: string;
  order: number;
  period: SeerahPeriodId;
  periodTitle: string;
  hijriYear: string;
  gregorianYear: string;
  locationName: string;
  title: string;
  subtitle: string;
  summary: string;
  readingTimeMinutes: number;
  sections: SeerahSection[];
  verses: SeerahVerse[];
  hadiths: SeerahHadith[];
  lessons: string[];
  figureIds: string[];
  placeIds: string[];
  sources: SeerahSourceRef[];
  status: 'published' | 'draft';
  createdAt: string;
  updatedAt: string;
}

export interface SeerahFigure {
  id: string;
  name: string;
  fullName: string;
  titleOrKunya: string;
  category: 'household' | 'rightly_guided' | 'muhajirun' | 'ansar' | 'other_historical';
  categoryLabel: string;
  honorific: string;
  summary: string;
  biographyParagraphs: string[];
  keyRolesInSeerah: string[];
  authenticVirtueOrHadith?: {
    text: string;
    source: string;
  };
  relatedChapterIds: string[];
  sources: string[];
}

export interface SeerahPlace {
  id: string;
  name: string;
  modernLocation: string;
  region: 'makkah' | 'madinah' | 'hijaz_north' | 'sham_ethiopia';
  regionLabel: string;
  summary: string;
  historicalSignificance: string[];
  distanceNote?: string;
  relatedChapterIds: string[];
  sources: string[];
}

export type SeerahFavoriteType = 'chapter' | 'section' | 'figure' | 'place';

export interface SeerahFavoriteItem {
  id: string; // `${type}_${targetId}`
  userId: string;
  type: SeerahFavoriteType;
  targetId: string;
  chapterId?: string;
  title: string;
  subtitle: string;
  periodTitle?: string;
  createdAt: string;
}

export interface SeerahReadingProgress {
  userId: string;
  lastChapterId: string;
  lastChapterTitle: string;
  lastSectionId?: string;
  lastSectionTitle?: string;
  scrollPercent: number;
  completedChapterIds: string[];
  updatedAt: string;
}

export interface SeerahSearchResult {
  id: string;
  type: 'chapter' | 'section' | 'subsection' | 'verse' | 'hadith' | 'figure' | 'place';
  typeLabel: string;
  title: string;
  subtitle: string;
  snippet: string;
  chapterId?: string;
  sectionId?: string;
  figureId?: string;
  placeId?: string;
}
