import { SEERAH_CHAPTERS_PART1 } from './chaptersPart1_Makkah';
import { SEERAH_CHAPTERS_PART2 } from './chaptersPart2_MadinahBattles';
import { SEERAH_CHAPTERS_PART3 } from './chaptersPart3_FathToPassing';
import { SeerahChapter } from './types';

export * from './types';
export * from './periodsAndMeta';

export const SEERAH_ALL_CHAPTERS: SeerahChapter[] = [
  ...SEERAH_CHAPTERS_PART1,
  ...SEERAH_CHAPTERS_PART2,
  ...SEERAH_CHAPTERS_PART3,
].sort((a, b) => a.order - b.order);
