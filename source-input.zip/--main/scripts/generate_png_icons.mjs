import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

/**
 * Unified RIFQ Section Icon Pack Generator (SVG + 128x128 4x-Supersampled RGBA PNG)
 * Palette:
 * - Medallion Background: #FFFEFA -> #F7F6FD -> #EFEFF9
 * - Medallion Golden Border: #DEB253 / #E6BC63
 * - Primary Purple/Indigo: #7C80FF -> #5B5FEF -> #4145C7
 * - Secondary Gold Accent: #FFE17D -> #F4C047 -> #DC9B2B
 * - Calm Secondary Accents: Emerald (#68D391 -> #2F855A), Sky Blue (#8CC5FF -> #4A7BE8), Rose (#F687B3)
 */

const OUT_W = 128;
const OUT_H = 128;
const SS = 4;
const W = OUT_W * SS;
const H = OUT_H * SS;

function clamp(v, min = 0, max = 1) {
  return v < min ? min : v > max ? max : v;
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function smoothstep(edge0, edge1, x) {
  const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function parseHex(hex, alpha = 1) {
  const h = hex.replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
    alpha,
  ];
}

function mixColor(c1, c2, t) {
  const u = clamp(t, 0, 1);
  return [
    lerp(c1[0], c2[0], u),
    lerp(c1[1], c2[1], u),
    lerp(c1[2], c2[2], u),
    lerp(c1[3], c2[3], u),
  ];
}

class Canvas512 {
  constructor() {
    this.buf = new Float32Array(W * H * 4);
  }

  blendPixel(x, y, r, g, b, a) {
    if (x < 0 || x >= W || y < 0 || y >= H || a <= 0.001) return;
    const idx = (y * W + x) * 4;
    const sa = clamp(a, 0, 1);
    const inv = 1 - sa;
    this.buf[idx] = r * sa + this.buf[idx] * inv;
    this.buf[idx + 1] = g * sa + this.buf[idx + 1] * inv;
    this.buf[idx + 2] = b * sa + this.buf[idx + 2] * inv;
    this.buf[idx + 3] = sa + this.buf[idx + 3] * inv;
  }

  drawSDF(sdfFn, opts = {}) {
    const {
      fill = null,
      stroke = null,
      shadow = null,
      bbox = [0, 0, 128, 128],
    } = opts;

    const pad =
      (shadow ? shadow.blur + Math.max(Math.abs(shadow.dx), Math.abs(shadow.dy)) : 0) +
      (stroke ? stroke.width : 0) +
      6;
    const minX = Math.max(0, Math.floor((bbox[0] - pad) * SS));
    const minY = Math.max(0, Math.floor((bbox[1] - pad) * SS));
    const maxX = Math.min(W - 1, Math.ceil((bbox[2] + pad) * SS));
    const maxY = Math.min(H - 1, Math.ceil((bbox[3] + pad) * SS));

    const bw = Math.max(1, bbox[2] - bbox[0]);
    const bh = Math.max(1, bbox[3] - bbox[1]);

    if (shadow) {
      const sBlur = Math.max(0.5, shadow.blur);
      const [sr, sg, sb, sa] = shadow.color;
      for (let py = minY; py <= maxY; py++) {
        const uy = py / SS - shadow.dy;
        for (let px = minX; px <= maxX; px++) {
          const ux = px / SS - shadow.dx;
          const d = sdfFn(ux, uy);
          if (d < sBlur) {
            const alpha = sa * (1 - smoothstep(-sBlur * 0.6, sBlur, d));
            if (alpha > 0.002) {
              this.blendPixel(px, py, sr, sg, sb, alpha);
            }
          }
        }
      }
    }

    const aa = 0.45;
    for (let py = minY; py <= maxY; py++) {
      const uy = py / SS;
      const ny = clamp((uy - bbox[1]) / bh, 0, 1);
      for (let px = minX; px <= maxX; px++) {
        const ux = px / SS;
        const d = sdfFn(ux, uy);
        const halfStroke = stroke ? stroke.width * 0.5 : 0;

        if (d > halfStroke + aa) continue;

        const nx = clamp((ux - bbox[0]) / bw, 0, 1);

        if (fill && d < aa) {
          const fillAlpha = 1 - smoothstep(-aa, aa, d);
          const [fr, fg, fb, fa] = typeof fill === 'function' ? fill(nx, ny, ux, uy, d) : fill;
          this.blendPixel(px, py, fr, fg, fb, fa * fillAlpha);
        }

        if (stroke && Math.abs(d) < halfStroke + aa) {
          const strokeAlpha = 1 - smoothstep(halfStroke - aa, halfStroke + aa, Math.abs(d));
          const [kr, kg, kb, ka] =
            typeof stroke.color === 'function' ? stroke.color(nx, ny, ux, uy) : stroke.color;
          this.blendPixel(px, py, kr, kg, kb, ka * strokeAlpha);
        }
      }
    }
  }

  toPNG() {
    const raw = Buffer.alloc(OUT_H * (1 + OUT_W * 4));
    for (let y = 0; y < OUT_H; y++) {
      const rowOffset = y * (1 + OUT_W * 4);
      raw[rowOffset] = 0;
      for (let x = 0; x < OUT_W; x++) {
        let rSum = 0,
          gSum = 0,
          bSum = 0,
          aSum = 0;
        for (let sy = 0; sy < SS; sy++) {
          const py = y * SS + sy;
          for (let sx = 0; sx < SS; sx++) {
            const px = x * SS + sx;
            const idx = (py * W + px) * 4;
            rSum += this.buf[idx];
            gSum += this.buf[idx + 1];
            bSum += this.buf[idx + 2];
            aSum += this.buf[idx + 3];
          }
        }
        const invN = 1 / (SS * SS);
        const a = clamp(aSum * invN, 0, 1);
        let r = 0,
          g = 0,
          b = 0;
        if (a > 0.0001) {
          r = clamp((rSum * invN) / a, 0, 255);
          g = clamp((gSum * invN) / a, 0, 255);
          b = clamp((bSum * invN) / a, 0, 255);
        }
        const pOff = rowOffset + 1 + x * 4;
        raw[pOff] = Math.round(r);
        raw[pOff + 1] = Math.round(g);
        raw[pOff + 2] = Math.round(b);
        raw[pOff + 3] = Math.round(a * 255);
      }
    }
    return encodePNG(OUT_W, OUT_H, raw);
  }
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
    }
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  const combined = Buffer.concat([typeBuf, data]);
  crcBuf.writeUInt32BE(crc32(combined), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(width, height, rawFilterData) {
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  const idat = zlib.deflateSync(rawFilterData, { level: 9 });
  return Buffer.concat([sig, pngChunk('IHDR', ihdr), pngChunk('IDAT', idat), pngChunk('IEND', Buffer.alloc(0))]);
}

const sdCircle = (cx, cy, r) => (x, y) => Math.hypot(x - cx, y - cy) - r;
const sdEllipse = (cx, cy, rx, ry) => (x, y) => {
  const dx = (x - cx) / rx;
  const dy = (y - cy) / ry;
  return (Math.hypot(dx, dy) - 1) * Math.min(rx, ry);
};
const sdRoundRect = (cx, cy, hw, hh, r = 0) => (x, y) => {
  const qx = Math.abs(x - cx) - (hw - r);
  const qy = Math.abs(y - cy) - (hh - r);
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
};
const sdSegment = (x1, y1, x2, y2, r = 1) => (x, y) => {
  const px = x - x1,
    py = y - y1;
  const bx = x2 - x1,
    by = y2 - y1;
  const h = clamp((px * bx + py * by) / (bx * bx + by * by || 1), 0, 1);
  return Math.hypot(px - bx * h, py - by * h) - r;
};
const sdPolygon = (pts) => (x, y) => {
  let d = Infinity;
  let s = 1;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i];
    const [xj, yj] = pts[j];
    const ex = xj - xi,
      ey = yj - yi;
    const wx = x - xi,
      wy = y - yi;
    const b = clamp((wx * ex + wy * ey) / (ex * ex + ey * ey || 1), 0, 1);
    const bx = wx - ex * b,
      by = wy - ey * b;
    d = Math.min(d, bx * bx + by * by);
    const c1 = y >= yi,
      c2 = y < yj,
      c3 = ex * wy > ey * wx;
    if ((c1 && c2 && c3) || (!c1 && !c2 && !c3)) s = -s;
  }
  return s * Math.sqrt(d);
};
const sdStar8 = (cx, cy, r) => {
  const s = r * 0.72;
  return (x, y) => {
    const dx = x - cx,
      dy = y - cy;
    const d1 = Math.max(Math.abs(dx), Math.abs(dy)) - s;
    const rx = (dx + dy) * Math.SQRT1_2;
    const ry = (dy - dx) * Math.SQRT1_2;
    const d2 = Math.max(Math.abs(rx), Math.abs(ry)) - s;
    return Math.min(d1, d2);
  };
};
const opUnion = (...fns) => (x, y) => {
  let m = Infinity;
  for (const fn of fns) {
    const v = fn(x, y);
    if (v < m) m = v;
  }
  return m;
};
const opSub = (fnA, fnB) => (x, y) => Math.max(fnA(x, y), -fnB(x, y));
const opInter = (fnA, fnB) => (x, y) => Math.max(fnA(x, y), fnB(x, y));

// ── Shared RIFQ Purple/Indigo + Gold Gradients ──
const PURPLE_GRAD = (nx, ny) =>
  mixColor(parseHex('#7C80FF'), parseHex('#4145C7'), clamp(nx * 0.4 + ny * 0.6, 0, 1));
const PURPLE_SOFT = (nx, ny) =>
  mixColor(parseHex('#A5A8FF'), parseHex('#6C70F5'), clamp(nx * 0.4 + ny * 0.6, 0, 1));
const PURPLE_DARK = parseHex('#2B2E85');
const GOLD_GRAD = (nx, ny) =>
  mixColor(parseHex('#FFE17D'), parseHex('#DC9B2B'), clamp(nx * 0.4 + ny * 0.6, 0, 1));
const GREEN_GRAD = (nx, ny) =>
  mixColor(parseHex('#68D391'), parseHex('#2F855A'), clamp(nx * 0.4 + ny * 0.6, 0, 1));
const BLUE_GRAD = (nx, ny) =>
  mixColor(parseHex('#8CC5FF'), parseHex('#4A7BE8'), clamp(nx * 0.4 + ny * 0.6, 0, 1));
const SKIN_GRAD = (nx, ny) =>
  mixColor(parseHex('#FCD8C0'), parseHex('#EAA887'), clamp(nx * 0.4 + ny * 0.6, 0, 1));

function createMedallionCanvas() {
  const c = new Canvas512();
  c.drawSDF(sdCircle(64, 64, 58), {
    fill: (nx, ny) => mixColor(parseHex('#FFFEFA'), parseHex('#EFEFF9'), clamp(Math.hypot(nx - 0.35, ny - 0.3), 0, 1)),
    stroke: { color: parseHex('#DEB253'), width: 3.0 },
    shadow: { dx: 0, dy: 2.5, blur: 4.0, color: [91, 95, 239, 0.14] },
  });
  return c;
}

function renderMisbaha() {
  const c = createMedallionCanvas();
  for (let i = 0; i < 12; i++) {
    const a = (i * Math.PI * 2) / 12 - Math.PI / 2;
    const bx = 64 + Math.cos(a) * 23;
    const by = 54 + Math.sin(a) * 23;
    c.drawSDF(sdCircle(bx, by, 5.5), { fill: PURPLE_GRAD, bbox: [bx - 7, by - 7, bx + 7, by + 7] });
    c.drawSDF(sdCircle(bx - 1.6, by - 1.6, 1.7), { fill: parseHex('#E0E2FF'), bbox: [bx - 4, by - 4, bx + 4, by + 4] });
  }
  c.drawSDF(sdCircle(64, 81, 4.5), { fill: PURPLE_DARK });
  c.drawSDF(sdRoundRect(64, 86, 3.6, 2.0, 1), { fill: GOLD_GRAD });
  c.drawSDF(sdPolygon([[61, 88], [67, 88], [71, 101], [57, 101]]), { fill: PURPLE_GRAD });
  return c;
}

function renderMosque() {
  const c = createMedallionCanvas();
  const cresc = opSub(sdCircle(57, 33, 6.5), sdCircle(59.5, 31, 5.2));
  c.drawSDF(cresc, { fill: GOLD_GRAD });
  c.drawSDF(sdRoundRect(87, 70, 4.5, 22, 1.5), { fill: PURPLE_SOFT });
  c.drawSDF(sdPolygon([[82, 47], [87, 37], [92, 47]]), { fill: PURPLE_GRAD });
  c.drawSDF(opInter(sdCircle(57, 68, 22), (x, y) => y - 68), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(63, 81, 31, 12, 3), { fill: PURPLE_SOFT });
  c.drawSDF(sdRoundRect(57, 85, 7, 8, 3.5), { fill: PURPLE_DARK });
  return c;
}

function renderQuran() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdSegment(38, 93, 90, 72, 3.2), sdSegment(90, 93, 38, 72, 3.2)), { fill: GOLD_GRAD });
  c.drawSDF(sdPolygon([[28, 58], [64, 72], [100, 58], [95, 44], [64, 56], [33, 44]]), { fill: PURPLE_GRAD });
  c.drawSDF(sdPolygon([[32, 54], [64, 66], [96, 54], [92, 41], [64, 52], [36, 41]]), {
    fill: parseHex('#FFFFFF'),
    stroke: { color: parseHex('#C5C8FF'), width: 1.5 },
  });
  return c;
}

function renderQuranAudio() {
  const c = createMedallionCanvas();
  const arc = opInter(opSub(sdCircle(64, 58, 31), sdCircle(64, 58, 25)), (x, y) => y - 58);
  c.drawSDF(arc, { fill: PURPLE_GRAD });
  c.drawSDF(opUnion(sdRoundRect(32, 66, 5.5, 11, 5), sdRoundRect(96, 66, 5.5, 11, 5)), { fill: PURPLE_DARK });
  c.drawSDF(sdRoundRect(64, 70, 18, 21, 4), { fill: PURPLE_GRAD });
  c.drawSDF(sdStar8(64, 68, 9), { fill: GOLD_GRAD });
  return c;
}

function renderWird() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 62, 26, 32, 6), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 87, 23, 3.8, 2), { fill: parseHex('#FFFFFF') });
  c.drawSDF(sdStar8(64, 56, 12), { fill: GOLD_GRAD });
  c.drawSDF(sdCircle(64, 56, 4.5), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 95, 4.5, 6, 1), { fill: GOLD_GRAD });
  return c;
}

function renderArbain() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 62, 26, 32, 6), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 87, 23, 3.8, 2), { fill: parseHex('#FFFFFF') });
  c.drawSDF(sdCircle(64, 57, 15.5), { fill: GOLD_GRAD, stroke: { color: parseHex('#FFF3C4'), width: 1.8 } });
  c.drawSDF(sdCircle(64, 57, 6), { fill: PURPLE_DARK });
  return c;
}

function renderWasaya() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(57, 64, 21, 26, 4), {
    fill: parseHex('#F2F2FF'),
    stroke: { color: parseHex('#B8BCFA'), width: 2 },
  });
  c.drawSDF(
    opUnion(
      sdSegment(45, 50, 69, 50, 1.8),
      sdSegment(45, 59, 69, 59, 1.8),
      sdSegment(45, 68, 63, 68, 1.8)
    ),
    { fill: GOLD_GRAD }
  );
  c.drawSDF(sdPolygon([[94, 41], [72, 58], [65, 83], [84, 71]]), { fill: PURPLE_GRAD });
  return c;
}

function renderCompanions() {
  const c = createMedallionCanvas();
  c.drawSDF(sdCircle(48, 50, 11.5), { fill: SKIN_GRAD });
  c.drawSDF(opInter(sdCircle(48, 46, 12), (x, y) => y - 46), { fill: PURPLE_DARK });
  c.drawSDF(sdCircle(80, 51, 11), { fill: SKIN_GRAD });
  c.drawSDF(opInter(sdCircle(80, 47, 11.5), (x, y) => y - 47), { fill: PURPLE_DARK });
  c.drawSDF(sdPolygon([[36, 67], [64, 74], [92, 67], [92, 92], [64, 98], [36, 92]]), { fill: PURPLE_GRAD });
  return c;
}

function renderHikayat() {
  const c = createMedallionCanvas();
  const cresc = opSub(sdCircle(64, 34, 7), sdCircle(67, 31.5, 5.5));
  c.drawSDF(cresc, { fill: GOLD_GRAD });
  c.drawSDF(sdPolygon([[30, 65], [64, 73], [98, 65], [98, 91], [64, 98], [30, 91]]), { fill: PURPLE_GRAD });
  c.drawSDF(sdPolygon([[34, 61], [64, 69], [94, 61], [94, 86], [64, 93], [34, 86]]), {
    fill: parseHex('#FFFFFF'),
    stroke: { color: parseHex('#C5C8FF'), width: 1.5 },
  });
  return c;
}

function renderKidsStories() {
  const c = createMedallionCanvas();
  c.drawSDF(sdStar8(64, 31, 4.5), { fill: GOLD_GRAD });
  c.drawSDF(sdCircle(48, 51, 11), { fill: SKIN_GRAD });
  c.drawSDF(opInter(sdCircle(48, 47, 11.5), (x, y) => y - 47), { fill: PURPLE_DARK });
  c.drawSDF(sdCircle(80, 52, 10.5), { fill: SKIN_GRAD });
  c.drawSDF(opInter(sdCircle(80, 48, 11), (x, y) => y - 48), { fill: PURPLE_DARK });
  c.drawSDF(sdRoundRect(64, 80, 31, 14, 4), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 77, 27, 12, 3), {
    fill: parseHex('#FFFFFF'),
    stroke: { color: parseHex('#C5C8FF'), width: 1.5 },
  });
  return c;
}

function renderHadith() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 64, 25, 27, 4), {
    fill: parseHex('#F3F3FF'),
    stroke: { color: parseHex('#C5C8FA'), width: 2 },
  });
  c.drawSDF(opInter(sdCircle(64, 62, 10), (x, y) => y - 62), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 66, 11, 4.5, 1.5), { fill: PURPLE_SOFT });
  return c;
}

function renderGharib() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(60, 64, 28, 22, 4), {
    fill: parseHex('#FFFFFF'),
    stroke: { color: parseHex('#5B5FEF'), width: 3 },
  });
  c.drawSDF(sdCircle(79, 73, 14), {
    fill: parseHex('#DCE6FF'),
    stroke: { color: parseHex('#5B5FEF'), width: 5 },
  });
  c.drawSDF(sdSegment(89, 83, 99, 93, 3.5), { fill: PURPLE_DARK });
  return c;
}

function renderTajweed() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 62, 26, 32, 6), { fill: PURPLE_GRAD });
  c.drawSDF(sdPolygon([[64, 44], [75, 58], [64, 72], [53, 58]]), { fill: GOLD_GRAD });
  c.drawSDF(sdCircle(64, 58, 4.2), { fill: PURPLE_GRAD });
  return c;
}

function renderFiqh() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 62, 26, 32, 6), { fill: PURPLE_GRAD });
  c.drawSDF(
    opUnion(
      sdSegment(64, 42, 64, 71, 2.2),
      sdSegment(52, 49, 76, 49, 2.2),
      sdCircle(52, 59, 5),
      sdCircle(76, 59, 5)
    ),
    { fill: GOLD_GRAD }
  );
  return c;
}

function renderTadabbur() {
  const c = createMedallionCanvas();
  c.drawSDF(sdSegment(66, 68, 66, 44, 2.2), { fill: GREEN_GRAD });
  c.drawSDF(opUnion(sdEllipse(57, 48, 8, 5), sdEllipse(75, 44, 8, 5)), { fill: GREEN_GRAD });
  c.drawSDF(sdRoundRect(64, 80, 28, 8, 4), { fill: PURPLE_GRAD });
  return c;
}

function renderZakat() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdRoundRect(64, 64, 3.2, 25, 1.5), sdRoundRect(64, 89, 18, 4, 2)), { fill: PURPLE_GRAD });
  c.drawSDF(sdSegment(37, 47, 91, 47, 2.5), { fill: PURPLE_DARK });
  c.drawSDF(opUnion(sdCircle(39, 72, 10), sdCircle(89, 72, 10)), { fill: GOLD_GRAD });
  return c;
}

function renderHijri() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 66, 30, 27, 8), {
    fill: parseHex('#EAEBFF'),
    stroke: { color: parseHex('#5B5FEF'), width: 3 },
  });
  c.drawSDF(sdRoundRect(64, 46, 30, 7, 4), { fill: PURPLE_GRAD });
  const cresc = opSub(sdCircle(64, 70, 11), sdCircle(69, 66, 8.5));
  c.drawSDF(cresc, { fill: GOLD_GRAD });
  return c;
}

function renderHajj() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(60, 64, 26, 26, 4), { fill: parseHex('#252850') });
  c.drawSDF(sdRoundRect(60, 52, 26, 4, 1), { fill: GOLD_GRAD });
  c.drawSDF(sdRoundRect(67, 72, 4, 7, 1), { fill: GOLD_GRAD });
  c.drawSDF(sdSegment(68, 90, 98, 72, 3.5), { fill: PURPLE_SOFT });
  return c;
}

function renderRuqyah() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdEllipse(48, 54, 7, 12), sdEllipse(64, 50, 7, 14), sdEllipse(80, 54, 7, 12)), {
    fill: GREEN_GRAD,
  });
  c.drawSDF(opInter(sdCircle(64, 69, 28), (x, y) => 69 - y), { fill: PURPLE_GRAD });
  return c;
}

function renderAzkar() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdRoundRect(50, 62, 10, 18, 5), sdRoundRect(78, 62, 10, 18, 5)), { fill: SKIN_GRAD });
  c.drawSDF(opUnion(sdRoundRect(48, 86, 9, 7, 2), sdRoundRect(80, 86, 9, 7, 2)), { fill: PURPLE_GRAD });
  c.drawSDF(sdStar8(64, 35, 4.5), { fill: GOLD_GRAD });
  return c;
}

function renderGraduation() {
  const c = createMedallionCanvas();
  c.drawSDF(sdPolygon([[28, 55], [64, 39], [100, 55], [64, 71]]), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 74, 20, 12, 5), { fill: PURPLE_DARK });
  c.drawSDF(sdSegment(64, 55, 90, 82, 2.2), { fill: GOLD_GRAD });
  return c;
}

function renderWudu() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdCircle(63, 46, 9), sdCircle(43, 54, 5.5), sdCircle(81, 55, 5)), { fill: BLUE_GRAD });
  c.drawSDF(sdRoundRect(64, 80, 28, 8, 4), { fill: PURPLE_GRAD });
  return c;
}

function renderTrophy() {
  const c = createMedallionCanvas();
  c.drawSDF(sdSegment(39, 61, 80, 35, 2.5), { fill: GOLD_GRAD });
  c.drawSDF(sdRoundRect(42, 81, 6.5, 11, 3), { fill: PURPLE_SOFT });
  c.drawSDF(sdRoundRect(64, 75, 6.5, 17, 3), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(86, 69, 6.5, 23, 3), { fill: PURPLE_DARK });
  return c;
}

function renderPalmTree() {
  const c = createMedallionCanvas();
  c.drawSDF(opUnion(sdSegment(43, 56, 43, 86, 2.2), sdSegment(85, 56, 85, 86, 2.2)), { fill: GOLD_GRAD });
  c.drawSDF(opUnion(sdEllipse(43, 52, 12, 6), sdEllipse(85, 52, 12, 6)), { fill: GREEN_GRAD });
  c.drawSDF(sdRoundRect(64, 73, 11, 18, 5.5), {
    stroke: { color: parseHex('#5B5FEF'), width: 4 },
  });
  return c;
}

function renderWomanFlower() {
  const c = createMedallionCanvas();
  c.drawSDF(sdCircle(62, 56, 15), { fill: SKIN_GRAD });
  c.drawSDF(sdPolygon([[36, 89], [40, 40], [68, 36], [76, 89]]), { fill: PURPLE_GRAD });
  c.drawSDF(sdCircle(88, 67, 6), { fill: parseHex('#F687B3') });
  return c;
}

function renderStatistics() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 64, 28, 31, 6), {
    fill: parseHex('#EAEBFF'),
    stroke: { color: parseHex('#7C80FF'), width: 2.5 },
  });
  c.drawSDF(sdCircle(75, 56, 10), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(79, 52, 5, 5, 1), { fill: GOLD_GRAD });
  return c;
}

function renderUser() {
  const c = createMedallionCanvas();
  c.drawSDF(sdCircle(60, 48, 13), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(60, 79, 24, 12, 6), { fill: PURPLE_GRAD });
  c.drawSDF(sdCircle(83, 81, 9), { fill: PURPLE_DARK });
  return c;
}

function renderAllahNames() {
  const c = createMedallionCanvas();
  c.drawSDF(sdStar8(64, 64, 40), { fill: GOLD_GRAD });
  c.drawSDF(sdStar8(64, 64, 33), { fill: PURPLE_GRAD });
  c.drawSDF(
    opUnion(
      sdRoundRect(74, 64, 2, 11, 1),
      sdRoundRect(66, 64, 2, 11, 1),
      sdRoundRect(58, 65, 2, 10, 1),
      sdRoundRect(62, 74, 10, 2, 1),
      sdCircle(51, 70, 4.5)
    ),
    { fill: GOLD_GRAD }
  );
  return c;
}

function renderSettings() {
  const c = createMedallionCanvas();
  const teeth = [sdCircle(64, 64, 25)];
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    teeth.push(sdCircle(64 + 26 * Math.cos(a), 64 + 26 * Math.sin(a), 6.5));
  }
  c.drawSDF(opSub(opUnion(...teeth), sdCircle(64, 64, 10)), { fill: PURPLE_GRAD });
  return c;
}

function renderContact() {
  const c = createMedallionCanvas();
  c.drawSDF(sdRoundRect(64, 53, 24, 17, 5), {
    fill: parseHex('#EAEBFF'),
    stroke: { color: parseHex('#5B5FEF'), width: 3 },
  });
  c.drawSDF(sdRoundRect(55, 76, 16, 12, 3), { fill: PURPLE_SOFT });
  c.drawSDF(sdPolygon([[71, 79], [95, 66], [87, 91]]), { fill: PURPLE_GRAD });
  return c;
}

function renderHome() {
  const c = createMedallionCanvas();
  c.drawSDF(sdPolygon([[34, 60], [64, 36], [94, 60], [94, 92], [34, 92]]), { fill: PURPLE_GRAD });
  c.drawSDF(sdRoundRect(64, 80, 8, 12, 4), { fill: GOLD_GRAD });
  return c;
}

function renderMorning() {
  const c = createMedallionCanvas();
  c.drawSDF(sdCircle(64, 58, 18), { fill: GOLD_GRAD });
  c.drawSDF(sdRoundRect(64, 84, 9, 6, 3), { fill: PURPLE_GRAD });
  return c;
}

function renderSleep() {
  const c = createMedallionCanvas();
  const cresc = opSub(sdCircle(62, 64, 22), sdCircle(72, 55, 18));
  c.drawSDF(cresc, { fill: GOLD_GRAD });
  return c;
}

const ICONS = {
  'ic_misbaha.png': renderMisbaha,
  'ic_mosque.png': renderMosque,
  'ic_quran.png': renderQuran,
  'ic_quran_audio.png': renderQuranAudio,
  'ic_wird.png': renderWird,
  'ic_arbain_nawawiya.png': renderArbain,
  'ic_wasaya.png': renderWasaya,
  'ic_companions.png': renderCompanions,
  'ic_hikayat.png': renderHikayat,
  'ic_kids_stories.png': renderKidsStories,
  'ic_hadith.png': renderHadith,
  'ic_gharib.png': renderGharib,
  'ic_tajweed.png': renderTajweed,
  'ic_fiqh_muyassar.png': renderFiqh,
  'ic_tadabbur.png': renderTadabbur,
  'ic_zakat.png': renderZakat,
  'ic_hijri.png': renderHijri,
  'ic_hajj.png': renderHajj,
  'ic_ruqyah.png': renderRuqyah,
  'ic_azkar.png': renderAzkar,
  'ic_graduation.png': renderGraduation,
  'ic_wudu.png': renderWudu,
  'ic_trophy.png': renderTrophy,
  'ic_palm_tree.png': renderPalmTree,
  'ic_microphone.png': renderQuranAudio,
  'ic_woman_flower.png': renderWomanFlower,
  'ic_statistics.png': renderStatistics,
  'ic_user.png': renderUser,
  'ic_allah_names.png': renderAllahNames,
  'ic_settings.png': renderSettings,
  'ic_contact.png': renderContact,
  'ic_home.png': renderHome,
  'ic_morning.png': renderMorning,
  'ic_noon.png': renderMorning,
  'ic_evening.png': renderSleep,
  'ic_sleep.png': renderSleep,
};

const ROOT = process.cwd();
const TARGET_DIRS = [
  path.join(ROOT, 'public/assets/icons/menu'),
  path.join(ROOT, 'flutter/assets/icons/menu'),
  path.join(ROOT, 'assets/icons/menu'),
];

for (const dir of TARGET_DIRS) {
  fs.mkdirSync(dir, { recursive: true });
}

console.log('Generating unified RIFQ 128x128 RGBA PNG icons...');
for (const [filename, renderFn] of Object.entries(ICONS)) {
  const canvas = renderFn();
  const pngBuffer = canvas.toPNG();
  for (const dir of TARGET_DIRS) {
    fs.writeFileSync(path.join(dir, filename), pngBuffer);
  }
}
console.log(`✓ Generated ${Object.keys(ICONS).length} unified PNG icons in all asset directories!`);
