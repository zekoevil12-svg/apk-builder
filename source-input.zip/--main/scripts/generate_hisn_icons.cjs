const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const targetDirs = [
  path.join(__dirname, '..', 'public', 'assets', 'hisn_almuslim', 'icons'),
  path.join(__dirname, '..', 'assets', 'hisn_almuslim', 'icons')
];

for (const dir of targetDirs) {
  fs.mkdirSync(dir, { recursive: true });
}

// Map categories/themes to specialized SVG graphics
const iconThemes = {
  // Mosques & Sacred places
  to_mosque: 'mosque',
  enter_mosque: 'mosque',
  exit_mosque: 'mosque',
  mosque_2: 'mosque',
  madinah: 'mosque',
  aqsa: 'mosque',
  kaaba: 'kaaba',
  hajj: 'kaaba',
  umrah: 'kaaba',
  arafah: 'kaaba',
  
  // Morning, Evening, Celestial
  morning_evening: 'sun_moon',
  wakeup: 'sun_rise',
  sleep: 'crescent_star',
  sleep_2: 'crescent_star',
  crescent: 'crescent_star',
  witr: 'crescent_star',
  laylat_alqadr: 'crescent_star',
  ramadan: 'crescent_star',
  muharram: 'crescent_star',
  ashura: 'crescent_star',
  new_year: 'crescent_star',
  mawlid: 'crescent_star',
  isra_meraj: 'crescent_star',
  eid_fitr: 'crescent_star',
  dreams: 'crescent_star',
  
  // Supplication & Worship
  dua: 'hands_dua',
  opening_prayer: 'hands_dua',
  qunut: 'hands_dua',
  istikhara: 'hands_dua',
  adhan: 'adhan_call',
  rukoo: 'prayer_bow',
  rising: 'prayer_bow',
  sujood: 'prayer_sujood',
  between_sujood: 'prayer_sujood',
  tilawah_sujood: 'prayer_sujood',
  tashahhud: 'hands_dua',
  after_tashahhud: 'hands_dua',
  after_salam: 'prayer_beads',
  prayer_beads: 'prayer_beads',
  dhikr: 'prayer_beads',
  tasbeeh: 'prayer_beads',
  takbir: 'prayer_beads',
  tahleel: 'prayer_beads',
  hamd: 'prayer_beads',
  salah_nabi: 'lantern_rose',
  forgiveness: 'hands_dua',
  repentance: 'hands_dua',
  gratitude: 'hands_dua',
  patience: 'hands_dua',
  praising: 'hands_dua',
  
  // Quran & Knowledge
  quran_recitation: 'quran_book',
  knowledge: 'quran_book',
  hafiz: 'quran_book',
  scholars: 'quran_book',
  itikaf: 'quran_book',
  
  // Water, Purity & Hygiene
  wudu: 'water_pitcher',
  after_wudu: 'water_pitcher',
  bathroom: 'water_pitcher',
  drinking: 'water_pitcher',
  
  // Clothes & Appearance
  clothing: 'garment',
  new_clothes: 'garment',
  remove_clothes: 'garment',
  hijab: 'garment',
  
  // Travel & Movement
  travel: 'travel_compass',
  return_travel: 'travel_compass',
  entering_village: 'travel_compass',
  animal: 'riding_beast',
  riding: 'riding_beast',
  traveler_resident: 'travel_compass',
  ascending: 'travel_compass',
  airplane: 'airplane',
  walking: 'travel_compass',
  
  // Food & Hospitality
  before_food: 'food_dates',
  after_food: 'food_dates',
  eating: 'food_dates',
  fasting_break: 'food_dates',
  guest: 'hospitality_chalice',
  guests: 'hospitality_chalice',
  eid_adha: 'hospitality_chalice',
  
  // Protection, Shield, Health
  protection: 'shield_protection',
  protection_2: 'shield_protection',
  fear: 'shield_protection',
  whispers: 'shield_protection',
  whispers_2: 'shield_protection',
  anger: 'shield_protection',
  evil_eye: 'shield_protection',
  evil: 'shield_protection',
  magic: 'shield_protection',
  envy: 'shield_protection',
  enemy: 'shield_protection',
  distress: 'shield_protection',
  calamity: 'shield_protection',
  shifa: 'olive_leaf_shifa',
  raqyah: 'olive_leaf_shifa',
  sick: 'olive_leaf_shifa',
  visiting_sick: 'olive_leaf_shifa',
  health: 'olive_leaf_shifa',
  
  // Weather & Nature
  wind: 'weather_wind',
  thunder: 'weather_thunder',
  rain: 'weather_rain',
  rain_stop: 'weather_rain',
  asking_rain: 'weather_rain',
  
  // Home & Society
  enter_home: 'home_arch',
  exit_home: 'home_arch',
  market: 'market_coins',
  shopping: 'market_coins',
  work: 'market_coins',
  wealth: 'market_coins',
  zakat: 'charity_coins',
  sadaqah: 'charity_coins',
  poor: 'charity_coins',
  orphans: 'family_kindness',
  family: 'family_kindness',
  parents: 'family_kindness',
  children: 'family_kindness',
  neighbors: 'family_kindness',
  kindness: 'family_kindness',
  greeting: 'handshake',
  handshake: 'handshake',
  sneezing: 'sun_rise',
  yawning: 'crescent_star',
  marriage: 'marriage_rings',
  intimacy: 'marriage_rings',
  friday: 'friday_mosque',
  time: 'hourglass_time',
  
  // Afterlife & Unseen
  death: 'crescent_star',
  death_2: 'crescent_star',
  funeral: 'crescent_star',
  condolences: 'hands_dua',
  grave: 'crescent_star',
  barzakh: 'crescent_star',
  day_judgment: 'scales_justice',
  jannah: 'jannah_garden',
  jahannam: 'shield_protection',
  angels: 'light_star',
  prophets: 'light_star',
  companions: 'light_star',
  companions_wives: 'light_star',
  
  default: 'shield_protection'
};

function getVectorGraphic(theme) {
  switch (theme) {
    case 'mosque':
      return `
        <!-- Mosque Dome & Minarets -->
        <path d="M 256 120 C 210 160 190 220 190 270 L 322 270 C 322 220 302 160 256 120 Z" fill="url(#goldGrad)" />
        <rect x="200" y="270" width="112" height="120" rx="6" fill="#FDFBF7" stroke="#C9A84C" stroke-width="8" />
        <path d="M 230 390 L 230 320 C 230 305 282 305 282 320 L 282 390 Z" fill="#3E2723" />
        <!-- Left Minaret -->
        <rect x="145" y="170" width="30" height="220" rx="4" fill="#F5F0E8" stroke="#C9A84C" stroke-width="6" />
        <path d="M 160 125 L 140 170 L 180 170 Z" fill="url(#goldGrad)" />
        <!-- Right Minaret -->
        <rect x="337" y="170" width="30" height="220" rx="4" fill="#F5F0E8" stroke="#C9A84C" stroke-width="6" />
        <path d="M 352 125 L 332 170 L 372 170 Z" fill="url(#goldGrad)" />
        <!-- Top Finial & Crescent -->
        <path d="M 256 95 L 256 120" stroke="#C9A84C" stroke-width="8" stroke-linecap="round" />
        <circle cx="256" cy="90" r="14" fill="none" stroke="#C9A84C" stroke-width="6" />
      `;

    case 'kaaba':
      return `
        <!-- Holy Kaaba -->
        <path d="M 180 200 L 256 160 L 332 200 L 332 350 L 256 390 L 180 350 Z" fill="#2A2421" stroke="#C9A84C" stroke-width="6" />
        <path d="M 256 160 L 256 390" stroke="#3D3531" stroke-width="6" />
        <!-- Gold Belt (Kiswah Hizam) -->
        <path d="M 180 235 L 256 200 L 332 235 L 332 255 L 256 220 L 180 255 Z" fill="url(#goldGrad)" />
        <!-- Golden Door of Kaaba -->
        <rect x="270" y="270" width="36" height="65" rx="3" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="4" />
      `;

    case 'quran_book':
      return `
        <!-- Holy Quran on Rehal (Stand) -->
        <!-- Pages Book Left & Right -->
        <path d="M 256 260 C 220 220 160 215 130 225 L 130 330 C 160 320 220 325 256 360 C 292 325 352 320 382 330 L 382 225 C 352 215 292 220 256 260 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" stroke-linejoin="round" />
        <!-- Binding spine -->
        <line x1="256" y1="260" x2="256" y2="360" stroke="#8A671A" stroke-width="8" stroke-linecap="round" />
        <!-- Gold text markings -->
        <line x1="160" y1="260" x2="225" y2="255" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <line x1="160" y1="285" x2="225" y2="280" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <line x1="160" y1="310" x2="215" y2="305" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <line x1="287" y1="255" x2="352" y2="260" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <line x1="287" y1="280" x2="352" y2="285" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <line x1="297" y1="305" x2="352" y2="310" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        <!-- Wooden Rehal Base -->
        <path d="M 160 365 L 256 425 L 352 365" stroke="#8A671A" stroke-width="14" stroke-linecap="round" stroke-linejoin="round" fill="none" />
        <path d="M 190 415 L 322 415" stroke="#8A671A" stroke-width="10" stroke-linecap="round" />
      `;

    case 'hands_dua':
      return `
        <!-- Hands in Supplication (Dua) -->
        <g transform="translate(0, 10)">
          <!-- Left Palm -->
          <path d="M 230 380 C 230 380 205 320 185 280 C 175 260 155 240 145 255 C 135 270 150 295 160 315 L 165 240 C 165 220 180 220 185 240 L 195 305 L 195 210 C 195 190 210 190 215 210 L 220 305 L 225 215 C 225 195 240 195 245 215 L 248 340 Z" fill="#FBF8F2" stroke="#C9A84C" stroke-width="7" stroke-linejoin="round" />
          <!-- Right Palm (mirrored) -->
          <path d="M 282 380 C 282 380 307 320 327 280 C 337 260 357 240 367 255 C 377 270 362 295 352 315 L 347 240 C 347 220 332 220 327 240 L 317 305 L 317 210 C 317 190 302 190 297 210 L 292 305 L 287 215 C 287 195 272 195 267 215 L 264 340 Z" fill="#FBF8F2" stroke="#C9A84C" stroke-width="7" stroke-linejoin="round" />
          <!-- Glow sparkles above hands -->
          <circle cx="256" cy="150" r="10" fill="url(#goldGrad)" />
          <path d="M 256 120 L 256 180 M 226 150 L 286 150" stroke="#C9A84C" stroke-width="5" stroke-linecap="round" />
        </g>
      `;

    case 'crescent_star':
      return `
        <!-- Islamic Crescent & Radiant Star -->
        <path d="M 280 140 C 200 140 140 200 140 280 C 140 360 200 420 280 420 C 335 420 380 390 405 345 C 330 365 240 330 220 250 C 210 200 235 155 280 140 Z" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="6" />
        <!-- Radiant Star -->
        <polygon points="340,190 352,220 384,222 358,242 368,272 340,254 312,272 322,242 296,222 328,220" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="4" />
      `;

    case 'sun_moon':
      return `
        <!-- Sun and Moon Together (Morning & Evening) -->
        <!-- Morning Radiant Sun Left -->
        <circle cx="210" cy="240" r="60" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="5" />
        <g stroke="#C9A84C" stroke-width="7" stroke-linecap="round">
          <line x1="210" y1="145" x2="210" y2="165" />
          <line x1="210" y1="315" x2="210" y2="335" />
          <line x1="115" y1="240" x2="135" y2="240" />
          <line x1="285" y1="240" x2="305" y2="240" />
          <line x1="143" y1="173" x2="158" y2="188" />
          <line x1="262" y1="292" x2="277" y2="307" />
          <line x1="143" y1="307" x2="158" y2="292" />
          <line x1="262" y1="188" x2="277" y2="173" />
        </g>
        <!-- Evening Crescent Right -->
        <path d="M 330 200 C 285 200 250 235 250 280 C 250 325 285 360 330 360 C 358 360 382 345 395 322 C 352 332 305 310 295 265 C 290 235 305 210 330 200 Z" fill="#2E7D32" stroke="#C9A84C" stroke-width="6" />
      `;

    case 'sun_rise':
      return `
        <!-- Sunrise / Awakening -->
        <path d="M 140 340 L 372 340" stroke="#C9A84C" stroke-width="10" stroke-linecap="round" />
        <path d="M 170 340 C 170 270 208 220 256 220 C 304 220 342 270 342 340 Z" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="6" />
        <g stroke="#C9A84C" stroke-width="8" stroke-linecap="round">
          <line x1="256" y1="140" x2="256" y2="185" />
          <line x1="170" y1="180" x2="200" y2="210" />
          <line x1="342" y1="180" x2="312" y2="210" />
          <line x1="120" y1="260" x2="160" y2="275" />
          <line x1="392" y1="260" x2="352" y2="275" />
        </g>
      `;

    case 'prayer_beads':
      return `
        <!-- Prayer Beads (Subha / Masbaha) -->
        <ellipse cx="256" cy="250" rx="95" ry="90" fill="none" stroke="#C9A84C" stroke-width="6" stroke-dasharray="2 18" stroke-linecap="round" />
        <!-- Bead circles around -->
        ${Array.from({ length: 18 }).map((_, i) => {
          const angle = (i * 20 * Math.PI) / 180;
          const x = 256 + 95 * Math.cos(angle);
          const y = 250 + 90 * Math.sin(angle);
          return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="11" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="3" />`;
        }).join('')}
        <!-- Minaret/Shahed Top Tassel -->
        <path d="M 256 340 L 256 400" stroke="#C9A84C" stroke-width="8" stroke-linecap="round" />
        <polygon points="256,400 240,440 272,440" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="3" />
      `;

    case 'shield_protection':
      return `
        <!-- Islamic Defense Shield (Hisn Protection) -->
        <path d="M 256 130 C 330 130 365 170 365 240 C 365 330 290 395 256 420 C 222 395 147 330 147 240 C 147 170 182 130 256 130 Z" fill="#FFFDF8" stroke="url(#goldGrad)" stroke-width="14" stroke-linejoin="round" />
        <path d="M 256 155 C 315 155 345 188 345 245 C 345 315 285 372 256 395 C 227 372 167 315 167 245 C 167 188 197 155 256 155 Z" fill="#F5F0E8" stroke="#C9A84C" stroke-width="5" />
        <!-- Emblem Crescent & Star inside Shield -->
        <path d="M 265 200 C 230 200 205 228 205 265 C 205 302 230 330 265 330 C 285 330 302 320 312 305 C 282 312 250 295 245 260 C 240 230 258 208 265 200 Z" fill="url(#goldGrad)" />
        <polygon points="295,225 301,240 317,241 304,251 309,266 295,257 281,266 286,251 273,241 289,240" fill="url(#goldGrad)" />
      `;

    case 'water_pitcher':
      return `
        <!-- Traditional Ewer / Pitcher for Wudu -->
        <path d="M 220 180 L 292 180 L 305 270 C 315 310 285 360 256 360 C 227 360 197 310 207 270 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" />
        <!-- Handle -->
        <path d="M 207 220 C 165 220 165 310 215 320" fill="none" stroke="#C9A84C" stroke-width="8" stroke-linecap="round" />
        <!-- Spout -->
        <path d="M 285 240 C 330 230 355 190 350 170 C 345 170 330 195 280 215" fill="#C9A84C" />
        <!-- Water Drops -->
        <path d="M 370 210 C 370 225 355 235 355 220 C 355 205 370 190 370 210 Z" fill="#2E7D32" />
        <path d="M 256 390 C 262 402 256 415 256 415 C 256 415 250 402 256 390 Z" fill="#C9A84C" stroke="#8A671A" stroke-width="3" />
      `;

    case 'garment':
      return `
        <!-- Islamic Robe / Thobe / Garment -->
        <path d="M 200 160 L 235 190 L 256 175 L 277 190 L 312 160 L 372 230 L 332 255 L 320 235 L 320 400 L 192 400 L 192 235 L 180 255 L 140 230 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" stroke-linejoin="round" />
        <!-- Collar & Buttons -->
        <line x1="256" y1="190" x2="256" y2="280" stroke="#C9A84C" stroke-width="6" stroke-linecap="round" />
        <circle cx="256" cy="215" r="4" fill="#8A671A" />
        <circle cx="256" cy="245" r="4" fill="#8A671A" />
        <circle cx="256" cy="275" r="4" fill="#8A671A" />
      `;

    case 'travel_compass':
      return `
        <!-- Compass & Travel Navigation -->
        <circle cx="256" cy="256" r="110" fill="#FFFDF8" stroke="#C9A84C" stroke-width="10" />
        <circle cx="256" cy="256" r="85" fill="none" stroke="#F5F0E8" stroke-width="6" stroke-dasharray="6 6" />
        <!-- Compass Needle -->
        <polygon points="256,160 272,256 256,242 240,256" fill="#1B5E20" stroke="#1B5E20" stroke-width="2" />
        <polygon points="256,352 272,256 256,270 240,256" fill="#C9A84C" stroke="#8A671A" stroke-width="2" />
        <circle cx="256" cy="256" r="10" fill="#FFFDF8" stroke="#8A671A" stroke-width="5" />
      `;

    case 'airplane':
      return `
        <!-- Airplane Travel -->
        <path d="M 256 140 L 270 220 L 382 280 L 382 305 L 270 270 L 270 360 L 305 385 L 305 405 L 256 395 L 207 405 L 207 385 L 242 360 L 242 270 L 130 305 L 130 280 L 242 220 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" stroke-linejoin="round" />
      `;

    case 'riding_beast':
      return `
        <!-- Camel / Travel Mount Silhouette -->
        <path d="M 180 380 L 180 300 C 180 270 200 260 220 260 C 235 240 250 210 255 240 C 270 220 290 220 305 250 C 330 260 345 285 345 320 L 345 380 M 345 290 L 375 240 C 385 220 375 190 350 185 L 325 185" fill="none" stroke="#C9A84C" stroke-width="12" stroke-linecap="round" stroke-linejoin="round" />
        <!-- Saddle / Howdah -->
        <rect x="250" y="220" width="40" height="25" rx="4" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="3" />
      `;

    case 'food_dates':
      return `
        <!-- Palm Dates & Plate for Iftar/Food -->
        <ellipse cx="256" cy="340" rx="120" ry="40" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" />
        <!-- 3 Rich Golden Dates -->
        <ellipse cx="225" cy="305" rx="35" ry="25" transform="rotate(-15 225 305)" fill="#6D4C41" stroke="#C9A84C" stroke-width="4" />
        <ellipse cx="285" cy="305" rx="35" ry="25" transform="rotate(15 285 305)" fill="#5D4037" stroke="#C9A84C" stroke-width="4" />
        <ellipse cx="256" cy="275" rx="38" ry="26" fill="#4E342E" stroke="#C9A84C" stroke-width="4" />
        <!-- Palm Frond on side -->
        <path d="M 256 160 C 256 220 220 250 180 260" stroke="#1B5E20" stroke-width="6" stroke-linecap="round" fill="none" />
        <line x1="240" y1="185" x2="215" y2="180" stroke="#1B5E20" stroke-width="5" stroke-linecap="round" />
        <line x1="230" y1="210" x2="200" y2="210" stroke="#1B5E20" stroke-width="5" stroke-linecap="round" />
      `;

    case 'olive_leaf_shifa':
      return `
        <!-- Olive Branch / Honey / Healing Shifa -->
        <path d="M 180 360 C 200 280 260 210 340 160" stroke="#1B5E20" stroke-width="10" stroke-linecap="round" fill="none" />
        <!-- Leaves -->
        <path d="M 230 300 C 200 290 190 260 210 250 C 230 260 235 280 230 300 Z" fill="#2E7D32" stroke="#C9A84C" stroke-width="4" />
        <path d="M 270 250 C 275 220 305 215 315 235 C 305 255 285 260 270 250 Z" fill="#2E7D32" stroke="#C9A84C" stroke-width="4" />
        <path d="M 310 190 C 305 160 335 150 350 170 C 345 190 325 195 310 190 Z" fill="#2E7D32" stroke="#C9A84C" stroke-width="4" />
        <!-- Honey drop / healing sphere -->
        <circle cx="210" cy="200" r="32" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="5" />
        <path d="M 210 160 L 210 175" stroke="#C9A84C" stroke-width="6" stroke-linecap="round" />
      `;

    case 'home_arch':
      return `
        <!-- Islamic Home Arch & Door -->
        <path d="M 180 390 L 180 240 C 180 180 220 150 256 130 C 292 150 332 180 332 240 L 332 390 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="10" stroke-linejoin="round" />
        <!-- Wooden Door Panels -->
        <rect x="205" y="235" width="46" height="155" rx="3" fill="#F5F0E8" stroke="#8A671A" stroke-width="4" />
        <rect x="259" y="235" width="46" height="155" rx="3" fill="#F5F0E8" stroke="#8A671A" stroke-width="4" />
        <circle cx="242" cy="315" r="4" fill="#C9A84C" />
        <circle cx="268" cy="315" r="4" fill="#C9A84C" />
      `;

    case 'market_coins':
      return `
        <!-- Islamic Market & Commerce Scales/Coins -->
        <ellipse cx="256" cy="350" rx="90" ry="25" fill="#F5F0E8" stroke="#C9A84C" stroke-width="6" />
        <!-- 3 Gold Dinars -->
        <circle cx="220" cy="290" r="35" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="5" />
        <circle cx="292" cy="290" r="35" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="5" />
        <circle cx="256" cy="235" r="38" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="6" />
        <!-- Center Arabic Star Mark -->
        <polygon points="256,215 261,228 274,228 263,237 267,250 256,242 245,250 249,237 238,228 251,228" fill="#8A671A" />
      `;

    case 'charity_coins':
      return `
        <!-- Hand Giving Charity (Sadaqah & Zakat) -->
        <path d="M 140 330 C 180 330 200 310 240 310 C 270 310 320 335 370 335" stroke="#C9A84C" stroke-width="12" stroke-linecap="round" fill="none" />
        <path d="M 230 310 C 220 280 200 270 170 270 L 140 270" stroke="#C9A84C" stroke-width="10" stroke-linecap="round" fill="none" />
        <!-- Coin falling into hand -->
        <circle cx="256" cy="190" r="42" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="6" />
        <text x="256" y="200" font-size="28" font-weight="bold" text-anchor="middle" fill="#8A671A" font-family="sans-serif">لله</text>
      `;

    case 'family_kindness':
      return `
        <!-- Family / Compassion (Heart of Mercy & Arch) -->
        <path d="M 256 380 C 180 320 150 260 170 200 C 190 155 240 160 256 195 C 272 160 322 155 342 200 C 362 260 332 320 256 380 Z" fill="#FDFBF7" stroke="#C9A84C" stroke-width="10" stroke-linejoin="round" />
        <!-- Child and Parents silhouettes -->
        <circle cx="225" cy="245" r="14" fill="#C9A84C" />
        <circle cx="287" cy="245" r="14" fill="#C9A84C" />
        <circle cx="256" cy="295" r="11" fill="#1B5E20" />
      `;

    case 'handshake':
      return `
        <!-- Handshake / Salam / Brotherhood -->
        <path d="M 140 280 L 220 280 L 260 250 L 300 280 L 372 280" stroke="#C9A84C" stroke-width="12" stroke-linecap="round" fill="none" />
        <path d="M 220 250 L 292 250" stroke="#1B5E20" stroke-width="10" stroke-linecap="round" />
        <!-- Greeting Sparkle -->
        <polygon points="256,160 262,175 277,175 265,185 270,200 256,190 242,200 247,185 235,175 250,175" fill="url(#goldGrad)" />
      `;

    case 'jannah_garden':
      return `
        <!-- Palm Trees & River of Jannah -->
        <!-- River Stream -->
        <path d="M 170 380 C 210 350 220 300 256 300 C 292 300 302 350 342 380" stroke="#2E7D32" stroke-width="14" stroke-linecap="round" fill="none" />
        <!-- Palm Tree Trunk -->
        <path d="M 245 350 C 240 280 250 240 256 180" stroke="#8A671A" stroke-width="12" stroke-linecap="round" fill="none" />
        <!-- Palm Leaves Canopy -->
        <path d="M 256 180 C 210 170 170 190 150 220" stroke="#1B5E20" stroke-width="8" stroke-linecap="round" fill="none" />
        <path d="M 256 180 C 302 170 342 190 362 220" stroke="#1B5E20" stroke-width="8" stroke-linecap="round" fill="none" />
        <path d="M 256 180 C 230 140 190 130 160 145" stroke="#1B5E20" stroke-width="8" stroke-linecap="round" fill="none" />
        <path d="M 256 180 C 282 140 322 130 352 145" stroke="#1B5E20" stroke-width="8" stroke-linecap="round" fill="none" />
        <path d="M 256 180 L 256 120" stroke="#1B5E20" stroke-width="8" stroke-linecap="round" />
      `;

    case 'weather_rain':
      return `
        <!-- Cloud and Blessings Rain -->
        <path d="M 190 260 C 160 260 140 235 140 210 C 140 180 170 160 200 165 C 215 135 255 125 285 140 C 315 130 355 150 365 185 C 385 195 390 230 375 255 C 365 260 340 260 330 260 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" stroke-linejoin="round" />
        <!-- Rain Streaks -->
        <line x1="200" y1="290" x2="180" y2="340" stroke="#1B5E20" stroke-width="6" stroke-linecap="round" />
        <line x1="240" y1="290" x2="220" y2="350" stroke="#C9A84C" stroke-width="6" stroke-linecap="round" />
        <line x1="280" y1="290" x2="260" y2="340" stroke="#1B5E20" stroke-width="6" stroke-linecap="round" />
        <line x1="320" y1="290" x2="300" y2="350" stroke="#C9A84C" stroke-width="6" stroke-linecap="round" />
      `;

    case 'weather_wind':
      return `
        <!-- Wind Breezes -->
        <path d="M 150 210 C 250 210 320 210 320 185 C 320 160 295 160 295 180" stroke="#C9A84C" stroke-width="10" stroke-linecap="round" fill="none" />
        <path d="M 130 260 C 270 260 360 260 360 230 C 360 205 330 205 330 225" stroke="#1B5E20" stroke-width="10" stroke-linecap="round" fill="none" />
        <path d="M 170 310 C 240 310 290 310 290 285 C 290 265 270 265 270 280" stroke="#C9A84C" stroke-width="10" stroke-linecap="round" fill="none" />
      `;

    case 'weather_thunder':
      return `
        <!-- Cloud and Lightning -->
        <path d="M 190 230 C 160 230 140 205 140 180 C 140 150 170 130 200 135 C 215 105 255 95 285 110 C 315 100 355 120 365 155 C 385 165 390 200 375 225 C 365 230 340 230 330 230 Z" fill="#FFFDF8" stroke="#C9A84C" stroke-width="8" stroke-linejoin="round" />
        <!-- Golden Lightning Bolt -->
        <polygon points="265,210 230,285 265,285 240,370 295,270 260,270" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="4" stroke-linejoin="round" />
      `;

    case 'light_star':
      return `
        <!-- Eight-Pointed Islamic Rub-el-Hizb Star -->
        <g transform="translate(256, 256) scale(1.1) translate(-256, -256)">
          <rect x="186" y="186" width="140" height="140" rx="8" fill="#FFFDF8" stroke="url(#goldGrad)" stroke-width="10" />
          <rect x="186" y="186" width="140" height="140" rx="8" transform="rotate(45 256 256)" fill="#FFFDF8" stroke="url(#goldGrad)" stroke-width="10" />
          <circle cx="256" cy="256" r="42" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="4" />
          <circle cx="256" cy="256" r="14" fill="#FFFDF8" />
        </g>
      `;

    default:
      return `
        <!-- Default Islamic Ornament / Crest -->
        <path d="M 256 130 C 330 130 365 170 365 240 C 365 330 290 395 256 420 C 222 395 147 330 147 240 C 147 170 182 130 256 130 Z" fill="#FFFDF8" stroke="url(#goldGrad)" stroke-width="14" stroke-linejoin="round" />
        <circle cx="256" cy="265" r="45" fill="url(#goldGrad)" stroke="#8A671A" stroke-width="5" />
        <polygon points="256,235 262,252 280,252 266,262 271,280 256,270 241,280 246,262 232,252 250,252" fill="#FFFDF8" />
      `;
  }
}

function buildSvgForIcon(iconName) {
  const theme = iconThemes[iconName] || iconThemes.default;
  const vectorGraphic = getVectorGraphic(theme);

  return `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
      <defs>
        <!-- Luxury Golden Gradients -->
        <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#E8CA72" />
          <stop offset="35%" stop-color="#D4AF37" />
          <stop offset="70%" stop-color="#C9A84C" />
          <stop offset="100%" stop-color="#A27D2C" />
        </linearGradient>
        
        <linearGradient id="goldBorder" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#8A671A" />
          <stop offset="50%" stop-color="#E8CA72" />
          <stop offset="100%" stop-color="#A27D2C" />
        </linearGradient>

        <radialGradient id="beigeRadial" cx="50%" cy="40%" r="55%">
          <stop offset="0%" stop-color="#FFFFFF" />
          <stop offset="70%" stop-color="#FDFBF7" />
          <stop offset="100%" stop-color="#F4ECE1" />
        </radialGradient>

        <!-- Drop shadow for the outer medallion -->
        <filter id="shadow" x="-10%" y="-10%" width="125%" height="125%">
          <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#3E2723" flood-opacity="0.18" />
        </filter>
      </defs>

      <!-- Transparent background with centered circular medallion -->
      <g filter="url(#shadow)">
        <!-- Outer Outer Ring -->
        <circle cx="256" cy="256" r="236" fill="url(#goldBorder)" />
        <circle cx="256" cy="256" r="226" fill="#FFFFFF" />
        
        <!-- Intricate Geometric Inner Border -->
        <circle cx="256" cy="256" r="218" fill="url(#beigeRadial)" stroke="#C9A84C" stroke-width="4" />
        <circle cx="256" cy="256" r="206" fill="none" stroke="#C9A84C" stroke-width="2" stroke-dasharray="6 6" />
      </g>

      <!-- Unique Vector Theme Graphic -->
      <g id="iconGraphic">
        ${vectorGraphic}
      </g>

      <!-- Subtle Golden Bottom Arc Finial -->
      <path d="M 216 450 Q 256 462 296 450" fill="none" stroke="#C9A84C" stroke-width="4" stroke-linecap="round" />
    </svg>
  `;
}

// All 132+ Icon names required
const iconNames = [
  'morning_evening',
  'sleep',
  'wakeup',
  'clothing',
  'new_clothes',
  'remove_clothes',
  'bathroom',
  'wudu',
  'after_wudu',
  'to_mosque',
  'enter_mosque',
  'exit_mosque',
  'adhan',
  'opening_prayer',
  'rukoo',
  'rising',
  'sujood',
  'between_sujood',
  'tilawah_sujood',
  'tashahhud',
  'after_tashahhud',
  'after_salam',
  'istikhara',
  'qunut',
  'witr',
  'distress',
  'calamity',
  'enemy',
  'protection',
  'fear',
  'whispers',
  'anger',
  'evil_eye',
  'travel',
  'return_travel',
  'entering_village',
  'market',
  'animal',
  'riding',
  'traveler_resident',
  'ascending',
  'airplane',
  'enter_home',
  'exit_home',
  'before_food',
  'after_food',
  'guest',
  'fasting_break',
  'crescent',
  'laylat_alqadr',
  'itikaf',
  'marriage',
  'intimacy',
  'sick',
  'visiting_sick',
  'death',
  'funeral',
  'condolences',
  'grave',
  'wind',
  'thunder',
  'rain',
  'rain_stop',
  'asking_rain',
  'friday',
  'shopping',
  'work',
  'walking',
  'eating',
  'drinking',
  'sneezing',
  'yawning',
  'greeting',
  'handshake',
  'praising',
  'forgiveness',
  'dua',
  'quran_recitation',
  'knowledge',
  'patience',
  'gratitude',
  'repentance',
  'dhikr',
  'tasbeeh',
  'takbir',
  'tahleel',
  'hamd',
  'salah_nabi',
  'hajj',
  'umrah',
  'eid_fitr',
  'eid_adha',
  'ramadan',
  'muharram',
  'ashura',
  'arafah',
  'new_year',
  'mawlid',
  'isra_meraj',
  'hijab',
  'zakat',
  'sadaqah',
  'kindness',
  'family',
  'parents',
  'children',
  'neighbors',
  'guests',
  'orphans',
  'poor',
  'wealth',
  'time',
  'health',
  'sleep_2',
  'dreams',
  'whispers_2',
  'protection_2',
  'shifa',
  'raqyah',
  'evil',
  'magic',
  'envy',
  'death_2',
  'barzakh',
  'day_judgment',
  'jannah',
  'jahannam',
  'angels',
  'prophets',
  'companions',
  'companions_wives',
  'scholars',
  'hafiz',
  'mosque_2',
  'kaaba',
  'madinah',
  'aqsa',
  'prayer_beads',
  'default'
];

async function generateAllIcons() {
  console.log(`Starting generation of ${iconNames.length} Hisn Al-Muslim PNG icons...`);
  let count = 0;

  for (const name of iconNames) {
    const svgStr = buildSvgForIcon(name);
    const buffer = Buffer.from(svgStr);

    const pngBuffer = await sharp(buffer)
      .resize(512, 512)
      .png({ quality: 95, compressionLevel: 8 })
      .toBuffer();

    for (const dir of targetDirs) {
      const filePath = path.join(dir, `${name}.png`);
      fs.writeFileSync(filePath, pngBuffer);
    }

    count++;
    if (count % 25 === 0 || count === iconNames.length) {
      console.log(`Generated ${count}/${iconNames.length} icons`);
    }
  }

  console.log(`Successfully generated all ${count} PNG icons in public/assets/hisn_almuslim/icons/`);
}

generateAllIcons().catch(err => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
