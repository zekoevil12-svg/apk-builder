import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Animated, Dimensions, ImageBackground, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useApp } from '@/context/AppContext';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { getDailyWisdom } from '@/data/quran';
import colors from '@/constants/colors';

const { width } = Dimensions.get('window');
const C = colors.light;

const bgImages: Record<string, any> = {
  bg1: require('@/assets/images/bg1.jpg'),
  bg2: require('@/assets/images/bg2.jpg'),
};

const features = [
  { route: '/quran', icon: '📖', titleAr: 'القرآن الكريم', titleEn: 'Holy Quran', color: C.quranColor, bg: '#E8F0F8' },
  { route: '/journal', icon: '📝', titleAr: 'يومياتي', titleEn: 'My Journal', color: C.journalColor, bg: '#EDE8F8' },
  { route: '/drawing', icon: '🎨', titleAr: 'لوحة الرسم', titleEn: 'Drawing Board', color: C.drawingColor, bg: '#F8EBE8' },
  { route: '/ai-chat', icon: '✨', titleAr: 'رفيق السكينة', titleEn: 'AI Companion', color: C.aiColor, bg: '#E8F5EE' },
];

export default function HomeScreen() {
  const router = useRouter();
  const { background, isConnected, t } = useApp();
  const wisdom = getDailyWisdom();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 900, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 700, useNativeDriver: true }),
    ]).start();

    // Gentle offline pulse on indicator
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 1800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (isConnected) {
      router.replace('/gate');
    }
  }, [isConnected]);

  const Content = () => (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <Animated.View style={[styles.container, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>

        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.settingsBtn} onPress={() => router.push('/settings')}>
            <Text style={styles.settingsIcon}>⚙</Text>
          </TouchableOpacity>
          <View style={styles.headerCenter}>
            <Text style={styles.crescent}>☽</Text>
            <Text style={styles.appTitle}>السكينة</Text>
          </View>
          <Animated.View style={[styles.offlineDot, { transform: [{ scale: pulseAnim }] }]}>
            <View style={styles.offlineDotInner} />
          </Animated.View>
        </View>

        {/* Date */}
        <Text style={styles.dateText}>
          {new Date().toLocaleDateString('ar-SA', { weekday: 'long', day: 'numeric', month: 'long' })}
        </Text>

        {/* Daily Wisdom Card */}
        <View style={styles.wisdomCard}>
          <View style={styles.wisdomTop}>
            <Text style={styles.wisdomLabel}>{t('آية اليوم', 'Verse of the Day')}</Text>
          </View>
          <Text style={styles.wisdomAyah}>{wisdom.arabic}</Text>
          <View style={styles.wisdomDivider} />
          <Text style={styles.wisdomSource}>{wisdom.source}</Text>
        </View>

        {/* Feature Grid */}
        <Text style={styles.sectionTitle}>{t('أدوات السكينة', 'Serenity Tools')}</Text>
        <View style={styles.grid}>
          {features.map((f) => (
            <TouchableOpacity
              key={f.route}
              style={styles.featureCard}
              onPress={() => router.push(f.route as any)}
              activeOpacity={0.75}
            >
              <LinearGradient
                colors={[f.bg, '#FFFFFF']}
                style={styles.featureGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Text style={styles.featureIcon}>{f.icon}</Text>
                <Text style={[styles.featureTitle, { color: f.color }]}>
                  {t(f.titleAr, f.titleEn)}
                </Text>
                <View style={[styles.featureAccent, { backgroundColor: f.color }]} />
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>

        {/* Offline Badge */}
        <View style={styles.offlineBadge}>
          <View style={styles.offlineDotSmall} />
          <Text style={styles.offlineBadgeText}>{t('وضع الطيران مفعّل', 'Airplane Mode On')}</Text>
        </View>

      </Animated.View>
    </SafeAreaView>
  );

  if (background !== 'none' && bgImages[background]) {
    return (
      <ImageBackground source={bgImages[background]} style={styles.bgImage} imageStyle={{ opacity: 0.18 }}>
        <Content />
      </ImageBackground>
    );
  }

  return <Content />;
}

const CARD_W = (width - 48 - 12) / 2;

const styles = StyleSheet.create({
  bgImage: { flex: 1, backgroundColor: C.bg },
  safe: { flex: 1, backgroundColor: 'transparent' },
  container: { flex: 1, paddingHorizontal: 20 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
    marginBottom: 4,
  },
  settingsBtn: { padding: 8 },
  settingsIcon: { fontSize: 20, color: C.textMuted },
  headerCenter: { alignItems: 'center' },
  crescent: { fontSize: 22, color: C.gold, marginBottom: -4 },
  appTitle: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 32,
    color: C.textPrimary,
    letterSpacing: 1,
  },
  offlineDot: {
    width: 24, height: 24,
    borderRadius: 12,
    backgroundColor: '#E8F5EE',
    justifyContent: 'center',
    alignItems: 'center',
  },
  offlineDotInner: {
    width: 10, height: 10,
    borderRadius: 5,
    backgroundColor: C.emerald,
  },

  dateText: {
    textAlign: 'center',
    fontFamily: 'Amiri_400Regular',
    fontSize: 14,
    color: C.textMuted,
    marginBottom: 20,
  },

  wisdomCard: {
    backgroundColor: C.bgCard,
    borderRadius: colors.radius.lg,
    padding: 22,
    marginBottom: 28,
    borderWidth: 1,
    borderColor: C.borderLight,
    shadowColor: C.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 4,
  },
  wisdomTop: { flexDirection: 'row', justifyContent: 'center', marginBottom: 14 },
  wisdomLabel: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 12,
    color: C.gold,
    backgroundColor: C.goldSurface,
    paddingHorizontal: 14,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.goldMuted,
  },
  wisdomAyah: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 22,
    color: C.textPrimary,
    textAlign: 'center',
    lineHeight: 42,
    writingDirection: 'rtl',
  },
  wisdomDivider: {
    height: 1,
    backgroundColor: C.borderLight,
    marginVertical: 14,
    marginHorizontal: 20,
  },
  wisdomSource: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 13,
    color: C.textMuted,
    textAlign: 'center',
  },

  sectionTitle: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 18,
    color: C.textSecondary,
    textAlign: 'right',
    marginBottom: 14,
  },

  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
    marginBottom: 24,
  },
  featureCard: {
    width: CARD_W,
    borderRadius: colors.radius.md,
    overflow: 'hidden',
    shadowColor: C.shadow,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 3,
  },
  featureGradient: {
    paddingVertical: 24,
    paddingHorizontal: 16,
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: C.borderLight,
    borderRadius: colors.radius.md,
  },
  featureIcon: { fontSize: 32 },
  featureTitle: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 16,
    textAlign: 'center',
  },
  featureAccent: {
    width: 28,
    height: 3,
    borderRadius: 2,
    opacity: 0.6,
    marginTop: 4,
  },

  offlineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: '#E8F5EE',
    borderRadius: colors.radius.full,
    alignSelf: 'center',
  },
  offlineDotSmall: {
    width: 6, height: 6,
    borderRadius: 3,
    backgroundColor: C.emerald,
  },
  offlineBadgeText: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 13,
    color: C.emerald,
  },
});
