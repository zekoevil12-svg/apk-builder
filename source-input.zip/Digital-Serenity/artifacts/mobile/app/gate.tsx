import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, Dimensions, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const { width, height } = Dimensions.get('window');
const C = colors.light;

export default function GateScreen() {
  const router = useRouter();
  const { isConnected, recheckNetwork } = useApp();
  const [checking, setChecking] = useState(false);
  const [step, setStep] = useState(0);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.85)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const ring1Anim = useRef(new Animated.Value(0)).current;
  const ring2Anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();

    // Pulsing rings
    const pulse = () => {
      ring1Anim.setValue(0);
      ring2Anim.setValue(0);
      Animated.parallel([
        Animated.timing(ring1Anim, { toValue: 1, duration: 2000, useNativeDriver: true }),
        Animated.sequence([
          Animated.delay(500),
          Animated.timing(ring2Anim, { toValue: 1, duration: 2000, useNativeDriver: true }),
        ]),
      ]).start(pulse);
    };
    pulse();

    // Slow crescent rotation
    Animated.loop(
      Animated.timing(rotateAnim, { toValue: 1, duration: 20000, useNativeDriver: true })
    ).start();

    const interval = setInterval(() => {
      setStep(s => (s + 1) % 3);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!isConnected) {
      router.replace('/(tabs)');
    }
  }, [isConnected]);

  const handleCheck = async () => {
    setChecking(true);
    const connected = await recheckNetwork();
    setChecking(false);
    if (!connected) router.replace('/(tabs)');
  };

  const ring1Scale = ring1Anim.interpolate({ inputRange: [0, 1], outputRange: [1, 2.2] });
  const ring1Opacity = ring1Anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.4, 0.15, 0] });
  const ring2Scale = ring2Anim.interpolate({ inputRange: [0, 1], outputRange: [1, 2.8] });
  const ring2Opacity = ring2Anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.3, 0.1, 0] });
  const rotate = rotateAnim.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  const steps = [
    { icon: '✈', text: 'فعّل وضع الطيران من الإعدادات' },
    { icon: '📵', text: 'أغلق الواي فاي والبيانات' },
    { icon: '🌙', text: 'عُد لتدخل عالم السكينة' },
  ];

  return (
    <LinearGradient colors={['#FEFCF8', '#F5EFE2', '#EDE4D0']} style={styles.gradient}>
      <SafeAreaView style={styles.safe}>
        <Animated.View style={[styles.container, { opacity: fadeAnim }]}>

          {/* Pulsing Rings */}
          <View style={styles.ringContainer}>
            <Animated.View style={[styles.ring, { transform: [{ scale: ring1Scale }], opacity: ring1Opacity }]} />
            <Animated.View style={[styles.ring2, { transform: [{ scale: ring2Scale }], opacity: ring2Opacity }]} />

            {/* Crescent */}
            <Animated.View style={[styles.crescentContainer, { transform: [{ rotate }] }]}>
              <Text style={styles.crescentIcon}>☽</Text>
            </Animated.View>
          </View>

          {/* Title */}
          <Text style={styles.title}>السكينة</Text>
          <Text style={styles.subtitle}>عالم من الهدوء بانتظارك</Text>

          {/* Divider with Arabic decoration */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerDecor}>✦</Text>
            <View style={styles.dividerLine} />
          </View>

          {/* Message */}
          <View style={styles.messageBox}>
            <Text style={styles.messageTitle}>أنت متصل بالإنترنت</Text>
            <Text style={styles.messageBody}>
              السكينة تعمل في وضع العزلة الرقمية الكاملة{'\n'}
              يرجى إيقاف الاتصال للدخول
            </Text>
          </View>

          {/* Steps */}
          <View style={styles.stepsContainer}>
            {steps.map((s, i) => (
              <Animated.View
                key={i}
                style={[
                  styles.stepRow,
                  { opacity: step === i ? 1 : 0.35, transform: [{ scale: step === i ? 1 : 0.96 }] }
                ]}
              >
                <Text style={styles.stepIcon}>{s.icon}</Text>
                <Text style={styles.stepText}>{s.text}</Text>
                {step === i && <View style={styles.stepActiveDot} />}
              </Animated.View>
            ))}
          </View>

          {/* CTA Button */}
          <TouchableOpacity
            style={[styles.btn, checking && styles.btnChecking]}
            onPress={handleCheck}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={checking ? ['#B8A080', '#A09070'] : ['#C09434', '#8B6A1A']}
              style={styles.btnGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
            >
              <Text style={styles.btnText}>
                {checking ? 'جاري التحقق...' : 'تحقق من الاتصال'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>

          <Text style={styles.hint}>
            سيتم الدخول تلقائياً عند إيقاف الاتصال
          </Text>

          {/* Download Quran while online */}
          <TouchableOpacity style={styles.downloadLink} onPress={() => router.push('/quran-download')}>
            <Text style={styles.downloadLinkIcon}>⬇</Text>
            <Text style={styles.downloadLinkText}>حمّل القرآن للاستماع أوفلاين</Text>
          </TouchableOpacity>

        </Animated.View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  safe: { flex: 1 },
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },

  ringContainer: { width: 140, height: 140, alignItems: 'center', justifyContent: 'center', marginBottom: 32 },
  ring: {
    position: 'absolute',
    width: 100, height: 100, borderRadius: 50,
    borderWidth: 1.5, borderColor: C.gold,
  },
  ring2: {
    position: 'absolute',
    width: 100, height: 100, borderRadius: 50,
    borderWidth: 1, borderColor: C.goldDark,
  },
  crescentContainer: { width: 100, height: 100, alignItems: 'center', justifyContent: 'center' },
  crescentIcon: { fontSize: 64, color: C.gold },

  title: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 44,
    color: C.textPrimary,
    textAlign: 'center',
    marginBottom: 6,
  },
  subtitle: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 17,
    color: C.textMuted,
    textAlign: 'center',
    marginBottom: 28,
  },

  divider: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 28, width: '70%' },
  dividerLine: { flex: 1, height: 0.8, backgroundColor: C.goldMuted },
  dividerDecor: { color: C.gold, fontSize: 14 },

  messageBox: {
    backgroundColor: 'rgba(255,255,255,0.75)',
    borderRadius: colors.radius.lg,
    padding: 20,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: C.borderLight,
    width: '100%',
  },
  messageTitle: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 18,
    color: C.accent,
    marginBottom: 8,
    textAlign: 'center',
  },
  messageBody: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 15,
    color: C.textSecondary,
    textAlign: 'center',
    lineHeight: 26,
  },

  stepsContainer: { width: '100%', gap: 10, marginBottom: 28 },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: 'rgba(255,255,255,0.6)',
    padding: 14,
    borderRadius: colors.radius.md,
    borderWidth: 1,
    borderColor: C.borderLight,
  },
  stepIcon: { fontSize: 22 },
  stepText: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 15,
    color: C.textPrimary,
    flex: 1,
  },
  stepActiveDot: {
    width: 8, height: 8, borderRadius: 4,
    backgroundColor: C.gold,
  },

  btn: { width: '100%', borderRadius: colors.radius.full, overflow: 'hidden', marginBottom: 14 },
  btnChecking: { opacity: 0.75 },
  btnGradient: { paddingVertical: 16, alignItems: 'center', borderRadius: colors.radius.full },
  btnText: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 18,
    color: '#FFFDF8',
    letterSpacing: 0.5,
  },

  hint: {
    fontFamily: 'Amiri_400Regular',
    fontSize: 13,
    color: C.textLight,
    textAlign: 'center',
  },
  downloadLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 16,
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.65)',
    borderRadius: colors.radius.full,
    borderWidth: 1,
    borderColor: C.borderLight,
  },
  downloadLinkIcon: { fontSize: 18, color: C.quranColor },
  downloadLinkText: {
    fontFamily: 'Amiri_700Bold',
    fontSize: 15,
    color: C.quranColor,
  },
});
