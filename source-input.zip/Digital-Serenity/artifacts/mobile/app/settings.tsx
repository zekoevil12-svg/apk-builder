import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Switch, Linking, Alert, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;

const bgOptions = [
  { id: 'none', label: 'بدون', labelEn: 'None', preview: '#F9F6EF' },
  { id: 'bg1', label: 'رقّة', labelEn: 'Parchment', preview: '#E8D8B0' },
  { id: 'bg2', label: 'عتيق', labelEn: 'Manuscript', preview: '#C8A870' },
];

export default function SettingsScreen() {
  const router = useRouter();
  const { language, setLanguage, background, setBackground, t } = useApp();
  const [dndGuideShown, setDndGuideShown] = useState(false);

  const openDNDSettings = () => {
    if (Platform.OS === 'android') {
      Linking.openSettings();
    } else {
      Linking.openURL('App-Prefs:NOTIFICATIONS_ID');
    }
  };

  const showDNDGuide = () => {
    Alert.alert(
      t('إيقاف الإشعارات', 'Silence Notifications'),
      Platform.OS === 'android'
        ? t(
            'لإيقاف جميع الإشعارات:\n\n١. اسحب من أعلى الشاشة\n٢. اضغط على "عدم الإزعاج" أو "Do Not Disturb"\n٣. فعّل الوضع\n\nأو يمكنك فتح الإعدادات مباشرةً.',
            'To silence all notifications:\n\n1. Pull down from top\n2. Tap "Do Not Disturb"\n3. Enable it\n\nOr open Settings directly.'
          )
        : t(
            'لإيقاف الإشعارات على iOS:\n\n١. افتح الإعدادات\n٢. اضغط على "التركيز"\n٣. اختر "عدم الإزعاج"\n٤. فعّل الوضع',
            'To silence on iOS:\n\n1. Open Settings\n2. Tap "Focus"\n3. Choose "Do Not Disturb"\n4. Enable it'
          ),
      [
        { text: t('إلغاء', 'Cancel'), style: 'cancel' },
        { text: t('فتح الإعدادات', 'Open Settings'), onPress: openDNDSettings },
      ]
    );
    setDndGuideShown(true);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      {/* Header */}
      <LinearGradient colors={['#2C1B0E', '#1A100A']} style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backIcon}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{t('الإعدادات', 'Settings')}</Text>
        <View style={{ width: 40 }} />
      </LinearGradient>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Language */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>{t('اللغة', 'Language')}</Text>
          <View style={styles.card}>
            <View style={styles.langRow}>
              <TouchableOpacity
                style={[styles.langBtn, language === 'ar' && styles.langBtnActive]}
                onPress={() => setLanguage('ar')}
              >
                <Text style={[styles.langBtnText, language === 'ar' && styles.langBtnTextActive]}>العربية</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.langBtn, language === 'en' && styles.langBtnActive]}
                onPress={() => setLanguage('en')}
              >
                <Text style={[styles.langBtnText, language === 'en' && styles.langBtnTextActive]}>English</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Background */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>{t('خلفية التطبيق', 'App Background')}</Text>
          <View style={styles.card}>
            <View style={styles.bgRow}>
              {bgOptions.map((bg) => (
                <TouchableOpacity
                  key={bg.id}
                  style={[styles.bgCard, background === bg.id && styles.bgCardActive]}
                  onPress={() => setBackground(bg.id as any)}
                >
                  <View style={[styles.bgSwatch, { backgroundColor: bg.preview }]} />
                  <Text style={[styles.bgLabel, background === bg.id && styles.bgLabelActive]}>
                    {t(bg.label, bg.labelEn)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* DND / Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>{t('راحة رقمية', 'Digital Rest')}</Text>
          <View style={styles.card}>
            <TouchableOpacity style={styles.dndRow} onPress={showDNDGuide}>
              <View style={styles.dndLeft}>
                <Text style={styles.dndIcon}>🔕</Text>
                <View>
                  <Text style={styles.dndTitle}>{t('إيقاف الإشعارات', 'Silence Notifications')}</Text>
                  <Text style={styles.dndSubtitle}>
                    {t('فعّل وضع عدم الإزعاج للتركيز الكامل', 'Enable Do Not Disturb for full focus')}
                  </Text>
                </View>
              </View>
              <Text style={styles.dndChevron}>›</Text>
            </TouchableOpacity>

            <View style={styles.divider} />

            <TouchableOpacity style={styles.dndRow} onPress={openDNDSettings}>
              <View style={styles.dndLeft}>
                <Text style={styles.dndIcon}>⚙️</Text>
                <View>
                  <Text style={styles.dndTitle}>{t('إعدادات الجهاز', 'Device Settings')}</Text>
                  <Text style={styles.dndSubtitle}>{t('فتح إعدادات الإشعارات', 'Open notification settings')}</Text>
                </View>
              </View>
              <Text style={styles.dndChevron}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>{t('عن التطبيق', 'About')}</Text>
          <View style={styles.card}>
            <View style={styles.aboutBox}>
              <Text style={styles.aboutCrescent}>☽</Text>
              <Text style={styles.aboutTitle}>السكينة</Text>
              <Text style={styles.aboutSubtitle}>Al-Sakeena · v2.0</Text>
              <View style={styles.aboutDivider} />
              <Text style={styles.aboutDesc}>
                {t(
                  'تطبيق يعمل بالكامل بدون إنترنت\nللقراءة والتأمل والتدبّر\nفي أوقات الهدوء الرقمي',
                  'A fully offline app for reading,\nreflection, and mindfulness\nduring digital serenity'
                )}
              </Text>
              <View style={styles.tagRow}>
                {['Offline-First', 'القرآن الكريم', 'اليوميات', 'الرسم'].map((tag) => (
                  <View key={tag} style={styles.tag}>
                    <Text style={styles.tagText}>{tag}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  backIcon: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  headerTitle: { fontFamily: 'Amiri_700Bold', fontSize: 22, color: '#FFFDF8' },

  scroll: { flex: 1 },
  section: { padding: 16, paddingBottom: 0 },
  sectionHeader: {
    fontFamily: 'Amiri_700Bold', fontSize: 14, color: C.textMuted,
    textAlign: 'right', marginBottom: 10,
    paddingHorizontal: 4,
  },
  card: {
    backgroundColor: C.bgCard, borderRadius: colors.radius.md,
    borderWidth: 1, borderColor: C.borderLight,
    shadowColor: C.shadow, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1, shadowRadius: 6, elevation: 2,
    overflow: 'hidden',
  },

  langRow: { flexDirection: 'row', padding: 8, gap: 8 },
  langBtn: {
    flex: 1, paddingVertical: 12, borderRadius: colors.radius.sm,
    backgroundColor: C.bgAlt, alignItems: 'center',
    borderWidth: 1, borderColor: 'transparent',
  },
  langBtnActive: { backgroundColor: '#F5EED8', borderColor: C.gold },
  langBtnText: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: C.textSecondary },
  langBtnTextActive: { color: C.goldDark },

  bgRow: { flexDirection: 'row', padding: 12, gap: 10 },
  bgCard: {
    flex: 1, alignItems: 'center', gap: 8,
    padding: 12, borderRadius: colors.radius.sm,
    borderWidth: 1.5, borderColor: 'transparent',
    backgroundColor: C.bgAlt,
  },
  bgCardActive: { borderColor: C.gold, backgroundColor: C.goldSurface },
  bgSwatch: { width: 44, height: 44, borderRadius: 22, borderWidth: 1, borderColor: C.borderLight },
  bgLabel: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textSecondary },
  bgLabelActive: { color: C.goldDark, fontFamily: 'Amiri_700Bold' },

  dndRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 16,
  },
  dndLeft: { flexDirection: 'row', alignItems: 'center', gap: 14, flex: 1 },
  dndIcon: { fontSize: 28 },
  dndTitle: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: C.textPrimary, textAlign: 'right' },
  dndSubtitle: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textMuted, marginTop: 2, textAlign: 'right' },
  dndChevron: { fontSize: 22, color: C.textLight },
  divider: { height: 1, backgroundColor: C.borderLight, marginHorizontal: 16 },

  aboutBox: { padding: 24, alignItems: 'center', gap: 8 },
  aboutCrescent: { fontSize: 42, color: C.gold },
  aboutTitle: { fontFamily: 'Amiri_700Bold', fontSize: 30, color: C.textPrimary },
  aboutSubtitle: { fontFamily: 'LibreBaskerville_400Regular', fontSize: 13, color: C.textMuted },
  aboutDivider: { width: 40, height: 1, backgroundColor: C.goldMuted, marginVertical: 4 },
  aboutDesc: {
    fontFamily: 'Amiri_400Regular', fontSize: 15, color: C.textSecondary,
    textAlign: 'center', lineHeight: 26,
  },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center', marginTop: 4 },
  tag: {
    paddingHorizontal: 12, paddingVertical: 4,
    backgroundColor: C.goldSurface, borderRadius: colors.radius.full,
    borderWidth: 1, borderColor: C.goldMuted,
  },
  tagText: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.goldDark },
});
