import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { createJournal, updateJournal, getJournal } from '@/data/db';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;

const fonts = [
  { id: 'amiri', label: 'أميري', fontFamily: 'Amiri_400Regular' },
  { id: 'amiri-bold', label: 'أميري عريض', fontFamily: 'Amiri_700Bold' },
  { id: 'baskerville', label: 'Baskerville', fontFamily: 'LibreBaskerville_400Regular' },
  { id: 'baskerville-bold', label: 'Baskerville Bold', fontFamily: 'LibreBaskerville_700Bold' },
  { id: 'baskerville-italic', label: 'Baskerville Italic', fontFamily: 'LibreBaskerville_400Italic' },
];

const moods = [
  { id: 'happy', icon: '😊', label: 'سعيد' },
  { id: 'calm', icon: '😌', label: 'هادئ' },
  { id: 'grateful', icon: '🙏', label: 'ممتن' },
  { id: 'hopeful', icon: '✨', label: 'متفائل' },
  { id: 'sad', icon: '😢', label: 'حزين' },
  { id: 'anxious', icon: '😰', label: 'قلق' },
];

export default function JournalEditorScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { t } = useApp();
  const isEditing = !!id;

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedFont, setSelectedFont] = useState('amiri');
  const [selectedMood, setSelectedMood] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [saved, setSaved] = useState(false);
  const contentRef = useRef<TextInput>(null);

  useEffect(() => {
    if (isEditing && id) {
      const entry = getJournal(Number(id));
      if (entry) {
        setTitle(entry.title);
        setContent(entry.content);
        setSelectedFont(entry.font);
        setSelectedMood(entry.mood);
        setWordCount(entry.content.split(' ').filter(Boolean).length);
      }
    }
  }, [id]);

  useEffect(() => {
    setWordCount(content.split(' ').filter(Boolean).length);
  }, [content]);

  const handleSave = () => {
    if (!title.trim() && !content.trim()) {
      Alert.alert(t('تنبيه', 'Notice'), t('الرجاء كتابة شيء أولاً', 'Please write something first'));
      return;
    }
    const titleToSave = title.trim() || t('بدون عنوان', 'Untitled');
    if (isEditing && id) {
      updateJournal(Number(id), titleToSave, content, selectedFont, selectedMood);
    } else {
      createJournal(titleToSave, content, selectedFont, selectedMood);
    }
    setSaved(true);
    setTimeout(() => router.back(), 500);
  };

  const currentFont = fonts.find(f => f.id === selectedFont);

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        {/* Header */}
        <LinearGradient colors={['#4A2E6B', '#371F52']} style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.headerBtn}>
            <Text style={styles.headerBtnText}>{t('إلغاء', 'Cancel')}</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>
            {isEditing ? t('تعديل', 'Edit') : t('مذكرة جديدة', 'New Entry')}
          </Text>
          <TouchableOpacity onPress={handleSave} style={styles.saveBtn}>
            <Text style={styles.saveBtnText}>{saved ? '✓' : t('حفظ', 'Save')}</Text>
          </TouchableOpacity>
        </LinearGradient>

        <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {/* Mood Picker */}
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{t('حالتك الآن', 'Your mood')}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.moodRow}>
              {moods.map((m) => (
                <TouchableOpacity
                  key={m.id}
                  style={[styles.moodChip, selectedMood === m.id && styles.moodChipActive]}
                  onPress={() => setSelectedMood(selectedMood === m.id ? '' : m.id)}
                >
                  <Text style={styles.moodChipIcon}>{m.icon}</Text>
                  <Text style={[styles.moodChipLabel, selectedMood === m.id && styles.moodChipLabelActive]}>
                    {m.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Title */}
          <View style={styles.titleContainer}>
            <TextInput
              style={styles.titleInput}
              placeholder={t('عنوان المذكرة...', 'Entry title...')}
              placeholderTextColor={C.textLight}
              value={title}
              onChangeText={setTitle}
              textAlign="right"
              returnKeyType="next"
              onSubmitEditing={() => contentRef.current?.focus()}
              maxLength={80}
            />
          </View>

          {/* Date Line */}
          <Text style={styles.dateLine}>
            {new Date().toLocaleDateString('ar-SA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </Text>

          {/* Content */}
          <TextInput
            ref={contentRef}
            style={[styles.contentInput, { fontFamily: currentFont?.fontFamily || 'Amiri_400Regular' }]}
            placeholder={t('اكتب ما يدور في قلبك...', 'Write what\'s on your heart...')}
            placeholderTextColor={C.textLight}
            value={content}
            onChangeText={setContent}
            multiline
            textAlign="right"
            textAlignVertical="top"
            autoCapitalize="sentences"
          />

          {/* Font Picker */}
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>{t('الخط', 'Font')}</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.fontRow}>
              {fonts.map((f) => (
                <TouchableOpacity
                  key={f.id}
                  style={[styles.fontChip, selectedFont === f.id && styles.fontChipActive]}
                  onPress={() => setSelectedFont(f.id)}
                >
                  <Text style={[styles.fontChipText, { fontFamily: f.fontFamily }, selectedFont === f.id && styles.fontChipTextActive]}>
                    {f.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Word Count */}
          <View style={styles.stats}>
            <Text style={styles.statsText}>
              {wordCount} {t('كلمة', 'words')} · {content.length} {t('حرف', 'chars')}
            </Text>
          </View>

          <View style={{ height: 60 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
  },
  headerBtn: { paddingHorizontal: 8, paddingVertical: 4 },
  headerBtnText: { fontFamily: 'Amiri_400Regular', fontSize: 16, color: 'rgba(255,253,248,0.8)' },
  headerTitle: { fontFamily: 'Amiri_700Bold', fontSize: 18, color: '#FFFDF8' },
  saveBtn: { paddingHorizontal: 16, paddingVertical: 6, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 20 },
  saveBtnText: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: '#FFFDF8' },

  scroll: { flex: 1 },

  section: { paddingHorizontal: 16, paddingTop: 16 },
  sectionLabel: { fontFamily: 'Amiri_700Bold', fontSize: 14, color: C.textMuted, marginBottom: 10, textAlign: 'right' },

  moodRow: { flexDirection: 'row' },
  moodChip: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 8,
    backgroundColor: C.bgCard, borderRadius: colors.radius.full,
    borderWidth: 1, borderColor: C.borderLight,
    marginRight: 8,
  },
  moodChipActive: { backgroundColor: '#EDE8F8', borderColor: '#7B5EA8' },
  moodChipIcon: { fontSize: 18 },
  moodChipLabel: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: C.textSecondary },
  moodChipLabelActive: { color: '#4A2E6B' },

  titleContainer: {
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 4,
    borderBottomWidth: 1, borderBottomColor: C.borderLight,
  },
  titleInput: {
    fontFamily: 'Amiri_700Bold', fontSize: 26,
    color: C.textPrimary, minHeight: 40,
  },

  dateLine: {
    fontFamily: 'Amiri_400Regular', fontSize: 13,
    color: C.textLight, textAlign: 'right',
    paddingHorizontal: 20, paddingVertical: 8,
  },

  contentInput: {
    fontSize: 18, color: C.textPrimary,
    paddingHorizontal: 20, paddingTop: 8,
    minHeight: 300, lineHeight: 34,
  },

  fontRow: { flexDirection: 'row' },
  fontChip: {
    paddingHorizontal: 16, paddingVertical: 8,
    backgroundColor: C.bgCard, borderRadius: colors.radius.full,
    borderWidth: 1, borderColor: C.borderLight, marginRight: 8,
  },
  fontChipActive: { backgroundColor: '#EDE8F8', borderColor: '#7B5EA8' },
  fontChipText: { fontSize: 14, color: C.textSecondary },
  fontChipTextActive: { color: '#4A2E6B' },

  stats: { paddingHorizontal: 20, paddingTop: 16, alignItems: 'flex-end' },
  statsText: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textLight },
});
