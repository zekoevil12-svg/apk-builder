import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, PanResponder,
  Dimensions, Alert, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Svg, { Path, Rect } from 'react-native-svg';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;
const { width: W, height: H } = Dimensions.get('window');

interface StrokePath {
  d: string;
  color: string;
  width: number;
}

const palette = [
  { color: '#1C1008', label: 'عتيق' },
  { color: '#8B6A1A', label: 'ذهبي' },
  { color: '#7B3520', label: 'طيني' },
  { color: '#1E4D6B', label: 'نيلي' },
  { color: '#2E6B50', label: 'زمردي' },
  { color: '#6B2E6B', label: 'أرجواني' },
  { color: '#8B8060', label: 'رمادي دافئ' },
  { color: '#C09434', label: 'ذهبي فاتح' },
  { color: '#4A1A1A', label: 'أحمر قانٍ' },
  { color: '#F9F6EF', label: 'أبيض' },
];

const strokeWidths = [2, 4, 7, 12, 20];
const bgOptions = ['#F9F6EF', '#1C1008', '#EDE4CC', '#1E3A2E', '#1A1A3A'];

export default function DrawingScreen() {
  const router = useRouter();
  const { t } = useApp();
  const [paths, setPaths] = useState<StrokePath[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [color, setColor] = useState('#1C1008');
  const [strokeWidth, setStrokeWidth] = useState(4);
  const [bgColor, setBgColor] = useState('#F9F6EF');
  const [showPalette, setShowPalette] = useState(true);
  const canvasRef = useRef<View>(null);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => {
        const { locationX, locationY } = evt.nativeEvent;
        setCurrentPath(`M${locationX.toFixed(1)},${locationY.toFixed(1)}`);
      },
      onPanResponderMove: (evt) => {
        const { locationX, locationY } = evt.nativeEvent;
        setCurrentPath((prev) => `${prev} L${locationX.toFixed(1)},${locationY.toFixed(1)}`);
      },
      onPanResponderRelease: () => {
        setCurrentPath((prev) => {
          if (prev) {
            setPaths((ps) => [...ps, { d: prev, color, width: strokeWidth }]);
          }
          return '';
        });
      },
    })
  ).current;

  const undo = () => setPaths((ps) => ps.slice(0, -1));
  const clear = () => {
    Alert.alert(
      t('مسح اللوحة', 'Clear Canvas'),
      t('هل تريد مسح كل شيء؟', 'Clear everything?'),
      [
        { text: t('إلغاء', 'Cancel'), style: 'cancel' },
        { text: t('مسح', 'Clear'), style: 'destructive', onPress: () => setPaths([]) },
      ]
    );
  };

  const CANVAS_H = H - 260;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      {/* Header */}
      <LinearGradient colors={['#6B2E1E', '#4A1A0A']} style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backIcon}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{t('لوحة الرسم', 'Drawing Board')}</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.actionBtn} onPress={undo} disabled={paths.length === 0}>
            <Text style={[styles.actionIcon, paths.length === 0 && { opacity: 0.3 }]}>↩</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={clear} disabled={paths.length === 0}>
            <Text style={[styles.actionIcon, paths.length === 0 && { opacity: 0.3 }]}>🗑</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* Canvas */}
      <View ref={canvasRef} style={[styles.canvas, { height: CANVAS_H, backgroundColor: bgColor }]} {...panResponder.panHandlers}>
        <Svg width="100%" height="100%">
          {paths.map((p, i) => (
            <Path key={i} d={p.d} stroke={p.color} strokeWidth={p.width} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          ))}
          {currentPath ? (
            <Path d={currentPath} stroke={color} strokeWidth={strokeWidth} fill="none" strokeLinecap="round" strokeLinejoin="round" />
          ) : null}
        </Svg>

        {paths.length === 0 && (
          <View style={styles.canvasHint} pointerEvents="none">
            <Text style={[styles.canvasHintText, { color: bgColor === '#1C1008' ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.12)' }]}>
              {t('ارسم هنا بحرية', 'Draw freely here')}
            </Text>
          </View>
        )}
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        {/* Color Palette */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.paletteRow}>
          {palette.map((p) => (
            <TouchableOpacity
              key={p.color}
              style={[
                styles.colorDot,
                { backgroundColor: p.color },
                color === p.color && styles.colorDotActive,
                p.color === '#F9F6EF' && { borderWidth: 1.5, borderColor: C.borderLight },
              ]}
              onPress={() => setColor(p.color)}
            />
          ))}
        </ScrollView>

        {/* Stroke Width */}
        <View style={styles.strokeRow}>
          <Text style={styles.controlLabel}>{t('السُّمك', 'Size')}</Text>
          <View style={styles.strokeBtns}>
            {strokeWidths.map((sw) => (
              <TouchableOpacity
                key={sw}
                style={[styles.strokeBtn, strokeWidth === sw && styles.strokeBtnActive]}
                onPress={() => setStrokeWidth(sw)}
              >
                <View style={[styles.strokePreview, { width: Math.min(sw * 1.5, 22), height: Math.min(sw * 1.5, 22), borderRadius: sw, backgroundColor: color }]} />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Background */}
        <View style={styles.bgRow}>
          <Text style={styles.controlLabel}>{t('الخلفية', 'Background')}</Text>
          <View style={styles.bgBtns}>
            {bgOptions.map((bg) => (
              <TouchableOpacity
                key={bg}
                style={[
                  styles.bgDot,
                  { backgroundColor: bg },
                  bgColor === bg && styles.bgDotActive,
                  bg === '#F9F6EF' && { borderWidth: 1.5, borderColor: C.borderLight },
                ]}
                onPress={() => setBgColor(bg)}
              />
            ))}
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.textPrimary },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14, gap: 8,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  backIcon: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  headerTitle: { flex: 1, fontFamily: 'Amiri_700Bold', fontSize: 22, color: '#FFFDF8', textAlign: 'center' },
  headerActions: { flexDirection: 'row', gap: 4 },
  actionBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  actionIcon: { fontSize: 20, color: '#FFFDF8' },

  canvas: { width: '100%' },
  canvasHint: { position: 'absolute', top: '45%', left: 0, right: 0, alignItems: 'center' },
  canvasHintText: { fontFamily: 'Amiri_400Regular', fontSize: 18 },

  controls: {
    backgroundColor: '#FAF8F3', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8, gap: 12,
    borderTopWidth: 1, borderTopColor: C.borderLight,
  },
  paletteRow: { flexDirection: 'row' },
  colorDot: {
    width: 34, height: 34, borderRadius: 17, marginRight: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 3, elevation: 2,
  },
  colorDotActive: {
    borderWidth: 3, borderColor: C.gold,
    shadowColor: C.gold, shadowOpacity: 0.5, shadowRadius: 6, elevation: 4,
  },

  strokeRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  controlLabel: { fontFamily: 'Amiri_700Bold', fontSize: 13, color: C.textMuted, width: 48 },
  strokeBtns: { flexDirection: 'row', gap: 10, alignItems: 'center' },
  strokeBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: C.bgAlt, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: C.borderLight,
  },
  strokeBtnActive: { borderColor: C.gold, backgroundColor: C.goldSurface },
  strokePreview: {},

  bgRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  bgBtns: { flexDirection: 'row', gap: 10 },
  bgDot: {
    width: 28, height: 28, borderRadius: 14,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.15, shadowRadius: 2, elevation: 1,
  },
  bgDotActive: { borderWidth: 2.5, borderColor: C.gold },
});
