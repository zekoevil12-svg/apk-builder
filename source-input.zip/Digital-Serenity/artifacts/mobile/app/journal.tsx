import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  Alert, Animated,
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { getAllJournals, deleteJournal, JournalEntry } from '@/data/db';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;

const moodIcons: Record<string, string> = {
  happy: '😊', sad: '😢', calm: '😌',
  anxious: '😰', grateful: '🙏', hopeful: '✨', '': '📝',
};

export default function JournalScreen() {
  const router = useRouter();
  const { t } = useApp();
  const [entries, setEntries] = useState<JournalEntry[]>([]);

  useFocusEffect(
    useCallback(() => {
      setEntries(getAllJournals());
    }, [])
  );

  const handleDelete = (id: number, title: string) => {
    Alert.alert(
      t('حذف المذكرة', 'Delete Entry'),
      t(`هل تريد حذف "${title}"؟`, `Delete "${title}"?`),
      [
        { text: t('إلغاء', 'Cancel'), style: 'cancel' },
        {
          text: t('حذف', 'Delete'),
          style: 'destructive',
          onPress: () => {
            deleteJournal(id);
            setEntries(getAllJournals());
          },
        },
      ]
    );
  };

  const formatDate = (ts: number) => {
    return new Date(ts).toLocaleDateString('ar-SA', {
      weekday: 'short', day: 'numeric', month: 'short',
    });
  };

  const renderItem = ({ item, index }: { item: JournalEntry; index: number }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => router.push({ pathname: '/journal-editor', params: { id: item.id } })}
      onLongPress={() => handleDelete(item.id, item.title)}
      activeOpacity={0.75}
    >
      <View style={styles.cardTop}>
        <Text style={styles.moodIcon}>{moodIcons[item.mood] || '📝'}</Text>
        <View style={styles.cardInfo}>
          <Text style={styles.cardTitle} numberOfLines={1}>{item.title || t('بدون عنوان', 'Untitled')}</Text>
          <Text style={styles.cardDate}>{formatDate(item.updated_at)}</Text>
        </View>
      </View>
      {item.content ? (
        <Text style={styles.cardPreview} numberOfLines={2}>{item.content}</Text>
      ) : null}
      <View style={styles.cardFooter}>
        <Text style={styles.cardFont}>{item.font === 'amiri' ? 'أميري' : 'Baskerville'}</Text>
        <Text style={styles.cardWords}>
          {item.content?.split(' ').filter(Boolean).length || 0} {t('كلمة', 'words')}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <LinearGradient colors={['#4A2E6B', '#371F52']} style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backIcon}>‹</Text>
        </TouchableOpacity>
        <View style={styles.headerTitle}>
          <Text style={styles.headerTitleText}>{t('يومياتي', 'My Journal')}</Text>
          <Text style={styles.headerSubtitle}>{entries.length} {t('مذكرة', 'entries')}</Text>
        </View>
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => router.push('/journal-editor')}
        >
          <Text style={styles.addBtnText}>+</Text>
        </TouchableOpacity>
      </LinearGradient>

      {entries.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>📓</Text>
          <Text style={styles.emptyTitle}>{t('لا توجد مذكرات بعد', 'No entries yet')}</Text>
          <Text style={styles.emptySubtitle}>
            {t('ابدأ بكتابة أولى مذكراتك', 'Start writing your first entry')}
          </Text>
          <TouchableOpacity
            style={styles.emptyBtn}
            onPress={() => router.push('/journal-editor')}
          >
            <Text style={styles.emptyBtnText}>{t('مذكرة جديدة', 'New Entry')}</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={entries}
          keyExtractor={(e) => String(e.id)}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <Text style={styles.hint}>{t('اضغط مطولاً للحذف', 'Long press to delete')}</Text>
          }
        />
      )}

      {entries.length > 0 && (
        <TouchableOpacity style={styles.fab} onPress={() => router.push('/journal-editor')}>
          <LinearGradient colors={['#6B3FA0', '#4A2E6B']} style={styles.fabGradient}>
            <Text style={styles.fabIcon}>+</Text>
          </LinearGradient>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 14, gap: 8,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  backIcon: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  headerTitle: { flex: 1, alignItems: 'center' },
  headerTitleText: { fontFamily: 'Amiri_700Bold', fontSize: 22, color: '#FFFDF8' },
  headerSubtitle: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: 'rgba(255,253,248,0.7)', marginTop: 2 },
  addBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  addBtnText: { color: '#FFFDF8', fontSize: 24, lineHeight: 28 },

  list: { padding: 16, gap: 12, paddingBottom: 100 },
  hint: {
    fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textLight,
    textAlign: 'center', marginBottom: 8,
  },

  card: {
    backgroundColor: C.bgCard, borderRadius: colors.radius.md,
    padding: 16, gap: 10,
    borderWidth: 1, borderColor: C.borderLight,
    shadowColor: C.shadow, shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 1, shadowRadius: 8, elevation: 3,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  moodIcon: { fontSize: 28 },
  cardInfo: { flex: 1 },
  cardTitle: {
    fontFamily: 'Amiri_700Bold', fontSize: 18,
    color: C.textPrimary, textAlign: 'right',
  },
  cardDate: {
    fontFamily: 'Amiri_400Regular', fontSize: 12,
    color: C.textMuted, textAlign: 'right', marginTop: 2,
  },
  cardPreview: {
    fontFamily: 'Amiri_400Regular', fontSize: 15,
    color: C.textSecondary, textAlign: 'right', lineHeight: 26,
    paddingTop: 8, borderTopWidth: 1, borderTopColor: C.borderLight,
  },
  cardFooter: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingTop: 8, borderTopWidth: 1, borderTopColor: C.borderLight,
  },
  cardFont: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textLight },
  cardWords: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textLight },

  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, padding: 40 },
  emptyIcon: { fontSize: 64 },
  emptyTitle: { fontFamily: 'Amiri_700Bold', fontSize: 22, color: C.textSecondary, textAlign: 'center' },
  emptySubtitle: { fontFamily: 'Amiri_400Regular', fontSize: 15, color: C.textMuted, textAlign: 'center' },
  emptyBtn: {
    backgroundColor: '#4A2E6B', borderRadius: colors.radius.full,
    paddingHorizontal: 28, paddingVertical: 12, marginTop: 8,
  },
  emptyBtnText: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: '#FFFDF8' },

  fab: {
    position: 'absolute', bottom: 32, right: 24,
    borderRadius: 30, overflow: 'hidden',
    shadowColor: '#4A2E6B', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 8, elevation: 8,
  },
  fabGradient: { width: 60, height: 60, justifyContent: 'center', alignItems: 'center' },
  fabIcon: { color: '#FFFDF8', fontSize: 28, lineHeight: 32 },
});
