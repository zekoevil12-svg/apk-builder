import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  ActivityIndicator, Alert, ScrollView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ALL_SURAHS } from '@/data/surahsMeta';
import { RECITERS, Reciter, DEFAULT_RECITER } from '@/data/reciters';
import {
  downloadSurah, deleteSurahCache,
  getSurahCacheProgress, isSurahFullyCached,
} from '@/data/audioManager';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;

interface SurahStatus {
  surahNumber: number;
  progress: number; // 0-1
  downloading: boolean;
}

export default function QuranDownloadScreen() {
  const router = useRouter();
  const { t, isConnected } = useApp();
  const [reciter, setReciter] = useState<Reciter>(DEFAULT_RECITER);
  const [statuses, setStatuses] = useState<Map<number, SurahStatus>>(new Map());
  const [loadingStatuses, setLoadingStatuses] = useState(true);
  const [downloadAll, setDownloadAll] = useState(false);
  const downloadCancels = React.useRef<Map<number, { cancelled: boolean }>>(new Map());

  const loadStatuses = async () => {
    setLoadingStatuses(true);
    const map = new Map<number, SurahStatus>();
    for (const s of ALL_SURAHS) {
      const progress = await getSurahCacheProgress(reciter.id, s.startAyah, s.ayahCount);
      map.set(s.number, { surahNumber: s.number, progress, downloading: false });
    }
    setStatuses(new Map(map));
    setLoadingStatuses(false);
  };

  useEffect(() => { loadStatuses(); }, [reciter]);

  const handleDownload = async (surahNumber: number) => {
    if (!isConnected) {
      Alert.alert(t('غير متصل', 'Offline'), t('يلزم الاتصال بالإنترنت', 'Internet required'));
      return;
    }
    const surah = ALL_SURAHS.find(s => s.number === surahNumber)!;
    const cancel = { cancelled: false };
    downloadCancels.current.set(surahNumber, cancel);

    setStatuses(prev => {
      const next = new Map(prev);
      next.set(surahNumber, { surahNumber, progress: 0, downloading: true });
      return next;
    });

    await downloadSurah(
      reciter.id, surahNumber, surah.startAyah, surah.ayahCount,
      (done, total) => {
        setStatuses(prev => {
          const next = new Map(prev);
          next.set(surahNumber, { surahNumber, progress: done / total, downloading: true });
          return next;
        });
      },
      cancel
    );

    setStatuses(prev => {
      const next = new Map(prev);
      const p = cancel.cancelled ? (prev.get(surahNumber)?.progress ?? 0) : 1;
      next.set(surahNumber, { surahNumber, progress: p, downloading: false });
      return next;
    });
  };

  const handleDelete = (surahNumber: number) => {
    const surah = ALL_SURAHS.find(s => s.number === surahNumber)!;
    Alert.alert(
      t('حذف الصوت', 'Delete Audio'),
      t(`حذف صوت سورة ${surah.nameAr}؟`, `Delete audio for ${surah.nameEn}?`),
      [
        { text: t('إلغاء', 'Cancel'), style: 'cancel' },
        {
          text: t('حذف', 'Delete'), style: 'destructive',
          onPress: async () => {
            await deleteSurahCache(reciter.id, surah.startAyah, surah.ayahCount);
            setStatuses(prev => {
              const next = new Map(prev);
              next.set(surahNumber, { surahNumber, progress: 0, downloading: false });
              return next;
            });
          },
        },
      ]
    );
  };

  const handleDownloadAll = async () => {
    if (!isConnected) { Alert.alert(t('غير متصل', 'Offline'), t('يلزم الاتصال بالإنترنت', 'Internet required')); return; }
    setDownloadAll(true);
    for (const s of ALL_SURAHS) {
      const current = statuses.get(s.number);
      if (!current || current.progress < 0.99) {
        await handleDownload(s.number);
      }
    }
    setDownloadAll(false);
  };

  const cachedCount = Array.from(statuses.values()).filter(v => v.progress >= 0.99).length;

  const renderItem = ({ item }: { item: typeof ALL_SURAHS[0] }) => {
    const status = statuses.get(item.number) ?? { surahNumber: item.number, progress: 0, downloading: false };
    const isCached = status.progress >= 0.99;
    const isDownloading = status.downloading;
    return (
      <View style={styles.surahRow}>
        <View style={styles.surahLeft}>
          <View style={styles.numBadge}><Text style={styles.numTxt}>{item.number}</Text></View>
          <View>
            <Text style={styles.surahName}>{item.nameAr}</Text>
            <Text style={styles.surahSub}>{item.ayahCount} {t('آية', 'ayahs')}</Text>
          </View>
        </View>
        <View style={styles.surahRight}>
          {isDownloading ? (
            <View style={styles.progressContainer}>
              <View style={styles.progressTrack}>
                <View style={[styles.progressBar, { width: `${Math.round(status.progress * 100)}%` as any }]} />
              </View>
              <Text style={styles.progressPct}>{Math.round(status.progress * 100)}%</Text>
            </View>
          ) : isCached ? (
            <View style={styles.actionRow}>
              <View style={styles.cachedBadge}>
                <Text style={styles.cachedTxt}>✓ {t('محفوظ', 'Saved')}</Text>
              </View>
              <TouchableOpacity onPress={() => handleDelete(item.number)} style={styles.deleteBtn}>
                <Text style={styles.deleteTxt}>🗑</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              style={[styles.downloadBtn, !isConnected && { opacity: 0.5 }]}
              onPress={() => handleDownload(item.number)}
              disabled={!isConnected}
            >
              <Text style={styles.downloadTxt}>⬇ {t('تحميل', 'Download')}</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <LinearGradient colors={['#1E4D6B', '#163A52']} style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backTxt}>‹</Text>
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={styles.headerTitle}>{t('تحميل القرآن', 'Download Quran')}</Text>
          <Text style={styles.headerSub}>{cachedCount} / 114 {t('سورة محفوظة', 'surahs saved')}</Text>
        </View>
        <View style={{ width: 44 }} />
      </LinearGradient>

      {/* Reciter Selector */}
      <View style={styles.reciterRow}>
        <Text style={styles.reciterLabel}>{t('القارئ:', 'Reciter:')}</Text>
        <ScrollingReciterPicker selected={reciter} onSelect={setReciter} />
      </View>

      {/* Download All */}
      <TouchableOpacity
        style={[styles.downloadAllBtn, (!isConnected || downloadAll) && { opacity: 0.6 }]}
        onPress={handleDownloadAll}
        disabled={!isConnected || downloadAll}
      >
        <LinearGradient colors={['#1E4D6B', '#163A52']} style={styles.downloadAllGradient}>
          {downloadAll
            ? <ActivityIndicator color="#fff" size="small" />
            : <Text style={styles.downloadAllTxt}>⬇ {t('تحميل القرآن الكامل', 'Download Full Quran')}</Text>
          }
        </LinearGradient>
      </TouchableOpacity>

      {loadingStatuses ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={C.quranColor} />
        </View>
      ) : (
        <FlatList
          data={ALL_SURAHS}
          keyExtractor={s => String(s.number)}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          getItemLayout={(_, i) => ({ length: 66, offset: 66 * i, index: i })}
        />
      )}
    </SafeAreaView>
  );
}

function ScrollingReciterPicker({ selected, onSelect }: { selected: Reciter; onSelect: (r: Reciter) => void }) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flex: 1 }}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        {RECITERS.map(r => (
          <TouchableOpacity
            key={r.id}
            style={[styles.reciterChip, selected.id === r.id && { backgroundColor: r.color, borderColor: r.color }]}
            onPress={() => onSelect(r)}
          >
            <Text style={[styles.reciterChipTxt, selected.id === r.id && { color: '#fff' }]}>{r.nameAr}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 12 },
  backBtn: { width: 44, height: 44, justifyContent: 'center', alignItems: 'center' },
  backTxt: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  headerTitle: { fontFamily: 'Amiri_700Bold', fontSize: 20, color: '#FFFDF8' },
  headerSub: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: 'rgba(255,253,248,0.7)', marginTop: 2 },

  reciterRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.borderLight },
  reciterLabel: { fontFamily: 'Amiri_700Bold', fontSize: 14, color: C.textMuted },
  reciterChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: C.borderLight, backgroundColor: C.bgAlt },
  reciterChipTxt: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textSecondary },

  downloadAllBtn: { marginHorizontal: 14, marginVertical: 10, borderRadius: 14, overflow: 'hidden' },
  downloadAllGradient: { paddingVertical: 14, alignItems: 'center' },
  downloadAllTxt: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: '#FFFDF8' },

  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  list: { paddingHorizontal: 14, paddingVertical: 8, gap: 6 },

  surahRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: C.bgCard, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10,
    borderWidth: 1, borderColor: C.borderLight, minHeight: 60,
  },
  surahLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  numBadge: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#E8F0F8', justifyContent: 'center', alignItems: 'center' },
  numTxt: { fontFamily: 'Amiri_700Bold', fontSize: 13, color: C.quranColor },
  surahName: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: C.textPrimary },
  surahSub: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textMuted },
  surahRight: { alignItems: 'flex-end', gap: 4 },

  progressContainer: { alignItems: 'flex-end', gap: 3 },
  progressTrack: { width: 80, height: 5, backgroundColor: C.bgAlt, borderRadius: 3, overflow: 'hidden' },
  progressBar: { height: '100%', backgroundColor: C.quranColor, borderRadius: 3 },
  progressPct: { fontFamily: 'Amiri_400Regular', fontSize: 11, color: C.textMuted },

  actionRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  cachedBadge: { backgroundColor: '#E8F5EE', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  cachedTxt: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.emerald },
  deleteBtn: { padding: 4 },
  deleteTxt: { fontSize: 16 },

  downloadBtn: { backgroundColor: '#EDF4FC', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  downloadTxt: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.quranColor },
});
