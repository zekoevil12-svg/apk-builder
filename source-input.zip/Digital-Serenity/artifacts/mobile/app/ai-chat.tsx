import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  FlatList, KeyboardAvoidingView, Platform, Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { getAIResponse, getWelcomeMessage, AIMessage } from '@/data/aiResponses';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;

export default function AIChatScreen() {
  const router = useRouter();
  const { t } = useApp();
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: '0',
      text: getWelcomeMessage(),
      isUser: false,
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const dotAnim1 = useRef(new Animated.Value(0)).current;
  const dotAnim2 = useRef(new Animated.Value(0)).current;
  const dotAnim3 = useRef(new Animated.Value(0)).current;

  const animateDots = () => {
    const dotAnim = (dot: Animated.Value, delay: number) =>
      Animated.sequence([
        Animated.delay(delay),
        Animated.loop(
          Animated.sequence([
            Animated.timing(dot, { toValue: -6, duration: 300, useNativeDriver: true }),
            Animated.timing(dot, { toValue: 0, duration: 300, useNativeDriver: true }),
          ]),
          { iterations: 10 }
        ),
      ]);

    Animated.parallel([
      dotAnim(dotAnim1, 0),
      dotAnim(dotAnim2, 150),
      dotAnim(dotAnim3, 300),
    ]).start();
  };

  const sendMessage = async () => {
    const text = input.trim();
    if (!text) return;

    const userMsg: AIMessage = { id: Date.now().toString(), text, isUser: true, timestamp: Date.now() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    animateDots();

    const delay = 1200 + Math.random() * 800;
    setTimeout(() => {
      const response = getAIResponse(text);
      const aiMsg: AIMessage = { id: (Date.now() + 1).toString(), text: response, isUser: false, timestamp: Date.now() };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, delay);
  };

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages, isTyping]);

  const formatTime = (ts: number) =>
    new Date(ts).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });

  const renderMessage = ({ item }: { item: AIMessage }) => (
    <View style={[styles.msgRow, item.isUser ? styles.msgRowUser : styles.msgRowAI]}>
      {!item.isUser && (
        <View style={styles.aiAvatar}>
          <Text style={styles.aiAvatarIcon}>☽</Text>
        </View>
      )}
      <View style={[styles.bubble, item.isUser ? styles.bubbleUser : styles.bubbleAI]}>
        <Text style={[styles.bubbleText, item.isUser ? styles.bubbleTextUser : styles.bubbleTextAI]}>
          {item.text}
        </Text>
        <Text style={[styles.timestamp, item.isUser ? styles.timestampUser : styles.timestampAI]}>
          {formatTime(item.timestamp)}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
        {/* Header */}
        <LinearGradient colors={['#1E5C3A', '#144029']} style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backIcon}>‹</Text>
          </TouchableOpacity>
          <View style={styles.headerInfo}>
            <View style={styles.aiAvatarLg}>
              <Text style={styles.aiAvatarLgIcon}>☽</Text>
            </View>
            <View>
              <Text style={styles.headerTitle}>{t('رفيق السكينة', 'Serenity Companion')}</Text>
              <View style={styles.onlineRow}>
                <View style={styles.onlineDot} />
                <Text style={styles.onlineText}>{t('متاح دائماً · أوفلاين', 'Always available · Offline')}</Text>
              </View>
            </View>
          </View>
          <TouchableOpacity
            style={styles.clearBtn}
            onPress={() => setMessages([{ id: '0', text: getWelcomeMessage(), isUser: false, timestamp: Date.now() }])}
          >
            <Text style={styles.clearBtnText}>{t('جديد', 'New')}</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Messages */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(m) => m.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.messagesList}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />

        {/* Typing Indicator */}
        {isTyping && (
          <View style={styles.typingRow}>
            <View style={styles.aiAvatar}>
              <Text style={styles.aiAvatarIcon}>☽</Text>
            </View>
            <View style={styles.typingBubble}>
              <Animated.View style={[styles.typingDot, { transform: [{ translateY: dotAnim1 }] }]} />
              <Animated.View style={[styles.typingDot, { transform: [{ translateY: dotAnim2 }] }]} />
              <Animated.View style={[styles.typingDot, { transform: [{ translateY: dotAnim3 }] }]} />
            </View>
          </View>
        )}

        {/* Suggestions */}
        {messages.length <= 1 && (
          <View style={styles.suggestionsRow}>
            {[t('أشعر بالقلق', "I'm anxious"), t('أريد أن أتأمل', 'Help me reflect'), t('الحمد لله', 'Alhamdulillah')].map((s) => (
              <TouchableOpacity key={s} style={styles.suggestionChip} onPress={() => { setInput(s); }}>
                <Text style={styles.suggestionText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Input */}
        <View style={styles.inputBar}>
          <TextInput
            style={styles.input}
            placeholder={t('اكتب ما يشغل بالك...', 'Type what\'s on your mind...')}
            placeholderTextColor={C.textLight}
            value={input}
            onChangeText={setInput}
            multiline
            maxLength={500}
            textAlign="right"
            returnKeyType="send"
            onSubmitEditing={sendMessage}
          />
          <TouchableOpacity
            style={[styles.sendBtn, (!input.trim() || isTyping) && styles.sendBtnDisabled]}
            onPress={sendMessage}
            disabled={!input.trim() || isTyping}
          >
            <LinearGradient
              colors={!input.trim() || isTyping ? ['#C8BEB4', '#B0A89C'] : ['#2E6B50', '#1E5C3A']}
              style={styles.sendBtnGradient}
            >
              <Text style={styles.sendBtnIcon}>↑</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F2F8F5' },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 16, paddingVertical: 12, gap: 10,
  },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  backIcon: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  headerInfo: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  aiAvatarLg: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center',
  },
  aiAvatarLgIcon: { fontSize: 22 },
  headerTitle: { fontFamily: 'Amiri_700Bold', fontSize: 18, color: '#FFFDF8' },
  onlineRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#6EE7A0' },
  onlineText: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: 'rgba(255,253,248,0.7)' },
  clearBtn: { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: 'rgba(255,255,255,0.15)', borderRadius: 12 },
  clearBtnText: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: '#FFFDF8' },

  messagesList: { padding: 16, gap: 12, paddingBottom: 8 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 4 },
  msgRowUser: { flexDirection: 'row-reverse' },
  msgRowAI: { flexDirection: 'row' },

  aiAvatar: {
    width: 30, height: 30, borderRadius: 15,
    backgroundColor: '#D4EDDE', justifyContent: 'center', alignItems: 'center',
  },
  aiAvatarIcon: { fontSize: 16 },

  bubble: {
    maxWidth: '78%', borderRadius: 18, padding: 12, paddingHorizontal: 14,
    shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 4, elevation: 2,
  },
  bubbleUser: {
    backgroundColor: '#2E6B50', borderBottomRightRadius: 4,
    shadowColor: '#1E5C3A',
  },
  bubbleAI: {
    backgroundColor: '#FFFFFF', borderBottomLeftRadius: 4,
    borderWidth: 1, borderColor: C.borderLight, shadowColor: C.shadow,
  },
  bubbleText: { fontSize: 16, lineHeight: 26 },
  bubbleTextUser: { fontFamily: 'Amiri_400Regular', color: '#FFFDF8', textAlign: 'right' },
  bubbleTextAI: { fontFamily: 'Amiri_400Regular', color: C.textPrimary, textAlign: 'right' },
  timestamp: { fontSize: 11, marginTop: 4 },
  timestampUser: { fontFamily: 'Amiri_400Regular', color: 'rgba(255,255,255,0.6)', textAlign: 'right' },
  timestampAI: { fontFamily: 'Amiri_400Regular', color: C.textLight, textAlign: 'left' },

  typingRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 16, paddingBottom: 8 },
  typingBubble: {
    flexDirection: 'row', gap: 5, alignItems: 'center',
    backgroundColor: '#FFFFFF', borderRadius: 18, borderBottomLeftRadius: 4,
    padding: 14, borderWidth: 1, borderColor: C.borderLight,
  },
  typingDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.emeraldLight },

  suggestionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 16, paddingBottom: 8 },
  suggestionChip: {
    paddingHorizontal: 14, paddingVertical: 7,
    backgroundColor: '#FFFFFF', borderRadius: 20,
    borderWidth: 1, borderColor: '#A8D4B8',
  },
  suggestionText: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: C.emerald },

  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 10,
    paddingHorizontal: 16, paddingVertical: 10,
    backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: C.borderLight,
  },
  input: {
    flex: 1, fontFamily: 'Amiri_400Regular', fontSize: 16,
    color: C.textPrimary, backgroundColor: C.bgAlt,
    borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10,
    maxHeight: 100, borderWidth: 1, borderColor: C.borderLight,
  },
  sendBtn: { borderRadius: 22, overflow: 'hidden' },
  sendBtnDisabled: { opacity: 0.6 },
  sendBtnGradient: { width: 44, height: 44, justifyContent: 'center', alignItems: 'center', borderRadius: 22 },
  sendBtnIcon: { color: '#FFFDF8', fontSize: 20 },
});
