import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList,
  ScrollView, Animated, Dimensions, Modal, ActivityIndicator,
  Alert, Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as Speech from 'expo-speech';
import { ALL_SURAHS, SurahMeta, getGlobalAyahNumber } from '@/data/surahsMeta';
import { RECITERS, Reciter, DEFAULT_RECITER } from '@/data/reciters';
import { loadSurahAyahs, AyahData } from '@/data/quranCache';
import {
  playAyahAudio, stopAudio, pauseAudio, resumeAudio,
  downloadSurah, getSurahCacheProgress, isSurahFullyCached,
} from '@/data/audioManager';
import DownloadConsentSheet, { getSavedConsent, saveConsent } from '@/components/DownloadConsentSheet';
import { useApp } from '@/context/AppContext';
import colors from '@/constants/colors';

const C = colors.light;
const { width: W, height: H } = Dimensions.get('window');

type View = 'list' | 'reader';

export default function QuranScreen() {
  const router = useRouter();
  const { t, isConnected } = useApp();

  // Navigation state
  const [view, setView] = useState<'list' | 'reader'>('list');
  const [selectedSurah, setSelectedSurah] = useState<SurahMeta | null>(null);
  const slideAnim = useRef(new Animated.Value(W)).current;

  // Reader state
  const [ayahs, setAyahs] = useState<AyahData[]>([]);
  const [loading, setLoading] = useState(false);
  const [showTranslation, setShowTranslation] = useState(false);
  const [currentAyahIdx, setCurrentAyahIdx] = useState(0);
  const ayahListRef = useRef<FlatList>(null);

  // Audio state
  const [reciter, setReciter] = useState<Reciter>(DEFAULT_RECITER);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [audioLoading, setAudioLoading] = useState(false);
  const [showReciterPicker, setShowReciterPicker] = useState(false);
  const playingRef = useRef(false);
  const cancelRef = useRef(false);

  // Download state
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'downloading' | 'done' | 'error'>('idle');
  const [surahCacheStatus, setSurahCacheStatus] = useState<Map<number, number>>(new Map());
  const downloadCancel = useRef({ cancelled: false });

  // Consent sheet state
  const [showConsent, setShowConsent] = useState(false);
  const pendingPlayRef = useRef<(() => void) | null>(null);

  // Surah list state
  const [searchFilter, setSearchFilter] = useState<'all' | 'Meccan' | 'Medinan'>('all');

  const openSurah = async (surah: SurahMeta) => {
    setSelectedSurah(surah);
    setCurrentAyahIdx(0);
    setAyahs([]);
    setLoading(true);
    setIsPlaying(false);
    setIsPaused(false);
    cancelRef.current = true;
    await stopAudio();

    setView('reader');
    Animated.spring(slideAnim, { toValue: 0, tension: 80, friction: 10, useNativeDriver: true }).start();

    const data = await loadSurahAyahs(surah.number);
    setLoading(false);
    if (data) setAyahs(data);
  };

  const closeSurah = async () => {
    cancelRef.current = true;
    playingRef.current = false;
    await stopAudio();
    setIsPlaying(false);
    setIsPaused(false);
    Animated.timing(slideAnim, { toValue: W, duration: 280, useNativeDriver: true }).start(() => {
      setView('list');
      setSelectedSurah(null);
      setAyahs([]);
    });
  };

  const playFromIndex = useCallback(async (idx: number) => {
    if (!selectedSurah || idx >= ayahs.length) {
      setIsPlaying(false);
      setIsPaused(false);
      playingRef.current = false;
      return;
    }
    if (cancelRef.current) { cancelRef.current = false; return; }

    setCurrentAyahIdx(idx);
    setAudioLoading(true);
    ayahListRef.current?.scrollToIndex({ index: idx, animated: true, viewPosition: 0.3 });

    const globalNum = getGlobalAyahNumber(selectedSurah.number, ayahs[idx].number);

    const success = await playAyahAudio(reciter.id, globalNum, () => {
      if (playingRef.current && !cancelRef.current) {
        playFromIndex(idx + 1);
      }
    });

    setAudioLoading(false);
    if (!success) {
      // fallback: expo-speech
      if (Platform.OS !== 'web') {
        Speech.speak(ayahs[idx].arabic, {
          language: 'ar-SA', rate: 0.72,
          onDone: () => { if (playingRef.current) playFromIndex(idx + 1); },
        });
      }
    }
  }, [selectedSurah, ayahs, reciter]);

  const handlePlay = async () => {
    if (isPaused) {
      await resumeAudio();
      setIsPaused(false);
      setIsPlaying(true);
      playingRef.current = true;
      return;
    }

    // Check if audio is already cached for this surah
    if (selectedSurah && Platform.OS !== 'web') {
      const cached = await isSurahFullyCached(
        reciter.id, selectedSurah.number,
        selectedSurah.startAyah, selectedSurah.ayahCount
      );
      if (!cached) {
        // Check saved preference
        const saved = await getSavedConsent(reciter.id, selectedSurah.number);
        if (!saved) {
          // Ask permission
          pendingPlayRef.current = () => {
            cancelRef.current = false;
            playingRef.current = true;
            setIsPlaying(true);
            playFromIndex(currentAyahIdx);
          };
          setShowConsent(true);
          return;
        }
        // saved === 'stream' → just play without downloading
      }
    }

    cancelRef.current = false;
    playingRef.current = true;
    setIsPlaying(true);
    playFromIndex(currentAyahIdx);
  };

  const handleConsentAccept = async () => {
    setShowConsent(false);
    if (!selectedSurah) return;
    // Save choice
    await saveConsent(reciter.id, selectedSurah.number, 'download');
    // Download in background then play
    downloadCancel.current = { cancelled: false };
    setDownloadProgress(0);
    setDownloadStatus('downloading');
    setShowDownloadModal(true);
    await downloadSurah(
      reciter.id, selectedSurah.number,
      selectedSurah.startAyah, selectedSurah.ayahCount,
      (done, total) => setDownloadProgress(done / total),
      downloadCancel.current
    );
    setDownloadStatus('done');
    // Now play
    pendingPlayRef.current?.();
    pendingPlayRef.current = null;
  };

  const handleConsentDecline = async () => {
    setShowConsent(false);
    if (selectedSurah) await saveConsent(reciter.id, selectedSurah.number, 'stream');
    // Play streaming without saving
    pendingPlayRef.current?.();
    pendingPlayRef.current = null;
  };

  const handleConsentLater = () => {
    setShowConsent(false);
    pendingPlayRef.current = null;
  };

  const handlePause = async () => {
    await pauseAudio();
    setIsPaused(true);
    setIsPlaying(false);
  };

  const handleStop = async () => {
    cancelRef.current = true;
    playingRef.current = false;
    await stopAudio();
    Speech.stop();
    setIsPlaying(false);
    setIsPaused(false);
  };

  const handleNextAyah = async () => {
    if (currentAyahIdx < ayahs.length - 1) {
      await handleStop();
      setCurrentAyahIdx(i => i + 1);
    }
  };

  const handlePrevAyah = async () => {
    if (currentAyahIdx > 0) {
      await handleStop();
      setCurrentAyahIdx(i => i - 1);
    }
  };

  const handleDownloadSurah = async () => {
    if (!selectedSurah) return;
    if (!isConnected) {
      Alert.alert(t('غير متصل', 'Offline'), t('يلزم الاتصال بالإنترنت للتحميل', 'Internet required to download'));
      return;
    }
    downloadCancel.current = { cancelled: false };
    setDownloadProgress(0);
    setDownloadStatus('downloading');
    setShowDownloadModal(true);

    try {
      await downloadSurah(
        reciter.id,
        selectedSurah.number,
        selectedSurah.startAyah,
        selectedSurah.ayahCount,
        (done, total) => setDownloadProgress(done / total),
        downloadCancel.current
      );
      setDownloadStatus(downloadCancel.current.cancelled ? 'idle' : 'done');
    } catch { setDownloadStatus('error'); }
  };

  // Load cache status for list
  useEffect(() => {
    const loadStatus = async () => {
      const map = new Map<number, number>();
      // Check a sample of surahs
      for (const s of ALL_SURAHS) {
        const progress = await getSurahCacheProgress(reciter.id, s.startAyah, s.ayahCount);
        if (progress > 0) map.set(s.number, progress);
      }
      setSurahCacheStatus(map);
    };
    if (Platform.OS !== 'web') loadStatus();
  }, [reciter, view]);

  useEffect(() => {
    return () => { stopAudio(); Speech.stop(); };
  }, []);

  const filtered = searchFilter === 'all'
    ? ALL_SURAHS
    : ALL_SURAHS.filter(s => s.revelationType === searchFilter);

  const renderSurahItem = ({ item }: { item: SurahMeta }) => {
    const progress = surahCacheStatus.get(item.number) ?? 0;
    const isCached = progress >= 0.99;
    return (
      <TouchableOpacity style={styles.surahCard} onPress={() => openSurah(item)} activeOpacity={0.75}>
        <View style={styles.surahNumBadge}>
          <Text style={styles.surahNum}>{item.number}</Text>
        </View>
        <View style={styles.surahInfo}>
          <View style={styles.surahNameRow}>
            <Text style={styles.surahNameAr}>{item.nameAr}</Text>
            {isCached && <View style={styles.cachedDot} />}
            {progress > 0 && progress < 0.99 && (
              <View style={[styles.progressMini, { width: Math.round(progress * 40) }]} />
            )}
          </View>
          <Text style={styles.surahMeta}>
            {item.nameEn} · {item.ayahCount} {t('آية', 'verses')} · {t(item.revelationType === 'Meccan' ? 'مكية' : 'مدنية', item.revelationType)}
          </Text>
        </View>
        <Text style={styles.chevron}>›</Text>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      {/* ── SURAH LIST ─────────────────────────────── */}
      <LinearGradient colors={['#1E4D6B', '#163A52']} style={styles.header}>
        <TouchableOpacity onPress={() => { stopAudio(); Speech.stop(); router.back(); }} style={styles.hBtn}>
          <Text style={styles.hBtnTxt}>‹</Text>
        </TouchableOpacity>
        <View style={styles.hCenter}>
          <Text style={styles.hTitle}>{t('القرآن الكريم', 'Holy Quran')}</Text>
          <Text style={styles.hSub}>١١٤ سورة · ٦٢٣٦ آية</Text>
        </View>
        <TouchableOpacity style={styles.hBtn} onPress={() => setShowReciterPicker(true)}>
          <Text style={styles.reciterBtnTxt} numberOfLines={1}>🎙</Text>
        </TouchableOpacity>
      </LinearGradient>

      {/* Reciter Banner */}
      <TouchableOpacity style={[styles.reciterBanner, { borderLeftColor: reciter.color }]} onPress={() => setShowReciterPicker(true)}>
        <Text style={styles.reciterBannerIcon}>🎙</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.reciterBannerName}>{reciter.nameAr}</Text>
          <Text style={styles.reciterBannerStyle}>{reciter.style}</Text>
        </View>
        <Text style={styles.reciterBannerChange}>{t('تغيير', 'Change')}</Text>
      </TouchableOpacity>

      {/* Filter Tabs */}
      <View style={styles.filterRow}>
        {(['all', 'Meccan', 'Medinan'] as const).map(f => (
          <TouchableOpacity key={f} style={[styles.filterBtn, searchFilter === f && styles.filterBtnActive]} onPress={() => setSearchFilter(f)}>
            <Text style={[styles.filterBtnTxt, searchFilter === f && styles.filterBtnTxtActive]}>
              {f === 'all' ? t('الكل', 'All') : f === 'Meccan' ? t('مكية', 'Meccan') : t('مدنية', 'Medinan')}
            </Text>
          </TouchableOpacity>
        ))}
        <View style={{ flex: 1 }} />
        <Text style={styles.filterCount}>{filtered.length} {t('سورة', 'surahs')}</Text>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={s => String(s.number)}
        renderItem={renderSurahItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        getItemLayout={(_, index) => ({ length: 74, offset: 74 * index, index })}
        ListHeaderComponent={
          <View style={styles.bismillahBanner}>
            <Text style={styles.bismillah}>بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</Text>
          </View>
        }
      />

      {/* ── READER PANEL ──────────────────────────── */}
      {view === 'reader' && selectedSurah && (
        <Animated.View style={[styles.reader, { transform: [{ translateX: slideAnim }] }]}>
          {/* Reader Header */}
          <LinearGradient colors={['#1E4D6B', '#163A52']} style={styles.header}>
            <TouchableOpacity onPress={closeSurah} style={styles.hBtn}>
              <Text style={styles.hBtnTxt}>‹</Text>
            </TouchableOpacity>
            <View style={styles.hCenter}>
              <Text style={styles.hTitle}>{selectedSurah.nameAr}</Text>
              <Text style={styles.hSub}>{selectedSurah.nameMeaning} · {selectedSurah.ayahCount} {t('آية', 'ayahs')}</Text>
            </View>
            <TouchableOpacity style={styles.hBtn} onPress={() => setShowTranslation(v => !v)}>
              <View style={[styles.transToggle, showTranslation && styles.transToggleOn]}>
                <Text style={styles.transToggleTxt}>EN</Text>
              </View>
            </TouchableOpacity>
          </LinearGradient>

          {/* Audio Player Bar */}
          <View style={styles.playerBar}>
            <View style={styles.playerLeft}>
              <TouchableOpacity onPress={handlePrevAyah} disabled={currentAyahIdx === 0} style={styles.playerBtn}>
                <Text style={[styles.playerBtnIcon, currentAyahIdx === 0 && { opacity: 0.3 }]}>⏮</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={isPlaying ? handlePause : handlePlay}
                style={[styles.playBtn, { backgroundColor: reciter.color }]}
              >
                {audioLoading
                  ? <ActivityIndicator color="#fff" size="small" />
                  : <Text style={styles.playBtnIcon}>{isPlaying ? '⏸' : isPaused ? '▶' : '▶'}</Text>
                }
              </TouchableOpacity>
              <TouchableOpacity onPress={handleNextAyah} disabled={currentAyahIdx >= ayahs.length - 1} style={styles.playerBtn}>
                <Text style={[styles.playerBtnIcon, currentAyahIdx >= ayahs.length - 1 && { opacity: 0.3 }]}>⏭</Text>
              </TouchableOpacity>
              {(isPlaying || isPaused) && (
                <TouchableOpacity onPress={handleStop} style={styles.playerBtn}>
                  <Text style={styles.playerBtnIcon}>⏹</Text>
                </TouchableOpacity>
              )}
            </View>
            <View style={styles.playerRight}>
              <TouchableOpacity onPress={() => setShowReciterPicker(true)} style={styles.reciterMiniBtn}>
                <Text style={styles.reciterMiniName} numberOfLines={1}>{reciter.nameAr}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleDownloadSurah} style={styles.downloadBtn}>
                <Text style={styles.downloadBtnTxt}>⬇</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Ayah Counter */}
          <View style={styles.ayahCounter}>
            <Text style={styles.ayahCounterTxt}>
              {t('الآية', 'Ayah')} {ayahs[currentAyahIdx]?.number ?? 1} / {selectedSurah.ayahCount}
            </Text>
          </View>

          {/* Ayahs */}
          {loading ? (
            <View style={styles.loadingCenter}>
              <ActivityIndicator size="large" color={C.quranColor} />
              <Text style={styles.loadingTxt}>{t('جاري التحميل...', 'Loading...')}</Text>
            </View>
          ) : ayahs.length === 0 ? (
            <View style={styles.loadingCenter}>
              <Text style={styles.noTextIcon}>🌐</Text>
              <Text style={styles.noTextTxt}>
                {t('هذه السورة تحتاج اتصالاً للتحميل', 'This surah needs internet to load')}
              </Text>
              {isConnected && (
                <TouchableOpacity style={styles.retryBtn} onPress={() => openSurah(selectedSurah)}>
                  <Text style={styles.retryTxt}>{t('إعادة المحاولة', 'Retry')}</Text>
                </TouchableOpacity>
              )}
            </View>
          ) : (
            <FlatList
              ref={ayahListRef}
              data={ayahs}
              keyExtractor={a => String(a.number)}
              contentContainerStyle={styles.ayahsList}
              showsVerticalScrollIndicator={false}
              onScrollToIndexFailed={() => {}}
              renderItem={({ item, index }) => (
                <TouchableOpacity
                  style={[styles.ayahCard, index === currentAyahIdx && isPlaying && styles.ayahCardActive]}
                  onPress={() => {
                    handleStop();
                    setCurrentAyahIdx(index);
                  }}
                  activeOpacity={0.8}
                >
                  <View style={[styles.ayahNumBadge, { borderColor: reciter.color + '60', backgroundColor: reciter.color + '18' }]}>
                    <Text style={[styles.ayahNum, { color: reciter.color }]}>{item.number}</Text>
                  </View>
                  <View style={styles.ayahContent}>
                    <Text style={styles.ayahAr} selectable>{item.arabic}</Text>
                    {showTranslation && item.translation ? (
                      <Text style={styles.ayahTrans}>{item.translation}</Text>
                    ) : null}
                  </View>
                </TouchableOpacity>
              )}
            />
          )}
        </Animated.View>
      )}

      {/* ── DOWNLOAD CONSENT SHEET ───────────────── */}
      {selectedSurah && (
        <DownloadConsentSheet
          visible={showConsent}
          surahNameAr={selectedSurah.nameAr}
          surahNameEn={selectedSurah.nameEn}
          ayahCount={selectedSurah.ayahCount}
          reciterNameAr={reciter.nameAr}
          onAccept={handleConsentAccept}
          onDecline={handleConsentDecline}
          onLater={handleConsentLater}
        />
      )}

      {/* ── RECITER PICKER MODAL ─────────────────── */}
      <Modal visible={showReciterPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>{t('اختر القارئ', 'Choose Reciter')}</Text>
            {RECITERS.map(r => (
              <TouchableOpacity
                key={r.id}
                style={[styles.reciterOption, reciter.id === r.id && styles.reciterOptionActive]}
                onPress={() => { setReciter(r); setShowReciterPicker(false); }}
              >
                <View style={[styles.reciterColorDot, { backgroundColor: r.color }]} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.reciterOptionName}>{r.nameAr}</Text>
                  <Text style={styles.reciterOptionEn}>{r.nameEn} · {r.style}</Text>
                </View>
                {reciter.id === r.id && <Text style={{ color: C.gold, fontSize: 20 }}>✓</Text>}
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.modalClose} onPress={() => setShowReciterPicker(false)}>
              <Text style={styles.modalCloseTxt}>{t('إغلاق', 'Close')}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ── DOWNLOAD MODAL ───────────────────────── */}
      <Modal visible={showDownloadModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.downloadModal}>
            <Text style={styles.downloadModalTitle}>
              {downloadStatus === 'done'
                ? t('✓ اكتمل التحميل', '✓ Download Complete')
                : downloadStatus === 'error'
                ? t('خطأ في التحميل', 'Download Error')
                : t(`تحميل ${selectedSurah?.nameAr}`, `Downloading ${selectedSurah?.nameEn}`)}
            </Text>
            <Text style={styles.downloadModalSub}>{reciter.nameAr}</Text>

            {downloadStatus === 'downloading' && (
              <>
                <View style={styles.progressBar}>
                  <Animated.View style={[styles.progressFill, { width: `${Math.round(downloadProgress * 100)}%` as any, backgroundColor: reciter.color }]} />
                </View>
                <Text style={styles.progressPct}>{Math.round(downloadProgress * 100)}%</Text>
              </>
            )}

            {downloadStatus === 'done' && (
              <Text style={styles.downloadDoneMsg}>
                {t('السورة محفوظة للاستماع أوفلاين 🎉', 'Surah saved for offline listening 🎉')}
              </Text>
            )}

            <View style={styles.downloadModalBtns}>
              {downloadStatus === 'downloading' && (
                <TouchableOpacity
                  style={[styles.modalBtn, { backgroundColor: '#8B2020' }]}
                  onPress={() => { downloadCancel.current.cancelled = true; setShowDownloadModal(false); setDownloadStatus('idle'); }}
                >
                  <Text style={styles.modalBtnTxt}>{t('إلغاء', 'Cancel')}</Text>
                </TouchableOpacity>
              )}
              {(downloadStatus === 'done' || downloadStatus === 'error') && (
                <TouchableOpacity
                  style={[styles.modalBtn, { backgroundColor: reciter.color }]}
                  onPress={() => { setShowDownloadModal(false); setDownloadStatus('idle'); }}
                >
                  <Text style={styles.modalBtnTxt}>{t('موافق', 'OK')}</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },

  // Header
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 12, gap: 4 },
  hBtn: { width: 44, height: 44, justifyContent: 'center', alignItems: 'center' },
  hBtnTxt: { color: '#FFFDF8', fontSize: 28, fontFamily: 'Amiri_400Regular' },
  hCenter: { flex: 1, alignItems: 'center' },
  hTitle: { fontFamily: 'Amiri_700Bold', fontSize: 21, color: '#FFFDF8' },
  hSub: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: 'rgba(255,253,248,0.7)', marginTop: 1 },
  reciterBtnTxt: { fontSize: 22 },

  // Reciter Banner
  reciterBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 16, paddingVertical: 10,
    backgroundColor: '#EDF4FC', borderLeftWidth: 4,
    borderBottomWidth: 1, borderBottomColor: C.borderLight,
  },
  reciterBannerIcon: { fontSize: 20 },
  reciterBannerName: { fontFamily: 'Amiri_700Bold', fontSize: 15, color: C.textPrimary },
  reciterBannerStyle: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textMuted },
  reciterBannerChange: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.quranColor },

  // Filter Tabs
  filterRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 14, paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: C.borderLight,
  },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20, backgroundColor: C.bgAlt, borderWidth: 1, borderColor: 'transparent' },
  filterBtnActive: { backgroundColor: '#1E4D6B', borderColor: '#1E4D6B' },
  filterBtnTxt: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textSecondary },
  filterBtnTxtActive: { color: '#FFFDF8' },
  filterCount: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textLight },

  // Surah List
  list: { padding: 10, gap: 6, paddingBottom: 24 },
  bismillahBanner: {
    backgroundColor: '#E8F0F8', borderRadius: colors.radius.md, padding: 14,
    alignItems: 'center', marginBottom: 4,
    borderWidth: 1, borderColor: '#C0D4E8',
  },
  bismillah: { fontFamily: 'Amiri_400Regular', fontSize: 20, color: C.quranColor, textAlign: 'center' },

  surahCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: C.bgCard, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: C.borderLight,
    shadowColor: C.shadow, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 4, elevation: 1,
  },
  surahNumBadge: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#E8F0F8', justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: '#C0D4E8',
  },
  surahNum: { fontFamily: 'Amiri_700Bold', fontSize: 14, color: C.quranColor },
  surahInfo: { flex: 1 },
  surahNameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 6 },
  surahNameAr: { fontFamily: 'Amiri_700Bold', fontSize: 18, color: C.textPrimary, textAlign: 'right' },
  cachedDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: C.emerald },
  progressMini: { height: 4, borderRadius: 2, backgroundColor: C.gold, opacity: 0.7 },
  surahMeta: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textMuted, textAlign: 'right', marginTop: 2 },
  chevron: { fontSize: 22, color: C.textLight, transform: [{ scaleX: -1 }] },

  // Reader
  reader: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: C.bg, zIndex: 10 },

  // Translation toggle
  transToggle: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)' },
  transToggleOn: { backgroundColor: 'rgba(255,255,255,0.25)' },
  transToggleTxt: { color: '#FFFDF8', fontSize: 12, fontWeight: '600' },

  // Audio Player Bar
  playerBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 12, paddingVertical: 10,
    backgroundColor: '#F0F6FC', borderBottomWidth: 1, borderBottomColor: C.borderLight,
    gap: 8,
  },
  playerLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  playerBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  playerBtnIcon: { fontSize: 20, color: C.quranColor },
  playBtn: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4 },
  playBtnIcon: { fontSize: 18, color: '#fff' },
  playerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  reciterMiniBtn: { maxWidth: 110 },
  reciterMiniName: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.quranColor },
  downloadBtn: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center', backgroundColor: '#E8F0F8', borderRadius: 18 },
  downloadBtnTxt: { fontSize: 18, color: C.quranColor },

  ayahCounter: { backgroundColor: '#F8FBFE', paddingHorizontal: 16, paddingVertical: 6, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: C.borderLight },
  ayahCounterTxt: { fontFamily: 'Amiri_400Regular', fontSize: 13, color: C.textMuted },

  // Ayah List
  ayahsList: { padding: 14, gap: 12, paddingBottom: 40 },
  ayahCard: {
    flexDirection: 'row-reverse', alignItems: 'flex-start', gap: 10,
    backgroundColor: C.bgCard, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: C.borderLight,
    shadowColor: C.shadow, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 4, elevation: 1,
  },
  ayahCardActive: { backgroundColor: '#EDF4FB', borderColor: '#90BEE0' },
  ayahNumBadge: { width: 34, height: 34, borderRadius: 17, borderWidth: 1, justifyContent: 'center', alignItems: 'center', marginTop: 4 },
  ayahNum: { fontFamily: 'Amiri_700Bold', fontSize: 13 },
  ayahContent: { flex: 1 },
  ayahAr: { fontFamily: 'Amiri_400Regular', fontSize: 22, color: C.textPrimary, textAlign: 'right', lineHeight: 44, writingDirection: 'rtl' },
  ayahTrans: { fontFamily: 'LibreBaskerville_400Regular', fontSize: 13, color: C.textSecondary, lineHeight: 22, marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: C.borderLight },

  // Loading
  loadingCenter: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16, padding: 40 },
  loadingTxt: { fontFamily: 'Amiri_400Regular', fontSize: 16, color: C.textMuted },
  noTextIcon: { fontSize: 48 },
  noTextTxt: { fontFamily: 'Amiri_400Regular', fontSize: 16, color: C.textMuted, textAlign: 'center' },
  retryBtn: { backgroundColor: C.quranColor, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 20, marginTop: 8 },
  retryTxt: { fontFamily: 'Amiri_700Bold', fontSize: 15, color: '#FFFDF8' },

  // Modals
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'flex-end' },
  modalSheet: { backgroundColor: '#FFFDF8', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, gap: 4, paddingBottom: 36 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: C.borderLight, alignSelf: 'center', marginBottom: 12 },
  modalTitle: { fontFamily: 'Amiri_700Bold', fontSize: 20, color: C.textPrimary, textAlign: 'center', marginBottom: 12 },

  reciterOption: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 12, borderWidth: 1, borderColor: 'transparent', marginVertical: 2 },
  reciterOptionActive: { backgroundColor: '#EDF4FC', borderColor: '#C0D4E8' },
  reciterColorDot: { width: 14, height: 14, borderRadius: 7 },
  reciterOptionName: { fontFamily: 'Amiri_700Bold', fontSize: 17, color: C.textPrimary },
  reciterOptionEn: { fontFamily: 'Amiri_400Regular', fontSize: 12, color: C.textMuted, marginTop: 2 },

  modalClose: { marginTop: 10, padding: 14, alignItems: 'center', backgroundColor: C.bgAlt, borderRadius: 12 },
  modalCloseTxt: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: C.textSecondary },

  downloadModal: { backgroundColor: '#FFFDF8', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 28, gap: 12, alignItems: 'center', paddingBottom: 40 },
  downloadModalTitle: { fontFamily: 'Amiri_700Bold', fontSize: 20, color: C.textPrimary, textAlign: 'center' },
  downloadModalSub: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: C.textMuted },
  progressBar: { width: '100%', height: 10, backgroundColor: C.bgAlt, borderRadius: 5, overflow: 'hidden', marginTop: 8 },
  progressFill: { height: '100%', borderRadius: 5 },
  progressPct: { fontFamily: 'Amiri_700Bold', fontSize: 22, color: C.textPrimary },
  downloadDoneMsg: { fontFamily: 'Amiri_400Regular', fontSize: 15, color: C.emerald, textAlign: 'center', marginTop: 4 },
  downloadModalBtns: { flexDirection: 'row', gap: 10, marginTop: 8 },
  modalBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, alignItems: 'center' },
  modalBtnTxt: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: '#FFFDF8' },
});
