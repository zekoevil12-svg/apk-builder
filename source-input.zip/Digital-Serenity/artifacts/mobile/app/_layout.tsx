import { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import { Amiri_400Regular, Amiri_700Bold } from '@expo-google-fonts/amiri';
import {
  LibreBaskerville_400Regular,
  LibreBaskerville_700Bold,
  LibreBaskerville_400Italic,
} from '@expo-google-fonts/libre-baskerville';
import { AppProvider } from '@/context/AppContext';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { initDb } from '@/data/db';
import LoadingScreen from '@/components/LoadingScreen';

// Hide the native splash immediately — our LoadingScreen replaces it
try { SplashScreen.preventAutoHideAsync(); } catch {}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Amiri_400Regular,
    Amiri_700Bold,
    LibreBaskerville_400Regular,
    LibreBaskerville_700Bold,
    LibreBaskerville_400Italic,
  });
  const [ready, setReady] = useState(false);

  // Hide native splash on first render — show our custom screen immediately
  useEffect(() => {
    try { SplashScreen.hideAsync(); } catch {}
  }, []);

  useEffect(() => {
    if (fontsLoaded || fontError) {
      try { initDb(); } catch {}
      setReady(true);
    }
    // Hard fallback: never wait more than 3s
    const t = setTimeout(() => { try { initDb(); } catch {}  setReady(true); }, 3000);
    return () => clearTimeout(t);
  }, [fontsLoaded, fontError]);

  // Show branded loading screen while fonts load
  if (!ready) return <LoadingScreen />;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AppProvider>
        <StatusBar style="dark" backgroundColor="#F9F6EF" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: '#F9F6EF' },
            animation: 'fade',
          }}
        />
      </AppProvider>
    </GestureHandlerRootView>
  );
}
