import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function LoadingScreen() {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.85)).current;
  const ring1 = useRef(new Animated.Value(1)).current;
  const ring2 = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();

    const pulse = () =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(ring1, { toValue: 1.35, duration: 1400, useNativeDriver: true }),
          Animated.timing(ring1, { toValue: 1, duration: 1400, useNativeDriver: true }),
        ])
      ).start();

    const pulse2 = () =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(500),
          Animated.timing(ring2, { toValue: 1.6, duration: 1800, useNativeDriver: true }),
          Animated.timing(ring2, { toValue: 1, duration: 1800, useNativeDriver: true }),
        ])
      ).start();

    pulse();
    pulse2();
  }, []);

  return (
    <LinearGradient colors={['#FEFCF8', '#F5EFE2', '#EDE4D0']} style={styles.container}>
      <Animated.View style={[styles.center, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.ringWrap}>
          <Animated.View style={[styles.ring, styles.ring2, { transform: [{ scale: ring2 }], opacity: 0.18 }]} />
          <Animated.View style={[styles.ring, { transform: [{ scale: ring1 }], opacity: 0.3 }]} />
          <View style={styles.iconCircle}>
            <Text style={styles.icon}>☽</Text>
          </View>
        </View>
        <Text style={styles.title}>السكينة</Text>
        <Text style={styles.sub}>جاري التحضير...</Text>
        <View style={styles.dotsRow}>
          {[0, 1, 2].map(i => <PulsingDot key={i} delay={i * 200} />)}
        </View>
      </Animated.View>
    </LinearGradient>
  );
}

function PulsingDot({ delay }: { delay: number }) {
  const anim = useRef(new Animated.Value(0.4)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(anim, { toValue: 1, duration: 500, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0.4, duration: 500, useNativeDriver: true }),
      ])
    ).start();
  }, []);
  return <Animated.View style={[styles.dot, { opacity: anim }]} />;
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  center: { alignItems: 'center', gap: 14 },
  ringWrap: { width: 130, height: 130, justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  ring: {
    position: 'absolute',
    width: 90, height: 90, borderRadius: 45,
    borderWidth: 1.5, borderColor: '#C09434',
  },
  ring2: { width: 90, height: 90, borderRadius: 45 },
  iconCircle: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(192,148,52,0.12)',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(192,148,52,0.3)',
  },
  icon: { fontSize: 36, color: '#C09434' },
  // Use system fonts here — custom fonts aren't loaded yet at this stage
  title: { fontFamily: undefined, fontSize: 34, fontWeight: '700', color: '#3C2A10', letterSpacing: 2 },
  sub: { fontFamily: undefined, fontSize: 15, fontWeight: '400', color: '#9A8060' },
  dotsRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#C09434' },
});
