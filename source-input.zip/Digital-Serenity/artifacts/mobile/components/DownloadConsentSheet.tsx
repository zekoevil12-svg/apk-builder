/**
 * BottomSheet that asks permission before downloading Quran audio.
 * Shows: reciter name, surah name, estimated size, Yes/No/Later.
 */
import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Modal,
  Animated, Dimensions, Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { height: H } = Dimensions.get('window');

export interface ConsentProps {
  visible: boolean;
  surahNameAr: string;
  surahNameEn: string;
  ayahCount: number;
  reciterNameAr: string;
  onAccept: () => void;
  onDecline: () => void;   // stream/TTS — don't save, just play
  onLater: () => void;     // dismiss modal
}

// Rough estimate: ~80KB per ayah at 128kbps
const estimateMB = (ayahCount: number) =>
  ((ayahCount * 80) / 1024).toFixed(1);

export default function DownloadConsentSheet({
  visible, surahNameAr, surahNameEn, ayahCount,
  reciterNameAr, onAccept, onDecline, onLater,
}: ConsentProps) {
  const slideAnim = useRef(new Animated.Value(H)).current;

  useEffect(() => {
    if (visible) {
      Animated.spring(slideAnim, {
        toValue: 0, tension: 70, friction: 12, useNativeDriver: true,
      }).start();
    } else {
      Animated.timing(slideAnim, {
        toValue: H, duration: 250, useNativeDriver: true,
      }).start();
    }
  }, [visible]);

  const mb = estimateMB(ayahCount);

  return (
    <Modal visible={visible} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay}>
        <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={onLater} />
        <Animated.View style={[styles.sheet, { transform: [{ translateY: slideAnim }] }]}>
          <View style={styles.handle} />

          {/* Icon */}
          <View style={styles.iconWrap}>
            <Text style={styles.icon}>🎙</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>تحميل الصوت أوفلاين؟</Text>
          <Text style={styles.sub}>
            سورة <Text style={styles.bold}>{surahNameAr}</Text> — {ayahCount} آية
          </Text>
          <Text style={styles.reciter}>القارئ: {reciterNameAr}</Text>

          {/* Size Info */}
          <View style={styles.infoBox}>
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>💾</Text>
              <Text style={styles.infoText}>المساحة المطلوبة: <Text style={styles.bold}>~{mb} ميغابايت</Text></Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>✈️</Text>
              <Text style={styles.infoText}>بعد التحميل تشتغل بدون إنترنت</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>📶</Text>
              <Text style={styles.infoText}>بدون تحميل تعمل فقط مع الإنترنت</Text>
            </View>
          </View>

          {/* Buttons */}
          <TouchableOpacity style={styles.btnPrimary} onPress={onAccept} activeOpacity={0.85}>
            <Text style={styles.btnPrimaryTxt}>⬇ تحميل وحفظ للاستخدام أوفلاين</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btnSecondary} onPress={onDecline} activeOpacity={0.85}>
            <Text style={styles.btnSecondaryTxt}>▶ تشغيل فقط (بدون حفظ)</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={onLater} style={styles.laterBtn}>
            <Text style={styles.laterTxt}>لاحقاً</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
    </Modal>
  );
}

// Helper — remember per-surah choice so we don't ask again
const CONSENT_KEY = (reciterId: string, surahNum: number) =>
  `dl_consent_${reciterId}_${surahNum}`;

export const getSavedConsent = async (
  reciterId: string, surahNum: number
): Promise<'download' | 'stream' | null> => {
  try {
    const v = await AsyncStorage.getItem(CONSENT_KEY(reciterId, surahNum));
    return (v as any) ?? null;
  } catch { return null; }
};

export const saveConsent = async (
  reciterId: string, surahNum: number, choice: 'download' | 'stream'
) => {
  try { await AsyncStorage.setItem(CONSENT_KEY(reciterId, surahNum), choice); } catch {}
};

const GOLD = '#C09434';
const DARK = '#3C2A10';
const MUTED = '#9A8060';

const styles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: {
    backgroundColor: '#FFFDF8',
    borderTopLeftRadius: 28, borderTopRightRadius: 28,
    paddingHorizontal: 24, paddingBottom: Platform.OS === 'ios' ? 40 : 28,
    paddingTop: 12, gap: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.12, shadowRadius: 20, elevation: 20,
  },
  handle: { width: 44, height: 4, borderRadius: 2, backgroundColor: '#DDD', alignSelf: 'center', marginBottom: 10 },
  iconWrap: { alignSelf: 'center', width: 64, height: 64, borderRadius: 32, backgroundColor: 'rgba(192,148,52,0.12)', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(192,148,52,0.25)', marginBottom: 2 },
  icon: { fontSize: 30 },
  title: { fontFamily: 'Amiri_700Bold', fontSize: 22, color: DARK, textAlign: 'center' },
  sub: { fontFamily: 'Amiri_400Regular', fontSize: 16, color: MUTED, textAlign: 'center' },
  reciter: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: MUTED, textAlign: 'center' },
  bold: { fontFamily: 'Amiri_700Bold', color: DARK },
  infoBox: { backgroundColor: '#F5EFE2', borderRadius: 14, padding: 14, gap: 8, marginVertical: 4 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoIcon: { fontSize: 16 },
  infoText: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: DARK, flex: 1 },
  btnPrimary: {
    backgroundColor: GOLD, borderRadius: 16,
    paddingVertical: 15, alignItems: 'center',
    shadowColor: GOLD, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35, shadowRadius: 8, elevation: 6,
  },
  btnPrimaryTxt: { fontFamily: 'Amiri_700Bold', fontSize: 16, color: '#FFFDF8' },
  btnSecondary: {
    backgroundColor: '#F0EBE0', borderRadius: 16,
    paddingVertical: 14, alignItems: 'center',
    borderWidth: 1, borderColor: '#DDD5C0',
  },
  btnSecondaryTxt: { fontFamily: 'Amiri_700Bold', fontSize: 15, color: DARK },
  laterBtn: { alignItems: 'center', paddingVertical: 6 },
  laterTxt: { fontFamily: 'Amiri_400Regular', fontSize: 14, color: MUTED },
});
