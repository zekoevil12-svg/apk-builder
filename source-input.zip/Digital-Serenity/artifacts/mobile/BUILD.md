# 📦 بناء ملف APK لتطبيق السكينة

## المتطلبات
- حساب مجاني على [Expo](https://expo.dev)
- Node.js مثبّت على جهازك
- pnpm أو npm

---

## خطوات بناء الـ APK

### ١. تسجيل الدخول لـ Expo
```bash
npx eas-cli login
```

### ٢. تهيئة المشروع (مرة واحدة فقط)
```bash
cd artifacts/mobile
npx eas-cli build:configure
```

### ٣. بناء ملف APK
```bash
npx eas-cli build --platform android --profile preview
```

سيبدأ البناء على سيرفرات Expo (5-10 دقائق) وعند الانتهاء يعطيك رابط لتحميل الـ APK مباشرة.

---

## بناء محلي (يتطلب Android Studio)
```bash
# تثبيت الـ dependencies
pnpm install

# توليد ملفات Android
npx expo prebuild --platform android

# بناء الـ APK
cd android && ./gradlew assembleRelease
```

الـ APK في: `android/app/build/outputs/apk/release/app-release.apk`

---

## ملاحظات
- الـ APK من `eas build` يعمل على أي جهاز Android
- لـ Google Play Store، استخدم `--profile production` (ينتج AAB)
- التطبيق يعمل **بالكامل بدون إنترنت** بعد التثبيت
