import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import * as Network from 'expo-network';

type Language = 'ar' | 'en';
type Background = 'none' | 'bg1' | 'bg2';

interface AppContextType {
  language: Language;
  setLanguage: (l: Language) => void;
  background: Background;
  setBackground: (b: Background) => void;
  isConnected: boolean;
  recheckNetwork: () => Promise<boolean>;
  t: (ar: string, en: string) => string;
}

const AppContext = createContext<AppContextType>({
  language: 'ar',
  setLanguage: () => {},
  background: 'none',
  setBackground: () => {},
  isConnected: false,
  recheckNetwork: async () => false,
  t: (ar) => ar,
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('ar');
  const [background, setBackground] = useState<Background>('none');
  const [isConnected, setIsConnected] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const checkNetwork = useCallback(async (): Promise<boolean> => {
    try {
      const state = await Network.getNetworkStateAsync();
      const connected = !!(state.isConnected && state.isInternetReachable);
      setIsConnected(connected);
      return connected;
    } catch {
      setIsConnected(false);
      return false;
    }
  }, []);

  useEffect(() => {
    checkNetwork();
    intervalRef.current = setInterval(checkNetwork, 8000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [checkNetwork]);

  const t = useCallback((ar: string, en: string) => (language === 'ar' ? ar : en), [language]);

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        background,
        setBackground,
        isConnected,
        recheckNetwork: checkNetwork,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
