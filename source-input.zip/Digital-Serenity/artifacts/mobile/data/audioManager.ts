import { Platform } from 'react-native';
import { getAudioUrl } from './reciters';
import { getGlobalAyahNumber } from './surahsMeta';

// Lazy imports for native-only modules
let FileSystem: any = null;
let AudioModule: any = null;
let soundInstance: any = null;

const getFS = () => {
  if (!FileSystem && Platform.OS !== 'web') {
    try { FileSystem = require('expo-file-system'); } catch {}
  }
  return FileSystem;
};

const getAudio = () => {
  if (!AudioModule && Platform.OS !== 'web') {
    try { AudioModule = require('expo-av'); } catch {}
  }
  return AudioModule;
};

export const getAudioCacheDir = (reciterId: string): string => {
  const fs = getFS();
  if (!fs) return '';
  return `${fs.documentDirectory}quran_audio/${reciterId}/`;
};

export const getAudioCachePath = (reciterId: string, globalAyahNum: number): string =>
  `${getAudioCacheDir(reciterId)}${globalAyahNum}.mp3`;

export const isAyahCached = async (reciterId: string, globalAyahNum: number): Promise<boolean> => {
  const fs = getFS();
  if (!fs) return false;
  try {
    const path = getAudioCachePath(reciterId, globalAyahNum);
    const info = await fs.getInfoAsync(path);
    return info.exists && (info.size ?? 0) > 1000;
  } catch { return false; }
};

export const isSurahFullyCached = async (
  reciterId: string,
  surahNumber: number,
  startGlobal: number,
  ayahCount: number
): Promise<boolean> => {
  const checks = await Promise.all(
    Array.from({ length: ayahCount }, (_, i) => isAyahCached(reciterId, startGlobal + i))
  );
  return checks.every(Boolean);
};

export const getSurahCacheProgress = async (
  reciterId: string,
  startGlobal: number,
  ayahCount: number
): Promise<number> => {
  const checks = await Promise.all(
    Array.from({ length: ayahCount }, (_, i) => isAyahCached(reciterId, startGlobal + i))
  );
  return checks.filter(Boolean).length / ayahCount;
};

export const downloadAyah = async (
  reciterId: string,
  globalAyahNum: number,
  onProgress?: (p: number) => void
): Promise<string | null> => {
  const fs = getFS();
  if (!fs) return null;
  try {
    const dir = getAudioCacheDir(reciterId);
    const dirInfo = await fs.getInfoAsync(dir);
    if (!dirInfo.exists) await fs.makeDirectoryAsync(dir, { intermediates: true });

    const path = getAudioCachePath(reciterId, globalAyahNum);
    const info = await fs.getInfoAsync(path);
    if (info.exists && (info.size ?? 0) > 1000) return path;

    const url = getAudioUrl(reciterId, globalAyahNum);
    const download = fs.createDownloadResumable(url, path, {}, (prog: any) => {
      if (onProgress && prog.totalBytesExpectedToWrite > 0) {
        onProgress(prog.totalBytesWritten / prog.totalBytesExpectedToWrite);
      }
    });
    const result = await download.downloadAsync();
    return result?.uri ?? null;
  } catch { return null; }
};

export const downloadSurah = async (
  reciterId: string,
  surahNumber: number,
  startGlobal: number,
  ayahCount: number,
  onProgress?: (done: number, total: number) => void,
  signal?: { cancelled: boolean }
): Promise<void> => {
  for (let i = 0; i < ayahCount; i++) {
    if (signal?.cancelled) break;
    const globalNum = startGlobal + i;
    const cached = await isAyahCached(reciterId, globalNum);
    if (!cached) await downloadAyah(reciterId, globalNum);
    onProgress?.(i + 1, ayahCount);
  }
};

export const deleteSurahCache = async (reciterId: string, startGlobal: number, ayahCount: number) => {
  const fs = getFS();
  if (!fs) return;
  for (let i = 0; i < ayahCount; i++) {
    try {
      const path = getAudioCachePath(reciterId, startGlobal + i);
      const info = await fs.getInfoAsync(path);
      if (info.exists) await fs.deleteAsync(path, { idempotent: true });
    } catch {}
  }
};

export const stopAudio = async () => {
  try {
    if (soundInstance) {
      await soundInstance.stopAsync();
      await soundInstance.unloadAsync();
      soundInstance = null;
    }
  } catch {}
};

export const playAyahAudio = async (
  reciterId: string,
  globalAyahNum: number,
  onFinish?: () => void
): Promise<boolean> => {
  const AV = getAudio();
  if (!AV) return false;
  try {
    await stopAudio();
    await AV.Audio.setAudioModeAsync({ playsInSilentModeIOS: true });

    const cached = await isAyahCached(reciterId, globalAyahNum);
    const uri = cached
      ? getAudioCachePath(reciterId, globalAyahNum)
      : getAudioUrl(reciterId, globalAyahNum);

    const { sound } = await AV.Audio.Sound.createAsync(
      { uri },
      { shouldPlay: true, volume: 1.0 },
      (status: any) => {
        if (status.didJustFinish) {
          sound.unloadAsync();
          soundInstance = null;
          onFinish?.();
        }
      }
    );
    soundInstance = sound;
    return true;
  } catch { return false; }
};

export const pauseAudio = async () => {
  try { if (soundInstance) await soundInstance.pauseAsync(); } catch {}
};

export const resumeAudio = async () => {
  try { if (soundInstance) await soundInstance.playAsync(); } catch {}
};
