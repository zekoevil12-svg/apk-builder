export interface SurahMeta {
  number: number;
  nameAr: string;
  nameEn: string;
  nameMeaning: string;
  ayahCount: number;
  revelationType: 'Meccan' | 'Medinan';
  startAyah: number; // global ayah number (1-6236)
}

// Ayah counts for all 114 surahs
const AYAH_COUNTS = [
  7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
  123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
  112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
  34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
  54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
  60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
  14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
  28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
  29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
  15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
  11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
  5, 4, 5, 6,
];

const SURAH_DATA: [string, string, string, 'Meccan' | 'Medinan'][] = [
  ['الفاتحة', 'Al-Fatiha', 'The Opening', 'Meccan'],
  ['البقرة', 'Al-Baqara', 'The Cow', 'Medinan'],
  ['آل عمران', 'Al-Imran', 'Family of Imran', 'Medinan'],
  ['النساء', 'An-Nisa', 'The Women', 'Medinan'],
  ['المائدة', 'Al-Maida', 'The Table Spread', 'Medinan'],
  ['الأنعام', 'Al-Anam', 'The Cattle', 'Meccan'],
  ['الأعراف', 'Al-Araf', 'The Heights', 'Meccan'],
  ['الأنفال', 'Al-Anfal', 'The Spoils of War', 'Medinan'],
  ['التوبة', 'At-Tawba', 'The Repentance', 'Medinan'],
  ['يونس', 'Yunus', 'Jonah', 'Meccan'],
  ['هود', 'Hud', 'Hud', 'Meccan'],
  ['يوسف', 'Yusuf', 'Joseph', 'Meccan'],
  ['الرعد', 'Ar-Rad', 'The Thunder', 'Medinan'],
  ['إبراهيم', 'Ibrahim', 'Abraham', 'Meccan'],
  ['الحجر', 'Al-Hijr', 'The Rocky Tract', 'Meccan'],
  ['النحل', 'An-Nahl', 'The Bee', 'Meccan'],
  ['الإسراء', 'Al-Isra', 'The Night Journey', 'Meccan'],
  ['الكهف', 'Al-Kahf', 'The Cave', 'Meccan'],
  ['مريم', 'Maryam', 'Mary', 'Meccan'],
  ['طه', 'Ta-Ha', 'Ta-Ha', 'Meccan'],
  ['الأنبياء', 'Al-Anbiya', 'The Prophets', 'Meccan'],
  ['الحج', 'Al-Hajj', 'The Pilgrimage', 'Medinan'],
  ['المؤمنون', 'Al-Muminun', 'The Believers', 'Meccan'],
  ['النور', 'An-Nur', 'The Light', 'Medinan'],
  ['الفرقان', 'Al-Furqan', 'The Criterion', 'Meccan'],
  ['الشعراء', 'Ash-Shuara', 'The Poets', 'Meccan'],
  ['النمل', 'An-Naml', 'The Ant', 'Meccan'],
  ['القصص', 'Al-Qasas', 'The Stories', 'Meccan'],
  ['العنكبوت', 'Al-Ankabut', 'The Spider', 'Meccan'],
  ['الروم', 'Ar-Rum', 'The Romans', 'Meccan'],
  ['لقمان', 'Luqman', 'Luqman', 'Meccan'],
  ['السجدة', 'As-Sajda', 'The Prostration', 'Meccan'],
  ['الأحزاب', 'Al-Ahzab', 'The Clans', 'Medinan'],
  ['سبأ', 'Saba', 'Sheba', 'Meccan'],
  ['فاطر', 'Fatir', 'Originator', 'Meccan'],
  ['يس', 'Ya-Sin', 'Ya Sin', 'Meccan'],
  ['الصافات', 'As-Saffat', 'Those Who Set Ranks', 'Meccan'],
  ['ص', 'Sad', 'Sad', 'Meccan'],
  ['الزمر', 'Az-Zumar', 'The Troops', 'Meccan'],
  ['غافر', 'Ghafir', 'The Forgiver', 'Meccan'],
  ['فصلت', 'Fussilat', 'Explained in Detail', 'Meccan'],
  ['الشورى', 'Ash-Shura', 'The Consultation', 'Meccan'],
  ['الزخرف', 'Az-Zukhruf', 'The Ornaments of Gold', 'Meccan'],
  ['الدخان', 'Ad-Dukhan', 'The Smoke', 'Meccan'],
  ['الجاثية', 'Al-Jathiya', 'Crouching', 'Meccan'],
  ['الأحقاف', 'Al-Ahqaf', 'The Wind-curved Sandhills', 'Meccan'],
  ['محمد', 'Muhammad', 'Muhammad', 'Medinan'],
  ['الفتح', 'Al-Fath', 'The Victory', 'Medinan'],
  ['الحجرات', 'Al-Hujurat', 'The Rooms', 'Medinan'],
  ['ق', 'Qaf', 'Qaf', 'Meccan'],
  ['الذاريات', 'Adh-Dhariyat', 'The Winnowing Winds', 'Meccan'],
  ['الطور', 'At-Tur', 'The Mount', 'Meccan'],
  ['النجم', 'An-Najm', 'The Star', 'Meccan'],
  ['القمر', 'Al-Qamar', 'The Moon', 'Meccan'],
  ['الرحمن', 'Ar-Rahman', 'The Beneficent', 'Medinan'],
  ['الواقعة', 'Al-Waqia', 'The Inevitable', 'Meccan'],
  ['الحديد', 'Al-Hadid', 'The Iron', 'Medinan'],
  ['المجادلة', 'Al-Mujadila', 'The Pleading', 'Medinan'],
  ['الحشر', 'Al-Hashr', 'The Exile', 'Medinan'],
  ['الممتحنة', 'Al-Mumtahana', 'She that is to be Examined', 'Medinan'],
  ['الصف', 'As-Saf', 'The Ranks', 'Medinan'],
  ['الجمعة', 'Al-Jumua', 'Friday', 'Medinan'],
  ['المنافقون', 'Al-Munafiqun', 'The Hypocrites', 'Medinan'],
  ['التغابن', 'At-Taghabun', 'Mutual Disillusion', 'Medinan'],
  ['الطلاق', 'At-Talaq', 'Divorce', 'Medinan'],
  ['التحريم', 'At-Tahrim', 'The Prohibition', 'Medinan'],
  ['الملك', 'Al-Mulk', 'The Sovereignty', 'Meccan'],
  ['القلم', 'Al-Qalam', 'The Pen', 'Meccan'],
  ['الحاقة', 'Al-Haqqа', 'The Reality', 'Meccan'],
  ['المعارج', 'Al-Maarij', 'The Ascending Stairways', 'Meccan'],
  ['نوح', 'Nuh', 'Noah', 'Meccan'],
  ['الجن', 'Al-Jinn', 'The Jinn', 'Meccan'],
  ['المزمل', 'Al-Muzzammil', 'The Enshrouded One', 'Meccan'],
  ['المدثر', 'Al-Muddaththir', 'The Cloaked One', 'Meccan'],
  ['القيامة', 'Al-Qiyama', 'The Resurrection', 'Meccan'],
  ['الإنسان', 'Al-Insan', 'Man', 'Medinan'],
  ['المرسلات', 'Al-Mursalat', 'The Emissaries', 'Meccan'],
  ['النبأ', 'An-Naba', 'The Tidings', 'Meccan'],
  ['النازعات', 'An-Naziat', 'Those Who Drag Forth', 'Meccan'],
  ['عبس', 'Abasa', 'He Frowned', 'Meccan'],
  ['التكوير', 'At-Takwir', 'The Folding Up', 'Meccan'],
  ['الانفطار', 'Al-Infitar', 'The Cleaving', 'Meccan'],
  ['المطففين', 'Al-Mutaffifin', 'Defrauding', 'Meccan'],
  ['الانشقاق', 'Al-Inshiqaq', 'The Splitting Open', 'Meccan'],
  ['البروج', 'Al-Buruj', 'The Mansions of the Stars', 'Meccan'],
  ['الطارق', 'At-Tariq', 'The Morning Star', 'Meccan'],
  ['الأعلى', 'Al-Ala', 'The Most High', 'Meccan'],
  ['الغاشية', 'Al-Ghashiya', 'The Overwhelming', 'Meccan'],
  ['الفجر', 'Al-Fajr', 'The Dawn', 'Meccan'],
  ['البلد', 'Al-Balad', 'The City', 'Meccan'],
  ['الشمس', 'Ash-Shams', 'The Sun', 'Meccan'],
  ['الليل', 'Al-Layl', 'The Night', 'Meccan'],
  ['الضحى', 'Ad-Duha', 'The Morning Hours', 'Meccan'],
  ['الشرح', 'Ash-Sharh', 'The Relief', 'Meccan'],
  ['التين', 'At-Tin', 'The Fig', 'Meccan'],
  ['العلق', 'Al-Alaq', 'The Clot', 'Meccan'],
  ['القدر', 'Al-Qadr', 'The Power', 'Meccan'],
  ['البينة', 'Al-Bayyina', 'The Clear Proof', 'Medinan'],
  ['الزلزلة', 'Az-Zalzala', 'The Earthquake', 'Medinan'],
  ['العاديات', 'Al-Adiyat', 'The Courser', 'Meccan'],
  ['القارعة', 'Al-Qaria', 'The Calamity', 'Meccan'],
  ['التكاثر', 'At-Takathur', 'Rivalry in World Increase', 'Meccan'],
  ['العصر', 'Al-Asr', 'The Declining Day', 'Meccan'],
  ['الهمزة', 'Al-Humaza', 'The Traducer', 'Meccan'],
  ['الفيل', 'Al-Fil', 'The Elephant', 'Meccan'],
  ['قريش', 'Quraysh', 'Quraysh', 'Meccan'],
  ['الماعون', 'Al-Maun', 'Small Kindnesses', 'Meccan'],
  ['الكوثر', 'Al-Kawthar', 'The Abundance', 'Meccan'],
  ['الكافرون', 'Al-Kafirun', 'The Disbelievers', 'Meccan'],
  ['النصر', 'An-Nasr', 'The Divine Support', 'Medinan'],
  ['المسد', 'Al-Masad', 'The Palm Fibre', 'Meccan'],
  ['الإخلاص', 'Al-Ikhlas', 'The Sincerity', 'Meccan'],
  ['الفلق', 'Al-Falaq', 'The Daybreak', 'Meccan'],
  ['الناس', 'An-Nas', 'Mankind', 'Meccan'],
];

// Build the complete metadata with start ayah numbers
let cumulative = 1;
export const ALL_SURAHS: SurahMeta[] = SURAH_DATA.map(([nameAr, nameEn, nameMeaning, revType], index) => {
  const entry: SurahMeta = {
    number: index + 1,
    nameAr,
    nameEn,
    nameMeaning,
    ayahCount: AYAH_COUNTS[index],
    revelationType: revType,
    startAyah: cumulative,
  };
  cumulative += AYAH_COUNTS[index];
  return entry;
});

export const getSurahByNumber = (n: number): SurahMeta | undefined =>
  ALL_SURAHS.find(s => s.number === n);

export const getGlobalAyahNumber = (surahNumber: number, ayahNumber: number): number => {
  const surah = getSurahByNumber(surahNumber);
  if (!surah) return ayahNumber;
  return surah.startAyah + ayahNumber - 1;
};

export const TOTAL_AYAHS = 6236;
