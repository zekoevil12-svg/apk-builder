export interface Reciter {
  id: string;
  nameAr: string;
  nameEn: string;
  style: string;
  color: string;
}

// All reciters use the Al-Quran Cloud CDN
// URL: https://cdn.islamic.network/quran/audio/128/{id}/{globalAyahNumber}.mp3
export const RECITERS: Reciter[] = [
  {
    id: 'ar.alafasy',
    nameAr: 'مشاري راشد العفاسي',
    nameEn: 'Mishary Rashid Alafasy',
    style: 'مرتّل',
    color: '#1E4D6B',
  },
  {
    id: 'ar.abdurrahmaansudais',
    nameAr: 'عبد الرحمن السديس',
    nameEn: 'Abdurrahman Al-Sudais',
    style: 'مرتّل',
    color: '#2E6B50',
  },
  {
    id: 'ar.saoodashurym',
    nameAr: 'سعود الشريم',
    nameEn: 'Saud Al-Shuraim',
    style: 'مرتّل',
    color: '#6B2E1E',
  },
  {
    id: 'ar.mahermuaiqly',
    nameAr: 'ماهر المعيقلي',
    nameEn: 'Maher Al-Muaiqly',
    style: 'مرتّل',
    color: '#4A2E6B',
  },
  {
    id: 'ar.husarymujawwad',
    nameAr: 'محمود خليل الحصري',
    nameEn: 'Mahmoud Khalil Al-Husary',
    style: 'مجوّد',
    color: '#6B5A1E',
  },
];

export const DEFAULT_RECITER = RECITERS[0];

export const getAudioUrl = (reciterId: string, globalAyahNumber: number): string =>
  `https://cdn.islamic.network/quran/audio/128/${reciterId}/${globalAyahNumber}.mp3`;

export const getReciterById = (id: string): Reciter =>
  RECITERS.find(r => r.id === id) ?? RECITERS[0];
