import { Platform } from 'react-native';

// Built-in ayahs for key surahs (always available offline)
import { surahs as builtInSurahs } from './quran';

let FileSystem: any = null;
const getFS = () => {
  if (!FileSystem && Platform.OS !== 'web') {
    try { FileSystem = require('expo-file-system'); } catch {}
  }
  return FileSystem;
};

export interface AyahData {
  number: number;
  arabic: string;
  translation: string;
}

const getTextCacheDir = () => {
  const fs = getFS();
  return fs ? `${fs.documentDirectory}quran_text/` : null;
};

const getTextCachePath = (surahNumber: number) =>
  `${getTextCacheDir()}${surahNumber}.json`;

// Fetch from Al-Quran Cloud API
const fetchSurahText = async (surahNumber: number): Promise<AyahData[] | null> => {
  try {
    const [arRes, enRes] = await Promise.all([
      fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}`),
      fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/en.asad`),
    ]);
    if (!arRes.ok || !enRes.ok) return null;
    const arData = await arRes.json();
    const enData = await enRes.json();

    const arAyahs = arData.data?.ayahs ?? [];
    const enAyahs = enData.data?.ayahs ?? [];

    return arAyahs.map((a: any, i: number) => ({
      number: a.numberInSurah,
      arabic: a.text,
      translation: enAyahs[i]?.text ?? '',
    }));
  } catch { return null; }
};

export const loadSurahAyahs = async (surahNumber: number): Promise<AyahData[] | null> => {
  // 1. Check built-in data
  const builtin = builtInSurahs.find(s => s.number === surahNumber);
  if (builtin) return builtin.ayahs;

  const fs = getFS();

  // 2. Check local cache
  if (fs) {
    try {
      const path = getTextCachePath(surahNumber);
      const info = await fs.getInfoAsync(path);
      if (info.exists) {
        const raw = await fs.readAsStringAsync(path);
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
  }

  // 3. Fetch from API and cache
  const fetched = await fetchSurahText(surahNumber);
  if (fetched && fs) {
    try {
      const dir = getTextCacheDir();
      if (dir) {
        const dirInfo = await fs.getInfoAsync(dir);
        if (!dirInfo.exists) await fs.makeDirectoryAsync(dir, { intermediates: true });
        await fs.writeAsStringAsync(getTextCachePath(surahNumber), JSON.stringify(fetched));
      }
    } catch {}
  }

  return fetched;
};

export const isSurahTextCached = async (surahNumber: number): Promise<boolean> => {
  const builtin = builtInSurahs.find(s => s.number === surahNumber);
  if (builtin) return true;
  const fs = getFS();
  if (!fs) return false;
  try {
    const path = getTextCachePath(surahNumber);
    const info = await fs.getInfoAsync(path);
    return info.exists;
  } catch { return false; }
};

export const downloadAllText = async (
  onProgress?: (done: number, total: number) => void
): Promise<void> => {
  const builtinNums = new Set(builtInSurahs.map(s => s.number));
  for (let i = 1; i <= 114; i++) {
    if (!builtinNums.has(i)) {
      await loadSurahAyahs(i); // downloads + caches
    }
    onProgress?.(i, 114);
  }
};
