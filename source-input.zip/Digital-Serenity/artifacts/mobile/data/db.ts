import { Platform } from 'react-native';

export interface JournalEntry {
  id: number;
  title: string;
  content: string;
  font: string;
  mood: string;
  created_at: number;
  updated_at: number;
}

// In-memory fallback for web (real SQLite used on Android/iOS)
let memStore: JournalEntry[] = [];
let memNextId = 1;

const isNative = Platform.OS !== 'web';

let _SQLite: any = null;
const getSQLite = () => {
  if (!_SQLite && isNative) {
    try { _SQLite = require('expo-sqlite'); } catch {}
  }
  return _SQLite;
};

let _db: any = null;
const getDb = () => {
  if (_db) return _db;
  const SQL = getSQLite();
  if (!SQL) return null;
  try {
    _db = SQL.openDatabaseSync('alsakeena.db');
    _db.execSync(`
      CREATE TABLE IF NOT EXISTS journals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL DEFAULT 'بدون عنوان',
        content TEXT NOT NULL DEFAULT '',
        font TEXT NOT NULL DEFAULT 'amiri',
        mood TEXT DEFAULT '',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );
    `);
    return _db;
  } catch {
    return null;
  }
};

export const getAllJournals = (): JournalEntry[] => {
  try {
    const db = getDb();
    if (!db) return [...memStore].sort((a, b) => b.updated_at - a.updated_at);
    return db.getAllSync('SELECT * FROM journals ORDER BY updated_at DESC') as JournalEntry[];
  } catch { return []; }
};

export const getJournal = (id: number): JournalEntry | null => {
  try {
    const db = getDb();
    if (!db) return memStore.find(e => e.id === id) ?? null;
    return db.getFirstSync('SELECT * FROM journals WHERE id = ?', [id]) ?? null;
  } catch { return null; }
};

export const createJournal = (title: string, content: string, font: string, mood: string): number => {
  const now = Date.now();
  const db = getDb();
  if (!db) {
    const entry: JournalEntry = { id: memNextId++, title, content, font, mood, created_at: now, updated_at: now };
    memStore.push(entry);
    return entry.id;
  }
  try {
    const result = db.runSync(
      'INSERT INTO journals (title, content, font, mood, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [title, content, font, mood, now, now]
    );
    return result.lastInsertRowId;
  } catch { return -1; }
};

export const updateJournal = (id: number, title: string, content: string, font: string, mood: string): void => {
  const db = getDb();
  if (!db) {
    const i = memStore.findIndex(e => e.id === id);
    if (i >= 0) memStore[i] = { ...memStore[i], title, content, font, mood, updated_at: Date.now() };
    return;
  }
  try { db.runSync('UPDATE journals SET title=?, content=?, font=?, mood=?, updated_at=? WHERE id=?', [title, content, font, mood, Date.now(), id]); } catch {}
};

export const deleteJournal = (id: number): void => {
  const db = getDb();
  if (!db) { memStore = memStore.filter(e => e.id !== id); return; }
  try { db.runSync('DELETE FROM journals WHERE id=?', [id]); } catch {}
};

export const initDb = (): void => { if (isNative) getDb(); };
