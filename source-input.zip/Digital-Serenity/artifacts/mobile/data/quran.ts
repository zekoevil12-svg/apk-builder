export interface Ayah {
  number: number;
  arabic: string;
  translation: string;
}

export interface Surah {
  number: number;
  nameArabic: string;
  nameEnglish: string;
  meaning: string;
  ayahs: Ayah[];
  totalAyahs: number;
}

export const surahs: Surah[] = [
  {
    number: 1, nameArabic: 'الفاتحة', nameEnglish: 'Al-Fatiha', meaning: 'The Opening',
    totalAyahs: 7,
    ayahs: [
      { number: 1, arabic: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', translation: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.' },
      { number: 2, arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', translation: '[All] praise is [due] to Allah, Lord of the worlds —' },
      { number: 3, arabic: 'الرَّحْمَٰنِ الرَّحِيمِ', translation: 'The Entirely Merciful, the Especially Merciful,' },
      { number: 4, arabic: 'مَالِكِ يَوْمِ الدِّينِ', translation: 'Sovereign of the Day of Recompense.' },
      { number: 5, arabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', translation: 'It is You we worship and You we ask for help.' },
      { number: 6, arabic: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', translation: 'Guide us to the straight path —' },
      { number: 7, arabic: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', translation: 'The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.' },
    ],
  },
  {
    number: 93, nameArabic: 'الضحى', nameEnglish: 'Ad-Duha', meaning: 'The Morning Hours',
    totalAyahs: 11,
    ayahs: [
      { number: 1, arabic: 'وَالضُّحَىٰ', translation: 'By the morning brightness' },
      { number: 2, arabic: 'وَاللَّيْلِ إِذَا سَجَىٰ', translation: 'And [by] the night when it covers with darkness,' },
      { number: 3, arabic: 'مَا وَدَّعَكَ رَبُّكَ وَمَا قَلَىٰ', translation: 'Your Lord has not taken leave of you, nor has He detested [you].' },
      { number: 4, arabic: 'وَلَلْآخِرَةُ خَيْرٌ لَّكَ مِنَ الْأُولَىٰ', translation: 'And the Hereafter is better for you than the first [life].' },
      { number: 5, arabic: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', translation: 'And your Lord is going to give you, and you will be satisfied.' },
      { number: 6, arabic: 'أَلَمْ يَجِدْكَ يَتِيمًا فَآوَىٰ', translation: 'Did He not find you an orphan and give [you] refuge?' },
      { number: 7, arabic: 'وَوَجَدَكَ ضَالًّا فَهَدَىٰ', translation: 'And He found you lost and guided [you],' },
      { number: 8, arabic: 'وَوَجَدَكَ عَائِلًا فَأَغْنَىٰ', translation: 'And He found you poor and made [you] self-sufficient.' },
      { number: 9, arabic: 'فَأَمَّا الْيَتِيمَ فَلَا تَقْهَرْ', translation: 'So as for the orphan, do not oppress [him].' },
      { number: 10, arabic: 'وَأَمَّا السَّائِلَ فَلَا تَنْهَرْ', translation: 'And as for the petitioner, do not repel [him].' },
      { number: 11, arabic: 'وَأَمَّا بِنِعْمَةِ رَبِّكَ فَحَدِّثْ', translation: 'But as for the favor of your Lord, report [it].' },
    ],
  },
  {
    number: 94, nameArabic: 'الشرح', nameEnglish: 'Ash-Sharh', meaning: 'The Relief',
    totalAyahs: 8,
    ayahs: [
      { number: 1, arabic: 'أَلَمْ نَشْرَحْ لَكَ صَدْرَكَ', translation: 'Did We not expand for you, [O Muhammad], your breast?' },
      { number: 2, arabic: 'وَوَضَعْنَا عَنكَ وِزْرَكَ', translation: 'And We removed from you your burden' },
      { number: 3, arabic: 'الَّذِي أَنقَضَ ظَهْرَكَ', translation: 'Which had weighed upon your back' },
      { number: 4, arabic: 'وَرَفَعْنَا لَكَ ذِكْرَكَ', translation: 'And raised high for you your repute.' },
      { number: 5, arabic: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا', translation: 'For indeed, with hardship [will be] ease.' },
      { number: 6, arabic: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا', translation: 'Indeed, with hardship [will be] ease.' },
      { number: 7, arabic: 'فَإِذَا فَرَغْتَ فَانصَبْ', translation: 'So when you have finished [your duties], then stand up [for worship].' },
      { number: 8, arabic: 'وَإِلَىٰ رَبِّكَ فَارْغَب', translation: 'And to your Lord direct [your] longing.' },
    ],
  },
  {
    number: 97, nameArabic: 'القدر', nameEnglish: 'Al-Qadr', meaning: 'The Power',
    totalAyahs: 5,
    ayahs: [
      { number: 1, arabic: 'إِنَّا أَنزَلْنَاهُ فِي لَيْلَةِ الْقَدْرِ', translation: 'Indeed, We sent the Qur\'an down during the Night of Decree.' },
      { number: 2, arabic: 'وَمَا أَدْرَاكَ مَا لَيْلَةُ الْقَدْرِ', translation: 'And what can make you know what is the Night of Decree?' },
      { number: 3, arabic: 'لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ', translation: 'The Night of Decree is better than a thousand months.' },
      { number: 4, arabic: 'تَنَزَّلُ الْمَلَائِكَةُ وَالرُّوحُ فِيهَا بِإِذْنِ رَبِّهِم مِّن كُلِّ أَمْرٍ', translation: 'The angels and the Spirit descend therein by permission of their Lord for every matter.' },
      { number: 5, arabic: 'سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ', translation: 'Peace it is until the emergence of dawn.' },
    ],
  },
  {
    number: 99, nameArabic: 'الزلزلة', nameEnglish: 'Az-Zalzala', meaning: 'The Earthquake',
    totalAyahs: 8,
    ayahs: [
      { number: 1, arabic: 'إِذَا زُلْزِلَتِ الْأَرْضُ زِلْزَالَهَا', translation: 'When the earth is shaken with its [final] earthquake' },
      { number: 2, arabic: 'وَأَخْرَجَتِ الْأَرْضُ أَثْقَالَهَا', translation: 'And the earth discharges its burdens' },
      { number: 3, arabic: 'وَقَالَ الْإِنسَانُ مَا لَهَا', translation: 'And man says, "What is [wrong] with it?"' },
      { number: 4, arabic: 'يَوْمَئِذٍ تُحَدِّثُ أَخْبَارَهَا', translation: 'That Day, it will report its news' },
      { number: 5, arabic: 'بِأَنَّ رَبَّكَ أَوْحَىٰ لَهَا', translation: 'Because your Lord has commanded it.' },
      { number: 6, arabic: 'يَوْمَئِذٍ يَصْدُرُ النَّاسُ أَشْتَاتًا لِّيُرَوْا أَعْمَالَهُمْ', translation: 'That Day, the people will depart separated [into categories] to be shown [the result of] their deeds.' },
      { number: 7, arabic: 'فَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَرَهُ', translation: 'So whoever does an atom\'s weight of good will see it,' },
      { number: 8, arabic: 'وَمَن يَعْمَلْ مِثْقَالَ ذَرَّةٍ شَرًّا يَرَهُ', translation: 'And whoever does an atom\'s weight of evil will see it.' },
    ],
  },
  {
    number: 103, nameArabic: 'العصر', nameEnglish: 'Al-Asr', meaning: 'The Declining Day',
    totalAyahs: 3,
    ayahs: [
      { number: 1, arabic: 'وَالْعَصْرِ', translation: 'By time,' },
      { number: 2, arabic: 'إِنَّ الْإِنسَانَ لَفِي خُسْرٍ', translation: 'Indeed, mankind is in loss,' },
      { number: 3, arabic: 'إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ', translation: 'Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience.' },
    ],
  },
  {
    number: 108, nameArabic: 'الكوثر', nameEnglish: 'Al-Kawthar', meaning: 'The Abundance',
    totalAyahs: 3,
    ayahs: [
      { number: 1, arabic: 'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ', translation: 'Indeed, We have granted you, [O Muhammad], al-Kawthar.' },
      { number: 2, arabic: 'فَصَلِّ لِرَبِّكَ وَانْحَرْ', translation: 'So pray to your Lord and sacrifice [to Him alone].' },
      { number: 3, arabic: 'إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ', translation: 'Indeed, your enemy is the one cut off.' },
    ],
  },
  {
    number: 109, nameArabic: 'الكافرون', nameEnglish: 'Al-Kafirun', meaning: 'The Disbelievers',
    totalAyahs: 6,
    ayahs: [
      { number: 1, arabic: 'قُلْ يَا أَيُّهَا الْكَافِرُونَ', translation: 'Say, "O disbelievers,"' },
      { number: 2, arabic: 'لَا أَعْبُدُ مَا تَعْبُدُونَ', translation: '"I do not worship what you worship."' },
      { number: 3, arabic: 'وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ', translation: '"Nor are you worshippers of what I worship."' },
      { number: 4, arabic: 'وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ', translation: '"Nor will I be a worshipper of what you worship."' },
      { number: 5, arabic: 'وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ', translation: '"Nor will you be worshippers of what I worship."' },
      { number: 6, arabic: 'لَكُمْ دِينُكُمْ وَلِيَ دِينِ', translation: '"For you is your religion, and for me is my religion."' },
    ],
  },
  {
    number: 110, nameArabic: 'النصر', nameEnglish: 'An-Nasr', meaning: 'The Divine Support',
    totalAyahs: 3,
    ayahs: [
      { number: 1, arabic: 'إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ', translation: 'When the victory of Allah has come and the conquest,' },
      { number: 2, arabic: 'وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا', translation: 'And you see the people entering into the religion of Allah in multitudes,' },
      { number: 3, arabic: 'فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ إِنَّهُ كَانَ تَوَّابًا', translation: 'Then exalt [Him] with praise of your Lord and ask forgiveness of Him. Indeed, He is ever Accepting of repentance.' },
    ],
  },
  {
    number: 112, nameArabic: 'الإخلاص', nameEnglish: 'Al-Ikhlas', meaning: 'The Sincerity',
    totalAyahs: 4,
    ayahs: [
      { number: 1, arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ', translation: 'Say, "He is Allah, [who is] One,"' },
      { number: 2, arabic: 'اللَّهُ الصَّمَدُ', translation: '"Allah, the Eternal Refuge."' },
      { number: 3, arabic: 'لَمْ يَلِدْ وَلَمْ يُولَدْ', translation: '"He neither begets nor is born,"' },
      { number: 4, arabic: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', translation: '"Nor is there to Him any equivalent."' },
    ],
  },
  {
    number: 113, nameArabic: 'الفلق', nameEnglish: 'Al-Falaq', meaning: 'The Daybreak',
    totalAyahs: 5,
    ayahs: [
      { number: 1, arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ', translation: 'Say, "I seek refuge in the Lord of daybreak"' },
      { number: 2, arabic: 'مِن شَرِّ مَا خَلَقَ', translation: '"From the evil of that which He created"' },
      { number: 3, arabic: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', translation: '"And from the evil of darkness when it settles"' },
      { number: 4, arabic: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ', translation: '"And from the evil of the blowers in knots"' },
      { number: 5, arabic: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', translation: '"And from the evil of an envier when he envies."' },
    ],
  },
  {
    number: 114, nameArabic: 'الناس', nameEnglish: 'An-Nas', meaning: 'Mankind',
    totalAyahs: 6,
    ayahs: [
      { number: 1, arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ', translation: 'Say, "I seek refuge in the Lord of mankind,"' },
      { number: 2, arabic: 'مَلِكِ النَّاسِ', translation: '"The Sovereign of mankind."' },
      { number: 3, arabic: 'إِلَٰهِ النَّاسِ', translation: '"The God of mankind,"' },
      { number: 4, arabic: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ', translation: '"From the evil of the retreating whisperer"' },
      { number: 5, arabic: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ', translation: '"Who whispers [evil] into the breasts of mankind"' },
      { number: 6, arabic: 'مِنَ الْجِنَّةِ وَالنَّاسِ', translation: '"From among the jinn and mankind."' },
    ],
  },
  {
    number: 67, nameArabic: 'الملك', nameEnglish: 'Al-Mulk', meaning: 'The Sovereignty',
    totalAyahs: 30,
    ayahs: [
      { number: 1, arabic: 'تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ', translation: 'Blessed is He in whose hand is dominion, and He is over all things competent —' },
      { number: 2, arabic: 'الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ', translation: '[He] who created death and life to test you [as to] which of you is best in deed — and He is the Exalted in Might, the Forgiving —' },
      { number: 3, arabic: 'الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ', translation: '[And] who created seven heavens in layers. You do not see in the creation of the Most Merciful any inconsistency. So return [your] vision [to the sky]; do you see any breaks?' },
      { number: 4, arabic: 'ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ', translation: 'Then return [your] vision twice again. [Your] vision will return to you humbled while it is fatigued.' },
      { number: 5, arabic: 'وَلَقَدْ زَيَّنَّا السَّمَاءَ الدُّنْيَا بِمَصَابِيحَ وَجَعَلْنَاهَا رُجُومًا لِّلشَّيَاطِينِ ۖ وَأَعْتَدْنَا لَهُمْ عَذَابَ السَّعِيرِ', translation: 'And We have certainly beautified the nearest heaven with stars and have made [from] them what is thrown at the devils and have prepared for them the punishment of the Blaze.' },
    ],
  },
  {
    number: 36, nameArabic: 'يس', nameEnglish: 'Ya-Sin', meaning: 'Ya Sin',
    totalAyahs: 83,
    ayahs: [
      { number: 1, arabic: 'يس', translation: 'Ya, Seen.' },
      { number: 2, arabic: 'وَالْقُرْآنِ الْحَكِيمِ', translation: 'By the wise Qur\'an.' },
      { number: 3, arabic: 'إِنَّكَ لَمِنَ الْمُرْسَلِينَ', translation: 'Indeed you, [O Muhammad], are from among the messengers,' },
      { number: 4, arabic: 'عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ', translation: 'On a straight path.' },
      { number: 5, arabic: 'تَنزِيلَ الْعَزِيزِ الرَّحِيمِ', translation: '[This is] a revelation of the Exalted in Might, the Merciful,' },
    ],
  },
  {
    number: 55, nameArabic: 'الرحمن', nameEnglish: 'Ar-Rahman', meaning: 'The Beneficent',
    totalAyahs: 78,
    ayahs: [
      { number: 1, arabic: 'الرَّحْمَٰنُ', translation: 'The Most Merciful' },
      { number: 2, arabic: 'عَلَّمَ الْقُرْآنَ', translation: 'Taught the Qur\'an,' },
      { number: 3, arabic: 'خَلَقَ الْإِنسَانَ', translation: 'Created man,' },
      { number: 4, arabic: 'عَلَّمَهُ الْبَيَانَ', translation: '[And] taught him eloquence.' },
      { number: 5, arabic: 'الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ', translation: 'The sun and moon [move] by precise calculation,' },
      { number: 13, arabic: 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ', translation: 'So which of the favors of your Lord would you deny?' },
    ],
  },
  {
    number: 18, nameArabic: 'الكهف', nameEnglish: 'Al-Kahf', meaning: 'The Cave',
    totalAyahs: 110,
    ayahs: [
      { number: 1, arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَل لَّهُ عِوَجًا', translation: '[All] praise is [due] to Allah, who has sent down upon His Servant the Book and has not made therein any deviance.' },
      { number: 10, arabic: 'إِذْ أَوَى الْفِتْيَةُ إِلَى الْكَهْفِ فَقَالُوا رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا', translation: '[Mention] when the youths retreated to the cave and said, "Our Lord, grant us from Yourself mercy and prepare for us from our affair right guidance."' },
    ],
  },
  {
    number: 56, nameArabic: 'الواقعة', nameEnglish: 'Al-Waqiah', meaning: 'The Inevitable',
    totalAyahs: 96,
    ayahs: [
      { number: 1, arabic: 'إِذَا وَقَعَتِ الْوَاقِعَةُ', translation: 'When the Occurrence occurs,' },
      { number: 2, arabic: 'لَيْسَ لِوَقْعَتِهَا كَاذِبَةٌ', translation: 'There is, at its occurrence, no denial.' },
      { number: 3, arabic: 'خَافِضَةٌ رَّافِعَةٌ', translation: 'It will bring down [some] and raise up [others].' },
    ],
  },
];

export const getDailyWisdom = (): { arabic: string; source: string } => {
  const wisdoms = [
    { arabic: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا', source: 'سورة الشرح - ٥:٦' },
    { arabic: 'وَلَسَوْفَ يُعْطِيكَ رَبُّكَ فَتَرْضَىٰ', source: 'سورة الضحى - ٥' },
    { arabic: 'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', source: 'سورة البقرة - ١٥٣' },
    { arabic: 'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', source: 'سورة الطلاق - ٣' },
    { arabic: 'سَلَامٌ هِيَ حَتَّىٰ مَطْلَعِ الْفَجْرِ', source: 'سورة القدر - ٥' },
    { arabic: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ', source: 'سورة الرعد - ٢٨' },
    { arabic: 'وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ', source: 'سورة الحديد - ٤' },
    { arabic: 'رَبِّ اشْرَحْ لِي صَدْرِي', source: 'سورة طه - ٢٥' },
    { arabic: 'حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ', source: 'سورة التوبة - ١٢٩' },
    { arabic: 'وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ', source: 'سورة غافر - ٦٠' },
  ];
  const today = new Date().getDate();
  return wisdoms[today % wisdoms.length];
};

export default surahs;
