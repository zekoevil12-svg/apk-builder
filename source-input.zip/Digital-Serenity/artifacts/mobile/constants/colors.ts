const colors = {
  light: {
    // Backgrounds
    bg: '#F9F6EF',
    bgCard: '#FFFFFF',
    bgAlt: '#F2EDE3',
    bgDark: '#1A120A',

    // Gold tones
    gold: '#C09434',
    goldDark: '#8B6A1A',
    goldLight: '#EDD98A',
    goldMuted: '#E8D5A3',
    goldSurface: '#FBF5E6',

    // Text
    textPrimary: '#1C1008',
    textSecondary: '#4A3728',
    textMuted: '#8A7060',
    textLight: '#B8A898',
    textInverse: '#FAF8F4',

    // Accents
    accent: '#7B3520',
    accentLight: '#C4684A',
    emerald: '#2E6B50',
    emeraldLight: '#4A9E78',

    // UI
    border: '#DDD0BC',
    borderLight: '#EDE5D8',
    shadow: 'rgba(28,16,8,0.08)',
    shadowMd: 'rgba(28,16,8,0.14)',
    shadowLg: 'rgba(28,16,8,0.22)',
    overlay: 'rgba(10,5,2,0.65)',
    overlayLight: 'rgba(10,5,2,0.35)',

    // Status
    success: '#2E6B50',
    error: '#8B2020',
    warning: '#B8790A',
    info: '#1A4A7B',

    // Feature colors
    quranColor: '#1E4D6B',
    journalColor: '#4A2E6B',
    drawingColor: '#6B2E1E',
    aiColor: '#1E5C3A',
  },
  radius: {
    xs: 6,
    sm: 10,
    md: 16,
    lg: 24,
    xl: 32,
    full: 9999,
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
};

export type AppColors = typeof colors.light;
export default colors;
